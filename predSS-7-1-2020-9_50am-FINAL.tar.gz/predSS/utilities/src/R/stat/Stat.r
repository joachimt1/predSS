# ======================================================================================
# . Stat.r : some additional statistical functions.
# . -------
# ======================================================================================

library(Hmisc);       # For function errbar().
library(vioplot);     # For function Stat.trellisBoxplots().

Stat.PVALMIN_FOR_COMBINE = 1.0e-50;    # Stand-ins for P = 0 for Stat.combinePvalMean and Stat.combinePvalMedian.
Stat.PMAX = 1000;                      # Maximum number of genes for heat maps.
Stat.NMAX = 1000;                      # Maximum number of samples for heat maps.
Stat.NLEVELMAX = 10;                   # Maximum number of levels allowed for some functions.
Stat.NMAX_FOR_INTERSECTION = 1000;     # Maximum number of genes to concatenate when summarizing geneset enrichment results.
Stat.CV_INFINITE_MCKAY = 4.0;          # 'Infinite' CV under confidence interval test with modified McKay method.
Stat.EPS_FOR_PLOT_DATA_MATRIX = 1.0e-9;          # 'Infinitesimal' value in kludge for colors in Stat.plotDataMatrix().
Stat.FLOOR_FOR_AUC = 1.0 / (1.0 + exp(20));      # Insures that logit(1/auc) <= 20
Stat.CEILING_FOR_AUC = 1.0 / (1.0 + exp(-20));   # Insures that logit(1/auc) >= -20
Stat.PMAX_FOR_TRELLIS_BOXPLOTS = 30;             # Maximum number of genes (columns) allowed for display in Stat.trellisBoxplots.
Stat.NCUMAX_FOR_TRELLIS_BOXPLOTS = 30;           # Maximum number of classes (rows) allowed for display in Stat.trellisBoxplots.
Stat.EPS_FOR_TRELLIS_BOXPLOTS = 1.0e-9;          # 'Infinitesimal' value for jittering all-tied values.
Stat.EPS_MAX_FOR_EM = 0.01;                      # Convergence criterion for EM algorithm (fractional change in parameters).

# ======================================================================================
# . Stat.computeFDR : computes the FDR values corresponding to a list of P-values.
# . ---------------   Note that this calculation entirely relies on the P-values.
# .
# .   aFdr = Stat.computeFDR(ap);
# .
# .   IN:
# .   ap = input array of P-values.
# .
# .   OUT:
# .   aFdr = the corresponding FDR values.
# .
# ======================================================================================

Stat.computeFDR <- function(ap)
{

  # .................................................................................
  if (!is.numeric(ap)) {
    msg  = cat("ERROR: from Stat.computeFDR: input object ap is not a numeric array.\n");
    stop(msg);
  }

  n = length(ap);

  if (n == 0) {
    msg  = cat("ERROR: from Stat.computeFDR: input array ap has 0 length.\n");
    stop(msg);
  }
  # .................................................................................


  # .................................................................................
  # . Do the actual computation here:
  # .................................................................................
  index = sort.list(ap);          # Permutation index for sort in increasing order.
  apSorted = ap[index];

  aFdrSorted = n * apSorted / (1:n);
  aFdrSorted = ifelse(aFdrSorted > 1.0, 1.0, aFdrSorted);

  aFdr = rep(1.0, times = n);
  aFdr[index] = aFdrSorted;
  # .................................................................................



  # .................................................................................
  # . Special adjustment :
  # .................................................................................
  if (!is.null(dim(ap))) {
    if (length(dim(ap)) == 2) {
      aFdr = matrix(aFdr, nrow = nrow(ap), ncol = ncol(ap), byrow = FALSE);
      rownames(aFdr) = rownames(ap);
      colnames(aFdr) = colnames(ap);      
    }
  }
  # .................................................................................  

  
  # .................
  return (aFdr);
  # .................

}

# ======================================================================================
# . End of Stat.computeFDR.
# ======================================================================================





# ======================================================================================
# . Stat.computeFDRandNF : computes the FDR values corresponding to a list of P-values.
# . --------------------   and the corresponding number of items for p <= p0.
# .
# .  Syntax :
# .   rs = Stat.computeFDRandNF(ap);
# .
# .  In:
# .   ap = input array of P-values.
# .
# .  Out:
# .    rs = list, with members :
# .
# .      apUp = array of P-values ("p0"), sorted in increasing order.
# .    afdrUp = corresponding FDRs.
# .     anfUp = corresponding number found so far, for p <= p0
# .   
# ======================================================================================

Stat.computeFDRandNF <- function(ap)
{

    # .................................................................................
    if (!is.numeric(ap)) {
      msg  = cat("ERROR: from Stat.computeFDRandNF: input object ap is not a numeric array.\n");
      stop(msg);
    }

    n = length(ap);

    if (n == 0) {
      msg  = cat("ERROR: from Stat.computeFDRandNF: input array ap has 0 length.\n");
      stop(msg);
    }
    # .................................................................................


    # .................................................................................
    # . Sort P-values ascending, then compute corresponding FDRs :
    # .................................................................................
    apUp = sort(ap, decreasing = FALSE);
    afdrUp = Stat.computeFDR(apUp);
    anfUp = 1:n;                                 # Corresponding number found.
    # .................................................................................


  
    # .....................................
    # . Package results :
    # .....................................
    rs = list(apUp = apUp,
              afdrUp = afdrUp,
              anfUp = anfUp);
    # .....................................

  
    # ..............
    return (rs);
    # ..............

}

# ======================================================================================
# . End of Stat.computeFDRandNF.
# ======================================================================================




# ======================================================================================
# . Stat.computeSandFDR : computes the sensitivity S and FDR values on the basis of 
# . -------------------   a list of P-values *and* a companion list giving the true
# .                       positives.
# .
# .   sf = Stat.computeSandFDR(av, ap);
# .
# .   IN:
# .       av = list of states (1 = true positive, 0 = true negative).
# .       ap = input array of P-values (or actually, any statistics for
# .            which small values means high significance).
# .
# .   OUT: sf has members:
# .
# .     aS = array of empirical sensitivity values.
# .   aFDR = array of empirical FDR values.
# ======================================================================================

Stat.computeSandFDR <- function(av, ap)
{

  # .................................................................................
  if (!is.numeric(ap)) {
    msg  = cat("ERROR: from Stat.computeSandFDR: input object ap is not a numeric array.\n");
    stop(msg);
  }

  n = length(ap);

  if (n == 0) {
    msg  = cat("ERROR: from Stat.computeSandFDR: input array ap has 0 length.\n");
    stop(msg);
  }

  if (!is.numeric(av)) {
    msg  = cat("ERROR: from Stat.computeSandFDR: input object av is not a numeric array.\n");
    stop(msg);
  }

  ntemp = length(av);

  if (ntemp != n) {
    msg  = cat("ERROR: from Stat.computeSandFDR: input array av not same length as input array ap.\n");
    stop(msg);
  }
  # .................................................................................


  # ...........................................
  nposTot = length(av[av == 1]);

  if (nposTot > 0) {
    fac1 = 1.0 / nposTot;
  } else {
    fac1 = 0.0;
  }
  # ...........................................


  
  # .................................................................................
  # . Do the actual computation here:
  # .................................................................................
  index = sort.list(ap);          # Permutation index for sort in increasing order.
  apSorted = NULL;
  avSorted = NULL;
  
  for (i in 1:n) {
    apSorted[i] = ap[index[i]];
    avSorted[i] = av[index[i]];      
  }

  aSSorted = NULL;
  aFdrSorted = NULL;

  npos = 0;                      # Tally of true positives.
  nneg = 0;                      # Tally of true negatives.
  
  for (i in 1:n) {
    if (avSorted[i] == 1) {
      npos = npos + 1;
    } else {
      nneg = nneg + 1;
    }

    nf = npos + nneg;            # Total number found so far.

    S = fac1 * npos;             # Sensitivity estimate.
    fdr = nneg / nf;             # FDR estimate.

    aSSorted[i] = S;
    aFdrSorted[i] = fdr;
  }

  aS = NULL;
  aFdr = NULL;
  
  for (i in 1:n) {
    aS[index[i]] = aSSorted[i];
    aFdr[index[i]] = aFdrSorted[i];
  }
  # .................................................................................

  
  # ............................
  sf = list(aS = aS,
            aFdr = aFdr);

  return (sf);
  # ............................

}

# ======================================================================================
# . End of Stat.computeSandFDR.
# ======================================================================================




# ======================================================================================
# . Stat.computeSmax : computes the maximum sensitivity S at a given FDR cutoff value.
# . ----------------   
# .
# .   smax = Stat.computeSmax(as, afdr, fdrc);
# .
# .   IN:
# .       as = input array of sensitivities.
# .       afdr = input array of corresponding FDRs.
# .       fdrc = FDR threshold.
# .
# .   OUT:
# .     smax = largest sensitivity with FDR <= fdrc.
# .
# ======================================================================================

Stat.computeSmax <- function(as, afdr, fdrc)
{

  # .................................................................................
  if (!is.numeric(afdr)) {
    msg  = cat("ERROR: from Stat.computeSmax: input object afdr is not a numeric array.\n");
    stop(msg);
  }

  n = length(afdr);

  if (n == 0) {
    msg  = cat("ERROR: from Stat.computeSmax: input array afdr has 0 length.\n");
    stop(msg);
  }

  if (!is.numeric(as)) {
    msg  = cat("ERROR: from Stat.computeSmax: input object as is not a numeric array.\n");
    stop(msg);
  }

  ntemp = length(as);

  if (ntemp != n) {
    msg  = cat("ERROR: from Stat.computeSmax: input array as not same length as input array afdr.\n");
    stop(msg);
  }
  # .................................................................................


  # .................................................................................
  # . Do the actual computation here:
  # .................................................................................
  index = sort.list(as, decreasing = TRUE);     # Permutation index for sort in decreasing order.

  asSorted = NULL;
  afdrSorted = NULL;
  
  for (i in 1:n) {
    asSorted[i] = as[index[i]];
    afdrSorted[i] = afdr[index[i]];      
  }

  smax = 0.0;
  # ..................................................................
  # . Visit starting with largest sensitivities:
  # ..................................................................
  for (i in 1:n) {
    if (afdrSorted[i] <= fdrc) {
      smax = asSorted[i];
      break;
    }
  }
  # .................................................................................

  
  # ..............
  return (smax);
  # ..............

}

# ======================================================================================
# . End of Stat.computeSmax.
# ======================================================================================




# ======================================================================================
# . Stat.getMlog10 : computes - log10(P) for the input P-value array.
# . --------------   For p = 0, places 1 - log10(smallest non-zero value).
# .
# .   amlog10p = Stat.getMlog10(ap);
# .
# .   IN:
# .       ap = input array of P-values.
# .
# .   OUT:
# .       amlog10p = - log10(ap).
# .
# ======================================================================================

Stat.getMlog10 <- function(ap)
{

     # .................................................................................
     if (!is.numeric(ap)) {
       msg  = cat("ERROR: from Stat.getMlog10: input object ap is not a numeric array.\n");
       stop(msg);
     }

     n = length(ap);
     # .................................................................................


     # .................................................................................
     apBuf = ap[ap > 0.0];
      
     if (length(apBuf) > 0) {
       mlog10Zero = 1 - log(min(apBuf), base = 10.0);      # Standin for -log10(0)
     } else {
       mlog10Zero = 20.0;                                  # Standin for -log10(0)
     }
          
     amlog10p = ifelse(ap > 0.0, - log(ap, base = 10.0), mlog10Zero);   # - log10(P).
     # .................................................................................


     # ....................
     return (amlog10p);
     # ....................
}

# ======================================================================================
# . End of Stat.getMlog10.
# ======================================================================================





# ======================================================================================
# . Stat.pvalEmpirical : computes empirical P-values for the input vector of values,
# . ------------------   against a set of reference values.
# .
# .
# .       ap = Stat.pvalEmpirical(ax, axRef);
# .
# . Input:
# .
# .        ax = input vector, say of length n.
# .     axref = reference vector; values randomly generated against null hypothesis
# .             distribution.
# .
# . Output:
# .  
# .        ap = empirical P-values array, length n. Based on a two-sided test.
# .
# ======================================================================================

Stat.pvalEmpirical <- function(ax, axRef)
{

  # ...............................
  n = length(ax);
  nr = length(axRef);
  # ...............................


  # ...................................................................
  fac1 = 1.0 / nr;
  ap = c(1);
  
  for (i in 1:n) {
    ay = (axRef > ax[i]);   # Prob. x > x_obs.
    count = sum(ay);

    ptemp = fac1 * count;

    if (ptemp > 0.5) {
      ptemp = 1.0 - ptemp;
    }

    ap[i] = 2.0 * ptemp;

  }
  # ...................................................................    

  
  # ............
  return (ap);
  # ............  
  
}

# ======================================================================================
# . End of Stat.pvalEmpirical.
# ======================================================================================








# ============================================================================================
# . Stat.makeHeatmapColors : generates heat map colors.
# . ----------------------
# .
# . From Steve Rowley heatmap example : 11-14-2007
# .
# . Syntax :
# .      col = Stat.makeHeatmapColors(numColors);
# .
# ============================================================================================

Stat.makeHeatmapColors <- function(numColors) {             # Green (small) -> black -> red (big)
  halfZeros <- rep(0, numColors %/% 2)                 # 0's and ramp for half range each
  halfSteps <- seq(from = 0, to = 1, length.out = numColors - length(halfZeros))
  rgb(g = c(rev(halfSteps), halfZeros),                # Green: ramp down followed by 0's
      r = c(halfZeros,      halfSteps),                # Red:   0's followed by ramp up
      b = c(halfZeros,      halfZeros))                # Blue:  0's everywhere
}

# ============================================================================================
# . End of makeHeatmapColors.
# ============================================================================================





# ======================================================================================================
# . Stat.makeHeatmapColorsOnRangeRG : generates heat map colors, with a Spotfire-like color ramp.
# . -------------------------------   RED-GREEN palette (red = high, green = low).
# .
# . Adapted from Steve Rowley heatmap example.
# .
# .    Syntax :
# .      col = Stat.makeHeatmapColorsOnRangeRG(nc,
# .                                            xminSat, xmidSat, xmaxSat,
# .                                            xminObs, xmaxObs);
# .
# .    In :
# .           nc = degree of discretization of colors (e.g. 256 gives a fairly continuous pallette).
# .
# .      xminSat = low reference value, at which color saturates to bright green.
# .      xmidSat = reference value for black.
# .      xmaxSat = high reference value, at which color saturates to bright red.
# .
# .      xminObs = smallest observed value to be plotted.
# .      xmaxObs = largest observed value to be plotted.
# .
# .                 - note that we must have:  xminSat < xmidSat < xmaxSat
# .                                            xminObs <= xmaxObs
# .
# ======================================================================================================

Stat.makeHeatmapColorsOnRangeRG <- function(nc,
                                            xminSat, xmidSat, xmaxSat,
                                            xminObs, xmaxObs)
{

  # ..................................................................................
  if (xminSat >= xmaxSat) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRG : xminSat >= xmaxSat\n");
    msg = paste(msg, "xminSat = " , xminSat, " xmaxSat = ", xmaxSat, "\n");
    stop(msg);
  }

  if (xmidSat <= xminSat) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRG : xmidSat <= xminSat\n");
    msg = paste(msg, "xmidSat = " , xmidSat, " xmaxSat = ", xminSat, "\n");
    stop(msg);
  }

  if (xmidSat >= xmaxSat) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRG : xmidSat >= xmaxSat\n");
    msg = paste(msg, "xmidSat = " , xmidSat, " xmaxSat = ", xmaxSat, "\n");
    stop(msg);
  }

  if (xminObs > xmaxObs) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRG : xminObs > xmaxObs\n");
    msg = paste(msg, "xminObs = " , xminObs, " xmaxObs = ", xmaxObs, "\n");
    stop(msg);
  }

  if (nc <= 2) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRG :\n");
    msg = paste(msg, "nc = " , nc, " must be at least 3.\n");
    stop(msg);
  }    
  # ..................................................................................  


  
  # ..................................................................................
  # . Generate linearly graded color vectors :
  # ..................................................................................  
  nc1 = nc - 1;
  dx = (xmaxObs - xminObs) / (nc - 1);
  ax = xminObs + dx * (0:nc1);                # Spans all of xminObs <= x <= xmaxObs.

  ar = Stat.fR(ax, xmidSat, xmaxSat);         # RED channel.
  ag = Stat.fG(ax, xminSat, xmidSat);         # GREEN channel.
  ab = rep(0.0, times = nc);                  # BLUE channel is all-zero.

  col = rgb(r = ar,  g = ag,  b = ab);
  # ..................................................................................


  # ...............
  return (col);
  # ...............
  
}

# ======================================================================================================
# . End of Stat.makeHeatmapColorsOnRangeRG.
# ======================================================================================================




# ======================================================================================================
# . Stat.makeHeatmapColorsOnRangeRB : generates heat map colors, with a Spotfire-like color ramp.
# . -------------------------------   RED-BLUE palette (red = high, blue = low).
# .
# . Adapted from Steve Rowley heatmap example.
# .
# .    Syntax :
# .      col = Stat.makeHeatmapColorsOnRangeRB(nc,
# .                                            xminSat, xmidSat, xmaxSat,
# .                                            xminObs, xmaxObs);
# .
# .    In :
# .           nc = degree of discretization of colors (e.g. 256 gives a fairly continuous pallette).
# .
# .      xminSat = low reference value, at which color saturates to bright blue.
# .      xmidSat = reference value for black.
# .      xmaxSat = high reference value, at which color saturates to bright red.
# .
# .      xminObs = smallest observed value to be plotted.
# .      xmaxObs = largest observed value to be plotted.
# .
# .                 - note that we must have:  xminSat < xmidSat < xmaxSat
# .                                            xminObs <= xmaxObs
# .
# ======================================================================================================

Stat.makeHeatmapColorsOnRangeRB <- function(nc,
                                          xminSat, xmidSat, xmaxSat,
                                          xminObs, xmaxObs)
{

  # ..................................................................................
  if (xminSat >= xmaxSat) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRB : xminSat >= xmaxSat\n");
    msg = paste(msg, "xminSat = " , xminSat, " xmaxSat = ", xmaxSat, "\n");
    stop(msg);
  }

  if (xmidSat <= xminSat) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRB : xmidSat <= xminSat\n");
    msg = paste(msg, "xmidSat = " , xmidSat, " xmaxSat = ", xminSat, "\n");
    stop(msg);
  }

  if (xmidSat >= xmaxSat) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRB : xmidSat >= xmaxSat\n");
    msg = paste(msg, "xmidSat = " , xmidSat, " xmaxSat = ", xmaxSat, "\n");
    stop(msg);
  }

  if (xminObs > xmaxObs) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRB : xminObs > xmaxObs\n");
    msg = paste(msg, "xminObs = " , xminObs, " xmaxObs = ", xmaxObs, "\n");
    stop(msg);
  }

  if (nc <= 2) {
    msg = paste("ERROR: from Stat.makeHeatmapColorsOnRangeRB :\n");
    msg = paste(msg, "nc = " , nc, " must be at least 3.\n");
    stop(msg);
  }    
  # ..................................................................................  


  
  # ..................................................................................
  # . Generate linearly graded color vectors :
  # ..................................................................................  
  nc1 = nc - 1;
  dx = (xmaxObs - xminObs) / (nc - 1);
  ax = xminObs + dx * (0:nc1);                # Spans all of xminObs <= x <= xmaxObs.

  ar = Stat.fR(ax, xmidSat, xmaxSat);         # RED channel.
  ag = rep(0.0, times = nc);                  # GREEN channel is all-zero.
  ab = Stat.fG(ax, xminSat, xmidSat);         # BLUE channel (use function fG for profile).

  col = rgb(r = ar,  g = ag,  b = ab);
  # ..................................................................................


  # ...............
  return (col);
  # ...............
  
}

# ======================================================================================================
# . End of Stat.makeHeatmapColorsOnRangeRB.
# ======================================================================================================





# ======================================================================================================
# . Stat.fR : RED channel generator. Utility function for heatmap color generator. 
# . -------
# .          value = Stat.fR(x, xmidSat, xmaxSat);
# .
# .
# .                        ^
# .            1           |          1
# . fG(x)  -----------     |      ------------- fR(x)
# .                   \    |     /
# .                    \   |    /
# .                     \  |   /
# .             xminSat  \ |  /  xmaxSat
# .                  |    \| /    | 
# .        ------------------------------------->  x
# .                     xmidSat   
# .
# ======================================================================================================

Stat.fR <- function(x, xmidSat, xmaxSat)
{

  # .....................................................................................  
  fac1 = 1.0 / (xmaxSat - xmidSat);
  value = ifelse(x <= xmidSat, 0.0, ifelse(x <= xmaxSat, (x - xmidSat) * fac1,  1.0));
  # .....................................................................................

  
  # ...............
  return (value)
  # ............... 
  

}

# ======================================================================================================
# . End of Stat.fR.
# ======================================================================================================




# ======================================================================================================
# . Stat.fG : GREEN channel generator. Utility function for heatmap color generator. 
# . -------
# .          value = Stat.fG(x, xminSat, xmidSat);
# .
# .
# .                        ^
# .            1           |          1
# . fG(x)  -----------     |      ------------- fR(x)
# .                   \    |     /
# .                    \   |    /
# .                     \  |   /
# .             xminSat  \ |  /  xmaxSat
# .                  |    \| /    | 
# .        ------------------------------------->  x
# .                     xmidSat
# .
# ======================================================================================================

Stat.fG <- function(x, xminSat, xmidSat)
{

  # .........................................................................................  
  fac1 = 1.0 / (xmidSat - xminSat);
  value = ifelse(x <= xminSat, 1.0, ifelse(x <= xmidSat, (xmidSat - x) * fac1,  0.0));
  # .........................................................................................

  
  # ...............
  return (value)
  # ............... 
  

}

# ======================================================================================================
# . End of Stat.fG.
# ======================================================================================================







# ======================================================================================
# . Stat.mlogP : computes minus the log-likehood, for an arbitrary input PDF and
# . ----------   set of arguments.
# .
# .       Stat.mlogP(f, param, ax);
# .
# . IN:
# .
# .   f = reference to PDF of interest. This should be a one-dimensional function,
# .       with x = ... as argument to dependent variable.
# .   param = set of parameters.
# .   ax = array of (one-dimensional) values.
# .
# . OUT:
# .
# .   Returns minus the log-likelihood, that is :
# .
# .                 1      n
# .       mll = -  --- .  sum    log (f(x  | theta))
# .                 n     i = 1          i
# .
# .   where n = number of samples, x_i the i-th samples, and theta the PDF parameters.
# .
# ======================================================================================

Stat.mlogP <- function(f, param, ax)
{

  # .................
  args = param;
  args$x = ax;
  n = length(ax);
  # .................

  # .................................................
  mll = - (1.0 / n) * sum(log(do.call(f, args)));
  # .................................................

  # .............
  return(mll);
  # .............

}

# ======================================================================================
# . End of Stat.mlogP.
# ======================================================================================




# ======================================================================================
# . Stat.pvalFTest : computes two-sided P-values based on F test.
# . --------------
# .
# .    ap = Stat.pvalFTest(af, nu1, nu2)
# .
# . IN:
# .   af = value(s) of F statistic.
# .   nu1 = degrees of freedom nu1 for theoretical F distribution.
# .   nu2 = degrees of freedom nu2 for theoretical F distribution.
# .
# . OUT:
# .   ap = P-value(s) from two-sided test on each input value.
# .
# ======================================================================================

Stat.pvalFTest <- function(af, nu1, nu2)
{

  # .................................................................
  # . Compute two-sided P-values :
  # .................................................................
  ap = stats::pf(af, df1 = nu1, df2 = nu2, lower.tail = FALSE);  # Compute upper tail.

  indexSmall = which(ap <= 0.5);
  indexBig = which(ap > 0.5);

  ap[indexSmall] = 2.0 * ap[indexSmall];      # These make it
  ap[indexBig] = 2.0 * (1.0 - ap[indexBig]);  # a two-sided P-value.
  # ..................................................................


  # ............
  return (ap);
  # ............

}

# ======================================================================================
# . End of Stat.pvalFTest.
# ======================================================================================




# ======================================================================================
# . Stat.adjustFDistribution : adjusts an empirical data set to an F distribution
# . ------------------------   of given degrees of freedom.
# .                         
# .
# .     au = Stat.adjustFDistribution(ax, nu1, nu2);
# .
# . IN:
# .
# .   ax = array of empirical F statistic values.
# .   nu1 = degrees of freedom nu1 for theoretical F distribution.
# .   nu2 = degrees of freedom nu2 for theoretical F distribution.
# .
# . OUT:
# .
# .   au = rescaled distribution.
# .
# ======================================================================================

Stat.adjustFDistribution <- function(ax, nu1, nu2)
{

  # .............................................................
  # . Theroretical quantiles for the given degrees of freedom :
  # .............................................................
  yt_25 = qf(p = 0.25, df1 = nu1, df2 = nu2);
  yt_50 = qf(p = 0.5, df1 = nu1, df2 = nu2);
  yt_75 = qf(p = 0.75, df1 = nu1, df2 = nu2);
  # .............................................................


  
  # ....................................................................................
  xe_50 = median(ax);          # Emprirical median.
  beta = yt_50 / xe_50;        # Overall scaling term.

  ay = beta * ax;              # Rescaled distribution.
  ye_25 = quantile(ay, 0.25);  # Emprirical 25th percentile of rescaled deistribution.
  ye_50 = yt_50;               # Emprirical 50th percentile of rescaled deistribution.
  ye_75 = quantile(ay, 0.75);  # Emprirical 75th percentile of rescaled deistribution.

  gamma_plus = (yt_75 - yt_50) / (ye_75 - ye_50);
  gamma_minus = ((1.0 / yt_25) - (1.0 / yt_50)) / ((1.0 / ye_25) - (1.0 / ye_50));

  au = ay;

  au[ay >= yt_50] = yt_50 + gamma_plus * (ay[ay >= yt_50] - yt_50);
  au[ay < yt_50] = 1.0 / (1.0 / yt_50 + gamma_minus * (1.0 / ay[ay < yt_50] - 1.0 / yt_50));
  # ....................................................................................


  # ...........
  return (au);
  # ...........
  
}

# ======================================================================================
# . End of Stat.adjustFDistribution.
# ======================================================================================




# ======================================================================================
# . Stat.testAdjustFDistribution : tests adjustment of empirical data set to an F distribution
# . ----------------------------   of given degrees of freedom.
# .                         
# .
# .     au = Stat.testAdjustFDistribution(ax, nu1, nu2, fdr0);
# .
# . IN:
# .   ax = array of (one-dimensional) values.
# .   nu1 = degrees of freedom nu1 for theoretical F distribution.
# .   nu2 = degrees of freedom nu2 for theoretical F distribution.
# .   fdr0 = FDR for point calculation of number found.
# .
# . OUT:
# .   Generates plots of PDFs and CDFs for raw and adjusted (renormalized) variables.
# .   Prints numbers found for point calculation FDR.
# .
# ======================================================================================

Stat.testAdjustFDistribution <- function(ax, nu1, nu2, fdr0)
{

  # .................................................................
  cat(" ..........  Entry in Stat.testAdjustFDistribution.\n");
  # .................................................................  

  
  # .................................................................
  # . Compute two-sided P-values for raw distribution:
  # .................................................................
  apRaw = stats::pf(ax, df1 = nu1, df2 = nu2, lower.tail = FALSE);  # Compute upper tail.

  indexSmall = which(apRaw <= 0.5);
  indexBig = which(apRaw > 0.5);

  apRaw[indexSmall] = 2.0 * apRaw[indexSmall];      # These make it
  apRaw[indexBig] = 2.0 * (1.0 - apRaw[indexBig]);  # a two-sided P-value.
  # ..................................................................


  # ..................................................................
  # . Compute renormalized values :
  # ..................................................................
  au = Stat.adjustFDistribution(ax, nu1, nu2);
  # ..................................................................

  
  # ..................................................................
  # . Test of symmetry under x --> 1 /x transformation.
  # . This is really just for debugging.
  # ..................................................................
#  axInv = 1.0 / ax;
#  auInv = Stat.adjustFDistribution(axInv, nu2, nu1);
#  au = 1.0 / auInv;
  # ..................................................................  


  # .................................................................
  # . Compute two-sided P-values for renormalized distribution:
  # .................................................................
  ap = stats::pf(au, df1 = nu1, df2 = nu2, lower.tail = FALSE);  # Compute upper tail.

  indexSmall = which(ap <= 0.5);
  indexBig = which(ap > 0.5);

  ap[indexSmall] = 2.0 * ap[indexSmall];      # These make it
  ap[indexBig] = 2.0 * (1.0 - ap[indexBig]);  # a two-sided P-value.
  # ..................................................................


  # ..................................................................
  # . Generate arrays for CDF of -log10(P) distributions :
  # ..................................................................
  n = length(ap);
  apSort = sort(ap, decreasing = TRUE);
  mlog10ApSort = - log(apSort, base = 10.0);
  log10Nf = log(n:1, base= 10.0);

  apSortRaw = sort(apRaw, decreasing = TRUE);
  mlog10ApSortRaw = - log(apSortRaw, base = 10.0);

  log10NfNull = log(n, base = 10.0) - mlog10ApSort;
  # ..................................................................
  

  
  # ........................................................................
  # . Compute FDRs :
  # ........................................................................
  afdr = (apSort * n) /(n:1);
  afdrRaw = (apSortRaw * n) / (n:1);

  afdr[afdr >= 1.0] = 1.0;
  afdrRaw[afdrRaw >= 1.0] = 1.0;  

  nf = n - min(which(afdr < fdr0))
  nfRaw = n - min(which(afdrRaw < fdr0));

  msg = paste("---------------------------------------------------------\n");
  msg = paste(msg, "Renormalization of samples against F distribution: \n");
  msg = paste(msg, "nu1 = ", nu1, ", nu2 = ", nu2, "\n");
  msg = paste(msg, "Number NF of instances found for FDR <= ", fdr0, "\n");
  msg = paste(msg, "Raw data: NF = ", nfRaw, "\n");
  msg = paste(msg, "Renormalized data: NF = ", nf, "\n");
  msg = paste(msg, "---------------------------------------------------------\n");

  cat(msg);
  # ........................................................................


  
  # ..................................................................
  # . Make plots here :
  # ..................................................................  
  par(mfrow = c(1, 2));
  cex.main.OLD = par("cex.main");
  par(cex.main = 0.7);
  # ..................................................................
  # . Compare distributions :
  # ..................................................................
  axT = rf(n, df1 = nu1, df2 = nu2);   # Theoretical sample of same size.
  
  axCut = ax[ax <= 10.0];     # Cutoff is a little arbitrary.
  auCut = au[au <= 10.0];
  axTCut = axT[axT <= 10.0];
  
  dxCut = density(axCut);
  duCut = density(auCut);
  dxTCut = density(axTCut);

  cap = "PDFs for raw, theo. and renormalized data.";
  xlab = "x";
  ylab = "f_x(x)";
  plot(duCut, type = 'l', main = cap,
                          xlab = xlab,
                          ylab = ylab);      # Renormalized distribtion.
  lines(dxCut, type = 'l', col = 'blue');    # Raw distribution.
  lines(dxTCut, type = 'l', col = 'red');    # Theoretical distribution.
  # ..................................................................
  # . Compare CDFs for -log10(P-value) :
  # ..................................................................
  cap = "P-value CDFs for raw, theo. and renormalized data.";
  xlab = "-log10(P0)";
  ylab = "log10(NF(P <= P0))";  

  plot(mlog10ApSort, log10Nf, type = 'l', main = cap, xlab = xlab, ylab = ylab);
  lines(mlog10ApSort, log10NfNull, type = 'l', col = 'red');
  lines(mlog10ApSortRaw, log10Nf, type = 'l', col = 'blue');    
  # ..................................................................
  # . Restore default graphics parameters :
  # ..................................................................  
  par(cex.main = cex.main.OLD);                    
  par(mfrow = c(1, 1));
  # ..................................................................  


  # .........................................................
  cat(" ..........  Exit Stat.testAdjustFDistribution.\n");
  # .........................................................


  # ..........
  return (0);
  # ..........

}

# ======================================================================================
# . End of Stat.testAdjustFDistribution.
# ======================================================================================





# ============================================================================================
# . Stat.thinOutRowOrColumnNames : thins out row or column names, prior to
# . ----------------------------   graphical display as a heat map.
# .
# . Syntax :
# .   axNew = Stat.thinOutRowOrColumnNames(ax, nxlabMax = 32, nylabMax = 32);
# .
# . In:
# .   ax = input array.
# .
# .   nxlabMax = maximum number of labels for rows.
# .   nylabMax = maximum number of labels for columns.
# .
# . Out:
# .   axNew = Same numerical data as input array, but with row or column names thinned out.
# .
# ============================================================================================

Stat.thinOutRowOrColumnNames <- function(ax, nxlabMax = 32, nylabMax = 32)
{

   # ............
   axBuf = ax;
   # ............   

  
   # .........................................................................
   # . Thin out row or column names for large dimensions :
   # .........................................................................
   nx = nrow(ax);
   ny = ncol(ax);
   
   #xxxx nxlabMax = 32;   # Maximum number of labels for rows.
   #xxxx nylabMax = 32;   # Maximum number of labels for columns.

   if (nx > nxlabMax) {
     ixStep = 1 + floor(nx / nxlabMax);    # Step size.
     abuf = rownames(ax);
     index = (1:nx) - 1;
     
     abuf[index%%ixStep != 0] = "";
     rownames(axBuf) = abuf;
   }

   if (ny > nylabMax) {
     iyStep = 1 + floor(ny / nylabMax);    # Step size.
     abuf = colnames(ax);
     index = (1:ny) - 1;
     
     abuf[index%%iyStep != 0] = "";
     colnames(axBuf) = abuf;
   }
   # ...........................................................................


   # .............
   return (axBuf);
   # .............

}

# ============================================================================================
# . End of Stat.thinOutRowOrColumnNames.
# ============================================================================================




# ============================================================================================
# . Stat.thinOutNames : thins out string elements in the array, by replacing a subset
# . -----------------   of elements by empty strings ''. Typically to be used for thinning
# .                     out labels prior to graphical display.
# .
# . Syntax :
# .
# .   y = Stat.thinOutNames(x, nmax = 32);
# .
# . In:
# .
# .   x = input array, consisting of string elements.
# .   nmax = maximum number of non-empty labels to be kept
# .
# . Out:
# .
# .   y = same as input array, but with a subset of elements replaced by ''.
# .
# ============================================================================================

Stat.thinOutNames <- function(x, nmax = 32)
{
  
   # .........................................................................
   y = x;
   n = length(x);

   if (n > nmax) {
     step = 1 + floor(n / nmax);    # Step size.
     index = (1:n) - 1;
     y[index%%step != 0] = "";
   }
   # ...........................................................................


   # ..........
   return (y);
   # ..........

}

# ============================================================================================
# . End of Stat.thinOutNames.
# ============================================================================================



# ============================================================================================
# . Stat.thinOutNamesRandom : thins out string elements in the array, by replacing a subset
# . -----------------------   of elements by empty strings ''. Typically to be used for thinning
# .                           out labels prior to graphical display.
# .
# .                           This version does a RANDOM subsampling.
# .
# . Syntax :
# .
# .   y = Stat.thinOutNamesRandom(x, nmax = 32, rng.seed = 777888);
# .
# . In:
# .
# .          x = input array, consisting of string elements.
# .       nmax = maximum number of non-empty labels to be kept.
# .   rng.seed = random number seed for sampling the labels.
# .              Note that this seed is used only temporarily (the
# .              generator is rest to its previous state afterward).
# .
# . Out:
# .
# .   y = same as input array, but with a subset of elements replaced by ''.
# .
# ============================================================================================

Stat.thinOutNamesRandom <- function(x, nmax = 32, rng.seed = 777888)
{

   # .....................
   stopifnot(nmax > 0);
   # .....................
   
  
   # .........................................................................
   n = length(x);
     
   if (n > nmax) {
     seedBuf = .Random.seed;    # Save current seed.

     set.seed(rng.seed);        # Set to this temporary state.
     indexBuf = 1:n;
     indexSub = sample(indexBuf, size = nmax);

     y = rep('', times = n);    # Initialize with all-empty.
     y[indexSub] = x[indexSub]; # Assign subset.

     .Random.seed = seedBuf;    # Reset to previous state.
   } else {
     y = x
   };
   # ...........................................................................


   # ..........
   return (y);
   # ..........

}

# ============================================================================================
# . End of Stat.thinOutNamesRandom.
# ============================================================================================














# ============================================================================================
# .  Stat.plotDataMatrix : displays a 2-dimensional data matrix as a heat map.
# .  -------------------   This is a basically a wrapper for the R function heatmap.
# .
# .  Syntax:
# .
# .     hm =    Stat.plotDataMatrix(ax,
# .                                 flagClusterx = 'yes', flagClustery = 'no',
# .                                 flagScalex = 'no', flagScaley = 'yes',
# .                                 nxlabMax = 32, nylabMax = 32,
# .                                 xlab, ylab,
# .                                 caption,
# .                                 variableName = "",
# .                                 xminSat = -1.0, xmidSat = 0.0, xmaxSat = 1.0,
# .                                 typeAutoCol = 'NONE',
# .                                 palette = 'RG',
# .                                 arowSide = NULL,
# .                                 acolSide = NULL);
# .
# .  where:
# .
# .  In:
# .                ax = nx * ny : two-dimensional matrix or data frame.
# .
# .     flagClusterx = yes/no : if yes, cluster on the rows. If no, do not cluster.
# .                    The default is no.
# .     flagClustery = yes/no : if yes, cluster on the columns. If no, do not cluster.
# .                    The default is no.
# .       flagScalex = yes/no : if yes, scale each row separately. If no, do not scale
# .                    (scale = subtract mean, divide by standard deviation).
# .                    The default is no.
# .
# .                    Note that if both flagScalex = "yes" and flagScaley = "yes"
# .                    scaling is first applied to the COLUMNS, then to the ROWS.
# .
# .       flagScaley = yes/no : if yes, scale each column separately. If no, do not scale
# .                    (scale = subtract mean, divide by standard deviation).
# .                    The default is no.
# .         nxlabMax = maximum number of labels for rows.
# .         nylabMax = maximum number of labels for columns.
# .             xlab = caption for x axis.
# .             ylab = caption for y axis.
# .          caption = main plot caption.
# .     variableName = string indicating name of variable being displayes (default is "").
# .
# .          xminSat = thresholds for color scheme : the transition is {green --> black --> red}
# .          xmidSat = We must have : xminSat < xmidSat < xmaxSat.
# .          xmaxSat = Green color saturates  for x < xminSat, tapers from intense green to black
# .                    in the range xminSat <= x <= xmidSat, tapers from black to intense red in the
# .                    range xmidSat <= x <= xmaxSat, and is saturated red for xmaxStat < x.
# .                    Default values are {-1, 0, 1}.
# .                    These thresholds are used only if typeAutoCol = 'NONE' (see below).
# .
# .      typeAutoCol = defines how the color scale thresholds are defined. Allowed values :
# .
# .                      - 'NONE'       : use explicit values {xminSat, xmidSat, xmaxSat}.
# .                      - 'symmetric'  : set xmidSat = 0.0,
# .                                           xminSat = - max(|ax|)
# .                                           xmaxSat =   max(|ax|)
# .                      - 'asymmetric' : set xminSat = min(ax),
# .                                           xmidSat = 0.5 * (min(ax) +  max(ax))
# .                                           xmaxSat = max(|ax|)
# .
# .         palette = defines color scheme; 'RG' (high = red, low = green), 'RB' (high = red, low = blue).
# .
# .        arowSide = colors for vertical side bar accompanying rows. Used in non-NULL, in which case
# .                   we must have length(arowSide) = nrow(ax).
# .
# .        acolSide = colors for horizontal side bar accompanying columns. Used in non-NULL, in which case
# .                   we must have length(acolSide) = ncol(ax).
# .
# .
# .
# .  Out:
# .         Heat map representation of the data matrix.
# .
# .         hm = list containing row and column sort indices, and sorted row and
# .              column names.
# ............................................................................................
# . * Details of display :
# .
# .                                 Y options
# .                                 ---------
# .
# .                            flagClustery = 'yes'
# .                                    |
# .                                    |
# .                             dendrogram appears
# .                                 here
# .
# .                            flagScaley = 'yes'
# .                                     |
# .                                     |
# .                                 scale each
# .                                 column
# .                                 individually
# .
# .                            |   |   |  . . . 
# .                            v   v   v
# .                          .............................
# .                          .   .   .   .   .   .   .   .
# .      X options           .............................
# .      ---------           .   .   .   .   .   .   .   .
# .                          .............................
# .   flagClusterx = 'yes'   .   .   .   .   .   .   .   .
# .           |              .............................    
# .           |              .   .   .   .   .   .   .   .    
# .    dendrogram appears    .............................    
# .        here              .   .   .   .   .   .   .   .   ylab    
# .                          .............................   appears 
# .                          .   .   .   .   .   .   .   .   here    
# .                          .............................
# .   flagScalex = 'yes'     .   .   .   .   .   .   .   .
# .           |              .............................
# .           |          .   .   .   .   .   .   .   .   .
# .       scale each     .   .............................
# .       row            .   .   .   .   .   .   .   .   .
# .       individually       .............................
# .                     ->   .   .   .   .   .   .   .   .
# .                          .............................
# .                     ->   .   .   .   .   .   .   .   .
# .                          .............................
# .                     ->   .   .   .   .   .   .   .   .
# .                          .............................
# .
# .
# .                               xlab appears here
# .
# ============================================================================================

Stat.plotDataMatrix <- function(ax,
                                flagClusterx = 'no',
                                flagClustery = 'no',
                                flagScalex = 'no',
                                flagScaley = 'no',
                                nxlabMax = 32,
                                nylabMax = 32,
                                xlab,
                                ylab,
                                caption,
                                variableName = "",
                                xminSat = -1.0, xmidSat = 0.0, xmaxSat = 1.0,
                                typeAutoCol = 'NONE',
                                palette = 'RG',
                                arowSide = NULL,
                                acolSide = NULL)
{

   # ......................................................................................
   stopifnot((flagClusterx == "yes") || (flagClusterx == "no"),
             (flagClustery == "yes") || (flagClustery == "no"),
             (flagScalex == "yes") || (flagScalex == "no"),
             (flagScaley == "yes") || (flagScaley == "no"));

   stopifnot(xminSat < xmidSat);
   stopifnot(xmidSat < xmaxSat);

   stopifnot((typeAutoCol == 'NONE')
             || (typeAutoCol == 'symmetric')
             || (typeAutoCol == 'asymmetric'));
   stopifnot((palette == 'RG') || (palette == 'RB'));
   # ......................................................................................


   # ......................................................................................
   # . Check on color side bars :
   # ......................................................................................
   if (!is.null(arowSide)) {
     if (length(arowSide) != nrow(ax)) {
       cat("ERROR: from Stat.plotDataMatrix:\n");
       cat("length arowSide not the same as number of rows in ax\n");
       stop();
     }
   }

   if (!is.null(acolSide)) {
     if (length(acolSide) != ncol(ax)) {
       cat("ERROR: from Stat.plotDataMatrix:\n");
       cat("length acolSide not the same as number of columns in ax\n");
       stop();
     }
   }   
   # ......................................................................................   

   

   # ..................................................................
   # . Set to default, in case values got scrambled along the way :
   # ..................................................................
   par(omd = c(0, 1, 0, 1));
   # ..................................................................


   
   
   # ................................................................................
   # . Do the required scaling :
   # . Subtract mean, divide by standard deviation.
   # ................................................................................
   if (flagScaley == "yes") {
     ax = Math.scaleRobust(ax);                # This scales each column independently.
   }

   if (flagScalex == "yes") {   
     ax = t(Math.scaleRobust(t(ax)));          # This scales each row independently.
   }
   # ................................................................................


   # .........................................................................
   # . Add to caption if scaling occurred (clustering is obvious from the
   # . dendrogram(s)) :
   # .........................................................................
   captionAdd = "";
   
   if (flagScalex == 'yes') {
     captionAdd = paste(captionAdd, "rows individually scaled", sep = "");
   }

   if (flagScaley == 'yes') {
     if (nchar(captionAdd) > 0) {
       captionAdd = paste(captionAdd, "; ", sep = "");
     }
     captionAdd = paste(captionAdd, "columns individually scaled", sep = "");
   }   

   caption = paste(caption, "\n", captionAdd, sep = "");
   # .........................................................................         
   

   
   # .........................................................................
   # . Thin out row or column names for large dimensions :
   # .........................................................................
   ar = rownames(ax);     # Cache the original row names.
   ac = colnames(ax);     # Cache the original column names.
   
   ax = Stat.thinOutRowOrColumnNames(ax, nxlabMax, nylabMax);
   # .........................................................................


   
   
   # .........................................................................
   # . Generate labels and colors :
   # . First adjust thresholds if specified :
   # .........................................................................
   if (typeAutoCol == 'symmetric') {
     temp1 = max(abs(ax), na.rm = TRUE);
     xminSat = - temp1;
     xmaxSat = temp1;
     xmidSat = 0.0;     
   }

   if (typeAutoCol == 'asymmetric') {
     xminSat = min(ax, na.rm = TRUE);
     xmaxSat = max(ax, na.rm = TRUE);
     xmidSat = 0.5 * (xminSat + xmaxSat);
   }   
   # .........................................................................


   

   # .........................................................................
   # . Build colors :
   # .........................................................................   
   xminObs = min(ax, na.rm = TRUE);
   xmaxObs = max(ax, na.rm = TRUE);   

   if (palette == 'RG') {
     heatmapColors = Stat.makeHeatmapColorsOnRangeRG(nc = 256,
                                                     xminSat = xminSat,
                                                     xmidSat = xmidSat,
                                                     xmaxSat = xmaxSat,
                                                     xminObs = xminObs,
                                                     xmaxObs = xmaxObs);
   } else if (palette == 'RB') {
     heatmapColors = Stat.makeHeatmapColorsOnRangeRB(nc = 256,
                                                     xminSat = xminSat,
                                                     xmidSat = xmidSat,
                                                     xmaxSat = xmaxSat,
                                                     xminObs = xminObs,
                                                     xmaxObs = xmaxObs);
   } else {
     stop();              # Failsafe.
   }     
   # .........................................................................


   # .......................................
   # . Get the current plot parameters :
   # .......................................
   op.OLD = par(no.readonly = TRUE);
   # .......................................

   
   # ................................................................
   # . Append number of elements for axis labels :
   # ................................................................
   nxIn = ncol(ax);
   nyIn = nrow(ax);

   xlab = paste(xlab, " (", nxIn, ")", sep = "");
   ylab = paste(ylab, " (", nyIn, ")", sep = "");   
   # ................................................................   

   
   
   # .......................................................................................................
   # . Now build the heat map.
   # .
   # . Adjust character size for the title :
   # .......................................................................................................
   cex.main.OLD = par("cex.main");
   nbuf = nchar(caption);
   nbuflo = 40;
   nbufhi = 100;
   
   if (nbuf <= nbuflo) {
     cex.main = 0.8;
   } else if (nbuf <= nbufhi) {
     cex.main = 0.8 - 0.3 * (nbuf - nbuflo) / (nbufhi - nbuflo);
   } else {
     cex.main = 0.5;
   }
     
   par(cex.main = cex.main);
   # .......................................................................................................
   # . Adjust values of cexRow and cexCol :
   # .......................................................................................................   
   cexRow = min(0.2 + 1/log10(nrow(ax)), 1.2);
   cexCol = min(0.3 + 1/log10(ncol(ax)), 1.2);
   # .......................................................................................................
   # . Set values for controlling clustering and generation of dendrograms :
   # .......................................................................................................   
   RowvValue = NA;                          # Default for no row clustering or dendrogram.
   
   if (flagClusterx == "yes") {
     RowvValue = NULL;                      # Compute row clustering and dendrogram.
   }

   ColvValue = NA;                          # Default for no column clustering or dendrogram.

   if (flagClustery == "yes") {
     ColvValue = NULL;                      # Compute column clustering and dendrogram.
   }
   # .......................................................................................................
   # . Now generate the heat map itself :
   # .......................................................................................................
   omd.OLD = par("omd");
   par(omd = c(0.15, 1, 0, 1));

   if (is.null(arowSide) && is.null(acolSide)) {
     hm = heatmap(ax,
                  Rowv = RowvValue,
                  Colv = ColvValue,   
                  scale =  "none",
                  na.rm = TRUE,
                  margins = c(20, 20),
                  col = heatmapColors,
                  labRow = NULL, labCol = NULL,
                  cexCol = cexCol,
                  cexRow = cexRow,       
                  main = caption,
                  xlab = xlab,
                  ylab = ylab);
   } else if (!is.null(arowSide) && is.null(acolSide)) {
          hm = heatmap(ax,
                  Rowv = RowvValue,
                  Colv = ColvValue,   
                  scale =  "none",
                  na.rm = TRUE,
                  margins = c(20, 20),
                  col = heatmapColors,
                  labRow = NULL, labCol = NULL,
                  cexCol = cexCol,
                  cexRow = cexRow,                   
                  main = caption,
                  xlab = xlab,
                  ylab = ylab,
                  RowSideColors = arowSide);
   } else if (is.null(arowSide) && !is.null(acolSide)) {
          hm = heatmap(ax,
                  Rowv = RowvValue,
                  Colv = ColvValue,   
                  scale =  "none",
                  na.rm = TRUE,
                  margins = c(20, 20),
                  col = heatmapColors,
                  labRow = NULL, labCol = NULL,
                  cexCol = cexCol,
                  cexRow = cexRow,                   
                  main = caption,
                  xlab = xlab,
                  ylab = ylab,
                  ColSideColors = acolSide);
   } else if (!is.null(arowSide) && !is.null(acolSide)) {
          hm = heatmap(ax,
                  Rowv = RowvValue,
                  Colv = ColvValue,   
                  scale =  "none",
                  na.rm = TRUE,
                  margins = c(20, 20),
                  col = heatmapColors,
                  labRow = NULL, labCol = NULL,
                  cexCol = cexCol,
                  cexRow = cexRow,                        
                  main = caption,
                  xlab = xlab,
                  ylab = ylab,
                  RowSideColors = arowSide,
                  ColSideColors = acolSide);
   }     
   # .......................................................................................................
   # . Add color bar to the left :
   # .......................................................................................................   
   par(new = TRUE);
   par(omd = c(0, 0.15, 0.0, 0.6));
   # .......................................................................................................
   # . Special kludge if values are all constant :
   # .......................................................................................................
   xminBuf = min(ax, na.rm = TRUE);
   xmaxBuf = max(ax, na.rm = TRUE);   

   if (xminBuf == xmaxBuf) {
     xminBuf = xminBuf - Stat.EPS_FOR_PLOT_DATA_MATRIX;
     xmaxBuf = xmaxBuf + Stat.EPS_FOR_PLOT_DATA_MATRIX;
   }
   # .......................................................................................................
   # . Now the color bar itself :
   # .......................................................................................................   
   image(x = 0, y = seq(from = xminBuf, to = xmaxBuf, along.with = heatmapColors),
         z = matrix(1:length(heatmapColors), ncol = length(heatmapColors)),
         ylim = c(xminSat, xmaxSat),
         col = heatmapColors, xaxt = "n", main = "color\nscale",
         xlab = "", ylab = variableName);
   # .......................................................................................................
   # . Add legend to the left :
   # .......................................................................................................   
   par(new = TRUE);
   par(omd = c(0, 0.35, 0.7, 1.0));      
   plot(c(0,1), c(0,1), xaxt = 'n', yaxt = 'n', col = 'white', xlab = "", ylab = "", axes = FALSE, bty = 'n');

   if (nchar(variableName) > 0) {
     temp1 = paste("Data matrix for ", variableName, " :\n",  sep = "");
   } else {
     temp1 = paste("Data matrix :\n", sep = "");     
   }
     
   temp1 = paste(temp1, "\nnrow = ", nrow(ax), sep = "");
   temp1 = paste(temp1, "\nncol = ", ncol(ax), sep = "");
   temp1 = paste(temp1, "\nmin(x) = ", format(min(ax, na.rm = TRUE), digits = 3), sep = "");
   temp1 = paste(temp1, "\nmax(x) = ", format(max(ax, na.rm = TRUE), digits = 3), sep = "");   
   
   text(0.0, 0.5, temp1, pos = 4, cex = 0.7);
   # .......................................................................................................
   # . Resume default values :
   # .......................................................................................................
   par(new = FALSE);
   par(omd = omd.OLD);
   par(cex.main = cex.main.OLD);
   # .......................................................................................................



   # .........................................................................
   # . Add the time axis here :
   # .........................................................................
   #xxx axis(side = 1);
   # .........................................................................            


   # ..................................
   # . Reset to old plot parameters :
   # ..................................   
   par(op.OLD);
   # ..................................    


   # ........................................................................................................................
   # . Generate arrays of the row and column names in the same order as
   # . in the heat map, then package into output list :
   # ........................................................................................................................
   arOrdered = ar[hm$rowInd];
   acOrdered = ac[hm$colInd];

   akRowInd = rep(0, length(hm$rowInd));
   akRowInd[hm$rowInd] = 1:length(hm$rowInd);     # akRowInd[1] is the actual row position in the heat map of gene 1, etc.
   
   akColInd = rep(0, length(hm$colInd));
   akColInd[hm$colInd] = 1:length(hm$colInd);     # akColInd[1] is the actual column position in the heat map of sample 1, etc.

   hdm = list(rowInd = hm$rowInd,   
              colInd = hm$colInd,
              arOrdered = arOrdered,      # Row names in same order as in heat map: bottom-to-top.
              acOrdered = acOrdered,      # Column names in same order as in heat map: left-to-right.
              akRowInd = akRowInd,        # Gives the discrete row coordinate of each gene in the final heat map.
              akColInd = akColInd);       # Gives the discrete column coordinate of each sample in the final heat map.     
   # ...........................................................................................................................
   
   
   # .............
   return (hdm);
   # .............
    
  
}

# ============================================================================================
# . End of Stat.plotDataMatrix.
# ============================================================================================






# ==========================================================================
# . Stat.qqNormCI : plots a normal QQ plot for the given series of input
# . -------------   numbers.
# .
# .        Stat.qqNormCI(y, caption = "Normal QQ Plot");
# .
# . This generates a plot of the values of y against the values of the
# . variable Z ~ N(0, 1) that obtains when the quantiles of y are mapped
# . into values of Z. One-standard-deviation confidence intervals are
# . also plotted.
# .
# ==========================================================================

Stat.qqNormCI <- function(y, caption = "Normal QQ Plot") 
{
	# ...............................................
	# . Compute basic quantities :
	# ...............................................
	n = length(y);    # Number of points.
	ybar = mean(y)    # Sample mean.
	s = sd(y);        # Sample standard deviation.
	# ...............................................


	# ..............................................................
	# . Establish quantiles :
	# ..............................................................
	ays = sort(y);                        # Sorted vector of data points.
	aq = ((1:n) - 0.5) / n;               # Vector of quantiles.
                                
	aqSigma = (1.0 / sqrt(n)) * sqrt(aq * (1.0 - aq)); # Vector of estimated sd(q).

	aqLo = aq * exp(- aqSigma / aq);          # Lower bound.
        aq1 = 1.0 - aq;
        aqHi = 1.0 - aq1 * exp(- aqSigma / aq1);  # Upper bound.
	# ..............................................................


	# ..............................................................
	# . Compute theoretical z-values, and map back to data set:
	# ..............................................................
	az = qnorm(aq);                       # Theoretical z values.
	azLo = qnorm(aqLo);                   # Lower bound.
	azHi = qnorm(aqHi);                   # Upper bound.

	ayT = ybar + s * az;                  # Theoretical distribution.
	ayTLo = ybar + s * azLo;              # Lower bound.
	ayTHi = ybar + s * azHi;              # Upper bound.
	# ..............................................................


        
	# ..............................................................
        # . Apply Shapiro-Wilk test of normality to determine a
        # . p-value :
	# ..............................................................
        if (length(y) > 5000) {
          ybuf = sample(y, size = 5000);    # Test requires 3 <= n <= 5000.
        } else {
          ybuf = y;
        }
          
        st  = shapiro.test(ybuf);
        pval = st$p.value;
        caption = paste(caption, ": P = ", sprintf("%8.3e", pval),
                        ", n = ", n, sep = "");
	# ..............................................................        
        


	# ..............................................................
	# . Plot here :
	# ..............................................................
	xlab = 'Z';
	plot(az, ays, type = 'p', main = caption, xlab = xlab, pch = 19);
	lines(az, ayT, type = 'l', col = 'black');
	lines(az, ayTLo, type = 'l', col = 'black', lty = 'dashed');
	lines(az, ayTHi, type = 'l', col = 'black', lty = 'dashed');
	# ..............................................................

	# ...........
	return (0);
	# ...........
}

# ==========================================================================
# . End of Stat.qqNormCI.
# ==========================================================================



# ======================================================================================
# . Stat.plotPvalueCD : plots the cumulative distribution of P-values in a log-log
# . -----------------   plot in which the null hypothesis appears as a straight line
# .                     of slope -1.
# .
# .   Syntax:
# .   Stat.plotPvalueCD(ap, mode = 'both', labelEffect = NULL);
# .
# .   In:
# .   ap = input array of P-values.
# .   mode = 'both', plot CDF of P-values, and also a plot of FDR on the same page,
# .          'pval', plot only CDF of P-values,
# .          'FDR', plot only FDR.
# .   labelEffect = prefix for plot caption (e.g. 'X', 'Z', 'ZX' or just '');
# .
# ======================================================================================

Stat.plotPvalueCD <- function(ap, mode = 'both', labelEffect = NULL)
{


  # .........................................................................................
  # . Remove missing values, if any :
  # .........................................................................................
  mask = !is.na(ap);

  if (sum(mask) == 0) {
    cat("ERROR: from Stat.plotPvalueCD: all P-values = NA");
    stop();
  }

  ap = ap[mask];                                                 # Restrict to non-NA values.
  # .........................................................................................  

  
  # .........................................................................................
  if (min(ap) < 0.0) {
    msg = "ERROR: from Stat.plotPvalueCD: some P-values < 0.";
    stop(msg);
  }
  
  if (max(ap) == 0.0) {
    ap = rep(Stat.PVALMIN_FOR_COMBINE, times = length(ap));   # Stand-in for all-0 values.
  }

  if ((mode != 'both') && (mode != 'pval') && (mode != 'FDR')) {
    msg = paste("ERROR: from Stat.plotPvalueCD: mode = ", mode,
                " is not valid. Valid: pval, FDR, both\n", sep = '');
    stop(msg);
  }
  # ..........................................................................................
  
  
  
  # .................................................................................
  # . Compute arrays for the P-values distribution :
  # .................................................................................
  n = length(ap);                                 # Total number of P-values.
  
  pmin = min(ap[ap > 0.0]);                       # Smallest non-zero P-value.
  mlog10pmin = - log(pmin, base = 10.0) + 1.0;    # Will be a stand-in for 0 values.

  amlog10p = ifelse(ap > 0.0, - log(ap, base = 10.0), mlog10pmin);
  amlog10p = sort(amlog10p);
  anf = (n + 1) - 1:n;                            # Number found for P < P0.
  alog10nf = log(anf, base = 10.0);               # Convert to log10.

  amlog10pNull = - log(anf / n, base = 10.0);     # P-value under null hypothesis.
  # .................................................................................


  
  # ........................................................................................
  # . Null distribution :
  # . under the null hypothesis that the P-values are truly indocative of probability, 
  # . the number Ne of hits expected for P <= P0 is given by :
  # .
  # .           Ne = N . P0
  # .
  # . so that :
  # .
  # .    log10(Ne) = log10(N) - (-log10(P0))
  # .
  # .........................................................................................
  amlog10pH0 = seq(from = 0.0, to = log10(n), length.out = 100)
  apH0 = 10^(-amlog10pH0);

  aNe = n * apH0;                                          # Mean.
  aNelo = qbinom(p = 0.025, size = n, prob = apH0);        # Lower bound of 95% CI.
  aNemed = qbinom(p = 0.5, size = n, prob = apH0);         # Median.
  aNehi = qbinom(p = 0.975, size = n, prob = apH0);        # Upper bound of 95% CI.
  
  alog10Ne = ifelse(aNe != -Inf, log10(aNe), 0.0);
  alog10Nelo = ifelse(aNelo != -Inf, log10(aNelo), 0.0);
  alog10Nehi = ifelse(aNehi != -Inf, log10(aNehi), 0.0);
  # .................................................................................  


  
  
  # .................................................................................
  # . Compute corresponding FDR :
  # .................................................................................
  apDown = sort(ap, decreasing = TRUE);
  afdr = Stat.computeFDR(apDown);
  # .................................................................................

  
  # .................................................................................
  # . Plot :
  # .................................................................................
  if (mode == 'both') {
    par(mfrow = c(2, 2));
  }
  
  captionPval = "P-value CDF (95% CI)";
  captionFDR = "FDR distribution";

  if (!is.null(labelEffect)) {
    captionPval = paste(labelEffect, ':', captionPval, sep = ' ');
    captionFDR = paste(labelEffect, ':', captionFDR, sep = ' ');    
  }

  xlim = c(0, max(amlog10p));
  
  if ((mode == 'both') || (mode == 'pval')) {
    plot(amlog10p, alog10nf, type = 'p', pch = 19,
         xlim = xlim,
         xlab = "-log10(P0)", ylab = "log10(NF(P <= P0))",
         main = captionPval);
    #xxx  lines(amlog10pNull, alog10nf, type = 'l', col = "red");               # Obsolete.
    lines(amlog10pH0, alog10Ne, type = 'l', col = "red");
    lines(amlog10pH0, alog10Nelo, type = 'l', col = "red", lty = 'dashed');
    lines(amlog10pH0, alog10Nehi, type = 'l', col = "red", lty = 'dashed');    
  }

  if ((mode == 'both') || (mode == 'FDR')) {
    plot(amlog10p, afdr, type = 'l',
         xlim = xlim,         
         ylim = c(0.0, 1.0),
         xlab = "-log10(P0))", ylab = "FDR(P <= P0)",
         main = captionFDR);
  }

  if (mode == 'both') {
    par(mfrow = c(1, 1));
  }
  # .................................................................................

  
  # ...........
  return (0);
  # ...........

}

# ======================================================================================
# . End of Stat.plotPvalueCD.
# ======================================================================================



# ======================================================================================
# . Stat.epsRandomSupervised : computes the average error that obtains under a random
# . ------------------------   classifier, that assigns output classes at random, with 
# .                            probability equal to the relative frequency of occurrence
# .                            of the input classes in the sample set.
# .
# .   Syntax:
# .   eps = Stat.epsRandomSupervised(af);
# .
# .   In:
# .   af = input array of relative frequencies, with sum equal to 1.
# .
# .   Out:
# .   eps = mean error.
# .
# ======================================================================================

Stat.epsRandomSupervised <- function(af)
{

     # ........................
     eps = 1.0 - sum(af^2);
     # ........................     

     # ...............     
     return (eps);
     # ...............
     
}

# ======================================================================================
# . End of Stat.epsRandomSupervised.
# ======================================================================================




# ======================================================================================================
# . Stat.sigmaEpsRandomSupervised : computes the standard deviation of the error that obtains
# . -----------------------------   under a random classifier, that assigns output classes at random, with 
# .                                 probability equal to the relative frequency of occurrence
# .                                 of the input classes in the sample set.
# .
# .   Syntax:
# .   sigma = Stat.sigmaEpsRandomSupervised(af, n);
# .
# .   In:
# .   af = input array of relative frequencies, with sum equal to 1.
# .   n = total number of samples.
# .
# .   Out:
# .   sigma = standard deviation of error.
# .
# ======================================================================================================

Stat.sigmaEpsRandomSupervised <- function(af, n)
{
     # ....................................................
     sigma = sqrt((1.0 /n) * sum(af^2 * (1.0 - af)));
     # ....................................................

     # ...............
     return (sigma);
     # ...............     
  
}

# ======================================================================================================
# . End of Stat.sigmaEpsRandomSupervised.
# ======================================================================================================



# ======================================================================================================
# . Stat.pvalRandomSupervised : computes a P-value for an observed error rate, computed as test against
# . -------------------------   the null hypothesis of a random classifier
# .
# .   Syntax:
# .   pval = Stat.pvalRandomSupervised(af, n, epsObs);
# .
# .   In:
# .   af = input array of relative frequencies, with sum equal to 1.
# .   n = total number of samples.
# .   epsObs = observed error rate (0 <= epsObs <= 1).
# .
# .   Out:
# .   pval = P-value, P(eps <= epsObs) under null hypothesis of a random classifier.
# .
# ======================================================================================================

Stat.pvalRandomSupervised <- function(af, n, epsObs)
{
     # ....................................................
     eps = Stat.epsRandomSupervised(af);
     sigma = Stat.sigmaEpsRandomSupervised(af, n);
     z = (epsObs - eps) / sigma;

     pval = pnorm(z, lower.tail = TRUE);
     # ....................................................


     # .............
     return (pval);
     # .............
  
}


# ======================================================================================================
# . End of Stat.pvalRandomSupervised.
# ======================================================================================================



# ======================================================================================================
# . Stat.barplotWithErrorBars : generates a barplot with vertical bar labels and corresponding error bars.
# . -------------------------   Assumes non-negative data.
# .
# . Syntax:
# .
# .   Stat.barplotWithErrorBars(ay, flagExp, as, alab, xlab, ylab, caption, ...)
# .
# . In:
# .
# .        ay = heights of the bars (it is assumed that all values ay >= 0).
# .   flagExp = determines type of upper and lower bounds computed from ay and as (see below).
# .        as = standard deviations for the error bars.
# .      alab = label for each bar, to be displayed vertically below.
# .      xlab = x axis legend.
# .      ylab = y-axis legend.
# .   caption = plot caption.
# .
# .  Details:
# .
# .   If flagEXp = FALSE, compute lower and upper bounds according to :
# .       aylo = ay - as
# .       aylo = ay + as
# .
# .   else if flagEXp = TRUE, bounds are computed according to :
# .       aylo = ay * exp(- as / ay)
# .       aylo = ay * exp(as / ay);
# ======================================================================================================

Stat.barplotWithErrorBars <- function(ay, as, flagExp = FALSE, alab, ylim, xlab, ylab, caption, ...) {

  
     # .........................................................................
     if (min(as) < 0) {
       cat("Stat.barplotWithErrorBars:\n");
       cat("Some values in as are negative.\n");
       stop();
     }
     # .........................................................................  

     
     # .........................................................................
     if (flagExp == FALSE) {
       aylo = ay - as;
       ayhi = ay + as;
     } else {
       aylo = ay * ifelse(ay > 0.0, exp(- as / ay), 0.0);
       ayhi = ay * ifelse(ay > 0.0, exp(as / ay), 0.0);
     }

     aylo = ifelse(aylo > 0.0, aylo, 0.0);

     if (missing(ylim)) {
       ylim = c(0, max(ayhi));  # If parameter is missing, set to this default.
     }

     if (missing(xlab)){
       xlab = '';
     }

     if (missing(ylab)){
       ylab = '';
     }

     if (missing(caption)){
       caption = '';
     }
     # ..........................................................................

     

     # ..............................................................................................................
     # . The actual plotting is here :
     # ..............................................................................................................
     cex.axis.OLD = par("cex.axis");
     par(cex.axis = 0.7);
     axbuf =  barplot(height = ay, names.arg = alab, las = 2, ylim = ylim, xlab = xlab, ylab = ylab, main = caption, ...);
     par(cex.axis = cex.axis.OLD);

     arrows(axbuf, ay, axbuf, ayhi, angle=90, length = 0.05);
     arrows(axbuf, ay, axbuf, aylo, angle=90, length = 0.05);
     # ...............................................................................................................

}

# ======================================================================================================
# . End of Stat.barplotWithErrorBars.
# ======================================================================================================






# ======================================================================================================
# . Stat.barplotWithErrorBarsAndTopLabels : generates a barplot with vertical bar labels and 
# . -------------------------------------   corresponding error bars. Writes labels on top of each
# .                                         error bar (e.g. typically the numerical count).
# . Syntax:
# .
# .   barx = Stat.barplotWithErrorBarsAndTopLabels(ay,
# .                                                flagErrbar = FALSE,
# .                                                aylo = NULL,
# .                                                ayhi = NULL,
# .                                                alabBot,
# .                                                alabTop,
# .                                                ylab = "",
# .                                                flagLogScale = FALSE,
# .                                                flagYlim = FALSE,
# .                                                ylimIn = NULL,
# .                                                flagSort = FALSE,
# .                                                lowerMargin = 2.0,
# .                                                caption = "", ...)
# .
# . In:
# .
# .           ay = heights of the bars (it is assumed that all values ay >= 0).
# .
# .   flagErrbar = if TRUE, add error bars,
# .
# .         aylo = lower bound for error bars (ignored otherwise).
# .
# .         ayhi = upper bound for error bars (ignored otherwise).
# .
# .      alabBot = bottom label for each bar, to be displayed vertically.
# .      alabTop = top label for each bar.
# .
# .         ylab = y-axis legend.
# .
# .      caption = plot caption.
# .
# .     flagLogScale = TRUE/FALSE; should we display the vertical axis with a log-scale?
# .                    If TRUE the data range is floored to 1.
# .
# .         flagYlim = TRUE/FALSE; if TRUE, use ylimIn to define y axis limits.
# .
# .          ylimIn = c(ymin, ymax) array giving y axis limits; ignored if flagYlim = FALSE.
# .
# .        flagSort = if TRUE, sort the samples in decreasing order, left-to-right.
# .
# .     lowerMargin = size of lower margin. May need to be bigger than default to accomodate
# .                   long alabBot entries.
# .
# .  Out :
# .
# .     barx = horizontal positions of bars.
# .
# ======================================================================================================

Stat.barplotWithErrorBarsAndTopLabels <- function(ay,
                                                  flagErrbar = FALSE,
                                                  aylo = NULL,
                                                  ayhi = NULL,
                                                  alabBot,
                                                  alabTop,
                                                  ylab = "",
                                                  caption = "",
                                                  flagLogScale = FALSE,
                                                  flagYlim = FALSE,
                                                  ylimIn = NULL,
                                                  flagSort = FALSE,
                                                  lowerMargin = 2.0,
                                                  ...)
{

     # .........................................................................
     n = length(ay);

     if (flagErrbar) {
       nlo = length(aylo);
       
       if (nlo != n) {
         cat("ERROR: from Stat.barplotWithErrorBarsAndTopLabels:\n");
         cat("aylo does not have same length as ay.\n");
         stop();
       }
       
       nhi = length(ayhi);
       
       if (nhi != n) {
         cat("ERROR: from Stat.barplotWithErrorBarsAndTopLabels:\n");
         cat("ayhi does not have same length as ay.\n");
         stop();
       }       
     }
     # ..........................................................................


     
     # .......................................................................................
     # . Sort input if requested :
     # .......................................................................................
     if (flagSort) {
       indexSort = order(ay, decreasing = TRUE);

       ay = ay[indexSort];

       if (flagErrbar) {
         aylo = aylo[indexSort];
         ayhi = ayhi[indexSort];         
       }

       alabBot = alabBot[indexSort];
       alabTop = alabTop[indexSort];       
     }
     # .......................................................................................     



     # ..............................................................................
     # . Get limits in y :
     # ..............................................................................
     if (!flagErrbar) {
       ytemp1 = max(ay);
     } else {
       ytemp1 = max(c(ay, ayhi));
     }
     
     yrange = ytemp1 - 0.0;
     ymax = ytemp1 + 0.1 * yrange;
     ymin = 0.0;

     if (flagLogScale) {
       ymin = 1.0;              # Floor display range to 1.
     }

     if (flagYlim) {
       ymin = ylimIn[1];
       ymax = ylimIn[2];       
     }
     # ..............................................................................     
     

     # ..............................................................................
     # . Adjust bottom margin size :
     # ..............................................................................
     mai.OLD = par("mai");
     buf = mai.OLD;
     buf[1] = lowerMargin;      # J. Theilhaber.
     par(mai = buf);
     # ..............................................................................
     # . Do the barplot :
     # ..............................................................................
     if (flagLogScale) {
       barx = barplot(ay,
                      ylim = c(ymin, ymax),
                      names.arg = alabBot,
                      las = 3,
                      ylab = ylab,
                      main = caption,
                      log = 'y',
                      ...);
     } else {
       barx = barplot(ay,
                      ylim = c(ymin, ymax),
                      names.arg = alabBot,
                      las = 3,
                      ylab = ylab,
                      main = caption,
                      ...);
     }
     # ..............................................................................
     # . Error bars if requested :
     # ..............................................................................
     if (flagErrbar) {
       errbar(barx, ay, aylo, ayhi, add = TRUE, lwd = 1);            # (library(Hmisc)).
     }
     # ..............................................................................
     # . Add top labels :
     # ..............................................................................
     cex = 1.0;

     if (n > 20) {
       cex = 0.5;
     }

     text(barx, 0.95 * ymax, alabTop, cex = cex);
     # ..............................................................................
     # . Restore margins :
     # ..............................................................................
     par(mai = mai.OLD);
     # ..............................................................................


     # ............
     return (barx);
     #xxx return (0);
     # ............

}

# ======================================================================================================
# . End of Stat.barplotWithErrorBarsAndTopLabels.
# ======================================================================================================






# ======================================================================================================
# . Stat.waterFallPlot : generates a ``waterfall'' bar plot for the input array.
# . ------------------
# .
# . Syntax:
# .
# .   Stat.waterFallPlot(ay, ylim = NULL, xlab, ylab, caption = NULL,
# .                      flagMono = 'no', colMono = NULL, flagWrite = 'no', fname,
# .                      lmargin = 2.0, cex.names = 1.0, ...);
# .
# . In:
# .               ay = array containing heights of the bars. Colors assigned are red for y >= 0
# .                    and blue for y < 0.
# .             ylim = bounds for y axis.
# .             xlab = horizontal label.
# .             ylab = label for y axis.
# .          caption = figure caption.
# .         flagMono = no/yes : monochrome switch; if yes, ignore red/blue two-color scheme, and assign 
# .                    the single color given by colMonochrome below.
# .          colMono = monochrome color used if flagMonochrome = yes.
# .
# .        flagWrite = no/yes : if yes, write to jpeg file rather than display in Xterm.
# .            fname = name for jpeg file to be written to, if flagWrite = 'yes',
# .                    ignored otherwise.
# .
# .          lmargin = space for lower margin.
# .        cex.names = size for bar labels below axis.
# .             alab = labels to be displayed below the bars (default is NULL : no labels).
# .             ...  = other graphical parameters.       
# .
# ......................................................................................................
# . Details : the numerical items in ay are sorted left-to-right in increasing order.
# . The bars are displayed either in the uniform color given by colorUniform, or red for y >= 0
# . and blue for y < 0.
# . 
# . Example :
# .
# .    Stat.waterFallPlot(ay = atox1, ylim = c(-30, 100), ylab = 'CDC toxicity SAR650984  (%)', caption = 'SAR650984 CDC toxicity profile', 
# .                       lmargin = 3,
# .                       cex.names = 1.5, 
# .   		          cex.main = 3.0,
# .		          cex.axis = 2.0,
# .		          cex.lab = 1.5);
# .
# ======================================================================================================

Stat.waterFallPlot <- function(ay, ylim = NULL, xlab = '', ylab = '', caption = '',
                               flagMono = 'no', colMono = NULL,
                               flagWrite = 'no', fname = NULL, 
                               lmargin = 0.5,
                               cex.names = 1.0,
                               alab = NULL,
                               ...) {

     # .......................................................
     stopifnot((flagMono == 'yes') || (flagMono == 'no'));
     stopifnot((flagWrite == 'yes') || (flagWrite == 'no'));     
     # .......................................................

     
     # ......................................................................
     if (flagWrite == 'yes') {
       jpeg(fname);              # Turn on plot device.
     }
     # ......................................................................


     # ......................................................................
     if (is.null(ylim)) {
       ylim = c(min(ay, na.rm = TRUE), max(ay, na.rm = TRUE));
     }
     # ......................................................................     
     
     
     # ..................................................................................................................
     ayBuf = sort(ay);

     if (!is.null(alab)) {
       alabBuf = alab[order(ay)];
     }

     if (flagMono == 'no') {
       colBuf = ifelse(ayBuf >= 0.0, "red", "blue");
     } else {
       stopifnot(!is.null(colMono));       
       colBuf = rep(times = length(ayBuf), colMono);
     }

     mai.OLD = Graphics.setLowerMargin(lmargin);          # Expand lower margin to get all the text of the labels in the barplots.

     if (is.null(alab)) {
       axBuf =  barplot(height = ayBuf,
                        col = colBuf,
                        las = 2,
                        cex.names = cex.names,
                        ylim = ylim, xlab = xlab, ylab = ylab, main = caption,
   		        ...);
     } else {
       axBuf =  barplot(height = ayBuf,
                        col = colBuf,
                        las = 2,
                        cex.names = cex.names,
                        ylim = ylim, xlab = xlab, ylab = ylab, main = caption,
                        names.arg = alabBuf,
   		        ...);       
     }

     if (!is.null(ylim)) {
       abline(h = ylim[1]); 
       abline(h = ylim[2]);
     }

     par(mai = mai.OLD); 
     # ......................................................................


     
     # ...........................
     # . Close device :
     # ...........................
     if (flagWrite == 'yes') {
        dev.off();
      }
     # ...........................

     
     # ..........
     return (0);
     # ..........
     
}

# ======================================================================================================
# . End of Stat.waterFallPlot.
# ======================================================================================================





# =================================================================================================
# . Stat.writePlotFile : writes a file containing the list of the plot files along with the
# . ------------------   corresponding plot titles.
# .
# .  Syntax:
# .
# .      Stat.writePlotFile(afile, aplot, fplot);
# .
# .  In:
# .
# .      afile = array containing full-path file names.
# .      aplot = array containing plot names (= plot titles). Must be same length as af.
# .      fplot = name of output file.
# .
# =================================================================================================

Stat.writePlotFile <- function(afile, aplot, fplot)
{

     # ........................................................................
     if (length(afile) == 0) {
       cat("ERROR: from Stat.writePlotFile:\n");
       cat("There are 0 plots in the input variable sp.\n", sep = "");
       stop();
     }

     if (length(aplot) != length(afile)) {
       cat("ERROR: from Stat.writePlotFile:\n");
       cat("Input arrays afile and aplot differ in length.\n", sep = "");
       stop();
     }     
     # ........................................................................


     # .........................................................................................
     FP = file(fplot, "w");

     dfBuf = data.frame(afile, aplot);
     colnames(dfBuf) = c('#filename', 'plotname');

     DataFrame.writeFlat(dfBuf, FP);
     
     close(FP);
     # .........................................................................................


     # ..........................................................................
     cat(" ..........  Plot file list written to file: ", fplot, "\n", sep = "");
     # ..........................................................................
     

     # .............
     return (0);
     # .............

}

# =================================================================================================
# . End of Stat.writePlotFile.
# =================================================================================================





# =========================================================================================================
# . Stat.generateWaterFallPlotsOnPanel : generates a series of waterfall plots, one per level of the 
# . ----------------------------------   selected factor.
# .
# . Syntax:
# .
# .     Stat.generateWaterFallPlotsOnPanel(dfIn, factorCategory, factorNumerical,
# .                                        ym, ylim, ylab = NULL,
# .                                        nrPage, ncPage,
# .                                        flagWrite, dirPlot, stemName,
# .                                        fplot);
# .
# . In:
# .
# .             dfIn = input data frame (required).
# .
# .       factorCategory = name of factor specifying the categories for each of which a 
# .                        waterfall plot will be generated. Example: 'tissue'.
# .                        If factorCategory = 'NONE', than a single waterfall plot is
# .                        generated.
# .
# .      factorNumerical = name of factor specifying the numerical values to be used in
# .                        the waterfall plots. Example: 'P.upPI3K.x'.
# .
# .               nrPage = number of rows in grouping panel : the waterfall plots
# .                        are generated in groups of nr * nc, where nr = number of rows
# .                        and nc = number of columns (below).
# .
# .               ncPage = number of columns in grouping panel.
# .
# .                   ym = offset to be subtracted from the values in the factorNumerical
# .                        column to defined positive and negative values.
# .
# .                 ylim = limits for display of y-axis (e.g. ylim = c(-0.5, 0.5));
# .
# .        flagWrite = no/yes :
# .                    - if no, each plot is generated successively, and the user is promptted
# .                    for a carriage return to proceed to the next plot.
# .                    - if yes, output to Xterm is suppressed, individual jpeg files are generated
# .                    in directory dirPlot, and a file containing the tabulation of the plot files
# .                    is generated.
# .
# .          dirPlot = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .         stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .            fplot = file containing tabulation of plot files generated.
# .   
# ==========================================================================================================

Stat.generateWaterFallPlotsOnPanel <- function(dfIn, factorCategory, factorNumerical, ym, ylim = NULL,
                                               ylab = NULL,
                                               nrPage = 1, ncPage = 1,
                                               flagWrite = 'no', dirPlot = NULL, stemName = NULL,
                                               fplot = NULL)
{

     # ....................................................................
     cat(" ..........  Entry in Stat.generateWaterFallPlotsOnPanel.\n");
     # ....................................................................
     
  
     # ....................................................................................
     # . Error checking :
     # .
     # . >>Check on factors, allowing for factorCategory = NONE (all samples in one group).
     # ....................................................................................
     if (factorCategory != 'NONE') {
       if (is.null(dfIn[[factorCategory]])) {
         cat("ERROR: from Stat.generateWaterFallPlotsOnPanel:\n");
         cat("factorCat = ", factorCategory, " is not defined in input data frame.\n");
         stop();
       }
       # ..................................................................................
       # . Check for any NAs : replace these by explicit '_NA_'.
       # ..................................................................................       
       naMask = is.na(dfIn[[factorCategory]]);

       if (sum(naMask) > 0) {
         cat(" ..........  Warning: under factorCategory = ", factorCategory, " there are some NA values.\n", sep = "");
         cat("             Replacing these with explicit _NA_ values.\n");
         dfIn[[factorCategory]][naMask] = "_NA_";
       }
       # ..................................................................................              
     } else {
       adummy = rep("all", times = nrow(dfIn));
       dfIn = data.frame(dfIn, XXXadummyXXX = adummy, check.names = FALSE);
       factorCategory = 'XXXadummyXXX';                                      # All samples in one group.
     }
     
     if (is.null(dfIn[[factorNumerical]])) {
       cat("ERROR: from Stat.generateWaterFallPlotsOnPanel:\n");
       cat("factorNumerical = ", factorNumerical, " is not defined in input data frame.\n");
       stop();
     }
     # ....................................................................................
     # . >>Check on the grouping parameters :
     # ....................................................................................
     stopifnot(nrPage >= 1);
     stopifnot(ncPage >= 1);
     # ....................................................................................
     # . >>Check on parameters for saved plot files :
     # ....................................................................................  
     stopifnot((flagWrite == 'yes') || (flagWrite == 'no'));
     
     if (flagWrite == 'yes') {
       if (is.null(dirPlot)) {
         cat("ERROR: from Stat.generateWaterFallPlotsOnPanel:\n");
         cat("dirPlot is not defined.\n");
         stop();
       }

       if (is.null(stemName)) {
         cat("ERROR: from Stat.generateWaterFallPlotsOnPanel:\n");
         cat("stemName is not defined.\n");
         stop();
       }

       if (is.null(fplot)) {
         cat("ERROR: from Stat.generateWaterFallPlotsOnPanel:\n");
         cat("fplot is not defined.\n");
         stop();
       }       
     }

     if (flagWrite == 'no') {
       dirPlot = "foo";        # Dummy value.
       stemName = "dum";       # Dummy value.
     } else if (flagWrite == 'yes') {
       if (!file.exists(dirPlot)) {
         cat("ERROR: from Stat.generateWaterFallPlotsOnPanel:\n");
         cat("dirPlot = ", dirPlot, " does not exist.\n");
         stop();
       }
     }     
     # ....................................................................................     



     # ...........................................................
     # . Initialize plot arrays :
     # ...........................................................
     afile = c();
     aplot = c();
     # ...........................................................



     
     
     # .............................................................................................................
     # . Generate a list, with each member containing an array of the numeric values for the corresponding
     # . category.
     # .............................................................................................................
     if (is.factor(dfIn[[factorCategory]])) {
       ac = levels(dfIn[[factorCategory]]);                 # Distinct category names.
     } else {
       ac = levels(as.factor(dfIn[[factorCategory]]));      # Distinct category names.
     }
         
     nc = length(ac);                              # Number of distinct categories.

     ax = sapply(1:nc, function(j){buf = dfIn[dfIn[[factorCategory]] == ac[j], factorNumerical]; return(buf);});

     if (nc == 1) {
       ax = list(ax = ax);                         # For nc = 1 sapply() returns a matrix rather than a list.
     }       
     # .............................................................................................................

     

     # ..............................................................................................................
     # . Generate counts for each category :
     # ..............................................................................................................
     acTot = by(dfIn[[factorNumerical]], dfIn[[factorCategory]], length);       # Total instances in each category.
     acPos = by(dfIn[[factorNumerical]], dfIn[[factorCategory]], 
                function(y){nbuf = sum(y >= ym); return(nbuf);})              # Positives in each category, relative to ym.
     # ...............................................................................................................          
     # . Compute the frequency estimates :
     # ...............................................................................................................         
     af = acPos / acTot;                                                      # Estimated frequency for each tissue.
     as = sqrt(af * (1.0 - af) / acTot);                                      # Estimated standard deviation in estimate.
     # ...............................................................................................................

     
     # .........................................................................
     if (flagWrite == 'no') {      
       buf = readline(">>Enter a carriage return to start first plot : ");
     }
     # .........................................................................


     
     # ..................................................................
     # . Single or multiple plots per page :
     # ..................................................................
     par(mfrow = c(nrPage, ncPage));

     nPage = nrPage * ncPage;         # Number of plots in a filled page.
     # ...................................................................

     

     # ............................................................................................................
     # . Walk through category in turn, generate a waterfall plot :
     # ............................................................................................................
     kinPage = 0;                     # Counts number of plots in page so far.
     
     for (j in 1:nc) {
       # .......................................................................................
       # . Progress indicator :
       # .......................................................................................       
       if (flagWrite == 'no') {      
         cat(">>Generating plot ", j, " out of ", nc, "\n", sep = "");
       }
       # .......................................................................................
       # . Skip emtpty levels :
       # .......................................................................................
       if (length(ax[[j]]) == 0) {
         cat(">>Warning: for plot ", j, ", level = ", ac[j], ", there are no members. Skip.\n", sep = "");
         next;
       }
       # .......................................................................................       
       # . Generate the file name :      
       # .......................................................................................
       if (kinPage == 0) {       
         fname = File.generateRandomName(dirPlot, stemName, ext = "jpg");
         pname = ac[j];
         afile = c(afile, fname);
         aplot = c(aplot, pname);
       }
       # .......................................................................................
       # . Open plot device if required :
       # .......................................................................................
       if (flagWrite == 'yes') {
         if (kinPage == 0) {
           jpeg(fname);                      # Turn on plot device if we are about to do the first plot in page.
           par(mfrow = c(nrPage, ncPage));   # Reset.
         }
       }
       # .......................................................................................
       # . The plot is generated here :
       # .......................................................................................
       if (class(ax) == 'matrix') {
         ay = ax[ , j] -ym;
       } else {
         ay = ax[[j]] - ym;            # Center data around specified offset.
       }
         
       xlab = NULL;
       
       if (is.null(ylab)) {
         ylab = paste(factorNumerical, " - ", ym, sep = "");
       } 
         
       freq = sprintf("%5.1f", 100 * af[j]);
       
       caption = paste(ac[j], " [", acTot[j], ", ", freq, "%]", sep = "");

       cex.main.OLD = par("cex.main");
       par(cex.main = 0.7);       
       Stat.waterFallPlot(ay = ay,
                          ylim = ylim,
                          xlab = xlab,
                          ylab = ylab,
                          caption = caption, 
                          flagMono = 'no', colMono = 'brown',
                          flagWrite = 'no', fname = fname);
       par(cex.main = cex.main.OLD);                    
       # .......................................................................................
       # . Update tally of plots in page :
       # .......................................................................................
       kinPage = kinPage + 1;           # Number of plots done so far.
       # .......................................................................................
       # . Close device or prompt user for next plot :      
       # .......................................................................................
       if (flagWrite == 'yes') {
         if (kinPage == nPage) {
           dev.off();                   # Turn off device, as we've completed an entire page.
         }
       } else if (flagWrite == 'no') {      
         buf = readline(">>Enter a carriage return to continue, x to exit: ");           # Pause.

         if (buf == 'x') {
           return (0);
         }
       }
       # .......................................................................................
       # . Reset in-page plot count :
       # .......................................................................................
       if (kinPage == nPage) {
         kinPage = 0;              # reset to 0.
       }
       # .......................................................................................       
     }
     # ............................................................................................................
     

     # .......................................................
     # . Clean-up for last page, if last page is not filled:
     # .......................................................
     if (flagWrite == 'yes') {     
       if (kinPage > 0) {
           dev.off();              
         }
     }
     # ........................................................

     
     
     # .......................................
     par(mfrow = c(1,1));     # Generic reset.       
     # .......................................

     
     
     # .............................................
     # . Write to plot file, if requested :
     # .............................................
     if (flagWrite =='yes') {
       Stat.writePlotFile(afile, aplot, fplot);
     }
     # .............................................


     # .............................................
     cat(" ..........  All plots generated.\n");
     # .............................................
     

     # ...........
     return (0);
     # ...........
     
}

# ==========================================================================================================================
# . End of Stat.generateWaterFallPlotsOnPanel.
# ==========================================================================================================================



# ======================================================================================
# . Stat.plotVolcano : generates a (horizontal) volcano plot, of coefficient against
# . ----------------   -log10(P-value).
# .
# .   Syntax:
# .   Stat.plotVolcano(ap, abeta, caption);
# .
# .   In:
# .   ap = input array of P-values.
# .   abeta = input array of coefficients.
# .   xlab = x axis label.
# .   ylab = y axis label.
# .   caption = plot caption.
# .
# ======================================================================================

Stat.plotVolcano <- function(ap, abeta, xlab = NULL, ylab = NULL, caption = NULL)
{

  # .........................................................................................
  if (min(ap) < 0.0) {
    msg = "ERROR: from Stat.plotVolcano: some P-values < 0.";
    stop(msg);
  }
  
  if (max(ap) == 0.0) {
    ap = rep(Stat.PVALMIN_FOR_COMBINE, times = length(ap));   # Stand-in for all-0 values.    
  }

  if (length(ap) != length(abeta)) {
    msg = "ERROR: from Stat.plotVolcano: arrays ap and abeta are of different lengths.";
    stop(msg);
  }
  # ..........................................................................................
  
  
  
  # .................................................................................
  # . Compute -log10(P), including provision for P = 0 exactly :
  # .................................................................................
  pmin = min(ap[ap > 0.0]);                       # Smallest non-zero P-value.
  mlog10pmin = - log(pmin, base = 10.0) + 1.0;    # Will be a stand-in for 0 values.
  amlog10p = ifelse(ap > 0.0, - log(ap, base = 10.0), mlog10pmin);
  # .................................................................................

  
  # .................................................................................
  # . Generate plot :
  # .................................................................................
  xlim = c(0.0, max(amlog10p));
  
  plot(amlog10p, abeta,
       xlim = xlim,
       type = 'p',
       xlab = xlab,
       ylab = ylab,
       main = caption, pch = 19);
  abline(h = 0);
  # .................................................................................

  
  # ...........
  return (0);
  # ...........

}

# ======================================================================================
# . End of Stat.plotVolcano.
# ======================================================================================



# ======================================================================================
# . Stat.generateCoxPval : computes the power for Cox proportional hazard modeling
# . --------------------   of two populations with differing hazard ratios.
# .
# . Syntax:
# .
# .      ap = Stat.generateCoxPval(n1, n2, fcens, hr, rngSeed, ns);
# .
# . In:
# .
# .       n1 = number of samples in population 1.
# .       n2 = number of samples in population 2.
# .    fcens = fraction of instances censored in populations 1 and 2.
# .            0 <= fcens < 1.
# .
# .      hr = hazard ratio for individuals in pop.2 relative to pop.1.
# .
# .                           lambda_2
# .                    hr =  -----------
# .                           lambda_1
# .
# .    rngSeed = random number seed for generating distributions.
# .         ns = number of samplings to be generated.
# .
# . Out : list with members :
# .
# .   ap = array of length ns, containing the P-values for the ns independent
# .        samplings.
# .
# .   abeta = array of length ns, containing the Cox coefficients for the ns independent samplings.
# .
# ......................................................................................
# . Details :
# .
# .   This generates series of exponentially-distributed survival times, with
# .   parameters lambda_1 = 1 for population 1, and lambda_2 = hr for population 2.
# .
# ======================================================================================

Stat.generateCoxPval <- function(n1, n2, fcens, hr, rngSeed, ns)
{

    # .........................................................................
    stopifnot(n1 > 0, n2 > 0, fcens >= 0.0, fcens < 1.0, rngSeed > 0, ns > 0);
    # .........................................................................
  

    # ........................................................
    set.seed(rngSeed);

    lambda0 = 1.0;          # Basal hazard rate in exponential model.
    fcens1 = 1.0 - fcens;   # Probability of no censoring.
    # ........................................................


    # ........................................................................
    # . Generate P-values for ns samplings :
    # ........................................................................
    ap = c();
    abeta = c();
    
    for (l in 1:ns) {
      # ......................................................................
      # . Generate survival times for population 1 :
      # ...................................................................... 
      alambda1 = rep(lambda0, times = n1);            # Exponential rate.
      at1 = rexp(n1, alambda1);                       # Exponential distribution.
      as1 = rbinom(1:n1, 1, fcens1);                  # Censoring status.

      if (sum(as1) == 0) {
        as1[1] = 1;                  # Correct for the unlikely case of all-censored.
      }
      
      az1 = rep(0.0, times = n1);                     # Covariates vector.
      # ......................................................................
      # . Generate survival times for population 2 :
      # ......................................................................
      alambda2 = rep(hr * lambda0, times = n2);       # Exponential rate, adjusted with hazard ratio.
      at2 = rexp(n1, alambda2);                       # Exponential distribution.
      as2 = rbinom(1:n2, 1, fcens1);                  # Censoring status.

      if (sum(as2) == 0) {
        as2[1] = 1;                  # Correct for the unlikely case of all-censored.
      }      
      
      az2 = rep(1.0, times = n2);                     # Covariates vector.
      # ......................................................................
      # . Package into single arrays :
      # ......................................................................
      at = c(at1, at2);
      as = c(as1, as2);
      az = c(az1, az2);
      # ......................................................................
      # . Compute the Cox model for this one data set :
      # ......................................................................      
      coxK = coxph(Surv(at, as) ~ az);                # Cox model on one co-covariate.
      sumBuf = summary(coxK);
      beta = sumBuf$coefficients[1];                  # Get the Cox coeffcient as well.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);   # Likelihood ratio statistic.
      dfTemp = 1;                                     # Degrees of freedom.
      pR = pchisq(qR, df = dfTemp, lower.tail = FALSE);   # p-value from likelihood ratio.
      # ......................................................................
      ap = c(ap, pR);
      abeta = c(abeta, beta);
      # ......................................................................      
    }
    # ........................................................................



    # ....................................
    # . Package arrays :
    # ....................................
    cF = list(ap = ap, abeta = abeta);
    # ....................................


    # .............
    return (cF);
    # .............

}

# ======================================================================================
# . End of Stat.generateCoxPval.
# ======================================================================================






# ======================================================================================
# . Stat.generateCoxPvalWithBio : computes the power for Cox proportional hazard modeling
# . ---------------------------   of two populations with differing hazard ratios.
# .
# .                               This version assumes the presence of a sensitizing
# .                               biomarker, with a given frequency. Only patients
# .                               with the biomarker experience a differential
# .                               hazard ratio (i.e. exhibit a response).
# .
# . Syntax:
# .
# .      ap = Stat.generateCoxPvalWithBio(n1, n2, fBio, fcens, hr, rngSeed, ns);
# .
# . In:
# .
# .       n1 = number of samples in population 1.
# .       n2 = number of samples in population 2.
# .     fBio = fraction of patients in either population bearing the biomarker.
# .
# .    fcens = fraction of instances censored in populations 1 and 2.
# .            0 <= fcens < 1.
# .
# .      hr = hazard ratio for individuals in pop.2 relative to pop.1., for those
# .           individuals bearing the biomarker (i.e. for a fraction fBio of all
# .           the patients).
# .
# .                           lambda_2
# .                    hr =  -----------
# .                           lambda_1
# .
# .           For all other patients (i.e. a fraction 1 - fBio), the harzard ratio is
# .           1.
# .
# .
# .    rngSeed = random number seed for generating distributions.
# .         ns = number of samplings to be generated.
# .
# . Out : list with members :
# .
# .   ap = array of length ns, containing the P-values for the ns independent
# .        samplings.
# .
# .   abeta = array of length ns, containing the Cox coefficients for the ns independent samplings.
# .
# ......................................................................................
# . Details :
# .
# .   This generates series of exponentially-distributed survival times, with
# .   parameters lambda_1 = 1 for population 1, and lambda_2 = hr for population 2.
# .
# ======================================================================================

Stat.generateCoxPvalWithBio <- function(n1, n2, fBio, fcens, hr, rngSeed, ns)
{

    # .........................................................................
    stopifnot(n1 > 0, n2 > 0, fcens >= 0.0, fcens < 1.0, rngSeed > 0, ns > 0);
    stopifnot(fBio >= 0, fBio <= 1);
    # .........................................................................
  

    # ........................................................
    set.seed(rngSeed);

    lambda0 = 1.0;          # Basal hazard rate in exponential model.
    fcens1 = 1.0 - fcens;   # Probability of no censoring.
    # ........................................................


    # ........................................................................
    # . Generate P-values for ns samplings :
    # ........................................................................
    ap = c();
    abeta = c();
    
    for (l in 1:ns) {
      # ......................................................................
      # . Generate survival times for population 1 :
      # ...................................................................... 
      alambda1 = rep(lambda0, times = n1);            # Exponential rate.
      at1 = rexp(n1, alambda1);                       # Exponential distribution.
      as1 = rbinom(1:n1, 1, fcens1);                  # Censoring status.

      if (sum(as1) == 0) {
        as1[1] = 1;                  # Correct for the unlikely case of all-censored.
      }
      
      az1 = rep(0.0, times = n1);                     # Covariates vector.
      # ......................................................................
      # . Generate survival times for population 2 :
      # ......................................................................
      alambdaPos = rep(hr * lambda0, times = n2);       # Exponential rate, adjusted with hazard ratio, for biomarker+.
      alambdaNeg = rep(lambda0, times = n2);            # Exponential rate, baseline, for biomarker-.
      aMask = as.logical(rbinom(1:n2, 1, fBio));        # A value of 1 indicates presence of the biomarker.
      alambda2 = ifelse(aMask, alambdaPos, alambdaNeg); # Exponential rates.
      
      at2 = rexp(n1, alambda2);                         # Exponential distribution.
      as2 = rbinom(1:n2, 1, fcens1);                    # Censoring status.

      if (sum(as2) == 0) {
        as2[1] = 1;                  # Correct for the unlikely case of all-censored.
      }      
      
      az2 = rep(1.0, times = n2);                     # Covariates vector.
      # ......................................................................
      # . Package into single arrays :
      # ......................................................................
      at = c(at1, at2);
      as = c(as1, as2);
      az = c(az1, az2);
      # ......................................................................
      # . Compute the Cox model for this one data set :
      # ......................................................................      
      coxK = coxph(Surv(at, as) ~ az);                # Cox model on one co-covariate.
      sumBuf = summary(coxK);
      beta = sumBuf$coefficients[1];                  # Get the Cox coeffcient as well.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);   # Likelihood ratio statistic.
      dfTemp = 1;                                     # Degrees of freedom.
      pR = pchisq(qR, df = dfTemp, lower.tail = FALSE);   # p-value from likelihood ratio.
      # ......................................................................
      ap = c(ap, pR);
      abeta = c(abeta, beta);
      # ......................................................................      
    }
    # ........................................................................



    # ....................................
    # . Package arrays :
    # ....................................
    cF = list(ap = ap, abeta = abeta);
    # ....................................


    # .............
    return (cF);
    # .............

}

# ======================================================================================
# . End of Stat.generateCoxPvalWithBio.
# ======================================================================================




# ======================================================================================
# . Stat.plotCoxROC : generates and plots ROCs for Cox proportional hazard modeling
# . ---------------   of two populations with differing hazard ratios, for the
# .                   specified values of sample numbers.
# . Syntax:
# .
# .      s = Stat.plotCoxROC(an, fcens, hr, rngSeed, ns);
# .
# . In:
# .
# .       an = array of values of n = n1 = n2, number of samples in pop. 1
# .            and pop. 2.
# .
# .    fcens = fraction of instances censored in populations 1 and 2.
# .            0 <= fcens < 1.
# .
# .      hr = hazard ratio for individuals in pop.2 relative to pop.1.
# .
# .                           lambda_2
# .                    hr =  -----------
# .                           lambda_1
# .
# .    rngSeed = random number seed for generating distributions.
# .
# .         ns = number of samplings to be generated for each value of n.
# .
# .      alpha = 1 - confidence level (= false positive rate).
# .
# .      flagSides = specifies number of sides in the tests :
# .
# .                  - 'twoSided' : accept as positives all comparaisons
# .                    which result in P < alpha, where P is the P-value
# .                    derived from a two-sided test, implicitely derived
# .                    from the Wald test :
# .
# .                                           1/2
# .                           z_obs = beta * J   (beta)
# .
# .                    where P = Prob(|z| >= |z_obs|).
# .
# .                  - 'oneSided' : accept as positives all comparisons
# .                    which result in beta >= 0 (greater hazard in the
# .                    second population), and for which
# .                    which result in P < alpha, where P is the P-value
# .                    derived from a one-sided test, implicitely derived
# .                    from the Wald test :
# .
# .                                            1/2
# .                            z_obs = beta * J   (beta)
# .
# .                    where P = Prob(z >= z_obs).
# .
# .
# . Out :
# .
# .   s = list, with members :
# .
# .       an = values of n used in calculation.
# .    aSSim = sensitivity at given alpha and for given value of hazard ratio, from the simulations.
# .   aSTheo = sensitivity at given alpha and for given value of hazard ratio, from analytic expression
# .            (Schoenfeld approximation).
# .
# ......................................................................................
# . Details :
# .
# .   This generates series of exponentially-distributed survival times, with
# .   parameters lambda_1 = 1 for population 1, and lambda_2 = hr for population 2.
# .
# ======================================================================================

Stat.plotCoxROC <- function(an, fcens, hr, rngSeed, ns, alpha, flagSides)
{

   # ..........................................................................................
   if ((flagSides != 'oneSided') &&  (flagSides != 'twoSided')) {
     cat("ERROR: from Stat.plotCoxROC: flagSides = ", flagSides, " is not valid.\n", sep = "");
     cat("Valid: oneSided, twoSided.\n");
     stop();
   }     
   # ..........................................................................................
   
  
   # ...................................................................................
   # . For the given hazard ratio, generate a series of arrays of P-values for
   # . the specified numbers of samples :
   # ...................................................................................
   apBig = list();
   abetaBig = list();   
   nBig = length(an);    # Number of values of n.
   
   for (i in 1:nBig) {
     cat("Process for n = ", an[i], "\n", sep = "");
     cF = Stat.generateCoxPval(n1 = an[i], n2 = an[i],
                               fcens = fcens, hr = hr,
                               rngSeed = rngSeed, ns = ns);

     apBig[[i]] = cF$ap;                 # This is P(|z| > |z_obs|).
     abetaBig[[i]] = cF$abeta;

     if (flagSides == 'oneSided') {
       apBig[[i]] = 0.5 * apBig[[i]];    # Adjust to P(z > |z_obs|) for one-sided test.
     }     
   }

   aS = (1:ns) / ns;           # Array of sensitivities.
   # ...................................................................................


   # ...................................................................................
   # . Compute sensitivity at given confidence level, for each value of n :
   # ...................................................................................   
   aSSim = c();
   aSTheo = c();   
   
   for (i in 1:nBig) {
     ap = apBig[[i]];
     abeta = abetaBig[[i]];     

     if (flagSides == 'twoSided') {
       sT = length(ap[ap <= alpha]) / ns;
     } else if (flagSides == 'oneSided') {
       sT = length(ap[(ap <= alpha) & (abeta >= 0.0)]) / ns;
     }
       
     aSSim = c(aSSim, sT);
     # .................................................................................
     # . Also compute the analytic results, from the Schoenfeld approximation :
     # .................................................................................     
     sTheo = Stat.powerCoxSchoenfeld(an[i], hr, alpha, flagSides)
     aSTheo = c(aSTheo, sTheo);
     # .................................................................................          
   }
   # ...................................................................................

   
   # ...................................................................................
   # . Plot sensitivity versus sample number :
   # ...................................................................................      
   caption = paste("Sensitivity for hr = ", sprintf("%6.3e", hr), "; alpha = ", alpha, "; ", flagSides, sep = "");

   cex.main.OLD = par("cex.main");
   par(cex.main = 0.8);
   plot(an, aSSim, type = 'l', main = caption, xlab = 'n', ylab = 'sensitivity', 
        xlim = c(0, max(an)), ylim = c(0,1));
   par(cex.main = cex.main.OLD); 
   # ...................................................................................


   # ...................................................................................
   buf = readline(">>Enter a carriage return to continue: ");    # Pause.
   # ...................................................................................
   
   
   # ...................................................................................   
   # . Plot ROCs for the given values of sample numbers :
   # ...................................................................................
   acolBase = c('gray', 'blue', 'green', 'red', 'black');  # Sets color rotation.
   nc = length(acolBase);                                  # Periodicity.
   icBig = 1;                                              # Global color index.
   acol = c();
   # ....................................................................................
   # . Make plot for first value of n :
   # ....................................................................................   
   caption = paste('ROC for Cox model; hazard ratio hr = ', sprintf("%6.3e", hr), "; ", flagSides, sep = "");
   cex.main.OLD = par("cex.main");
   par(cex.main = 0.8);

   icBig1 = icBig - 1;   
   ic = 1 + icBig1%%nc;
   plot(sort(apBig[[1]]), aS, type = 'l', col = acolBase[ic], 
        main = caption, 
        xlab = "false positive rate", ylab = "sensitivity",
        xlim = c(0,1), ylim = c(0,1));
   acol = c(acolBase[ic]);
   icBig = icBig + 1;

   abline(a = 0.0, b = 1.0, lty = 'dashed');    # Null didtribution.   
   # ....................................................................................
   # . Make plots for subsequent values of n, if any :
   # ....................................................................................     
   if (nBig > 1) {
     for (i in 2:nBig) {
       icBig1 = icBig - 1;
       ic = 1 + icBig1%%nc;
       lines(sort(apBig[[i]]), aS, type = 'l', col = acolBase[ic]);
       acol = c(acol, acolBase[ic]);
       icBig = icBig + 1;
     }
   }
   # ....................................................................................
   # . Generate legend :
   # ....................................................................................
   legendText = as.character(an);
   colVector = acol;
   ltyVector = rep('solid', times = nBig);
   legend(x = 0.8, y = 0.3, legend = legendText, col = colVector, lty = ltyVector, bty = 'n');
   # ....................................................................................



   # ....................................
   # . Package power profile as list :
   # ....................................   
   sOut = list(an = an,
               aSSim = aSSim,
               aSTheo = aSTheo);
   # ....................................


   # ...............
   return (sOut);
   # ...............
   

}

# ======================================================================================
# . End of Stat.plotCoxROC.
# ======================================================================================





# ======================================================================================
# . Stat.plotCoxROCWithBio : generates and plots ROCs for Cox proportional hazard modeling
# . ----------------------   of two populations with differing hazard ratios, for the
# .                          specified values of sample numbers.
# .
# .                          This version assumes the presence of a sensitizing
# .                          biomarker, with a given frequency. Only patients
# .                          with the biomarker experience a differential
# .                          hazard ratio (i.e. exhibit a response).
# .
# . Syntax:
# .
# .      s = Stat.plotCoxROCWithBio(an, fBio, fcens, hr, rngSeed, ns);
# .
# . In:
# .
# .       an = array of values of n = n1 = n2, number of samples in pop. 1
# .            and pop. 2.
# .     fBio = fraction of patients in either population bearing the biomarker.
# .
# .    fcens = fraction of instances censored in populations 1 and 2.
# .            0 <= fcens < 1.
# .
# .      hr = hazard ratio for individuals in pop.2 relative to pop.1.
# .
# .                           lambda_2
# .                    hr =  -----------
# .                           lambda_1
# .
# .    rngSeed = random number seed for generating distributions.
# .
# .         ns = number of samplings to be generated for each value of n.
# .
# .      alpha = 1 - confidence level (= false positive rate).
# .
# .      flagSides = specifies number of sides in the tests :
# .
# .                  - 'twoSided' : accept as positives all comparaisons
# .                    which result in P < alpha, where P is the P-value
# .                    derived from a two-sided test, implicitely derived
# .                    from the Wald test :
# .
# .                                           1/2
# .                           z_obs = beta * J   (beta)
# .
# .                    where P = Prob(|z| >= |z_obs|).
# .
# .                  - 'rightSided' : accept as positives all comparisons
# .                    which result in beta >= 0 (greater hazard in the
# .                    second population), and for which
# .                    which result in P < alpha, where P is the P-value
# .                    derived from a one-sided test, implicitely derived
# .                    from the Wald test :
# .
# .                                            1/2
# .                            z_obs = beta * J   (beta)
# .
# .                    where P = Prob(z >= z_obs).
# .
# .                  - 'leftSided' : accept as positives all comparisons
# .                    which result in beta < 0 (lesser hazard in the
# .                    second population), and for which
# .                    which result in P < alpha, where P is the P-value
# .                    derived from a one-sided test, implicitely derived
# .                    from the Wald test :
# .
# .                                            1/2
# .                            z_obs = beta * J   (beta)
# .
# .                    where P = Prob(z < z_obs).
# .
# .
# . Out :
# .
# .   s = list, with members :
# .
# .    afBio = array of (identical) values of fBio.
# .       an = values of n used in calculation.
# .    aSSim = sensitivity at given alpha and for given value of hazard ratio, from the simulations.
# .
# ......................................................................................
# . Details :
# .
# .   This generates series of exponentially-distributed survival times, with
# .   parameters lambda_1 = 1 for population 1, and lambda_2 = hr for population 2.
# .
# ======================================================================================

Stat.plotCoxROCWithBio <- function(an, fBio, fcens, hr, rngSeed, ns, alpha, flagSides)
{

   # ..........................................................................................
   if ((flagSides != 'rightSided') && (flagSides != 'leftSided') &&  (flagSides != 'twoSided')) {
     cat("ERROR: from Stat.plotCoxROCWithBio: flagSides = ", flagSides, " is not valid.\n", sep = "");
     cat("Valid: rightSided, leftSided, twoSided.\n");
     stop();
   }

   stopifnot(fBio >= 0, fBio <= 1);   
   # ..........................................................................................
   
  
   # ...................................................................................
   # . For the given hazard ratio, generate a series of arrays of P-values for
   # . the specified numbers of samples :
   # ...................................................................................
   apBig = list();
   abetaBig = list();   
   nBig = length(an);    # Number of values of n.
   
   for (i in 1:nBig) {
     cat("Process for n = ", an[i], "\n", sep = "");
     cF = Stat.generateCoxPvalWithBio(n1 = an[i], n2 = an[i],
                                      fBio,
                                      fcens = fcens, hr = hr,
                                      rngSeed = rngSeed, ns = ns);

     apBig[[i]] = cF$ap;                 # This is P(|z| > |z_obs|).
     abetaBig[[i]] = cF$abeta;

     if ((flagSides == 'leftSided') || (flagSides == 'rightSided')) {
       apBig[[i]] = 0.5 * apBig[[i]];    # Adjust to P(z > |z_obs|) or P(z < -|z_obs|) for one-sided test
     }     
   }

   aS = (1:ns) / ns;           # Array of sensitivities.
   # ...................................................................................


   # ...................................................................................
   # . Compute sensitivity at given confidence level, for each value of n :
   # ...................................................................................   
   aSSim = c();
   aSTheo = c();   
   
   for (i in 1:nBig) {
     ap = apBig[[i]];
     abeta = abetaBig[[i]];     

     if (flagSides == 'twoSided') {
       sT = length(ap[ap <= alpha]) / ns;
     } else if (flagSides == 'rightSided') {
       sT = length(ap[(ap <= alpha) & (abeta >= 0.0)]) / ns;
     } else if (flagSides == 'leftSided') {
       sT = length(ap[(ap <= alpha) & (abeta <= 0.0)]) / ns;
     }
       
     aSSim = c(aSSim, sT);
   }
   # ...................................................................................

   
   # ...................................................................................
   # . Plot sensitivity versus sample number :
   # ...................................................................................      
   caption = paste("Sensitivity for hr = ", sprintf("%6.3e", hr), "; alpha = ", alpha, "; ", flagSides, sep = "");

   cex.main.OLD = par("cex.main");
   par(cex.main = 0.8);
   plot(an, aSSim, type = 'l', main = caption, xlab = 'n', ylab = 'sensitivity', 
        xlim = c(0, max(an)), ylim = c(0,1));
   par(cex.main = cex.main.OLD); 
   # ...................................................................................


   # ...................................................................................
   buf = readline(">>Enter a carriage return to continue: ");    # Pause.
   # ...................................................................................
   
   
   # ...................................................................................   
   # . Plot ROCs for the given values of sample numbers :
   # ...................................................................................
   acolBase = c('gray', 'blue', 'green', 'red', 'black');  # Sets color rotation.
   nc = length(acolBase);                                  # Periodicity.
   icBig = 1;                                              # Global color index.
   acol = c();
   # ....................................................................................
   # . Make plot for first value of n :
   # ....................................................................................   
   caption = paste('ROC for Cox model; hazard ratio hr = ', sprintf("%6.3e", hr), "; ", flagSides, sep = "");
   cex.main.OLD = par("cex.main");
   par(cex.main = 0.8);

   icBig1 = icBig - 1;   
   ic = 1 + icBig1%%nc;
   plot(sort(apBig[[1]]), aS, type = 'l', col = acolBase[ic], 
        main = caption, 
        xlab = "false positive rate", ylab = "sensitivity",
        xlim = c(0,1), ylim = c(0,1));
   acol = c(acolBase[ic]);
   icBig = icBig + 1;

   abline(a = 0.0, b = 1.0, lty = 'dashed');    # Null didtribution.   
   # ....................................................................................
   # . Make plots for subsequent values of n, if any :
   # ....................................................................................     
   if (nBig > 1) {
     for (i in 2:nBig) {
       icBig1 = icBig - 1;
       ic = 1 + icBig1%%nc;
       lines(sort(apBig[[i]]), aS, type = 'l', col = acolBase[ic]);
       acol = c(acol, acolBase[ic]);
       icBig = icBig + 1;
     }
   }
   # ....................................................................................
   # . Generate legend :
   # ....................................................................................
   legendText = as.character(an);
   colVector = acol;
   ltyVector = rep('solid', times = nBig);
   legend(x = 0.8, y = 0.3, legend = legendText, col = colVector, lty = ltyVector, bty = 'n');
   # ....................................................................................



   # ....................................
   # . Package power profile as list :
   # ....................................
   afBio = rep(fBio, times = length(an));
   ahr = rep(hr, times = length(an));
   
   sOut = list(an = an,
               ahr = ahr,
               afBio = afBio,
               aSSim = aSSim);
   # ....................................


   # ...............
   return (sOut);
   # ...............
   

}

# ======================================================================================
# . End of Stat.plotCoxROCWithBio.
# ======================================================================================






# ===============================================================================================
# . Stat.powerCoxSchoenfeld : use Schoenfeld's approximation to compute the power
# . -----------------------   of a Cox proportional hazard model for a given
# .                           hazard ratio and given significance level.
# .
# . Syntax :
# .
# .   pow = Stat.powerCoxSchoenfeld(n, hr, alpha, flagSides = 'oneSided');
# .
# . In:
# .        n = TOTAL number of samples in either baseline or treated studies,
# .            where we assume n1 = n2 = n / 2.
# .       hr = hazard ratio between studies.
# .    alpha = significance level.
# .      flagSides = specifies number of sides in the test. Allowed:
# .                  'twoSided', 'oneSided'.
# .
# . Out:
# .       pow = power of test to detect alternative hypothesis at given significance level.
# .
# ......................................................................................
# . Details :
# .
# . This is based on the approximation for the sampling variance of the estimated log(hR) :
# .
# .                      4
# .    var(log(hR)) =  -----
# .                    n . d
# .
# . where n = TOTAL number of subjects, with (n/2) subjects per group, and d = probability of an
# . event occurring during the total duration of the study.
# . see: http://en.wikipedia.org/wiki/Log-rank_test
# .
# ================================================================================================

Stat.powerCoxSchoenfeld <- function(n, hr, alpha, flagSides = 'oneSided')
{

   # ..........................................................................................
   if ((flagSides != 'oneSided') &&  (flagSides != 'twoSided')) {
     cat("ERROR: from Stat.powerCoxSchoenfeld: flagSides = ", flagSides, " is not valid.\n", sep = "");
     cat("Valid: oneSided, twoSided.\n");
     stop();
   }     
   # ..........................................................................................



   # ..........................................................................................
   if (flagSides == 'twoSided') {
     Z1alpha = qnorm(0.5 * alpha, lower.tail = FALSE);
   } else if (flagSides == 'oneSided') {
     Z1alpha = qnorm(alpha, lower.tail = FALSE);     
   }

   Zbeta = 0.5 * sqrt(n) * abs(log(hr)) - Z1alpha;
   pow = pnorm(Zbeta);
   # ..........................................................................................


   # ...............
   return (pow);
   # ...............

}

# =============================================================================================
# . End of Stat.powerCoxSchoenfeld.
# =============================================================================================




# ===============================================================================================
# . Stat.nminPowerCoxSchoenfeld : use Schoenfeld's approximation to compute the power
# . ---------------------------   the minimum number of samples required in a Cox proportional hazard model 
# .                               to achieve a given power of detection, at given hazard ratio
# .                               and given significance level.
# .
# . Syntax :
# .
# .   nmin  = Stat.nminPowerCoxSchoenfeld(hr, beta, alpha, flagSides = 'oneSided');
# .
# . In:
# .        n = TOTAL number of samples in either baseline or treated studies,
# .            where we assume n1 = n2 = n / 2.
# .       hr = hazard ratio between studies.
# .    alpha = significance level.
# .      flagSides = specifies number of sides in the test. Allowed:
# .                  'twoSided', 'oneSide'.
# .
# . Out:
# .
# .       nmin = minimum number of samples for detection at given confidence level 
# .              and power.
# ......................................................................................
# .
# . This is based on the approimation for the sampling variance of the estimated log(hR) :
# .
# .                      4
# .    var(log(hR)) =  -----
# .                    n . d
# .
# . where n = TOTAL number of subjects, with (n/2) subjects per group, and d = probability of an
# . event occurring during the total duration of the study.
# . see: http://en.wikipedia.org/wiki/Log-rank_test
# .
# ================================================================================================

Stat.nminPowerCoxSchoenfeld <- function(hr, beta, alpha, flagSides = 'oneSided')
{

   # ..........................................................................................
   if ((flagSides != 'oneSided') &&  (flagSides != 'twoSided')) {
     cat("ERROR: from Stat.nminPowerCoxSchoenfeld: flagSides = ", flagSides, " is not valid.\n", sep = "");
     cat("Valid: oneSided, twoSided.\n");
     stop();
   }

   stopifnot(beta > 0, beta < 1);
   #xxx stopifnot(hr > 0);   
   # ..........................................................................................



   # ..........................................................................................
   if (flagSides == 'twoSided') {
     Z1alpha = qnorm(0.5 * alpha, lower.tail = FALSE);
   } else if (flagSides == 'oneSided') {
     Z1alpha = qnorm(alpha, lower.tail = FALSE);     
   }

   Zbeta = qnorm(beta, lower.tail = TRUE);

   nmin = 4 * ((Z1alpha + Zbeta) / log(hr))^2;
   # ..........................................................................................


   # ...............
   return (nmin);
   # ...............

}

# =============================================================================================
# . End of Stat.nminPowerCoxSchoenfeld.
# =============================================================================================





# ======================================================================================
# . Stat.combinePvalMean : combines n P-values, returns a single P-value, using as
# . --------------------   global statistic the mean of the logs of the individual
# .                        P-values.
# .
# . Syntax:
# .
# .      pAll = Stat.combinePval(ap);
# .
# . In:
# .      ap = array of P-values to be combined. All values must be >= 0.
# .           Values exactly equal to 0 are replaced by Stat.PVALMIN_FOR_COMBINE
# .           prior to taking the logarithm.
# .
# . Out:
# .      pAll = P-value based on sum statistic (see below).
# .
# ......................................................................................
# . * Details:
# .
# . We generate the global sum statistic :
# .
# .                 n
# .        u0 = -  sum  log(p  )
# .                i=1       i
# .
# . The global P-value is then based on testing against the gamma-distribution :
# .
# .              infnty
# .             /       n-1
# .             |      u
# .        p =  |    -------- exp(-u) du
# .             |    (n - 1)!
# .             /
# .            u0
# .
# ======================================================================================

Stat.combinePvalMean <- function(ap)
{

  # ..............................................
  pmin = min(ap, na.rm = TRUE);

  if (pmin < 0.0) {
    cat("ERROR: from Stat.combinePvalMean:\n");
    cat("The input array ap has values < 0");
  }
  # ..............................................


  # ..................................
  ap = na.omit(ap);  # Remove NAs.
  # ..................................

  
  # .....................................................................
  apBuf = ifelse(ap == 0.0, Stat.PVALMIN_FOR_COMBINE, ap);   # Control for values with P = 0 exactly.
  
  u0 = - sum(log(apBuf));
  pAll = pgamma(u0, shape = length(apBuf), scale = 1.0, lower.tail = FALSE);
  # .....................................................................


  # .............
  return (pAll);
  # .............  
  
}

# ======================================================================================
# . End of Stat.combinePvalMean.
# ======================================================================================






# ======================================================================================
# . Stat.combinePvalMedian : combines n P-values, returns a single P-value, using as
# . ----------------------   global statistic the median of the logs of the individual
# .                        P-values.
# .
# . Syntax:
# .
# .      pAll = Stat.combinePval(ap);
# .
# . In:
# .      ap = array of P-values to be combined. All values must be >= 0.
# .           Values exactly equal to 0 are replaced by Stat.PVALMIN_FOR_COMBINE
# .           prior to taking the logarithm.
# .
# . Out:
# .      pAll = P-value based on sum statistic (see below).
# .
# ......................................................................................
# . * Details:
# .
# . We generate the global ``medianized'' sum statistic :
# .
# .                 
# .        u0 = - n . Median  log(p )
# .                                i
# .
# . The global P-value is then based on testing against the gamma-distribution :
# .
# .              infnty
# .             /       n-1
# .             |      u
# .        p =  |    -------- exp(-u) du
# .             |    (n - 1)!
# .             /
# .            u0
# .
# ======================================================================================

Stat.combinePvalMedian <- function(ap)
{

  # ..............................................
  pmin = min(ap, na.rm = TRUE);

  if (pmin < 0.0) {
    cat("ERROR: from Stat.combinePvalMedian:\n");
    cat("The input array ap has values < 0");
  }
  # ..............................................  

  
  # ..................................
  ap = na.omit(ap);  # Remove NAs.
  # ..................................
  
  
  # .....................................................................
  apBuf = ifelse(ap == 0.0, Stat.PVALMIN_FOR_COMBINE, ap);   # Control for values with P = 0 exactly.
  
  u0 = - n * median(log(apBuf));                             # ``Medianized'' sum.
  pAll = pgamma(u0, shape = length(apBuf), scale = 1.0, lower.tail = FALSE);
  # .....................................................................


  # .............
  return (pAll);
  # .............  
  
}

# ======================================================================================
# . End of Stat.combinePvalMedian.
# ======================================================================================








# ===========================================================================================
# . Stat.basicROC : generates ROC sensitivity and false-positive arrays, given an input
# . -------------   score vector and {0, 1} true classification.
# .
# . Syntax :
# .
# .      roc = Stat.basicROC(ax, ac, flagPval, flagConfInterval, flagNormalModel, prob = 0.95);
# .
# . In:
# .        ax = vector of prognostic indices, such that the estimate of P(y = 1|x) is
# .             given by the logit function :
# .
# .                                     1
# .                  P(y = 1|x) = ---------------
# .                                1 + exp(- ax)
# .
# .             or equivalently,
# .
# .                         P(y = 1|x)
# .                  log ----------------- =  ax
# .                       1 - P(y = 1|x)
# .
# .             IF ax is not a prgnostic index, then the AUC and ROC calculations are
# .             still valid, but not any of the predictions predicated in MAP class
# .             assignments, the latter being simply :
# .
# .                             0 if x < 0
# .                   ayPred =
# .                             1 if x >= 0.
# .
# . 
# .        ac = vector of true class assignments. Values must be in {0,1}.
# .
# .              For a fixed threshold xc, the classifier is:
# .
# .                           --
# .                           | 0 ,   x <= xc
# .                   C(x) =  |
# .                           | 1 ,   x > xc.
# .                           --
# .
# .              i.e. class 1 is associated with a ``large'' positive score.
# .
# .
# .     * The following flags are used to turn off the corresponding options when doing
# .        bootstrap calculations. The default options are that the calculations get done.
# .
# .                flagPval = if TRUE, compute the P-value based on the Wilcoxon rank-sum test.
# .                           if FALSE, return NULL member.
# .
# .        flagConfInterval = if TRUE, compute confidence intervals for both the null hypothesis
# .                           and for the actual sensitivity profile. If FALSE, do not compute
# .                           these, and return NULL members.
# .
# .       flagNormalModel = if TRUE, compute the ROC corresponding to the assumption of
# .                           a normal distribution for samples taken from each two classes;
# .                           if FALSE, return NULL members.
# .
# .                  prob = probability for confidence interval (default = 0.95).
# .
# . Out:
# .       roc = list, with members :
# .
# ===========================================================================================

Stat.basicROC <- function(ax, ac,
                          flagPval = TRUE,
                          flagConfInterval = TRUE,
                          flagNormalModel = TRUE,
                          prob = 0.95)
{

     # ...................................
     stopifnot(prob > 0.0, prob < 1.0);
     # ...................................
     
  
     # ..................................................................................
     n = length(ax);       # Number of samples.
     nc = length(ac);      # Number of class labels (must be the same).
     
     if (nc != n) {
       cat("ERROR: from Stat.basicROC: length of class labels vector not same as score vector.\n");
       stop();
     }

     abuf = unique(ac) %in% c(0,1)

     if (length(which(abuf == FALSE)) > 0) {
       cat("ERROR: from Stat.basicROC: some class labels are neither 0 nor 1.\n");
       stop();
     }

     n1 = sum(ac);         # Number of members in class = 1.
     n0 = n - n1;          # Number of members in class = 0.

     if (n1 == 0) {
       cat("ERROR: from Stat.basicROC: 0 members with class 1.\n");
       stop();
     }

     if (n0 == 0) {
       cat("ERROR: from Stat.basicROC: 0 members with class 0.\n");
       stop();
     }

     if (flagNormalModel) {
       if ((n0 == 1) || (n1 == 1)) {
         cat("ERROR: from Stat.basicROC: class 0 or 1 has just 1 member.\n");
         cat("The normal model computation was requested, and I cannot compute\n");
         cat("the normal model for distributions with n = 1.\n");
         stop();         
       }
     }
     # ..................................................................................


    

     # ..................................................................................
     # . Sort in order of increasing score :
     # ..................................................................................     
     sBuf = sort(ax, decreasing = FALSE, index.return = TRUE);
     indexBuf = sBuf[["ix"]]; 

     axSort = ax[indexBuf];
     acSort = ac[indexBuf];
     # ..................................................................................



     # ..................................................................................
     # . Generate the sums of 1 and 0-class members, with x > xc, with the values of
     # . xc taken at every actual data value.
     # ..................................................................................
     anCum = cumsum(acSort);        # Upward cumulative sum.

     an1 = n1 - anCum;              # Number of true positives at the corresponding threshold.
     an0 = n0 - (1:n) + anCum;      # Number of false positives at the corresponding threshold.

     an1 = c(n1, an1);              # This corresponds to a threshold taken anywhere to the
     an0 = c(n0, an0);              # left of all the score values.

     aS = an1 / n1;                 # Sensitivity.
     aFP = an0 / n0;                # False positives.

     aSum = c(an0 + an1);                          # Is sequence: n, n-1, . . . , 1, 0.
     aFDR = ifelse(aSum > 0, an0 / aSum, 1.0);     # False-discovery rate.

     aErr = (an0 + n1 - an1) / n;   # Error rate on threshold = FP + FN on class 1 estimation.
     # ..................................................................................

     

     # ..................................................................................
     # . Compute point-wise error rates :
     # . >> 1. Minimum empirical error rate.
     # ..................................................................................
     errMin = min(aErr);                            # Minimum error rate.
     jMin = which.min(aErr);                        # Index in aS array for minimun error rate.

     if (jMin > 1) {
       xcMin = axSort[jMin - 1];                    # Threshold for min. error, under x > xc ==> class 1.
     } else {
       xcMin = min(ax) - 0.1 * (max(ax) - min(ax)); # Puts threshold to left of all points.
     }
     # ..................................................................................     
     # . >> 2. MAP error rate : this assumes that x = logit(P(y = 1|x)) is a
     # .       prognostic index. It is meaningless otherwise.
     # .
     # . Here MAP simply means : assign class = 1 if x >= 0.
     # ..................................................................................     
     #xxx ubuf = (ax - 0.5) * (2 * ac - 1);
     ubuf = ax * (2 * ac - 1);
     errMAP = sum(ubuf < 0) / n;                         # Negative ubuf -> misclassified instance.
     # ..................................................................................
     # . Add an analytic estimate of CI for MAP classification :
     # ..................................................................................     
     sigmaErrMAP = sqrt(errMAP * (1.0 - errMAP) / n);    # Binomial estimate.

     temp1 = 0.5 * (1.0 - prob);                 # Area under right-hand tail of PDF.
     zc = qnorm(temp1, lower.tail = FALSE);

     errMAPLo = max(0.0, errMAP - zc * sigmaErrMAP);
     errMAPHi = min(1.0, errMAP + zc * sigmaErrMAP);     
     # ..................................................................................
     # . Determine sorted array index which corresponds to decision boundary :
     # ..................................................................................    
     #xxxx indexBuf = which(axSort < 0.5);
     indexBuf = which(axSort < 0.0);

     if (length(indexBuf) > 0) {
       jMAP = 1 + max(indexBuf);                    # Index in aS array for threshold MAP error rate.
     } else {
       jMAP = 1;
     }

     if (jMAP > n) {
       jMAP = n;                                    # Failsafe.
     }
     # ..................................................................................
     # . Compute sensitivity and false-positive rates for MAP assignments. Add analytic
     # . CI estimates.
     # . >> Sensitivity :
     # ..................................................................................    
     SMAP = aS[jMAP];
     sigmaSMAP = sqrt(SMAP * (1.0 - SMAP) / n);    # Binomial estimate.
     SMAPLo = max(0.0, SMAP - zc * sigmaSMAP);
     SMAPHi = min(1.0, SMAP + zc * sigmaSMAP);
     # ..................................................................................         
     # . >> False positive :
     # ..................................................................................    
     FPMAP = aFP[jMAP];
     sigmaFPMAP = sqrt(FPMAP * (1.0 - FPMAP) / n);    # Binomial estimate.
     FPMAPLo = max(0.0, FPMAP - zc * sigmaFPMAP);
     FPMAPHi = min(1.0, FPMAP + zc * sigmaFPMAP);
     # ..................................................................................         
     # . >> FDR :
     # ..................................................................................
     nf = n1 * SMAP + n0 * FPMAP;     # Total number found.
     nfp = n0 * FPMAP;                # False positives among these.

     FDRMAP = 1;

     if (nf > 0) {
       FDRMAP = nfp / nf;
     }
     # ..................................................................................     
     


     # ..................................................................................
     # . Compute AUC :
     # ..................................................................................
     nall = length(aS);
     nall1 = nall - 1;

     ah = rev(aS);
     ad = rev(aFP);
     
     ah = ah[2:nall];                       # Catch right-hand points.
     ad = ad[2:nall] - ad[1:nall1];         # Intervals, some of which are zero.

     auc = sum(ad * ah);
     # ..................................................................................




     # ........................................................................................
     # . Compute the P-value if requested :
     # ........................................................................................
     pval = NULL;
     
     if (flagPval) {
       ax0 = ax[ac == 0];
       ax1 = ax[ac == 1];       
       w = wilcox.test(ax0, ax1);
       pval = w$p.value;
     }
     # ........................................................................................
     

     

     # ........................................................................................
     # . Compute confidence intervals if requested.
     # ........................................................................................
     aSnullLo = NULL;
     aSnull = NULL;
     aSnullHi = NULL;     

     aSLo = NULL;
     aSHi = NULL;

     aFPnull = NULL;
     
     if (flagConfInterval) {
       # ................................................................................
       # . Compute value of z corresponding to specified confidence interval :
       # ................................................................................
       temp1 = 0.5 * (1.0 - prob);               # Area under right-hand tail of PDF.
       zc = qnorm(temp1, lower.tail = FALSE);
       # ..................................................................................       
       # . >>1. Confidence interval for the null hypothesis :
       # ..................................................................................
       nx = 100;              # Rather arbitrary.
       dx = 1.0 / nx; 
       aFPnull = dx * (0:nx);
       deltaSnull = sqrt(aFPnull * (1.0 - aFPnull)) / sqrt(n1);    # Estimated sd.
       aSnullLo = aFPnull - zc * deltaSnull;
       aSnull = aFPnull;     
       aSnullHi = aFPnull + zc * deltaSnull;

       aSnullLo = ifelse(aSnullLo >= 0.0, aSnullLo, 0.0);
       aSnullHi = ifelse(aSnullHi <= 1.0, aSnullHi, 1.0);       
       # ..................................................................................     
       # . >>2. Confidence interval for the estimated values :
       # ..................................................................................
       sigmaS = sqrt(aS * (1.0 - aS)) / sqrt(n1);

       expLo = ifelse(aS > 0.0, exp(- zc * sigmaS / aS), 0.0);
       expHi = ifelse(aS < 1.0, exp(- zc * sigmaS /(1.0 - aS)), 0.0);

       aSLo = aS * expLo;
       aSHi = 1.0 - (1.0 - aS) * expHi;
       # ..................................................................................       
     }
     # ........................................................................................



     # ........................................................................................
     # . Normal model for the ROC if requested :
     # ........................................................................................
     aSnormal = NULL;
     aFPnormal = NULL;
     aucNormal = NULL;
     
     if (flagNormalModel) {
       # ...............................................................................
       # . Estimate the model parameters :
       # ...............................................................................       
       ax0 = ax[which(ac == 0)];   # Samples for class 0.
       ax1 = ax[which(ac == 1)];   # Samples for class 1.

       mu0 = mean(ax0)  ;          # Mean.
       sigma0 = sd(ax0);           # Sd.  

       mu1 = mean(ax1);            # Mean.
       sigma1 = sd(ax1);           # Sd.

       r = max(ax) - min(ax);      # Range of values.

       if (r == 0.0) {
         cat("ERROR: from Stat.basicROC: all values in input are identical!\n");
         stop();
       }
       
       if (sigma0 == 0) {
         sigma0 = 1.0e-3 * r;      # To get a finite distribution.
       }

       if (sigma1 == 0) {
         sigma1 = 1.0e-3 * r;      # To get a finite distribution.
       }       
       # ...............................................................................
       # . Generate model-based sensitivity and false-positive distributions :
       # ...............................................................................
       xlo = min(ax) - 0.1 * r;              # Determine range of scan for 
       xhi = max(ax) + 0.1 * r;              # values of x.

       xlo = min(xlo, mu0 - 3.0 * sigma0, mu1 - 3.0 * sigma1);
       xhi = max(xhi, mu0 + 3.0 * sigma0, mu1 + 3.0 * sigma1);       

       nx = 100;                                        # Rather arbitrary number of points.
       dx = (xhi - xlo) / (nx - 1);  
       axScan = xlo + dx * ((1:nx) - 1.0);              # We'll compute on this grid of points,

       aSnormal = pnorm(axScan, mean = mu1, sd = sigma1, lower.tail = FALSE);    # P(x > =xc|1)
       aFPnormal = pnorm(axScan, mean = mu0, sd = sigma0, lower.tail = FALSE);   # P(x >= xc|0)

       temp1 = (mu1 - mu0) / sqrt(sigma1^2 + sigma0^2);
       aucNormal = pnorm(temp1, lower.tail = TRUE);      # AUC estimate for normal model.
       # ...............................................................................       
     }
     # ........................................................................................     


     
     # ...........................................................................
     # . Package the results :
     # ...........................................................................
     roc = list(axSort = axSort,           # Input values sorted in increasing order.
                acSort = acSort,           # Corresponding {0, 1} class labels.
                n0 = n0,                   # Number of elements in class 0.
                n1 = n1,                   # Number of elements in class 1.
                aS = aS,                   # Empirical S values.
                aFP = aFP,                 # Empirical FP values.
                aFDR = aFDR,               # Empirical FDR values.       
                auc = auc,                 # Emprirical AUC.
                pval = pval,               # P-value from Wilcoxon test.
                errMin = errMin,           # Minimum error rate.
                jMin = jMin,               # Array index in aS array for minimun error rate threshold.
                xcMin = xcMin,             # Threshold for min. error, under x > xc ==> class 1.
                errMAP = errMAP,           # Error under MAP (valid only if x = logit(P(y = 1|x)) is a prognostic index).
                errMAPLo = errMAPLo,       # Lower bound on CI for errMAP.
                errMAPHi = errMAPHi,       # Upper bound on CI for errMAP.
                SMAP = SMAP,               # Sensitivity under MAP (valid only if x = logit(P(y = 1|x)) is a prognostic index).
                SMAPLo = SMAPLo,           # Lower bound on CI for SMAP.
                SMAPHi = SMAPHi,           # Upper bound on CI for SMAP.
                FPMAP = FPMAP,             # False-positive rate under MAP (valid only if x = logit(P(y = 1|x)) is a prognostic index).
                FPMAPLo = FPMAPLo,         # Lower bound on CI for FPMAP.
                FPMAPHi = FPMAPHi,         # Upper bound on CI for SMAP.
                FDRMAP = FDRMAP,           # FDR for MAP.
                jMAP = jMAP,               # Index in aS array for MAP error rate threshold.
                aFPnull = aFPnull,         # Analytic values for FP under null hypothesis.
                aSnullLo = aSnullLo,       # Analytic values for 0.025 level of S under null hyp.
                aSnull = aSnull,           # Analytic values for S under null hyp.
                aSnullHi = aSnullHi,       # Analytic values for 0.975 level of S under null hyp.
                aSLo = aSLo,               # Semi-empirical values for 0.025 level around actual S.
                aSHi = aSHi,               # Semi-empirical values for 0.975 level around actual S.
                aSnormal = aSnormal,       # S under normal model approximation.
                aFPnormal = aFPnormal,     # FP under normal model approximation.
                aucNormal = aucNormal);    # AUC under normal model approximation.

     class(roc) = "roc";
     # ............................................................................


     # .............
     return (roc);
     # .............
  
}
  
# ===========================================================================================
# . End of Stat.basicROC.
# ===========================================================================================






# ===========================================================================================
# . Stat.plotROC : generates ROC sensitivity and false-positive arrays, given an input
# . ------------   score vector and {0, 1} true classification, and plots the results.
# .
# . Syntax :
# .
# .      roc = Stat.plotROC(ax, ac, prob = 0.95, flagCI = 'no');
# .
# . In:
# .        ax = vector of scores.
# .        ac = vector of true class assignments. Values must be in {0,1}.
# .
# .              For a fixed threshold xc, the classifier is:
# .
# .                           --
# .                           | 0 ,   x <= xc
# .                   C(x) =  |
# .                           | 1 ,   x > xc.
# .                           --
# .
# .              i.e. class 1 is associated with a ``large'' positive score.
# .
# .
# .      prob = probability for confidence interval (default = 0.95).
# .
# .    flagCI = if 'yes', do not show binormal distribution curve, but add
# .             the confidence interval for the empirical ROC curve.
# .
# .
# . Out:
# .       roc = list, with members same as for Stat.basicROC (see above).
# .
# ===========================================================================================

Stat.plotROC <- function(ax, ac, prob = 0.95, flagCI = 'no')
{

        # .................................................
        stopifnot(prob > 0.0, prob < 1.0);
        stopifnot((flagCI == 'yes') || (flagCI == 'no'));
        # .................................................
     
  
        # ..................................................................................
        n = length(ax);       # Number of samples.
        nc = length(ac);      # Number of class labels (must be the same).
     
        if (nc != n) {
          cat("ERROR: from Stat.basicROC: length of class labels vector not same as score vector.\n");
          stop();
        }

        abuf = unique(ac) %in% c(0,1)

        if (length(which(abuf == FALSE)) > 0) {
          cat("ERROR: from Stat.basicROC: some class labels are neither 0 nor 1.\n");
          stop();
        }

        n1 = sum(ac);         # Number of members in class = 1.
        n0 = n - n1;          # Number of members in class = 0.

        if (n1 == 0) {
          cat("ERROR: from Stat.basicROC: 0 members with class 1.\n");
          stop();
        }

        if (n0 == 0) {
          cat("ERROR: from Stat.basicROC: 0 members with class 0.\n");
          stop();
        }
        # ..................................................................................

  

        # ..................................................................................
        # . Compute ROCs :
        # ..................................................................................        
        roc = Stat.basicROC(ax, ac,
                            flagPval = TRUE,
                            flagConfInterval = TRUE,
                            flagNormalModel = TRUE,
                            prob = 0.95);

        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ATemp = sprintf("%8.3e", roc$auc);           # Area under curve.
        pvalTemp = sprintf("%8.3e", roc$pval);       # Wilcoxon P-value for detection of y = 1 versus y = 0.
        errMAPTemp = sprintf("%8.3e", roc$errMAP);   # Error rate under MAP classification.
        errMinTemp = sprintf("%8.3e", roc$errMin);   # Minimum error rate.
      
        caption = paste("ROC: AUC = ", ATemp,
                        ", P-value = ", pvalTemp,
                        ", errMAP = ", errMAPTemp,
                        ", errMin = ", errMinTemp,
                        sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        # ........................................................................
        # . Plot empirical ROC :
        # ........................................................................        
        plot(roc$aFP, roc$aS,
             xlim = c(0, 1),
             ylim = c(0, 1),
             xlab = 'FP',
             ylab = 'S',
             main = caption,
             type = 'l',
             lwd = 2,
             pch = 19);

        points(roc$aFP[roc$jMAP], roc$aS[roc$jMAP], pch = 19);
        points(roc$aFP[roc$jMin], roc$aS[roc$jMin], pch = 19, col = 'red');        
        # ........................................................................
        # . Add analytic null distribution plus-minus 1 sd, and binormal
        # . model approximation :
        # ........................................................................        
        lines(roc$aFPnull, roc$aSnull, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullLo, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullHi, type = 'l', col = 'blue');        

        if (flagCI == 'no') {
          lines(roc$aFPnormal, roc$aSnormal, lty = 'dashed');
        } else {
          lines(roc$aFP, roc$aSLo, lty = 'dashed');
          lines(roc$aFP, roc$aSHi, lty = 'dashed');        
        }
        # ........................................................................
        # . Add legend :
        # ........................................................................
        if (flagCI == 'no') {        
          legendText = c("empirical", "binormal", "null, CI 95%");
        } else {
          legendText = c("empirical", "empirical, CI 95%", "null, CI 95%");          
        }
        
        colVector = c('black', 'black', 'blue');
        ltyVector = c('solid', 'dashed', 'solid');
        lwdVector = c(2, 1, 1);        
        legend(x = 0.6, y = 0.3,
               legend = legendText, 
               col = colVector, lty = ltyVector, lwd = lwdVector, bty = 'n');
        
        legendText = c("MAP", "Min");
        colVector = c('black', 'red');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = 0.6, y = 0.12,
               legend = legendText,
               col = colVector, pch = pchVector, bty = 'n');
        
        par(cex.main = cex.main.OLD);
        # ..................................................................................


        # ...............................................
        # . Package output :
        # ...............................................        
        rocOut = list(roc = roc, aucStats = aucStats);
        # ...............................................


        # .................
        return (rocOut);
        # .................


}
     
# ===========================================================================================
# . End of Stat.plotROC.
# ===========================================================================================






# ===========================================================================================
# . Stat.plotROCnoPlot : generates ROC sensitivity and false-positive arrays, given an input
# . ------------------   score vector and {0, 1} true classification.
# .                      This is identical to Stat.plotRIC, but does not generate plots
# .                      (only returns numerical values).
# . Syntax :
# .
# .      roc = Stat.plotROCnoPlot(ax, ac, prob = 0.95, flagCI = 'no');
# .
# . In:
# .        ax = vector of scores.
# .        ac = vector of true class assignments. Values must be in {0,1}.
# .
# .              For a fixed threshold xc, the classifier is:
# .
# .                           --
# .                           | 0 ,   x <= xc
# .                   C(x) =  |
# .                           | 1 ,   x > xc.
# .                           --
# .
# .              i.e. class 1 is associated with a ``large'' positive score.
# .
# .
# .      prob = probability for confidence interval (default = 0.95).
# .
# .    flagCI = if 'yes', do not show binormal distribution curve, but add
# .             the confidence interval for the empirical ROC curve.
# .
# .
# . Out:
# .       roc = list, with members same as for Stat.basicROC (see above).
# .
# ===========================================================================================

Stat.plotROCnoPlot <- function(ax, ac, prob = 0.95, flagCI = 'no')
{

        # .................................................
        stopifnot(prob > 0.0, prob < 1.0);
        stopifnot((flagCI == 'yes') || (flagCI == 'no'));
        # .................................................
     
  
        # ..................................................................................
        n = length(ax);       # Number of samples.
        nc = length(ac);      # Number of class labels (must be the same).
     
        if (nc != n) {
          cat("ERROR: from Stat.plotROCnoPlot: length of class labels vector not same as score vector.\n");
          stop();
        }

        abuf = unique(ac) %in% c(0,1)

        if (length(which(abuf == FALSE)) > 0) {
          cat("ERROR: from Stat.plotROCnoPlot: some class labels are neither 0 nor 1.\n");
          stop();
        }

        n1 = sum(ac);         # Number of members in class = 1.
        n0 = n - n1;          # Number of members in class = 0.

        if (n1 == 0) {
          cat("ERROR: from Stat.plotROCnoPlot: 0 members with class 1.\n");
          stop();
        }

        if (n0 == 0) {
          cat("ERROR: from Stat.plotROCnoPlot: 0 members with class 0.\n");
          stop();
        }
        # ..................................................................................

  

        # ..................................................................................
        # . Compute ROCs :
        # ..................................................................................        
        roc = Stat.basicROC(ax, ac,
                            flagPval = TRUE,
                            flagConfInterval = TRUE,
                            flagNormalModel = TRUE,
                            prob = 0.95);

        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);        
        # .......................................................................................


        # ...............................................
        # . Package output :
        # ...............................................        
        rocOut = list(roc = roc, aucStats = aucStats);
        # ...............................................


        # .................
        return (rocOut);
        # .................


}
     
# ===========================================================================================
# . End of Stat.plotROCnoPlot.
# ===========================================================================================









# ===========================================================================================
# . Stat.bootBasicROC : generates ROC sensitivity and false-positive arrays, given an input
# . -----------------   score vector and {0, 1} true classification.
# .                     This version bootstraps on Stat.basicROC() to generate bootstrap
# .                     statistics.
# .
# . Syntax :
# .
# .      roc = Stat.bootBasicROC(ax, ac, nsamp, prob = 0.95);
# .
# . In:
# .        ax = vector of scores.
# .        ac = vector of true class assignments. Values must be in {0,1}.
# .
# .              For a fixed threshold xc, the classifier is:
# .
# .                           0 ,   x <= xc
# .                   C(x) =
# .                           1 ,   x > xc.
# .
# .              i.e. class 1 is associated with a ``large'' positive score.
# .
# .     nsamp = number of bootstrap resamplings to be done.
# .     prob = probability for confidence interval (default = 0.95).
# .
# . Out:
# .       roc = list, with members :
# .
# ===========================================================================================

Stat.bootBasicROC <- function(ax, ac, nsamp, prob = 0.95)
{


     # ..................................................................................
     n = length(ax);       # Number of samples.
     nc = length(ac);      # Number of class labels (must be the same).
     
     if (nc != n) {
       cat("ERROR: Stat.bootBasicROC: length of class labels vector not same as score vector.\n");
       stop();
     }

     abuf = unique(ac) %in% c(0,1)

     if (length(which(abuf == FALSE)) > 0) {
       cat("ERROR: Stat.bootBasicROC: some class labels are neither 0 nor 1.\n");
       stop();
     }

     n1 = sum(ac);         # Number of members in class = 1.
     n0 = n - n1;          # Number of members in class = 0.

     if (n1 == 0) {
       cat("ERROR: Stat.bootBasicROC: 0 members with class 1.\n");
       stop();
     }

     if (n0 == 0) {
       cat("ERROR: Stat.bootBasicROC: 0 members with class 0.\n");
       stop();
     }
     # ..................................................................................


     
     # ..................................................................................
     # . Other checks :
     # ..................................................................................
     stopifnot(nsamp > 0);
     stopifnot(prob > 0.0, prob < 1.0);
     # ..................................................................................     

     
     # ..................................................................................
     # . Compute for the actual observation :
     # ..................................................................................     
     roc.obs = Stat.basicROC(ax, ac,
                             flagPval = TRUE,
                             flagConfInterval = TRUE,
                             flagNormalModel = TRUE);
     auc.obs = roc.obs$auc;                                     # Observed auc.
     # ..................................................................................


     
     # ..................................................................................
     # . Do bootstrap resampling for each population separately.
     # ..................................................................................     
     ax0 = ax[ac == 0];
     ax1 = ax[ac == 1];

     aAuc = c();                # Array with auc values.
     
     for (k in 1:nsamp) {
       ax0Buf = sample(x = ax0, size = n0, replace = TRUE);
       ax1Buf = sample(x = ax1, size = n1, replace = TRUE);     

       axBuf = c(ax0Buf, ax1Buf);
       acBuf = c(rep(0, times = length(ax0Buf)),
                 rep(1, times = length(ax1Buf)));

       roc.buf = Stat.basicROC(axBuf, acBuf,
                               flagPval = FALSE,
                               flagConfInterval = FALSE,
                               flagNormalModel = FALSE);
       aAuc = c(aAuc, roc.buf$auc);
     }     

     dprob = 0.5 * (1.0 - prob);
     probLo = dprob;
     probHi = 1.0 - dprob;
     
     aucLo = quantile(aAuc, prob = probLo);
     aucMed = median(aAuc);
     aucHi = quantile(aAuc, prob = probHi);

     nabove = sum(aAuc >= 0.5);
     P1 = nabove / nsamp;         # Area for auc* > 0.5.

     if (P1 < 0.5) {
       pval = 2.0 * P1;           # Two-sided P-value.
     } else {
       pval = 2.0 * (1.0 - P1);   # Two-sided P-value.
     }
     # ..................................................................................



     # ................................................
     # . Package the results :
     # ................................................
     roc = list(aS = roc.obs$aS,
                aFP = roc.obs$aFP,
                auc = auc.obs,
                aucLo = aucLo,
                aucMed = aucMed,
                aucHi = aucHi,
                pval = pval);

     class(roc) = "roc.boot";
     # ................................................


     
     # ...............
     return (roc);
     # ...............

}

# ===========================================================================================
# . End of Stat.bootBasicROC.
# ===========================================================================================





# ===========================================================================================
# . Stat.probabilityOnCountBayes : estimates probability of a binary event given the count
# . ----------------------------   of events and the total number of observations.
# .                                This is based on a Bayesian formulation.
# .
# .  Syntax :
# .
# .           theta = Stat.probabilityOnCountBayes(k, n, prob)
# .
# .  In:
# .           k = count of events.
# .           n = total number of observations.
# .        prob = probability for confidence interval (e.g. 0.95).
# .
# .  Out:
# .        List with members (pLo, p, pHi) where :
# .
# .            pLo = lower limit of confidence interval.
# .              p = value form median estimator for p.
# .            pHi = upper limit of confidence interval.
# .
# ..........................................................................................
# . Details:
# .
# .     * With uniform prior, the posterior distribution for p, the probability of the
# .       event, is given by:
# .
# .                          
# .                           / n \   k          n -k
# .          P(p|k) = (n + 1) |   |  p  . (1 - p)
# .                           \ k /
# .
# .                           
# ===========================================================================================

Stat.probabilityOnCountBayes <- function(k, n, prob = 0.95)
{
  
     # ......................................................................... 
     if (min(n - k) < 0) {
       cat("ERROR: from Stat.probabilityOnCountBayes:\n");
       cat("Some event counts are greater than the number of obeservations.\n");
       stop()
     }

     stopifnot((prob > 0.0) && (prob < 1.0));
     # .........................................................................

     

     # ........................................................
     shape1 = k + 1;
     shape2 = n - k + 1;

     probLo = 0.5 * (1.0 - prob);
     probHi = 0.5 * (1.0 + prob);

     pLo = qbeta(probLo, shape1 = shape1, shape2 = shape2);  
     p = qbeta(0.5, shape1 = shape1, shape2 = shape2);
     pHi = qbeta(probHi, shape1 = shape1, shape2 = shape2);    
     # ........................................................


     # ........................................................
     # . Special formating for single-value estimates :
     # ........................................................
     textCI = "";

     if (length(k) == 1) {
       pLobuf = sprintf("%8.2e", pLo);
       pbuf = sprintf("%8.2e", p);              
       pHibuf = sprintf("%8.2e", pHi);

       textCI = paste(pbuf, "[", pLobuf, ", ", pHibuf , "]_", prob, sep ="");
     }
     # ........................................................     


     
     # ..............................
     # . Package the results :
     # ..............................
     theta = list(pLo = pLo,
                  p = p,
                  pHi = pHi,
                  textCI = textCI);
     # ..............................


     # ..............
     return (theta);
     # ..............
}

# ===========================================================================================
# . End of Stat.probabilityOnCountBayes.
# ===========================================================================================






# ===========================================================================================
# . Stat.aucROCTest : for the given area A under the curve of a ROC for binary 
# . ---------------   discrimination between n1 and n2 samples, computes 
# .                   the statistical significance of A and its confidence limits,
# .                   using analytical formulas.
# . Syntax :
# .
# .          auc = Stat.aucROCTest(A, n1, n2, prob = 0.95);
# .
# . In:
# .        A = observed area under the curve (auc), 0 <= A <= 1.
# .        n1 = number of samples in first panel.
# .        n2 = number of samples in second panel.
# .      prob = probability for confidence interval.
# .
# . Out:
# .       auc = list, with members :
# .
# .           A = input area under curve.
# .         ALo = lower bound on CI
# .         AHi = upper bound on CI.
# .        pval = P-value
# .
# ...........................................................................................
# .  Details:
# .
# .  Under the null hypothesis of no difference in the distributions of the two populations,
# .  the auc is A given by :
# .
# .                       U
# .                        2
# .                A = --------
# .                    n1 . n2
# .
# .  where U2 is the Wilcoxon rank-sum statistic. The sampling variance of the auc under
# .  the same null hypothesis is then distribution-free, and given by:
# .
# .                2        1
# .          sigmaA  =   ----------  (n2 + n1 + 1)
# .                      12 n1 . n2
# .
# .  and this is used to calculate a P-value against the null hypothesis.
# .
# .  In general, the sampling variance of the auc under non-central 
# .  conditions depends on the distributional details. However, an analyitc expression
# .  based on exponentail distributions seems in fact a reasonable approximation for
# .  most distributions (normal, etc) :
# .
# .           2        1                               q         2
# .     sigmaA   =  -------  ( q (1 - q) + (n2 - 1) (-------  - q  )
# .                 n1 . n2                           2 - q
# .
# .                                                        2
# .                                                     2 q       2
# .                                        + (n1 - 1) (------- - q  )          Eq.(1).
# .                                                     1 + q
# .
# . where q = <A> = <Prob(X2 > x1)> is the true mean of A.
# .
# . * Eq.(1) can be written in a more symmetrical form:
# .
# .
# .
# .           2        1         1            1
# .     sigmaA   =  -------  ( (--- - dq) . (--- + dq)
# .                 n1 . n2      2            2
# .
# .                                           1
# .                                          --- + dq
# .                                           2             1       2
# .                            + (n2 - 1) .(----------  - (--- + dq)  )
# .                                           3             2
# .                                          --- - dq
# .                                           2
# .
# .                                           1
# .                                          --- - dq
# .                                           2             1       2
# .                            + (n1 - 1) .(----------  - (--- - dq)  )  )
# .                                           3             2
# .                                          --- + dq
# .                                           2
# . where dq = q - 1/2.
# .
# . * Finally, note that the much simpler formula :
# .
# .
# .            2    (n1 + n2 + 1)
# .      sigmaA  =  ------------- q . (1 - q)
# .                   3 n1 . n2
# .
# . is a very good approximation to the equations above.
# .
# ...........................................................................................
# . See also:  Stat.bootBasicROC
# .
# ===========================================================================================

Stat.aucROCTest <- function(A, n1, n2, prob = 0.95)
{

     # ........................................
     stopifnot((A >= 0.0) && (A <= 1.0));
     stopifnot(n1 > 0);
     stopifnot(n2 > 0);
     stopifnot((prob > 0.0) && (prob < 1.0));     
     # ........................................

     

     # ...................................................................
     # . Compute the P-value against the null hypothesis :
     # ...................................................................     
     sigA02 = 0.08333333 * (n1 + n2 + 1) / (n1 * n2);
     sigA0 = sqrt(sigA02);
     z = abs(A - 0.5) / sigA0;
     pval = 2.0 * pnorm(z, lower.tail = FALSE);
     # ...................................................................


     
     # ...................................................................
     # . Compute confidence limits :
     # ...................................................................
     q = A;
     q2 = q * q;

     temp2 = q / (2.0 - q) - q2;
     temp1 = 2 * q2 / (1.0 + q) - q2;

     buf1 = q * (1.0 - q) + (n2 - 1) * temp2 + (n1 - 1) * temp1;
     sigA = sqrt(buf1 / (n1 * n2));

     zc = qnorm(0.5 * (1.0 - prob), lower.tail = FALSE);
     dA = zc * sigA;

     ALo = A - dA;
     ALo = ifelse(ALo > 0.0, ALo, 0.0);
     AHi = A + dA;
     AHi = ifelse(AHi < 1.0, AHi, 1.0);     
     # ...................................................................          


     # ...........................
     auc = list(A = A,
                ALo = ALo,
                AHi = AHi,
                pval = pval);
     # ...........................


     # .............
     return (auc);
     # .............
     
}

# ===========================================================================================
# . End of Stat.aucROCTest.
# ===========================================================================================





# =========================================================================================================================
# . Stat.plotLinearRegressionFit : generates a scatter plot for two arrays, displays linear regression values
# . ----------------------------   in title.
# .                        
# .  Syntax :
# .
# .       Stat.plotLinearRegressionFit(ax, ay, ar = NULL,
# .                                    flagConfInt = FALSE,
# .                                    flagOrigin = FALSE, xlab = NULL, ylab = NULL,
# .                                    captionIn = '');
# .
# .  In :
# .              ax, ay = numerical arrays to be compared. They must have the same length.
# .         flagConfInt = if TRUE, plot +/- 1 std dev lines parallel to main regression line.
# .          flagOrigin = TRUE: set lower bounds of both X and Y at 0.
# .                  ar = optional array of sample names.
# .                xlab = optional X variable name.
# .                ylab = optional Y variable name.
# .           captionIn = optional prefix to plot title.
# .
# =========================================================================================================================

Stat.plotLinearRegressionFit <- function(ax, ay, ar = NULL,
                                         flagConfInt = FALSE,
                                         flagOrigin = FALSE,
                                         xlab = 'X', ylab = 'Y', captionIn = '')
{

     # ...............................................................
     n = length(ax);

     if (length(ay) != n) {
       cat("ERROR: from Stat.plotLinearRegression:\n");
       cat("Length of ay not same a ax.\n");
       stop();
     }

     if (!is.null(ar)) {
       if (length(ar) != n) {
         cat("ERROR: from Stat.plotLinearRegression:\n");
         cat("Length of ar not same a ax.\n");
         stop();
       }
     }
     # ...............................................................


     
     # ..............................................................................................
     # . Compute model and significance of fit :
     # ..............................................................................................
     fl = lm(ay ~ ax,  na.action = 'na.omit');
     fls = summary(fl);
     fla = anova(fl);

     beta0 = fls$coefficients[1,1];
     beta1 = fls$coefficients[2,1];
     pval =  fls$coefficients[2,4]
     R2 = fls$r.squared;
     sigma = fls$sigma;

     abuf = (!is.na(ax)) & (!is.na(ay));   # Flags as TRUE all pairs in which both members are non-NA.
     nused = sum(abuf);                    # Number of samples actually used in model.
     # ...............................................................................................
     



     # .........................................................................................
     # . Generate plot :
     # .........................................................................................     
     caption = paste(captionIn, ": nused = ", nused,
                     ", P = ", sprintf("%8.3e", pval),
                     ", R2 = ", sprintf("%8.3e", R2), 
                     ", beta0 = ", sprintf("%8.3e", beta0),
                     ", beta1 = ", sprintf("%8.3e", beta1), sep = "");

     if (flagOrigin) {
       plot(ax, ay, xlab = xlab, ylab = ylab,
            main = caption, pch = 19, xlim = c(0, 1.2 * max(ax)), ylim = c(0, 1.2 * max(ay)));
     } else {
       plot(ax, ay, xlab = xlab, ylab = ylab, main = caption, pch = 19);
     }

     if (!is.null(ar)) {     
       text(ax, ay, labels = ar, pos = 4, offset = 0.5);
     }
       
     abline(beta0, beta1, lty = 'dashed', col = 'blue');

     if (flagConfInt) {
       tempLo = beta0 - sigma;
       tempHi = beta0 + sigma;

       abline(tempLo, beta1, lty = 'dashed', col = 'black');
       abline(tempHi, beta1, lty = 'dashed', col = 'black');     
     }
     # .........................................................................................


     # ...........
     return (0);
     # ...........

}

# =========================================================================================================================
# . End of Stat.plotLinearRegressionFit.
# =========================================================================================================================



# =====================================================================================================
# . Stat.generateBinaryConfusionMatrix :  generates a confusion matrix for binary {0, 1} classification.
# . ----------------------------------
# .
# .  Syntax :
# .
# .      cm = Stat.generateBinaryConfusionMatrix(ayIn, ayOut);
# .
# .  In :
# .
# .      ayIn = (true) input class values, in {0, 1}.
# .      ayOut = (predicted) output class values, all in {0, 1}.
# .
# .  Out :
# .
# .      
# =====================================================================================================

Stat.generateBinaryConfusionMatrix <- function(ayIn, ayOut)
{
  
      # .................................................................
      # . Check on parameters :
      # .................................................................  
      n = length(ayIn);
      nOut = length(ayOut);

      if (nOut != n) {
        cat("ERROR: in Stat.generateBinaryConfusionMatrix:\n");
        cat("The arrays ayIn and ayOut do not have the same length.\n");
        stop();
      }

      abuf = unique(ayIn) %in% c(0,1)

      if (length(which(abuf == FALSE)) > 0) {
        cat("ERROR: in Stat.generateBinaryConfusionMatrix:\n");
        cat("Array ayIn has some values which are not 0 or 1.\n");
        stop();
      }

      abuf = unique(ayOut) %in% c(0,1)

      if (length(which(abuf == FALSE)) > 0) {
        cat("ERROR: in Stat.generateBinaryConfusionMatrix:\n");
        cat("Array ayOut has some values which are not 0 or 1.\n");
        stop();
      }      
      # .................................................................

      

      # ....................................................................
      # . Compute the confusion matrix :
      # ....................................................................
      c11 = sum(ayIn * ayOut);
      c00 = sum((1 - ayIn) * (1 - ayOut));
      c01 = sum((1 - ayIn) * ayOut);
      c10 = sum(ayIn * (1 - ayOut));

      M = matrix(c(c00, c01, c10, c11), nrow = 2, ncol = 2, byrow = TRUE);

      rownames(M) = c('input0', 'input1');
      colnames(M) = c('output0', 'output1');
      # ....................................................................
      # . Generate a version with margins pre-computed :
      # ....................................................................      
      Mmarg = addmargins(M);
      
      rownames(Mmarg) = c('input0', 'input1', 'column_sums');
      colnames(Mmarg) = c('output0', 'output1', 'row_sums');
      # ....................................................................
      # . Compute overall error rate and 95% confidence limits :
      # ....................................................................            
      errCount = sum(ayOut != ayIn);
      errRate = errCount / n;

      sigmaErrRate = sqrt(errRate * (1.0 - errRate) / n);         # Binomial estimate for sd.

      errRateLo95 = max(0.0, errRate - 1.959964 * sigmaErrRate);  
      errRateHi95 = min(1.0, errRate + 1.959964 * sigmaErrRate);      
      # ....................................................................
      # . Compute a P-value based on the Fisher exact test or Chisq approx.
      # ....................................................................      
      if (n < 100) {
        buf = fisher.test(M);
      } else {
        buf = chisq.test(M);
      }

      pval = buf$p.value;
      # ....................................................................


      
      # ..............................................................................
      # . Package results :
      # ..............................................................................
      cm = list(M = M,                        # Confusion matrix.
                Mmarg = Mmarg,                # Confusion matrix with margins added.
                errCount = errCount,          # Error count.
                errRateLo95 = errRateLo95,    # Error rate, lower bound on 95% CI.
                errRate = errRate,            # Error rate.
                errRateHi95 = errRateHi95,    # Error rate, upper bound on 95% CI.
                pval = pval);                 # P-value from 2 * 2 contingency table.
      # ..............................................................................


      # ............
      return (cm);
      # ............

}

# =====================================================================================================
# . End of Stat.generateBinaryConfusionMatrix.
# =====================================================================================================






# =====================================================================================================
# . Stat.generateMultipleClassConfusionMatrix :  generates a confusion matrix for multiple class
# . -----------------------------------------    classification.
# .
# .  Syntax :
# .
# .      cm = Stat.generateMultipleClassConfusionMatrix(ayIn, ayOut);
# .
# .  In :
# .
# .      ayIn = (true) input class values.
# .      ayOut = (predicted) output class values.
# .
# .  Out :
# .
# .      
# =====================================================================================================

Stat.generateMultipleClassConfusionMatrix <- function(ayIn, ayOut)
{
  
      # .................................................................
      # . Check on parameters :
      # .................................................................  
      n = length(ayIn);
      nOut = length(ayOut);

      if (nOut != n) {
        cat("ERROR: in Stat.generateMultipleClassConfusionMatrix:\n");
        cat("The arrays ayIn and ayOut do not have the same length.\n");
        stop();
      }
      # .................................................................

      

      # ....................................................................
      # . Compute the confusion matrix :
      # ....................................................................
      M = table(ayIn, ayOut);
      # ....................................................................
      # . Generate a version with margins pre-computed :
      # ....................................................................      
      Mmarg = addmargins(M);
      # ....................................................................
      # . Compute overall error rate and 95% confidence limits :
      # ....................................................................            
      errCount = sum(as.character(ayOut) != as.character(ayIn));
      errRate = errCount / n;
      sigmaErrRate = sqrt(errRate * (1.0 - errRate) / n);         # Binomial estimate for sd.

      errRateLo95 = max(0.0, errRate - 1.959964 * sigmaErrRate);  
      errRateHi95 = min(1.0, errRate + 1.959964 * sigmaErrRate);      
      # ....................................................................
      # . Compute a P-value based on the Fisher exact test or Chisq approx.
      # ....................................................................      
      if (n < 100) {
        buf = fisher.test(M);
      } else {
        buf = chisq.test(M);
      }

      pval = buf$p.value;
      # ....................................................................


      
       
      # ............................................................................................
      # . Compute S and FDR for each of the input classes.
      # . First restrict rows and columns to common classes :
      # ............................................................................................
      acIn = sort(unique(ayIn));                    # Unique row names.
      acOut = sort(unique(ayOut));                  # Unique column names.

      acCom = intersect(acIn, acOut);               # Common input-output classes.
      ncCom = length(acCom);                        # Number of common input-output classes.

      if (ncCom == 0) {
        cat(" ..........  Note: no common input-output classes found.\n");
        cat("             S and FDR will be set to NULL in list returned.\n");
        aS = NULL;
        aFDR = NULL;
      }

      if (ncCom > 0) {
        # ..........................................................................................
        # . Reduce the confusion matrix to the common classes :
        # ..........................................................................................
        Mbuf = M[acCom, ];
        Mcom = Mbuf[ , acCom];
        # ..........................................................................................
        # . Sensitivities and FDR for detection :
        # ..........................................................................................                
        aS = diag(Mcom) / rowSums(Mcom);
        abuf = colSums(Mcom);
        aFDR = (abuf - diag(Mcom)) / abuf;
        # ..........................................................................................        
      }
      # ............................................................................................      

      

      
      # ..............................................................................
      # . Package results :
      # ..............................................................................
      cm = list(M = M,                        # Confusion matrix.
                Mmarg = Mmarg,                # Confusion matrix with margins added.
                errCount = errCount,          # Error count.
                errRateLo95 = errRateLo95,    # Error rate, lower bound on 95% CI.
                errRate = errRate,            # Error rate.
                errRateHi95 = errRateHi95,    # Error rate, upper bound on 95% CI.
                pval = pval,                  # P-value from 2 * 2 contingency table.
                aS = aS,                      # Class-by-class detection sensitivity.
                aFDR = aFDR);                 # Class-by-class detection FDR.
      # ..............................................................................


      # ............
      return (cm);
      # ............

}

# =====================================================================================================
# . End of Stat.generateMultipleClassConfusionMatrix.
# =====================================================================================================





# =====================================================================================================
# . Stat.computeOverlapSignificance :  uses Fisher exact test to compute significance of overlap
# . -------------------------------    of two genesest, in the context of a given number of background
# .                                    genes.
# .  Syntax :
# .
# .      sig = Stat.computeOverlapSignificance(agA, agB, n, flagBfold = FALSE);
# .
# .  In :
# .
# .         agA = array of test gene names (geneset being tested).
# .
# .         agB = array of reference gene names (e.g. defines a functional category,
# .               whose enrichment in the test geneset relative to all genes in
# .               "universe" is being tested).
# .
# .          n = number of genes in "universe". We must have n >= |agA U agB|.
# .
# .  flagBfold = if TRUE, also compute Bfold enrichment statistics.
# .
# .  Out :
# .          List, see packaging at end of function.
# .
# ....................................................................................................
# . Details :
# .
# .   i. Perform Fisher exact test on contingency table of A and B set memberships.
# .
# .   ii. Use Bfold Bayesian estimation, to obtain estimates of enrichment :
# .
# .                  abundance of category B in A
# .          R = -------------------------------------
# .               abundance of category B in universe
# .
# .      
# =====================================================================================================

Stat.computeOverlapSignificance <- function(agA, agB, n, flagBfold = FALSE)
{

      # ..................
      stopifnot(n >0);
      # ..................

      
      # ...................................................................................  
      agU = union(agA, agB);
      nU = length(agU);

      if (n < nU) {
        cat("ERROR: in Stat.computeOverlapSignificance:\n");
        cat("Number of genes specified for background is smaller than union of genes in input sets.\n");
        cat("n = ", n, " nU = ", nU, "\n", sep = "\t");
        stop();
      }
      # ...................................................................................

      
      
      # ...................................................................................
      # . Generate sets for the analysis :
      # ...................................................................................      
      ag11 = intersect(agA, agB);    # In both.
      ag10 = setdiff(agA, agB);      # In agA, not in agB.
      ag01 = setdiff(agB, agA);      # In agB, not in agA.

      nA = length(agA);
      nB = length(agB);      
      
      n11 = length(ag11);            # Number of genes in both A and B.
      n10 = length(ag10);            # Number of genes in A, not in B.
      n01 = length(ag01);            # Number of genes in B, not in A.
      n00 = n - nU;                  # Balance : number of genes in neither set.
      # ...................................................................................
      # . Perform Fisher exact test :
      # ...................................................................................      
      x = matrix(c(n00, n01, n10, n11), nrow = 2, byrow = TRUE);

      fs = fisher.test(x);
      # ...................................................................................
      # . Use Bayesian estimation as well, to obtain estimates of enrichment :
      # .
      # .       abundance of category B in A
      # .   R = -----------------------------------
      # .       abundance of category B in universe
      # .
      # ...................................................................................
      if (flagBfold) {
        cf =  Bfold.computeSimple(k1 = nB, n1 = n, k2 = n11, n2 = nA, qc = 0.025);
      } else {
        cf = list(Pval = 1.0, Rlo = 1.0, Rmed = 1.0, Rhi = 1.0);
      }
      # ...................................................................................



      # ...................................................................................
      ag11Buf = ag11;

      if (length(ag11) == 0) {
        ag11Buf = c("NONE");
      }
      # ...................................................................................      
      
     
      # ...................................................................................
      # . Package results :
      # ...................................................................................
      if (flagBfold) {
        sig = list(flagBfold = flagBfold,           # Did we also compute Bfold estimates?
                   nA = nA,                         # Number of genes in list.
                   nB = nB,                         # Number of genes in geneset whose enrichment is being tested.
                   nAB = n11,                       # Number of genes overlapping.
                   gAB = ag11Buf,                   # Array of overlapping genes.
                   pval.fisher = fs$p.value,        # P-value from Fisher exact test.
                   Rlo95.fisher = fs$conf.int[1],   # Lower bound on odds ratio,95% CI.
                   Rmed.fisher = fs$estimate,       # Median for odds ratio.
                   Rhi95.fisher = fs$conf.int[2],   # Upper bound on odds ratio,95% CI.
                   pval.bfold = cf$Pval,            # P-value from Bayesian estimation.
                   Rlo95.bfold = cf$Rlo,            # Lower bound on enrichment, 95% CI.
                   Rmed.bfold = cf$Rmed,            # Median estimator for enrichment.
                   Rhi95.bfold = cf$Rhi);           # Upper bound on enrichment, 95% CI.
      } else {
        sig = list(flagBfold = flagBfold,           # Did we also compute Bfold estimates?
                   nA = nA,                         # Number of genes in list.
                   nB = nB,                         # Number of genes in geneset whose enrichment is being tested.
                   nAB = n11,                       # Number of genes overlapping.
                   gAB = ag11Buf,                   # Array of overlapping genes.          
                   pval.fisher = fs$p.value,        # P-value from Fisher exact test.
                   Rlo95.fisher = fs$conf.int[1],   # Lower bound on odds ratio,95% CI.
                   Rmed.fisher = fs$estimate,       # Median for odds ratio.
                   Rhi95.fisher = fs$conf.int[2]);  # Upper bound on odds ratio,95% CI.

      }
      # ...................................................................................       


      # ..............
      return (sig);
      # ..............

}

# =====================================================================================================
# . End of Stat.computeOverlapSignificance.
# =====================================================================================================







# =========================================================================================
# . Stat.sampleBinarySplit : simple utility function, generates a binary split of the
# . ---------------------   input array. If the length of the array is odd, will
# .                         randomly split on floor or ceiling.
# .
# . Syntax:
# .
# .       axSub =  Stat.sampleBinarySplit(ax);
# .
# . In:
# .       ax = input array.
# .
# . Out:
# .       axSub = subsetted array.
# .
# =========================================================================================

Stat.sampleBinarySplit <- function(ax)
{
  
     # ..............................................
     nx = length(ax);

     if (nx%%2 == 0) {
       nx2 = floor(nx / 2);
     } else {
       if (runif(1) > 0.5) {
         nx2 = floor(nx / 2);
       } else {
         nx2 = ceiling(nx / 2);
       }
     }
       
     axSub = sample(ax, size = nx2);
     # ............................................


     # ...............
     return (axSub);
     # ...............

}

# =========================================================================================
# . End of Stat.sampleBinarySplit.
# =========================================================================================






# =========================================================================================
# . Stat.sampleMultipleSplit : simple utility function, generates a multiple split of the
# . -----------------------   input array. Will always put at least one element into each
# .                           category.
# .
# . Syntax:
# .
# .       axS =  Stat.sampleMultipleSplit(ax, K);
# .
# . In:
# .       ax = input array.
# .        K = number of splits.
# .
# . Out:
# .      axS = list with K elements, each of which
# .            contains a subset of ax corresponding to
# .            the split.
# .
# =========================================================================================

Stat.sampleMultipleSplit <- function(ax, K)
{

     # ..............................................................
     stopifnot(K > 0);
     n = length(ax);

     if (K > n) {
       cat("ERROR: from Stat.sampleMultipleSplit:\n");
       cat("Number K = ", K,
           " of splits requested is greater than number n = ", n,
           " elements in the input array.\n");
       stop();
     }
     # ..............................................................

     
     
     # ..............................................................
     # . Randomly 
     # ..............................................................     
     n = length(ax);
     ft = 1 / K;
     cs = Stat.generateSplitsForVfold(n, ft, flagRandom = TRUE);

     axS = lapply(cs$aIndexSplit, function(index){ax[index];})
     # ..............................................................


     # .....................
     return (axS);
     # .....................

}

# =========================================================================================
# . End of Stat.sampleMultipleSplit.
# =========================================================================================






# =================================================================================================
# . Stat.generateSplitsForVfold : generates splits for the ``strict'' version of vfold.
# . ---------------------------
# .
# . Syntax :
# .
# .       cs = Stat.generateSplitsForVfold(n, ft, flagRandom);
# .
# . In:
# .              n = total number of samples.
# .
# .             ft = fraction to be removed from the total to generate each test.
# .                  0 < ft < 1.
# .
# .     flagRandom = TRUE/FALSE. If TRUE, randomize index order before generating the groups.
# .                  If FALSE, the groups are generated in order of appearance of the indices.
# .
# . Out:
# .        cs = list with members :
# .
# .                ncv = number of groups generated.
# .              ntest = number of members in each group (last one may be truncated).
# .        aIndexSplit = list of ncv arrays, each array containing the indices of the group
# .                      to be extracted for a round of the cross-validation.
# .
# =================================================================================================

Stat.generateSplitsForVfold <- function(n, ft, flagRandom = FALSE)
{

      # ..................................
      stopifnot(ft > 0.0, ft < 1.0);
      stopifnot(n > 1);
      # ..................................
     

      
      # .............................................................
      # . Determine the value of ntest :
      # .............................................................      
      ntest = ceiling(ft * n);         # Tentative number in each test set.

      if (ntest < 1) {
        ntest = 1                 # Smallest test set has 1 element.
      };

      n2 = ceiling(n / 2);
      
      if (ntest > n2) {
        ntest = n2;               # At least two approximately equal groups.
      }
      # .............................................................


      
      # .................................................................................................
      # . Now generate the actual groups :
      # .................................................................................................
      bufIndex = 1:n;
      bufIndexChoose = bufIndex;

      if (ntest == 1) {
        mask = 1:n;                      # Each group will contain just one index.
      } else {
        bufB = bufIndex%%ntest;          # 0's mark transitions between groups.
        bufB = c(0, bufB[1:(n-1)]);      # Pad with one leading 0.
        bufC = ifelse(bufB == 0, 1, 0);  # Now 1's mark transitioons between groups, all others are 0.
        mask = cumsum(bufC);             # The cum. sum generates the fold labels {1 1 1 2 2 2 3 3 3 . . .}
      }
        
      if (flagRandom) {
        bufIndexChoose = sample(bufIndexChoose);         # Randomize before assigning to folds.
      }

      aIndexSplit = split(bufIndexChoose, mask);     # Maps: fold --> bag of samples.
      ncv = length(aIndexSplit);

      afold = c();
      afold[bufIndexChoose] = mask;                  # Maps: sample --> fold of which it is a member.
      # ..................................................................................................



      # ........................................................................
      # . Package the results :
      # ........................................................................
      cs = list(ncv = ncv,
                ntest = ntest,      
                aIndexSplit = aIndexSplit,    # List, maps: fold --> bag of samples.
                afold = afold);               # Array, maps: sample --> fold of which it is a member.
      # .........................................................................


      # ...........
      return (cs);
      # ...........
      
}  

# =================================================================================================
# . End of Stat.generateSplitsForVfold.
# =================================================================================================







# =================================================================================================
# . Stat.plotDloghRSurvivalForBinaryArms : plots survival times versus a risk index (here taken
# . ------------------------------------   to be the differenetial hazard ratio DloghR).
# .
# . Syntax :
# .
# .   Stat.plotDloghRSurvivalForBinaryArms(aDloghR, at, as, az, flagDisplayCens = 'no', caption);
# .
# . In:
# .
# .             aDloghR = array of risk values.
# .                  at = array of survival times.
# .                  as = array of censoring status (values are ignored if flagDisplayCens == 'no',
# .                       but must still have same length as aDloghR).
# .                  az = array of treatment arm variables (0 or 1).
# .     flagDisplayCens = yes/no; if yes, display censored variables as open dots.
# .                 hRC = threshold in log-hazard ratio. Must be > 0.
# .             caption = overall plot caption.
# .
# . Out:
# .        scatter plot.
# .
# ==================================================================================================

Stat.plotDloghRSurvivalForBinaryArms <- function(aDloghR, at, as, az,
                                                 flagDisplayCens = 'no',
                                                 hRC,
                                                 caption)
{

      # ..........................................................................................
      # . Check on values :
      # ..........................................................................................
      stopifnot(hRC > 0.0);
      
      n = length(aDloghR);  # Number of samples in risk vector.
      nt = length(at);    # Number of samples in survival time vector.
      ns = length(as);    # Number of samples in censoring status vector.
      nz = length(az);    # Number of samples in external covariate vector.
      
      if (nt != n) {
        cat("ERROR: from Stat.plotDloghRSurvivalForBinaryArms:",
            "The survival time vector at has nt = ", nt, "samples. ",
            "This is not the same as the n = ", n, " samples in the risk vector.", sep = "");      
        stop();
      }

      if (ns != n) {
        cat("ERROR: from Stat.plotDloghRSurvivalForBinaryArms:",
            "The censoring vector as has ns = ", ns, "samples. ",
            "This is not the same as the n = ", n, " samples in the risk vector.", sep = "");      
        stop();
      }

      if (nz != n) {
        cat("ERROR: from Stat.plotDloghRSurvivalForBinaryArms:",
            "The treatment arm vector az has nz = ", nz, "samples. ",
            "This is not the same as the n = ", n, " samples in the risk vector.", sep = "");      
        stop();
      }

      if ((flagDisplayCens != 'yes') && (flagDisplayCens != 'no')) {
        cat("ERROR: from Stat.plotDloghRSurvivalForBinaryArms:",
            "flagDisplayCens = ", flagDisplayCens, " is not valid. ",
            "Valid = yes or no.", sep = "");      
        stop();
      }

      msg = Stat.checkBinary(az);                     # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg != 'ok') {
        cat(msg, "\n");
        stop();
      }
      # ..........................................................................................



      # .....................................................................................
      # . Assign colors and shapes :
      # .....................................................................................
      n = length(aDloghR);
      acol = ifelse(az == 1, 'blue', 'red');

      if (flagDisplayCens == 'yes') {
        apch = ifelse(as == 1, 19, 21);
      } else {
        apch = rep(19, times = n);
      }
      # .....................................................................................
      # . For the feature selection level that maximizes significance :
      # . Plot survival times againsts DloghR.
      # .....................................................................................
      ymin = 0.0;
      ymax = 1.1 * max(at);

      xmax = max(aDloghR);
      xmin = min(aDloghR);
        
      captionBuf = paste("Surv. time vs. predicted DloghR: ", caption,
                        ": n = ", n, sep ="");

      cex.main.OLD = par("cex.main");
      par(cex.main = 0.8);            
      plot(aDloghR, at, ylim = c(ymin, ymax),
           type = 'p', xlab = 'predicted DloghR = loghR(Z = 1) - loghR(Z =0)',
           ylab = 'survival time', main = captionBuf, col = acol, pch = apch);
      abline(h = 0.0);
      par(cex.main = cex.main.OLD);

      abline(v = 0);                           # Abcissa.
      temp1 = log(hRC);
      abline(v = temp1, lty = 'dashed');       # Boundary for determining sensitive patients.
      # ......................................................................................
      # . Add the legend here:
      # ......................................................................................
      xtemp1 = xmax - 0.2 * (xmax - xmin);
      ytemp1 = ymax;

      if (flagDisplayCens == 'no') {
        legendText = c("Z = 0", "Z = 1");
        colVector = c('red', 'blue');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
      }

      if (flagDisplayCens == 'yes') {
        legendText = c("Z = 0 uncens.",
                       "Z = 0 cens.",
                       "Z = 1 uncens.",
                       "Z = 1 cens.");
        
        colVector = c('red', 'red', 'blue', 'blue');
        ltyVector = c('solid', 'solid', 'solid', 'solid');
        pchVector = c(19, 21, 19, 21);        
      }

      legend(x = xtemp1, y = ytemp1,
             legend = legendText, col = colVector, pch = pchVector, bty = 'n');      
      # ......................................................................................


      # ...........
      return (0);
      # ...........
}

# =================================================================================================
# . End of Stat.plotDloghRSurvivalForBinaryArms.
# =================================================================================================






# ==========================================================================================================
# . Stat.checkBinary : utility function, checks that the input vector contains just 0 and 1 values.
# . ---------------
# .
# . Syntax:
# .
# .     msg = Stat.checkBinary(az);
# .
# . In:
# .      az = array of numerical values.
# .
# . Out:
# .      msg = 'ok', if all values of az are in binary set {0, 1}, else a message
# .             listing up to the first 5 non-binary values.
# .
# ==========================================================================================================

Stat.checkBinary <- function(az) {

  # ...................................
  msg = 'ok';   # Provisionally ok.
  # ...................................  

  
  # ...............................................................
  ad = sort(unique(az));     # Distinct values.
  buf = ad %in% c(0,1);      # Mark those not in {0, 1}.

  if (length(buf[buf == FALSE]) > 0) {
    adNon = ad[buf == FALSE];
    ndDisplay = min(length(adNon), 5);

    msg = paste("Some values in the array are not binary (not in {0, 1}).\n");
    msg = paste(msg, "Non-binary values [up to first 5]: ",
                paste(adNon[1:ndDisplay], collapse = ", "), "\n", sep ="");
  }
  # ................................................................  


  # ...............
  return (msg);
  # ...............
  
}

# ==========================================================================================================
# . End of Stat.checkBinary.
# ==========================================================================================================
      






# ======================================================================================================
# . Stat.plotSurvivalROC : plots the time-dependent ROC curve for prediction of non-death/death status
# . --------------------   as a function of a given (bio)marker. Note that this is designed for
# .                        estimation of performabce of detection of SENSITIVE patients.
# .
# . Syntax :
# .
# .   Stat.plotSurvivalROC(am, at, as, az, tp, mc, caption);
# .
# . In:
# .
# .                  am = array of risk values (the larger, the greater the hazard).
# .                  at = array of survival times.
# .                  as = array of censoring status.
# .                  tp = prediction time for generating ROC(tp).
# .                  mc = threshold value for point estimate of (FP, S). Ignored if
# .                       not present or NULL.
# .             caption = overall plot caption.
# .
# . Out:
# .        ROC(tp) curve displayed as a plot.
# .
# .......................................................................................................
# .  Details :
# .  -------
# .
# .   * For a given prediction time tp, "sensitive" (D = 1) and "resistant" (D = 0) patients are
# .     defined by :
# .
# .           t > tp : D = 1
# .           t <= tp : D = 0
# .
# .   * For a given marker decision threshold mc, predicted class assignments are estimayed from :
# .
# .                -
# .        ^       |   0, m > mc    (high-risk, short survival).
# .        D (m) = |
# .                |   1, m <= mc   (low-risk, long survival).
# .                -
# .                               
# .    and we have the definitions :
# .
# .                                       ^     
# .             sensitivity : S =    Prob(D = 1|D = 1)
# .
# .                                       ^
# .          false-positive : FP =   Prob(D = 1|D = 0)
# .
# .
# .    Note that these are inverse of those assumed in Heagerty et al. (2000), in which the focus was
# .    on identifying the high-risk individuals. The relation with the Heagerty values (subscript h) are :
# .
# .
# .         S(mc) = 1 - FP  (mc)
# .                       h
# .
# .         FP(mc) = 1 - S  (mc)
# .                       h
# .
# .   and note that the AUC is unchanged by this transformation.
# .
# ......................................................................................................
# .   * Reference :
# .
# .     P. Heagerty, T. Lumley, M. Pepe (2000). Time-dependent ROC curves for censored
# .     survival data and a diagnostic marker. Biometrics 56:337-344.
# .
# =======================================================================================================

Stat.plotSurvivalROC <- function(am, at, as, az, tp, mc = NULL, caption)
{

      # ..........................................................................................
      # . Check on values :
      # ..........................................................................................
      stopifnot(tp > 0.0);
      
      n = length(am);     # Number of samples in marker vector.
      nt = length(at);    # Number of samples in survival time vector.
      ns = length(as);    # Number of samples in censoring status vector.
      
      if (nt != n) {
        cat("ERROR: from Stat.plotSurvivalROC:",
            "The survival time vector at has nt = ", nt, "samples. ",
            "This is not the same as the n = ", n, " samples in the risk vector.", sep = "");      
        stop();
      }

      if (ns != n) {
        cat("ERROR: from Stat.plotSurvivalROC:",
            "The censoring vector as has ns = ", ns, "samples. ",
            "This is not the same as the n = ", n, " samples in the risk vector.", sep = "");      
        stop();
      }
      # ..........................................................................................




      # ..........................................................................
      # . Compute the ROC(t) :
      # ..........................................................................
      span = 0.25 / n^0.3333;          # Span for the NNE model.
      
      sr = survivalROC(Stime = at, status = as, marker = am, 
                       predict.time = tp,
                        method = "NNE", span = span);

      aS = 1 - sr$FP;      # For positive detection of "sensitives".
      aFP = 1 - sr$TP;     # For positive detection of "sensitives".
      # ...........................................................................
      # . Compute a P-value (may not be strictly applicable however) :
      # ...........................................................................
      n0 = sum(at > tp);
      n1 = sum(at <= tp);
      aucStats = Stat.aucROCTest(sr$AUC, n0, n1, prob = 0.95);  
      pval = aucStats$pval;
      # ...........................................................................
      # . Compute a point-wise estimate if requested :
      # ...........................................................................
      if (!is.null(mc)) {
        srPoint = survivalROC(Stime = at, status = as, marker = am, 
                              predict.time = tp,
                              method = "NNE", span = span,
                              cut.values = mc);

        Spoint = 1 - srPoint$FP[2];      # For positive detection of "sensitives".
        FPpoint = 1 - srPoint$TP[2];     # For positive detection of "sensitives".

        if (Spoint == 0.0) {
          FDRpoint = 1.0;
        } else {
          FDRpoint = (n0 * FPpoint) / (n1 * Spoint + n0 * FPpoint);   # Estimated FDR.
        }

        PVpoint = 1.0 - FDRpoint;         # Predictive value ("positive predictive value").
        # .................................................................................
        # . Compute corresponding quantities for "mirror image" : detection of
        # . t <= tp individuals.
        # .................................................................................
        SpointNEG = 1 - FPpoint;
        FPpointNEG = 1 - Spoint;
        
        if (SpointNEG == 0.0) {
          FDRpointNEG = 1.0;
        } else {
          FDRpointNEG = (n1 * FPpointNEG) / (n0 * SpointNEG + n1 * FPpointNEG);   # Estimated FDR.
        }

        PVpointNEG = 1.0 - FDRpointNEG;         # Predictive value ("negative predictive value").
        # .................................................................................        
      }
      # ...........................................................................
      # . No point-wise estimate requested :
      # ...........................................................................
      if (is.null(mc)) {
        SpointPOS = NULL;
        FPpointPOS = NULL;
        FDRpointPOS = NULL;
        PVpointPOS = NULL;
        SpointNEG = NULL;
        FPpointNEG = NULL;
        FDRpointNEG = NULL;
        PVpointNEG = NULL;        
      }
      # ...........................................................................      




      
      
      # ...........................................................................
      # . Generate plot caption :
      # ...........................................................................
      aucBuf = sprintf("%6.3f", sr$AUC);
      pvalBuf = sprintf("%6.1e", pval);
      
      captionBuf = paste("ROC(t = ", tp, ") : ", caption, ", AUC = ", aucBuf, 
                         ", pval = ", pvalBuf, ", n = " , n , sep = "");
      # ............................................................................
      # . Generate plot :
      # ............................................................................
      cex.main.OLD = par("cex.main");
      par(cex.main = 0.85);
      
      plot(aFP, aS, type = 'l', 
           xlab = "FP", ylab = "S",
           main = captionBuf);
      par(cex.main = cex.main.OLD);
      # ...........................................................................
      # . Add point estimate if requested :
      # ...........................................................................
      if (!is.null(mc)) {
        points(FPpoint, Spoint, pch = 19, col = 'red');

        legendText = c(paste("mc = ", mc, sep = ""));
        colVector = c('red');
        ltyVector = c('solid');
        pchVector = c(19);        
        legend(x = 0.75, y = 0.12,
               legend = legendText,
               col = colVector, pch = pchVector, bty = 'n');
        
      }
      # ...........................................................................
      # . Plot CI for null hypothesis :
      # ...........................................................................
      zc = 1.96;             # 95% confidence interval.
      nx = 100;              # Rather arbitrary.
      dx = 1.0 / nx; 
      aFPnull = dx * (0:nx);
      deltaSnull = sqrt(aFPnull * (1.0 - aFPnull)) / sqrt(n);    # Estimated sd.
      aSnullLo = aFPnull - zc * deltaSnull;
      aSnull = aFPnull;     
      aSnullHi = aFPnull + zc * deltaSnull;

      aSnullLo = ifelse(aSnullLo >= 0.0, aSnullLo, 0.0);
      aSnullHi = ifelse(aSnullHi <= 1.0, aSnullHi, 1.0);       

      lines(aFPnull, aSnull, type = 'l', lty = 'dashed');
      lines(aFPnull, aSnullHi, type = 'l', lty = 'dashed');
      lines(aFPnull, aSnullLo, type = 'l', lty = 'dashed');
      # .............................................................................................


      # .............................................................................................
      # . Package results :
      # .............................................................................................
      sr = list(n = n,                      # Total number of samples.
                tp = tp,                    # Time defining discrete categories.
                n0 = n0,                    # Samples with T <= tp.
                n1 = n1,                    # Samples with T > tp.
                mc = mc,                    # Threshold on DloghR for point estimate.
                SpointPOS = Spoint,         # Sensitivity.
                FPpointPOS = FPpoint,       # False-positive.
                FDRpointPOS = FDRpoint,     # FDR.
                PVpointPOS = PVpoint,       # Predictive value = 1 - FDR ("positive predictive value").
                SpointNEG = SpointNEG,      # Sensitivity for detection of t <= tp.
                FPpointNEG = FPpointNEG,    # False-positive for detection of t <= tp.
                FDRpointNEG = FDRpointNEG,  # FDR for detection of t <= tp.
                PVpointNEG = PVpointNEG );  # Predictive value = 1 - FDR ("negative predictive value").
      # .............................................................................................      



      # ...........
      return (sr);
      # ...........
}

# =================================================================================================
# . End of Stat.plotSurvivalROC.
# =================================================================================================






# ======================================================================================================
# . Stat.computeConfProbOnCount : computes confidence probabilities for bootstrap or other
# . ---------------------------   resampling results.
# .                        
# . This estimates the probability Prob(x <= 0) or Prob(x >= 0) (depending on specification),
# . given a sequence of values contained in ax, typically generated by a bootstrap resampling.
# .
# . Syntax :
# .
# .      cpr = Stat.computeConfProbOnCount(ax, xc, side);
# .
# . In:
# .
# .      ax = array of values, in range -infinity < x < infinity.
# .      xc = cutoff for dichotmizing regions.
# .    side = side for doing the test. Allowed values:
# .               'negative' : estimate Prob(x <= xc);
# .               'positive' : estimate Prob(x >= xc);
# .
# . Out:
# .
# .     cpr = list with members indicated at end of function.
# .
# =======================================================================================================

Stat.computeConfProbOnCount <- function(ax, xc, side)
{

      # ............................................................
      if ((side != 'negative') && (side != 'positive')) {
        cat("ERROR: from Stat.computeConfProbOnCount:\n");
        cat("side = ", side, " is not valid.\n", sep = "");
        stop();
      }

      nboot = length(ax);       # Total number of samples.

      stopifnot(nboot > 0);
      # ............................................................


      
      # ................................................................................................
      # .  Non-parametric estimate based on counts :
      # ................................................................................................
      if (side == 'negative') {
        ncount = length(which(ax <= xc));                 # Count of number of instances with x <= xc.
      } else if (side == 'positive') {
        ncount = length(which(ax >= xc));                 # Count of number of instances with x >= xc.
      } else {
        stop();                                            # Failsafe.
      }
        
      theta = Stat.probabilityOnCountBayes(k = ncount, n = nboot);     # Bayesian estimate of Pr(cond(x)).

      pconfLo = theta$pLo;                                 # Lower bound on CI (95%).
      pconf = theta$p;                                     # Median estimator. 
      pconfHi = theta$pHi;                                 # Upper bound on CI (95%).
      # ...................................................................................................

      
      # ...................................................................................................
      # .  Parametric estimate based on gaussian model and sample mean/sd :
      # ...................................................................................................
      mu = mean(ax);
      sigma = sd(ax);
      
      if (side == 'negative') {
        pconf_ANALYTIC = pnorm(xc, mean = mu, sd = sigma, lower.tail = TRUE);     # Area LEFT of x = xc.
      } else if (side == 'positive') {
        pconf_ANALYTIC = pnorm(xc, mean = mu, sd = sigma, lower.tail = FALSE);    # Area RIGHT of x = 0.        
      }
      # ....................................................................................................


      

      # ................................................
      # . Package results :
      # ................................................
      cpr = list(side = side,
                 xc = xc,
                 nboot = nboot,
                 ncount = ncount,
                 pconfLo = pconfLo,
                 pconf = pconf,
                 pconfHi = pconfHi,
                 pconf_ANALYTIC = pconf_ANALYTIC);
      # ................................................


      
      # ............
      return (cpr);
      # ............
      
}

# ======================================================================================================
# . End of Stat.computeConfProbOnCount.
# ======================================================================================================






# ======================================================================================================
# . Stat.plotSurvivalContingencyTable : Given two factors, and two-armed study survival data, plots 
# . ---------------------------------   a 'survival contingency table' consisting of survival curves 
# .                                     for all factor combinations plus margins.
# .
# . Syntax :
# .
# .      ffM = Stat.plotSurvivalContingencyTable(dfA,
# .                                              tTime, tCens, tZ,
# .                                              legend_0, legend_1,
# .                                              tFac1, tFac2,
# .                                              label1, label2,
# .                                              captionEnd);
# .
# . In :
# .
# .             dfA = input data frame.
# .           tTime = column name defining survival times.
# .           tCens = column name defining censoring status.
# .              tZ = column name defining binary treatment arm (Z = 0 or Z = 1).
# .        legend_0 = label for Z = 0 treatment arm.
# .        legend_1 = label for Z = 1 treatment arm.
# .
# .           tFac1 = column name for first factor.
# .           tFac2 = column name for second factor.
# .          label1 = literal name for first factor (e.g. "phase").
# .          label2 = literal name for second factor (e.g. "response").
# .
# .      captionEnd = caption suffix for overall plot sub-title (e.g. "stringent threshold").
# .                   For the examples given above, the overall sub-title is:
# .                         "phase * response : stringent threshold"
# .                   With an empty string, no suffix is appendne.
# .                           
# .
# . Out :
# .
# .    ffM = table of counts with margins.
# .
# .......................................................................................................
# . Note: this requires the module SuperPcDiag.r to be loaded.
# ,
# =======================================================================================================

Stat.plotSurvivalContingencyTable <- function(dfA,
                                              tTime, tCens, tZ,
                                              legend_0 = '0', legend_1 = '1',                                  
                                              tFac1, tFac2,
                                              label1, label2,
                                              captionEnd)
{

       # ....................................................................................
       # . Check input parameters :
       # ....................................................................................
       if (is.null(dfA[[tTime]])) {
         cat("ERROR: from Stat.plotSurvivalContingencyTable:\n");
         cat("factor tTime = ", tTime, " is not defined in input data frame.\n", sep = "");
         stop();
       }

       if (is.null(dfA[[tCens]])) {
         cat("ERROR: from Stat.plotSurvivalContingencyTable:\n");
         cat("factor tCens = ", tCens, " is not defined in input data frame.\n", sep = "");
         stop();
       }

       if (is.null(dfA[[tZ]])) {
         cat("ERROR: from Stat.plotSurvivalContingencyTable:\n");
         cat("factor tZ = ", tZ, " is not defined in input data frame.\n", sep = "");
         stop();
       }

       if (is.null(dfA[[tFac1]])) {
         cat("ERROR: from Stat.plotSurvivalContingencyTable:\n");
         cat("factor tFac1 = ", tFac1, " is not defined in input data frame.\n", sep = "");
         stop();
       }

       if (is.null(dfA[[tFac2]])) {
         cat("ERROR: from Stat.plotSurvivalContingencyTable:\n");
         cat("factor tFac2 = ", tFac2, " is not defined in input data frame.\n", sep = "");
         stop();
       }
       # .....................................................................................

       
       # .....................................................................................
       # . Check on internal values :
       # .....................................................................................
       msg = Stat.checkBinary(dfA[[tZ]]);

       if (msg != 'ok') {
         cat("ERROR: from Stat.plotSurvivalContingencyTable:\n");
         cat(msg, "\n", sep = "");
         stop();
       }

       afac1 = unique(as.character(dfA[[tFac1]]));              # Distinct levels for factor 1.
       afac2 = unique(as.character(dfA[[tFac2]]));              # Distinct levels for factor 2.

       afac1 = sort(afac1[!is.na(afac1)]);     # Remove NAs and sort.
       afac2 = sort(afac2[!is.na(afac2)]);     # Remove NAs and sort.

       nfac1 = length(afac1);
       nfac2 = length(afac2);

       if (nfac1 > Stat.NLEVELMAX) {
         cat("ERROR: from Stat.plotSurvivalContingencyTable:\n");
         cat("factor tFac1 = ", tFac1, " has ", nfac1, "levels.\n", sep = "");
         cat("This is more than maximum allowed Stat.NLEVELMAX = ", Stat.NLEVELMAX, "\n", sep = "");
         stop();
       }
       # .....................................................................................



       # .................................................................................................
       # . Construct the plots here :
       # .................................................................................................
       nr = nfac1 + 1;    # Total number of rows in contingency table.
       nc = nfac2 + 1;    # Total number of columns in contingency table.       

       par(mfrow = c(nr, nc));
       # .................................................................................................
       # . Build the top nr rows, including right-hand margin cells :
       # .................................................................................................       
       for (i in 1:nfac1) {
         for (j in 1:nfac2) {
           # .............................................................................................
           # . Subset to this combination of factors then plot :
           # .............................................................................................
           dfBuf = dfA[(dfA[[tFac1]] == afac1[i]) & (dfA[[tFac2]] == afac2[j]), ];    

           capBuf = paste(afac1[i], "*", afac2[j], sep = "");
           SuperPcDiag.plotSurvivalOnBinary(at = dfBuf[[tTime]],
                                            as = dfBuf[[tCens]],
                                            abin = dfBuf[[tZ]],
                                            legend_0 = legend_0,
                                            legend_1 = legend_1,
                                            caption = capBuf,
                                            flagAll = FALSE);
           # ..............................................................................................
         }
         # ................................................................................................
         # . Build right-hand margin cell for this row :
         # ................................................................................................
         dfBuf = dfA[dfA[[tFac1]] == afac1[i], ];    

         capBuf = paste(afac1[i], "-all", sep = "");
         SuperPcDiag.plotSurvivalOnBinary(at = dfBuf[[tTime]],
                                          as = dfBuf[[tCens]],
                                          abin = dfBuf[[tZ]],
                                          legend_0 = legend_0,
                                          legend_1 = legend_1,
                                          caption = capBuf,
                                          flagAll = FALSE);
         # ................................................................................................
       }
       # .................................................................................................
       # . Build the bottom margin cells :
       # .................................................................................................       
       for (j in 1:nfac2) {
         # .............................................................................................
         # . Subset to this combination of factors then plot :
         # .............................................................................................
         dfBuf = dfA[dfA[[tFac2]] == afac2[j], ];    

         capBuf = paste(afac2[j], "-all", sep = "");
         SuperPcDiag.plotSurvivalOnBinary(at = dfBuf[[tTime]],
                                          as = dfBuf[[tCens]],
                                          abin = dfBuf[[tZ]],
                                          legend_0 = legend_0,
                                          legend_1 = legend_1,
                                          caption = capBuf,
                                          flagAll = FALSE);
         # ..............................................................................................
       }
       # ................................................................................................
       # . Build right-hand margin cell for this final row, which is just the grand total :
       # ................................................................................................
       dfBuf = dfA;

       capBuf = paste("all", sep = "");
       SuperPcDiag.plotSurvivalOnBinary(at = dfBuf[[tTime]],
                                        as = dfBuf[[tCens]],
                                        abin = dfBuf[[tZ]],
                                        legend_0 = legend_0,
                                        legend_1 = legend_1,
                                        caption = capBuf,
                                        flagAll = FALSE);
       # .................................................................................................
       # . Restore plot parameters :
       # .................................................................................................
       par(mfrow = c(1, 1));  
       # .....................................................................................              


       
       # .....................................................
       capBuf = paste(label1, " * ", label2, sep = "");

       if (nchar(captionEnd) > 0) {
         capBuf = paste(capBuf, " : ", captionEnd, sep = "");
       }
       
       title(sub = capBuf);
       # .....................................................



       # ...................................................................
       # . Build a table of counts with margins :
       # ...................................................................
       ff =  table(dfA[[tFac1]], dfA[[tFac2]]);
       ffM = addmargins(ff);
       # ...................................................................


       
       # .............
       return (ffM);
       # .............
       
}

# ===========================================================================================================
# . End fo Stat.plotSurvivalContingencyTable.
# ===========================================================================================================






# ======================================================================================================
# . Stat.barplotsBackToBack : displays for purpose of comparison two non-negative data series as barplots, 
# . -----------------------   with one on top and the other displayed in mirror image below. 
# .                           This will typically be used in comparing distribution functions.
# .
# . Syntax :
# .
# .           Stat.barplotsBackToBack(ak, ayTop, ayBot, ymax = NULL,
# .                                   captionTop, captionBot,
# .                                   legendTop, legendBot,
# .                                   colTop = 'blue', colBot = 'red',
# .                                   xlab, ylab, caption, ...);
# .
# . In :
# .
# .
# =======================================================================================================

Stat.barplotsBackToBack <- function(ak, ayTop, ayBot, ymax = NULL,
                                    captionTop = '', captionBot = '',
                                    legendTop = '', legendBot = '',
                                    colTop = 'blue', colBot = 'red',                                    
                                    xlab = '', ylab = '', caption = '', ...)
{

       # ....................................................................................
       # . Check input parameters :
       # ....................................................................................
       n = length(ak);               # Number of data elements.
       n1 = length(ayTop);
       n2 = length(ayBot);

       if (n1 != n) {
         cat("ERROR: from Stat.barplotsBackToBack:\n");
         cat("ayTop not same length as ak.\n");
         stop();
       }
       
       if (n2 != n) {
         cat("ERROR: from Stat.barplotsBackToBack:\n");
         cat("ayBot not same length as ak.\n");
         stop();
       }

       if (min(ayTop) < 0) {
         cat("ERROR: from Stat.barplotsBackToBack:\n");
         cat("ayTop has some negative elements.\n");
         stop();
       }

       if (min(ayBot) < 0) {
         cat("ERROR: from Stat.barplotsBackToBack:\n");
         cat("ayBot has some negative elements.\n");
         stop();
       }       
       # .....................................................................................



       # .....................................................................................
       # . Make the plot :
       # .....................................................................................
       Kmin = 1;
       Kmax = n;
       
       ym = max(ayBot, ayTop);

       if (!is.null(ymax)) {
         ym = ymax;
       }

       cex.main.OLD = par("cex.main");
       par(cex.main = 0.8);
       
       barplot(ayTop, names.arg = ak, 
               ylim = c(-ym, ym),
               xlab = xlab, ylab = ylab, 
               main = caption, col = colTop, ...);
       par(cex.main = cex.main.OLD);
       
       par(new = TRUE);
       ayBuf = - ayBot;                           # Flip for display.
       barplot(ayBuf, names.arg = ak, 
               ylim = c(-ym, ym),
               xlab = '', ylab = '', 
               main = "", col = colBot, ...);
       par(new = FALSE);

       legendText = c(legendTop, legendBot);
       colVector = c('blue', 'red');
       ltyVector = c('solid', 'solid');
       lwdVector = c(3, 3);

       xleg = Kmin - 1 + 0.9 * (Kmax - Kmin + 1);

       if ((nchar(legendTop) > 0) || (nchar(legendBot) > 0)) {
         legend(x = xleg, y = 0.8 * ym, legend = legendText,
                col = colVector, lty = ltyVector, lwd = lwdVector, bty = 'n');
       }

       xtext = Kmin - 1 + 0.45 * (Kmax - Kmin + 1);

       if ((nchar(captionTop) > 0) || (nchar(captionBot) > 0)) {       
         text(x = xtext, y = 0.9 * ym, captionTop);
         text(x = xtext, y = -0.9 * ym, captionBot);
       }
       # .....................................................................................       

       
       # ...........
       return (0);
       # ...........
       
}

# ===========================================================================================================
# . End fo Stat.barplotsBackToBack.
# ===========================================================================================================







# =======================================================================================================
# . Stat.pairs : interfacing for the standard 'pairs' function, which generates scatter plots for all
# . ----------   pairs of columns in the input matrix or data frame.
# .
# . Syntax :
# .
# .     Stat.pairs(x, caption, labels = colnames(x), flagAxes = FALSE, acol = NULL);
# .
# . In :
# .
# .     x = n * m input matrix or data frame. Each columns defines a variable.
# .         Thus a table with m * m panels will be drawn.
# .
# .     labels = names to give the column variables.
# .
# .     flagAxes = if TRUE, draw x = 0 and y = 0 axes.
# .
# .     acol = array of color values for the points. If NULL, all points black.
# .
# . NOTE: as of 3-6-2013, the colors are NOT NOT implemented yet.
# .
# ......................................................................................................
# . This generates :
# .     - scatter plots in upper triangle.
# .     - histograms on the diagonal.
# .     - text output of Pearson correlation coefficients on the lower diagonal.
# .
# =======================================================================================================

Stat.pairs <- function(x,
                       caption, labels = colnames(x),
                       flagAxes = FALSE, acol = NULL)
{

      # .................................................
      # . Set colors :
      # .................................................  
      if (is.null(acol)) {
        acolBuf = 'black';
      } else {
        acolBuf = acol;
      }
      # .................................................  

  
      # ..............................................................................
      # . Generate scatter plots :
      # . NOTE: as of 3-6-2013, the colors are NOT implemented yet.
      # . I must write this in at some point.
      # ..............................................................................
      if (!flagAxes) {
        pairs(x, labels = labels,
             diag.panel = Stat.panelHist,
             lower.panel = Stat.panelPearson,
             main = caption, pch = 19);
      } else {
        pairs(x, labels = labels,
              panel = Stat.panelScatter,
              diag.panel = Stat.panelHist,
              lower.panel = Stat.panelPearson,
              main = caption, pch = 19);
      }
      # ..............................................................................


      # ............
      return (0);
      # ............
      
}

# =======================================================================================================
# . End of Stat.pairs.
# =======================================================================================================




# =======================================================================================================
# . Stat.panelPearson : utility function for computing and graphically displaying Pearson correlation
# . -----------------   coefficient. Used in Stat.pairs().
# .
# =======================================================================================================

Stat.panelPearson <- function(x, y, ...)
{
  
    # ..................................................................................
    # . Compute association statistics :
    # ..................................................................................  
    r = cor(x, y, use = "pairwise.complete.obs");                # Pearson correlation.
    fitLm = lm(x ~ y);                                           # Linear regression.
    sumLm = summary(fitLm);                                      # Extract summaries.
    R2 = sumLm$r.square;                                         # Proportion of variance in y explained by model and x.
                                                                 # Actually, this is just Pearson r^2.
    sigma = sumLm$sigma;                                         # Noise sd in linear regression.
    
    acoef = sumLm$coefficients;
    a = acoef[1, 1];                                             # Intercept.
    b = acoef[2, 1];                                             # Slope.
    pval = acoef[2, 4];                                          # P-value.
    # ..................................................................................

    
    # ..................................................................................
    # . Display as text :
    # ..................................................................................      
    xp = 0.5 * (par("usr")[1] + par("usr")[2]);
    yp = 0.7 * (par("usr")[3] + par("usr")[4]);
    
    buf = paste("r = ", format(r, digits = 3), sep = "");
    buf = paste(buf, "\n",
                "R2 = ", format(R2, digits = 3), sep = "");
    buf = paste(buf, "\n",
                "sigma = ", format(sigma, digits = 3), sep = "");
    buf = paste(buf, "\n",
                "pval = ", sprintf("%8.2e", pval), sep = "");
    buf = paste(buf, "\n",
                "a = ", sprintf("%8.2e", a), sep = "");
    buf = paste(buf, "\n",
                "b = ", sprintf("%8.2e", b), sep = "");                
    
    text(xp, yp, buf);
    # ..................................................................................

    
    # ...........
    return (0);
    # ...........
   
}

# =======================================================================================================
# . End of Stat.panelPearson.
# =======================================================================================================



# =======================================================================================================
# . Stat.panelHist : utility function for graphically displaying a histogram of the input data.
# . --------------   Used in Stat.pairs().
# .
# =======================================================================================================

Stat.panelHist <- function(x, ...)
{
      usr <- par("usr"); 
      on.exit(par(usr));
      par(usr = c(usr[1:2], 0, 1.5) )
      h = hist(x, plot = FALSE, breaks = 50);
      breaks = h$breaks; 
      nB = length(breaks);
      y = h$counts; 
      y = y / max(y);

      rect(breaks[-nB], 0, breaks[-1], y, col="blue", ...);
}

# =======================================================================================================
# . End of Stat.panelHist.
# =======================================================================================================



# =======================================================================================================
# . Stat.panelScatter : utility function for generating a scatter plot, with x = 0 and y = 0 axes 
# . ----------------    included. Used in Stat.pairs().
# .
# =======================================================================================================

Stat.panelScatter <- function(x, y, ...)
{
      # ..........................
      points(x, y, ...);
      abline(h = 0, v = 0);
      # ..........................      

}

# =======================================================================================================
# . End of Stat.panelScatter.
# =======================================================================================================







# ========================================================================================================
# . Stat.basicLinearRegression : packaging of very basic, univariate linear regression.
# . --------------------------
# .
# . Syntax :
# .
# .          lr = Stat.basicLinearRegression(ax, ay);
# .
# . In :
# .          ax = vector of covariate (independent variable).
# .          ay = vector of dependent variable (length must be the same as ax).
# .
# . Out :
# .          lr = list with members as decribed in code.
# .
# ........................................................................................................
# . Details :
# . 
# .  * Estimates the parameters for the univariate linear regression model :
# .
# .         y = beta0  +  beta1 * x  +  eps ,
# .
# .  where : eps ~ N(0, sigma^2).
# .
# ========================================================================================================

Stat.basicLinearRegression <- function(ax, ay)
{

        # ......................................
        stopifnot(length(ay) == length(ax));
        # ......................................

      
        # ..................................................................          
        fitReg = lm(ay ~ ax);
        sumReg = summary(fitReg);

        buf = sumReg$coefficients;
        
        beta0 = sumReg$coefficients[1, 1];      # Intercept.
        sbeta0 = sumReg$coefficients[1, 2];     # s.e. in intercept.

        beta1 = sumReg$coefficients[2, 1];      # Slope.
        sbeta1 = sumReg$coefficients[2, 2];     # s.e. in slope.        
        
        sigma = sumReg$sigma;                  
        R2 = sumReg$r.squared;
        eps2 = 1 - R2;        
        pval = anova(fitReg)[1, 5];             # This selects for the P-value.

        ares = sumReg$residuals;                # Residuals.        
        # ..................................................................

        

        # ..................................................................
        # . Package results :
        # ..................................................................
        lr = list(beta0  = beta0 ,      # Intercept.
                  sbeta0 = sbeta0,      # s.e. in intercept.
                  beta1  = beta1 ,      # Slope,
                  sbeta1 = sbeta1,      # s.e. in slope.
                  sigma  = sigma ,      # Estimate of sdev of noise term.
                  R2     = R2    ,      # Fraction of variance explained by the model.
                  eps2   = eps2  ,      # Fraction of variance NOT explained by the model.
                  pval   = pval  ,      # P-value for model.
                  ares   = ares   );    # Residuals.
        # ..................................................................


        # ............
        return (lr);
        # ............

}

# ========================================================================================================
# . End of Stat.basicLinearRegression.
# ========================================================================================================





# ========================================================================================================
# . Stat.computeStatsOnBinned : compute statistics on binned data.
# . -------------------------
# .
# .  Syntax :
# .           sb = Stat.computeStatsOnBinned(ax, an, prob = 0.25);
# .
# .  In :
# .
# .         ax = values denoting centers of bins.
# .         an = array with integer count for each bin.
# .         prob = probability for confidence interval around median.
# .                0 <= prob <= 0.5.
# .
# . Out :
# .           sb = list, with stat members as defined below.
# .
# ========================================================================================================

Stat.computeStatsOnBinned <- function(ax, an, prob = 0.25)
{


    # ...................................................................
    stopifnot((prob >= 0.0) && (prob <= 0.5));
    # ...................................................................  


    # ...........................................................................................    
    ntot = sum(an);                                              # Total number of samples.
    xmean = sum(ax * an) / ntot;                                 # Mean.
    xvar = (1.0 / (ntot - 1)) * sum((ax - xmean)^2 * an);        # Variance.
    xsd = sqrt(xvar);                                            # Standard deviation.

    aq = cumsum(an) / ntot;                                      # Quantiles.
    prob1 = 1.0 - prob;
    iqlo = which.min(abs(aq - prob));                            # Index for lower quantile.
    iqmed = which.min(abs(aq - 0.50));                           # Index for median.
    iqhi = which.min(abs(aq - prob1));                           # Index for upper quantile..        

    xlo = ax[iqlo];                                              # First quartile.
    xmed = ax[iqmed];                                            # Median.
    xhi = ax[iqhi];                                              # Third quantile.
    # ...........................................................................................



    # ....................................................
    # . Package for output :
    # ....................................................
    sb = list(xmean = xmean,
              xvar = xvar,
              xsd = xsd,
              xlo = xlo,
              xmed = xmed,
              xhi = xhi);
    # ....................................................


    # ..............
    return (sb);
    # ..............

}

# ========================================================================================================
# . End of Stat.computeStatsOnBinned.
# ========================================================================================================





# ========================================================================================================
# . Stat.computeSFPOnBinaryDetectionTable : for a binary y = {0, 1} outcome and a binary x ={0, 1} 
# . -------------------------------------   predictor, with class estimator C(x) = x, computes
# .                                         i) confusion matrix, ii) P-value for significance of prediction,
# .                                         S, FP and FDR for prediction of y = 1 and y = 0 outcomes.
# .                                           
# .  Syntax :
# .
# .         sfp = Stat.computeSFPOnBinaryDetectionTable(ax, ay);
# .
# .  In :
# .
# .         ax = predictor values. Values must be {0, 1, NA}.
# .         ay = outcome values. Values must be {0, 1, NA}.
# .
# .         All NAs are removed. Only corresponding values of ax and ay which are neither NA are used.
# .
# . Out :
# .
# .           sfp = list, with stat members as defined below.
# .
# ========================================================================================================

Stat.computeSFPOnBinaryDetectionTable <- function(ax, ay)
{


      # .......................................
      stopifnot(length(ax) == length(ay));
      # .......................................


      # ..................................................................................
      # . Subset to matching non-NA values :
      # ..................................................................................            
      n = length(ax);
      
      mask = !is.na(ax) & !is.na(ay);

      if (sum(mask) == 0) {
        cat("ERROR: from Stat.computeSFPOnBinaryDetectionTable:\n");
        cat("No matching non-NA values for ax and ay.\n");
        stop();
      }
      
      axb = ax[mask];
      ayb = ay[mask];

      nb = length(axb);
      # ..................................................................................


     
      
      # ..................................................................................
      # . Check for binary values :
      # ..................................................................................                   
      msg = Stat.checkBinary(axb);

      if (msg != 'ok') {
        cat("ERROR: from Stat.computeSFPOnBinaryDetectionTable:\n");
        cat("ax has some non 0, 1 values.\n");
        cat(msg, "\n", sep = "");
        stop();
      }

      msg = Stat.checkBinary(ayb);

      if (msg != 'ok') {
        cat("ERROR: from Stat.computeSFPOnBinaryDetectionTable:\n");
        cat("ay has some non 0, 1 values.\n");
        cat(msg, "\n", sep = "");
        stop();
      }
      # ..................................................................................


      
      # ..................................................................................
      # . Build the 2 X 2 table, perform Fisher exact test :
      # ..................................................................................      
      ff1 = table(ayb, axb);             # Confusion matrix: input class * output class.
      ff1M = addmargins(ff1);          # Add margins.
      
      ft = fisher.test(ff1);
      pval = ft$p.value;
      # ..................................................................................


      
      # ..................................................................................
      # . Compute S, FP and FDR for each outcome category separately :
      # .
      # . For input class 1:
      # ..................................................................................
      S1 = ff1M[2, 2] / ff1M[2, 3];
      FP1 = ff1M[1, 2] / ff1M[1, 3];
      FDR1 = ff1M[1, 2] / ff1M[3, 2];
      # ..................................................................................      
      # . For input class 0:
      # ..................................................................................
      S0 = ff1M[1, 1] / ff1M[1, 3];
      FP0 = ff1M[2, 1] / ff1M[2, 3];
      FDR0 = ff1M[2, 1] / ff1M[3, 1];
      # ..................................................................................      
      # . Overall error :
      # ..................................................................................
      errRate = (ff1M[1, 2] + ff1M[2, 1]) / ff1M[3, 3];
      # ..................................................................................



      # ..................................................................................
      # . Text output summary :
      # ..................................................................................
      buf = "";
      buf = paste(buf, "pval = ", sprintf("%10.3e", pval), "\n", sep = "");
      buf = paste(buf, "S1 = ", format(S1, digits = 5), "\n", sep = "");
      buf = paste(buf, "FP1 = ", format(FP1, digits = 5), "\n", sep = "");
      buf = paste(buf, "FDR1 = ", format(FDR1, digits = 5), "\n", sep = "");
      buf = paste(buf,"S0 = ", format(S1, digits = 5), "\n", sep = "");
      buf = paste(buf, "FP0 = ", format(FP1, digits = 5), "\n", sep = "");
      buf = paste(buf, "FDR0 = ", format(FDR1, digits = 5), "\n", sep = "");
      buf = paste(buf, "errRate = ", format(errRate, digits = 5), "\n", sep = "");
      
      txtSum = buf;
      # ..................................................................................      

      


      # ...........................................................
      # . Package output :
      # ...........................................................
      sfp = list(pval = pval,
                 ff1M = ff1M,
                 S1 = S1,
                 FP1 = FP1, 
                 FDR1 = FDR1,
                 S0 = S0,
                 FP0 = FP0,
                 FDR0 = FDR0,
                 errRate = errRate,
                 txtSum = txtSum);
      # ...........................................................



      # ...................
      return (sfp);
      # ...................  
        
}

# ========================================================================================================
# . End of Stat.computeSFPOnBinaryDetectionTable.
# ========================================================================================================





# =========================================================================================================
# . Stat.binormalModelROC : computes the theoretical properties of detection of occurrence of a binary
# . ---------------------   response, given a binormal model for the distributions.
# .
# . Syntax :
# .
# .     bn = Stat.binormalModelROC(mu0, sigma0, mu1, sigma1, pi1, n, FDR0);
# .
# . In :
# .
# .           mu0 = mean for predictor for class 0.
# .        sigma0 = sd for predictor for class 0.
# .           mu1 = mean for predictor for class 1.
# .        sigma1 = sd for predictor for class 1.
# .           pi1 = a priori probability of class 1 (pi0 = 1 - pi1) (for FDR calculations).
# .             n = total number of sample considered (for confidence interval calculation on
# .                 a finite sample).
# .          FDR0 = FDR for computing the corresponding threshold on x, and the resulting sensitivity
# .                 and total fraction of instances selected.
# .          beta = weight to be given to FALSE NEGATIVES in objective function for optimizing threshold.
# .                 0 <= beta <= 1. A value of beta = 1/2 means equal weight are given to false positives
# .                 and false-negatives.
# .
# ........................................................................................................
# . * Details :
# .
# . The objective function used is :
# .
# .     phi(x) = (1 - beta) . pi . Fp(x)  +  beta . pi1 . S(x)
# .                             0
# .
# . with the optimal decision threshold given by :
# .
# .            x    = argmin phi(x)
# .             opt     x
# .
# =========================================================================================================

Stat.binormalModelROC <- function(mu0, sigma0, mu1, sigma1, pi1, n, FDR0, beta = 0.5)
{

       # ........................................................
       stopifnot(pi1 > 0, pi1 < 1);
       stopifnot(beta >= 0, beta <= 1);       
       # ........................................................


       # .......................................................................................
       # . Define a range for the numerical computations :
       # .......................................................................................
       zm = 4.0;
       
       xlo = min(mu0 - zm * sigma0, mu1 - zm * sigma1);
       xhi = max(mu0 + zm * sigma0, mu1 + zm * sigma1);
       # .......................................................................................
       # . Generate sensitivity and FP profiles :
       # .......................................................................................
       pi0 = 1.0 - pi1;
       NP = 500;                                                              # Number of points.
       
       ax = seq(from = xlo, to = xhi, length.out = NP);

       aS = pnorm(ax, mean = mu1, sd = sigma1, lower.tail = FALSE);           # Sensitivity.
       aFP = pnorm(ax, mean = mu0, sd = sigma0, lower.tail = FALSE);          # False-positive rate.
       aFDR = (pi0 * aFP) / (pi0 * aFP + pi1 * aS);                           # FDR.
       aFT = pi0 * aFP + pi1 * aS;                                            # Fraction of total.
       # .......................................................................................
       # . Numerically compute the AUC :
       # .......................................................................................
       NP1 = NP - 1;
       afBuf = aFP[2:NP] - aFP[1:NP1];
       asBuf = 0.5 * (aS[1:NP1] + aS[2:NP]);

       AUCnum = - sum(afBuf * asBuf);                                      # AUC numerical integration.
       # .......................................................................................
       # . Find the sensitivity and total fraction selected at a given FDR :
       # .......................................................................................
       ic = min(which(aFDR < FDR0));

       x0 = ax[ic];                       # Threshold.
       S0 = aS[ic]
       FP0 = aFP[ic]
       FT0 = aFT[ic];

       FDRall = pi0;                      # FDR if there is no selction based on predictor (all chosen).
       # .......................................................................................
       # . Utility function : here I assume that the cost of treating a non-responding patient
       # . is the same as the cost of NOT treating a responding patient.
       # .......................................................................................
       beta1 = 1.0 - beta;
       aPhi = beta1 * pi0 * aFP + beta * pi1 * (1.0 - aS);

       icOpt = which.min(aPhi);

       xOpt = ax[icOpt];
       SOpt = aS[icOpt]
       FPOpt = aFP[icOpt]
       FDROpt = aFDR[icOpt]
       FTOpt = aFT[icOpt];
       # .......................................................................................


       # .......................................................................................
       # . Also check the analystic formula :
       # .......................................................................................       
       temp1 = (mu1 - mu0) / sqrt(sigma1^2 + sigma0^2);
       AUCtheo = pnorm(temp1, lower.tail = TRUE);                        # AUC analytic estimate.
       # .......................................................................................

       
       # .......................................................................................
       # . Use some other formulas for estimated sampling confidence interval :
       # .......................................................................................
       n0 = n * pi0;       
       n1 = n * pi1;
       
       roc = Stat.aucROCTest(AUCnum, n0, n1, prob = 0.95);
       # .......................................................................................


       # .......................................................................................
       # . Package the results :
       # .......................................................................................
       bn = list(mu0 = mu0,                       # Input value, mean(x) for class 0.
                 sigma0 = sigma0,                 # Input value, sd(x) for class 0.
                 mu1 = mu1,                       # Input value, mean(x) for class 1.
                 sigma1 = sigma1,                 # Input value, sd(x) for class 1.
                 pi1 = pi1,                       # Input prior for class 1.
                 AUCnum = AUCnum,                 # Resulting AUC (numerical calculation).
                 AUCtheo = AUCtheo,               # Resulting AUC (theroretical calculation, = numerical).
                 AUCLo = roc$ALo,                 # 95% CI lower bound estimate on AUC.
                 AUCHi = roc$AHi,                 # 95% CI upper bound estimate on AUC.
                 x0 = x0,                         # Decision threshold (C(x) = 1 if x >= x0) for FDR = FDR0.
                 S0 = S0,                         # Sensitivity for FDR = FDR0.
                 FP0 = FP0,                       # False-positive rate for FDR = FDR0.         
                 FDR0 = FDR0,                     # Input (fixed) FDR = FDR0.
                 FDRall = FDRall,                 # FDR that would obtain if ALL samples were retained (= pi0).
                 FT0 = FT0,                       # Fraction of all samples retained for x >= x0.
                 beta = beta,                     # beta = penalty term for false-negatives (and 1 - beta is the panelty for false-positives).
                 xOpt = xOpt,                     # Optimal decision threshold for given objective function.
                 SOpt = SOpt,                     # Sensitivity for optimal decision threshold.
                 FPOpt = FPOpt,                   # False-positive rate for optimal decision threshold.
                 FDROpt = FDROpt,                 # FDR for optimal decision threshold.
                 FTOpt = FTOpt);                  # Fraction of all samples retained for x >= xOpt.
       # .......................................................................................


       # .............
       return (bn);
       # .............
       
}

# =========================================================================================================
# . End of Stat.binormalModelROC.
# =========================================================================================================





# =========================================================================================================
# . Stat.plotAUCnomogram : rather trivial utility function for plotting AUCs as points with 
# . --------------------   horizontal confidence intervals.
# .
# . Syntax :
# .
# .    Stat.plotAUCnomogram(auc, aucLo, aucHi, apval = NULL, alab, caption = '');
# .
# . In :
# .
# .       auc = array of AUC values.
# .     aucLo = array of lower CI bound for AUC values.
# .     aucHi = array of upper CI bound for AUC values.
# .      alab = array of labels for each AUC.
# .   caption = overall caption for plot.
# .
# =========================================================================================================

Stat.plotAUCnomogram <- function(auc, aucLo, aucHi, apval = NULL, alab, caption = '')
{

    # ................................................................................
    L = length(auc);                         # Number of AUCs to be displayed.

    stopifnot(length(aucLo) == L);
    stopifnot(length(aucHi) == L);
    stopifnot(length(alab) == L);

    if (!is.null(apval)) {
      stopifnot(length(apval) == L);
    }

    xmin = min(0.2, min(aucLo));
    # ................................................................................
              
  
    # ................................................................................
    # .  Make a box with no tick marks on the y axis.
    # ................................................................................
    plot(1, xlim = c(xmin, 1),
         ylim = c(0, 1),
         col = 'white',
         xlab = 'AUC',
         ylab = '',
         yaxt = "n",
         main = caption);

    abline(v = 0.5, col = 'gray');
    # ................................................................................


    # ................................................................................
    dq = 1.0 / (L + 1);

    xtemp = min(aucLo);
    if (xmin < xtemp) {
      xt = 0.5 * (xmin + xtemp);
    } else {
      xt = xmin;
    }
    
    for (j in 1:L) {
      y = (L - j + 1) * dq;                              # Star from the top.
      lines(c(aucLo[j], aucHi[j]), c(y, y), lwd = 2);
      points(auc[j], y, pch = 19, lwd = 6);

      temp1 = alab[j];
      
      if (!is.null(apval)) {
        temp1 = paste(alab[j], ": P = ", sprintf("%8.1e", apval[j]), sep = "");
      }
      
      text(xt, y, temp1, cex = 0.7);
    }
    # ..............................................................................................


    # ............
    return (0);
    # ............


}  

# =========================================================================================================
# . End of Stat.plotAUCnomogram.
# =========================================================================================================



# =========================================================================================================
# . Stat.AUCpowerAnalysis : does a power analysis based on AUC, using normal sampling distribution 
# . ---------------------   approximation for the AUC. Generates a plot of confidence intervals for the 
# .                         range studied.
# . Syntax :
# .
# .    Stat.AUCpowerAnalysis(AUC1, AUC0, pi1, alpha, beta, nlo, nhi);
# .
# . In :
# .
# .      AUC1 = AUC under H1.
# .      AUC0 = AUC under H0.
# .       pi1 = prior probability for class 1 in sample set.
# .     alpha = one-sided significance level for rejecting H0.
# .      beta = power for accepting H1.
# .  nlo, nhi = range for total number of instances (total number of patients) in a given set.
# .
# =========================================================================================================

Stat.AUCpowerAnalysis <- function(AUC1, AUC0, pi1, alpha, beta, nlo, nhi)
{

       # ..........................................
       stopifnot(pi1 > 0, pi1 < 1);
       stopifnot(AUC0 > 0, AUC0 < 1);
       stopifnot(AUC1 > 0, AUC1 < 1);
       stopifnot(alpha > 0, alpha < 1);
       stopifnot(beta > 0, beta < 1);
       stopifnot(nlo <= nhi);
       # ..........................................


       
       # .........................................................................................................
       # . Set general variables :
       # .........................................................................................................
       an = nlo:nhi;                       # Total number of samples.
       L = length(an);
       pi0 = 1.0 - pi1;                    # Prior for class 0.
       # .........................................................................................................
       # . Generate bounds for H1 : AUC = 0.8
       # . We want the bounds to correspond to the 0.6 CI, so that each tail contains just 0.2 prob. measure.
       # .........................................................................................................
       probBeta = 1 - 2 * min(beta, 1.0 - beta);
       aroc1 = sapply(1:L, function(j){buf = Stat.aucROCTest(AUC1, n1 = an[j] * pi0, n2 = an[j] * pi1, prob = probBeta);
                                      buf$n = an[j]; return (buf); })
       aroc1 = t(aroc1);
       aroc1 = as.data.frame(apply(aroc1, 2, unlist));
       # .........................................................................................................
       # . Generate bounds for H0 : AUC = 0.7
       # . We want the bounds to correspond to the 0.8 CI, so that each tail contains just 0.1 prob. measure.
       # .........................................................................................................
       probAlpha = 1.0 - 2 * alpha;
       aroc0 = sapply(1:L, function(j){buf = Stat.aucROCTest(AUC0, n1 = an[j] * pi0, n2 = an[j] * pi1, prob = probAlpha);
                                      buf$n = an[j]; return (buf); })
       aroc0 = t(aroc0);
       aroc0 = as.data.frame(apply(aroc0, 2, unlist));
       # .........................................................................................................
       # . Find the intersection point :
       # .........................................................................................................
       imin = which.min(abs(aroc1$ALo - aroc0$AHi));
       nmin = aroc1$n[imin];
       # .........................................................................................................
       # . Plot H0 and H1 distributions :
       # .........................................................................................................
       ymin = min(0.4, c(aroc1$ALo, aroc0$ALo));
       ymax = max(c(aroc1$AHi, aroc0$Ahi));

       caption = paste('AUC power analysis: alpha = ', alpha, 
                       ' , beta = ', beta, 
                       ' , nmin = ', nmin, sep = "");

       cex.main.OLD = par("cex.main");
       par(cex.main = 1.0);
       plot(aroc1$n, aroc1$A, type = 'l', lty = 'dashed',
            xlim = c(0, max(an)), 
            ylim = c(ymin, ymax),
            main = caption,
            xlab = 'Total number of patients',
            ylab = 'AUC');
        par(cex.main = cex.main.OLD);

       lines(aroc1$n, aroc1$ALo, type = 'l');
       lines(aroc1$n, aroc1$AHi, type = 'l');

       lines(aroc0$n, aroc0$A, type = 'l', col = 'red', lty = 'dashed');
       lines(aroc0$n, aroc0$ALo, type = 'l', col = 'red');
       lines(aroc0$n, aroc0$AHi, type = 'l', col = 'red');

       abline(h = 0.5, col = 'gray');
       abline(v = nmin, col = 'gray');
       # ............................................................
       # . Add legend :
       # ............................................................
       temp0 = paste('H0: AUC = ', AUC0, sep ="");
       temp1 = paste('H1: AUC = ', AUC1, sep ="");
       legendText = c(temp1, temp0);
       colVector = c('black', 'red');
       ltyVector = c(1, 1);
       lwdVector = c(1, 1);
       pchVector = rep(19, times = 2);

       legend(x = 0, y = 0.5,
              legend = legendText, 
              col = colVector, 
              lty = ltyVector, 
              lwd = lwdVector,
              bty = 'n');
       # .........................................................................................................


       # ...............
       return (nmin);
       # ...............
  
}

# =========================================================================================================
# . End of Stat.AUCpowerAnalysis.
# =========================================================================================================




# ========================================================================================================================
# . Stat.powerAnalysisForCorrelation : for two random variables, computes the number of samples required to distinguish 
# . --------------------------------   two hypotheses of association between them, as specified by the R2 value, 
# .                                    for given confidence level alpha and power of detection beta.
# .
# . Syntax :
# .
# .       n = Stat.powerAnalysisForCorrelation(R20, R21, alpha, beta);
# .
# . In :
# .
# .        R20 = R2 value for hypothesis H0. We must have R20 >= 0.
# .        R21 = R2 value for hypothesis H1. We must have R21 > R20.
# .      alpha = one-sided significance level for rejecting H0.
# .       beta = desired power of detection of H1.
# .
# . Out :
# .
# .          n = number of samples required for achieving power beta.
# .........................................................................................................................
# . Note: This version uses Fisher's z-transformation of the Pearson correlation coefficient and its concomitant
# . approximately normal distribution. Thus if :
# .
# .                  -1 
# .          z = tanh  (r)
# .
# . then :
# .                   -1
# .         z ~ N(tanh  (rho), 1 / (n - 3))
# .
# . where rho = true correlation coeffcient.
# .
# . Under this approximation, the expression for n, the number of samples required to achieve detection power of H1 of beta
# . under confidence level alpha is then given by :
# .
# .                                               2
# .                        /   z       + z       \ 
# .                        |    alpha     beta   |
# .               n = 3 +  | ------------------- |
# .                        |    mu    -  mu      |
# .                        \      1        0     /
# .
# . where z_alpha = one-sided distance for confidence level alpha (z_alpha = 1.644 for alpha = 0.05), and z_beta
# . distance for power beta (z_beta = 0.841 for beta = 0.8), and where :
# .
# .                 -1             -1     1/2
# .      mu   = tanh  (rho ) = tanh   ( R2    )
# .        k              k               k
# .
# =========================================================================================================================

Stat.powerAnalysisForCorrelation <- function(R20, R21, alpha, beta)
{

     # ........................................................
     stopifnot(R20 >= 0.0);
     stopifnot(R21 >= R20);
     stopifnot(alpha > 0, alpha < 1);
     stopifnot(beta > 0, beta < 1);
     # ........................................................  


     
     # ............................................................
     # . Apply the Fisher z-transformation and subsequent
     # . approximations.
     # ............................................................
     r0 = sqrt(R20);
     r1 = sqrt(R21);

     z0 = atanh(r0);
     z1 = atanh(r1);

     zalpha = qnorm(alpha, lower.tail = FALSE);
     zbeta = qnorm(beta);
     
     n = 3 + ((zalpha + zbeta) / (z1 - z0))^2;
     # ............................................................



     # ...........
     return(n);
     # ...........

}

# ========================================================================================================================
# . End of Stat.powerAnalysisForCorrelation.
# ========================================================================================================================




# ========================================================================================================================
# . Stat.powerCurveForCorrelation : computes the curve of power versus R2 for detection of bivariate correlation 
# . -----------------------------   characterized by R2 = rho^2, for fied number of samples and given one-sided
# .                                 confidence level alpha.
# .
# . Syntax :
# .
# .      pw = Stat.powerCurveForCorrelation(n, alpha = 0.05, flagPlot = TRUE);
# .
# . In :
# .          n = number of samples.
# .      alpha = alpha for one-side confidence level against H0.
# .   flagPlot = if TRUE, generate a plot of the power curve.
# . 
# . Out :
# .
# .  pw = list, with members :
# .
# .        ar2 = array of avlues of R2 in interval 0 <= R2 < 1 (increment 0.01).
# .       apow = corersponding values for power.
# .
# .........................................................................................................................
# . Note: This version uses Fisher's z-transformation of the Pearson correlation coefficient and its concomitant
# . approximately normal distribution. Thus if :
# .
# .                  -1 
# .          z = tanh  (r)
# .
# . then :
# .                   -1
# .         z ~ N(tanh  (rho), 1 / (n - 3))
# .
# . where rho = true correlation coeffcient.
# .
# . * If rho1 is the true correlation coefficient of two co-variates, the power P for detecting H1: rho = rho1 against
# . H0: rho = 0, is given by :
# .
# .                        1/2       -1
# .       P = pnorm( (n - 3)  .  tanh  (rho1)  - z       , lower.tail = TRUE);
# .                                               alpha
# .
# ,
# . where z       =  qnorm(alpha, lower.tail = FALSE);
# .        alpha
# . 
# =========================================================================================================================

Stat.powerCurveForCorrelation <- function(n, alpha = 0.05, flagPlot = TRUE)
{


   # .................................................................................
   # . Check on values :
   # .................................................................................
   if (n <= 3) {
     cat("ERROR: from Stat.powerCurveForCorrelation:\n");
     cat("n = ", n, " is not valid. We must have n > 3.\n", sep = "");
     stop();
   }

   stopifnot(alpha > 0.0, alpha < 1.0);
   stopifnot(is.logical(flagPlot));
   # .................................................................................  


   # .................................................................................
   # . Generate an array of p
   # .................................................................................
   zalpha = qnorm(alpha, lower.tail = FALSE);

   ar2 = seq(from = 0.0, to = 0.999, by = 0.01);       # Range of values of R2.
   arho = sqrt(ar2);                                   # Corresponding values of rho.

   ad = sqrt(n - 3) * atanh(arho) - zalpha;            # Difference.
   apow = pnorm(ad, lower.tail = TRUE);                # The power.
   # .................................................................................


   
   # .................................................................................
   # . Plot the results if requested :
   # .................................................................................
   if (flagPlot) {
     caption = paste('Power of detection of correlation:  n = ', n, ' alpha = ', alpha, sep = "");
     plot(ar2, apow, type = 'l', lwd = 2,
          xlim = c(0, 1), ylim = c(0, 1),
          xlab = 'R2', ylab = 'power', 
          main = caption);
     # ...............................................................................
     # . Add some common reference lines :
     # ...............................................................................
     abline(v = 0.25, lty = 'dashed');
     abline(v = 0.5, lty = 'dashed');
     abline(v = 0.8, lty = 'dashed');
     abline(v = 0.95, lty = 'dashed');
     abline(h = 0.8, lty = 'dashed', col = 'red');
     # ...............................................................................
   }
   # .................................................................................



   # .................................................
   # . Package the results :
   # .................................................
   pw = list(ar2 = ar2, apow = apow);
   # .................................................


   # .............
   return (pw);
   # .............


}

# ========================================================================================================================
# . End of Stat.powerCurveForCorrelation.
# ========================================================================================================================


   

# ========================================================================================================================
# . Stat.computeBinormalAUC : returns AUC = P(x2 > x1) assuming a binormal model. Takes as input measn and standard
# . -----------------------   deviations of the distributions for the two populations.
# .
# . Syntax :
# .
# .        auc = Stat.computeBinormalAUC(mu1, sigma1, mu2, sigma2);
# .
# . In :
# .
# .        mu1 = array of means for population 1
# .     sigma1 = array of sd's for population 1.
# .
# .        mu2 = array of means for population 2.
# .     sigma2 = array of sd's for population 2.
# .
# . Out :
# .
# .       auc = array of corresponding values of the AUC = Prob(x2 > x1) for independent samplings of the two
# .             populations.
# .
# .........................................................................................................................
# . The calculation uses the analytic formula :
# .    
# .                     mu2  -  mu1
# .    AUC = pnorm( -------------------   , lower.tail = TRUE);
# .                       2        2  1/2
# .                 (sigma  + sigma  )
# .                       2        1
# .
# ========================================================================================================================

Stat.computeBinormalAUC <- function(mu1, sigma1, mu2, sigma2)
{

     # .................................................................
     sigma = sqrt(sigma1 * sigma1 + sigma2 * sigma2);
     Dmu = mu2 - mu1;

     xi = ifelse(sigma > 0.0, Dmu / sigma, 0.0);
     valEx = ifelse(Dmu > 0, 1, ifelse(Dmu < 0, 0, 0.5));

     auc = ifelse(sigma > 0, pnorm(xi, lower.tail = TRUE), valEx);
     # .................................................................


     # .............
     return (auc);
     # .............  

}

# ========================================================================================================================
# . End of Stat.computeBinormalAUC.
# ========================================================================================================================



# ========================================================================================================================
# . Stat.computeEmpiricalAUC : returns AUC = P(x2 > x1), given two empirical distributions.
# . ------------------------   
# .
# . Syntax :
# .
# .        ra = Stat.computeEmpiricalAUC(ax1, ax2, prob = 0.95);
# .
# . In :
# .
# .        ax1 = array of values for population 1
# .        ax2 = array of values for population 2.
# .       prob = specification for confidence interval.
# .
# . Out :
# .
# .      ra = list, with members :
# .
# .         auc = AUC = Prob(x2 > x1) for independent samplings of the two populations.
# .         aucLo = lower bound of CI.
# .         aucHi = upper bound of CI.
# .
# .........................................................................................................................
# . The calculation uses the analytic formula :
# .
# .                      U
# .                       2
# .             AUC = --------
# .                    n1 . n2
# .
# .  where U2 is the Wilcoxon rank-sum statistic.
# .
# .  An approximation to the standard error is given by :
# .
# .
# .            2    (n1 + n2 + 1)
# .      sigmaA  =  ------------- A . (1 - A)
# .                   3 n1 . n2
# .
# . where A = AUC.
# .
# .  See function Stat.aucROCTest() for more details.
# .
# .  Note that U2 is the same as the statistic returned by wilcox.test():
# .
# .        buf = wilcox.test(ax2, ax1);
# .        W = buf$statistic;
# .
# ========================================================================================================================

Stat.computeEmpiricalAUC <- function(ax1, ax2, prob = 0.95)
{

     # .............................................
     stopifnot((prob > 0.0) && (prob < 1.0));
     # .............................................
     

     # .................................................................
     n1 = length(ax1);
     n2 = length(ax2);
     
     n = n1 + n2;
     n11 = n1 + 1;
     
     ar = rank(c(ax1, ax2));
     U2 = sum(ar[n11:n]) - 0.5 * n2 * (n2 + 1);

     #xx buf = wilcox.test(ax2, ax1);                   # Comparison
     #xx W = buf$statistic;                             # for debugging.
     
     auc = U2 / (n1 * n2);
     # .................................................................


     
     # .................................................................
     # . Compute the approximation to the standard error :
     # .................................................................
     sigA = sqrt(((n + 1.0) / (3.0 * n1 * n2)) * auc * (1.0 - auc));
     
     zc = qnorm(0.5 * (1.0 - prob), lower.tail = FALSE);
     dA = zc * sigA;

     aucLo = auc - dA;
     aucLo = ifelse(aucLo > 0.0, aucLo, 0.0);
     aucHi = auc + dA;
     aucHi = ifelse(aucHi < 1.0, aucHi, 1.0);
     # .................................................................


     
     # .....................................................
     # . Package results :
     # .....................................................
     ra = list(auc = auc, aucLo = aucLo, aucHi = aucHi);
     # .....................................................
     

     # .............
     return (ra);
     # .............  

}

# ========================================================================================================================
# . End of computeEmpiricalAUC.
# ========================================================================================================================





# ========================================================================================================================
# . Stat.computeEmpiricalAUCParallel : returns AUC = P(x2 > x1), given two empirical distributions.
# . --------------------------------   This is a 'parallelized' version that works on the rows of two input data frames.
# .
# . Syntax :
# .
# .        auc = Stat.computeEmpiricalAUCParallel(dfX1, dfX2);
# .
# . In :
# .
# .        dfX1 = data frame for population 1. Each row has an array of values for population 1
# .        dfX2 = data frame for population 2. Each row has the corersponding array of values for population 2.
# .               The number of rows must be the same.
# .        prob = specification for confidence interval.
# .
# . Out :
# .
# .      ra = list, with members :
# .
# .           auc = AUC = Prob(x2 > x1) for independent samplings of the two populations.
# .         aucLo = lower bound of CI.
# .         aucHi = upper bound of CI.
# .
# .         These are all vectors with length =  number of rows in dfX1 or dfX2.
# .
# .........................................................................................................................
# . The calculation uses the analytic formula :
# .
# .                      U
# .                       2
# .             AUC = --------
# .                    n1 . n2
# .
# .  where U2 is the Wilcoxon rank-sum statistic.
# .
# .  An approximation to the standard error is gievn by :
# .
# .
# .            2    (n1 + n2 + 1)
# .      sigmaA  =  ------------- A . (1 - A)
# .                   3 n1 . n2
# .
# .  where A = AUC.
# .
# .  See function Stat.aucROCTest() for more details.
# .
# .  Note that U2 is the same as the statistic returned by wilcox.test():
# .
# .        buf = wilcox.test(ax2, ax1);
# .        W = buf$statistic;
# .
# ========================================================================================================================

Stat.computeEmpiricalAUCParallel <- function(dfX1, dfX2, prob = 0.95)
{

     # ........................................
     stopifnot(nrow(dfX1) == nrow(dfX2));
     stopifnot((prob > 0.0) && (prob < 1.0));     
     # ........................................

     
     # .................................................................
     n1 = ncol(dfX1);
     n2 = ncol(dfX2);
     
     n = n1 + n2;
     n11 = n1 + 1;

     dfR = t(apply(cbind(dfX1, dfX2), 1, rank));
     U2 = apply(dfR[ , n11:n], 1, sum) - 0.5 * n2 * (n2 + 1);
     
     auc = U2 / (n1 * n2);
     # .................................................................


     
     # .................................................................
     # . Compute the approximation to the standard error :
     # .................................................................
     sigA = sqrt(((n + 1.0) / (3.0 * n1 * n2)) * auc * (1.0 - auc));
     
     zc = qnorm(0.5 * (1.0 - prob), lower.tail = FALSE);
     dA = zc * sigA;

     aucLo = auc - dA;
     aucLo = ifelse(aucLo > 0.0, aucLo, 0.0);
     aucHi = auc + dA;
     aucHi = ifelse(aucHi < 1.0, aucHi, 1.0);
     # .................................................................
     

     # .....................................................
     # . Package results :
     # .....................................................
     ra = list(auc = auc, aucLo = aucLo, aucHi = aucHi);
     # .....................................................
     

     # .............
     return (ra);
     # .............  

}

# ========================================================================================================================
# . End of computeEmpiricalAUCParallel.
# ========================================================================================================================







# ========================================================================================================================
# . Stat.computePvalOnR : computes the P-value corresponding to a given Pearson correlation coefficient
# . -------------------   and number of samples.
# .
# . Syntax :
# .
# .           pval = Stat.computePvalOnR(r, n);
# .
# . In :
# .           r = Pearson correlation coeffient, -1 < r < 1.
# .           n = number of samples (the degrees of freedom for the claculation are then nu = n - 2.
# .
# . Out :
# .
# .           pval = P-value, computed with a two-sided test using the statistic :
# .
# .                             1/2      r
# .                  xi = (n - 2)   ------------
# .                                       2  1/2
# .                                 (1 - r  )
# .
# .                  which under H0 has a Student-t distribution with nu = n - 2 degrees of freedom.
# .
# ========================================================================================================================

Stat.computePvalOnR <- function(r, n)
{

     # ....................
     stopifnot(n > 2);
     # ....................
     
  
     # .............................................................................
     nu = n - 2;
     fac1 = sqrt(nu);

     xi = fac1 * r / sqrt(1.0 - r^2);
     pvalUp = pt(xi, df = nu, lower.tail = FALSE);
     pvalLo = pt(xi, df = nu, lower.tail = TRUE);

     pval = ifelse(pvalUp < 0.5, 2 * pvalUp, 2 * pvalLo);
     # .............................................................................


     # ...............
     return (pval);
     # ...............

}

# ========================================================================================================================
# . End of Stat.computePvalOnR.
# ========================================================================================================================



# ========================================================================================================================
# . Stat.computePvalOnRMatrix : computes the P-value corresponding to a given Pearson correlation coefficient
# . -------------------------   and number of samples. Same as Stat.computePvalOnR(), but takes as argumenta
# .                             rectabgukar matrices for both r and n.
# . Syntax :
# .
# .           pval = Stat.computePvalOnRMatrix(r, n);
# .
# . In :
# .           r = matrix of Pearson correlation coeffient, -1 < r < 1.
# .           n = matrix of number of samples (the degrees of freedom for the calculation are then nu = n - 2).
# .               Note that the numbers of rows and columns must match in r an n.
# .
# . Out :
# .
# .           pval = matrix of P-values, computed with a two-sided test using the statistic :
# .
# .                             1/2      r
# .                  xi = (n - 2)   ------------
# .                                       2  1/2
# .                                 (1 - r  )
# .
# .                  which under H0 has a Student-t distribution with nu = n - 2 degrees of freedom.
# .
# ========================================================================================================================

Stat.computePvalOnRMatrix <- function(r, n)
{

     # ........................................................
     stopifnot(nrow(n) == nrow(r));
     stopifnot(ncol(n) == ncol(r));     
     stopifnot(min(n) > 2);
     # ........................................................
     
  
     # .............................................................................
     nu = n - 2;
     fac1 = sqrt(nu);

     xi = fac1 * r / sqrt(1.0 - r^2);
     pvalUp = pt(xi, df = nu, lower.tail = FALSE);
     pvalLo = pt(xi, df = nu, lower.tail = TRUE);

     pval = ifelse(pvalUp < 0.5, 2 * pvalUp, 2 * pvalLo);
     # .............................................................................


     # ...............
     return (pval);
     # ...............

}

# ========================================================================================================================
# . End of Stat.computePvalOnRMatrix.
# ========================================================================================================================






# ========================================================================================================================
# . Stat.computePvalCutoffOnFDR : computes the P-value threshold necessary for attaining a given FDR.
# . ---------------------------   
# .
# . Syntax :
# .
# .          tc = Stat.computePvalCutoffOnFDR(apval, FDR0);
# .
# . In :
# .           apval = array of P-values.
# .            FDR0 = FDR threshold.
# .
# . Out :
# .          tc = list, with members :
# .
# .               P0 = largest threshold P0, with P <= P0 for attaining FDR <= FDR0.
# .              NF0 = number of itens with P <= P0.
# .           aindex = array of indices for which elements P <= P0.
# .
# ========================================================================================================================

Stat.computePvalCutoffOnFDR <- function(apval, FDR0)
{

     # ....................................
     stopifnot(FDR0 >= 0.0, FDR0 <= 1);
     # ....................................
     
  
     # .............................................................................
     n = length(apval);
     afdr = Stat.computeFDR(apval);
       
     indexOrder = order(apval, decreasing = TRUE);

     apvalSorted = apval[indexOrder];
     afdrSorted = afdr[indexOrder];
     # .............................................................................

     
     # .............................................................................
     # . If no cutoff can guarantee the required FDR, return 0 items found :
     # .............................................................................
     if (min(afdrSorted) > FDR0) {
       P0 = NA;
       NF0 = 0;
       aindex = NULL;
       tc = list(n = n,
                 P0 = P0,
                 NF0 = NF0,
                 aindex = aindex);
     }
     # .............................................................................


     
     # .............................................................................
     # . There is a threshold :
     # .............................................................................          
     if (min(afdrSorted) <= FDR0) {
       index_0 = min(which(afdrSorted <= FDR0));
       P0 = apvalSorted[index_0];
       NF0 = n - index_0 + 1;
       aindex = which(apval <= P0);        # Indices correspond to the *unsorted* list.
     }
     # .............................................................................

     

     # .............................................................................
     # . Package results :
     # .............................................................................
     tc = list(n = n,
               P0 = P0,
               NF0 = NF0,
               aindex = aindex);
     # .............................................................................


     
     # ...............
     return (tc);
     # ...............

}

# ========================================================================================================================
# . End of Stat.computePvalCutoffOnFDR.
# ========================================================================================================================







# ====================================================================================================================
# . Stat.boxplotSortedOnMedian : generates boxplots for the distribution of values according to the specified factor.
# . --------------------------   
# .                          
# . Syntax :
# .
# .                Stat.boxplotSortedOnMedian(ax,
# .                                           at,
# .                                           al = NULL,
# .                                           levelMarked = NULL,
# .                                           flagSort = TRUE,
# .                                           caption = '',
# .                                           ylab = 'expression');
# .
# . In :
# .
# .            ax = array of numerical values.
# .
# .            at = array of factor levels.
# .
# .            al = array of labels to post on top of each box.
# .
# .   levelMarked = level to be marked, If present, the box for this level gets colored red.
# .
# .
# .      flagSort = if TRUE, sort boxplots according to in decreasing order of median.
# .
# .       caption = caption that appears at top of graphs
# .
# .          ylab = label for y (expression) axis; e.g. 'log2(count)'. If missing, set to 'expression'.
# .
# ====================================================================================================================

Stat.boxplotSortedOnMedian <- function(ax,
                                       at,
                                       al = NULL,                                
                                       levelMarked = NULL,
                                       flagSort = TRUE,
                                       caption = '',
                                       ylab = 'expression',
                                       ...)
{


     # ............................................................................
     stopifnot(length(at) == length(ax));

     if (!is.null(al)) {
       stopifnot(length(al) == length(ax));
     }
     # ............................................................................  
  


     # ............................................................................
     # . Sorted order :
     # ............................................................................
     if (flagSort) {
       axm = tapply(ax, at, median);                       # Median will be the sort parameter.
       oind = order(axm, decreasing = TRUE);
       atFac =  ordered(at, levels = levels(as.factor(at))[oind]);
     } else {
       atFac = at;
     }
     # ............................................................................


     # ............................................................................
     # . Generate colors ;
     # ............................................................................
     alev = levels(atFac);
     nt = length(alev);
     acol = rep('white', nt);

     if (!is.null(levelMarked)) {
       itarget = grep(levelMarked, alev);
       acol[itarget] = 'red';
     }
     # ............................................................................          


     
     # .............................................................................
     # . Box plots here :
     # .............................................................................
     mai.OLD = par("mai");
     buf = mai.OLD;
     buf[1] = 3.5;
     par(mai = buf);

     barx = boxplot(ax ~ atFac, las = 2,
                    col = acol,
                    ylab = ylab,
                    main = caption, ...);

     par(mai = mai.OLD);   
     # ............................................................................


     # ............................................................................
     # . Add labels if specified :
     # . TO BE FINISHED!! 9-27-2014
     # ............................................................................
     if (!is.null(al)) {
       n = length(al);
       xmin = min(ax, na.rm = TRUE);
       xmax = max(ax, na.rm = TRUE);       
       yt = xmax - 0.05 * (xmax - xmin);
       text(1:n, yt, al, cex = 0.7);
     }
     # ............................................................................     


     # ............
     return(0);
     # ............

}

# ====================================================================================================================
# . End of Stat.boxplotSortedOnMedian.
# ====================================================================================================================





# ====================================================================================================================
# . Stat.boxplotSortedOnMedianNew : generates boxplots for the distribution of values according to the specified factor.
# . ------------------------------  Options include sorting and coloring the boxes. The numerical count is displayed
# .                                 above each box. This is meant to REPLACE Stat.boxplotSortedOnMedian().
# .                                 NOTE: 4-22-2015: COLOR assignments under flagSort = TRUE are not correct.
# .                                 This needs to be corrected.
# .
# . Syntax :
# .
# .                Stat.boxplotSortedOnMedianNew(ax,
# .                                              at,
# .                                              flagLevelMarked = FALSE,
# .                                              levelMarked = NULL,
# .                                              flagColorAll = FALSE,
# .                                              flagSort = TRUE,
# .                                              caption = '',
# .                                              ylab = 'expression');
# .
# . In :
# .
# .            ax = array of numerical values.
# .
# .            at = array of factor levels.
# .
# .  flagLevelMarked = if TRUE, use levelMarked to color its box. This ption is overridden
# .                    if flagColorAll is TRUE.
# .
# .   levelMarked = level to be marked. If present, the box for this level gets colored red.
# .
# .  flagColorAll = if TRUE, color boxes automatically. This overrides the option defined by 'levelMarked'.
# .
# .       rngSeed = random number seed used under flagColorAll = TRUE.
# .
# .      flagSort = if TRUE, sort boxplots according to in decreasing order of median.
# .
# .       caption = caption that appears at top of graphs
# .
# .          ylab = label for y (expression) axis; e.g. 'log2(count)'. If missing, set to 'expression'.
# .
# ====================================================================================================================

Stat.boxplotSortedOnMedianNew <- function(ax,
                                          at,
                                          flagLevelMarked = FALSE,
                                          levelMarked = NULL,
                                          flagColorAll = FALSE,
                                          rngSeed = 123456,
                                          flagSort = TRUE,
                                          caption = '',
                                          ylab = 'expression',
                                          lmargin = 3.5,
                                          ...)
{


     # ............................................................................
     stopifnot(length(at) == length(ax));
     # ............................................................................  
  


     # ............................................................................
     # . Sorted order :
     # ............................................................................
     if (flagSort) {
       axm = tapply(ax, at, median);                       # Median will be the sort parameter.
       oind = order(axm, decreasing = TRUE);
       atFac =  ordered(at, levels = levels(as.factor(at))[oind]);
     } else {
       atFac = as.factor(at);
     }
     # ............................................................................


     
     # ............................................................................
     # . Generate colors ;
     # ............................................................................
     alev = levels(atFac);
     nt = length(alev);
     acol = rep('white', nt);
     # ............................................................................
     # . >> 1. Mark a single designated level :
     # ............................................................................     
     if (flagLevelMarked) {
       itarget = grep(levelMarked, alev);
       acol[itarget] = 'red';
     }
     # ............................................................................
     # . >> 2. OR, if flagColorAll = TRUE, each box gets a different color.
     # . This option overrides flagLevelMarked = TRUE.
     # ............................................................................     
     if (flagColorAll) {
       #xxx cw = Graphics.makeColorWheelOnArray(atFac, flagAllBlack = 'no');
       cw = Graphics.makeColorWheelOnArray(atFac,
                                           flagAllBlack = 'no',
                                           flagSortNumerical = FALSE,
                                           flagShuffle = TRUE,
                                           rngSeed = rngSeed);
     
       acol = cw$colorWheel[levels(atFac)];
       acol[acol == 'black'] = 'gray';           # Avoid all-black.
     }
     # ............................................................................


     # ............................................................................
     # . Add transparency to the colors :
     # ............................................................................     
     acol = Graphics.addTrans(color = acol, trans = 128);
     # ............................................................................     
   
     
     # .............................................................................
     # . Box plots here :
     # .............................................................................
     mai.OLD = Graphics.setLowerMargin(lmargin);          # Expand lower margin to get all the text of the labels in the barplots.     
     barx = boxplot(ax ~ atFac, las = 2,
                    col = acol,
                    ylab = ylab,
                    main = caption,
                    ...);

     par(mai = mai.OLD);   
     # ............................................................................



     # ............................................................................
     #. Tabulate numerical count, then display :
     # ............................................................................
     ff1 = table(atFac, useNA = 'ifany');
     
     n = length(ff1);
     xmin = min(ax, na.rm = TRUE);
     xmax = max(ax, na.rm = TRUE);       
     yt = xmax - 0.05 * (xmax - xmin);
     text(1:n, yt, ff1, cex = 0.8, srt = 90);     
     # ............................................................................                    

     

     # ............
     return(0);
     # ............

}

# ====================================================================================================================
# . End of Stat.boxplotSortedOnMedianNew.
# ====================================================================================================================







# ====================================================================================================================
# . Stat.boxplotSortedOnGroups : generates boxplots for the distribution of values according to the specified factor.
# . --------------------------   Options include sorting on another factor, and coloring the boxes.
# .                              The numerical count is displayed above each box.
# .                              NOTE: 4-22-2015: COLOR assignments under flagSort = TRUE are not correct.
# .                              This needs to be corrected.
# .
# . Syntax :
# .
# .         cw =   Stat.boxplotSortedOnGroups(ax,
# .                                           at,
# .                                           ag,
# .                                           flagLevelMarked = FALSE,
# .                                           levelMarked = NULL,
# .                                           flagColorAll = FALSE,
# .                                           flagSort = TRUE,
# .                                           caption = '',
# .                                           ylab = 'expression');
# .
# . In :
# .
# .            ax = array of numerical values.
# .
# .            at = array of factor levels defining each box.
# .
# .            ag = array of levels defining groups by which to sort at values. Note that *all* instances with a given
# .                 value from array at are assumed to all have the *same* value from ag (e.g. all BLCA from at are
# .                 assumed to have the same 'Bladder' value in ag). A check is done on the mapping before generating
# .                 the plot.
# .
# .  flagLevelMarked = if TRUE, use levelMarked to color its box. This option is overridden
# .                    if flagColorAll is TRUE.
# .
# .   levelMarked = level to be marked. If present, the box for this level gets colored red.
# .
# .  flagColorAll = if TRUE, color boxes automatically. This overrides the option defined by 'levelMarked'.
# .
# .   colorSource = 'group', 'box'. If 'group' use the group memberships to color the boxes.
# .                 If 'box', each individual box gets a different color.
# . 
# .       rngSeed = random number seed used under flagColorAll = TRUE.
# .
# .      flagSort = if TRUE, sort boxplots according to values in ag. If FALSE, do not do any sorting.
# .
# .       caption = caption that appears at top of graphs
# .
# .          ylab = label for y (expression) axis; e.g. 'log2(count)'. If missing, set to 'expression'.
# .
# .
# .  Out :
# .
# .           cw = 'colorWheel' object. A legend can be generate dwith :
# .                 Graphics.plotLegendOnColorWheel(cw, caption = '', hpos = 'left');
# .
# ====================================================================================================================

Stat.boxplotSortedOnGroups <- function(ax,
                                       at,
                                       ag,
                                       flagLevelMarked = FALSE,
                                       levelMarked = NULL,
                                       flagColorAll = FALSE,
                                       colorSource = 'group',
                                       rngSeed = 123456,
                                       flagSort = TRUE,
                                       caption = '',
                                       ylab = 'expression',
                                       lmargin = 3.5,
                                       ...)
{


     # .....................................................................................
     # . Check on values.
     # . >> Array lengths :
     # .....................................................................................
     stopifnot(length(at) == length(ax));
     stopifnot(length(ag) == length(ax));
     # .....................................................................................     
     # . >> Each box level must be entirely contained in a group :
     # .....................................................................................
     ff2 = table(at, ag);
     an1 = apply(ff2, 1, function(x){sum(x > 0)});    # Number of nonzero cells per row.

     if (max(an1) > 1) {
       cat("ERROR: from Stat.boxplotSortedOnGroups:\n");
       cat("some given levels in at are split across more than 1 group in ag.\n");
       stop();       
     }
     # .....................................................................................     
     # . >> What determines the colors :
     # .....................................................................................     
     if ((colorSource != 'group') && (colorSource != 'box')) {
       cat("ERROR: from Stat.boxplotSortedOnGroups:\n");
       cat("colorSource = ", colorSource, " is not valid.\n", sep = "");
       cat("Valid: group, box.\n");
       stop();       
     }
     # .....................................................................................
  

     
     # .....................................................................................
     # . Determine box --> group mapping for colors :
     # .....................................................................................     
     ff2 = table(at, ag);
     ic = apply(ff2, 1, function(x){which(x > 0)});    # Points to group.

     hmapToGroup = colnames(ff2)[ic];                  # Values are the group names.
     names(hmapToGroup) = rownames(ff2);               # Keys are the box names.
     # .....................................................................................     

     
     
     # ..........................................................................................
     # . Sorted order :
     # . Note that all samples for a given factor are assumed from the same group
     # ..........................................................................................
     if (flagSort) {
       agm = tapply(ag, at, function(x){x[1]});
       oind = order(agm);
       atFac =  ordered(at, levels = levels(as.factor(at))[oind]);
     } else {
       atFac = as.factor(at);
     }
     # ..........................................................................................


     
     # ............................................................................
     # . Generate colors ;
     # ............................................................................
     alev = levels(atFac);
     nt = length(alev);
     acol = rep('white', nt);
     # ............................................................................
     # . >> 1. Mark a single designated level :
     # ............................................................................     
     if (flagLevelMarked) {
       itarget = grep(levelMarked, alev);
       acol[itarget] = 'red';
     }
     # ............................................................................
     # . >> 2. OR, if flagColorAll = TRUE, each box gets a different color.
     # . This option overrides flagLevelMarked = TRUE.
     # ............................................................................     
     if (flagColorAll) {
       # ..........................................................................
       # . Color individual boxes :
       # ..........................................................................
       if (colorSource == 'box') {
         cw = Graphics.makeColorWheelOnArray(atFac,
                                             flagAllBlack = 'no',
                                             flagSortNumerical = FALSE,
                                             flagShuffle = TRUE,
                                             rngSeed = rngSeed);
         acol = cw$colorWheel[levels(atFac)];
         acol[acol == 'black'] = 'gray';           # Avoid all-black.
       }
       # ..........................................................................
       # . Color by group :
       # ..........................................................................
       if (colorSource == 'group') {
         cw = Graphics.makeColorWheelOnArray(ag,
                                             flagAllBlack = 'no',
                                             flagSortNumerical = FALSE,
                                             flagShuffle = TRUE,
                                             rngSeed = rngSeed);

         agLev = hmapToGroup[alev];

         acol = cw$colorWheel[agLev];
         acol[acol == 'black'] = 'gray';           # Avoid all-black.
       }        
       # ..........................................................................                  
     }
     # ............................................................................


     # ............................................................................
     # . Add transparency to the colors :
     # ............................................................................     
     acol = Graphics.addTrans(color = acol, trans = 128);
     # ............................................................................     
   
     
     # ............................................................................................................................
     # . Plots :
     # . >> Generate the positioning array which separates clusters of boxes from different groups :
     # ............................................................................................................................
     agLev = hmapToGroup[alev];                                # Groups in order of display in plot.
     ngLev = length(agLev);
     ngLev1 = ngLev - 1;
     
     flagDiff = as.integer(agLev[2:ngLev] != agLev[1:ngLev1]);
     buf1 = cumsum(flagDiff);
     buf2 = c(0, buf1);
     atBuf = (1:ngLev) + buf2;
     # ............................................................................................................................
     # . Find the "holes" where to draw vertical divider lines :
     # ............................................................................................................................
     abuf = 1:max(atBuf);
     mask = !(abuf %in% atBuf);
     adiv = abuf[mask];
     # ............................................................................................................................     
     # . >> Box plot here :
     # ............................................................................................................................     
     mai.OLD = Graphics.setLowerMargin(lmargin);               # Expand lower margin to get all the text of the labels in the barplots.     
     barx = boxplot(ax ~ atFac, las = 2,
                    col = acol,
                    ylab = ylab,
                    main = caption,
                    at = atBuf,
                    ...);

     par(mai = mai.OLD);

     buf = sapply(adiv, function(x){abline(v = x, col = 'blue')});
     # .............................................................................................................................



     # ............................................................................
     #. Tabulate numerical count, then display :
     # ............................................................................
     ff1 = table(atFac, useNA = 'ifany');
     
     n = length(ff1);
     xmin = min(ax, na.rm = TRUE);
     xmax = max(ax, na.rm = TRUE);       
     yt = xmax - 0.05 * (xmax - xmin);
     text(atBuf, yt, ff1, cex = 0.8, srt = 90);     
     # ............................................................................                    

     

     # ............
     return(cw);
     # ............

}

# ====================================================================================================================
# . End of Stat.boxplotSortedOnGroups.
# ====================================================================================================================






# ============================================================================================================
# . ttestEqualVariance : returns the P-values computed from a two-tailed equal-variance t-test, using
# . ------------------   pre-computed means and std. dev.
# .
# . Syntax :
# .
# .     pval = Stat.ttestEqualVariance(x, y, sx, sy, nsx, nsy);
# .
# . In:
# .
# .   x   =  Mean in first panel (array).
# .   y   =  Mean in second panel (array).
# .   sx  =  Sample standard deviation in first panel (array).
# .   sy  =  Sample standard deviation in second panel (array).
# .   nsx =  Number of samples in first panel.
# .   nsy =  Number of samples in second panel.
# .
# . Out :
# .
# .   pval = two-tailed, equal variances T-test P-value.
# .
# .
# . Note: requires that nsx + nsy > 2, else an exception occurs.
# .
# ============================================================================================================  

Stat.ttestEqualVariance <- function(x, y, sx, sy, nsx, nsy)
{

       # .....................................................................................
       nu = nsx + nsy - 2.0;                            # Degrees of freedom.
		      
       if (nu <= 0.0) {
	   cat("ERROR: from Stat.ttestEqualVariance:\n");
	   cat("nu = nsx +nsy - 2 <= 0. Cannot do equal variance test.\n");
	   cat("Here: nu = ", nu, "\n");
           stop();
       }
       # .....................................................................................       


       # .....................................................................................       
       dmean = y - x;                                            # Difference of means.
       fac1 = 1.0 / nsx + 1.0 / nsy;
       SS = (nsx - 1.0) * (sx * sx) + (nsy - 1.0) * (sy * sy);   # Pooled sum-of-squares.
       s2 = fac1 * (SS / nu);                                    # Variance estimate.

       tval = ifelse(s2 == 0, 0.0, abs(dmean / sqrt(s2)));       # |t|

       pval = ifelse(s2 == 0, ifelse(dmean == 0, 1.0, 0.0),
                     2.0 * pt(tval, df = nu, lower.tail = FALSE));
       # ......................................................................................



       # ................
       return (pval);
       # ................

}

# ==================================================================================================
# . End of Stat.ttestEqualVariance.
# ==================================================================================================







# ===========================================================================================
# . Stat.onePointROC : computes an AUC by fitting a quadratic function with juts one  
# . ----------------   (FP, S) point as input. Also calculates a confidence interval
# .                    for the AUC. This is a rather special purpose function for
# .                    quick back-of-the-envelope estimates of AUC and ROC.
# . Syntax :
# .
# .          cs = Stat.onePointROC(S, FP, n1, n2, prob = 0.95, flagPlot = FALSE);
# .
# . In:
# .        S = single-point sensitivity. Assumes: 0 < S < 1.
# .        FP = single-point false-positive rate. Assumes:  0 < FP < 1.
# .        n1 = number of samples in first panel.
# .        n2 = number of samples in second panel.
# .      prob = probability for confidence interval.
# .  flagPlot = if TRUE, generate plot of ROC.
# .
# . Out:
# .       cs = list, with members :
# .
# .           A = estimated AUC.
# .         ALo = lower bound on CI
# .         AHi = upper bound on CI.
# .        pval = P-value
# .        beta = linear coefficient of fit to ROC.
# .        gamma = quadratic coefficient of fit to ROC.
# .
# ...........................................................................................
# .  Details:
# .
# ===========================================================================================

Stat.onePointROC <- function(S, FP, n1, n2, prob = 0.95, flagPlot = FALSE)
{

     # .................................................................
     stopifnot(FP > 0, FP < 1.0);
     stopifnot(S > 0, S < 1.0);     
     # .................................................................


     # .................................................................
     # . Calculate the coefficients :
     # .................................................................     
     fac1 = 1.0 / (FP * (1.0 - FP));
     beta = fac1 * (S - FP * FP);
     gamma = fac1 * (FP - S);
     # .................................................................


     # .................................................................
     # . Compute the area by numerical integration :
     # .................................................................
     dx = 0.005;
     ax = seq(0.0, 1.0, by = dx);
     ay = beta * ax + gamma * ax * ax;
     ay = ifelse(ay > 1.0, 1.0, ay);
     ay = ifelse(ay < 0.0, 0.0, ay);
     nx = length(ay);
     
     A = dx * (sum(ay) - 0.5 * ay[1] - 0.5 * ay[nx]);

     A = ifelse(A > 1, 1, A);     # Adjust for small errors.
     A = ifelse(A < 0, 0, A);
     # .................................................................     


     # .................................................................
     # . Compute confidence interval :
     # .................................................................          
     auc = Stat.aucROCTest(A, n1, n2, prob = prob);
     # .................................................................


     # .............................................................
     # . Package results :
     # .............................................................
     cs = list(A = A,
               ALo = auc$ALo,
               AHi = auc$AHi,
               pval = auc$pval,
               beta = beta,
               gamma = gamma);
     # .............................................................


     # .............................................................
     # . Plot if requested :
     # .............................................................
     if (flagPlot) {
       Stemp = sprintf("%6.3f", S);
       FPtemp = sprintf("%6.3f", FP);
       Atemp = sprintf("%6.3f", A);
       ALoTemp = sprintf("%6.3f", auc$ALo);
       AHiTemp = sprintf("%6.3f", auc$AHi);              
       
       caption = paste("One-point ROC: S = ", Stemp,
                       ", FP = ", FPtemp,
                       ", A = ", Atemp,
                       " [", ALoTemp,
                       ", ", AHiTemp, "]_", prob, sep = "");
       plot(ax,
            ay,
            xlim = c(0, 1),            
            ylim = c(0, 1),
            xlab = 'FP',
            ylab = 'S',
            type = 'l',
            main = caption);

       points(FP, S, pch = 19);
     }
     # .............................................................          


     # .............
     return (cs);
     # .............

}

# ===========================================================================================
# . End of Stat.onePointROC.
# ===========================================================================================






# ============================================================================================================
# . Stat.symAuc : simple utility function, 'symmetrizes' a set of AUCs via the transformation 
# . -----------   t = - log(auc / (1 - auc)) = logit(P(x2 < x1)) = logit(1 - auc). Takes care of extreme values 
# .               of 0 or 1 by putting floor and ceiling on the input values.
# .
# . Syntax :
# .
# .          t = Stat.symAuc(auc);
# .
# . In:
# .
# .   auc   =  auc value, in range 0 <= auc <= 1.
# .
# . Out :
# .
# .                                 1 - auc 
# .       t = logit(1 - auc) = log( -------- }
# .                                   auc 
# .
# .           Note that t -> infinity as auc -> 0+, and t -> -infinity as auc -> 1-.
# .
# .           To allow for auc = 0, 1 exactly, values of auc are floored above 0 and ceilinged below 1,
# .           so that t is rectricted to the range -20  <= t <= 20.
# .
# ============================================================================================================  

Stat.symAuc <- function(auc)
{

       # .......................................................
       if (sum(auc < 0.0) > 0) {
         cat("ERROR: from Stat.symAuc:\n");
         cat("some input values of auc < 0.\n");
         stop();
       }

       if (sum(auc > 1.0) > 0) {
         cat("ERROR: from Stat.symAuc:\n");
         cat("some input values of auc > 1.\n");
         stop();
       }
       # .......................................................       


       # ......................................................................................
       # . Push from extreme values, then transform :
       # ......................................................................................       
       auc = ifelse(auc < Stat.FLOOR_FOR_AUC, Stat.FLOOR_FOR_AUC, auc);
       auc = ifelse(auc > Stat.CEILING_FOR_AUC, Stat.CEILING_FOR_AUC, auc);

       t = log((1.0 - auc) / auc);
       # ......................................................................................



       # ................
       return (t);
       # ................

}

# ==================================================================================================
# . End of Stat.symAuc.
# ==================================================================================================




# ============================================================================================================
# . logit1 : simple utility function, 'symmetrizes' a set of AUCs via the transformation 
# . ------   t = - log(auc / (1 - auc)) = logit(P(x2 < x1)) = logit(1 - auc). Takes care of extreme values 
# .          of 0 or 1 by putting floor and ceiling on the input values. This function is *identical*
# .          to Stat.symAuc(), I am just renaming it because 'logit1' is easier to remember.
# .
# . Syntax :
# .
# .          t = Stat.logit1(auc);
# .
# . In:
# .
# .   auc   =  auc value, in range 0 <= auc <= 1.
# .
# . Out :
# .
# .                                 1 - auc 
# .       t = logit(1 - auc) = log( -------- }
# .                                   auc 
# .
# .           Note that t -> infinity as auc -> 0+, and t -> -infinity as auc -> 1-.
# .
# .           To allow for auc = 0, 1 exactly, values of auc are floored above 0 and ceilinged below 1,
# .           so that t is rectricted to the range -20  <= t <= 20.
# .
# ============================================================================================================  

Stat.logit1 <- function(auc)
{

       # .......................................................
       if (sum(auc < 0.0) > 0) {
         cat("ERROR: from Stat.logit1:\n");
         cat("some input values of auc < 0.\n");
         stop();
       }

       if (sum(auc > 1.0) > 0) {
         cat("ERROR: from Stat.logit1:\n");
         cat("some input values of auc > 1.\n");
         stop();
       }
       # .......................................................       


       # ......................................................................................
       # . Push from extreme values, then transform :
       # ......................................................................................       
       auc = ifelse(auc < Stat.FLOOR_FOR_AUC, Stat.FLOOR_FOR_AUC, auc);
       auc = ifelse(auc > Stat.CEILING_FOR_AUC, Stat.CEILING_FOR_AUC, auc);

       t = log((1.0 - auc) / auc);
       # ......................................................................................



       # ................
       return (t);
       # ................

}

# ==================================================================================================
# . End of Stat.logit1.
# ==================================================================================================




# ===========================================================================================
# . Stat.probabilityOnCountClassical : estimates probability of a binary event given the count
# . --------------------------------   of events and the total number of observations.
# .                                    This is based on the classicalian (frequentist) formulation.
# .
# .  Syntax :
# .
# .           theta = Stat.probabilityOnCountClassical(k, n, prob)
# .
# .  In:
# .           k = count of events.
# .           n = total number of observations.
# .        prob = probability for confidence interval (e.g. 0.95).
# .
# .  Out:
# .        List with members (pLo, p, pHi) where :
# .
# .            pLo = lower limit of confidence interval.
# .              p = value form median estimator for p.
# .            pHi = upper limit of confidence interval.
# .
# ..........................................................................................
# . Details:
# .
# ===========================================================================================

Stat.probabilityOnCountClassical <- function(k, n, prob = 0.95)
{
  
     # ......................................................................... 
     if (min(n - k) < 0) {
       cat("ERROR: from Stat.probabilityOnCountClassical:\n");
       cat("Some event counts are greater than the number of obeservations.\n");
       stop()
     }

     stopifnot((prob > 0.0) && (prob < 1.0));
     stopifnot(n > 0);
     # .........................................................................

     

     # ..........................................................................
     p = k / n;

     probHi = 0.5 * (1.0 + prob);
     zc = qnorm(probHi);
     deltaP = zc * sqrt((p * (1.0 - p)) / n);

     pLo = p - deltaP;
     pHi = p + deltaP;

     pLo = ifelse(pLo < 0.0, 0.0, pLo);
     pHi = ifelse(pHi > 1.0, 1.0, pHi);     
     # ............................................................................


     
     # ..............................
     # . Package the results :
     # ..............................
     theta = list(pLo = pLo,
                  p = p,
                  pHi = pHi);
     # ..............................


     # ..............
     return (theta);
     # ..............
}

# ===========================================================================================
# . End of Stat.probabilityOnCountClassical.
# ===========================================================================================




# ==========================================================================================================
# . Stat.computeHardyWeinberg: computes the Hardy-Weinberg equilibrium distribution of
# . -------------------------  genotype probabilities corresponding to a input set of allelic
# .                            frequencies.
# .
# . Syntax :
# .
# .       pf = Stat.computeHardyWeinberg(ap);
# .
# . In:
# .
# .      ap = array of allelic frequencies, with named elements.
# .
# . Out:
# .
# .   
# ===========================================================================================================

Stat.computeHardyWeinberg <- function(ap)
{


    # ...........................................................................................
    # . Check on values :
    # ...........................................................................................
    flag = Math.checkSumIs1(ap);

    if (flag != 'ok') {
        cat("ERROR: from Stat.computeHardyWeinberg: for input array ap ", flag, "\n", sep = "");
        stop();
    }
    # ...........................................................................................
    

    
    # .........................................................................
    # . Compute HW probabilities for the different allelic combinations :
    # .........................................................................    
    afm = outer(ap, ap);
    afm = 2 * afm - diag(diag(afm));

    apNames = names(ap);
    afmNames = outer(an, an, FUN = "paste", sep = "")

    checkSum = sum(afm[upper.tri(afm, diag = TRUE)]);

    af = afm[upper.tri(afm, diag = TRUE)];
    names(af) = afmNames[upper.tri(afm, diag = TRUE)];
    checkSum = sum(af);                                          # Should be 1.
    # .........................................................................



    # ...................................................
    # . Package results :
    # ...................................................    
    pf  = list(afm = afm,     # As matrix.
               af = af);      # As vector.
    # ...................................................


    # ..................
    return (pf);
    # ..................
    
}

# ==========================================================================================================
# . End of Stat.computeHardyWeinberg.
# ==========================================================================================================







# ==========================================================================================================
# . Stat.compareAndPlotClassifications: compares and plots two distinct classification schemes for the
# . ----------------------------------  same set of samples. Generates a confusion matrix, computes the
# .                                     Jaccard coefficient, computes row-wise and column-wise entropies.
# .                                     If indicated, plots the entropies and prints the confusion matrix.
# .
# . Syntax :
# .
# .       pf = Stat.compareAndPlotClassifications(ac1,
# .                                               ac2,
# .                                               cname1 = "classifier 1",
# .                                               cname2 = "classifier 2",
# .                                               flagPlot = 'yes',
# .                                               captionStem = '');
# .
# . In:
# .
# .         ac1 = array of class assignments under classification 1.
# .  
# .         ac2 = array of class assignments under classification 2.
# .
# .      cname1 = name for classificion scheme 1.
# .
# .      cname2 = name for classificion scheme 2.
# .
# .    flagPlot = yes/no. If yes, make plots for entropies, and print the confusion matrix.
# .
# . captionStem = stem for plot titles.
# .
# . Out:
# .
# ...........................................................................................................
# . Details :
# .
# .             - requires package 'entropy'.
# .   
# ===========================================================================================================

Stat.compareAndPlotClassifications <- function(ac1,
                                               ac2,
                                               cname1 = "classifier 1",
                                               cname2 = "classifier 2",
                                               flagPlot = 'yes',
                                               captionStem = '')
{

    # ...........................................................................................
    # . Check on values :
    # ...........................................................................................
    n1 = length(ac1);
    n2 = length(ac2);
    
    if (n2 != n1) {
        cat("ERROR: from Stat.compareAndPlotClassifications: for input arrays difer in length.\n");
        stop();
    }

    stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
    # ...........................................................................................
    

    
    # ...............................................................................................
    # . Generate the confusion matrix :
    # ...............................................................................................
    cmat = table(ac1, ac2, useNA = 'ifany');
    # ...............................................................................................
    # . Adjust names for NA classes, if any :
    # ...............................................................................................
    indexNArow = which(is.na(rownames(cmat)));

    if (length(indexNArow) > 0) {
      rownames(cmat)[indexNArow] = 'NA';
    }
    
    indexNAcol = which(is.na(colnames(cmat)));

    if (length(indexNAcol) > 0) {    
      colnames(cmat)[indexNAcol] = 'NA';
    }
    # ...............................................................................................
    # . Subset to non-NA category submatrix :
    # ...............................................................................................
    indexNArow = which(rownames(cmat) == 'NA');
    indexNAcol = which(colnames(cmat) == 'NA');    
    
    cmat.noNA = cmat;
    
    if (length(indexNArow) > 0) {
      cmat.noNA = cmat.noNA[-indexNArow, ];
    }

    if (length(indexNAcol) > 0) {
      cmat.noNA = cmat.noNA[  , -indexNAcol];
    }    
    # ...............................................................................................
    # . Add margins for display :
    # ...............................................................................................
    cmat.M = addmargins(cmat);                             # Add margins.
    # .......................................................................................................................
    # . Compute the Jaccard index :
    # .......................................................................................................................
    jaccard.ALL = Stat.jaccardOnConfusionMatrix(x = cmat, method = 'chisq');
    jaccard.noNA = Stat.jaccardOnConfusionMatrix(x = cmat.noNA, method = 'chisq');    
    # .......................................................................................................................
    # . Compute entropies :
    # .......................................................................................................................
    aeRow = apply(cmat, 1, entropy, method = "ML", unit = "log2");
    aeCol = apply(cmat, 2, entropy, method = "ML", unit = "log2");

    aeRow.noNA = apply(cmat.noNA, 1, entropy, method = "ML", unit = "log2");
    aeCol.noNA = apply(cmat.noNA, 2, entropy, method = "ML", unit = "log2");
    # .......................................................................................................................
    # . Compute maximum classification probability :
    # .......................................................................................................................
    apMaxRow = apply(cmat, 1, max) / rowSums(cmat);
    apMaxCol = apply(cmat, 2, max) / colSums(cmat);

    apMaxRow.noNA = apply(cmat.noNA, 1, max) / rowSums(cmat);
    apMaxCol.noNA = apply(cmat.noNA, 2, max) / colSums(cmat);
    # .......................................................................................................................



    # .....................................................................................................................
    # . Display if requested :
    # .....................................................................................................................    
    if (flagPlot == 'yes') {
      # ...............................................................................................
      # . Print CM and Jaccard coefficient :
      # ...............................................................................................      
      cat("------------------------------------------------------------------------------------\n");
      cat("Confusion matrix : ", captionStem, ":  {", cname1, " * ", cname2, "} \n", sep = "");
      cat("\n");
      Util.writeTable(cmat.M);
      cat("------------------------------------------------------------------------------------\n");
      cat("\n");

      cat("------------------------------------------------------------------------------------\n");
      cat("Jaccard for all classes:", "\t", jaccard.ALL$Jtext, "\n", sep = "");
      cat("Jaccard for classes excluding NA:", "\t", jaccard.noNA$Jtext, "\n", sep = "");      
      cat("------------------------------------------------------------------------------------\n");
      cat("\n");      
      # ...............................................................................................
      # . Plot entropies :
      # . >> 1. For all classes :
      # ...............................................................................................
      buf = readline(">>Enter a carriage return for first plot or q to skip plots: ");    # Pause.
        
      if (buf == 'q') {
        break;
      }
      
      par(mfrow = c(1, 2));

      emax = log2(ncol(cmat));
      barplot(aeRow, ylim = c(0, emax),
              ylab = "Entropy (bits)",
              main = paste("Entropy for ", cname1, " classified by ", cname2, sep =""));
      abline(h = emax, lty = 'dashed');
      
      emax = log2(nrow(cmat));
      barplot(aeCol, ylim = c(0, emax),
              ylab = "Entropy (bits)",
              main = paste("Entropy for ", cname2, " classified by ", cname1, sep =""));              
      abline(h = emax, lty = 'dashed');

      par(mfrow = c(1, 1));
      # ...............................................................................................
      # . >> 2. Excluding NAs :
      # ...............................................................................................
      buf = readline(">>Enter a carriage return to continue or q to skip plots: ");    # Pause.
        
      if (buf == 'q') {
        break;
      }        

      par(mfrow = c(1, 2));

      emax = log2(ncol(cmat.noNA));
      barplot(aeRow.noNA, ylim = c(0, emax),
              ylab = "Entropy (bits)",
              main = paste("Entropy for ", cname1, " classified by ", cname2, "- noNA - [", captionStem, "]", sep =""));
      abline(h = emax, lty = 'dashed');
      
      emax = log2(nrow(cmat.noNA));
      barplot(aeCol.noNA, ylim = c(0, emax),
              ylab = "Entropy (bits)",
              main = paste("Entropy for ", cname2, " classified by ", cname1, "- noNA - [", captionStem, "]", sep =""));              
      abline(h = emax, lty = 'dashed');

      par(mfrow = c(1, 1));      
      # ...............................................................................................
      # . Plot max. classification probability :
      # . >> 3. For all classes :
      # ...............................................................................................
      buf = readline(">>Enter a carriage return or q to skip plots: ");    # Pause.
        
      if (buf == 'q') {
        break;
      }
      
      par(mfrow = c(1, 2));

      barplot(apMaxRow, ylim = c(0, 1),
              ylab = "max Prob(C)",
              main = paste("max Prob(C) for ", cname1, " classified by ", cname2, sep =""));
      abline(h = 0.5, lty = 'dashed');
      
      barplot(apMaxCol, ylim = c(0, 1),
              ylab = "max Prob(C)",
              main = paste("max Prob(C) for ", cname2, " classified by ", cname1, sep =""));
      abline(h = 0.5, lty = 'dashed');      

      par(mfrow = c(1, 1));
      # ...............................................................................................
      # . >> 4. Excluding NAs :
      # ...............................................................................................
      buf = readline(">>Enter a carriage return to continue or q to skip plots: ");    # Pause.
        
      if (buf == 'q') {
        break;
      }        

      par(mfrow = c(1, 2));

      barplot(apMaxRow.noNA, ylim = c(0, 1),
              ylab = "max Prob(C)",
              main = paste("max Prob(C) for ", cname1, " classified by ", cname2, "- noNA - [", captionStem, "]", sep =""));
      abline(h = 0.5, lty = 'dashed');            
      
      emax = log2(nrow(cmat.noNA));
      barplot(apMaxCol.noNA, ylim = c(0, 1),
              ylab = "max Prob(C)",
              main = paste("max Prob(C) for ", cname2, " classified by ", cname1, "- noNA - [", captionStem, "]", sep =""));
      abline(h = 0.5, lty = 'dashed');                  

      par(mfrow = c(1, 1));      
      # ...............................................................................................                  
    }
    # .......................................................................................................................


    

    # .......................................................................................................
    # . Package results :
    # .......................................................................................................
    pf  = list(cmat = cmat,                        # Confusion matrix.
               cmat.noNA = cmat.noNA,              # Confusion matrix with no NA.
               cmat.M = cmat.M,                    # Confusion matrix with margins.
               jaccard.ALL = jaccard.ALL,          # Jaccard for complete matrix.
               jaccard.noNA = jaccard.noNA,        # Jaccard for matrix without NA categories in rows or columns.
               aeRow = aeRow,                      # Row entropies.   
               aeCol = aeCol,                      # Column entropies.
               aeRow.noNA = aeRow.noNA,            # Row entropies, no NA categories.
               aeCol.noNA = aeCol.noNA,            # Column entropies, no NA categories.
               apMaxRow = apMaxRow,                # Row maximum classification probability.   
               apMaxCol = apMaxCol,                # Column maximum classification probability.
               apMaxRow.noNA = apMaxRow.noNA,      # Row maximum classification probability, no NA categories.
               apMaxCol.noNA = apMaxCol.noNA);     # Column maximum classification probability, no NA categories.
    # .........................................................................................................


    # ..................
    return (pf);
    # ..................
    
}

# ==========================================================================================================
# . End of Stat.compareAndPlotClassifications.
# ==========================================================================================================









# ====================================================================================================================
# . Stat.plotProbsOnContingTable : given a contingency tables of *counts*, generates barplots of probability of
# . ----------------------------   occurrence in each cell, relative to the *row* categories.
# .
# . Syntax :
# .
# .               dfP2 = Stat.plotProbsOnContingTable(ff2, caption);
# .
# . In :
# .
# .        ff2 = {m * K} 2-dimensional contingency table of counts, with names rows and columns.
# .
# .    caption = plot caption.
# .
# . Out :
# .
# .        - Barplot of estimated probabilities. The barplot contains K sucessive groups of bars, each group
# .          corresponding to a different column in the input table. Each group contains m bars, each bar
# .          corresponding to a different row in the table.  If the table elements are designated by f22_{i, k},
# .          i = 1, . . ., m,  k = 1, . . ., K, then the i-th bar in the k-th group denotes :
# .
# .
# .                                           ff2_{i, k}
# .                       Prob(k|i) =  ---------------------------
# .                                       K
# .                                      sum    ff2_{i, j}
# .                                      j = 1
# .
# .          (actually, the Bayesian implementation of this).
# .
# .          dfP2 =  matrix of format {pLo, p, pHi} * {panel.subtype}
# ....................................................................................................................
# . Example :
# .
# .   ff2 = 
# .
# .            CMS1 CMS2 CMS3 CMS4 NONE
# .        II    14   41   17   20   16
# .        III   70  156   62  161  131
# .
# .    yields the plot :
# .
# .         ^
# .         |
# .         |
# .         |
# .         |
# .         |
# .         |                                   [
# .         |                                   [
# .         |     [                             [
# .         |     [                   [         [
# .         |     [         [         [         [
# .         |     [         [         [         [
# .         |     [         [         [         [
# .         |     [         [         [         [         . . .     . . .     . . .     . . .      
# .         --------------------------------------------------------------------------------------
# .            II.CMS1   III.CMS1   II.CMS2   III.CMS2   II.CMS3   III.CMS3   II.CMS4   III.CMS4      
# .
# .
# ====================================================================================================================

Stat.plotProbsOnContingTable <- function(ff2, caption = '')
{

     # ...............................................................................
     # . Check on input :
     # ...............................................................................
     if ((class(ff2) != 'matrix') && (class(ff2) != 'table')) {
       cat("ERROR: from Stat.plotProbsOnContingTable:\n");
       cat("Input ff2 class is not valid. Valid: table, matrix.\n");
       stop();
     }

     if (length(dim(ff2)) != 2) {
       cat("ERROR: from Stat.plotProbsOnContingTable:\n");
       cat("Input ff2 must have two dimensions, even if nrow or ncol = 1.\n");
       stop();
     }

     abuf = rownames(ff2);
     if (is.null(abuf)) {
       cat("ERROR: from Stat.plotProbsOnContingTable:\n");
       cat("Input ff2 has no assigned rownames.\n");
       stop();
     }

     abuf = colnames(ff2);     
     if (is.null(abuf)) {
       cat("ERROR: from Stat.plotProbsOnContingTable:\n");
       cat("Input ff2 has no assigned colnames.\n");
       stop();
     }     

     # ...............................................................................


     # ...............................................................................
     # . Chisq test on the table :
     # ...............................................................................
     if ((nrow(ff2) > 1) && (ncol(ff2) > 1)) {
       cs = chisq.test(ff2);
       pval =  cs$p.value;
       flagPval = TRUE;
     } else{
       pval = 1.0;
       flagPval = FALSE;
     }
     # ...............................................................................


     
     # .......................................................................................................................
     # . Compute row sums : these are the reference totals :
     # .......................................................................................................................
     an = rowSums(ff2);
     names(an) = rownames(ff2);
     # .......................................................................................................................
     # . Compute probability estimates with CIs :
     # .......................................................................................................................
     lbuf1 = lapply(1:nrow(ff2), function(i){Stat.probabilityOnCountBayes(k = as.numeric(ff2[i, ]), n = an[i], prob = 0.95);});
     lbuf2 = lapply(lbuf1, as.data.frame)
     names(lbuf2) = rownames(ff2);
     dfP = do.call("rbind", lbuf2);           # Probability estimates.

     dbuf = outer(rownames(ff2), colnames(ff2), FUN = function(x, y){paste(x, ".", y, sep = "");});
     arNew = as.character(t(dbuf))
     rownames(dfP) = arNew;
     # .......................................................................................................................
     # . Remove 'textCI' field, transpose :
     # .......................................................................................................................     
     dfP1 = t(dfP[  , -4]);                   # This is now a matrix : {pLo, p, pHi} * {panel.subtype}
     # .......................................................................................................................
     # . Rearrange to group items from the same columns together :
     # .......................................................................................................................
     akey = rep(1:ncol(ff2), times = nrow(ff2));
     atype = rep(colnames(ff2), times = nrow(ff2));
     
     indexSort = order(akey);
     
     dfP2 = dfP1[  , indexSort];
     atypeSort = atype[indexSort];
     akeySort = akey[indexSort]
     # .......................................................................................................................
     # . Now plot :
     # .......................................................................................................................
     cw = Graphics.makeColorWheelOnArray(atypeSort);
     acol = cw$acol;
     # ............................................................................................................
     # . Make colors more transparent :
     # ............................................................................................................
     acol = Graphics.addTransJST(acol, alpha = 0.25);
     # ............................................................................................................
     # . The actual barplot is here :
     # ............................................................................................................
     pvalBuf = sprintf("%2.2e", pval);

     if (flagPval) {
       captionBuf = paste(caption, "   [P = ", pvalBuf, "]", sep = "");
     } else {
       captionBuf = caption;
     }
       
     alabTop = akeySort;

     buf = Stat.barplotWithErrorBarsAndTopLabels(ay = as.numeric(dfP2["p", ]),
                                                 flagErrbar = TRUE,
                                                 aylo = as.numeric(dfP2["pLo", ]),
                                                 ayhi = as.numeric(dfP2["pHi", ]),
                                                 alabBot = colnames(dfP2),
                                                 alabTop = alabTop,
                                                 ylab = 'Probability of occurrence [95% CI]',
                                                 caption = captionBuf,
                                                 flagLogScale = FALSE,
                                                 flagYlim = FALSE,
                                                 ylimIn = NULL,
                                                 flagSort = FALSE,
                                                 col = acol);
     # .......................................................................................................................


     # ...............
     return (dfP2);
     # ...............

}

# ====================================================================================================================
# . End of Stat.plotProbsOnContingTable.
# ====================================================================================================================



# ====================================================================================================================
# . Stat.computeEffectiveDegFreedomForPearson : computes the effective sample number for a given distribution of 
# . -----------------------------------------   Pearson correlation coefficients.
# .
# . Syntax :
# .
# .        neff = Stat.computeEffectiveDegFreedomForPearson(ar);
# .
# . In:
# .
# .    ar = array of correlation coefficients.
# .
# . Out:
# .
# .             neff = effective number of samples.
# .
# ====================================================================================================================

Stat.computeEffectiveDegFreedomForPearson  <- function(ar)
{

     # ..............................................................................
     # . Use the interquartile range to 'renormalize' the P-values :
     # ..............................................................................  
     az = atanh(ar);
     fac1 = 1.0 / (2.0 * qnorm(0.75));
     sigma = fac1 * (quantile(az, probs = 0.75) - quantile(az, probs = 0.25));
     neff = 3 + 1 / sigma^2;
     # ............................................................................

     
     # ..............
     return (neff);
     # ..............


}

# ====================================================================================================================
# . End of Stat.computeEffectiveDegFreedomForPearson.
# ====================================================================================================================








# =================================================================================================
# . Stat.plotPairedHistograms :  generates histograms for a pair of distributions, plots them
# . -------------------------    together in the same graph.
# .
# .  Syntax :
# .
# .      buf = Stat.plotPairedHistograms(ax1,
# .                                      ax2,
# .                                      abreak,
# .                                      acol,
# .                                      agroup,
# .                                      xlab,
# .                                      flagSameScale = TRUE,
# .                                      captionStem,
# .                                      agroup);
# .
# . In :
# .               ax1 = series of values 1.
# .
# .               ax2 = series of values 2.
# .
# .            abreak = vector of length 2, specifies the number of breaks for the histograms.
# .
# .              acol = vector of length 2, specifies the colors for the histograms.
# .
# .            agroup = vector of length 2, specifies the two group names.
# .
# .              xlab = labelfor x axis.
# .
# .     flagSameScale = if FALSE, do not put the histograms on the same vertical scale (if
# .                     flagSameScale = FALSE, the histograms will actually appear to be of
# .                     approximately the same height regardless of distributions).
# .
# .       captionStem = stem for caption text.
# .
# .
# =================================================================================================

Stat.plotPairedHistograms <- function(ax1,
                                      ax2,
                                      abreak,
                                      acol,
                                      agroup,
                                      xlab,
                                      flagSameScale = TRUE,
                                      captionStem)
{


       # ....................................................................................
       stopifnot(length(abreak) == 2);
       stopifnot(length(acol) == 2);
       stopifnot(length(agroup) == 2);              
       # ....................................................................................  

       
       # ....................................................................................
       # . Add transparency to the input colors :
       # ....................................................................................
       acolT = Graphics.addTransJST(acol, alpha = 0.35);
       # ....................................................................................
       # . Determine limits for x axis :
       # ....................................................................................
       xmin = min(ax1, ax2);
       xmax = max(ax1, ax2);

       n1 = length(ax1);
       n2 = length(ax2);

       #xx caption = paste(captionStem, " (n1 = ", n1, ", n2  = ", n2, ")", sep = "");
       caption = captionStem;
       # ....................................................................................



       
       # ..................................................................................
       # . Put the histograms on the SAME scale :
       # ..................................................................................
       if (flagSameScale) {
         # ......................................................................
         # . DRY RUN to determine y axis limits :
         # ......................................................................
         h1 = hist(ax1,
                   breaks = abreak[1],
                   plot = FALSE);

         h2 = hist(ax2,
                   breaks = abreak[2],
                   plot = FALSE);

         ymin = 0.0;
         ymax = max(h1$counts, h2$counts);
         # ......................................................................
         # . Histogram #1 :
         # ......................................................................
         h1 = hist(ax1,
                   breaks = abreak[1],
                   xlim = c(xmin, xmax),
                   ylim = c(0, ymax),
                   main = caption,
                   xlab = xlab,
                   border = acol[1],
                   col = acolT[1],
                   lwd = 2);
       
         par(new = TRUE);
         # ......................................................................
         # . Histogram #2 :
         # ......................................................................
         h2 = hist(ax2,
                   breaks = abreak[2],
                   xlim = c(xmin, xmax),
                   ylim = c(0, ymax),
                   main = '',
                   xlab = '',
                   border = acol[2],
                   col = acolT[2],
                   lwd = 2,
                   xaxt = 'n',
                   yaxt = 'n');
         
         par(new = FALSE);
         # ......................................................................
         # . Add legend :
         # ......................................................................
         abuf1 = paste(agroup[1], " (", n1, ")", sep = "");
         abuf2 = paste(agroup[2], " (", n2, ")", sep = "");         
         legendText = c(abuf1, abuf2);
         colVector = acol;
         ltyVector = c(1, 1);
         lwdVector = c(1, 1);
         pchVector = rep(19, times = 2);

         legend(x = xmin + 0.75 * (xmax - xmin),
                y = ymin + 0.9 * (ymax - ymin),
                legend = legendText, 
                col = colVector,
                pch = pchVector,
                bty = 'n');
         # ......................................................................         
       }
       # ..................................................................................


       # ..................................................................................
       # . Put the histograms on the DIFFERENT scales (so that
       # . they appear to have the same height) :
       # ..................................................................................
       if (!flagSameScale) {
         # ......................................................................
         # . Histogram #1 :
         # ......................................................................
         h1 = hist(ax1,
                   breaks = abreak[1],
                   xlim = c(xmin, xmax),
                   main = caption,
                   xlab = xlab,
                   border = acol[1],
                   col = acolT[1],
                   lwd = 2);
       
         par(new = TRUE);
         # ......................................................................
         # . Histogram #2 :
         # ......................................................................
         h2 = hist(ax2,
                   breaks = abreak[2],
                   xlim = c(xmin, xmax),
                   main = '',
                   xlab = '',
                   border = acol[2],
                   col = acolT[2],
                   lwd = 2,
                   xaxt = 'n');
         par(new = FALSE);
         # ......................................................................
         # . Add legend :
         # ......................................................................
         ymin = 0.0;
         ymax = max(h2$counts);
         abuf1 = paste(agroup[1], " (", n1, ")", sep = "");
         abuf2 = paste(agroup[2], " (", n2, ")", sep = "");         
         legendText = c(abuf1, abuf2);
         colVector = acol;
         ltyVector = c(1, 1);
         lwdVector = c(1, 1);
         pchVector = rep(19, times = 2);

         legend(x = xmin + 0.75 * (xmax - xmin),
                y = ymin + 0.9 * (ymax - ymin),
                legend = legendText, 
                col = colVector,
                pch = pchVector,
                bty = 'n');
         
         # ......................................................................
       }
       # ..................................................................................



       

       # ...........
       return (0);
       # ...........

}

# =================================================================================================
# . End of Stat.plotPairedHistograms.
# =================================================================================================





# =============================================================================================================
# . Stat.scatterPlotWithMarginalHistograms :  makes a scatter plot with marginal histograms.
# . --------------------------------------    
# .
# .  Syntax :
# .
# .      cl = Stat.scatterPlotWithMarginalHistograms(ax,
# .                                                  ay,
# .                                                  nbreak,
# .                                                  acol = NULL,
# .                                                  xlab,
# .                                                  ylab,
# .                                                  caption,
# .                                                  flagColorBack = FALSE,
# .                                                  ...);
# .
# . In :
# .               ax = array of x values.
# .               ay = array of y values.
# .            nbreak = number of breaks for the histograms.
# .              acol = colors for the points. If NULL, all points are black.
# .              xlab = label for x axis.
# .              ylab = label for x axis.
# .           caption = caption.
# .     flagColorBack = if TRUE, add light beige background.
# .
# . Out :
# .
# .          cl = list containing x and y histogram objects.
# .
# =============================================================================================================

Stat.scatterPlotWithMarginalHistograms <- function(ax,
                                                   ay,
                                                   nbreak,
                                                   acol = NULL,
                                                   xlab,
                                                   ylab,                                                   
                                                   caption,
                                                   flagColorBack = FALSE,
                                                   ...)
{


       # ....................................................................................
       stopifnot(length(ay) == length(ax));

       if (!is.null(acol)) {
         stopifnot(length(acol) == length(ax));         
       } else {
         acol = rep('black', length(ax));
       }
       # ....................................................................................  

       
       # ....................................................................................  
       def.par = par(no.readonly = TRUE);      # Save default, for resetting.
       # ....................................................................................
       
       
       # ...................................................................................................................
       # . Use layout() to make a scatter plot with marginal histograms (Crawley, p.860) :
       # . 
       # . >> 1. Create the histograms without plotting :
       # ...................................................................................................................
       hx = hist(ax, breaks = nbreak, plot = FALSE);
       hy = hist(ay, breaks = nbreak, plot = FALSE);

       top = max(c(hx$counts, hy$counts));

       xrange = c(min(ax, na.rm = TRUE), max(ax, na.rm = TRUE));
       yrange = c(min(ay, na.rm = TRUE), max(ay, na.rm = TRUE));       
       # ...................................................................................................................
       # . >> 2. Build the layout :
       # ...................................................................................................................
       am = matrix(c(3, 1, 0, 2), nrow = 2, ncol = 2, byrow = TRUE);
       nf = layout(mat = am, widths = c(1, 3), heights = c(3, 1), respect = TRUE);        # We are ready for plotting.
       
       #>> layout.show(nf);                                                               # For debug only, to see the prospective layout.
       # ...................................................................................................................
       # . >> 3. Make the actual plots here :
       # . a. Scatter plot :
       # ...................................................................................................................
       bg.OLD = par("bg");
       
       if (flagColorBack) {
         colIn = "sandybrown";
         colIn = "#FFFF00";
         col1 =  Graphics.addTransJST(colIn, alpha = 0.1);
         par(bg = col1);
       }
       
       mar.OLD = par("mar");

       plot(ax, ay,
            pch = 19,
            xlim = xrange, ylim = yrange,
            xlab = xlab, ylab = ylab,
            col = acol,
            main = caption, ...);
       abline(v = 0 , h = 0);

       rug(ax, side = 1, col = 'darkgray');
       rug(ay, side = 2, col = 'darkgray');
       # ...................................................................................................................              
       # . b. Bottom histogram :
       # ...................................................................................................................
       mar1 = mar.OLD;
       mar1[3] = 0;
       par(mar = mar1);
       #xx barplot(hx$counts, ylim = c(0, top), space = 0, ylab = 'Count');
       hx = hist(ax, breaks = nbreak, xlab = '', ylab = 'Count', main = '');
       abline(v = 0);
       # ...................................................................................................................              
       # . c. Left histogram :
       # . Note that horiz = TRUE does not work with hist().
       # ...................................................................................................................              
       mar2 = mar.OLD;
       mar2[4] = 3;
       par(mar = mar2);
       #xx barplot(hy$counts, xlim = c(0, top), space = 0, horiz = TRUE, xlab = 'Count');   
       plot(NULL, type = "n", xlim = c(0, max(hy$counts)), ylim = yrange,
            xlab = 'Count', ylab = '', main = '');
       rect(0,
            hy$breaks[1:(length(hy$breaks) - 1)],
            hy$counts,
            hy$breaks[2:length(hy$breaks)])
       abline(h = 0);

       par(bg = bg.OLD);                
       par(mar = mar.OLD);

       par(def.par);             # Reset to default
       # ...................................................................................................................


       # ................................
       cl = list(hx = hx, hy = hy);
       # ................................


       # ............
       return (cl);
       # ............

}

# =============================================================================================================
# . End of Stat.scatterPlotWithMarginalHistograms.
# =============================================================================================================






# =============================================================================================================
# . Stat.treillisBoxplots : generates a {classes * genes} trellis of boxplots, with each boxplot showing
# . ---------------------   the distribution of expression levels for the corresponding gene over the
# .                         members of the corresponding class.
# .
# .  Syntax :
# .
# .      cl = Stat.trellisBoxplots(dfX,
# .                                ac,
# .                                type = 'boxplot',
# .                                xlab,
# .                                ylab,
# .                                caption,
# .                                rngSeed = 123456,
# .                                flagColorBack = FALSE, ...);
# .
# . In :
# .
# .             dfX = {n * p} data matrix in samples * genes geometry.
# .              ac = classification of the samples. Length must be same as number of rows in dfX.
# .            type = type of plot. Valid: 'boxplot', 'violinplot'.
# .            xlab = label for x-axis (typically 'genes'). The number of genes gets appended automatically.
# .            ylab = label for y-axis (i.e. a label for the classification scheme). The number of classes gets
# .                   appended automatically.
# .         caption = caption.
# .         rngSeed = seed for generating class-by-class color assignments.
# .   flagColorBack = if TRUE, add light beige background.
# .       cex.class = size of class labels.
# .        cex.gene = size of gene labels.
# . orientGeneLabel = if 'right', foot of gene lables is on the right. if 'left'  it  is on the left.
# .
# . Out :
# .
# .
# =============================================================================================================

Stat.trellisBoxplots <- function(dfX,
                                 ac,
                                 type = 'boxplot',
                                 xlab,
                                 ylab,
                                 caption,
                                 rngSeed = 123456,
                                 flagColorBack = FALSE,
                                 cex.class = 1.3,
                                 cex.gene = 1.3,
                                 orientGeneLabel = 'right',
                                 cex.main = 1.5,
                                 ...)
{


      # ...........................................................................
      # . Check values :
      # ...........................................................................
      stopifnot(length(ac) == nrow(dfX));
      stopifnot((type == 'boxplot') || (type == 'violinplot'));
      stopifnot((orientGeneLabel == 'right') || (orientGeneLabel == 'left'));
      # ...........................................................................



      # ............................................................................................................
      # . Get basic attributes :
      # ............................................................................................................      
      acu = sort(unique(ac));                         # Non-redundant list of class labels.
      ncu = length(acu);                              # Number of distinct class labels.

      ag = colnames(dfX);                             # List of genes, same order as in data matrix.
      p = ncol(dfX);                                  # Number of genes.
      # ............................................................................................................


      
      # ............................................................................................................
      # . Check against extravagant requests :      
      # ............................................................................................................     
      if (p > Stat.PMAX_FOR_TRELLIS_BOXPLOTS) {
        cat("ERROR: from Stat.trellisBoxplots:\n");
        cat("The number of genes p = ", p,
            " is greater than max allowed Stat.PMAX_FOR_TRELLIS_BOXPLOTS = ", Stat.PMAX_FOR_TRELLIS_BOXPLOTS,
            "\n", sep = "");
        stop();
      }

      if (ncu > Stat.NCUMAX_FOR_TRELLIS_BOXPLOTS) {
        cat("ERROR: from Stat.trellisBoxplots:\n");
        cat("The number of classes ncu = ", ncu,
            " is greater than max allowed Stat.NCUMAX_FOR_TRELLIS_BOXPLOTS = ", Stat.NCUMAX_FOR_TRELLIS_BOXPLOTS,
            "\n", sep = "");
        stop();
      }      
      # ............................................................................................................



      # ............................................................................................................
      # . Generate colors for the classes :
      # ............................................................................................................
      cw = Graphics.makeColorWheelOnArray(acu,
                                          flagAllBlack = 'no',
                                          flagSortNumerical = FALSE,
                                          flagShuffle = TRUE,
                                          rngSeed = rngSeed);
      # ............................................................................................................



      
      # ............................................................................................................
      # . Initialize some graphics parameters :
      # ............................................................................................................
      fig.OLD = c(0, 1, 0, 1);

      bg.OLD = par("bg");
       
      if (flagColorBack) {
        colIn = "#FFFF00";
        col1 =  Graphics.addTransJST(colIn, alpha = 0.1);
        par(bg = col1);
      }
      # .............................................................................................................



      # .............................................................................................................
      # . Tabulate frequencies and add to class labels :
      # .............................................................................................................
      ff1 = table(ac);                       # Tabulate.
      an = ff1[acu];                         # Frequencies in same order as sorted class labels.
      anbuf = sprintf("%6.0f", an);          # Formatted frequencies.
      acuText = paste(acu, " : ", anbuf, sep = "");
      # .............................................................................................................
      


      # ...................................................................................................................
      # . Build the layout :
      #. >> Preamble :
      # ...................................................................................................................
      nbig = ncu * p;                                                  # Total number of plot cells.
      aorder = 1:nbig;                                                 # Order in which to build the plots.

      am = matrix(aorder, nrow = ncu, ncol = p, byrow = FALSE);        # The trellis be filled in column-major order.
      # ...................................................................................................................
      # . am is now {ncu * p}.
      # . Left-hand-border :
      # ...................................................................................................................      
      nbig1 = nbig + 1;
      nbig2 = nbig + ncu;
      abuf = nbig1:nbig2;
      apad = matrix(abuf, nrow = ncu, ncol = 1);
      am = cbind(apad, am);
      # ...................................................................................................................
      # . am is now {ncu * (p + 1)}.
      # . Top-border :
      # ...................................................................................................................
      nbig21 = nbig2 + 1;
      nbig3 = nbig2 + p;
      abuf = c(0, nbig21:nbig3);
      apad = matrix(abuf, nrow = 1 , ncol = p + 1);
      am = rbind(apad, am);
      # ...................................................................................................................
      # . am is now {(ncu + 1) * (p + 1)}.
      # . Bottom-border :
      # ...................................................................................................................
      nbig31 = nbig3 + 1;
      nbig4 = nbig3 + p;
      abuf = c(0, nbig31:nbig4);
      apad = matrix(abuf, nrow = 1 , ncol = p + 1);
      am = rbind(am, apad);
      # ...................................................................................................................
      # . am is now {(ncu + 2) * (p + 1)}.
      # . Right-hand border :
      # ...................................................................................................................
      abuf = rep(0, ncu + 2);
      apad = matrix(abuf, nrow = ncu + 2 , ncol = 1);
      am = cbind(am, apad);
      # ...................................................................................................................
      # . am is now {(ncu + 2) * (p + 2)}.
      # . Now for the actual layout :
      # ...................................................................................................................                  
      aw = c(5, rep(1, p), 0.5);                                     # Widths of cells.
      ah = rep(1, ncu + 2);                                          # Heights of cells.
      
      nf = layout(mat = am,
                  widths = aw,
                  heights = ah,
                  respect = FALSE);                                  # We are now ready for plotting.
       
      layout.show(nf);                                               # For debug only, to see the prospective layout.      
      # ............................................................................................................
      # .  Example for a 10 class * 5 gene layout :
      # .
      # .             [,1] [,2] [,3] [,4] [,5] [,6] [,7]
      # .        [1,]    0   61   62   63   64   65    0
      # .        [2,]   51    1   11   21   31   41    0
      # .        [3,]   52    2   12   22   32   42    0
      # .        [4,]   53    3   13   23   33   43    0
      # .        [5,]   54    4   14   24   34   44    0
      # .        [6,]   55    5   15   25   35   45    0
      # .        [7,]   56    6   16   26   36   46    0
      # .        [8,]   57    7   17   27   37   47    0
      # .        [9,]   58    8   18   28   38   48    0
      # .       [10,]   59    9   19   29   39   49    0
      # .       [11,]   60   10   20   30   40   50    0
      # .       [12,]    0   66   67   68   69   70    0
      # .    
      # . Gather the {class * gene} values :
      # ............................................................................................................
      lbuf = apply(dfX, 2, function(x){tapply(x, ac, FUN = function(y){y})});
      # ............................................................................................................
      # . Find gene-by-gene maxima and minima :
      # ............................................................................................................
      axmax = apply(dfX, 2, max, na.rm = TRUE);
      axmin = apply(dfX, 2, min, na.rm = TRUE);
      axmin = ifelse(axmin > 0.0, 0.0, axmin);
      # ............................................................................................................
      # . Build the plots one-by-one, column-major order :
      # ............................................................................................................
      mar.OLD = par("mar");
      amarBuf = c(0, 0, 0, 0);
      par(mar = amarBuf);

      xrangeText = c();
      flagFirst = TRUE;                                 # Toggle for warning messages.
      
      for (j in 1:p) {
        gene = ag[j];                                   # Gene name.
        al = lbuf[[gene]];                              # List of data for that gene.
        xrange = c(axmin[gene], axmax[gene]);

        temp1 = round(axmin[gene], digits = 1);
        temp2 = round(axmax[gene], digits = 1);       
        xrangeText[j] = paste("[", temp1, ", ", temp2, "]", sep = "");        
        
        for (i in 1:ncu) {
          cl = acu[i];               # Class name.
          ax = al[[cl]]              # Numerical values.
          col = cw$colorWheel[cl];
          col1 =  Graphics.addTransJST(col, alpha = 0.2);

          if (i ==  ncu) {
            temp1 = 'n';                   # Induces a "Noop"  if this is 'n'. Set to 's' for tick marks on bottom margins of bottom row.
          } else {
            temp1 = 'n';            
          }
          # ........................................................................................................
          # . Boxplots :
          # ........................................................................................................
          if (type == 'boxplot') {
            buf = boxplot(ax,
                          horizontal = TRUE,
                          ylim = xrange,
                          xaxt = temp1,
                          col = col1,
                          pch = 19);
            box(col = "black");                       # Redundant here if col = 'black'. Place holder in case we want to change the color.
          }
          # ........................................................................................................
          # . Violin plots :
          # ........................................................................................................
          if (type == 'violinplot') {
            ax1 = ax;                           # Default is identity.
            # ......................................................................................................
            # . May have to deal with all-equal values. Fix with this kludge :
            # ......................................................................................................            
            if (min(ax) == max(ax)) {
              ax1 = jitter(ax, amount = Stat.EPS_FOR_TRELLIS_BOXPLOTS);             # May be needed to avoid error.

              if (flagFirst) {
                cat("WARNING: from Stat.trellisBoxplots: ");                
                cat("adding jitter Stat.EPS_FOR_TRELLIS_BOXPLOTS = ",
                    Stat.EPS_FOR_TRELLIS_BOXPLOTS, " to numerical values to break ties ",
                    "(only first warning printed).\n", sep = "");
                flagFirst = FALSE;
              }
            }
            # ......................................................................................................
            # . Now the plot itself :
            # ......................................................................................................            
            buf = plot(1, 1,
                       xlim = xrange,
                       ylim = c(-0.5, 0.5),
                       axes = FALSE, xaxt = 'n', yaxt = 'n', xlab = "", ylab = "");
            buf = vioplot(ax1,
                          horizontal = TRUE, 
                          at = 0,
                          col= col1, 
                          border= "black", 
                          rectCol ="gray", 
                          colMed = "black", 
                          pchMed = 19,
                          drawRect = TRUE,
                          add = TRUE);
            abline(v = 0.0, col = "gray");
            # ......................................................................................................            
          }
          # ........................................................................................................          
        }
      }

      par(mar = mar.OLD);      
      # ............................................................................................................
      # . Add the class names, one-by-one, to left :
      # ............................................................................................................
      for (i in 1:ncu) {
        cl = acuText[i];               # Class name + frequency.
        amarBuf = c(0, 0, 0, 0);
        par(mar = amarBuf);
        plot(0:1, 0:1, xaxt = 'n', yaxt = 'n', axes = FALSE, type = 'n');
        text(1.0, 0.5, cl, pos = 2, cex = cex.class)
      }

      par(mar = mar.OLD);
      # ............................................................................................................
      # . Add the gene names, one-by-one, to top :
      # ............................................................................................................
      for (j in 1:p) {
        gene = ag[j];               # Gene name.        
        amarBuf = c(0, 0, 0, 0);
        par(mar = amarBuf);
        plot(0:1, 0:1, xaxt = 'n', yaxt = 'n', axes = FALSE, type = 'n');

        if (orientGeneLabel == 'right') {
          text(0.5, 0.0, gene, pos = 4, cex = cex.gene, srt = 90);
        } else if (orientGeneLabel == 'left') {
          text(0.5, 0.0, gene, pos = 2, cex = cex.gene, srt = -90);
        }
      }

      par(mar = mar.OLD);
      # ............................................................................................................
      # . Add the gene expression ranges, one-by-one, to bottom :
      # ............................................................................................................
      for (j in 1:p) {
        amarBuf = c(0, 0, 0, 0);
        par(mar = amarBuf);
        plot(0:1, 0:1, xaxt = 'n', yaxt = 'n', axes = FALSE, type = 'n');

        if (orientGeneLabel == 'right') {
          text(0.5, 0.75, xrangeText[j], pos = 1, cex = 0.7 * cex.gene, srt = 90);
        } else if (orientGeneLabel == 'left') {
          text(0.5, 0.75, xrangeText[j], pos = 4, cex = 0.7 * cex.gene, srt = -90);
        }
      }

      par(mar = mar.OLD);                  
      # ............................................................................................................      


      # ....................................
      # . Restore :
      # ....................................
      par(bg = bg.OLD);                      
      par(fig = fig.OLD);
      # ....................................


      # .............................................................................
      temp1 = paste("\n\n", caption, sep = "");
      title(main = temp1, outer = TRUE, cex.main = cex.main);
      # .............................................................................
      
      
      # ............
      return (0);
      # ............

}

# =============================================================================================================
# . End of Stat.treillisBoxplots.
# =============================================================================================================








# =============================================================================================================
# . Stat.computeRowMeanAndSDevinChunks :  computes the row means and standard devs of a data frame in chunks of
# . ----------------------------------    rows. To be used for very large data matrices.
# .                  
# .  Syntax :
# .
# .       cr = Stat.computeRowMeanAndSDevinChunks(dfX, nchunk = 20);
# .
# .  In :
# .
# .         dfX = input data matrix.
# .
# .      nchunk = number of chunks to be used.
# .
# . Out :
# .
# .       cr = list, with members :
# .
# .               axm = row means.
# .               asd = row standard devs.
# .   
# =============================================================================================================

Stat.computeRowMeanAndSDevinChunks  <- function(dfX, nchunk = 20)
{

      
      # ....................................................................................
      # . Process chunk-by-chunk :
      # ....................................................................................      
      index0 = 1:nrow(dfX);
      afac = cut(index0, nchunk);
      lbuf = split(index0, afac);

      lbuf.axm = list();
      lbuf.asd = list();      
      
      for (i in 1:nchunk) {
        cat(">> Processing for mean and sd: chunk ", i, " out of ", nchunk, ".\n", sep ="");

        dfX.buf = dfX[lbuf[[i]], ];
        lbuf.axm[[i]] = apply(dfX.buf, 1, mean);
        lbuf.asd[[i]] = apply(dfX.buf, 1, sd);        
      }
      # ....................................................................................
      # . Collect into single arrays :
      # ....................................................................................      
      axm = unlist(lbuf.axm);
      asd = unlist(lbuf.asd);
      # ....................................................................................


      # ...........................................
      # . Package into a list :
      # ...........................................
      cr = list(axm = axm,
                asd = asd);
      # ...........................................      


      # .............
      return (cr);
      # .............
      
}

# =============================================================================================================
# . End of Stat.computeRowMeanAndSDevinChunks.
# =============================================================================================================




# =============================================================================================================
# . Stat.computeQuantileOnThresholdinChunks :  computes quantiles on a threshold in chunks of COLUMNS.
# . ---------------------------------------    To be used for very large data matrices.
# .                  
# .  Syntax :
# .
# .      ax = Stat.computeQuantileOnThresholdinChunks(dfX, xc, probs = 0.75, nchunk = 20);
# .
# .  In :
# .
# .         dfX = input data matrix.
# .          xc = threshold.
# .       probs = quantile to be computed.
# .      nchunk = number of chunks to be used.
# .
# . Out :
# .
# .       ax = array with results.
# .
# .............................................................................................................
# . Example :
# .
# .      axp75 = Stat.computeQuantileOnThresholdinChunks(dfX, xc =  0, probs = 0.75, nchunk = 20);
# .
# . returns the same result as :
# .
# .       axp75 = apply(dfX, 2, function(x){quantile(x[x > 0], probs = 0.75);});         # xp75.
# .
# =============================================================================================================

Stat.computeQuantileOnThresholdinChunks  <- function(dfX, xc, probs = 0.75, nchunk = 20)
{


      # ....................................................................................
      stopifnot((probs >= 0.0) & (probs <= 1.0));
      # ....................................................................................  

      # ....................................................................................
      # . Shortcut if nchunk = 1 :
      # ....................................................................................    
      if (nchunk == 1) {
        ax = apply(dfX, 2, function(x){quantile(x[x > xc], probs = probs);});
      }
      # ....................................................................................
      # . Process chunk-by-chunk :
      # ....................................................................................
      if (nchunk > 1) {      
        index0 = 1:ncol(dfX);
        afac = cut(index0, nchunk);
        lbuf = split(index0, afac);

        lbuf.ax = list();
      
        for (i in 1:nchunk) {
          cat(">> Processing for quantile: chunk ", i, " out of ", nchunk, ".\n", sep ="");

          dfX.buf = dfX[  , lbuf[[i]]];
          lbuf.ax[[i]] = apply(dfX.buf, 2, function(x){quantile(x[x > xc], probs = probs);});
        }
        # ....................................................................................
        # . Collect into single arrays :
        # ....................................................................................      
        ax = unlist(lbuf.ax);
        # ....................................................................................
      }
      # ........................................................................................


      # .............
      return (ax);
      # .............
      
}

# =============================================================================================================
# . End of Stat.computeQuantileOnThresholdinChunks.
# =============================================================================================================




# =============================================================================================================
# . Stat.computePresentGenesOnThresholdinChunks :  computes numbers of present genes on a threshold in chunks of COLUMNS.
# . -------------------------------------------    To be used for very large data matrices.
# .                  
# .  Syntax :
# .
# .      anp = Stat.computePresentGenesOnThresholdinChunks(dfX, xc, nchunk = 20);
# .
# .  In :
# .
# .         dfX = input data matrix.
# .          xc = threshold.
# .      nchunk = number of chunks to be used.
# .
# . Out :
# .
# .       anp = array with results.
# .
# =============================================================================================================

Stat.computePresentGenesOnThresholdinChunks  <- function(dfX, xc, probs = 0.75, nchunk = 20)
{


      # ....................................................................................
      stopifnot((probs >= 0.0) & (probs <= 1.0));
      # ....................................................................................  

      # ....................................................................................
      # . Shortcut if nchunk = 1 :
      # ....................................................................................    
      if (nchunk == 1) {
       anp = apply(dfX, 2, function(x){length(x[x > xc]);});                           # number present.
      }
      # ....................................................................................
      # . Process chunk-by-chunk :
      # ....................................................................................
      if (nchunk > 1) {      
        index0 = 1:ncol(dfX);
        afac = cut(index0, nchunk);
        lbuf = split(index0, afac);

        lbuf.anp = list();
      
        for (i in 1:nchunk) {
          cat(">> Processing for present genes: chunk ", i, " out of ", nchunk, ".\n", sep ="");

          dfX.buf = dfX[  , lbuf[[i]]];
          lbuf.anp[[i]] = apply(dfX.buf, 2, function(x){length(x[x > xc]);});                           # number present.          
        }
      }
      # ....................................................................................
      # . Collect into single arrays :
      # ....................................................................................      
      anp = unlist(lbuf.anp);
      # ....................................................................................



      # .............
      return (anp);
      # .............
      
}

# =============================================================================================================
# . End of Stat.computePresentGenesOnThresholdinChunks.
# =============================================================================================================







# =============================================================================================================
# . Stat.computePowerOfDetectionOnBinomial : computes the power of detecting hypothesis H2 versus H1 when
# . --------------------------------------   n samples are avilable and we are couting a binary outcome in
# .                                          each.
# .
# . Syntax :
# .
# .      apow = Stat.computePowerOfDetectionOnBinomial(n, q1, q2, alpha = 0.05);
# .
# . In :
# .       n = number of samples (can be an array of values);
# .
# .      q1 = probability of event under H1.
# .
# .      q2 = probability of event under H2. One must have q2 >= q1.
# .
# .   alpha = one-tailed confidenec level for testing q2 > q1.
# .
# . Out :
# .
# .   apow = power value(s) corresponding to n.
# .
# =============================================================================================================


Stat.computePowerOfDetectionOnBinomial <- function(n, q1, q2, alpha = 0.05)
{

     # ........................................................................
     stopifnot(q2 >= q1);         
     stopifnot((alpha > 0) && (alpha < 1));
     # ........................................................................     

     # ........................................................................     
     k1_alpha = qbinom(alpha, size = n, prob = q1, lower.tail = FALSE);
     pow = pbinom(k1_alpha, size = n, prob = q2, lower.tail = FALSE);
     # ........................................................................     


     # .....................
     return(pow);
     # .....................     

}

# =============================================================================================================
# . End of Stat.computePowerOfDetectionOnBinomial.
# =============================================================================================================






# =============================================================================================================
# . Stat.basicROCplusOneClassOnly : generates ROC sensitivity and false-positive arrays, given an input
# . -----------------------------   score vector and {0, 1} true classification. Special use function,
# .                                 extends Stat.basicROC by allowing casese with only one type of class
# .                                 instances in input.
# . Syntax :
# .
# .      roc = Stat.basicROCplusOneClassOnly(ax, ac, flagPval, flagConfInterval, flagNormalModel, prob = 0.95);
# .
# . In:
# .        ax = vector of prognostic indices, such that the estimate of P(y = 1|x) is
# .             given by the logit function :
# .
# .                                     1
# .                  P(y = 1|x) = ---------------
# .                                1 + exp(- ax)
# .
# .             or equivalently,
# .
# .                         P(y = 1|x)
# .                  log ----------------- =  ax
# .                       1 - P(y = 1|x)
# .
# .             IF ax is not a prognostic index, then the AUC and ROC calculations are
# .             still valid, but not any of the predictions predicated in MAP class
# .             assignments, the latter being simply :
# .
# .                             0 if x < 0
# .                   ayPred =
# .                             1 if x >= 0.
# .
# . 
# .        ac = vector of true class assignments. Values must be in {0,1}.
# .
# .              For a fixed threshold xc, the classifier is:
# .
# .                           --
# .                           | 0 ,   x <= xc
# .                   C(x) =  |
# .                           | 1 ,   x > xc.
# .                           --
# .
# .              i.e. class 1 is associated with a ``large'' positive score.
# .
# .
# .     * The following flags are used to turn off the corresponding options when doing
# .        bootstrap calculations. The default options are that the calculations get done.
# .
# .                flagPval = if TRUE, compute the P-value based on the Wilcoxon rank-sum test.
# .                           if FALSE, return NULL member.
# .
# .        flagConfInterval = if TRUE, compute confidence intervals for both the null hypothesis
# .                           and for the actual sensitivity profile. If FALSE, do not compute
# .                           these, and return NULL members.
# .
# .       flagNormalModel = if TRUE, compute the ROC corresponding to the assumption of
# .                           a normal distribution for samples taken from each two classes;
# .                           if FALSE, return NULL members.
# .
# .                  prob = probability for confidence interval (default = 0.95).
# .
# . Out:
# .       roc = list, with members :
# .
# =========================================================================================================

Stat.basicROCplusOneClassOnly <- function(ax, ac,
                                          flagPval = TRUE,
                                          flagConfInterval = TRUE,
                                          flagNormalModel = TRUE,
                                          prob = 0.95)
{

     # ...................................
     stopifnot(prob > 0.0, prob < 1.0);
     # ...................................
     
  
     # ..................................................................................
     n = length(ax);       # Number of samples.
     nc = length(ac);      # Number of class labels (must be the same).
     
     if (nc != n) {
       cat("ERROR: from Stat.basicROCplusOneClassOnly: length of class labels vector not same as score vector.\n");
       stop();
     }

     abuf = unique(ac) %in% c(0,1)

     if (length(which(abuf == FALSE)) > 0) {
       cat("ERROR: from Stat.basicROCplusOneClassOnly: some class labels are neither 0 nor 1.\n");
       stop();
     }

     n1 = sum(ac);         # Number of members in class = 1.
     n0 = n - n1;          # Number of members in class = 0.

     if (n1 == 0) {
       cat("Note: from Stat.basicROCplusOneClassOnly: 0 members with class 1.\n");
       cat("Sensitivity will be assigned a dummy value of 0.\n");
     }

     if (n0 == 0) {
       cat("Note: from Stat.basicROCplusOneClassOnly: 0 members with class 0.\n");
       cat("FP rate will be assigned a dummy value of 0.\n");
     }
     # ..................................................................................



     # ..............................................................................................
     # . >> 1. General case with n0, n1 != 0 :
     # ..............................................................................................
     if ((n0 > 0) & (n1 > 0)) {
       roc = Stat.basicROC(ax, ac,
                           flagPval = flagPval,
                           flagConfInterval = flagConfInterval,
                           flagNormalModel = flagNormalModel,
                           prob = prob);
     }
     # ..............................................................................................
     # . >> 2. Case with n0 = 0, n1 > 0 :
     # ..............................................................................................
     if ((n0 == 0) & (n1 > 0)) {
       xmin = min(ax, na.rm = TRUE);
       xmax = max(ax, na.rm = TRUE);

       xl1 = xmin - 0.1 *(xmax - xmin);
       xl2 = xmin - 0.2 *(xmax - xmin);

       axBuf = c(xl2, xl1, ax);
       acBuf = c(0, 0, ac);       
       
       roc = Stat.basicROC(axBuf, acBuf,
                           flagPval = flagPval,
                           flagConfInterval = flagConfInterval,
                           flagNormalModel = flagNormalModel,
                           prob = prob);
     }
     # ..............................................................................................
     # . >> 3. Case with n0 > 0,  n1 = 0 :
     # ..............................................................................................
     if ((n0 > 0) & (n1 == 0)) {
       xmin = min(ax, na.rm = TRUE);
       xmax = max(ax, na.rm = TRUE);

       xr1 = xmax + 0.1 *(xmax - xmin);
       xr2 = xmax + 0.2 *(xmax - xmin);

       axBuf = c(ax, xr1, xr2);
       acBuf = c(ac, 1, 1);       
       
       roc = Stat.basicROC(axBuf, acBuf,
                           flagPval = flagPval,
                           flagConfInterval = flagConfInterval,
                           flagNormalModel = flagNormalModel,
                           prob = prob);
     }     
     # ..............................................................................................       


     
     # .............
     return (roc);
     # .............
  
}
  
# ============================================================================================================
# . End of Stat.basicROCplusOneClassOnly.
# ============================================================================================================
