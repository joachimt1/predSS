# =====================================================================================
# .  DataFrame.r: simple wrappers for reading into and writing from data frames
# .  -----------  plus several utility functions.
# .
# =====================================================================================

library(data.table);                        # For function fread().
#xxx library(Matrix);

# =======================================================================================
# . DataFrame.read : reads a file into a data frame. Alias for read.table.
# . --------------
# .
# .               df = DataFrame.read(fin);
# .
# .    IN:
# .          fin = input file (full path).
# .    OUT:
# .          df = output data frame.
# .
# =======================================================================================

DataFrame.read <- function(fin)
{

	# .............................................................
	if (!is.character(fin)) {
	   msg = cat("ERROR: from DataFrame.read: fin parameter = ", 
	             fin, " is not of type character.\n");
	   stop(msg);
	}
	# .............................................................


	# .............................................................
      	cat(" ..........  Reading input file: ", fin, "\n");
   	# .............................................................


	# ....................................................
	df = read.table(fin);
	# ....................................................


	# ...............
	return (df);
        # ...............

}

# =======================================================================================
# . End of DataFrame.read.
# =======================================================================================


# =======================================================================================
# . DataFrame.readDataMatrix : reads a numerical data matrix in a number of different 
# . ------------------------   input formats, returns a data frame in canonical format
# .                            with rows corresponding to samples and columns corresponding
# .                            to features.
# .
# .  Syntax :
# .               dfX = DataFrame.readDataMatrix(fin);
# .
# .  In :
# .          fin = input file (full path). Allowed extensions: DF, DFV, FLAT.
# .
# .                - For extension DF, the input file rows (= samples) are mapped to the 
# .                output data frame rows, and the input file columns (= features) 
# .                are mapped to the output data frame columns.
# .
# .                - For extensions DFV and FLAT, the input file is transposed relative to
# .                the output data frame : the input file rows (= features) are mapped to the 
# .                the output data frame columns, and the input file columns (= samples) 
# .                are mapped to the output data frame rows.
# .
# .  Out :
# .          dfX = output data frame : rows = samples, columns = features.
# .
# =======================================================================================

DataFrame.readDataMatrix <- function(fin)
{


      # ....................................................................
      # . Determine the extension for the input file :
      # ....................................................................
      ext = "";   # Placeholder.
      
      if (length(grep("\\.DF$", fin, perl = TRUE)) == 1) {
        ext = 'DF';
      } else if (length(grep("\\.DFV$", fin, perl = TRUE)) == 1) {
        ext = 'DFV';
      } else if (length(grep("\\.FLAT$", fin, perl = TRUE)) == 1) {
        ext = 'FLAT';
      } else {
        cat("ERROR: from DataFrame.readDataMatrix:\n");
        cat("Invalid extension for input file fin = ", fin, "\n", sep = "");
        cat("Valid extensions: DF, DFV, FLAT.\n");
        stop();
      }
      # .....................................................................
        

      # .............................................................
      # . Read file in accordance with format :
      # .............................................................      
      if (ext == 'DF') {
        dfX = read.table(fin);
      }

      if (ext == 'DFV') {
        dfX = read.table(fin);
        dfX = t(dfX);           # Transpose to standard data frame format.
      }

      if (ext == 'FLAT') {
        dfX = DataFrame.readFlat(fin);
      }
      # ..............................................................


      # ...............
      return (dfX);
      # ...............

}

# =======================================================================================
# . End of DataFrame.readDataMatrix.
# =======================================================================================





# =======================================================================================
# . DataFrame.readDataMatrixFread : reads a numerical data matrix in a number of different 
# . -----------------------------   input formats, returns a data frame in canonical format
# .                                 with rows corresponding to samples and columns corresponding
# .                                 to features.
# .
# . Note: this is the SAME as DataFrame.readDataMatrix, but uses the much faster fread() for
# .       reading FLAT files.
# .
# .
# .  Syntax :
# .               dfX = DataFrame.readDataMatrixFread(fin);
# .
# .  In :
# .          fin = input file (full path). Allowed extensions: DF, DFV, FLAT.
# .
# .                - For extension DF, the input file rows (= samples) are mapped to the 
# .                output data frame rows, and the input file columns (= features) 
# .                are mapped to the output data frame columns.
# .
# .                - For extensions DFV and FLAT, the input file is transposed relative to
# .                the output data frame : the input file rows (= features) are mapped to the 
# .                the output data frame columns, and the input file columns (= samples) 
# .                are mapped to the output data frame rows.
# .
# .  Out :
# .          dfX = output data frame : rows = samples, columns = features.
# .
# =======================================================================================

DataFrame.readDataMatrixFread <- function(fin)
{


      # ....................................................................
      # . Determine the extension for the input file :
      # ....................................................................
      ext = "";   # Placeholder.
      
      if (length(grep("\\.DF$", fin, perl = TRUE)) == 1) {
        ext = 'DF';
      } else if (length(grep("\\.DFV$", fin, perl = TRUE)) == 1) {
        ext = 'DFV';
      } else if (length(grep("\\.FLAT$", fin, perl = TRUE)) == 1) {
        ext = 'FLAT';
      } else {
        cat("ERROR: from DataFrame.readDataMatrixFread:\n");
        cat("Invalid extension for input file fin = ", fin, "\n", sep = "");
        cat("Valid extensions: DF, DFV, FLAT.\n");
        stop();
      }
      # .....................................................................
        

      # .............................................................
      # . Read file in accordance with format :
      # .............................................................      
      if (ext == 'DF') {
        dfX = read.table(fin);
      }

      if (ext == 'DFV') {
        dfX = read.table(fin);
        dfX = t(dfX);           # Transpose to standard data frame format.
      }

      if (ext == 'FLAT') {
	#xxxx        dfX = DataFrame.readFlat(fin);
        dfX = DataFrame.readFlatFread(fin);
      }
      # ..............................................................


      # ...............
      return (dfX);
      # ...............

}

# =======================================================================================
# . End of DataFrame.readDataMatrixFread.
# =======================================================================================







# =======================================================================================
# . DataFrame.readFlat : reads a numerical data matrix in FLAT file format.
# . ------------------   Note that the input file is transposed relative to the output
# .                      data frame.
# .                      
# .
# .  Syntax :
# .               dfX = DataFrame.readFlat(fin);
# .
# .  In :
# .          fin = input file (full path). Allowed extension: FLAT
# .
# .                - For extension FLAT, the input file is transposed relative to
# .                the output data frame : the input file rows (= features) are mapped to the 
# .                the output data frame columns, and the input file columns (= samples) 
# .                are mapped to the output data frame rows.
# .
# .  Out :
# .          dfX = output data frame : rows = samples, columns = features.
# .
# =======================================================================================

DataFrame.readFlat <- function(fin)
{

      # ....................................................................
      # . Check the extension for the input file :
      # ....................................................................
      if (length(grep("\\.FLAT$", fin, perl = TRUE)) == 0) {
        cat("ERROR: from DataFrame.readFlat:\n");
        cat("Invalid extension for input file fin = ", fin, "\n", sep = "");
        cat("Valid extension: FLAT.\n");
        stop();
      }
      # .....................................................................
        

      # .............................................................
      # . Check header :
      # .............................................................      
      buf = scan(fin, what = "character", sep = "\t", nlines = 1);

      if (buf[1] != "#QUAL") {
        cat("ERROR: from DataFrame.readFlat:\n");
        cat("The header in input file fin = ", fin, "\n", sep = "");
        cat("does not start with #QUAL\n");
        stop();
      }
      # .............................................................
      # . Read table, set row names to first column, which contains
      # . the qualifier names :
      # .............................................................      
      dfBuf = read.table(fin, header = TRUE, comment.char = "",
                         quote = "", check.names = FALSE);

      n1 = ncol(dfBuf);      # Number of samples + 1.
      dfX = dfBuf[ , 2:n1];
      rownames(dfX) = dfBuf[ , 1];

      dfX = t(dfX);          # Put into standard data frame format.
      # ..............................................................


      # .............
      return (dfX);
      # .............

}

# =======================================================================================
# . End of DataFrame.readFlat.
# =======================================================================================






# =======================================================================================
# . DataFrame.readFlatFread : reads a numerical data matrix in FLAT file format.
# . -----------------------   Note that the input file is transposed relative to the output
# .                           data frame.
# .                      
# . Note: this is the SAME as DataFrame.readFlat, but uses the much faster fread() for
# .       reading FLAT files.
# .
# .  Syntax :
# .               dfX = DataFrame.readFlatFread(fin);
# .
# .  In :
# .          fin = input file (full path). Allowed extension: FLAT
# .
# .                - For extension FLAT, the input file is transposed relative to
# .                the output data frame : the input file rows (= features) are mapped to the 
# .                the output data frame columns, and the input file columns (= samples) 
# .                are mapped to the output data frame rows.
# .
# .  Out :
# .          dfX = output data frame : rows = samples, columns = features.
# .
# =======================================================================================

DataFrame.readFlatFread <- function(fin)
{

      # ....................................................................
      # . Check the extension for the input file :
      # ....................................................................
      if (length(grep("\\.FLAT$", fin, perl = TRUE)) == 0) {
        cat("ERROR: from DataFrame.readFlatFread:\n");
        cat("Invalid extension for input file fin = ", fin, "\n", sep = "");
        cat("Valid extension: FLAT.\n");
        stop();
      }
      # .....................................................................
        

      # .............................................................
      # . Check header :
      # .............................................................      
      buf = scan(fin, what = "character", sep = "\t", nlines = 1);

      if (buf[1] != "#QUAL") {
        cat("ERROR: from DataFrame.readFlatFread:\n");
        cat("The header in input file fin = ", fin, "\n", sep = "");
        cat("does not start with #QUAL\n");
        stop();
      }
      # .............................................................
      # . Read table, set row names to first column, which contains
      # . the qualifier names :
      # .............................................................      
      #xxx       dfBuf = read.table(fin, header = TRUE, comment.char = "",
      #xxx                   quote = "", check.names = FALSE);
      #xxx dfBuf = fread(fin, sep = "\t", header = TRUE, verbose = FALSE,
      #xxx               select = NULL, drop = NULL, colClasses = NULL,
      #xxx               showProgress = TRUE, data.table = FALSE);

      dfBuf = fread(fin, sep = "\t", header = TRUE, verbose = FALSE,
                    showProgress = TRUE, data.table = FALSE);
      
      n1 = ncol(dfBuf);      # Number of samples + 1.
      dfX = dfBuf[ , 2:n1];
      rownames(dfX) = dfBuf[ , 1];

      dfX = t(dfX);          # Put into standard data frame format.
      # ..............................................................


      # .............
      return (dfX);
      # .............

}

# =======================================================================================
# . End of DataFrame.readFlatFread.
# =======================================================================================







# =======================================================================================
# . DataFrame.readFlatNoTranspose : reads a numerical data matrix in FLAT file format.
# . -----------------------------   This version, unlike DataFrame.readFlat(), does NOT
# .                                 transpose the input array. It should be used
# .                                 on FLAT data matrices where the rows already
# .                                 correspond to samples, and the columns to features.
# .
# .  Syntax :
# .               dfX = DataFrame.readFlatNoTranspose(fin, checkExt);
# .
# .  In :
# .          fin = input file (full path). Allowed extension: FLAT,
# .                unless checkExt = FALSE, in which case any extension is allowed.
# .
# .          checkExt = TRUE, check that extension is 'FLAT', signal an error if it is not.
# .                     FALSE, any extension is valid.
# .
# .  Out :
# .          dfX = output data frame : rows = samples, columns = features.
# .
# =======================================================================================

DataFrame.readFlatNoTranspose <- function(fin, checkExt = TRUE)
{

      # ....................................................................
      # . Check the extension for the input file :
      # ....................................................................
      ext = File.getExt(fin);

      if (checkExt) {
        if (ext != 'FLAT') {
          cat("ERROR: from DataFrame.readFlatNoTranspose:\n");
          cat("Invalid extension for input file fin = ", fin, "\n", sep = "");
          cat("Valid extension: FLAT.\n");
          stop();
        }
      }
      # .....................................................................

      

      # .............................................................
      # . Check header :
      # .............................................................      
      buf = scan(fin, what = "character", sep = "\t", nlines = 1);

      if (buf[1] != "#QUAL") {
        cat("ERROR: from DataFrame.readFlatNoTranspose:\n");
        cat("The header in input file fin = ", fin, "\n", sep = "");
        cat("does not start with #QUAL\n");
        stop();
      }
      # .............................................................
      # . Read table, set row names to first column, which contains
      # . the qualifier names :
      # .............................................................      
      dfBuf = read.table(fin, header = TRUE, comment.char = "", sep = "\t",
                         quote = "",
                         check.names = FALSE);

      n1 = ncol(dfBuf);      # Number of features + 1.
      dfX = dfBuf[ , 2:n1];
      rownames(dfX) = dfBuf[ , 1];
      # ..............................................................


      # .............
      return (dfX);
      # .............

}

# =======================================================================================
# . End of DataFrame.readFlatNoTranspose.
# =======================================================================================







# =======================================================================================
# . DataFrame.readFlatNoTransposeFread : reads a numerical data matrix in FLAT file format.
# . ----------------------------------   This version, unlike DataFrame.readFlat(), does NOT
# .                                      transpose the input array. It should be used
# .                                      on FLAT data matrices where the rows already
# .                                      correspond to samples, and the columns to features.
# .
# . NOTE: this is a version of DataFrame.readFlatNoTranspose() that uses the data.table
# .       package function fread() which is much faster than read.table().
# .
# .  Syntax :
# .               dfX = DataFrame.readFlatNoTransposeFread(fin, checkExt);
# .
# .  In :
# .          fin = input file (full path). Allowed extension: FLAT,
# .                unless checkExt = FALSE, in which case any extension is allowed.
# .
# .          checkExt = TRUE, check that extension is 'FLAT', signal an error if it is not.
# .                     FALSE, any extension is valid.
# .
# .  Out :
# .          dfX = output data frame : rows = samples, columns = features.
# .
# =======================================================================================

DataFrame.readFlatNoTransposeFread <- function(fin, checkExt = TRUE)
{

      # ....................................................................
      # . Check the extension for the input file :
      # ....................................................................
      ext = File.getExt(fin);

      if (checkExt) {
        if (ext != 'FLAT') {
          cat("ERROR: from DataFrame.readFlatNoTransposeFread:\n");
          cat("Invalid extension for input file fin = ", fin, "\n", sep = "");
          cat("Valid extension: FLAT.\n");
          stop();
        }
      }
      # .....................................................................

      

      # .............................................................
      # . Check header :
      # .............................................................      
      buf = scan(fin, what = "character", sep = "\t", nlines = 1);

      if (buf[1] != "#QUAL") {
        cat("ERROR: from DataFrame.readFlatNoTransposeFread:\n");
        cat("The header in input file fin = ", fin, "\n", sep = "");
        cat("does not start with #QUAL\n");
        stop();
      }
      # .............................................................
      # . Read table, set row names to first column, which contains
      # . the qualifier names :
      # .............................................................
      dfX = fread(fin, sep = "\t", header = TRUE, verbose = FALSE,
                  showProgress = TRUE, data.table = FALSE);

      #xxx    select = NULL, drop = NULL, colClasses = NULL,

      rownames(dfX) = dfX[ , 1];          # Assign gene names to rows.
      n1 = ncol(dfX);                     # = number of features + 1.
      dfX = dfX[ , 2:n1];                 # Remove gene names from body.
      # ..............................................................


      # .............
      return (dfX);
      # .............

}

# =======================================================================================
# . End of DataFrame.readFlatNoTransposeFread.
# =======================================================================================




# =======================================================================================
# . DataFrame.readFlatNoTransposeFreadCsv : reads a numerical data matrix in FLAT file format.
# . -------------------------------------   Comma-separated-values (CSV) file input format is assumed.
# .                                      This version, unlike DataFrame.readFlat(), does NOT
# .                                      transpose the input array. It should be used
# .                                      on FLAT data matrices where the rows already
# .                                      correspond to samples, and the columns to features.
# .
# . NOTE: this is a version of DataFrame.readFlatNoTranspose() that uses the data.table
# .       package function fread() which is much faster than read.table().
# .
# .  Syntax :
# .               dfX = DataFrame.readFlatNoTransposeFreadCsv(fin, checkExt);
# .
# .  In :
# .          fin = input file (full path). Allowed extension: csv, CSV,
# .                unless checkExt = FALSE, in which case any extension is allowed.
# .
# .          checkExt = TRUE, check that extension is csv or CSV', signal an error if it is not.
# .                     FALSE, any extension is valid.
# .
# .  Out :
# .          dfX = output data frame : rows = samples, columns = features.
# .
# =======================================================================================

DataFrame.readFlatNoTransposeFreadCsv <- function(fin, checkExt = TRUE)
{

      # ....................................................................
      # . Check the extension for the input file :
      # ....................................................................
      ext = File.getExt(fin);

      if (checkExt) {
        if ((ext != 'csv') & (ext != 'CSV')) {
          cat("ERROR: from DataFrame.readFlatNoTransposeFreadCsv:\n");
          cat("Invalid extension for input file fin = ", fin, "\n", sep = "");
          cat("Valid extension: csv, CSV.\n");
          stop();
        }
      }
      # .....................................................................

      

      # .............................................................
      # . Check header :
      # .............................................................      
      buf = scan(fin, what = "character", sep = ",", nlines = 1);

      if (buf[1] != "") {
        cat("ERROR: from DataFrame.readFlatNoTransposeFreadCsv:\n");
        cat("The header in input file fin = ", fin, "\n", sep = "");
        cat("does not start with a blank space\n");
        stop();
      }
      # .............................................................
      # . Read table, set row names to first column, which contains
      # . the qualifier names :
      # .............................................................
      dfX = fread(fin, sep = ",", header = TRUE, verbose = FALSE,
                  showProgress = TRUE, data.table = FALSE);

      rownames(dfX) = dfX[ , 1];          # Assign gene names to rows.
      n1 = ncol(dfX);                     # = number of features + 1.
      dfX = dfX[ , 2:n1];                 # Remove gene names from body.
      # ..............................................................


      # .............
      return (dfX);
      # .............

}

# =======================================================================================
# . End of DataFrame.readFlatNoTransposeFreadCsv.
# =======================================================================================







# =======================================================================================
# . DataFrame.write : writes a data frame into a file.
# . ---------------
# .
# .               DataFrame.write(df, fo);
# .
# .    IN:
# .           df = input data frame.
# .           fo = output file (full path).
# .
# =======================================================================================

DataFrame.write <- function(df, fo)
{

	# .................................................................................
	if (class(df) != "data.frame") {
	   msg = cat("ERROR: from DataFrame.write: df parameter is not of a data frame.\n");
	   stop(msg);
	}

	if (!is.character(fo)) {
	   msg = cat("ERROR: from DataFrame.write: fo parameter = ", 
	             fo, " is not of type character.\n");
	   stop(msg);
	}
	# ..................................................................................



   	# ...................................
	nr = nrow(df);        # Rows.
	nc = ncol(df);        # Columns.

	rowName = rownames(df);
	colName = colnames(df);
   	# ...................................



   	# .............................................................
	FO = file(fo, "w");
      	cat(" ..........  Writing to output file: ", fo, "\n");
   	# .............................................................


   	# .............................................................
	# . Print the header:
   	# .............................................................
	line = paste(colName, collapse = "\t");
	line = paste("\t", line, "\n", sep = "");
	cat(line, file = FO);
	# .............................................................
	# . Print the body:
   	# .............................................................
	dfMat = as.matrix(df);

	for (i in 1:nr) {
	    rowBuf = as.character(dfMat[i, ]);
	    line = paste(rowBuf, collapse = "\t");
	    line = paste(rowName[i], "\t", line, "\n", sep = "");

	    cat(line, file = FO);
	}
   	# .............................................................



	# .............................................................................
	close(FO);
      	cat(" ..........  Data frame written to file : ", fo, "\n");
   	# .............................................................................


}

# =======================================================================================
# . End of DataFrame.write.
# =======================================================================================





# =======================================================================================
# . DataFrame.writeWithQual : writes a data frame into a file. Includes a ``qualifier''
# . -----------------------   string in the first position of the first line of
# .                           text.
# .
# .               DataFrame.write(df, qualName, fo);
# .
# .    IN:
# .           df = input data frame.
# .           qualName = name used to identify the first column.
# .           fo = output file (full path).
# .
# =======================================================================================

DataFrame.writeWithQual <- function(df, qualName, fo)
{

	# .................................................................................
	if (class(df) != "data.frame") {
	   msg = cat("ERROR: from DataFrame.writeWithQual: df parameter is not of a data frame.\n");
	   stop(msg);
	}

	if (!is.character(fo)) {
	   msg = cat("ERROR: from DataFrame.writeWithQual: fo parameter = ", 
	             fo, " is not of type character.\n");
	   stop(msg);
	}
	# ..................................................................................



   	# ...................................
	nr = nrow(df);        # Rows.
	nc = ncol(df);        # Columns.

	rowName = rownames(df);
	colName = colnames(df);
   	# ...................................



   	# .............................................................
	FO = file(fo, "w");
      	cat(" ..........  Writing to output file: ", fo, "\n");
   	# .............................................................


   	# .............................................................
	# . Print the header:
   	# .............................................................
	line = paste(colName, collapse = "\t");
	line = paste(qualName, "\t", line, "\n", sep = "");
	cat(line, file = FO);
	# .............................................................
	# . Print the body:
   	# .............................................................
	dfMat = as.matrix(df);

	for (i in 1:nr) {
	    rowBuf = as.character(dfMat[i, ]);
	    line = paste(rowBuf, collapse = "\t");
	    line = paste(rowName[i], "\t", line, "\n", sep = "");

	    cat(line, file = FO);
	}
   	# .............................................................



	# .............................................................................
	close(FO);
      	cat(" ..........  Data frame written to file : ", fo, "\n");
   	# .............................................................................


}

# =======================================================================================
# . End of DataFrame.writeWithQual.
# =======================================================================================





# ======================================================================================
# . DataFrame.replaceMissingValues : replaces missing values in the input data frame
# . ------------------------------   by their column averages.
# .
# . Note that the data frame format used here is specialied to the ``classifiers''
# . flavor: column names staring with ``factor_'' explicitly denote factor columns.
# . All other columns are de facto columns for the numerical data matrix.
# .
# ======================================================================================

DataFrame.replaceMissingValues <- function(df)
{

	# ...............................................................................
	# . Separate numerical data from factors:
	# ...............................................................................
	acName = colnames(df);
	acPrefix = substr(acName, 1, 7);

	dfFactor = df[acPrefix == "factor_"];       # Only factor columns.
	dfNum = df[acPrefix != "factor_"];          # Get the numerical data matrix.
	ncolNum = ncol(dfNum);                      # Number of columns in data matrix.
	# ...............................................................................


	# ...............................................................................
	# . Replace NAs by the corresponding column averages:
	# ...............................................................................
	acMean = colMeans(dfNum, na.rm = TRUE);     # Build column averages ignoring NAs.

	for (j in 1:ncolNum) {
	    colBuf = dfNum[ , j];                   # Column vector.
	    colBuf[is.na(colBuf)] = acMean[j   ]    # Replace NAs by means.
	    dfNum[ , j] = colBuf;                   # Swap back.
	}
	# ...............................................................................


	# .....................................
	# . Package output data frame:
	# .....................................
	dfOut = cbind(dfFactor, dfNum);
	# .....................................


	# ................
	return (dfOut);
	# ................

}

# ======================================================================================
# . End of DataFrame.replaceMissingValues.
# ======================================================================================





# =======================================================================================
# . DataFrame.writeToLABEL : writes a data frame representing an ED into a file.
# . ----------------------   in the generic Gecko LABEL format.
# .                          
# .
# .           DataFrame.writeToLABEL(df, prefixName = "label_", fo);
# .
# .    IN:
# .           dfED = input data frame contining only factors.
# .           prefixName = name used to identify the factors in the output file header.
# .                        Options are:
# .
# .                         '', do not introduce any prefix.
# .                         'label_', replace each prefix 'factor_' by the
# .                                   'label_', add 'label_' de novo for items
# .                                   which do not have it.
# .                         'factor_', do not change 'factor_' prefix if present,
# .                                    add it de novo if not present.
# .
# .           fo = output file (full path).
# .
# .......................................................................................
# . Example:condider the following ED:
# . >> dfED:
# .
# .     factor_well factor_op factor_comp factor_dose factor_row factor_col
# .  A1          A1      mean        DMSO        10nM          A          1
# .  A2          A2      mean         NGF       100nM          A          2
# .  B1          B1      mean        BDNF        10nM          B          1
# .  B2          B2      mean         NGF        50nM          B          2
# .
# .
# .
# =======================================================================================

DataFrame.writeToLABEL <- function(df, prefixName = "label_", fo)
{

	# .................................................................................
	if (class(df) != "data.frame") {
	   msg = paste("ERROR: from DataFrame.writeToLABEL: df parameter is not of a data frame.\n");
	   stop(msg);
	}

	if (!is.character(fo)) {
	   msg = paste("ERROR: from DataFrame.writeToLABEL: fo parameter = ", 
                       fo, " is not of type character.\n");
	   stop(msg);
	}

        if ((nchar(prefixName) != 0)
            && (prefixName != 'label_')
            && (prefixName != 'factor_')) {
          msg = paste("ERROR: from DataFrame.writeToLABEL: prefixName = ",
	             prefixName, " is not valid.\n");
          msg = paste(msg, "Valid options: null string, label_, factor_\n");
          stop(msg);
	}
	# ..................................................................................



   	# ...................................
	nr = nrow(df);        # Rows.
	nc = ncol(df);        # Columns.

	rowName = rownames(df);
	colName = colnames(df);
   	# ...................................


        # .........................................................................
        # . Add prefix to column names if indicated:
        # .........................................................................
        if (nchar(prefixName) > 0) {
          if (prefixName == "label_") {
            colName = gsub("^factor_", "", colName, perl = TRUE);
            ap = rep("label_", times = nc);
            colName = paste(ap, colName, sep = "");
            colName[1] = paste("#", colName[1], sep = "");   # Leading # sign.
          }

          if (prefixName == "factor_") {
            colName = gsub("^factor_", "", colName, perl = TRUE);
            colName = gsub("^label_", "", colName, perl = TRUE);
            ap = rep("factor_", times = nc);
            colName = paste(ap, colName, sep = "");
            colName[1] = paste("#", colName[1], sep = "");   # Leading # sign.
          }
        }
        # .........................................................................



   	# .............................................................
	FO = file(fo, "w");
      	#xxx cat(" ..........  Writing to output file: ", fo, "\n");
   	# .............................................................


   	# .............................................................
	# . Print the header:
   	# .............................................................
	line = paste(colName, collapse = "\t");
	cat(line, file = FO);
        cat("\n", file = FO);
	# .............................................................
	# . Print the body:
   	# .............................................................
	dfMat = as.matrix(df);

	for (i in 1:nr) {
	    rowBuf = as.character(dfMat[i, ]);
	    line = paste(rowBuf, collapse = "\t");
	    cat(line, file = FO);
            cat("\n", file = FO);
	}
   	# .............................................................



	# .............................................................................
	close(FO);
      	#xxx cat(" ..........  Data frame written to file : ", fo, "\n");
   	# .............................................................................


}

# =======================================================================================
# . End of DataFrame.writeToLABEL.
# =======================================================================================






# =======================================================================================
# . DataFrame.writeFlat : writes a data frame into a file in a tab-separated spreadsheet 
# . -------------------   format, with *no* tab-indented first line.
# .
# .  Syntax :
# .
# .          DataFrame.writeFlat(dfIn, fo, na = "NA",
# .                              flagQual = FALSE, append = FALSE,
# .                              header = TRUE);
# .
# .  In:
# .
# .         dfIn = input data frame.
# .           fo = output file.
# .           na = literal symbol to write NAs.
# .     flagQual = if TRUE, add a first column with header '#QAL' that will
# .                contain the row names.
# .       append = if TRUE, append to existing file.
# .       header = if TRUE, include header (column names) in file, else omit.
# .
# .  Note that this does *not* automatically write out the data frame row names. 
# .  Use flagQual = TRUE to write out the row names as first column under header '#QUAL'.
# .
# =======================================================================================

DataFrame.writeFlat <- function(dfIn,
                                fo,
                                na = "NA",
                                flagQual = FALSE,
                                append = FALSE,
                                header = TRUE)
{

     # ..........................................................................................
     if (flagQual) {
       dfBuf = data.frame("#QUAL" = rownames(dfIn), dfIn, check.names = FALSE);
       write.table(dfBuf, file = fo,
                   append = append,
                   quote = FALSE,
                   sep = "\t", na = na,
                   row.names = FALSE, col.names = header)   # No quotes, no row names, but do
                                                            # use col names if specified.
     } else {
       write.table(dfIn, file = fo,
                   append = append,
                   quote = FALSE,
                   sep = "\t", na = na,
                   row.names = FALSE, col.names = header)   # No quotes, no row names, but do
                                                            # use col names if specified.
     }
     # ............................................................................................


     # ...........
     return (0);
     # ...........

}

# =======================================================================================
# . End of DataFrame.writeFlat.
# =======================================================================================





# =======================================================================================
# . DataFrame.writeFlatBig : writes a data frame into a file in a tab-separated spreadsheet 
# . ----------------------   format, with *no* tab-indented first line.
# .
# .                          Note: this is for typically LARGE data frames containing
# .                          only numerical data. Always writes the qualifier column
# .                          using the row names.
# .
# .  Syntax :
# .
# .              DataFrame.writeFlatBig(dfIn, fo, na = "NA");
# .
# .  In:
# .
# .         dfIn = input data frame.
# .           fo = output file.
# .           na = literal symbol to write NAs.
# .
# =======================================================================================

DataFrame.writeFlatBig <- function(dfIn, fo, na = "NA")
{


   	# .........................................................................
	# . Open the output file :
   	# .........................................................................
        FO = file(fo, "w");
        cat(" ..........  Writing to output file: ", fo, "\n");
   	# .........................................................................


        # .........................
        ta = proc.time()[3];
        # .........................     



   	# .........................................................................
	# . Print just the table header:
   	# .........................................................................
	colName = colnames(dfIn);
	header = paste(colName, collapse = "\t");
        header = paste("#QUAL\t", header, sep = "");
	cat(header, "\n", sep = "", file = FO);
	close(FO);
   	# .........................................................................


        # ..................................................................................
        write.table(as.matrix(dfIn), file = fo, append = TRUE, quote = FALSE, sep = "\t",
                    eol = "\n", na = na, row.names = TRUE, col.names = FALSE);
        # ..................................................................................


	# ..............................
        tb = proc.time()[3] - ta;
	# ..............................


	# .............................................................................
  	cat(" ..........  Data frame written to file : ", fo, "\n", sep = "");
  	cat(" ..........  Total processing time : ", tb, " s. \n", sep = "");
        # .............................................................................


        # ...........
        return (0);
        # ...........

}

# =======================================================================================
# . End of DataFrame.writeFlatBig.
# =======================================================================================






# =======================================================================================
# . DataFrame.writeDataMatrix : writes a data frame containing numerical data to a 
# . -------------------------   file in a tab-separated spreadsheet format, with format
# .                             determined by the file extension.
# .
# .  Syntax :
# .
# .          DataFrame.writeDataMatrix(dfIn, fo);
# .
# .  In:
# .          dfIn = input data frame.
# .          fo = output file.
# .
# .  Allowed output file extensions : DF, DFV, FLAT.
# .
# .    DF : write in literal data frame format, with first line starting with indented tab.
# .         rows = samples, columns = features.
# .   DFV : write in ``vertical'' data frame format, with first line starting with indented tab.
# .         The body of the data is transposed, with now rows = features, columns = samples.
# .  FLAT : similar to DFV, but with no first line tab indentation. Instead, the first
# .         line starts with the key word #QUAL.
# .
# =======================================================================================

DataFrame.writeDataMatrix <- function(dfIn, fo)
{

      # ....................................................................
      # . Determine the extension for the input file :
      # ....................................................................
      ext = "";   # Placeholder.
      
      if (length(grep("\\.DF$", fo, perl = TRUE)) == 1) {
        ext = 'DF';
      } else if (length(grep("\\.DFV$", fo, perl = TRUE)) == 1) {
        ext = 'DFV';
      } else if (length(grep("\\.FLAT$", fo, perl = TRUE)) == 1) {
        ext = 'FLAT';
      } else {
        cat("ERROR: from DataFrame.writeDataMatrix:\n");
        cat("Invalid extension for input file fo = ", fo, "\n", sep = "");
        cat("Valid extensions: DF, DFV, FLAT.\n");
        stop();
      }
      # .....................................................................

  
      # .........................................................................
      if (ext == 'DF') {
        write.table(dfIn, file = fo, quote = FALSE, sep = "\t",
                    row.names = TRUE, col.names = TRUE);
      } else if (ext == 'DFV') {
        dfBuf = t(dfIn);
        write.table(dfBuf, file = fo, quote = FALSE, sep = "\t",
                    row.names = TRUE, col.names = TRUE);
      } else if (ext == 'FLAT') {
        dfBuf = t(dfIn);
        ar = rownames(dfBuf);                    # Row names.
        dfOut = cbind(ar, dfBuf);                # Row names and numerical data.
        colnames(dfOut) = c('#QUAL', colnames(dfBuf));
        DataFrame.writeFlat(dfOut, fo);
      }
      # .........................................................................


      # ...........
      return (0);
      # ...........

}

# =======================================================================================
# . End of DataFrame.writeDataMatrix.
# =======================================================================================




# =======================================================================================
# . DataFrame.filterOnQlist :  filters columns on the input qualifier list.
# . -----------------------
# . Syntax:
# .
# .    dfOut = DataFrame.filterOnQlist(dfX, aq);
# .
# . In:
# .
# .    dfX = input matrix or data frame.
# .     aq = input qlist.
# .
# . Out :
# .
# .   dfOut = output matrix, columns subsetted to the ones specified in aq.
# .
# =======================================================================================

DataFrame.filterOnQlist <- function(dfX, aq)
{


      # ...............................................................
      if (length(aq) == 0) {
        cat("ERROR: from DataFrame.filterOnQlist:\n");
        cat("Input qlist array aq is empty.\n");
        msg = "";
        stop(msg);
      }

      if ((class(dfX) != 'matrix') && (class(dfX) != 'data.frame')) {
        cat("ERROR: from DataFrame.filterOnQlist:\n");
        cat("Input dfX is neither a matrix nor a data frame.\n");
        cat("class(dfX) = ", class(dfX), "\n");
        msg = "";
        stop(msg);
      }
      
      # ................................................................

      

      # ..............................................................................
      ac = colnames(dfX);

      indexBuf = match(aq, ac);
      indexBuf = indexBuf[!is.na(indexBuf)];            # Subset to only the matches.

      if (length(indexBuf) == 0) {
        cat("ERROR: from DataFrame.filterOnQlist:\n");
        cat("I found 0 matches between the input qlist array\n");
        cat("and the column names in the target data matrix.\n");
        msg = " no matches found.";
        stop(msg);
      }

      if (length(indexBuf) >= 2) {
        dfOut = dfX[ , indexBuf];
      } else {
        if (class(dfX) == 'matrix') {
          dfOut = as.matrix(dfX[ ,indexBuf]);
        } else if (class(dfX) == 'data.frame') {
          dfOut = as.data.frame(dfX[ ,indexBuf]);
        }

        rownames(dfOut) = rownames(dfX);
        colnames(dfOut) = ac[indexBuf];
      }
      # ...............................................................................


      # ...............
      return (dfOut);
      # ...............

}

# =======================================================================================
# . End of DataFrame.filterOnQlist.
# =======================================================================================



# =======================================================================================
# . DataFrame.generateTextNum : generates a text representation of an all-numerical
# . -------------------------   data frame.
# .
# . Syntax :
# .
# .  txt = DataFrame.generateTextNum(dfIn, fmt);
# .
# . In:
# .
# .   dfIn = input data frame, with only numerical columns.
# .    fmt = character string specifying format. E.g. "%5.3e".
# .
# . Out:
# .
# .   txt = text tabular representation, with rows and column names included.
# .
# =======================================================================================

DataFrame.generateTextNum <- function(dfIn, fmt)
{

     # ........................................................................
     xBuf = apply(dfIn, 2, function(r){sprintf(fmt, r);})         # Convert entries to desired format.

     buf1 = apply(xBuf, 1, paste, collapse = "\t");               # Paste within each row.
     buf2 = paste(rownames(dfIn), "\t", buf1, sep = "");          # Prepend row name to each row.
     buf3 = paste(buf2, collapse = "\n");                         # Join with CRs.
     buf4 = paste(colnames(dfIn), collapse = '\t', sep = '');     # Paste column names.
     buf4 = paste('\t', buf4, sep = '');                          # Prepend tab.
     buf5 = paste(buf4, '\n', buf3, '\n', sep = '');              # Join all.

     txtSummary = buf5;                                           # Final output.
     # ........................................................................


     # ...................
     return (txtSummary);
     # ...................
     
}

# =======================================================================================
# . End of DataFrame.generateTextNum.
# =======================================================================================







# =======================================================================================================
# . DataFrame.makeIntoOneColumn : converts a numeric vector into a single-column data frame.
# . ---------------------------   Used to reverse spurious automatic conversion into numeric.
# .
# .    
# =======================================================================================================

DataFrame.makeIntoOneColumn <- function(ax, colname)
{
  
     # ........................................................
     stopifnot(is.numeric(ax));
     # ........................................................


     # ........................................................     
     dfX = data.frame("buf" = ax, row.names = names(ax));
     colnames(dfX)[1] = colname;
     # ........................................................

     # ................
     return (dfX);
     # ................

}

# =======================================================================================================
# . End of DataFrame.makeIntoOneColumn.
# =======================================================================================================




# =======================================================================================================
# . DataFrame.makeIntoOneRow : converts a numeric vector into a single-row data frame.
# . ------------------------- Used to reverse spurious automatic conversion into numeric.
# .
# .    
# =======================================================================================================

DataFrame.makeIntoOneRow <- function(ax, rowname)
{
  
     # ........................................................
     stopifnot(is.numeric(ax));
     # ........................................................


     # ........................................................     
     dfX = data.frame("buf" = ax, row.names = names(ax));
     colnames(dfX)[1] = rowname;        # Pre-transpose.
     dfX = t(dfX);
     # ........................................................

     # ................
     return (dfX);
     # ................

}

# =======================================================================================================
# . End of DataFrame.makeIntoOneRow.
# =======================================================================================================





# =======================================================================================
# . DataFrame.readFromLABEL : reads a file in the generic Gecko LABEL format.
# . -----------------------   Strips label_ prefixes from the column names before
# .                           returning a data frame.
# .
# .           dfL = DataFrame.readFromLABEL(fl);
# .
# .    IN:
# .           fl = input LABEL file.
# .
# =======================================================================================

DataFrame.readFromLABEL <- function(fl)
{

	# ...................................................................................................
        dfL = read.table(fl, sep = "\t", comment.char = '', quote = "", header = TRUE, check.names = FALSE);
        abuf = colnames(dfL);
        abuf = gsub("\\#", "", abuf);
        abuf = gsub("label_", "", abuf);
        colnames(dfL) = abuf;
   	# ....................................................................................................


        # ............
        return (dfL);
        # ............

}

# =======================================================================================
# . End of DataFrame.readFromLABEL.
# =======================================================================================




# =======================================================================================
# . DataFrame.readTable : just a wrapper for read.table() with my favorite options set.
# . -------------------  
# .
# .  Syntax :
# .
# .          dfA = DataFrame.readTable(fA);
# .
# .  In :
#  .          fA = input file (full path).
# .
# .  Out :
# .          dfA = output data frame.
# .
# =======================================================================================

DataFrame.readTable <- function(fA)
{

      # ...................................................................................................
      dfA = read.table(fA, sep = "\t", comment.char = '', quote = "", header = TRUE, check.names = FALSE);
      # ...................................................................................................

      
      # .............
      return (dfA);
      # .............

}

# =======================================================================================
# . End of DataFrame.readTable.
# =======================================================================================




# =======================================================================================
# . DataFrame.readTableFread : just a wrapper for fread() with my favorite options set.
# . ------------------------
# .
# .  Syntax :
# .
# .          dfA = DataFrame.readTableFread(fA);
# .
# .  In :
#  .          fA = input file (full path).
# .
# .  Out :
# .          dfA = output data frame.
# .
# =======================================================================================

DataFrame.readTableFread <- function(fA)
{

      # ...................................................................................................
      dfA = fread(fA, sep = "\t", header = TRUE, verbose = FALSE,
                  showProgress = TRUE, data.table = FALSE);

      #xx select = NULL, drop = NULL, colClasses = NULL,
      # ...................................................................................................

      
      # .............
      return (dfA);
      # .............

}

# =======================================================================================
# . End of DataFrame.readTableFread.
# =======================================================================================



# =======================================================================================
# . DataFrame.readTableNoHeader : just a wrapper for read.table() with my favorite options set.
# . ---------------------------   This version fro no-header tables.  
# .
# .  Syntax :
# .
# .          dfA = DataFrame.readTableNoHeader(fA);
# .
# .  In :
#  .          fA = input file (full path).
# .
# .  Out :
# .          dfA = output data frame.
# .
# =======================================================================================

DataFrame.readTableNoHeader <- function(fA)
{

      # ...................................................................................................
      dfA = read.table(fA, sep = "\t", comment.char = '', quote = "", header = FALSE, check.names = FALSE);
      # ...................................................................................................

      
      # .............
      return (dfA);
      # .............

}

# =======================================================================================
# . End of DataFrame.readTableNoHeader.
# =======================================================================================




# =======================================================================================
# . DataFrame.writeFlatAndLabel : for a given numerical data frame dfX and companion
# . ---------------------------   expDesign dfE, writes contents to FLAT and LABEL
# .                               format files, respectively.
# .
# .  Syntax :
# .
# .      fn =  DataFrame.writeFlatAndLabel(dfX, dfE, fX);
# .
# .  In :
# .
# .         dfX = numerical data frame (p * n = genes * samples format).
# .         dfE = companion expDesign (n * k, where k = number of factors).
# .               Note that we must have nrow(dfE) = ncol(dfX).
# .          fX = name of FLAT output file. Must have extension FLAT.
# .               The name of the companion LABEL file is automatically
# .               generated by replacing the FLAT extension by the LABEL extension.
# .
# .  Out :
# .          fn = list with members :
# .
# .                     fX = input FLAT file name.
# .                     fE = name of companion LABEL file.
# .
# =======================================================================================

DataFrame.writeFlatAndLabel <- function(dfX, dfE, fX)
{

      # ...................................................................................................
      # . Check on input :
      # ...................................................................................................
      n = ncol(dfX);
      ne = nrow(dfE);

      if (ne != n) {
        cat("ERROR: from DataFrame.writeFlatAndLabel:\n");
        cat("The number ne of rows in dfE is not the same as the number n of columns in dfX.\n");
        cat("ne = ", ne, " n = ", n, "\n", sep = "");
        stop();
      }

      ext = File.getExt(fX);

      if (ext != 'FLAT') {
        cat("ERROR: from DataFrame.readFlatNoTranspose:\n");
        cat("Invalid extension for output file fX = ", fX, "\n", sep = "");
        cat("Valid extension: FLAT.\n");
        stop();
      }
      # ...................................................................................................

      
      # .............................................................
      # . File name for companion LABEL file :
      # .............................................................            
      fE = gsub("\\.FLAT$", "\\.LABEL", fX, perl = TRUE);
      # .............................................................


      # .............................................................
      # . Write to files here :
      # .............................................................      
      DataFrame.writeFlat(dfX, fX, flagQual = TRUE);
      DataFrame.writeToLABEL(df = dfE, fo = fE);
      # .............................................................

      
      # ...............................
      fn = list(fX = fX, fE = fE);
      # ...............................
      

      # .............
      return (fn);
      # .............

}

# =======================================================================================
# . End of DataFrame.writeFlatAndLabel.
# =======================================================================================






# =======================================================================================
# . DataFrame.readFlatAndLabel : simultaneously reads a FLAT file and its companion
# . --------------------------   ed file, provided they have the same stem name
# .                              and reside in the same directory.
# .                              
# .
# .  Syntax :
# .
# .      fl = DataFrame.readFlatAndLabel(fX);
# .
# .  In :
# .
# .          fX = name of FLAT output file. Must have extension FLAT.
# .               The name of the companion LABEL file is automatically
# .               generated by replacing the FLAT extension by the LABEL extension.
# .
# .  Out :
# .
# .     fl = list with members :
# .
# .                 dfX = numerical data matrix
# .                 dfE = expdesign.
# .
# =======================================================================================

DataFrame.readFlatAndLabel <- function(fX)
{

      # ...................................................................................................
      # . Check on input :
      # ...................................................................................................
      ext = File.getExt(fX);

      if (ext != 'FLAT') {
        cat("ERROR: from DataFrame.readFlatNoTranspose:\n");
        cat("Invalid extension for input file fX = ", fX, "\n", sep = "");
        cat("Valid extension: FLAT.\n");
        stop();
      }
      # ...................................................................................................

      
      # .............................................................
      # . File name for companion LABEL file :
      # .............................................................            
      fE = gsub("\\.FLAT$", "\\.LABEL", fX, perl = TRUE);
      # .............................................................      


      # .............................................................
      # . Check that the expdesign file exists :
      # .............................................................      
      if (!file.exists(fE)) {
        cat("ERROR: from DataFrame.readFlatNoTranspose:\n");
        cat("I could not find companion expdesign file fE = ", fE, "\n", sep = "");
        stop();
      }      
      # .............................................................


      # .............................................................
      # . Read here :
      # .............................................................      
      dfE = DataFrame.readFromLABEL(fE);
      dfX = DataFrame.readFlatNoTransposeFread(fX);      
      #xx DataFrame.writeToLABEL(df = dfE, fo = fE);
      # .............................................................



      # ...................................
      # . Package results :
      # ...................................
      fl = list(dfX = dfX,
                dfE = dfE);
      # ...................................
      

      # .............
      return (fl);
      # .............

}

# =======================================================================================
# . End of DataFrame.readFlatAndLabel.
# =======================================================================================

