# =====================================================================================
# .  Rdat.r: utility functions for reading the CDAT format files into 
# .  ------  an R data frame.
# .
# =====================================================================================


# =======================================================================================
# . Rdat.read : reads an RDAT format file into a data frame. Checks for the presence
# . ---------   of essential fields.
# .
# .               ar = Rdat.read(fr);
# .
# .    IN:
# .          fr = RDAT input file (full path).
# .    OUT:
# .          ar = output Rdat object.
# .
# .......................................................................................
# .  RDAT file format:
# .
# .       311_AT  204_AT  202_AT  209_AT   qual	     y         training     group    test 
# .  Q1	  1.5     2.5     3.4     1.0      taxol_1   1.56      y	    taxol    NONE 
# .  Q2	  0.7     1.1     1.5     0.9      taxol_2   1.32      y	    taxol    NONE 
# .  Q3	  5.5     4.2     1.5     0.7      campto_1  0.42      y	    campto   NONE 
# .  Q4	  2.3     3.7     2.5     1.1      campto_4  0.27      y	    campto   NONE 
# .  Q5	  8.3     1.7     2.5     1.1      doxo_1    0.12      y	    doxo     NONE 
# .  Q6	  3.3     2.4     3.5     1.0      doxo_17   0.27      y	    doxo     NONE 
# .  Q7	  2.3     3.7     2.5     1.1      flavo_5   3.51      NONE	    NONE     flavo
# .  Q8	  7.0     2.7     3.1     2.1      flavo_2   2.78      NONE	    NONE     flavo
# .
# .
# .
# .  * Compulsory fields:
# .
# .     qual        : ``qualifier''; absolute name for this data entry.
# .                   Note that the input row names (here denoted by Q1, . . . )
# .                   are merely duumies, and are always replaced by the
# .                   qual names in the final data frame.
# .
# .     y           : actual response variable.
# .
# .
# .  * Optional fields:
# .
# .     training    : factor that determines which part of the data is to be used
# .                   for the training set. Can never be all-NONE.
# .                   An entry of NONE always excludes the instance.
# .                   Instances for all other instances are always included. If
# .                   this field is absent, it is added to the data frame, with 
# .                   all instances in the training set. 
# .
# .     group       : factor used for grouping instances in logo, or for otherwise
# .                   labeling output. Can be all-NONE. If absent, this field is 
# .                   added to the data frame with all-NONE entries.  
# .
# .     test        : factor that determines which part of the data is to be used
# .                   as a test set. Can be all-NONE.
# .                   If absent, this field is added to the data frame
# .                   with all-NONE entries. If present, a check is done to insure 
# .                   that all non-NONE entries corespond to NONE entries in the
# .                   training set (to avoid inconsistency).
# .
# .......................................................................................
# . Rdat members:
# .
# .     ad          = data frame, with predictor variables, response variable,
# .                   training set, group set and test set entries.
# .
# .     flagGroup   = TRUE, if there are non-NONE group entries, 
# .                   FALSE otherwise.
# .
# .     flagTest    = TRUE, if there are non-NONE test entries, 
# .                   FALSE otherwise.
# .
# .
# =======================================================================================

Rdat.read <- function(fr)
{

	# ....................................................................
	if (!is.character(fr)) {
	   msg = cat("ERROR: from Rdat.read: fr parameter = ", fr, " is not of type character.\n");
	   stop(msg);
	}
	# ....................................................................


	# .............................................................
      	cat(" ..........  Reading iput file: ", fr, "\n");
   	# .............................................................


	# ....................................................................
	ad = read.table(fr);

	nr = nrow(ad);
	nc = ncol(ad);

      	cat(" ..........  Found: nr = ", nr, " rows\n");
      	cat("                    nc = ", nc, " columns.\n");
	# ....................................................................



	# .....................................................................................
	# . Check for the required fields:
	# .....................................................................................
	ac = colnames(ad);                # Column names.	

	if (length(ac[ac == "qual"]) == 0) {
	   msg = cat("ERROR: from Rdat.read: I did not qual column in the input file.\n");
	   stop(msg);
	}

	if (length(ac[ac == "y"]) == 0) {
	   msg = cat("ERROR: from Rdat.read: I did not find y column in the input file.\n");
	   stop(msg);
	}
	# ....................................................................................


	# ....................................................................................
	# . Training set field: 
	# ....................................................................................
	if (length(ac[ac == "training"]) == 0) {
	    training = rep("y", nr);
	    ad = cbind(ad, training);     # If not present, add an all-present training set field.
	}

	abuf = ad$training;               # Training set column.

	if (length(abuf[abuf != "NONE"]) == 0) {
	   msg = cat("ERROR: from Rdat.read: no non-NONE levels in training set field.\n");
	   stop(msg);	   
	}
	# ....................................................................................


	# ....................................................................................
	# . Group field:
	# ....................................................................................
	if (length(ac[ac == "group"]) == 0) {
	    group = rep("NONE", nr);
	    ad = cbind(ad, group);     # If not present, add an all-NONE group set field.
	}

	abuf = ad$group;               # Group set column.

	if (length(abuf[abuf != "NONE"]) == 0) {
	   flagGroup = FALSE;
	} else {
	   flagGroup = TRUE;
	}
	# ....................................................................................



	# ....................................................................................
	# . Test field:
	# ....................................................................................
	if (length(ac[ac == "test"]) == 0) {
	    test = rep("NONE", nr);
	    ad = cbind(ad, test);     # If not present, add an all-NONE test set field.
	}

	for (i in 1:nr) {
            if ((ad$training[i] != "NONE") && (ad$test[i] != "NONE")) {
		msg = cat("ERROR: from Rdat.read: some test set entries are non-NONE");
		msg = cat(msg, "for non-NONE training set entries.\n");
		msg = cat(msg, "Test set entries can be non-NONE only for those instances not");
		msg = cat(msg, "in the training set.");
  	        stop(msg);	   
	    }
	}

	abuf = ad$test;               # Test set column.

	if (length(abuf[abuf != "NONE"]) == 0) {
	   flagTest = FALSE;
	} else {
	   flagTest = TRUE;
	}
	# ....................................................................................



	# ....................................................................................
	# . Final fail-safe: check that all reserved column names occur only once:
	# ....................................................................................
	if (length(ac[ac == "qual"]) > 1) {
	   msg = cat("ERROR: from Rdat.read: qual column occurs more than once.\n");
	   stop(msg);	   
	}	

	if (length(ac[ac == "y"]) > 1) {
	   msg = cat("ERROR: from Rdat.read: y column occurs more than once.\n");
	   stop(msg);	   
	}

	if (length(ac[ac == "training"]) > 1) {
	   msg = cat("ERROR: from Rdat.read: training column occurs more than once.\n");
	   stop(msg);	   
	}

	if (length(ac[ac == "test"]) > 1) {
	   msg = cat("ERROR: from Rdat.read: test column occurs more than once.\n");
	   stop(msg);	   
	}
	# ....................................................................................


        # .............................................................................
	# . Package into object:
        # .............................................................................
	ar = list(ad = ad,
	          flagGroup = flagGroup,
                  flagTest = flagTest);

	class(ar) = "Rdat";
	return (ar);
        # .............................................................................

}

# =======================================================================================
# . End of Rdat.read.
# =======================================================================================



# =======================================================================================
# . Rdat.getPredictors : for the input data frame, returns a data frame
# . ------------------   that only contains the predictor variables.
# .
# .
# .        adPred = Rdat.getPredictors(ad;
# .
# =======================================================================================

Rdat.getPredictors <- function(ad)
{

        # .....................................................................................
        if (!is.data.frame(ad)) {
	    msg = "ERROR: from Rdat.getPredictors: input variable ad is not a data frame. Exit.";
	    stop(msg);
	}
        # .....................................................................................


        # .....................................................................................
	ac = colnames(ad);
	adPred = ad[(ac != "qual") & (ac != "y") 
                    & (ac != "training") & (ac != "group") & (ac != "test")];

        # .....................................................................................


	# ...................
	return (adPred);
	# ...................


}

# =======================================================================================
# . End of Rdat.getPredictors.
# =======================================================================================