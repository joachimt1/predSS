# ======================================================================================
# . Matrix.r : some matrix utility functions.
# . --------
# ======================================================================================


# ======================================================================================
# . Matrix.spreadRow : this replicates a given row vector nr times, returns the
# . ----------------   corresponding matrix.
# .
# .              A = Matrix.spreadRow(row, nr);
# .
# .    row = input row vector.
# .    nr = number of rows in resulting matrix.
# ======================================================================================

Matrix.spreadRow <- function(row, nr)
{

        # ...................................................................
	# . Check input parameters:
        # ...................................................................
	if (!is.numeric(row)) {
	    msg = "ERROR: from Matrix.spreadRow: parameter for input row vector is non-numeric. Exit.";
	    stop(msg);
	}

        if (length(row) < 1) {
	    msg = "ERROR: from Matrix.spreadRow: input row vector is empty. Exit.";
	    stop(msg);
	}

        if (nr < 1) {
	    msg = "ERROR: from Matrix.spreadRow: nr < 1. Exit.";
	    stop(msg);
	}
        # ...................................................................


        # ...................................................................
	A = matrix(data = row, nrow = nr, ncol = length(row), byrow = TRUE);
        # ...................................................................


	# ...........
	return(A);
	# ...........


}

# ======================================================================================
# . End of Matrix.spreadRow.
# ======================================================================================


# ======================================================================================
# . Matrix.spreadCol : this replicates a given column vector nc times, returns the
# . ---------   corresponding matrix.
# .
# .              A = Matrix.spreadCol(col, nc);
# .
# .    col = input column vector.
# .    nr = number of cols in resulting matrix.
# ======================================================================================

Matrix.spreadCol = function(col, nc)
{

        # ...................................................................
	# . Check input parameters:
        # ...................................................................
	if (!is.numeric(col)) {
	    msg = "ERROR: from Matrix.spreadCol: parameter for input column vector is non-numeric. Exit.";
	    stop(msg);
	}

        if (length(col) < 1) {
	    msg = "ERROR: from Matrix.spreadCol: input column vector is empty. Exit.";
	    stop(msg);
	}

        if (nc < 1) {
	    msg = "ERROR: from Matrix.spreadCol: nc < 1. Exit.";
	    stop(msg);
	}
        # ...................................................................


        # ...................................................................
	A = matrix(data = col, nrow = length(col), ncol = nc, byrow = FALSE);
        # ...................................................................


	# ........
	return(A);
	# ........


}

# ======================================================================================
# . End of Matrix.spreadCol.
# ======================================================================================
