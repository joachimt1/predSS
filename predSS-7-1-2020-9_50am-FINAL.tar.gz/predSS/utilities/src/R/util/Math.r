# =====================================================================================
# .  Math.r: simple math utilities.
# .  ------  
# .
# =====================================================================================

library(limma);             # Needed for Math.plotVenn2.

Math.EPSILON = 1.0e-12;     # Stand in for infinitesimally small.

# =======================================================================================
# . Math.makeChunks : makes series of lower and upper bound arrays for dividing a
# . ---------------   range into `chunks'.
# .
# .             ch = Math.makeChunks(m, mchunk);
# .
# . Syntax:
# .    In:
# .        m = maximum index; range to be covered is 1:m; m >= 1.
# .        mchunk = length of each chunk; mchunk >= 1.
# .
# .    Out:
# .          ch = list with arrays :
# .               kchunk = number of chunks generated.
# .               amLo = array of lower bounds.
# .               amHi = array of upper bounds.
# .   
# .......................................................................................
# . * Example :
# .
# .    ch = Math.makeChunks(m = 250, mchunk = 90);
# .
# . returns :
# .
# .    ch$kchunk = 4
# .    ch$amLo =   1  81 161 241
# .    ch$amHi =  80 160 240 250
# .
# =======================================================================================

Math.makeChunks <- function(m, mchunk)
{

    # ................................................................
    if (m < 1) {
      cat("ERROR: from Math.makeChunks: m = ", m, " < 1.");
      stop();
    }
    
    if (mchunk < 1) {
      cat("ERROR: from Math.makeChunks: mchunk = ", mchunk, " < 1.");
      stop();
    }      
    # .................................................................


    # .........................................................................
    kchunk = 1 + floor((m - 1) / mchunk);    # Number of chunks to generate.

    kchunk1 = kchunk - 1;
    akLo = 0:kchunk1;

    amLo = 1 + akLo * mchunk;
    amHi = amLo + mchunk - 1;

    if (amHi[kchunk] > m) {
      amHi[kchunk] = m;     # Adjusts upper bound in last chunk.
    }
    # .........................................................................


    # .........................................................................
    # . Package into list :
    # .........................................................................    
    ch = list(kchunk = kchunk,
              amLo = amLo,
              amHi = amHi);
    # .........................................................................


    # ..............
    return (ch);
    # ..............

}

# =======================================================================================
# . End of Math.makeChunks.
# =======================================================================================





# =======================================================================================================
# . Math.cutOnQuantiles : for a given set of numbers, discretizes into approximately
# . -------------------   equal groups divided by quantiles.
# .
# . Syntax :
# .
# .       ar = Math.cutOnQuantiles(ax, nq);
# .
# . In:
# .
# .       ax = vector of numerical values.
# .       nq = number of groups to be defined.
# .
# . Out:
# .
# .       ar = output label assignments. If nq = 2, these are '-1', '1'.
# .            For nq > 2, these are '1, '2', . . ., 'nq'.
# .            If nq = 1, then there is a single group with label '1'.
# .
# . Example : 
# .
# =======================================================================================================

Math.cutOnQuantiles <- function(ax, nq)
{

     # ...............................................
     stopifnot(nq >= 1);
     stopifnot(length(ax) > 0);
     # ...............................................


     
     # ..................................................................................................
     n = length(ax);

     if (nq == 1) {
       ar = rep('1', times = n);                          # Just one group.
     }
     
     if (nq >= 2) {
       buf = sort(ax, index.return = TRUE);               # Stable sort.
       axSort = buf[["x"]];                               # Sorted array.
       indexSort = buf[["ix"]];                           # Sort index.

       axSort = axSort + 1:n;                             # This breaks any ties.

       nq1 = nq - 1;
       aq = (1:nq1) / nq;                                         # Inner quantiles.
       aqVal = quantile(axSort, probs = aq);                      # Inner quantile values.

       min1 = min(axSort) - 1.0;                                  # Min - 1.
       max1 = max(axSort) + 1.0;                                  # Max = 1.
       abreak = c(min1, aqVal, max1);                             # This will define nq groups.
       alab = 1:nq;                                               # Labels for the groups.
       arSort = cut(axSort, breaks = abreak, labels = alab);      # Assign the labels to all samples.

       ar = 1:n;                                                  # Dummy initialization.
       ar[indexSort] = arSort;                                    # Restore to original order.


       if (nq == 2) {
         ar = ifelse(ar == 1, -1, 1);                             # Discretize to {-1, 1].
       }
     }
     # ..................................................................................................


     # .............
     return (ar);
     # .............
        
}

# =======================================================================================================
# . End of Math.cutOnQuantiles.
# =======================================================================================================



# =======================================================================================
# . Math.isInt : checks if number is an integer.
# . ----------
# .
# . Syntax :
# .
# .     flag = Math.isInt(x);
# .
# . In :
# .     x = input number.
# .
# . Out:
# .     flag = TRUE if x is an integer, FALSE otherwise.
# .
# =======================================================================================

Math.isInt <- function(x, tol = .Machine$double.eps) {
   (x - floor(x)) < tol
}

# =======================================================================================
# . End of Math.isInt.
# =======================================================================================

