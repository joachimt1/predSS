# =====================================================================================
# .  Param.r: utility functions for getting parameters in the command line.
# .  -------
# .
# =====================================================================================


# =======================================================================================
# . Param.get_parameter: returns the string in the command line that immediately
# . -------------------  follows the specified token.
# .
# .
# .     value = Param.get_parameter(token = "-cin", required = FALSE);
# .
# .    required == TRUE, print error message and EXIT if target not found.
# .             == FALSE, return empty string, "", but do not exit.
# .
# . Note: if the target starts with a "-" character, will signal a potential error and
# . exit. In other words, the token-target pair:
# .
# .         -x  -60.0
# .
# . is not allowed. Use instead the function Param.get_parameter_ez as in:
# .
# .    Param.get_parameter_ez(token = "-x", required = "TRUE"); 
# .
# =======================================================================================

Param.get_parameter <- function(argv, token, required)
{
        # ...........................................
	flag_found = FALSE;     
        target = "";
	# ...........................................


	# .........................................................................
	# . Check that token starts with a '-':
	# .........................................................................
	if (substr(token, 1, 1) != "-") {
	   msg = cat("ERROR: from Param.get_parameter: token ", token, " does not start with a -.\n");
	   stop(msg);
        }

	argc = length(argv);       # Length of argv vector.

	if (length(argv) == 0) {
	   msg = cat("ERROR: from Param.get_parameter: argv is of zero length.\n");
	   stop(msg);
	}

	if (length(argv) == 1) {
	   msg = cat("ERROR: from Param.get_parameter: argv is of length 1. Must have at least 2 items.\n");
	   stop(msg);
	}
	# .........................................................................



	# .........................................................................
        # . Scan the line for the target:
        # .........................................................................
	i = 1;    

	for (item in argv) {
           if (item == token) {
 	     if (i < argc) {                       # Target was found.
 	       target = argv[i+1];
	       flag_found = TRUE;
	       break;                              # Note that it gets the *first* instance.
	     } else {                              # Target was not found.
	       target =  "";
               break;
	     }
  	   }
	   i = i + 1;
	}
	# .........................................................................



        # .........................................................................
	# . Check that target does NOT start with a '-':
	# .........................................................................
        if (nchar(target) > 0) {
	   if (substr(target, 1, 1) == "-") {
	     msg = cat("ERROR: from Param.get_parameter: the target was found\n");
	     msg = cat(msg, " target = ", target, ", but it starts with a -.\n");
	     msg = cat(msg, "A parameter is probably missing between two tokens in the command line.\n");
	     stop(msg);
	   }
        }
	# .........................................................................


	# .........................................................................
        if (flag_found) {
	  return (target);
        } else if (required == FALSE) {
	  return (target);                 # Will return an empty string.
        } else {
	  msg = cat("ERROR: from Param.get_parameter: could not find target for");
	  msg = cat(msg, "command line token ", token, "\n");
	  stop(msg);
	}
	# ......................................................................... 


        # ...............................
        return (target);
        # ...............................
}

# =======================================================================================
# . End of Param.get_parameter.
# =======================================================================================


# =======================================================================================
# . Param.get_parameter_ez: returns the string in the command line that immediately
# . ----------------------  follows the specified token.
# .
# .
# .     value = Param.get_parameter_ez(token = "-cin", required = FALSE);
# .
# .    required == TRUE, print error message and EXIT if target not found.
# .             == FALSE, return empty string, "", but do not exit.
# .
# . Note: unlike Param.get_parameter, the token-target pair is allowed:
# .
# .         -x  -60.0
# .
# =======================================================================================

Param.get_parameter_ez <- function(argv, token, required)
{
        # ...........................................
	flag_found = FALSE;     
        target = "";
	# ...........................................


	# .........................................................................
	# . Check that token starts with a '-':
	# .........................................................................
	if (substr(token, 1, 1) != "-") {
	   msg = cat("ERROR: from Param.get_parameter_ez: token ", token, " does not start with a -.\n");
	   stop(msg);
        }

	argc = length(argv);       # Length of argv vector.

	if (length(argv) == 0) {
	   msg = cat("ERROR: from Param.get_parameter_ez: argv is of zero length.\n");
	   stop(msg);
	}

	if (length(argv) == 1) {
	   msg = cat("ERROR: from Param.get_parameter_ez: argv is of length 1. Must have at least 2 items.\n");
	   stop(msg);
	}
	# .........................................................................



	# .........................................................................
        # . Scan the line for the target:
        # .........................................................................
	i = 1;    

	for (item in argv) {
           if (item == token) {
 	     if (i < argc) {                       # Target was found.
 	       target = argv[i+1];
	       flag_found = TRUE;
	       break;                              # Note that it gets the *first* instance.
	     } else {                              # Target was not found.
	       target =  "";
               break;
	     }
  	   }
	   i = i + 1;
	}
	# .........................................................................




	# .........................................................................
        if (flag_found) {
	  return (target);
        } else if (required == FALSE) {
	  return (target);                 # Will return an empty string.
        } else {
	  msg = cat("ERROR: from Param.get_parameter_ez: could not find target for");
	  msg = cat(msg, "command line token ", token, "\n");
	  stop(msg);
	}
	# ......................................................................... 


        # ...............................
        return (target);
        # ...............................
}

# =======================================================================================
# . End of Param.get_parameter_ez.
# =======================================================================================
