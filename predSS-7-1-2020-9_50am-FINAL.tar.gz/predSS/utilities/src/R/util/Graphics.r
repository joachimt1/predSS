# =================================================================================================
# . Graphics : some basic utility functions for graphics.
# . --------
# .         
# . start: 3-7-2013.
# =================================================================================================


# =========================================================================================================
# . Graphics.makeColorWheelOnArray : for an input array of categorical variables, generates a color
# . ------------------------------   code for each distinct type, and assigns a color to each element
# .                                  in the array. Also returns data for generating the legened.
# . Syntax:
# .
# .      cw = Graphics.makeColorWheelOnArray(ac,
# .                                          flagAllBlack = 'no',
# .                                          flagSortNumerical = FALSE,
# .                                          flagShuffle = FALSE,
# .                                          rngSeed = 123456);
# .   
# . In :
# .
# .               ac = character or factor array of categorical variables.
# .
# .     flagAllBlack = yes/no, if yes, force all colors to black. To be used in code logic 
# .                    if one judges that there are too many colors to represent.
# .
# . flagSortNumerical = if TRUE, sort categories in accordance to their numerical values
# .                     under conversion by as.numeric().
# .
# .      flagShuffle = if TRUE, randomly shuffle the color assignments.
# .
# .          rngSeed = seed for random number generator, used if flagShuffle = TRUE.
# .
# . Out :
# .
# . cw = list, with members :
# .
# .      cw = list(colorWheel = colorWheel,         # Assignments to distinct values. 
# .                acol = acol,                     # Element-by-element assignments. 
# .                legendText = legendText,         # Texts for legend.
# .                colVector = colVector,           # Colors for legend.
# .                ltyVector = ltyVector,           # Line types for legend.
# .                pchVector = pchVector);          # Dot types for legend.
# .
# ==========================================================================================================

Graphics.makeColorWheelOnArray <- function(ac,
                                           flagAllBlack = 'no',
                                           flagSortNumerical = FALSE,                                           
                                           flagShuffle = FALSE,
                                           rngSeed = 123456)
{

      # ..............................................................
      stopifnot((flagAllBlack == 'yes') || (flagAllBlack == 'no'));

      if (flagShuffle) {
        stopifnot(rngSeed > 0);
      }

      ac = as.character(ac);
      # ..............................................................

  
      # .....................................................................................................................
      # . Sort unique values.
      # . Non-numeric sort or numeric sort :
      # .....................................................................................................................
      if (!flagSortNumerical){
        ad = sort(unique(ac));                               # Array of distinct values.
      } else {
        abuf = unique(ac);
        abuf.num = as.numeric(abuf);

        flag = sum(is.na(abuf.num));

        if (flag > 0) {
          cat("ERROR: from Graphics.makeColorWheelOnArray:\n");
          cat("you specified flagSortNumerical = TRUE, but not all input categories have names that convert to numerical values.\n");
          stop();
        }
        
        indexSort = order(abuf.num);
        ad = abuf[indexSort];
      }
      
      nd = length(ad);                                       # Number of distinct values.
      NMAX = 100;
      
      if (nd <= 8) {
        colorWheel = c('black', 'brown', 'green', 'blue', 'red', 'yellow', 'cyan', 'magenta');
       
        colorWheel = colorWheel[1:nd];
      } else if (nd <= NMAX) {
        colorWheel = rainbow(nd);
      } else {
        colorWheel = array(rainbow(NMAX), dim = nd);         # Recycle colors if more than NMAX.
      }

      if (flagAllBlack == 'yes') {
        colorWheel = rep('black', times = nd);               # Force back to all-black values.
      }
      # .......................................................................................
      # . Randomly shuffle the colors if requested :
      # .......................................................................................
      if (flagShuffle){
        set.seed(rngSeed);
        colorWheel =  sample(colorWheel, size = length(colorWheel), replace = FALSE);
      }
      # .......................................................................................
      names(colorWheel) = ad;                                # So we can use the names as keys.
      acol = colorWheel[ac];                                 # Assigns a color value to each element.
      # .....................................................................................................................


      
      
      # ....................................................................................................
      # . Generate entries for legend :
      # . This might be used eg. as :
      # .
      # .  legend(x = 0.5, y = 1.0, legend = cw$legendText, col = cw$colVector, pch = cw$pchVector, bty = 'y', bg = 'gray');
      # .
      # . See function: Graphics.plotLegendOnColorWheel().
      # ....................................................................................................
      legendText = names(colorWheel);
      colVector = colorWheel;
      ltyVector = rep('solid', times = nd);
      pchVector = rep(19, times = nd);

      ff1 = table(ac);                                               # Computes frequencies.
      acount = ff1[names(colorWheel)];                               # Assigns frequencies.

      legendText = paste(legendText, " (", acount, ")", sep = "");   # Add frequencies to labels.
      # ....................................................................................................

      

      # .........................................................................
      # . Package results into a list :
      # .........................................................................
      cw = list(nd = nd,                         # Number of distinct values.
                colorWheel = colorWheel,         # Assignments to distinct values.
                acol = acol,                     # Element-by-element assignments.
                legendText = legendText,         # Texts for legend.
                colVector = colVector,           # Colors for legend.
                ltyVector = ltyVector,           # Line types for legend.
                pchVector = pchVector);          # Dot types for legend.

      class(cw) = 'color.wheel';
      # .........................................................................

      
      # ...........
      return (cw);
      # ...........
      
}

# ==========================================================================================================
# . End of Graphics.makeColorWheelOnArray.
# ==========================================================================================================




# =========================================================================================================
# . Graphics.addAnnotationToColorWheel : adds annotation to the text fields in the color wheel.
# . ----------------------------------   
# .
# . Syntax:
# .
# .      cw = Graphics.addAnnotationToColorWheel(cw, agroup);
# .   
# . In :
# .
# .          cw = color wheel, returned by call to Graphics.makeColorWheelOnArray().
# .
# .      agroup = optional named array, providing group assignments to the tetxt items in the color wheel.
# .               For instance if the colors are keyed on compounds, and each compound is assigned an MOA class :
# .
# .                     EX00122183    SAR238535    SAR305455   SAR344517A    SAR382995   SAR391535A 
# .                     "BRAF-V600E" "BRAF-V600E" "BRAF-V600E"  "ERK1|ERK2"  "ERK1|ERK2"  "ERK1|ERK2"
# .
# .                     SAR163917    SAR170205   SAR225853A   SAR327784A    SAR342707  EX00138042A 
# .                     "MEK1|MEK2"  "MEK1|MEK2"  "MEK1|MEK2"  "MEK1|MEK2"  "MEK1|MEK2"  "ERK1|ERK2"
# .
# .                     SAR328778 
# .                     "ERK1|ERK2"
# .
# .                then the latter are appended to the corresponding text fields for the legends.
# .
# ==========================================================================================================

Graphics.addAnnotationToColorWheel <- function(cw, agroup)
{

      # .......................................................................................
      if (class(cw) != 'color.wheel') {
        cat("ERROR: from Graphics.addAnnotationToColorWheel:\n");
        cat("cw is not of class = color.wheel\n");
        stop();
      }
      # .......................................................................................

      
      # ....................................................................................................
      # . Add the annotation. Items with no defined mapping are assigned 'NONE' :
      # ....................................................................................................
      mask = cw$legendText %in% names(agroup);                                 # TRUE only for compounds with a defined group.
      annotAdd = ifelse(mask, agroup[as.character(cw$legendText)], 'NONE');   
      cw$legendText = paste(cw$legendText, ' --- ', annotAdd, sep = "");
      # ....................................................................................................
      
      
      # .............
      return (cw);
      # .............
      
}

# =========================================================================================================
# . End of Graphics.addAnnotationToColorWheel.
# =========================================================================================================






# =========================================================================================================
# . Graphics.plotLegendOnColorWheel : generates a separate plot page, containing the legend corresponding
# . -------------------------------   to the color wheel assignments returned by Graphics.makeColorWheelOnArray().
# .
# . Syntax:
# .
# .      Graphics.plotLegendOnColorWheel(cw, caption = '', hpos = 'left');
# .   
# . In :
# .
# .          cw = color wheel, returned by call to Graphics.makeColorWheelOnArray().
# .
# .     caption = legend caption.
# .
# .        hpos = 'left', 'right'. Specifies horizontal position of text box for legend.
# .
# ==========================================================================================================

Graphics.plotLegendOnColorWheel <- function(cw, caption = '', hpos = 'left')
{

      # .......................................................................................
      if (class(cw) != 'color.wheel') {
        cat("ERROR: from Graphics.plotLegendOnColorWheel:\n");
        cat("cw is not of class = color.wheel\n");
        stop();
      }

      stopifnot((hpos == 'left') || (hpos == 'right'));
      # .......................................................................................

      
      # .......................................................................................
      xoff = 0.0;         # Horizontal offset.

      if (hpos == 'right') {
        xoff = 0.85;
      }

      if (nchar(caption) > 0) {
        caption = paste(caption, " (", cw$nd, ")", sep = "");      # Add number of items.
      }
      # .......................................................................................      

      
      
      # ....................................................................................................
      # . Boundary box here. No axis labels or tick marks.
      # ....................................................................................................
      xbuf = c(0,1);
      ybuf = c(0,1);

      plot(xbuf, ybuf, type = 'n',
           xaxt = 'n', yaxt = 'n',
           xlab = '', ylab = '',
           main = caption,
           axes = FALSE);
      # ....................................................................................................
      # . The legend here :
      # ....................................................................................................      
      nd = cw$nd;                 # Number of items to display.
      NMAX = 30;                  # Maximum number per column.
      kc = nd%/%NMAX;             # Number of columns needed.

      if (nd%%NMAX > 0) {         
        kc = kc + 1;              # Catch the remainder as well.
      }

      KCMAX = 4;                  # Maximum number of columns to display.
      dx = 1.0 / KCMAX;
      kcDisplay = min(kc, KCMAX);

      bgCol = Graphics.addTrans(color = 'gray', trans = 50);

      for (k in 1:kcDisplay) {
        klo = (k - 1) * NMAX + 1;
        khi = k * NMAX;

        if (khi > nd) {
          khi = nd;
        }

        legendText = cw$legendText[klo:khi];
        colVector = cw$colVector[klo:khi];
        pchVector = cw$pchVector[klo:khi];

        x = xoff + dx * (k - 1);
        legend(x = x, y = 1.0, legend = legendText, col = colVector, pch = pchVector, bty = 'y', bg = bgCol);
      }
      # ....................................................................................................
      
      
      # ...........
      return (0);
      # ...........
      
}

# =========================================================================================================
# . End of Graphics.plotLegendOnColorWheel.
# =========================================================================================================



# =========================================================================================================
# . Graphics.setLowerMargin : sets the value of the lower plot margin to the indicated quantity.
# . -----------------------
# .
# . Syntax :
# .
# .    mai.OLD = Graphics.setLowerMargin(lmargin);
# .
# . In :
# .
# .   lmargin = new value of lower margin (e.g. 3.0).
# .
# . Out :
# .
# .     mai.OLD = value of margins (4-vector) before reset.
# .
# =========================================================================================================

Graphics.setLowerMargin <- function(lmargin)
{

     # .............................................
     stopifnot(lmargin > 0.0);
     # .............................................


     # .............................................................................
     mai.OLD = par("mai");       # Note that: mai = c(bottom, left, top, right).
     buf = mai.OLD;
     buf[1] = lmargin;
     par(mai = buf);
     # .............................................................................


     # ..................
     return (mai.OLD);
     # ..................     

}

# =========================================================================================================
# . End of Graphics.setLowerMargin.
# =========================================================================================================



# =========================================================================================================
# . Graphics.setTopMargin : sets the value of the top plot margin to the indicated quantity.
# . -----------------------
# .
# . Syntax :
# .
# .    mai.OLD = Graphics.setTopMargin(lmargin);
# .
# . In :
# .
# .   lmargin = new value of lower margin (e.g. 3.0).
# .
# . Out :
# .
# .     mai.OLD = value of margins (4-vector) before reset.
# .
# =========================================================================================================

Graphics.setTopMargin <- function(lmargin)
{

     # .............................................
     stopifnot(lmargin > 0.0);
     # .............................................


     # .............................................................................
     mai.OLD = par("mai");       # Note that: mai = c(bottom, left, top, right).
     buf = mai.OLD;
     buf[3] = lmargin;
     par(mai = buf);
     # .............................................................................


     # ..................
     return (mai.OLD);
     # ..................     

}

# =========================================================================================================
# . End of Graphics.setTopMargin.
# =========================================================================================================



# =========================================================================================================
# . Graphics.setLeftMargin : sets the value of the left plot margin to the indicated quantity.
# . -----------------------
# .
# . Syntax :
# .
# .    mai.OLD = Graphics.setLeftMargin(lmargin);
# .
# . In :
# .
# .   lmargin = new value of left margin (e.g. 3.0).
# .
# . Out :
# .
# .     mai.OLD = value of margins (4-vector) before reset.
# .
# =========================================================================================================

Graphics.setLeftMargin <- function(lmargin)
{

     # .............................................
     stopifnot(lmargin > 0.0);
     # .............................................


     # .............................................................................
     mai.OLD = par("mai");       # Note that: mai = c(bottom, left, top, right).
     buf = mai.OLD;
     buf[2] = lmargin;
     par(mai = buf);
     # .............................................................................


     # ..................
     return (mai.OLD);
     # ..................     

}

# =========================================================================================================
# . End of Graphics.setLeftMargin.
# =========================================================================================================




# =========================================================================================================
# . Graphics.setRightMargin : sets the value of the right plot margin to the indicated quantity.
# . -----------------------
# .
# . Syntax :
# .
# .    mai.OLD = Graphics.setRightMargin(lmargin);
# .
# . In :
# .
# .   lmargin = new value of left margin (e.g. 3.0).
# .
# . Out :
# .
# .     mai.OLD = value of margins (4-vector) before reset.
# .
# =========================================================================================================

Graphics.setRightMargin <- function(lmargin)
{

     # .............................................
     stopifnot(lmargin > 0.0);
     # .............................................


     # .............................................................................
     mai.OLD = par("mai");       # Note that: mai = c(bottom, left, top, right).
     buf = mai.OLD;
     buf[4] = lmargin;
     par(mai = buf);
     # .............................................................................


     # ..................
     return (mai.OLD);
     # ..................     

}

# =========================================================================================================
# . End of Graphics.setRightMargin.
# =========================================================================================================



# =========================================================================================================
# . Graphics.setAllMargins : sets all margins.
# . ----------------------
# .
# . Syntax :
# .
# .    mai.OLD = Graphics.setAllMargins(mai.NEW);
# .
# . In :
# .
# .    mai.NEW = new value specifying the margins.   This is a numerical vector of the form
# .              'c(bottom, left, top, right)' which gives the margin size specified in inches.
# .
# . Out :
# .
# .     mai.OLD = previous value of margin before reset.
# .
# ........................................................................................................
# . * Note that the default values appear to be :
# .
# .    mai =  1.02 0.82 0.82 0.42
# =========================================================================================================

Graphics.setAllMargins <- function(mai.NEW)
{


     # .............................................................................
     mai.OLD = par("mai");       # Note that: mai = c(bottom, left, top, right).
     par(mai = mai.NEW);
     # .............................................................................


     # ..................
     return (mai.OLD);
     # ..................     

}

# =========================================================================================================
# . End of Graphics.setAllMargins.
# =========================================================================================================




# =========================================================================================================
# . Graphics.plotLegendOnArrays : generates a separate plot page, containing the legend corresponding
# . ---------------------------   to the color assignments specified by the input arrays.
# .
# . Syntax:
# .
# .      Graphics.plotLegendOnArrays(legendText, colVector, pchVector, caption = '');
# .   
# . In :
# .
# .     legendText = array of text legends.
# .      colVector = corresponding color vector (must be same length as legendText).
# .      pchVector = corresponding point font vector (must be same length as legendText).
# .
# .     caption = legend caption.
# ==========================================================================================================

Graphics.plotLegendOnArrays <- function(legendText, colVector, pchVector, caption = '')
{

      # .......................................................................................
      nd = length(legendText);

      if (length(colVector) != nd) {
        cat("ERROR: from Graphics.plotLegendOnArrays:\n");
        cat("colVector not same length as legendText.\n");
        stop();
      }

      if (length(pchVector) != nd) {
        cat("ERROR: from Graphics.plotLegendOnArrays:\n");
        cat("pchVector not same length as legendText.\n");
        stop();
      }      
      # .......................................................................................

      
      # ....................................................................................................
      # . Boundary box here. No axis labels or tick marks.
      # ....................................................................................................
      xbuf = c(0,1);
      ybuf = c(0,1);

      plot(xbuf, ybuf, type = 'n',
           xaxt = 'n', yaxt = 'n',
           xlab = '', ylab = '',
           main = caption);
      # ....................................................................................................
      # . The legend here :
      # ....................................................................................................      
      NMAX = 30;                  # Maximum number per column.
      kc = nd%/%NMAX;             # Number of columns needed.

      if (nd%%NMAX > 0) {         
        kc = kc + 1;              # Catch the remainder as well.
      }

      KCMAX = 4;                  # Maximum number of columns to display.
      dx = 1.0 / KCMAX;
      kcDisplay = min(kc, KCMAX);

      for (k in 1:kcDisplay) {
        klo = (k - 1) * NMAX + 1;
        khi = k * NMAX;

        if (khi > nd) {
          khi = nd;
        }

        x = dx * (k - 1);
        legend(x = x, y = 1.0, legend = legendText, col = colVector, pch = pchVector, bty = 'y', bg = 'gray');          
      }
      # ....................................................................................................
      
      
      # ...........
      return (0);
      # ...........
      
}

# =========================================================================================================
# . End of Graphics.plotLegendOnArrays.
# =========================================================================================================






# =========================================================================================================
# . Graphics.addTrans : adds transparency to a color.
# . -----------------   (lifted from the web from post by Sacha Epskamp).
# .
# . Syntax:
# .
# .      colorNew = Graphics.addTrans(color, trans);
# .   
# . In :
# .
# .        color = color to be made transparent.
# .
# .        trans = transparency (see author's comments below.
# .
# ......................................................................................................
# .  Some examples:                                                 
# .                                                                 
# .  cols <- sample(c("red","green","pink"),100,TRUE)               
# .                                                                 
# .  # Fully visible:                                               
# .  plot(rnorm(100),rnorm(100),col=cols,pch=16,cex=4)              
# .                                                                 
# .  # Somewhat transparent:                                        
# .  plot(rnorm(100),rnorm(100),col=addTrans(cols,200),pch=16,cex=4)
# .                                                                 
# .  # Very transparent:                                            
# .  plot(rnorm(100),rnorm(100),col=addTrans(cols,100),pch=16,cex=4)
# .
# .
# ==========================================================================================================

Graphics.addTrans <- function(color,trans)
{
  # This function adds transparency to a color.
  # Define transparancy with an integer between 0 and 255
  # 0 being fully transparent and 255 being fully visible
  # Works with either color and trans a vector of equal length,
  # or one of the two of length 1.

  if (length(color)!=length(trans)&!any(c(length(color),length(trans))==1)) stop("Vector lengths not correct")
  if (length(color)==1 & length(trans)>1) color <- rep(color,length(trans))
  if (length(trans)==1 & length(color)>1) trans <- rep(trans,length(color))

  num2hex <- function(x)
  {
    hex <- unlist(strsplit("0123456789ABCDEF",split=""))
    return(paste(hex[(x-x%%16)/16+1],hex[x%%16+1],sep=""))
  }
  rgb <- rbind(col2rgb(color),trans)
  res <- paste("#",apply(apply(rgb,2,num2hex),2,paste,collapse=""),sep="")
  return(res)
}

# =========================================================================================================
# . End of Graphics.addTrans.
# =========================================================================================================




# =========================================================================================================
# . Graphics.addTransJST : JST version for making colors transparent.
# . --------------------   
# .
# . Syntax:
# .
# .      colorNew = Graphics.addTransJST(acol, alpha);
# .   
# . In :
# .
# .        acol = arrays of colors to be made transparent.
# .
# .        alpha = transparency factor (1 = solid, 0 = completely transparent).
# .
# ==========================================================================================================

Graphics.addTransJST <- function(acol, alpha)
{


     # ........................................................................................
     # . Make colors transparent :
     # ........................................................................................
     abuf = col2rgb(acol) / 255;
     acolNew = apply(abuf, 2, function(x){rgb(x[1], x[2], x[3], alpha = alpha, max = 1);});
     # ........................................................................................


     # .................
     return (acolNew)
     # .................

   }

# =========================================================================================================
# . End of Graphics.addTransJST.
# =========================================================================================================







# =========================================================================================================
# . Graphics.setParMfrow : optimizes and sets par(mfrom = ...) for multiple plots.
# .------------------   
# .
# . Syntax:
# .
# .      ac = Graphics.setParMfrow(nplot);
# .   
# . In :
# .
# ==========================================================================================================

Graphics.setParMfrow <- function(nplot)
{


     # ............................................................................
     # . Kludge to determine number of rows and columns in plot page :
     # ............................................................................
     ntemp = sqrt(nplot);
     nrPlot = max(floor(ntemp), 1);
     ncPlot = ceiling(ntemp);

     ntemp2 = nrPlot * ncPlot;

     if (ntemp2 < nplot) {
       nrPlot = nrPlot + 1;
     }

     ac = c(nrPlot, ncPlot);
     # ............................................................................
     # . Set here :
     # ............................................................................
     par(mfrow = c(nrPlot, ncPlot));
     # ............................................................................          



     # .................
     return (ac);
     # .................

   }

# =========================================================================================================
# . End of Graphics.setParMfrow.
# =========================================================================================================






# =========================================================================================================
# . Graphics.makeColorWheelOnArrayRowColUnified : generates a unified color code for both row and column labels.
# . -------------------------------------------   See function : Graphics.makeColorWheelOnArray()
# .                                  
# . Syntax:
# .
# .      lb = Graphics.makeColorWheelOnArrayRowColUnified(acRow,
# .                                                       acCol,
# .                                                       flagAllBlack = 'no',
# .                                                       flagSortNumerical = FALSE,
# .                                                       flagShuffle = FALSE,
# .                                                       rngSeed = 123456);
# .   
# . In :
# .
# .               acRow = character or factor array of categorical variables for the rows.
# .
# .               acCol = character or factor array of categorical variables for the columns.
# .
# .     flagAllBlack = yes/no, if yes, force all colors to black. To be used in code logic 
# .                    if one judges that there are too many colors to represent.
# .
# . flagSortNumerical = if TRUE, sort categories in accordance to their numerical values
# .                     under conversion by as.numeric().
# .
# .      flagShuffle = if TRUE, randomly shuffle the color assignments.
# .
# .          rngSeed = seed for random number generator, used if flagShuffle = TRUE.
# .
# . Out :
# .
# . lb = list, with members :
# .
# .       cwRow, cwCol
# .
# ..........................................................................................................
# . * Each color wheel object contains :
# .
# .      cw = list(colorWheel = colorWheel,         # Assignments to distinct values. 
# .                acol = acol,                     # Element-by-element assignments. 
# .                legendText = legendText,         # Texts for legend.
# .                colVector = colVector,           # Colors for legend.
# .                ltyVector = ltyVector,           # Line types for legend.
# .                pchVector = pchVector);          # Dot types for legend.
# .
# ==========================================================================================================

Graphics.makeColorWheelOnArrayRowColUnified <- function(acRow,
                                                        acCol,
                                                        flagAllBlack = 'no',
                                                        flagSortNumerical = FALSE,                                           
                                                        flagShuffle = FALSE,
                                                        rngSeed = 123456)
{

      # ..............................................................
      stopifnot((flagAllBlack == 'yes') || (flagAllBlack == 'no'));

      if (flagShuffle) {
        stopifnot(rngSeed > 0);
      }
      # ..............................................................

      

      # ........................................................................................................
      # . Generate a unified hash map :
      # ........................................................................................................
      acBuf = c(acRow, acCol);

      cwUni = Graphics.makeColorWheelOnArray(acBuf,
                                             flagAllBlack = flagAllBlack,
                                             flagSortNumerical = flagSortNumerical,
                                             flagShuffle = flagShuffle,
                                             rngSeed = rngSeed);      

      # ........................................................................................................
      # . Rows :
      # ........................................................................................................
      cwRow = list();
      cwRow$colorWheel = cwUni$colorWheel; 
      cwRow$acol = cwUni$colorWheel[as.character(acRow)];                                 # Assigns a color value to each element.
      # ....................................................................................................
      # . Generate entries for legend :
      # ....................................................................................................
      cwRow$nd = cwUni$nd;
      cwRow$legendText = names(cwUni$colorWheel);
      cwRow$colVector = cwUni$colorWheel;
      cwRow$ltyVector = rep('solid', times = cwUni$nd);
      cwRow$pchVector = rep(19, times = cwUni$nd);

      ff1 = table(acRow);                                               # Computes frequencies.
      acount = ff1[names(cwUni$colorWheel)];                               # Assigns frequencies.

      cwRow$legendText = paste(cwRow$legendText, " (", acount, ")", sep = "");   # Add frequencies to labels.
      # ....................................................................................................
      # . Remove values not represented :
      # ....................................................................................................
      flagKeep = !is.na(acount);

      cwRow$nd = sum(flagKeep);
      cwRow$legendText =  cwRow$legendText[flagKeep];
      cwRow$colVector  =  cwRow$colVector[flagKeep];
      cwRow$ltyVector  =  cwRow$ltyVector[flagKeep];
      cwRow$pchVector  =  cwRow$pchVector[flagKeep];
      # ....................................................................................................
      # . Assign class :
      # ....................................................................................................
      class(cwRow) = 'color.wheel';
      # ........................................................................................................
      # . Columns :
      # ........................................................................................................      
      cwCol = list();
      cwCol$colorWheel = cwUni$colorWheel;       
      cwCol$acol = cwUni$colorWheel[as.character(acCol)];                                 # Assigns a color value to each element.
      # ....................................................................................................
      # . Generate entries for legend :
      # ....................................................................................................
      cwCol$nd = cwUni$nd;
      cwCol$legendText = names(cwUni$colorWheel);
      cwCol$colVector = cwUni$colorWheel;
      cwCol$ltyVector = rep('solid', times = cwUni$nd);
      cwCol$pchVector = rep(19, times = cwUni$nd);

      ff1 = table(acCol);                                               # Computes frequencies.
      acount = ff1[names(cwUni$colorWheel)];                               # Assigns frequencies.

      cwCol$legendText = paste(cwCol$legendText, " (", acount, ")", sep = "");   # Add frequencies to labels.
      # ....................................................................................................
      # . Remove values not represented :
      # ....................................................................................................
      flagKeep = !is.na(acount);

      cwCol$nd = sum(flagKeep);
      cwCol$legendText =  cwCol$legendText[flagKeep];
      cwCol$colVector  =  cwCol$colVector[flagKeep];
      cwCol$ltyVector  =  cwCol$ltyVector[flagKeep];
      cwCol$pchVector  =  cwCol$pchVector[flagKeep];
      # ....................................................................................................
      # . Assign class :
      # ....................................................................................................      
      class(cwCol) = 'color.wheel';      
      # ........................................................................................................      


      # .........................................................................
      # . Package results into a list :
      # .........................................................................
      lb = list(cwRow = cwRow,
                cwCol = cwCol);
      # .........................................................................
      
      
      # ...........
      return (lb);
      # ...........
      
}

# ==========================================================================================================
# . End of Graphics.makeColorWheelOnArrayRowColUnified.
# ==========================================================================================================

