# =====================================================================================
# .  File.r: simple utilities for reading items in files or generating file names.
# .  ------  
# .
# =====================================================================================


# =======================================================================================
# . File.readValues : for a given input file, looks for values of given items in a 
# . ---------------   list of keys.
# .
# .             val = File.readValues(fin, keys);
# .
# .    IN:
# .          fin = input file (full path).
# .          keys = character array containing list of items.
# .
# .    OUT:
# .          val = list containing values.
# .
# .......................................................................................
# . EXAMPLE:
# . >> Given the keys:
# .
# .          keys = c('smaxChi2', 'smaxWs', 'smaxAs');
# .
# . this function looks for lines starting with:
# .
# .     smaxChi2 = 0.333333
# .      smaxWs = 0.510417
# .     smaxAs = 0.291667
# .
# . There can be white space at the start of the line, and additional words after
# . the actual assignment.
# .
# . The assignments are returned in a list (hash).
# .
# =======================================================================================

File.readValues <- function(fin, keys)
{

	# ..............................................................................
	if (!is.character(fin)) {
	   msg = cat("ERROR: from File.readValues: fin parameter = ", 
	             fin, " is not of type character.\n");
	   stop(msg);
	}

        nkeys = length(keys);
        
        if (nkeys == 0) {
	   msg = cat("ERROR: from File.readValues: input keys array is of 0 length.\n");
	   stop(msg);          
        }
	# ..............................................................................

        
	# .............................................................
        # . List of input keys:
	# .............................................................
        h = list();
        
        for (i in 1:nkeys) {
          item = keys[i];
          h[[item]] = "__none__";
        }
	# .............................................................
        

        
	# .............................................................................
        # . Read all rows in the file:
	# .............................................................................
        arow = scan(fin, what = 'character', sep = "\n");
        nrow = length(arow);

        if (nrow == 0) {
	   msg = cat("ERROR: from File.readValues: input file is empty.\n");
	   stop(msg);          
        }
	# .............................................................................

        

	# .............................................................................
        # . March through the rows and find if there are matches:
       	# .............................................................................
        for (i in 1:nrow) {
          line = arow[i];
          line = sub("^\\s+", "", line);
          line = sub("\\s+$", "", line);
          
          al = strsplit(line, split="\\s+", perl=TRUE)[[1]];

          if (length(al) >= 3) {
            item = al[1];
            sign = al[2];
            value = al[3];

            if (sign == "=")
              if (!is.null(h[[item]])) {
                h[[item]] = as.numeric(al[3]);
              }
            }
          }
      	# .............................................................................


      	# .............................................................................
        # . Final tally of assignments:
      	# .............................................................................
        for (i in 1:nkeys) {
          item = keys[i];
          if (h[[item]] == "__none__") {
              msg = cat("ERROR: from File.readValues:\n");
              msg = cat(msg, "Could not find value for item = ", item, "\n");
              stop(msg);          
          }
        }
      	# .............................................................................

        
	# ...............
	return (h);
        # ...............

}

# =======================================================================================
# . End of File.readValues.
# =======================================================================================



# ====================================================================================================
# . File.readParam : for a given input file, looks for parameter --> values assignments.
# . --------------
# .
# .             p = File.readParam(fin);
# .
# .    In:
# .          fin = input file (full path). See data format below.
# .
# .    OUT:
# .          p = list containing values in hash form.
# .
# .......................................................................................
# . EXAMPLE:
# . >> The input file has the contents:
# .
# .     #This is a data set for testing small numbers of time steps.
# .     #PARAMETER        VALUE            COMMENT
# .     gNa               35.0             Fast sodium channel conductivity.
# .     nx                256              Number of neurons in cortical slice.
# .     concMg            3                Mg2+ concentration (mM).
# .
# . The expected header line is as indicated above. 
# . Entries in different columns are tab-separated.
# . White space at start and end of individual entries is stripped.
# .
# . The assignments are returned as literals in the output list. Thus for
# . the example above, the values are returned as :
# .
# .     p$gNa = "35.0";
# .     p$nx = "256";
# .     p$concMg = "3";
# .
# ====================================================================================================

File.readParam <- function(fin)
{

	# ..............................................................................
	if (!is.character(fin)) {
	   msg = paste("ERROR: from File.readParam: fin parameter = ", 
                        fin, " is not of type character.\n");
	   stop(msg);
	}
	# ..............................................................................


        
        # .............................................................
        cat(" ..........  Reading parameter input file: ", fin, "\n");
        # ............................................................. 
        

        
	# .............................................................................
        # . Read all rows in the file:
	# .............................................................................
        arow = scan(fin, what = 'character', sep = "\n");
        nrow = length(arow);

        if (nrow == 0) {
	   msg = paste("ERROR: from File.readParam: input file is empty.\n");
	   stop(msg);          
        }
	# .............................................................................



	# .............................................................................
        # . Find the header :
	# .............................................................................
        headerExpected = "#PARAMETER\tVALUE\tCOMMENT";
        flagFound = FALSE;

        for (i in 1:nrow) {
          line = arow[i];
          if (line == headerExpected) {
            iheader = i;
            flagFound = TRUE;
            break;
          }
        }

        if (!flagFound) {
          msg = paste("ERROR: from File.readParam:\n");
          msg = paste(msg, "I could not find the expected header in the input file.\n");
          msg = paste(msg, "Expected header =", headerExpected);
          stop(msg);          
        }
	# .............................................................................

        

	# .............................................................................
        # . March through the rows and find if there are matches:
       	# .............................................................................
        h = list();
        
        if (nrow > iheader) {
          iheader1 = iheader + 1;
          
          for (i in iheader1:nrow) {
            line = arow[i];
            line = sub("^\\s+", "", line);
            line = sub("\\s+$", "", line);

            if (nchar(line) == 0) {
              next;                        # Skip blank lines.
            }

            if (length(grep("^#", line, perl = TRUE)) > 0) {
              next;                        # Skip blank lines starting with #.
            }
            # .........................................................................
            # . Parse line contents :
            # .........................................................................            
            al = strsplit(line, split="\\t", perl=TRUE)[[1]];

            if (length(al) < 2) {
              msg = paste("ERROR: from File.readParam:\n");
              msg = paste(msg, "A line in the input file has less than 2 items.\n");
              msg = paste(msg, "line =", line);
              stop(msg);          
            }
            
            if (length(al) >= 2) {
              param = al[1];
              value = al[2];

              param = sub("^\\s+", "", param);
              param = sub("\\s+$", "", param);              

              value = sub("^\\s+", "", value);
              value = sub("\\s+$", "", value);

              if (nchar(param) == 0) {
                msg = paste("ERROR: from File.readParam:\n");
                msg = paste(msg, "A line in the input file has a blank parameter\n");
                msg = paste(msg, "line =", line);
                stop(msg);          
              }

              if (nchar(value) == 0) {
                msg = paste("ERROR: from File.readParam:\n");
                msg = paste(msg, "A line in the input file has a blank value\n");
                msg = paste(msg, "line =", line);
                stop(msg);          
              }              

              h[[param]] = value;
            }
            # .........................................................................            
          }
        }
      	# .............................................................................

        

      	# ....................................................................................
        # . Final tally of assignments:
      	# ....................................................................................
        if (length(names(h)) == 0) {
          msg = paste("ERROR: from File.readParam:\n");
          msg = paste(msg, "0 parameters assignments were found in the input parameter file.\n");
          msg = paste(msg, "line =", line);
          stop(msg);          
        } else {
          nparam = length(names(h));
          cat(" ..........  ", nparam, " parameters found in input file.\n");
        }
      	# ....................................................................................

        
        
	# ...............
	return (h);
        # ...............

}

# ====================================================================================================
# . End of File.readParam.
# ====================================================================================================



# ====================================================================================================
# . File.generateRandomName : generates a random file name, using given directory and stem names.
# . -----------------------
# .
# .   Syntax :
# . 
# .          fname = File.generateRandomName(dirName, stemName, ext);
# .
# .    In:
# .
# .      dirName = name of directory.
# .     stemName = stem name for generating the basename.
# .          ext = file extension.
# .
# .    Out:
# .     
# .
# ====================================================================================================

File.generateRandomName <- function(dirName, stemName, ext)
{


       # .....................................................................
       stopifnot(nchar(dirName) > 0, nchar(stemName) > 0);
       # .....................................................................


       # .....................................................................
       stemName = gsub("\\s+", "_", stemName, perl = TRUE);
       stemName = gsub("\\.", "_", stemName, perl = TRUE);

       if (length(grep("\\s+", dirName)) > 0) {
         cat("ERROR: from File.generateRandomName: dirName = ",
             dirName, " contains white space.\n", sep = "");
         stop()
       }

       if (length(grep("\\.", stemName)) > 0) {
         cat("ERROR: from File.generateRandomName: stemName = ",
             stemName, " contains a period.\n", sep = "");
         stop()
       }              
       # .....................................................................  

       
       # .....................................................................
       dirName = sub("\\/$", "", dirName, perl = TRUE);   # Strip lagging /.

       temp1 = as.character(proc.time()[3]);
       temp1 = sub("\\.", "_", temp1, perl = TRUE);       # Elapsed time.
       temp2 = sample(1:100000, 1);                       # Random number in 1:1e5

       fbase = paste(stemName, "-", temp1, "-", temp2, ".", ext, sep = "");
       fname = paste(dirName, "/", fbase, sep = "");
       # .....................................................................


       # ................
       return (fname);
       # ................
  
}

# ====================================================================================================
# . End of File.generateRandomName.
# ====================================================================================================




# ====================================================================================================
# . File.readQlist :  reads a generic list of ``qualifiers'', which are most commonly gene names.
# . --------------
# .
# .   Syntax :
# . 
# .          aq = File.readQlist(fq);
# .
# .    In:
# .
# .      fq = name of file containing the qualifier list.
# .
# .    Out:
# .
# .      aq = array, containing the qualifiers.
# .
# ....................................................................................................
# .  Format of file contents :
# .
# .  #QUAL                                        
# .  genename1                                    
# .  genename2                                    
# .  #genename2                                   
# .    . . .                                        
# .  All gene entries starting with # are ignored.
# .
# .
# ====================================================================================================

File.readQlist <- function(fq)
{
  
     # ......................................................................................
     abuf = scan(fq, what = 'character', sep = '\n');

     if (abuf[1] != '#QUAL') {
       cat("ERROR: from File.readQlist:\n");
       cat("Input file does not start with header: #QUAL\n");
       cat("Input file fq = ", fq, " \n", sep = "");
       msg = "";
       stop(msg);
     }

     indexBuf = grep("^#", abuf, invert = TRUE);   # All elements that do not start with #.

     if (length(indexBuf) == 0) {
       cat("ERROR: from File.readQlist:\n");
       cat("All items in the input file start with #\n");
       cat("Input file fq = ", fq, " \n", sep = "");
       msg = "";
       stop(msg);
     }
         
     aq = abuf[indexBuf];                       # Restricted list.
     # .......................................................................................



     # ............
     return (aq);
     # ............
         

}

# ====================================================================================================
# . End of File.readQlist.
# ====================================================================================================




# ====================================================================================================
# . File.getExt : simple utility function, gets file extension.
# . -----------
# .
# .  Syntax:
# .           ext = File.getExt(fname);
# .
# .  In:
# .           fname = file name.
# .
# .  Out:
# .             ext = file extension.
# .
# ....................................................................................................
# . * Example :
# .
# .     If fname = "filePh2Ph3.COXPH" then ext = "COXPH".
# .
# .   If there is no extension, returns a string of 0 length.
# .
# ====================================================================================================

File.getExt <- function(fname)
{
  
    # ................................................................
    pos = regexpr("\\.\\w+$", fname, perl = TRUE);

    if (pos == -1) {
      ext = "";
    } else {
      ext = substring(fname, first = pos + 1, last = nchar(fname));
    }
    # ................................................................


    # .............
    return (ext);
    # .............

}

# ====================================================================================================
# . End of File.getExt.
# ====================================================================================================



