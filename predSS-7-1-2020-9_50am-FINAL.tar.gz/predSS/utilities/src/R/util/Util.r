# =====================================================================================
# .  Util.r: various utilities.
# .  ------  
# .
# =====================================================================================



# =======================================================================================
# . Util.getExt : gets extension in a file name.
# . -----------
# .
# . Syntax:
# .
# .     aext = Util.getExt(af);
# .
# . In :
# .       af = single file name or array of file names.
# .
# . Out :
# .     aext = corresponding extension(s).
# .
# =======================================================================================

Util.getExt <- function(af)
{

  # .......................................................................................................
  abuf = strsplit(af, split = "\\.", perl = TRUE);	# Splits each element of fin by the character "."
  aext = sapply(abuf, function(x){x[length(x)]});       # Retrieve last element of each list.
  # .......................................................................................................

  # ..............
  return (aext);
  # ..............

}

# =======================================================================================
# . End of Util.getExt.
# =======================================================================================



# =======================================================================================
# . Util.colnames : displays column names in table format.
# . -------------
# .
# . Syntax :
# .              Util.colnames(dfA);
# .
# . In :
# .          dfA = input data frame or matrix.
# .     
# =======================================================================================

Util.colnames <- function(dfA)
{
     # ......................................................
     write.table(colnames(dfA), sep = "\t", quote = FALSE);
     # ......................................................
     
}

# =======================================================================================
# . End of Util.colnames.
# =======================================================================================




# =======================================================================================
# . Util.rownames : displays row names in table format.
# . -------------
# .
# . Syntax :
# .              Util.rownames(dfA);
# .
# . In :
# .          dfA = input data frame or matrix.
# .     
# =======================================================================================

Util.rownames <- function(dfA)
{
     # ......................................................
     write.table(rownames(dfA), sep = "\t", quote = FALSE);
     # ......................................................
     
}

# =======================================================================================
# . End of Util.rownames.
# =======================================================================================



# =======================================================================================
# . Util.colClasses : displays column classes in table format.
# . ---------------
# .
# . Syntax :
# .              Util.colClasses(dfA);
# .
# . In :
# .          dfA = input data frame.
# .     
# =======================================================================================

Util.colClasses <- function(dfA)
{
     # .................................................................
     write.table(DataFrame.getClasses(dfA), sep = "\t", quote = FALSE);
     # .................................................................
     
}

# =======================================================================================
# . End of Util.colClasses.
# =======================================================================================



# =======================================================================================
# . Util.writeTable : wraps simpe formating to display a table in tab-separated format.
# . ---------------
# .
# . Syntax :
# .              Util.writeTable(ff, flagSort = FALSE, file = "");
# .
# . In :
# .          ff = input table.
# .
# .    flagSort = if TRUE, numerically sort in decreasing order before display.
# .
# .        file = file name or connection. file = "" means writing to console.
# .
# =======================================================================================

Util.writeTable <- function(ff, flagSort = FALSE, file = "")
{
     # .................................................................
     cat("\t", file = file);

     if (flagSort) {
       write.table(sort(ff), file = file, sep = "\t", quote = FALSE);
     } else {
       write.table(ff, file = file, sep = "\t", quote = FALSE);
     }
     # .................................................................
     
}

# =======================================================================================
# . End of Util.writeTable.
# =======================================================================================



# =======================================================================================
# . Util.readLine : pauses execution, waits for user input. A carriage return to
# . -------------   continue, q to quit.
# .
# . Syntax :
# .            Util.readLine();
# .
# =======================================================================================

Util.readLine <- function()
{

     # ...............................................................................
     buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.

     if (buf == 'q') {
       stop();
     }
     # ...............................................................................     

     
     # ..................
     return ();
     # ..................
     
}

# =======================================================================================
# . End of Util.readLine.
# =======================================================================================


# =======================================================================================
# . Util.trimws : trims leading and lagging white space for every element in the 
# . -----------   input array. This is a replacement for the base function trimws()
# .               in older versions of R (R < 3.3.0 I believe) which do not have it.
# .               N.B. : this implements only the default version of trimws (trims
# .               both leading and lagging).
# .
# . Syntax :
# .                    y = Util.trimws(x);
# .
# .                 
# =======================================================================================


Util.trimws <- function(x) 
{

       # ................................................
       y1 = gsub("^[ \t\r\n]+", "", x, perl = TRUE);
       y = gsub("[ \t\r\n]+$", "", y1, perl = TRUE);
       # ................................................

       
       # ..............
       return (y);
       # ..............       

}

# =======================================================================================
# . End of Util.trimws.
# =======================================================================================




# =======================================================================================
# . Util.findFunctions : lists functions that have been loaded in the R environment,
# . ------------------   using a set of tokens.
# .               
# .               
# . Syntax :
# .
# .             Util.findFunctions(ak, connect = 'and');
# .
# . In :
# .
# .         ak = array of key strings to search by.
# .              Search is case-independent.
# .
# .         connect = logic of search syntax. Valid : and, or.
# .
# =======================================================================================


Util.findFunctions <- function(ak, connect = 'and') 
{

       # ...................................................
       stopifnot((connect == 'and') || (connect == 'or'));
       # ...................................................


       # ...........................................................................
       af = ls();                        # List of functions and data objects.
       # ...........................................................................       

       
       # ...........................................................................
       # . Implement 'and' :
       # ...........................................................................
       if (connect == 'and') {
         nk = length(ak);
         
         for (i in 1:nk) {
           indexBuf = grep(ak[i], af, ignore.case = TRUE, perl = TRUE);
           af = af[indexBuf];

           if (length(indexBuf == 0)) {
             break;
           }
         }
       }
       # ...........................................................................
       # . Implement 'or' :
       # ...........................................................................
       if (connect == 'or') {
         ak.all = paste(ak, collapse = "|");
         indexBuf = grep(ak.all, af, ignore.case = TRUE, perl = TRUE);
         af = af[indexBuf];
       }
       # ..........................................................................           

       
       # ..............
       return (af);
       # ..............       

}

# =======================================================================================
# . End of Util.findFunctions.
# =======================================================================================






# =======================================================================================
# . Util.getFileSize : returns file size in Mb.
# . -------------   
# .               
# .               
# . Syntax :
# .
# .           s = Util.getFileSize(fX);
# .
# . In :
# .
# .           fX = file name.
# .
# =======================================================================================


Util.getFileSize <- function(fX)
{

       # .....................................................
       # . Get the file size in Mb :
       # .....................................................
       s = file.info(fX)[1, 1] / 1.0e6;
       # .....................................................
       
       
       # ..............
       return (s);
       # ..............       

}

# =======================================================================================
# . End of Util.getFileSize.
# =======================================================================================



# =======================================================================================
# . Util.readLineQ : pauses execution, waits for user input. A carriage return to
# . ------------------   continue, q to quit. This queries the user for a possible 'skip'
# .                      entry as welll as 'quit'.
# .
# . Syntax :
# .            buf = Util.readLineQ(text = "s to skip :");
# .
# =======================================================================================

Util.readLineQ <- function(text = "s to skip :")
{

     # ...............................................................................
     cat(">>Enter a carriage return to continue, q to quit, ");
     cat(text);
     buf = readline("");    # Pause.

     if (buf == 'q') {
       stop();
     }
     # ...............................................................................     

     
     # ..................
     return (buf);
     # ..................
     
}

# =======================================================================================
# . End of Util.readLineQ.
# =======================================================================================




# =======================================================================================
# . Util.getObjectSizes : returns sorted list of current object sizes.
# . -------------------
# .
# . Syntax :
# .            dfS = Util.getObjectSizes();
# .
# =======================================================================================

Util.getObjectSizes <- function()
{

     # ...............................................................................
     aob = ls(envir = globalenv());
     as = sapply(aob, function(x){object.size(get(x))});

     dfS = data.frame("objectName" = aob, "size" = as);
     dfS = dfS[order(as, decreasing = TRUE), ];
     # ...............................................................................     

     
     # ..................
     return (dfS);
     # ..................
     
}

# =======================================================================================
# . End of Util.getObjectSizes.
# =======================================================================================




# =======================================================================================
# . Util.getInstalledPackages : returns list of installed packages.
# . -------------------------
# .
# . Syntax :
# .            ap = Util.getInstalledPackages();
# .
# =======================================================================================

Util.getInstalledPackages <- function()
{
  
      # .................................................
      ap = installed.packages()[  , 1];
      # .................................................


      # ....................
      return (ap);
      # ....................      

}

# =======================================================================================
# . End of Util.getInstalledPackages.
# =======================================================================================



# =======================================================================================
# . Util.isInstalled : returns logical flag(s) indicating whether a package is installed 
# . ----------------   or not.
# .
# . Syntax :
# .
# .      flag = Util.isInstalled(ap);
# .
# . In :
# .
# .        ap = list of packages to be ested.
# .
# =======================================================================================

Util.isInstalled <- function(ap)
{
  
      # .................................................
      ap.ins = installed.packages()[  , 1];
      flag = (ap %in% ap.ins);
      # .................................................


      # ....................
      return (flag);
      # ....................      

}

# =======================================================================================
# . End of Util.isInstalled.
# =======================================================================================




# =======================================================================================
# . Util.readFunctionDescriptions : reads the 'R.functionDescriptions' file contents
# . -----------------------------   into a data frame.
# .
# . Syntax :
# .
# .      dfR = Util.readFunctionDescriptions(fR);
# .
# . In :
# .
# .        fR = 'R.functionDescriptions' file.
# .
# =======================================================================================

Util.readFunctionDescriptions <- function(fR)
{
  
      # .........................................................................................
      abuf = scan(file = fR, what = "character", sep = "\n", quote = '');

      index1 = grep("^#package", abuf)[1];
      abuf1 = abuf[index1:length(abuf)];

      dfR = read.table(text = abuf1,
                              sep = "\t",
                              comment.char = '',
                              quote = "",
                              header = TRUE,
                              check.names = FALSE,
                              fill = TRUE);            # Use fill = TRUE to add blanks when needed
      # .........................................................................................


      # .............
      return (dfR);
      # .............

}

# =======================================================================================
# . End of Util.readFunctionDescriptions.
# =======================================================================================




# =======================================================================================
# . Util.resetTempDir : resets the R tmp directory, which may get periodically wiped
# . -----------------    out by automated disk clean up.
# .
# . Syntax :
# .
# .      tempDir = Util.resetTempDir();
# .
# =======================================================================================

Util.resetTempDir <- function()
{

       # ........................................................................................
       tempDir = tempdir();

       if (!file.exists(tempDir)) {
         dir.create(tempDir);
       } else {
         cat(" ..........  Temp directory = ", tempDir, " already exists. Do nothing.\n", sep = "");
       }
       # ........................................................................................


       # .....................
       return (tempDir);
       # .....................  

}

# =======================================================================================
# . End of Util.resetTempDir.
# =======================================================================================



# ============================================================================================
# . Util.strWrap : breaks a long string by putting in carriage returns at periodic intervals.
# . ------------
# .
# . Syntax :
# .
# .    y = Util.strWrap(x, k);
# .
# . In :
# .
# .   x = input string.
# .
# .   k = interval size,
# .
# ============================================================================================

Util.strWrap <- function(x, k)
{

      # ....................  
      stopifnot(k >= 1);
      # ....................        

      
      # ............................................
      xbuf = unlist(strsplit(x, split = ""));
      n = length(xbuf);
      index0 = 1:n;

      offset = (index0 - 1) %/% k;
      index1 = index0 + offset;

      names(index0) = index1;
      npadded = max(index1);
      ybuf = rep("\n", npadded);
      ybuf[index1] = xbuf;
      
      y = paste(ybuf, collapse = "");
      # ............................................


      # ............
      return (y);
      # ............

     

}

# ============================================================================================
# . End of Util.strWrap.
# ============================================================================================






# ============================================================================================
# . Util.findFunctionCallsOnModule : in a given string of text or file finds distinct instances of
# . ------------------------------   function calls for a given module.
# .
# . Syntax :
# .
# .    af = Util.findFunctionCallsOnModule(fIn = NULL, txt = NULL, module);
# .
# . In :
# .
# .
# ============================================================================================

Util.findFunctionCallsOnModule <- function(fIn = NULL, text = NULL, module)
{
      
      # .....................................................................................
      stopifnot(!is.null(fIn) | !is.null(text));
      module = gsub("\\.$", "", module);
      # .....................................................................................


      
      # ...............................................................................................
      # . Split input into lines :
      # . Note that file has precedence over text input.
      # ...............................................................................................
      if (!is.null(fIn)) {
        abuf0 = scan(file = fIn, what = "character", sep = "\n");
      } else {
        abuf0 = unlist(strsplit(text, split = "\n"));
      }
      # ................................................................................................

      
      # .....................................................................................
      # . Remove all-comment lines :
      # .....................................................................................      
      atemp = gsub("^\\s+", "", abuf0);
      indexIn = grep("^#", atemp, invert = TRUE);
      abuf = abuf0[indexIn];
      # .....................................................................................
      # . Split into words :
      # .....................................................................................      
      lbuf = strsplit(abuf, split = "\\s+");
      abuf1 = unlist(lbuf);
      # .....................................................................................
      # . Get values :
      # .....................................................................................      
      module1 = paste0(module, "\\.");
      af = grep(module1, abuf1, value = TRUE);
      index0 = grep(module1, abuf1);                      # For debugging.
      af1 = gsub("\\(.*$", "", af);
      # .....................................................................................
      # . Further filter :
      # .....................................................................................      
      indexIn1 = grep("\\:", af1, invert = TRUE);
      indexIn2 = grep("\\..*\\.", af1, invert = TRUE);
      indexIn = intersect(indexIn1, indexIn2);
      af2 = af1[indexIn];
      # .....................................................................................
      # . Final sort :
      # .....................................................................................            
      af3 = sort(unique(af2));
      # .....................................................................................


      # .....................................................................................
      af = af3;              # Reset.
      nf = length(af3);
      # .....................................................................................


      # ............
      return (af);
      # ............

}

# ============================================================================================
# . End of Util.findFunctionCallsOnModule.
# ============================================================================================




# ===============================================================================================================
# . Util.findFunctionCallsOnMultipleModules : in a given file finds distinct instances of
# . ---------------------------------------   function calls for a list of modules.
# .
# . Syntax :
# .
# .    dfF = Util.findFunctionCallsOnMultipleModules(fIn, amod);
# .
# . In :
# .
# .  fIn = input file name (usually with extension .r).
# .
# .  amod = list of modules (usually without any extensions, but can deal with .r).
# .
# . Out :
# .
# .   dfF = table with columns: file name, module, number of distinct function calls, and functions.
# .
# ===============================================================================================================

Util.findFunctionCallsOnMultipleModules <- function(fIn, amod)
{
      
      # ...............................................................................................
      # . Visit the file for each module separately :
      # ...............................................................................................
      amod = gsub("\\.r$", "", amod);
      nmod = length(amod);
      lbuf = list();
      an = c();
      
      for (i in 1:nmod) {
        afbuf = Util.findFunctionCallsOnModule(fIn = fIn, module = amod[i]);
        nfbuf = length(afbuf);
        if (nfbuf == 0) {
          next;
        }
        dfBuf = data.frame("file" = fIn, "module" = rep(amod[i], nfbuf), "nf" = nfbuf, 
                           "functions" = afbuf, check.names = FALSE);
        lbuf[[i]] = dfBuf;
      }
      # ................................................................................................


      # ................................................................................................
      dfF = NULL;
      
      if (length(lbuf) > 0) {
        dfF = do.call("rbind", lbuf);
      }
      # ................................................................................................      

      
      # ................
      return (dfF);
      # ................

}

# ============================================================================================
# . End of Util.findFunctionCallsOnMultipleModules.
# ============================================================================================







# ===============================================================================================================
# . Util.findFunctionCallsOnMultipleModulesSeries : in a *series* of files finds distinct instances of
# . ---------------------------------------------   function calls for a list of modules.
# .
# . Syntax :
# .
# .       cq = Util.findFunctionCallsOnMultipleModulesSeries(af, amod);
# .
# . In :
# .
# .  af = list of input file name (usually with extension .r).
# .
# .  amod = list of modules (usually without any extensions, but can deal with .r).
# .
# . Out : cq = list with members :
# .
# .        dfF = table with columns: file name, module, number of distinct function calls, and functions.
# .        afun = array with list of distinct function calls.
# .        amod = array with list of distinct module names present in function calls.
# .
# ===============================================================================================================

Util.findFunctionCallsOnMultipleModulesSeries <- function(af, amod)
{

      # ...............................................................................................
      flag = !file.exists(af);
      nflag = sum(flag);

      if (nflag > 0) {
        cat("ERROR: from Util.findFunctionCallsOnMultipleModulesSeries:\n");
        cat("Missing input files.\n");
        stop();
      }
      # ...............................................................................................

      
      # ...............................................................................................
      # . Visit each file :
      # ...............................................................................................
      nf = length(af);
      lbuf = list();
      kc = 1;
      
      for (i in 1:nf) {
        cat("Processing file : ", af[i], "\n", sep = "");
        dfBuf = Util.findFunctionCallsOnMultipleModules(fIn = af[i], amod = amod);

        if (!is.null(dfBuf)) {
          lbuf[[kc]] = dfBuf;
          kc = kc + 1;
        }
      }
      # ................................................................................................


      # ................................................................................................
      cq = NULL;
      
      if (length(lbuf) > 0) {
        dfF = do.call("rbind", lbuf);
        afun = sort(unique(as.character(dfF$functions)));
        amod = sort(unique(as.character(dfF$module)));

        cq =  list(dfF = dfF, afun = afun, amod = amod);
      }
      # ................................................................................................      

      
      # ................
      return (cq);
      # ................

}

# ============================================================================================
# . End of Util.findFunctionCallsOnMultipleModulesSeries.
# ============================================================================================
