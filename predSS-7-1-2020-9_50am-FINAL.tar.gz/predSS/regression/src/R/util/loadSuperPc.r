# ================================================================================
# . loadSuperPc.r : generic set of scripts for loading all super pc functions
# . -------------   under the regression tree. This includes the .r files under
# .                 the directories:
# .
# .                   compute
# .                   drivers
# .                    
# ================================================================================


# ================================================================================
# . loadSuperPc : the load program itself.
# . -----------
# . 
# .              loadSuperPc();
# .
# ================================================================================

loadSuperPc <- function()
{

 # ...............................................................
 dirHere = getwd();      # The current Makefile directory.
 # ...............................................................


 # ...............................................................
 cat (" ..........  Loading super pc functions.\n");
 # ...............................................................


 # ..............................................................................
 # . Load from each subdirectory in turn:
 # .
 # . compute:
 # ..............................................................................
 au = c("SuperPc.r", "SuperPcCv.r", "SuperPcSim.r", "Cox.r", "SuperPcDiag.r",
        "Regress.r", "BasicCox.r", "BasicCoxCv.r", "BasicCoxDiag.r",
        "SuperPcBoot.r", "Logistic.r", 
        "Glmnet.r", "GlmnetDiag.r", "GlmnetCv.r");

 for (fbase in au) {
    fcode = paste(dirHere, "/./regression/src/R/compute/", fbase, sep = "");
    source(fcode);
 }
 # ..............................................................................
 # . drivers:
 # ..............................................................................
 au = c("InparamReg.r",
        "run_generate_sim_data_cox.r",
        "run_test_super_pc_cox.r",
        "run_super_pc_cox.r",
        "run_super_pc_cox_cv.r",
        "run_super_pc_cox_fs.r",
        "run_super_pc_cox_uni.r",
        "run_generate_sim_data_cox.r",
        "run_generate_sim_data_cox_with_cov.r",
        "run_super_pc_cox_uni_with_cov.r",
        "run_super_pc_cox_with_cov.r",
        "run_super_pc_cox_cv_with_cov.r",
        "run_super_pc_cox_cv_with_cov_random.r",
        "run_super_pc_cox_cv_with_cov_single.r",
        "run_basic_cox_cv_with_cov_single.r",
        "run_basic_cox_with_cov.r",
        "run_roc_on_coxph.r",
        "run_coxnet_with_cov.r",
        "run_coxnet_cv_with_cov.r",
        "run_coxnet_cv_with_cov_boot.r",
        "run_super_pc_cox_cv_with_cov_boot.r",
        "run_basic_cox_cv_with_cov_boot.r");

 for (fbase in au) {
    fcode = paste(dirHere, "/./regression/src/R/drivers/", fbase, sep = "");
    source(fcode);
 }
 # ..............................................................................


 # .......................................................
 cat (" ..........  All super pc functions loaded.\n");
 # .......................................................

	
 # ...........
 return (0);
 # ...........

}

# ================================================================================
# . End of loadSuperPc.
# ================================================================================


loadSuperPc();      # The main program is executed here.


