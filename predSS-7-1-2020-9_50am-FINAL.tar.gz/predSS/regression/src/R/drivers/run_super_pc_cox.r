# =======================================================================================================
# . run_super_pc_cox : computes a Cox proportional hazard model on the indicated training set,
# . ----------------   using supervised principal components analysis based on feature selection 
# .                    and singular value decomposition.
# .
# .......................................................................................................
# . See the function:
# .
# .                   Inparamreg.getCommandLineSuperPcCox
# .
# . in module:
# .
# .                   InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Type :
# .
# .     run_super_pc_cox("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_super_pc_cox <- function(commandString)
{

	# .................................................................................
      	cat(" ..........  Begin execution of program: run_super_pc_cox\n");
   	# .................................................................................

        

   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_super_pc_cox", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineSuperPcCox(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read the input data files to get the input data matrices :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");

        dfX = DataFrame.readDataMatrix(inparam$fx);  # Numerical data.
        dfE = read.table(file = inparam$fe);         # Experimental design.
   	# ..........................................................................................



   	# ..........................................................................................
        # . Check consistency of input data matrices :
   	# ..........................................................................................        
        msg = SuperPc.checkDataMatricesForCox(dfX, dfE, inparam);

        if (msg != 'ok') {
          cat(msg, "\n", sep = "");
          stop();
        }
   	# ..........................................................................................



   	# ..........................................................................................
        # . Extract the training set from the input data matrices.
        # . Note that if tTrain = NONE, then all instances are used in
        # . training set.
   	# ..........................................................................................
        if (inparam$tTrain != 'NONE') {
          dfXTrain = dfX[dfE[[inparam$tTrain]] == 'train', ]; 
          dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ];
        } else {
          dfXTrain = dfX;
          dfETrain = dfE;
        }
        # .........................................................................................
        


   	# ..........................................................................................
        # . Extract the test set from the input data matrices, provided tTest != NONE.
        # . Otherwise set to NULL.
   	# ..........................................................................................
        if (inparam$tTest != 'NONE') {
          dfXTest = dfX[dfE[[inparam$tTest]] == 'test', ]; 
          dfETest = dfE[dfE[[inparam$tTest]] == 'test', ];

          atTest = dfETest[[inparam$tTime]];         # Survival times.
          asTest = dfETest[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
        } else {
          dfXTest = NULL;
          dfETest = NULL;

          atTest = NULL;
          asTest = NULL;
        }
        # .........................................................................................
        

        
 
        
   	# ...............................................................................................
        # . >> COMPUTATION :
        # .
        # . Compute the Cox proportional hazard model on the training set :
        # ...............................................................................................
        cat(" ..........  Compute the Cox proportional hazard model on the training set.\n");

        atTrain = dfETrain[[inparam$tTime]];         # Survival times.
        asTrain = dfETrain[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).

        spc = SuperPc.computeCox(at = atTrain,
                                 as = asTrain,
                                 dfX = dfXTrain,
                                 scoreType = inparam$scoreType,
                                 methodFs = inparam$methodFs,
                                 p0 = inparam$p0,
                                 mtop = inparam$mtop,
                                 K = inparam$K,
                                 flagVerbose = TRUE);

        cat(" ..........  Computation done.\n");
        # ...............................................................................................


        

        # ...............................................................................................
        # . Compute the statistical significance of the model for both training and test
        # . sets (if the latter is defined):
        # ...............................................................................................
        csTrain = SuperPc.computeCoxSignificanceOnSplit(atTrain, asTrain, dfXTrain, spc);

        if (inparam$tTest != 'NONE') {
          csTest = SuperPc.computeCoxSignificanceOnSplit(atTest, asTest, dfXTest, spc);
        } else {
          csTest = NULL;
        }
        # ...............................................................................................        


        

   	# .............................................................................
        # . >>OUTPUT FILES :
        # . Write the statistical summary :
   	# .............................................................................
        SuperPcDiag.writeCoxSummary(spc, csTrain, csTest, inparam$fs);
   	# .............................................................................        
        # . Write the K principal components (projections onto pc vectors) and estimated
        # . hazard ratios for *all* samples, including those not in the training set.
        # .............................................................................
        SuperPcDiag.writeCoxPcDataMatrix(spc, dfX, dfE, inparam$fo);
        # .............................................................................
        # . Write the actual K pc vectors :
        # .............................................................................        
        SuperPcDiag.writeCoxPcVectors(spc, dfXTrain, inparam$fv);
   	# .............................................................................

        
   	# .............................................................................
        # . >>PLOTS :
   	# .............................................................................        
        if (inparam$flagPlot == 'yes') {
          # ............................................................................
          # . If flagPlotWrite = 'no', generate plots interactively.
          # . If flagPlotWrite = 'yes', save the plots one-by-one as jpeg files in 
          # . the indicated directory, and create an html file which refers to the
          # . images.
          # ............................................................................          
          sp = SuperPcDiag.plotCox(at = atTrain, as = asTrain, dfX = dfXTrain, spc = spc,
                                   flagWrite = inparam$flagPlotWrite,
                                   dirName = inparam$dirPlot, stemName = "temp-cox");
          # ............................................................................
          # . Plot test data if it was also specified :
          # ............................................................................
          if (inparam$tTest != 'NONE') {
            spTest = SuperPcDiag.plotCoxOnTest(at = atTest, as = asTest, dfX = dfXTest, spc = spc,
                                               flagWrite = inparam$flagPlotWrite,
                                               dirName = inparam$dirPlot, stemName = "temp-cox");

            sp = SuperPcDiag.addPlots(sp, spTest);            # Add the plots for the test data.
          }            
          # ............................................................................
          # . Generate html file with plot file pointers:
          # ............................................................................          
          if (inparam$flagPlotWrite == 'yes') {
            SuperPcDiag.writePlotFile(sp = sp, fplot = inparam$fplot);
          }
          # ............................................................................          
        }
   	# .............................................................................

        
	# ............................................................
      	cat(" ..........  End of execution of run_super_pc_cox.\n");
   	# ............................................................


   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================
