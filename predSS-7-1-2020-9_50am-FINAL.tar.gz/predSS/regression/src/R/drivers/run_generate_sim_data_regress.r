# =======================================================================================================
# . run_generate_sim_data_regress : generates files containing simulated data for testing out the
# . -----------------------------   supervised principal components regression models.
# .                
# .......................................................................................................
# . See the function:
# .
# .                   Inparamreg.getCommandLineGenerateSimDataRegress
# .
# . in module:
# .
# .                   InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Useage:
# .
# .     run_generate_sim_data_regress("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

#xxx library(MASS);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_generate_sim_data_regress <- function(commandString)
{

	# .................................................................................
      	cat(" ..........  Begin execution of program: run_generate_sim_data_regress\n");
   	# .................................................................................


   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_generate_sim_data_regress", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineGenerateSimDataRegress(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................



	# .....................................................................................................
	# . Generate the simulated data set :
	# .....................................................................................................
        dTrain = SuperPcSim.generateDataRegress(inparam$nTwoRegion,
                                                inparam$nFourRegion,
                                                inparam$nb,
                                                inparam$rngSeed,
                                                inparam$sigma,
                                                inparam$generatingPanel,
                                                inparam$modelType,          
                                                inparam$betaSim0,
                                                inparam$betaSim1,
                                                inparam$sigmaY)
	# .....................................................................................................
	# . Graphics will follow :
	# .....................................................................................................
        cat(">>Plots will follow.\n");
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
	# .....................................................................................................
        # . Set current display size :
	# .....................................................................................................
	dev.new(width = 960, height = 960); 
	# .....................................................................................................
	# . Display the gene expression data matrix :
	# .....................................................................................................
        SuperPcDiag.plotGeneDataMatrix(ax = dTrain$A, caption = "Training set data matrix");

        buf = readline(">>Enter a carriage return to continue: ");    # Pause.        
	# .....................................................................................................
	# . Display survival times and generating covariate :
	# .....................................................................................................
        SuperPcSim.plotOutputVariableRegress(dTrain,
                                             inparam$generatingPanel,
                                             inparam$betaSim0,
                                             inparam$betaSim1,
                                             modelType = inparam$modelType);
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.        
	# .....................................................................................................




	# ....................................................................................
        # . Write to output files :
	# ....................................................................................
        dfXT = as.data.frame(t(dTrain$dfX));
        DataFrame.write(dfXT, inparam$fdv);
        DataFrame.write(dTrain$dfE, inparam$fe);

        cat(" ..........  Gene expression data written to file : ", inparam$fdv, "\n", sep = "");
        cat(" ..........  Survival data written to file : ", inparam$fe, "\n", sep = "");        
	# ....................................................................................

        

	# .....................................................................
      	cat(" ..........  End of execution of run_generate_sim_data_regress.\n");
   	# .....................................................................


   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================
