# =======================================================================================================
# . run_super_pc_cox_cv_with_cov_random : Does cross-validation of a Cox proportional hazard model 
# . -----------------------------------   on the indicated training set, using supervised
# .                                       principal components analysis based on
# .                                       feature selection and singular value decomposition. 
# .                                       Includes an external covariate as well.
# .                                       This version performs an external randomization loop,
# .                                       so as to generate a baseline against which to gauge the
# .                                       significance of the cross-validation result.
# .
# .......................................................................................................
# . See the function:
# .
# .        Inparamreg.getCommandLineSuperPcCoxCvWithCov
# .
# . in module:
# .
# .        InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Type :
# .
# .     run_super_pc_cox_cv_with_cov_random("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_super_pc_cox_cv_with_cov_random <- function(commandString)
{

	# .....................................................................................
      	cat(" ..........  Begin execution of program: run_super_pc_cox_cv_with_cov_random\n");
   	# .....................................................................................

        

   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_super_pc_cox_cv_with_cov_random", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineSuperPcCoxCvWithCov(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read the input data files to get the input data matrices :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");

        dfX = DataFrame.readDataMatrix(inparam$fx);  # Numerical data.
        dfE = read.table(file = inparam$fe);         # Experimental design.
   	# ..........................................................................................



   	# ..........................................................................................
        # . Check consistency of input data matrices :
   	# ..........................................................................................        
        msg = SuperPc.checkDataMatricesForCoxCvWithCov(dfX, dfE, inparam);

        if (msg != 'ok') {
          cat(msg, "\n", sep = "");
          stop();
        }
   	# ..........................................................................................



   	# ..........................................................................................
        # . Extract the training set data from the input data matrices :
   	# ..........................................................................................            
        if (inparam$tTrain != 'NONE') {
          dfXTrain = dfX[dfE[[inparam$tTrain]] == 'train', ]; 
          dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ];
        } else {
          dfXTrain = dfX;
          dfETrain = dfE;
        }

        atTrain = dfETrain[[inparam$tTime]];         # Survival times.
        asTrain = dfETrain[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
        azTrain = dfETrain[[inparam$tCov]];          # Additional external covariate.                

        if (inparam$methodSplit == 'given') {
          af = dfETrain[[inparam$tSplit]];           # Assigns to given train and test categories.
        } else if (inparam$methodSplit == 'vfold') {
          af = rep('NONE', times = length(atTrain)); # Dummy.
        }
        # .........................................................................................
        


        
   	# ..................................................................................................
   	# . >> COMPUTATION :
   	# ..................................................................................................
      	cat(" ..........  Cross-validation with split method = ", inparam$methodSplit, "\n", sep = "");
     	cat(" ..........  Parameter scanned = ", inparam$parameterScan, "\n", sep = "");        

        cv = SuperPcCv.crossValidateCoxWithCov(at = atTrain,
                                               as = asTrain,
                                               az = azTrain,          
                                               dfX = dfXTrain,
                                               methodSplit = inparam$methodSplit,
                                               af = af,
                                               ft = inparam$ft,
                                               ncv = inparam$ncv,
                                               rngSeed = inparam$rngSeed,
                                               flagRngSeed = TRUE,
                                               mtop = inparam$mtop,
                                               K = inparam$K,
                                               parameterScan = inparam$parameterScan,
                                               amtop = inparam$amtop,
                                               aK = inparam$aK,
                                               flagVerbose = TRUE);
   	# ....................................................................................




   	# ....................................................................................
        # . Generate cross-validation statistics baseline :
   	# ....................................................................................
        nperm = 10;                                                   # Temporary assignment.
        
        cvRand = SuperPcCv.generatePermutedCoxWithCov(at = atTrain,
                                                      as = asTrain,
                                                      az = azTrain,          
                                                      dfX = dfXTrain,
                                                      methodSplit = inparam$methodSplit,
                                                      af = af,
                                                      ft = inparam$ft,
                                                      ncv = inparam$ncv,
                                                      rngSeed = inparam$rngSeed,          
                                                      mtop = inparam$mtop,
                                                      K = inparam$K,
                                                      parameterScan = inparam$parameterScan,
                                                      amtop = inparam$amtop,
                                                      aK = inparam$aK,
                                                      nperm = nperm);
   	# ....................................................................................        

        



  	# ................................................
        # . >>OUTPUT FILES :        
   	# ................................................
        SuperPcDiag.writeCoxCv(cv, inparam$fs);        
   	# ................................................

        
  	# ..............................................................................
        # . >>PLOTS :
   	# ..............................................................................
        if (inparam$flagPlot == 'yes') {
          # ............................................................................
          # . If flagPlotWrite = 'no', generate plots interactively.
          # . If flagPlotWrite = 'yes', save the plots one-by-one as jpeg files in 
          # . the indicated directory, and create an html file which refers to the
          # . images.
          # ............................................................................          
          sp = SuperPcDiag.plotCoxCv(cv,
                                     flagWrite = inparam$flagPlotWrite,
                                     dirName = inparam$dirPlot, stemName = "temp-cox");
          # ............................................................................
          # . Generate html file with plot file pointers:
          # ............................................................................          
          if (inparam$flagPlotWrite == 'yes') {
            SuperPcDiag.writePlotFile(sp = sp, fplot = inparam$fplot);
          }
          # ............................................................................          
        }        
  	# ..............................................................................

        
	# .......................................................................
      	cat(" ..........  End of execution of run_super_pc_cox_cv_with_cov_random.\n");
   	# .......................................................................


   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================

