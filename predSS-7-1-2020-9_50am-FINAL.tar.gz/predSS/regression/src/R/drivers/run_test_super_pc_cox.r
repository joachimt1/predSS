# =======================================================================================================
# . run_test_super_pc_cox : runs tests of supervised principal components analysis for
# . ----------------------  survival data using Cox proportional hazard models.
# .
# .......................................................................................................
# . See the function:
# .
# .                   Inparamreg.getCommandLineTestSuperPcCox
# .
# . in module:
# .
# .                   InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Use:
# .
# .     run_test_super_pc_cox("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_test_super_pc_cox <- function(commandString)
{

	# .................................................................................
      	cat(" ..........  Begin execution of program: run_test_super_pc_cox\n");
   	# .................................................................................

        

   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_test_super_pc_cox", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineTestSuperPcCox(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read the input data files to get the input data matrices :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");
        
        dfX = read.table(file = inparam$fx);   # Gene expression data in DFV format.
        dfX = t(dfX);                          # Transpose to standard data frame format.
        
        dfE = read.table(file = inparam$fe);   # Experimental design.
   	# ..........................................................................................

        
        
        
   	# ..........................................................................................
        # . Subset the input data matrices to training and test sets :
   	# ..........................................................................................
        dfXTrain = dfX[dfE[[inparam$tTrainTest]] == 'train', ];
        dfETrain = dfE[dfE[[inparam$tTrainTest]] == 'train', ];        

        n = nrow(dfX);
        nTrain = nrow(dfXTrain);
        nTest = sum(dfE[[inparam$tTrainTest]] == 'test');
        
        cat(" ..........  Total number of samples in data matrix = ", n, "\n", sep = "");        
        cat("             Number of samples in training set = ", nTrain, "\n", sep = "");
        cat("             Number of samples in test set = ", nTest, "\n", sep = "");        
        
        flagTest = FALSE;        
        
        if (nTest > 0) {
          flagTest = TRUE;                                  
          dfXTest = dfX[dfE[[inparam$tTrainTest]] == 'test', ];
          dfETest = dfE[dfE[[inparam$tTrainTest]] == 'test', ];                  
        }
        # .........................................................................................
        

 
        
   	# .......................................................................................................
        # . >>GLOBAL CALCULATION : perform a computation using all of the data as training and test set
        # . simultanesouly.
        # .......................................................................................................
        cat(" ..........  Global model : perform a computation using all of the data.\n");
        
        at = dfE[[inparam$tTime]];              # Survival times.
        as = dfE[[inparam$tStatus]];            # Censoring statuses (1 = not censored, 0 = censored).

        inparam$scoreType = 'u0';               # Additional parameter, here hardwired.

        spc = SuperPc.computeCox(at = at,
                                 as = as,
                                 dfX = dfX,
                                 scoreType = inparam$scoreType,
                                 methodFs = inparam$methodFs,
                                 p0 = inparam$p0,
                                 mtop = inparam$mtop,
                                 K = inparam$K,
                                 flagVerbose = TRUE);
   	# ...............................................................................
        # . Compute the log-likelihood on the training set itself, considered here
        # . as a test set (this should generate the same qR = 2 * (l(beta*) - l(0))
        # . as in SuperPc.computeCox()).
   	# ...............................................................................        
        lOut = SuperPc.computeCoxLogLikelihood(spc,
                                               atIn = at, asIn = as,
                                               dfXIn = dfX);
   	# .............................................................................
        # . >> Generate a summary of results for the global model.
        # . Compute principal components and log-hazard-ratios for all samples
        # . in the input data set.
   	# .............................................................................
        txtSummary = SuperPcDiag.writeCoxSummary(spc, inparam$fs);
        SuperPcDiag.writeCoxPcDataMatrix(spc, dfX, dfE, inparam$fo);
        SuperPcDiag.writeCoxPcVectors(spc, dfX, inparam$fv);
   	# ..............................................................................
        # . >> Generate a series of plots for global analysis.
   	# ..............................................................................
        buf = readline(">>Display plots? [y/n]");    # Pause.

        if (buf == 'y') {        
          SuperPcDiag.plotCox(at = at, as = as, dfX = dfX, spc = spc,
                              flagWrite = 'no', dirName = NULL, stemName = NULL);
        }
   	# .......................................................................................................
        # . >> END of GLOBAL CALCULATION.
   	# .......................................................................................................        





        

   	# ......................................................................................................
        # . >>SPLIT MODEL : perform computations separately on training and test data.
        # . First generate the Cox model using only the training set data.
        # ......................................................................................................
        cat(" ..........  Split model : perform computations separately on training and test data.\n");
        
        atTrain = dfETrain[[inparam$tTime]];         # Survival times.
        asTrain = dfETrain[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).

        inparam$scoreType = 'u0';                    # Additional parameter, here hardwired.
        
        spcTrain = SuperPc.computeCox(at = atTrain,
                                      as = asTrain,
                                      dfX = dfXTrain,
                                      scoreType = inparam$scoreType,          
                                      methodFs = inparam$methodFs,
                                      p0 = inparam$p0,
                                      mtop = inparam$mtop,
                                      K = inparam$K,
                                      flagVerbose = TRUE);
   	# ...............................................................................
        # . Then compute the log-likelihood of the test set, using the model
        # . generated by the training set.
   	# ...............................................................................
        atTest = dfETest[[inparam$tTime]];         # Survival times.
        asTest = dfETest[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).

        lOutTest = SuperPc.computeCoxLogLikelihood(spcTrain,
                                                   atIn = atTest, asIn = asTest,
                                                   dfXIn = dfXTest);
   	# ...............................................................................






   	# .................................................................................................
        # . Test the cross-validation loops.
        # . Cross-validation with given or vfold split of training and test sets.
        # . >> PREAMBLE :
   	# .................................................................................................
      	cat(" ..........  Testing the cross-validation loops.\n");

        rngSeed = 123456;
        set.seed(rngSeed);                      # Sets the random number seed for this run.        
        
        at = dfE[[inparam$tTime]];              # Survival times.
        as = dfE[[inparam$tStatus]];            # Censoring statuses (1 = not censored, 0 = censored).
        af = dfE[[inparam$tTrainTest]];         # Assigns to train or test.        

        p = ncol(dfX);
   	# .................................................................................................



   	# .................................................................................................
        # . >> CROSS-VALIDATION : set the scan parameters.
        # . >> parameterScan = mtop :
   	# .................................................................................................
        mtopLo = 3;                             # These initial values are chosen a bit arbitrarily.
        mtopHi = 250;
        amtop = seq(mtopLo, mtopHi, by = 5);    # If parameterScan = K, these will be dummy values.
        
        if (inparam$parameterScan == 'mtop') {
          if (mtopHi > p) {
            msg = "ERROR: from run_test_super_pc_cox :";
            msg = paste(msg, " in selecting scanning parameters for cross-validation :", sep = "");            
            msg = paste(msg, " the upper value of mtop for the cross-validation, mtopHi = ", mtopHi, sep = "");
            msg = paste(msg, " is greater than the number of genes in the input data matrix, p = ", p, sep = "");
            stop(msg);
          }
          
          if (inparam$K > mtopHi) {
            msg = "ERROR: from run_test_super_pc_cox :";
            msg = paste(msg, " in selecting scanning parameters for cross-validation :", sep = "");            
            msg = paste(msg, " the number of principal components chosen, K = ", inparam$K, sep = "");
            msg = paste(msg, " is greater than the upper value of mtop for the cross-validation, mtopHi = ",
                        mtopLo, sep = "");
            stop(msg);
          }            
          
          mtopLo = max(mtopLo, inparam$K);       # Adjust lower bound, so that rank of matrix >= K.
          
          amtop = seq(mtopLo, mtopHi, by = 5);   # Actual values used.
        }
   	# .................................................................................................
        # . >> parameterScan = K :
   	# .................................................................................................        
        aK = c(1, 2, 3, 4, 5, 6);               # If parameterScan = mtop, these will be dummy values.

        if (inparam$parameterScan == 'K') {
          KHi = max(aK);
          
          if (KHi > inparam$mtop) {
            msg = "ERROR: from run_test_super_pc_cox :";
            msg = paste(msg, " in selecting scanning parameters for cross-validation :", sep = "");
            msg = paste(msg, " the value of mtop for the cross-validation, mtop = ", inparam$mtop, sep = "");
            msg = paste(msg, " is less than the upper bound for the number of principal components, KHi = ",
                        KHi, sep = "");
            stop(msg);
          }
        }
   	# .................................................................................................
        # . >> Amount used for test set :
   	# .................................................................................................        
        ft = 0.5;                     # If vfold is used, remove 1/2 of the data set for testing.
   	# .................................................................................................


        
        
   	# .................................................................................................
   	# . >> CROSS-VALIDATION, SINGLE SPLIT :
   	# .................................................................................................
      	cat(" ..........  Test of a SINGLE split calculation.\n", sep = "");        

      	cat(" ..........  Cross-validation with split method = ", inparam$methodSplit, "\n", sep = "");
     	cat(" ..........  Parameter scanned = ", inparam$parameterScan, "\n", sep = "");        
   	# .................................................................................................
        # . Run the cross-validation :
   	# .................................................................................................        
        cv = SuperPcCv.crossValidateCoxSingleSplit(at = at,
                                                   as = as,
                                                   dfX = dfX,
                                                   methodSplit = inparam$methodSplit,
                                                   af = af,
                                                   ft = ft,             
                                                   mtop = inparam$mtop,
                                                   K = inparam$K,
                                                   parameterScan = inparam$parameterScan,
                                                   amtop = amtop,
                                                   aK = aK,
                                                   flagVerbose = TRUE);
   	# ........................................................................
        # . Display cv results :
   	# ........................................................................
        SuperPcDiag.plotCoxCvSingle(cv);
        # ..................................................................................................
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        # ..................................................................................................



        
   	# ..................................................................................................
   	# . >> CROSS-VALIDATION, MULTIPLES SPLITS :
   	# ..................................................................................................
      	cat(" ..........  Test of a MULTIPLE splits calculation.\n", sep = "");        

      	cat(" ..........  Cross-validation with split method = ", inparam$methodSplit, "\n", sep = "");
     	cat(" ..........  Parameter scanned = ", inparam$parameterScan, "\n", sep = "");        

        ncv = 5;                      # Generate 5 independent splits, for methodSplit = vfold.
        rngSeed = 123456;             # Random number generator seed.
        
        cv = SuperPcCv.crossValidateCox(at = at,
                                        as = as,
                                        dfX = dfX,
                                        methodSplit = inparam$methodSplit,
                                        af = af,
                                        ft = ft,
                                        ncv = ncv,
                                        rngSeed = rngSeed,
                                        scoreType = 'u0',
                                        mtop = inparam$mtop,
                                        K = inparam$K,
                                        parameterScan = inparam$parameterScan,
                                        amtop = amtop,
                                        aK = aK,
                                        flagVerbose = FALSE);
   	# ....................................................................................
        # . Display cv results :
   	# ....................................................................................
        SuperPcDiag.plotCoxCv(cv);
        SuperPcDiag.writeCoxCv(cv, inparam$fcv);        
        # .........................................................................................
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
   	# ..........................................................................................




        
	# .....................................................................
      	cat(" ..........  End of execution of run_test_super_pc_cox.\n");
   	# .....................................................................


   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================
