# =======================================================================================================
# . run_coxnet_cv_with_cov : Does cross-validation of a Cox proportional hazard model on the indicated 
# . ----------------------   training set, using the glmnet model, with optionally a first level of feature
# .                          selection.
# .
# .......................................................................................................
# . See the function:
# .
# .        Inparamreg.getCommandLineCoxnetCvWithCov
# .
# . in module:
# .
# .        InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Type :
# .
# .     run_coxnet_cv_with_cov("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_coxnet_cv_with_cov <- function(commandString)
{

	# ..............................................................................
      	cat(" ..........  Begin execution of program: run_coxnet_cv_with_cov\n");
   	# ..............................................................................

        
        # ...............................................................
        options(warn = 1)  # Warning messages will be printed immediately.
        # ...............................................................

        
   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_coxnet_cv_with_cov", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineCoxnetCvWithCov(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read the input data files to get the input data matrices :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");

        dfX = DataFrame.readDataMatrixFread(inparam$fx);  # Numerical data.
        dfE = read.table(file = inparam$fe);              # Experimental design.
   	# ..........................................................................................



   	# ..........................................................................................
        # . Check consistency of input data matrices :
   	# ..........................................................................................        
        msg = Glmnet.checkDataMatricesForCoxCvWithCov(dfX, dfE, inparam);

        if (msg != 'ok') {
          cat(msg, "\n", sep = "");
          stop();
        }
   	# ..........................................................................................



   	# ..........................................................................................
        # . Extract the training set data from the input data matrices :
   	# ..........................................................................................
        if (inparam$tTrain != 'NONE') {
          dfXTrain = dfX[dfE[[inparam$tTrain]] == 'train', ]; 
          dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ];
        } else {
          dfXTrain = dfX;
          dfETrain = dfE;
        }

        atTrain = dfETrain[[inparam$tTime]];         # Survival times.
        asTrain = dfETrain[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
        azTrain = dfETrain[[inparam$tCov]];          # Additional external covariate.                

        if (inparam$methodSplit == 'given') {
          af = dfETrain[[inparam$tSplit]];           # Assigns to given train and test categories.
        } else if ((inparam$methodSplit == 'vfold')
                   || (inparam$methodSplit == 'vfoldStrict')){
          af = rep('NONE', times = length(atTrain)); # Dummy.
        }
        # .........................................................................................
        


        
   	# ..................................................................................................
   	# . >> COMPUTATION :
   	# ..................................................................................................
      	cat(" ..........  Cross-validation with split method = ", inparam$methodSplit, "\n", sep = "");

        if (inparam$cvType == 'loop') {
          cat(" ..........  Loop cross-validation : parameter scanned = lambda\n", sep = "");
          cat(" ..........  Number of levels at input: nlambdaIn = ", inparam$nlambdaIn, "\n", sep = "");
          cat("             (may be adjusted by glmnet coordinate descent convergence criteria).\n");          
        } else if (inparam$cvType == 'single') {
          cat(" ..........  Single-level cross-validation : lambda = ", inparam$lambda, "\n", sep = "");
        }

        cv = GlmnetCv.crossValidateCoxWithCov(at = atTrain,
                                              as = asTrain,
                                              az = azTrain,          
                                              dfX = dfXTrain,
                                              flagCenter = inparam$flagCenter,
                                              cvType = inparam$cvType,
                                              methodSplit = inparam$methodSplit,
                                              af = af,
                                              ft = inparam$ft,
                                              rngSeed = inparam$rngSeed,
                                              flagRngSeed = TRUE,
                                              flagFs = inparam$flagFs,
                                              mtop = inparam$mtop,
                                              typePval = inparam$typePval,          
                                              alpha = inparam$alpha,
                                              lambda = inparam$lambda,
                                              nlambdaIn = inparam$nlambdaIn,
                                              flagVerbose = TRUE);
   	# ....................................................................................


        

   	# ....................................................................................
        # . Add the fold assignments used to dfETrain, if methodSplit = vfoldStrict :
   	# ....................................................................................
        if (inparam$methodSplit == 'vfoldStrict') {
          dfETrain = data.frame(dfETrain, cvFOLD = cv$afold);
        }
   	# ....................................................................................                

        


  	# ....................................................................................
        # . >>OUTPUT FILES :        
   	# ....................................................................................
        if (inparam$cvType == 'loop') {
          GlmnetDiag.writeCoxCvWithCov(cv, inparam$fs);
        } else if (inparam$cvType == 'single') {
          # ............................................................................
          # . P-values for the given tuning parameters :
          # ............................................................................
          GlmnetDiag.writeCoxCvWithCovSingle(cv = cv,
                                             hRC = inparam$hRC,
                                             fs = inparam$fs);
     	  # ............................................................................
          # . Output sample-by-sample cross-validated log-hazards and sensitivity
          # . predictions :
   	  # ............................................................................
          SuperPcDiag.writeCoxCvDataMatrixWithCov(cv = cv,
                                                  dfX = dfXTrain,
                                                  dfE = dfETrain,
                                                  az = azTrain,
                                                  hRC = inparam$hRC,                                                
                                                  fo = inparam$fo);       
   	  # ............................................................................          
        }
   	# ....................................................................................


        
        
  	# .........................................................................................
        # . >>PLOTS :
   	# .........................................................................................
        if (inparam$flagPlot == 'yes') {
          # ............................................................................
          # . If flagPlotWrite = 'no', generate plots interactively.
          # . If flagPlotWrite = 'yes', save the plots one-by-one as jpeg files in 
          # . the indicated directory, and create an html file which refers to the
          # . images.
          # ............................................................................
          if (inparam$cvType == 'loop') {
            sp = GlmnetDiag.plotCoxCvWithCov(cv,
                                             flagWrite = inparam$flagPlotWrite,
                                             dirName = inparam$dirPlot, stemName = "temp-cox");
          } else if (inparam$cvType == 'single') {
            sp = SuperPcDiag.plotCoxCvWithCovSingle(cv = cv,
                                                    hRC = inparam$hRC,
                                                    flagWrite = inparam$flagPlotWrite,
                                                    dirName = inparam$dirPlot, stemName = "temp-cox");
          }
          # ...............................................................................
          # . Generate html file with plot file pointers:
          # ...............................................................................
          if (inparam$flagPlotWrite == 'yes') {
            SuperPcDiag.writePlotFile(sp = sp, fplot = inparam$fplot);
          }
          # ................................................................................
        }        
  	# ...........................................................................................

        
        
	# .......................................................................
      	cat(" ..........  End of execution of run_coxnet_cv_with_cov.\n");
   	# .......................................................................


        # .................................................
        options(warn = 0)     # Reset warnings to default.
        # .................................................

        
   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================

