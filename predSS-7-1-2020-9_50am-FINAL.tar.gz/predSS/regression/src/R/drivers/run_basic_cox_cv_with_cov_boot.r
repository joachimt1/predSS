# =======================================================================================================
# . run_basic_cox_cv_with_cov_boot : Does cross-validation of a Cox proportional hazard model on the indicated 
# . ------------------------------   training set, using the basic Cox multivariate model.
# .                                  This version performs an external BOOTSTRAP or PERMUTATION
# .                                  on the internal cross-validation loop.
# .......................................................................................................
# . See the function:
# .
# .        Inparamreg.getCommandLineBasicCoxCvWithCovBoot
# .
# . in module:
# .
# .        InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Type :
# .
# .     run_basic_cox_cv_with_cov_boot("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ==============================================================================================================
# . MAIN program:
# ==============================================================================================================

run_basic_cox_cv_with_cov_boot <- function(commandString)
{

	# ...................................................................................
      	cat(" ..........  Begin execution of program: run_basic_cox_cv_with_cov_boot\n");
   	# ...................................................................................

        
        # .................................................................
        options(warn = 1)  # Warning messages will be printed immediately.
        # .................................................................

        
   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_basic_cox_cv_with_cov_boot", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineBasicCoxCvWithCovBoot(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read the input data files to get the input data matrices :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");

        dfX = DataFrame.readDataMatrix(inparam$fx);  # Numerical data.
        dfE = read.table(file = inparam$fe);         # Experimental design.
   	# ..........................................................................................



   	# ..........................................................................................
        # . Filter the genes on a qualifier list, if indicated :
   	# ..........................................................................................
        aqEff = colnames(dfX);                         # Default gene list.
        
        if (inparam$flagQlist == 'yes') {
          aq = File.readQlist(inparam$fq);
          dfX = DataFrame.filterOnQlist(dfX, aq);
          aqEff = colnames(dfX);                       # Effective gene list.
        }

        nqEff = length(aqEff);
        cat(" ..........  The Cox model will be built using nqEff = ", nqEff, " genes.\n", sep = "");
   	# ..........................................................................................                



   	# ..........................................................................................
        # . Check consistency of input data matrices :
   	# ..........................................................................................        
        msg = BasicCox.checkDataMatricesForCoxCvWithCovBoot(dfX, dfE, inparam);

        if (msg != 'ok') {
          cat(msg, "\n", sep = "");
          stop();
        }
   	# ..........................................................................................



   	# ..........................................................................................
        # . Extract the training set data from the input data matrices :
   	# ..........................................................................................
        if (inparam$tTrain != 'NONE') {
          dfXTrain = dfX[dfE[[inparam$tTrain]] == 'train', ]; 
          dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ];
        } else {
          dfXTrain = dfX;
          dfETrain = dfE;
        }

        atTrain = dfETrain[[inparam$tTime]];         # Survival times.
        asTrain = dfETrain[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
        azTrain = dfETrain[[inparam$tCov]];          # Additional external covariate.                

        af = rep('NONE', times = length(atTrain)); # Dummy.
        # .........................................................................................
        


        
   	# ............................................................................................................
   	# . >> COMPUTATION :
   	# ............................................................................................................
      	cat(" ..........  Bootstrap of cross-validation with split method = ", inparam$methodSplit, "\n", sep = "");
        cat(" ..........  Use single-level cross-validation for each resampling.\n");

        cvBoot = BasicCoxCv.crossValidateCoxWithCovBoot(at = atTrain,
                                                        as = asTrain,
                                                        az = azTrain,          
                                                        dfX = dfXTrain,
                                                        flagCenter = inparam$flagCenter,
                                                        ft = inparam$ft,
                                                        rngSeed = inparam$rngSeed,
                                                        bootType = inparam$bootType,
                                                        nboot = inparam$nboot,
                                                        flaghRCOpt = inparam$flaghRCOpt,
                                                        hRC = inparam$hRC,
                                                        flagVerbose = TRUE);
   	# ............................................................................................................
        


      	# ...................................................................................
        # . Extract arrays and summary statistics :
      	# ...................................................................................        
        rs = SuperPcBoot.extractResampledCoxWithCovStats(cvBoot);
      	# ...................................................................................        
        


  	# ....................................................................................
        # . >>OUTPUT FILES :
        # . >>1. Summary statistics :
   	# ....................................................................................
        BasicCoxDiag.writeCoxWithCovBootFULL(rs = rs, fs = inparam$fs);
        # ....................................................................................
        # . >>2. Record-by-record resampling results :
        # ....................................................................................        
        BasicCoxDiag.writeCoxWithCovBootSERIES(rs = rs, fo = inparam$fo);       
   	# ....................................................................................


        
        
  	# .........................................................................................
        # . >>PLOTS :
   	# .........................................................................................
        if (inparam$flagPlot == 'yes') {
          # ............................................................................
          # . If flagPlotWrite = 'no', generate plots interactively.
          # . If flagPlotWrite = 'yes', save the plots one-by-one as jpeg files in 
          # . the indicated directory, and create an html file which refers to the
          # . images.
          # ............................................................................
          sp = SuperPcDiag.plotCoxWithCovBoot(rs = rs,
                                              flagWrite = inparam$flagPlotWrite,
                                              dirName = inparam$dirPlot, stemName = "temp-cox");
          # ...............................................................................
          # . Generate html file with plot file pointers:
          # ...............................................................................
          if (inparam$flagPlotWrite == 'yes') {
            SuperPcDiag.writePlotFile(sp = sp, fplot = inparam$fplot);
          }
          # ................................................................................
        }        
  	# ...........................................................................................

        
        
	# ............................................................................
      	cat(" ..........  End of execution of run_basic_cox_cv_with_cov_boot.\n");
   	# ............................................................................


        # .................................................
        options(warn = 0)     # Reset warnings to default.
        # .................................................

        
   	# ...........
        return (0);
   	# ...........

}

# ================================================================================================================
# . End of MAIN.
# ================================================================================================================

