# =====================================================================
# . InparamReg : this module contains functions for reading the
# . -----------  command line and assigning parameters.
# .
# =====================================================================

# =====================================================================================
# . InparamReg.getCommandLineCVloop : gets command line arg8uments for 
# . -------------------------------   a cross-validation loop.
# .
# .    inparam = InparamReg.getCommandLineCVloop(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# .
# . OUT:
# .     inparam : InparamReg object containing the assigned cross-validation parameters.
# .
# . InparamReg members:
# .
# .     fr          = name of input RDAT file.      
# .	fs          = name of output STAT file.
# .	flavor      = flavor of regression (ridge).
# .	lambdalo    = lower bound on lambda values (for flavor = ridge).
# .	lambdahi    = upper bound on lambda values  (for flavor = ridge).
# .	lambdainc   = increment on lambda values (for flavor = ridge).
# .	cv_method   = cross-validation method used (loocv, logo, vfold).
# .	ncv         = number of cross-validation steps used (for cv_method = vfold).
# .	ft          = test set fraction  (for cv_method = vfold).
# .
# =====================================================================================

InparamReg.getCommandLineCVloop <- function(argv)
{

	# ...................................................................................
	# . Indications for use:
	# ...................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax for CVloop:\n");
           cat("----------------------------------------------------------------------------\n");
           cat("\n");
           cat("      -fr foo.CDAT         : RDAT input file (data matrix + class labels)\n");  
           cat("      -fs foo.STAT         : output statistics file.\n");
           cat("\n");
           cat("      -flavor ridge        : Flavor of regression method. Allowed.\n");	  
           cat("                                ridge = ridge regression.\n");
           cat("\n");
           cat("      -lambdalo  lambdalo  : Lambda lower bound in ridge regression.\n");
           cat("      -lambdahi  lambdahi  : Lambda upper bound.\n");
           cat("      -lambdainc lambdainc : Lambda increment.\n");
           cat("\n");
   	   cat("      -cv_method logo        : Cross-validation methodology. Allowed:\n")
           cat("                                  loocv = leave-one-out.             \n");
           cat("                                  logo = leave-one-group-out.        \n");
           cat("                                  vfold = V-fold.                    \n");
           cat("          -ncv  20           : Number of V-fold samplings.\n");	   
           cat("          -ft 0.333          : Fraction of training set for test set under vfold.\n");
           cat("----------------------------------------------------------------------------\n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ...................................................................................



	# ...................................................................................
	# . Get the command line arguments:
	# . Input and output files:
	# ...................................................................................
	fr = Param.get_parameter(argv, "-fr", 1);       # Input CDAT file.
	fs = Param.get_parameter(argv, "-fs", 1);       # Ouput STAT file.
	# ...................................................................................
	# . Type of regression:
	# ...................................................................................
	flavor = Param.get_parameter(argv, "-flavor", 1);
	# ...................................................................................
	# . Cross-validation parameters: ridge-regression specific.
	# ...................................................................................
	lambdalo = as.numeric(Param.get_parameter(argv, "-lambdalo", 1));
	lambdahi = as.numeric(Param.get_parameter(argv, "-lambdahi", 1));
	lambdainc = as.numeric(Param.get_parameter(argv, "-lambdainc", 1));
	# ...................................................................................
	# . Cross-validation parameters: general.
	# ...................................................................................
	cv_method = Param.get_parameter(argv, "-cv_method", 1);
	ncv = as.numeric(Param.get_parameter(argv, "-ncv", 1));

	ft = as.numeric(Param.get_parameter(argv, "-ft", 1));
	# ...................................................................................


	# ...................................................................................
	# . Check on validity of input parameters:
	# . Regression flavor:
	# ...................................................................................
	if (flavor != "ridge") {
	    msg = cat("ERROR: from InparamReg.getCommandLineCVloop: flavor = ", flavor, " is not valid.");
	    stop(msg);
	}
	# ...................................................................................
	# . Regularization parameter:
	# ...................................................................................
	if (lambdalo < 0.0) {
	    msg = cat("ERROR: from InparamReg.getCommandLineCVloop: lambdalo < 0.");
	    stop(msg);
	}

	if (lambdahi < lambdalo) {
	    msg = cat("ERROR: from InparamReg.getCommandLineCVloop: lambdahi < lambdalo.");
	    stop(msg);
	}

	if (lambdainc <= 0.0) {
	    msg = cat("ERROR: from InparamReg.getCommandLineCVloop: lambdainc <= 0.0.");
	    stop(msg);
	}

	NLAMBDAMAX = 10000;
	nlambda = 1 + floor((lambdahi - lambdalo) / lambdainc);

	if (nlambda > NLAMBDAMAX) {
	    msg = cat("ERROR: from InparamReg.getCommandLineCVloop: lambdainc is too small.\n");
	    msg = cat(msg, "The resulting number of steps nlambda = ", nlambda);
	    msg = cat(msg, "is greater than internal limit of NLAMBDAMAX = ", NLAMBDAMAX);
	    stop(msg);
	}
	# ...................................................................................
	# . Cross-validation parameters: general.
	# ...................................................................................
	if ((cv_method != "loocv") && (cv_method != "logo") && (cv_method != "vfold")) {
	    msg = cat("ERROR: from InparamReg.getCommandLineCVloop: cv_method = ", cv_method, " is not valid.");
	    stop(msg);
	}

	if (cv_method == "vfold") {
   	    if (ncv <= 0) {
		msg = cat("ERROR: from InparamReg.getCommandLineCVloop: for vfold, ncv < 0.");
		stop(msg);
	    }

   	    if ((ft <= 0.0) || (ft >= 1.0)) {
		msg = cat("ERROR: from InparamReg.getCommandLineCVloop: for vfold, ft = ", ft);
		msg = cat(msg, "is out of the range 0  <ft < 1.");
		stop(msg);
	    }
	}
	# ...................................................................................



	# ...................................................................................
	# . Now package the parameters into an object:
	# ...................................................................................
	inparam = list(fr = fr,
                       fs = fs,
                       flavor = flavor,
                       lambdalo = lambdalo,
                       lambdahi = lambdahi,
                       lambdainc = lambdainc,
	               cv_method = cv_method,
                       ncv = ncv,
	               ft = ft);

	class(inparam) = "InparamReg";
	return (inparam);
	# ...................................................................................

}

# =====================================================================================
# . End of InparamReg.getCommandLineCVloop.
# =====================================================================================



# =================================================================================================
# . InparamReg.getCommandLineRocHTG : gets command line arg8uments for 
# . -------------------------------   a cross-validation loop.
# .
# .    inparam = InparamReg.getCommandLineRocHTG(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineRocHTG <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax for RocHTG:\n");
           cat("------------------------------------------------------------------------------------------- \n");
           cat("  run_roc_htg                                                                               \n");
           cat("      -fin foo.FLAT        : FLAT input file.                                               \n");  
           cat("      -geneNormalize GFAP  : gene used for normalization.                                   \n");
           cat("\n");           
           cat("      -fo foo.STAT         : output statistics file.                                        \n");           
           cat("\n");
           cat("      -ncontrol 8          : number of samples to be used as controls.                      \n");
           cat("      -nresamp 1000        : total number of resamplings to be done.                        \n");           
           cat("\n");
           cat("      -flagSimulation no   : yes/no. If yes, ignore treated data and simulate fold-changes  \n");
           cat("                             based only on the control data.                                \n");
           cat("      -ratioList 1.5:2:3   : required if flagSimulation = yes. Colon-separated list of      \n");
           cat("                             fold-changes to be used for the simulation.                    \n");
           cat("      -nsim 20             : required if flagSimulation = yes. Number of simulated treated  \n");
           cat("                             samples generated per overall resampling.                      \n");
           cat("\n");           
   	   cat("      -keyControl DMSO     : columns with names starting with this key are controls.        \n");
   	   cat("      -keyTreated TPA      : columns with names starting with this key are treated samples. \n");
           cat("\n");           
   	   cat("      -zlo  -10.0          : lower bound for building ROCs on z-scores.                     \n");
   	   cat("      -zhi  50.0           : upper bound for building ROCs on z-scores.                     \n");
   	   cat("      -nz  600             : number of points for building ROCs on z-scores.                \n");                      
           cat("\n");
           cat("      -zcList 3:6:8:10     : Colon-separated list of values of cutoff zc, to be used in     \n");
           cat("                             generating summary statistics for detection                    \n");
           cat("      -p1List 0.001:0.01   : Colon-separated list of values of a priori activation          \n");
           cat("                             probabilities, for generating summary statistics for detection.\n");
           cat("\n");           
           cat("      -fdrPoint 0.6        : FDR to be used for point estimation of S and zc in table in    \n");
           cat("                             output statistics file.                                        \n");
           cat("------------------------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        




	# ...................................................................................
	# . Get the command line arguments:
	# . Input and output files:
	# ...................................................................................
	fin = Param.get_parameter(argv, "-fin", 1);                           # Input FLAT file.
	geneNormalize = Param.get_parameter(argv, "-geneNormalize", 1);       # Input FLAT file.        

	fo = Param.get_parameter(argv, "-fo", 1);                             # Ouput STAT file.
	# ...................................................................................
	# . Resampling parameters :
	# ...................................................................................
	ncontrol = as.numeric(Param.get_parameter(argv, "-ncontrol", 1));
	nresamp = as.numeric(Param.get_parameter(argv, "-nresamp", 1));
	# ...................................................................................
	# . Sample keys :
	# ...................................................................................
	keyControl = Param.get_parameter(argv, "-keyControl", 1);
	keyTreated = Param.get_parameter(argv, "-keyTreated", 1);
       	# ...................................................................................
	# . ROC parameters :
	# ...................................................................................
	zlo = as.numeric(Param.get_parameter_ez(argv, "-zlo", 1));
	zhi = as.numeric(Param.get_parameter_ez(argv, "-zhi", 1));
	nz = as.numeric(Param.get_parameter(argv, "-nz", 1));
	# ...................................................................................
        # . Simulation parameters :
	# ...................................................................................
        flagSimulation = Param.get_parameter(argv, "-flagSimulation", 1);

        if ((flagSimulation != "yes") && (flagSimulation != "no")) {
          msg = paste("ERROR: from InparamReg.getCommandLineRocHTG : flagSimulation =", flagSimulation, " must be yes or no.\n");
          stop(msg);
        }
        
        if (flagSimulation == "yes") {
          ratioList = Param.get_parameter(argv, "-ratioList", 1);
          nsim = as.numeric(Param.get_parameter(argv, "-nsim", 1));
        } else {
          ratioList = "NONE";
          nsim = 0;                # Dummy.
        }
	# ...................................................................................
        # . List of zc and P1 values for tabular summary of detection characteristics :
	# ...................................................................................
        zcList = Param.get_parameter(argv, "-zcList", 1);
        p1List = Param.get_parameter(argv, "-p1List", 1);
	# ...................................................................................
        # . FDR for point calculation in final table :
	# ...................................................................................
	fdrPoint = as.numeric(Param.get_parameter(argv, "-fdrPoint", 1));
        stopifnot((fdrPoint >= 0.0) && (fdrPoint <= 1.0));
	# ...................................................................................


        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(fin = fin,
                       geneNormalize = geneNormalize,
                       fo = fo,
                       ncontrol = ncontrol,
                       nresamp = nresamp,
                       keyControl = keyControl,
                       keyTreated = keyTreated,
                       zlo = zlo,
                       zhi = zhi,
                       nz = nz,
                       flagSimulation = flagSimulation,
                       ratioList = ratioList,
                       nsim = nsim,
                       zcList = zcList,
                       p1List = p1List,
                       fdrPoint = fdrPoint);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineRocHTG.
# =================================================================================================






# =================================================================================================
# . InparamReg.getCommandLineTestSuperPcLm : gets command line arguments for tests of the supervised
# . --------------------------------------   principal components analysis using linear models
# .                                          for the outcome data.
# .
# .    inparam = InparamReg.getCommandLineTestSuperPcLm(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineTestSuperPcLm <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_test_super_pc_lm                                                          \n");
           cat("      -nb 20         :  number of samples in each of 4 blocks used to gene-  \n");
           cat("                        rate all of the simulated data matrix columns        \n");
           cat("                        (there are thus a total of 4 * nb sample columns in  \n");
           cat("                        the simulated data matrix). Range: nb > 1.           \n");
           cat("      -alpha 0.1     :  value of alpha parameter in generation of simulated  \n");
           cat("                        outcomes. Range:  0 <= alpha <= 1.0.                 \n");
           cat("                        alpha --> 0 : outcome has a two peaks-two troughs    \n");
           cat("                                      mean profile.                          \n");
           cat("                        alpha --> 1 : outcome has a one peak-one trough      \n");
           cat("                                      mean profile.                          \n");
           cat("\n");
           cat("      -panel both    :  Type of combination of panels of gene expression in  \n");
           cat("                        simulated data. Allowed values: both, top, bottom.   \n");
           cat("      -sigma 1.0     :  standard deviation of all noise terms in simulated   \n");
           cat("                        data. Range: sigma >= 0.0.                           \n");
           cat("      -rngSeed 1234  :  random number generator seed for generation of all   \n");
           cat("                        noise terms.                                         \n");
           cat("\n");
           cat("      -methodFs mtop :  method of feature selection. Allowed values:         \n");
           cat("                        = 'theta' : use the threshold parameter theta for    \n");
           cat("                        selecting genes.                                     \n");
           cat("                        = 'mtop' :use the cutoff parameter mtop for          \n");
           cat("                        selecting genes.                                     \n");
           cat("\n");           
           cat("      -theta 0.1     :  value of theta parameter: determines threshold       \n");
           cat("                        in absolute value of correl. coefficients for        \n");
           cat("                        retaining genes prior to SVD. Range: 1 >= theta > 0. \n");
           cat("      -mtop 50       :  alternative feature-selection parameter : select the \n");
           cat("                        top mtop genes in decreasing order of correlation.   \n");
           cat("\n");           
           cat("      -mtopLo 10     :  lower bound on mtop for cross-validation run.        \n");
           cat("      -mtopHi 200    :  upper bound on mtop for cross-validation run.        \n");
           cat("      -mtopInc 10    :  increment on mtop for cross-validation run.          \n");
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
	# ...................................................................................
	nb = as.numeric(Param.get_parameter(argv, "-nb", 1));        
	alpha = as.numeric(Param.get_parameter(argv, "-alpha", 1));
	panel = Param.get_parameter(argv, "-panel", 1);
	sigma = as.numeric(Param.get_parameter(argv, "-sigma", 1));        
	rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1));

        methodFs = Param.get_parameter(argv, "-methodFs", 1);        

        theta = as.numeric(Param.get_parameter(argv, "-theta", 1));
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));        

        mtopLo = as.numeric(Param.get_parameter(argv, "-mtopLo", 1));
        mtopHi = as.numeric(Param.get_parameter(argv, "-mtopHi", 1));
        mtopInc = as.numeric(Param.get_parameter(argv, "-mtopInc", 1));                
        
        stopifnot(nb > 1);
        stopifnot((alpha >= 0.0) && (alpha <= 1.0));
        stopifnot(sigma >= 0.0);
        stopifnot((panel == "both") || (panel == "top") || (panel == "bottom"));
        
        stopifnot((methodFs == 'theta') || (methodFs == 'mtop'));
        stopifnot((theta >= 0.0) && (theta <= 1.0));
        stopifnot(mtop >= 1);

        stopifnot(mtopLo >= 1);
        stopifnot(mtopHi >= 1);
        stopifnot(mtopLo <= mtopHi);
        stopifnot(mtopInc >= 1);        
	# ...................................................................................


        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       nb = nb,          
                       alpha = alpha,
                       panel = panel,
                       sigma = sigma,
                       rngSeed = rngSeed,
                       methodFs = methodFs,          
                       theta = theta,
                       mtop = mtop,
                       mtopLo = mtopLo,
                       mtopHi = mtopHi,
                       mtopInc = mtopInc );

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineTestSuperPcLm.
# =================================================================================================





# =================================================================================================
# . InparamReg.getCommandLineTestSuperPcCox : gets command line arguments for tests of the supervised
# . ---------------------------------------   principal components analysis using Cox proportional
# .                                           hazards for modeling survival data on the gene
# .                                           expression covariates.
# .
# .    inparam = InparamReg.getCommandLineTestSuperPcCox(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineTestSuperPcCox <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_test_super_pc_cox                                                      \n");
           cat("\n");
           cat("      -fx foo-data.DFV : name of numerical data file. Must have DFV          \n");
           cat("                         extension and be in vertical data frame format.     \n");
           cat("\n");
           cat("       -fe foo-exp.DF : name of experimental design file. Must have the DF   \n");
           cat("                        extension and be in data frame format.               \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrainTest panel1 : factor defining the training and test set        \n");
           cat("                            members :                                        \n");
           cat("                            - training set members are flagged with          \n");
           cat("                              label = train. There must be at least 2        \n");
           cat("                              training set members.                          \n");           
           cat("                            - test set members are flagged with              \n");
           cat("                              label = test. There can be 0 or more test set  \n");
           cat("                              members. Note that training and test sets      \n");
           cat("                              cannot overlap.                                \n");           
           cat("                            - all samples with label NONE are ignored.       \n");
           cat("\n");           
           cat("       -fv foo.PC     : output file for the principal component vectors.     \n");
           cat("\n");
           cat("       -fo foo.COXPH  : output file for sample-by-sample pcs and log-hazards.\n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("\n");
           cat("       -fcv foo.CV    : output file for cross-validation results.            \n");
           cat("\n");           
           cat("      -methodFs p0 : method of feature selection. Allowed options :	     \n");
           cat("                       - 'p0'   : use the P-value threshold p0 for           \n");
           cat("                                  selecting genes.                           \n");
           cat("                       - 'mtop' : use the parameter mtop for selecting       \n");
           cat("                                  genes.                                     \n");
           cat("\n");                                                                          
           cat("      -p0 0.01  : threshold in P-values from Cox proportional hazards model. \n");
           cat("                  Only genes with p <= p0 are kept after feature selection.  \n")
           cat("                  The p-values are computed using the univariate score test. \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("\n");
           cat("      -K 2      : number of principal components to be used as covariates    \n");
           cat("                  in the Cox proportional hazard model for the survival data.\n");
           cat("\n");
           cat("      -methodSplit vfold : how to split the data matrix into training and    \n");
           cat("                           test sets.                                        \n");
           cat("                           Allowed values: given, vfold                      \n");
           cat("\n");
           cat("      -parameterScan mtop : which parameter to scan in doing the cross-      \n");
           cat("                            validation. Allowed values: mtop, K              \n")
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tTrainTest = Param.get_parameter(argv, "-tTrainTest", 1);  # Factor defining train/test sets.

        fo = Param.get_parameter(argv, "-fo", 1);    # Output file for sample-by-sample pcs and hazards.
        fv = Param.get_parameter(argv, "-fv", 1);    # Output file for the principal component vectors.
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.
        fcv = Param.get_parameter(argv, "-fcv", 1);  # Output file for cross-validation results.

        methodFs = Param.get_parameter(argv, "-methodFs", 1);  # Feature selection method.

        p0 = as.numeric(Param.get_parameter(argv, "-p0", 1));      # P-value cutoff.
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.

        K = as.numeric(Param.get_parameter(argv, "-K", 1));    # Number of PCs to be used.

        methodSplit = Param.get_parameter(argv, "-methodSplit", 1);        # Partition for CV loop.
        parameterScan = Param.get_parameter(argv, "-parameterScan", 1);    # Parameter to be scanned.
	# ...................................................................................


	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................        
        stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
        stopifnot((p0 >= 0.0) && (p0 <= 1.0));
        stopifnot(mtop >= 1);
        stopifnot(K >= 1);
        stopifnot((methodSplit == 'given') || (methodSplit == 'vfold'));
        stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));          
	# ...................................................................................

        
	# ...................................................................................        
        # . Check on stupid file name errors :
	# ...................................................................................
        if (fo == fx) {
          msg = "ERROR: from InparamReg.getCommandLineTestSuperPcCox:";
          msg = paste(msg, " File fo has same name as file fx.", sep = "");
          stop(msg);
        }

        if (fs == fx) {
          msg = "ERROR: from InparamReg.getCommandLineTestSuperPcCox:";
          msg = paste(msg, " File fs has same name as file fx.", sep = "");
          stop(msg);
        }

        if (fcv == fx) {
          msg = "ERROR: from InparamReg.getCommandLineTestSuperPcCox:";
          msg = paste(msg, " File fcv has same name as file fx.", sep = "");
          stop(msg);
        }
        
        if (fo == fe) {
          msg = "ERROR: from InparamReg.getCommandLineTestSuperPcCox:";
          msg = paste(msg, " File fo has same name as file fe.", sep = "");
          stop(msg);
        }

        if (fs == fe) {
          msg = "ERROR: from InparamReg.getCommandLineTestSuperPcCox:";
          msg = paste(msg, " File fs has same name as file fe.", sep = "");
          stop(msg);
        }

        if (fcv == fe) {
          msg = "ERROR: from InparamReg.getCommandLineTestSuperPcCox:";
          msg = paste(msg, " File fcv has same name as file fe.", sep = "");
          stop(msg);
        }        

        if (fv == fx) {
          msg = "ERROR: from InparamReg.getCommandLineTestSuperPcCox:";
          msg = paste(msg, " File fv has same name as file fo.", sep = "");
          stop(msg);
        }

        if (fv == fe) {
          msg = "ERROR: from InparamReg.getCommandLineTestSuperPcCox:";
          msg = paste(msg, " File fv has same name as file fe.", sep = "");
          stop(msg);
        }        
	# ...................................................................................


        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       fv = fv,          
                       tTime = tTime,
                       tStatus = tStatus,
                       tTrainTest = tTrainTest,          
                       fo = fo,
                       fs = fs,
                       fcv = fcv,                    
                       methodFs = methodFs,          
                       p0 = p0,
                       mtop = mtop,
                       K = K,
                       methodSplit = methodSplit,
                       parameterScan = parameterScan );

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineTestSuperPcCox.
# =================================================================================================






# =================================================================================================
# . InparamReg.getCommandLineGenerateSimDataCox : gets command line arguments for generating files
# . -------------------------------------------   containing simulated data for testing out the
# .                                               Cox models for supervised principal components.
# .
# . Syntax :
# .
# .    inparam = InparamReg.getCommandLineGenerateSimDataCox(argv);
# .
# . In :
# .
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out :
# .
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineGenerateSimDataCox <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_generate_sim_data_cox                                                  \n");
           cat("\n");           
           cat("      -nTwoRegion 200 : number of genes used for panel twoRegion.            \n");
           cat("                        Genes in this region have a (-2,2) mean profile.     \n");
           cat("\n");
           cat("      -nFourRegion 50 : number of genes used for panel fourRegion.           \n");
           cat("                        Genes in this region have a (-1,1,-1,1) mean profile.\n");
           cat("\n");
           cat("      -nb 20         :  number of samples in each of 4 blocks used to gene-  \n");
           cat("                        rate all of the simulated data matrix columns        \n");
           cat("                        (there are thus a total of 4 * nb sample columns in  \n");
           cat("                        the simulated data matrix). Range: nb > 1.           \n");
           cat("\n");           
           cat("      -sigma 1.0     :  standard deviation of all noise terms in simulated   \n");
           cat("                        data. Range: sigma >= 0.0.                           \n");
           cat("\n");           
           cat("      -rngSeed 1234  :  random number generator seed for generation of all   \n");           
           cat("\n");
           cat("  -hazardPanel twoRegion : determines which panel of genes determines the    \n");
           cat("                           hazard ratios, as explained below.                \n");
           cat("                           Allowed: twoRegion, fourRegion, NONE              \n");
           cat("\n");                                                                       
           cat("                * The survival times are generated according to the          \n");
           cat("                exponential model :                                          \n");
           cat("\n");                                                                       
           cat("                   lambda(t|z) = lambda0 * exp(betaSim * z)                  \n");
           cat("\n");                                                                       
           cat("                where z = mean gene expression profile of selected panel     \n");
           cat("                (thus either from the (-2, 2) profile of the twoRegion,      \n");
           cat("                or the (-1,1,-1,1) profile of the fourRegion.                \n");
           cat("                Lambda0 = 1.0 is hard-wired.                                 \n");
           cat("                hazardPanel = NONE is the same as betaSim = 0 above : no     \n");
           cat("                dependence on gene expression covariates.                    \n");
           cat("\n");
           cat("     -betaSim 0.5  : true Cox coefficient, used in the exponential model.    \n");
           cat("\n");
           cat("  -fdv foo-gene.DFV  : output file for expression data, in DFV format.       \n");
           cat("                       File name must have extension DFV.                    \n");
           cat("\n");           
           cat("  -fe foo-label.DF   : output file for experimental design, containing       \n");
           cat("                       the survival times. File name must have extension DF. \n");
           cat("\n");
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
	# ...................................................................................
	nTwoRegion = as.numeric(Param.get_parameter(argv, "-nTwoRegion", 1));
	nFourRegion = as.numeric(Param.get_parameter(argv, "-nFourRegion", 1));                        
	nb = as.numeric(Param.get_parameter(argv, "-nb", 1));        
	sigma = as.numeric(Param.get_parameter(argv, "-sigma", 1));        
	rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1));
	hazardPanel = Param.get_parameter(argv, "-hazardPanel", 1);
        betaSim = as.numeric(Param.get_parameter(argv, "-betaSim", 1));        
        fdv = Param.get_parameter(argv, "-fdv", 1);
        fe = Param.get_parameter(argv, "-fe", 1);
	# ...................................................................................


        
	# ...................................................................................
        # . Check values :
	# ...................................................................................
        stopifnot(nb > 1);
        stopifnot(nTwoRegion >= 0);
        stopifnot(nFourRegion >= 0);

        stopifnot((nTwoRegion > 0) || (nFourRegion >0));  
        stopifnot(nFourRegion >= 0);        
        stopifnot(sigma >= 0.0);
        stopifnot((hazardPanel == 'twoRegion')
                  || (hazardPanel == 'fourRegion')
                  || (hazardPanel == 'NONE'));
        
        if (length(grep("\\.DFV$", fdv)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineGenerateSimDataCox:\n");
          cat("Output file fdv = ", fdv, " does not have DFV extension.\n");
          stop();
        }

        if (length(grep("\\.DF$", fe)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineGenerateSimDataCox:\n");
          cat("Output file fe = ", fe, " does not have DF extension.\n");
          stop();
        }        
	# ...................................................................................


        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       nTwoRegion = nTwoRegion,
                       nFourRegion = nFourRegion,
                       nb = nb,
                       sigma = sigma,
                       rngSeed = rngSeed,
                       hazardPanel = hazardPanel,
                       betaSim = betaSim,
                       fdv = fdv,
                       fe = fe   );

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineGenerateSimDataCox.
# =================================================================================================





# =================================================================================================
# . InparamReg.getCommandLineSuperPcCox : gets the command line arguments for 
# . -----------------------------------   run_super_pc_cox.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineSuperPcCox(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcCox <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_cox                                                           \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat("       -tTest testFlag        : factor defining test members                 \n");
           cat("                                - test set members are indicated by          \n");
           cat("                                  label = test. There must be at least 2     \n");
           cat("                                  test set members. Note that the test set   \n");
           cat("                                  can overlap with the training set or be    \n");
           cat("                                  completely disjoint.                       \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the test set.       \n");
           cat("                                - if the value of tTest is NONE, than no     \n");
           cat("                                  test set will be generated and used.       \n");
           cat("\n");           
           cat(">>SPC PARAMETERS:                                                            \n");
           cat("\n");
           cat("  -scoreType loglik : type of score used for computation of significance.    \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'loglik' : use score = 2 * (l(beta*) - l(0)).        \n");
           cat("                      - 'u0'     : use score = U(0)^2 / J(0).                \n");           
           cat("\n");                      
           cat("   -methodFs p0 : method of feature selection. Allowed options :	     \n");
           cat("                     - 'p0'   : use the P-value threshold p0 for             \n");
           cat("                                selecting genes.                             \n");
           cat("                     - 'mtop' : use the parameter mtop for selecting         \n");
           cat("                                genes.                                       \n");
           cat("\n");                                                                          
           cat("      -p0 0.01  : threshold in P-values from Cox proportional hazards model. \n");
           cat("                  Only genes with p <= p0 are kept after feature selection.  \n")
           cat("                  The p-values are computed using the univariate score test. \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("\n");
           cat("      -K 2      : number of principal components to be used as covariates    \n");
           cat("                  in the Cox proportional hazard model for the survival data.\n");
           cat("\n");
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");                      
           cat("       -fo foo.COXPH  : output file for sample-by-sample pcs and log-hazards.\n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("\n");
           cat("       -fv foo.PC     : output file for the principal component vectors.     \n");
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
	tTest = Param.get_parameter(argv, "-tTest", 1);      # Factor defining train/test sets.        
	# ...................................................................................
        # . >>Super pc parameters :
	# ...................................................................................
        scoreType = Param.get_parameter(argv, "-scoreType", 1);    # Univariate score.        
        methodFs = Param.get_parameter(argv, "-methodFs", 1);      # Feature selection method.

        p0 = as.numeric(Param.get_parameter(argv, "-p0", 1));      # P-value cutoff.
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.

        K = as.numeric(Param.get_parameter(argv, "-K", 1));    # Number of PCs to be used.
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
        
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.        
        fo = Param.get_parameter(argv, "-fo", 1);    # Output file for sample-by-sample pcs and hazards.
        fv = Param.get_parameter(argv, "-fv", 1);    # Output file for the principal component vectors.
	# ...................................................................................


	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCox:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCox:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (flagPlotWrite == "yes") {
          if (length(grep("\\.PLOT$", fplot, perl = TRUE)) == 0) {
            cat("ERROR: from InparamReg.getCommandLineSuperPcCox:\n");
            cat("The output plot file: fplot = ", fplot, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extension: PLOT.\n");
            msg = "";
            stop(msg);
          }
        }
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));        
        stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
        stopifnot((p0 >= 0.0) && (p0 <= 1.0));
        stopifnot(mtop >= 1);
        stopifnot(K >= 1);
	# ...................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo, fv, fplot);    # Output files.
        bBuf = c(fx, fe);               # Input files.

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCox:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tTime = tTime,
                       tStatus = tStatus,
                       tTrain = tTrain,
                       tTest = tTest,          
                       fs = fs,          
                       fo = fo,
                       fv = fv,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       scoreType = scoreType,          
                       methodFs = methodFs,          
                       p0 = p0,
                       mtop = mtop,
                       K = K );

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcCox.
# =================================================================================================




# =================================================================================================
# . InparamReg.getCommandLineSuperPcCoxCv : gets the command line arguments for 
# . -------------------------------------   run_super_pc_cox_cv.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineSuperPcCoxCv(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcCoxCv <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_cox_cv                                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -methodSplit vfold : how to split the data matrix into training and    \n");
           cat("                           test sets.                                        \n");
           cat("                           Allowed values: given, vfold, vfoldStrict         \n");
           cat("                           If value = given, a non-NONE value must be given  \n");
           cat("                           to option -tSplit (see below).                    \n");
           cat("\n");
           cat("      -ft 0.5            : required if methodSplit = vfold or vfoldStrict.   \n");
           cat("                           Fraction of training set instances                \n");
           cat("                           put into the test set at each                     \n");
           cat("                           sampling. Allowed values: 0 < ft < 1.             \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -ncv 10            : required if methodSplit = vfold. Number of vfold  \n");
           cat("                           resamplings.                                      \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfold. Initial random   \n");
           cat("                           number generator seed.                            \n");
           cat("\n");                      
           cat("      -tSplit testTrain  : factor defining how to splt the training set      \n");           
           cat("                           into subsets for the cross-validation.            \n");
           cat("                           Required if methodSplit = given, optional and     \n");
           cat("                           ignored otherwise.                                \n");
           cat("                           - In the field indicated by the (non-NONE) value,     \n");           
           cat("                           training set members are indicated by value = train   \n");
           cat("                           and test set by value = test. Values = NONE are       \n");
           cat("                           ignored. Any other values in this field are invalid.  \n");           
           cat("\n");           
           cat("      -parameterScan mtop : which parameter to scan in doing the cross-      \n");
           cat("                            validation. Allowed values: mtop, K              \n")
           cat("\n");
           cat(">>SPC PARAMETERS FOR THE CROSS_VALIDATION:                                   \n");
           cat("\n");
           cat("  -scoreType loglik : type of score used for computation of significance.    \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'loglik' : use score = 2 * (l(beta*) - l(0)).        \n");
           cat("                      - 'u0'     : use score = U(0)^2 / J(0).                \n");
           cat("\n");           
           cat(">>Parameters required if parameterScan = mtop, optional otherwise :          \n");
           cat("\n");           
           cat("      -K 2      : number of principal components to be used as covariates    \n");
           cat("                  in the Cox proportional hazard model for the survival data.\n");
           cat("                  Required if parameterScan = mtop, optional and ignored     \n");
           cat("                  otherwise.                                                 \n");
           cat("\n");
           cat("      -mtoplo 10  : lower bound on mtop values to be scanned.                 \n");
           cat("      -mtophi 500 : upper bound on mtop values to be scanned.                 \n");
           cat("      -mtopinc 50 : increment in mtop values to be scanned.                   \n");
           cat("\n");
           cat("\n");                      
           cat(">>Parameters required if parameterScan = K, optional otherwise :             \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values). Required if        \n");
           cat("                  parameterScan = K, optional and ignored otherwise.         \n");
           cat("\n");
           cat("      -Klo 1  : lower bound on K values to be scanned.                       \n");
           cat("      -Khi 10 : upper bound on K values to be scanned.                       \n");
           cat("      -Kinc 1 : increment in K values to be scanned.                         \n");           
           cat("\n");           
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Cross-validation parameters :
        # . >>How to split the data :
        # .................................................................................
        methodSplit = Param.get_parameter(argv, "-methodSplit", 1);      # Partition for CV loop.
        stopifnot((methodSplit == 'given')
                  || (methodSplit == 'vfold')
                  || (methodSplit == 'vfoldStrict'));

        if (methodSplit =='vfold') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = as.numeric(Param.get_parameter(argv, "-ncv", 1));         # Number of resamplings.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.
        } else if (methodSplit =='vfoldStrict') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = 0;                                                        # Dummy.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.          
        } else if (methodSplit == 'given') {
          ft = 0.0;                                                       # Dummy.
          ncv = 0;                                                        # Dummy.
          rngSeed = 123456;                                               # Dummy.
          tSplit = Param.get_parameter(argv, "-tSplit", 1);               # Factor for split,
        }
        # .................................................................................
        # . >>What to scan in the cross-validation loop :
        # .................................................................................
        scoreType = Param.get_parameter(argv, "-scoreType", 1);            # Univariate score.
        
        parameterScan = Param.get_parameter(argv, "-parameterScan", 1);    # Parameter to be scanned.
        stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));

        if (parameterScan == 'mtop') {
          mtop = 0;                                                  # Dummy for the fixed value.
          K = as.numeric(Param.get_parameter(argv, "-K", 1));        # Number of pcs used.
          mtoplo = as.numeric(Param.get_parameter(argv, "-mtoplo", 1));     # Lower bound.
          mtophi = as.numeric(Param.get_parameter(argv, "-mtophi", 1));     # Upper bound.
          mtopinc = as.numeric(Param.get_parameter(argv, "-mtopinc", 1));   # Increment.
          Klo = 0;                                                    # Dummy.
          Khi = 0;                                                    # Dummy.
          Kinc = 0;                                                   # Dummy.
        } else if (parameterScan == 'K') {                            
          mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff used.
          K = 0;                                                     # Dummy for fixed value.
          mtoplo = 0;                                                # Dummy.
          mtophi = 0;                                                # Dummy.
          mtopinc = 0;                                               # Dummy.
          Klo = as.numeric(Param.get_parameter(argv, "-Klo", 1));    # Lower bound.
          Khi = as.numeric(Param.get_parameter(argv, "-Khi", 1));    # Lower bound.
          Kinc = as.numeric(Param.get_parameter(argv, "-Kinc", 1));  # Increment.          
        }
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);              # Output file for cv results.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCv:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCv:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }        
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters, and generate arrays
        # . continaing the discrete values :
	# ...................................................................................        
        if (parameterScan == 'mtop') {
          stopifnot(K > 0);          
          stopifnot(mtoplo > 0);
          stopifnot(mtophi >= mtoplo);
          stopifnot(mtopinc > 0);

          amtop = seq(from = mtoplo, to = mtophi, by = mtopinc);
          if (max(amtop) < mtophi) {
            amtop = c(amtop, mtophi);    # Always include mtophi.
          }

          aK = c(0);                     # Dummy.
        } else if (parameterScan == 'K') {
          stopifnot(mtop > 0);          
          stopifnot(Klo > 0);
          stopifnot(Khi >= Klo);
          stopifnot(Kinc > 0);

          amtop = c(0);                  # Dummy.                    

          aK = seq(from = Klo, to = Khi, by = Kinc);
          if (max(aK) < Khi) {
            aK = c(aK, Khi);             # Always include Khi.
          }
        }

        stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));        
	# ...................................................................................


	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCv:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tTime = tTime,
                       tStatus = tStatus,
                       tTrain = tTrain,
                       methodSplit = methodSplit,
                       ft = ft,
                       ncv = ncv,
                       rngSeed = rngSeed,
                       tSplit = tSplit,
                       scoreType = scoreType,          
                       parameterScan = parameterScan,
                       K = K,
                       mtoplo = mtoplo,
                       mtophi = mtophi,
                       mtopinc = mtopinc,                    
                       mtop = mtop,
                       amtop = amtop,
                       Klo = Klo,
                       Khi = Khi,
                       Kinc = Kinc,
                       aK = aK,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcCoxCv.
# =================================================================================================




# =================================================================================================
# . InparamReg.getCommandLineSuperPcCoxFs : gets the command line arguments for 
# . -------------------------------------   run_super_pc_cox_fs.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineSuperPcCoxFs(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcCoxFs <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_cox_fs                                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>SPC PARAMETERS:                                                            \n");
           cat("\n");           
           cat("   -methodFs p0 : method of feature selection. Allowed options :	     \n");
           cat("                     - 'p0'   : use the P-value threshold p0 for             \n");
           cat("                                selecting genes.                             \n");
           cat("                     - 'mtop' : use the parameter mtop for selecting         \n");
           cat("                                genes.                                       \n");
           cat("\n");                                                                          
           cat("      -p0 0.01  : threshold in P-values from Cox proportional hazards model. \n");
           cat("                  Only genes with p <= p0 are kept after feature selection.  \n")
           cat("                  The p-values are computed using the univariate score test. \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("\n");
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fo foo.FLAT  : output file for data matrix subsetted to the selected \n");
           cat("                       features. Valid formats, indicated by the extension,  \n");
           cat("                       are: DF, DFV, FLAT.                                   \n");
           cat("\n");
           cat("       -fp foo.PVAL   : output file for P-values for all genes.              \n");
           cat("                        Extensions can be PVAL, PVAL1 or TSV.                \n");           
           cat("\n");                      
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
	# ...................................................................................
        # . >>Super pc parameters :
	# ...................................................................................
        methodFs = Param.get_parameter(argv, "-methodFs", 1);  # Feature selection method.

        p0 = as.numeric(Param.get_parameter(argv, "-p0", 1));      # P-value cutoff.
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
        
        fo = Param.get_parameter(argv, "-fo", 1);    # Output file for feature selected data matrix.
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.
        fp = Param.get_parameter(argv, "-fp", 1);    # Output file for P-values.
	# ...................................................................................


	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxFs:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxFs:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if ((length(grep("\\.DF$", fo, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fo, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fo, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxFs:\n");
          cat("The output data matrix file: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if ((length(grep("\\.PVAL$", fp, perl = TRUE)) == 0)
	    && (length(grep("\\.PVAL1$", fp, perl = TRUE)) == 0)
	    && (length(grep("\\.TSV$", fp, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxFs:\n");
          cat("The output P-values file: fp = ", fp, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: PVAL, PVAL1, TSV.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxFs:\n");
          cat("The output stats file: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: STAT.\n");
          msg = "";
          stop(msg);
        }                
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................        
        stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
        stopifnot((p0 >= 0.0) && (p0 <= 1.0));
        stopifnot(mtop >= 1);
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ...................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxFs:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tTime = tTime,
                       tStatus = tStatus,
                       tTrain = tTrain,
                       fs = fs,          
                       fo = fo,
                       fp = fp,          
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       methodFs = methodFs,          
                       p0 = p0,
                       mtop = mtop);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcCoxFs.
# =================================================================================================





# =================================================================================================
# . InparamReg.getCommandLineSuperPcCoxUni : gets the command line arguments for 
# . --------------------------------------   run_super_pc_cox_uni.r
# .
# .    inparam = InparamReg.getCommandLineSuperPcCoxUni(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcCoxUni <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");

           cat("Description:\n");
           cat("Generates univariate, gene-by-gene Cox proportional hazard statistics\n");
           cat("for the given input data matrix. For each gene computes one of two measures of\n");
           cat("significance, one based on the fitted model score 2 * (l(beta*) - l(0)),\n");
           cat("and the other based on the score for beta = 0, U(0)^2 / J(0). Each of\n");
           cat("these scores should have a Chi-squared distribution with one degree of\n");
           cat("freedom, under the null hypothesis of no dependence of survival time on gene\n");
           cat("expression. Internally does feature selection on the selected score, and optionally.\n");
           cat("outputs the subsetted data matrix.\n");           

           cat("\n");           
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_cox_uni                                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>SCORE AND FEATURE SELECTION PARAMETERS:                                    \n")
           cat("\n");
           cat("  -scoreType loglik : type of score used for computation of significance.    \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'loglik' : use score = 2 * (l(beta*) - l(0)).        \n");
           cat("                      - 'u0'     : use score = U(0)^2 / J(0).                \n");           
           cat("\n");           
           cat("   -methodFs p0 : method of feature selection.                               \n");
           cat("                  Allowed values :	                                     \n");
           cat("                     - 'p0'   : use the P-value threshold p0 for             \n");
           cat("                                selecting genes.                             \n");
           cat("                     - 'mtop' : use the parameter mtop for selecting         \n");
           cat("                                genes.                                       \n");
           cat("\n");                                                                          
           cat("      -p0 0.01  : threshold in P-values from Cox proportional hazards model. \n");
           cat("                  Only genes with p <= p0 are kept after feature selection.  \n")
           cat("                  The p-values are computed using the univariate score test. \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("\n");
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");
           cat("       -fp foo.PVAL   : output file for scores and P-values for all genes.   \n");
           cat("                        Extensions can be PVAL, PVAL1, TSV or COXUNI.        \n");           
           cat("\n");                      
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");
           cat("\n");
           cat("  -flagFsOut yes : yes/no; if yes, write the feature-selected data matrix    \n");
           cat("                   to file (as specified by option -fs).                     \n");
           cat("\n");
           cat("       -fo foo.FLAT  : output file for data matrix subsetted to the selected \n");
           cat("                       features. Valid formats, indicated by the extension,  \n");
           cat("                       are: DF, DFV, FLAT.                                   \n");
           cat("                       Required if flagFsOut = 'yes', ignored otherwise.     \n");
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
	# ...................................................................................
        # . >>Feature selection parameters :
	# ...................................................................................
        scoreType = Param.get_parameter(argv, "-scoreType", 1);    # Flag for feature selection.
        methodFs = Param.get_parameter(argv, "-methodFs", 1);      # Feature selection method.

        p0 = as.numeric(Param.get_parameter(argv, "-p0", 1));      # P-value cutoff.
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.
	# ...................................................................................
        # . >>Output : plots :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);      # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
	# ...................................................................................
        # . >>Output : general statistics and score files :
	# ...................................................................................
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.
        fp = Param.get_parameter(argv, "-fp", 1);    # Output file for P-values.
	# ...................................................................................
        # . >>Output : optional subsetted data matrix.
	# ...................................................................................        
        flagFsOut = Param.get_parameter(argv, "-flagFsOut", 1);     # Flag for output of feature selection.
        stopifnot((flagFsOut == 'yes') || (flagFsOut == 'no'));
        
        if (flagFsOut == 'yes') {
          fo = Param.get_parameter(argv, "-fo", 1);         # Output file for feature selected data matrix.
        } else {
          fo = 'NONE';                                      # Dummy assignment.
        }
	# ...................................................................................


	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUni:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUni:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (flagFsOut == 'yes') {
          if ((length(grep("\\.DF$", fo, perl = TRUE)) == 0)
              && (length(grep("\\.DFV$", fo, perl = TRUE)) == 0)
              && (length(grep("\\.FLAT$", fo, perl = TRUE)) == 0)) {
            cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUni:\n");
            cat("The output data matrix file: fo = ", fo, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
            msg = "";
            stop(msg);
          }
        }

        if ((length(grep("\\.PVAL$", fp, perl = TRUE)) == 0)
	    && (length(grep("\\.PVAL1$", fp, perl = TRUE)) == 0)
	    && (length(grep("\\.TSV$", fp, perl = TRUE)) == 0)
	    && (length(grep("\\.COXUNI$", fp, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUni:\n");
          cat("The output P-values file: fp = ", fp, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: PVAL, PVAL1, TSV, COXUNI.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUni:\n");
          cat("The output stats file: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: STAT.\n");
          msg = "";
          stop(msg);
        }                
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));        
        stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
        stopifnot((p0 >= 0.0) && (p0 <= 1.0));
        stopifnot(mtop >= 1);

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ...................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUni:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tTime = tTime,
                       tStatus = tStatus,
                       tTrain = tTrain,
                       fs = fs,          
                       fp = fp,          
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       flagFsOut = flagFsOut,
                       fo = fo,
                       scoreType = scoreType,
                       methodFs = methodFs,          
                       p0 = p0,
                       mtop = mtop);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcCoxUni.
# =================================================================================================






# =================================================================================================
# . InparamReg.getCommandLineSuperPcRegressUni : gets the command line arguments for 
# . ------------------------------------------   run_super_pc_regress_uni.r
# .
# .    inparam = InparamReg.getCommandLineSuperPcRegressUni(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcRegressUni <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");

           cat("Description:\n");
           cat("Generates univariate, gene-by-gene regression model statistics\n");
           cat("for the given input data matrix. For each gene computes a significance\n");
           cat("score and a P-value.\n");
           cat("Internally does feature selection, and optionally outputs the subsetted data matrix.\n");

           cat("\n");           
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_regress_uni                                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>OUTPUT VARIABLE AND TRAIN/TEST SPECIFICATION:                              \n");
           cat("\n");
           cat("       -tY tumorToControl     : factor for output variable in experimental   \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>MODEL AND FEATURE SELECTION PARAMETERS:                                    \n")
           cat("\n");
           cat("   -modelType lm : regression model to be used.                               \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'lm'       : linear mod.                             \n");
           cat("                      - 'logistic' : logistic distribution.                  \n");           
           cat("\n");           
           cat("   -methodFs p0 : method of feature selection.                               \n");
           cat("                  Allowed values :	                                     \n");
           cat("                     - 'p0'   : use the P-value threshold p0 for             \n");
           cat("                                selecting genes.                             \n");
           cat("                     - 'mtop' : use the parameter mtop for selecting         \n");
           cat("                                genes.                                       \n");
           cat("\n");                                                                          
           cat("      -p0 0.01  : threshold in P-values from Cox proportional hazards model. \n");
           cat("                  Only genes with p <= p0 are kept after feature selection.  \n")
           cat("                  The p-values are computed using the univariate score test. \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("\n");
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");
           cat("       -fp foo.REGUNI : output file for scores and P-values for all genes.   \n");
           cat("                        Extension must be REGUNI.                            \n");           
           cat("\n");                      
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");
           cat("\n");
           cat("  -flagFsOut yes : yes/no; if yes, write the feature-selected data matrix    \n");
           cat("                   to file (as specified by option -fs).                     \n");
           cat("\n");
           cat("       -fo foo.FLAT  : output file for data matrix subsetted to the selected \n");
           cat("                       features. Valid formats, indicated by the extension,  \n");
           cat("                       are: DF, DFV, FLAT.                                   \n");
           cat("                       Required if flagFsOut = 'yes', ignored otherwise.     \n");
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tY = Param.get_parameter(argv, "-tY", 1);            # Factor for output variable.
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
	# ...................................................................................
        # . >>Feature selection parameters :
	# ...................................................................................
        modelType = Param.get_parameter(argv, "-modelType", 1);    # Flag for feature selection.
        methodFs = Param.get_parameter(argv, "-methodFs", 1);      # Feature selection method.

        p0 = as.numeric(Param.get_parameter(argv, "-p0", 1));      # P-value cutoff.
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.
	# ...................................................................................
        # . >>Output : plots :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);      # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
	# ...................................................................................
        # . >>Output : general statistics and score files :
	# ...................................................................................
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.
        fp = Param.get_parameter(argv, "-fp", 1);    # Output file for P-values.
	# ...................................................................................
        # . >>Output : optional subsetted data matrix.
	# ...................................................................................        
        flagFsOut = Param.get_parameter(argv, "-flagFsOut", 1);     # Flag for output of feature selection.
        stopifnot((flagFsOut == 'yes') || (flagFsOut == 'no'));
        
        if (flagFsOut == 'yes') {
          fo = Param.get_parameter(argv, "-fo", 1);         # Output file for feature selected data matrix.
        } else {
          fo = 'NONE';                                      # Dummy assignment.
        }
	# ...................................................................................


	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressUni:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressUni:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (flagFsOut == 'yes') {
          if ((length(grep("\\.DF$", fo, perl = TRUE)) == 0)
              && (length(grep("\\.DFV$", fo, perl = TRUE)) == 0)
              && (length(grep("\\.FLAT$", fo, perl = TRUE)) == 0)) {
            cat("ERROR: from InparamReg.getCommandLineSuperPcRegressUni:\n");
            cat("The output data matrix file: fo = ", fo, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
            msg = "";
            stop(msg);
          }
        }

        if ((length(grep("\\.REGUNI$", fp, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressUni:\n");
          cat("The output P-values file: fp = ", fp, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: REGUNI.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressUni:\n");
          cat("The output stats file: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: STAT.\n");
          msg = "";
          stop(msg);
        }                
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot((modelType == 'lm') || (modelType == 'logistic'));        
        stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
        stopifnot((p0 >= 0.0) && (p0 <= 1.0));
        stopifnot(mtop >= 1);

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ...................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressUni:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tY = tY,
                       tTrain = tTrain,
                       fs = fs,          
                       fp = fp,          
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       flagFsOut = flagFsOut,
                       fo = fo,
                       modelType = modelType,
                       methodFs = methodFs,          
                       p0 = p0,
                       mtop = mtop);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcRegressUni.
# =================================================================================================






# =================================================================================================
# . InparamReg.getCommandLineSuperPcRegress : gets the command line arguments for 
# . ---------------------------------------   run_super_pc_regress.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineSuperPcRegress(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcRegress <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");

           cat("Description:\n");
           cat("Multivariate regression of a given output variable on the\n");
           cat("gene expression values provided in an input data matrix :\n");           
           cat("i) performs feature selection on genes using a univariate regression model,\n");
           cat("ii) then generates a multivariate regression model for the output variable,\n");
           cat("using the principal components the reduced feature set as covariates.\n");

           cat("\n");           
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_regress                                                       \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>OUTPUT VARIABLE AND TRAIN/TEST SPECIFICATION:                              \n");           
           cat("\n");
           cat("       -tY tumorToControl     : factor for output variable in experimental   \n");
           cat("                                design file.                                 \n"); 
           cat("\n");           
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>MODEL AND FEATURE SELECTION PARAMETERS:                                    \n")
           cat("\n");           
           cat("   -modelType lm : regression model to be used.                               \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'lm'     : linear model.                             \n");
           cat("                      - 'logistic' : logistic distribution.                  \n");           
           cat("\n");           
           cat("   -methodFs p0 : method of feature selection. Allowed options :	     \n");
           cat("                     - 'p0'   : use the P-value threshold p0 for             \n");
           cat("                                selecting genes.                             \n");
           cat("                     - 'mtop' : use the parameter mtop for selecting         \n");
           cat("                                genes.                                       \n");
           cat("\n");                                                                          
           cat("      -p0 0.01  : threshold in P-values from the regression model.           \n");
           cat("                  Only genes with p <= p0 are kept after feature selection.  \n")
           cat("                  The p-values are computed using the univariate score test. \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant regression scores\n");  
           cat("                  (i.e. those with the mtop smallest P-values).              \n");
           cat("\n");
           cat("      -K 2      : number of principal components to be used as covariates    \n");
           cat("                  in the regression model for the survival data.             \n");
           cat("\n");
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-regress', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");                      
           cat("       -fo foo.REGRESS: output file for sample-by-sample pcs and predictions.\n");
           cat("                        Must have extension REGRESS.                         \n");           
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("\n");
           cat("       -fv foo.PC     : output file for the principal component vectors.     \n");
           cat("                        Must have extension PC.                              \n");
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tY = Param.get_parameter(argv, "-tY", 1);            # Factor for output variable.       
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
	# ...................................................................................
        # . >>Super pc parameters :
	# ...................................................................................
        modelType = Param.get_parameter(argv, "-modelType", 1);    # Flag for feature selection.        
        methodFs = Param.get_parameter(argv, "-methodFs", 1);      # Feature selection method.

        p0 = as.numeric(Param.get_parameter(argv, "-p0", 1));      # P-value cutoff.
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.

        K = as.numeric(Param.get_parameter(argv, "-K", 1));    # Number of PCs to be used.
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
        
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.        
        fo = Param.get_parameter(argv, "-fo", 1);    # Output file for sample-by-sample pcs and predictions.
        fv = Param.get_parameter(argv, "-fv", 1);    # Output file for the principal component vectors.
	# ...................................................................................


	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegress:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegress:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if ((length(grep("\\.REGRESS$", fo, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegress:\n");
          cat("The regression predictions output file: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: REGRESS.\n");
          msg = "";
          stop(msg);
        }

        if ((length(grep("\\.PC$", fv, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegress:\n");
          cat("The principal component vectors output file: fv = ", fv, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: PC.\n");
          msg = "";
          stop(msg);
        }        
        
        if (flagPlotWrite == "yes") {
          if (length(grep("\\.PLOT$", fplot, perl = TRUE)) == 0) {
            cat("ERROR: from InparamReg.getCommandLineSuperPcRegress:\n");
            cat("The output plot file: fplot = ", fplot, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extension: PLOT.\n");
            msg = "";
            stop(msg);
          }
        }
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot((modelType == 'lm') || (modelType == 'logistic'));        
        stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
        stopifnot((p0 >= 0.0) && (p0 <= 1.0));
        stopifnot(mtop >= 1);
        stopifnot(K >= 1);
	# ...................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo, fv, fplot);    # Output files.
        bBuf = c(fx, fe);               # Input files.

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegress:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tY = tY,          
                       tTrain = tTrain,
                       fs = fs,          
                       fo = fo,
                       fv = fv,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       modelType = modelType,
                       methodFs = methodFs,          
                       p0 = p0,
                       mtop = mtop,
                       K = K );

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcRegress.
# =================================================================================================






# =================================================================================================
# . InparamReg.getCommandLineSuperPcRegressCv : gets the command line arguments for 
# . -----------------------------------------   run_super_pc_regress_cv.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineSuperPcRegressCv(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcRegressCv <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           
           cat("Description:\n");
           cat("Performs cross-validation of a multivariate regression model\n");
           cat("of a given output variable on the gene expression values\n");
           cat("provided in an input data matrix. The model: \n");           
           cat("i) performs feature selection on genes using a univariate regression model,\n");
           cat("ii) then generates a multivariate regression model for the output variable,\n");
           cat("using the principal components the reduced feature set as covariates.\n");

           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_regress_cv                                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>OUTPUT VARIABLE AND TRAIN/TEST SPECIFICATION:                              \n");
           cat("\n");
           cat("       -tY tumorToControl     : factor for output variable in experimental   \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");
           cat("\n");
           cat(">>MODEL TYPE:                                                                \n")
           cat("\n");           
           cat("   -modelType lm : regression model to be used.                              \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'lm'     : linear model.                             \n");
           cat("                      - 'logistic' : logistic distribution.                  \n");           
           cat("\n");                      
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -methodSplit vfoldStrict : how to split the data matrix into training  \n");
           cat("                           and test sets.                                    \n");
           cat("                           Allowed values: given, vfold                      \n");
           cat("                           If value = given, a non-NONE value must be given  \n");
           cat("                           to option -tSplit (see below).                    \n");
           cat("\n");
           cat("      -ft 0.5            : required if methodSplit = vfold. Fraction of      \n");
           cat("                           training set instances put into test set at each  \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -ncv 10            : required if methodSplit = vfold. Number of vfold  \n");
           cat("                           resamplings.                                      \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfold. Initial random   \n");
           cat("                           number generator seed.                            \n");
           cat("\n");                      
           cat("      -tSplit testTrain  : factor defining how to split the training set     \n");           
           cat("                           into subsets for the cross-validation.            \n");
           cat("                           Required if methodSplit = given, optional and     \n");
           cat("                           ignored otherwise.                                \n");
           cat("                           - In the field indicated by the (non-NONE) value,     \n");           
           cat("                           training set members are indicated by value = train   \n");
           cat("                           and test set by value = test. Values = NONE are       \n");
           cat("                           ignored. Any other values in this field are invalid.  \n");           
           cat("\n");           
           cat("      -parameterScan mtop : which parameter to scan in doing the cross-      \n");
           cat("                            validation. Allowed values: mtop, K              \n")
           cat("\n");
           cat(">>SPC PARAMETERS FOR THE CROSS_VALIDATION:                                   \n");
           cat(">>Parameters required if parameterScan = mtop, optional otherwise :          \n");
           cat("\n");           
           cat("      -K 2      : number of principal components to be used as covariates    \n");
           cat("                  in the regression  model for the output variable.          \n");
           cat("                  Required if parameterScan = mtop, optional and ignored     \n");
           cat("                  otherwise.                                                 \n");
           cat("\n");
           cat("      -mtoplo 10  : lower bound on mtop values to be scanned.                 \n");
           cat("      -mtophi 500 : upper bound on mtop values to be scanned.                 \n");
           cat("      -mtopinc 50 : increment in mtop values to be scanned.                   \n");
           cat("\n");
           cat("\n");                      
           cat(">>Parameters required if parameterScan = K, optional otherwise :             \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant regressionscores (i.e. \n");  
           cat("                  those with the mtop smallest P-values). Required if        \n");
           cat("                  parameterScan = K, optional and ignored otherwise.         \n");
           cat("\n");
           cat("      -Klo 1  : lower bound on K values to be scanned.                       \n");
           cat("      -Khi 10 : upper bound on K values to be scanned.                       \n");
           cat("      -Kinc 1 : increment in K values to be scanned.                         \n");           
           cat("\n");           
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-regress', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	tY = Param.get_parameter(argv, "-tY", 1);            # Factor for output variable.               
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Model type :
        # .................................................................................
        modelType = Param.get_parameter(argv, "-modelType", 1);    # Flag for feature selection.        
        # .................................................................................
        # . Cross-validation parameters :
        # . >>How to split the data :
        # .................................................................................
        methodSplit = Param.get_parameter(argv, "-methodSplit", 1);      # Partition for CV loop.
        stopifnot((methodSplit == 'given')
                  || (methodSplit == 'vfoldStrict'));                    # N.B. I suppressed vfold option.

        if (methodSplit =='vfold') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = as.numeric(Param.get_parameter(argv, "-ncv", 1));         # Number of resamplings.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.
        } else if (methodSplit =='vfoldStrict') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = 0;                                                        # Dummy.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.                              
        } else if (methodSplit == 'given') {
          ft = 0.0;                                                       # Dummy.
          ncv = 0;                                                        # Dummy.
          rngSeed = 123456;                                               # Dummy.
          tSplit = Param.get_parameter(argv, "-tSplit", 1);               # Factor for split,
        }
        # .................................................................................
        # . >>What to scan in the cross-validation loop :
        # .................................................................................
        parameterScan = Param.get_parameter(argv, "-parameterScan", 1);    # Parameter to be scanned.
        stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));

        if (parameterScan == 'mtop') {
          mtop = 0;                                                  # Dummy for the fixed value.
          K = as.numeric(Param.get_parameter(argv, "-K", 1));        # Number of pcs used.
          mtoplo = as.numeric(Param.get_parameter(argv, "-mtoplo", 1));     # Lower bound.
          mtophi = as.numeric(Param.get_parameter(argv, "-mtophi", 1));     # Upper bound.
          mtopinc = as.numeric(Param.get_parameter(argv, "-mtopinc", 1));   # Increment.
          Klo = 0;                                                    # Dummy.
          Khi = 0;                                                    # Dummy.
          Kinc = 0;                                                   # Dummy.
        } else if (parameterScan == 'K') {                            
          mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff used.
          K = 0;                                                     # Dummy for fixed value.
          mtoplo = 0;                                                # Dummy.
          mtophi = 0;                                                # Dummy.
          mtopinc = 0;                                               # Dummy.
          Klo = as.numeric(Param.get_parameter(argv, "-Klo", 1));    # Lower bound.
          Khi = as.numeric(Param.get_parameter(argv, "-Khi", 1));    # Lower bound.
          Kinc = as.numeric(Param.get_parameter(argv, "-Kinc", 1));  # Increment.          
        }
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);              # Output file for cv results.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressCv:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressCv:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }        
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters, and generate arrays
        # . continaing the discrete values :
	# ...................................................................................        
        if (parameterScan == 'mtop') {
          stopifnot(K > 0);          
          stopifnot(mtoplo > 0);
          stopifnot(mtophi >= mtoplo);
          stopifnot(mtopinc > 0);

          amtop = seq(from = mtoplo, to = mtophi, by = mtopinc);
          if (max(amtop) < mtophi) {
            amtop = c(amtop, mtophi);    # Always include mtophi.
          }

          aK = c(0);                     # Dummy.
        } else if (parameterScan == 'K') {
          stopifnot(mtop > 0);          
          stopifnot(Klo > 0);
          stopifnot(Khi >= Klo);
          stopifnot(Kinc > 0);

          amtop = c(0);                  # Dummy.                    

          aK = seq(from = Klo, to = Khi, by = Kinc);
          if (max(aK) < Khi) {
            aK = c(aK, Khi);             # Always include Khi.
          }
        }
	# ...................................................................................

        

	# ...............................................................
        # . Check on the validity of the other input parameters :
        # ...............................................................
        stopifnot((modelType == 'lm') || (modelType == 'logistic'));                
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ...............................................................
        

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressCv:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tY = tY,          
                       tTrain = tTrain,
                       modelType = modelType,          
                       methodSplit = methodSplit,
                       ft = ft,
                       ncv = ncv,
                       rngSeed = rngSeed,
                       tSplit = tSplit,
                       parameterScan = parameterScan,
                       K = K,
                       mtoplo = mtoplo,
                       mtophi = mtophi,
                       mtopinc = mtopinc,                    
                       mtop = mtop,
                       amtop = amtop,
                       Klo = Klo,
                       Khi = Khi,
                       Kinc = Kinc,
                       aK = aK,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcRegressCv.
# =================================================================================================




# =================================================================================================
# . InparamReg.getCommandLineGenerateSimDataRegress : gets command line arguments for generating files
# . -----------------------------------------------   containing simulated data for testing out the
# .                                                   supervised principal components regression
# .                                                   models.
# .
# . Syntax :
# .
# .    inparam = InparamReg.getCommandLineGenerateSimDataRegress(argv);
# .
# . In :
# .
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out :
# .
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineGenerateSimDataRegress <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_generate_sim_data_regress                                              \n");
           cat("\n");           
           cat("      -nTwoRegion 200 : number of genes used for panel twoRegion.            \n");
           cat("                        Genes in this region have a (-2,2) mean profile.     \n");
           cat("\n");
           cat("      -nFourRegion 50 : number of genes used for panel fourRegion.           \n");
           cat("                        Genes in this region have a (-1,1,-1,1) mean profile.\n");
           cat("\n");
           cat("      -nb 20         :  number of samples in each of 4 blocks used to gene-  \n");
           cat("                        rate all of the simulated data matrix columns        \n");
           cat("                        (there are thus a total of 4 * nb sample columns in  \n");
           cat("                        the simulated data matrix). Range: nb > 1.           \n");
           cat("\n");           
           cat("      -sigma 1.0     :  standard deviation of all noise terms in simulated   \n");
           cat("                        gene expression data. Range: sigma >= 0.0.           \n");
           cat("\n");
           cat("      -rngSeed 1234  :  random number generator seed for generation of all   \n");
           cat("                        noise terms.                                         \n");
           cat("\n");
           cat("  -generatingPanel twoRegion : determines which panel of genes determines    \n");
           cat("                               the output variable statistical parameters,   \n");
           cat("                               as explained below.                           \n");
           cat("                               Allowed: twoRegion, fourRegion, NONE          \n");
           cat("\n");
           cat("       -modelType lm : model used to generate the simulated output variable  \n");
           cat("                       data. Allowed:                                        \n");
           cat("                            - lm : linear model.                             \n");
           cat("                            - logistic : logistic distribution.              \n");
           cat("\n");           
           cat("                * The output variables are generated according to            \n");
           cat("                modelType :                                                  \n");
           cat("\n");           
           cat("                 1).lm : linear model, with output y generated accorrding to: \n");
           cat("\n");
           cat("                            y = betaSim0  +  betaSim1 * z  + epsY            \n"); 
           cat("\n");          
           cat("                 2) logistic : output y is a binary {0, 1} variable, probabilitically \n");
           cat("                               generated according to:                                \n");
           cat("\n");
           cat("                            logit(P(y = 1|z)) = betaSim0  +  betaSim1 * z             \n");
           cat("\n");
           cat("                               or equivalently :                                      \n");
           cat("\n");
           cat("                                                       1                              \n");
           cat("                            P(y = 1|z) =  --------------------------------            \n");
           cat("                                           1 + exp( - (beta0 + beta1 * z))            \n");
           cat("\n");
           cat("\n");
           cat("                         where:                                              \n");
           cat("\n");           
           cat("                        z = mean gene expression profile of selected panel   \n");
           cat("                            (thus either from the (-2, 2) profile of the,    \n");
           cat("                            twoRegion or the (-1,1,-1,1) profile of the      \n");
           cat("                            fourRegion.                                      \n");
           cat("\n");           
           cat("                        betaSim0, betaSim1 = linear model parameters         \n");
           cat("                                             (see below).                    \n"); 
           cat("\n");
           cat("                        epsY = Gaussian noise term, with standard deviation  \n");
           cat("                               given by sigmaY below.                        \n");
           cat("\n");           
           cat("                Note that generatingPanel = NONE is the same as              \n");
           cat("                betaSim1 = 0 above : no dependence on gene expression        \n");
           cat("                covariates.                                                  \n");
           cat("\n");
           cat("     -betaSim0 0.5  : intercept parameter, used in linear model lm.          \n");
           cat("\n");           
           cat("     -betaSim1 2.0  : slope parameter, used in linear model lm.              \n");
           cat("\n");
           cat("     -sigmaY 1.0    : standard deviation of noise terms in simulated         \n");
           cat("                      output variable Y. Range: sigmaY >= 0.0.               \n");
           cat("\n");
           cat("  -fdv foo-gene.DFV  : output file for expression data, in DFV format.       \n");
           cat("                       File name must have extension DFV.                    \n");
           cat("\n");           
           cat("  -fe foo-label.DF   : output file for experimental design, containing       \n");
           cat("                       the survival times. File name must have extension DF. \n");
           cat("\n");
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
	# ...................................................................................
	nTwoRegion = as.numeric(Param.get_parameter(argv, "-nTwoRegion", 1));
	nFourRegion = as.numeric(Param.get_parameter(argv, "-nFourRegion", 1));                        
	nb = as.numeric(Param.get_parameter(argv, "-nb", 1));        
	sigma = as.numeric(Param.get_parameter(argv, "-sigma", 1));        
	rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1));
	generatingPanel = Param.get_parameter(argv, "-generatingPanel", 1);
        modelType = Param.get_parameter(argv, "-modelType", 1);        
        betaSim0 = as.numeric(Param.get_parameter(argv, "-betaSim0", 1));
        betaSim1 = as.numeric(Param.get_parameter(argv, "-betaSim1", 1));
	sigmaY = as.numeric(Param.get_parameter(argv, "-sigmaY", 1));        
        fdv = Param.get_parameter(argv, "-fdv", 1);
        fe = Param.get_parameter(argv, "-fe", 1);
	# ...................................................................................


        
	# ...................................................................................
        # . Check values :
	# ...................................................................................
        stopifnot(nb > 1);
        stopifnot(nTwoRegion >= 0);
        stopifnot(nFourRegion >= 0);

        stopifnot((nTwoRegion > 0) || (nFourRegion >0));  
        stopifnot(nFourRegion >= 0);        
        stopifnot(sigma >= 0.0);
        stopifnot((modelType == 'lm') || (modelType == 'logistic'));        
        stopifnot((generatingPanel == 'twoRegion')
                  || (generatingPanel == 'fourRegion')
                  || (generatingPanel == 'NONE'));
        stopifnot(sigmaY >= 0.0);        
        
        if (length(grep("\\.DFV$", fdv)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineGenerateSimDataRegress:\n");
          cat("Output file fdv = ", fdv, " does not have DFV extension.\n");
          stop();
        }

        if (length(grep("\\.DF$", fe)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineGenerateSimDataRegress:\n");
          cat("Output file fe = ", fe, " does not have DF extension.\n");
          stop();
        }        
	# ...................................................................................


        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       nTwoRegion = nTwoRegion,
                       nFourRegion = nFourRegion,
                       nb = nb,
                       sigma = sigma,
                       rngSeed = rngSeed,
                       modelType = modelType,
                       generatingPanel = generatingPanel,
                       betaSim0 = betaSim0,
                       betaSim1 = betaSim1,
                       sigmaY = sigmaY,          
                       fdv = fdv,
                       fe = fe   );

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineGenerateSimDataRegress.
# =================================================================================================






# =================================================================================================
# . InparamReg.getCommandLineGenerateSimDataCoxWithCov : gets command line arguments for generating files
# . --------------------------------------------------   containing simulated data for testing out the
# .                                                      Cox models for supervised principal components.
# .                                                      This version includes dependency on an
#.                                                       external covariate.
# .
# . Syntax :
# .
# .    inparam = InparamReg.getCommandLineGenerateSimDataCoxWithCov(argv);
# .
# . In :
# .
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out :
# .
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineGenerateSimDataCoxWithCov <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_generate_sim_data_cox                                                  \n");
           cat("............................................................................ \n");
           cat(" * Region specifications for gene expression :                               \n");
           cat("\n");           
           cat("      -nTwoRegion 200 : number of genes used for panel twoRegion.            \n");
           cat("                        Genes in this region have a (-xTwoRegion,xTwoRegion) \n");
           cat("                        mean profile, where xTwoRegion is specified below.   \n");
           cat("\n");
           cat("      -xTwoRegionLeft 2 : specifies mean values for panel twoRegion.         \n");
           cat("\n");
           cat("      -sigmaTwoRegion 1 : std. dev. of noise for for panel twoRegion.        \n");
           cat("\n");                      
           cat("      -nFourRegion 50 : number of genes used for panel fourRegion.           \n");
           cat("                        Genes in this region have a (x4L, x4R, x4L, x4R)     \n");
           cat("                        mean profile, where x4L = xFourRegionL and           \n");
           cat("                        x4R = xFourRegionR are specified below.              \n");
           cat("\n");
           cat("      -xFourRegionL 0  : specifies mean values for LH sides for panel        \n");
           cat("                         fourRegion (see above).                             \n");
           cat("\n");
           cat("      -xFourRegionR 1  : specifies mean values for RH sides for panel        \n");
           cat("                         fourRegion (see above).                             \n");
           cat("\n");           
           cat("      -sigmaFourRegion 1 : std. dev. of noise for for panel fourRegion.      \n");
           cat("\n");                                 
           cat("      -nb 20         :  number of samples in each of 4 blocks used to gene-  \n");
           cat("                        rate all of the simulated data matrix columns        \n");
           cat("                        (there are thus a total of 4 * nb sample columns in  \n");
           cat("                        the simulated data matrix). Range: nb > 1.           \n");
           cat("\n");           
           cat("      -rngSeed 1234  :  random number generator seed for generation of all   \n");           
           cat("\n");
           cat("  -hazardPanel twoRegion : determines which panel of genes determines the    \n");
           cat("                           hazard ratios, as explained below.                \n");
           cat("                           Allowed: twoRegion, fourRegion, NONE              \n");
           cat("............................................................................ \n");
           cat(" * Cox coefficients for generating model :                                   \n");
           cat("\n");
           cat("     -betaSim1 1.0  : true Cox coefficient beta1.                            \n");
           cat("\n");
           cat("     -betaSim2 1.0  : true Cox coefficient beta2.                            \n");
           cat("\n");
           cat("     -betaSim3 -2.0 : true Cox coefficient beta3.                            \n");           
           cat("\n");
           cat("\n");                                                                       
           cat("                * The survival times are generated according to an           \n");
           cat("                exponential model with hazard :                              \n");
           cat("\n");                                                                       
           cat("                   lambda(t|x,z) = lambda0 *                                 \n");
           cat("                               exp(beta1 * x + beta2 * z + beta3 * z * x)    \n");
           cat("\n");                                                                       
           cat("                where x = mean gene expression profile of selected panel     \n");
           cat("                (thus either from the (-2, 2) profile of the twoRegion,      \n");
           cat("                or the (-1,1,-1,1) profile of the fourRegion, and where z    \n");
           cat("                is a covariate with z = 0 in the first half of the panel,    \n");
           cat("                and z = 1 in the second half of the entire panel.            \n");
           cat("\n");
           cat("                Lambda0 = 1.0 is hard-wired.                                 \n");
           cat("                hazardPanel = NONE is the same as betaSim = 0 above : no     \n");
           cat("                dependence on gene expression covariates.                    \n");
           cat("\n");
           cat("............................................................................ \n");
           cat(" * Output files :                                                            \n");
           cat("\n");
           cat("  -fdv foo-gene.DFV  : output file for expression data, in DFV format.       \n");
           cat("                       File name must have extension DFV.                    \n");
           cat("\n");           
           cat("  -fe foo-label.DF   : output file for experimental design, containing       \n");
           cat("                       the survival times. File name must have extension DF. \n");
           cat("\n");
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
	# ...................................................................................
	nTwoRegion = as.numeric(Param.get_parameter(argv, "-nTwoRegion", 1));
	xTwoRegion = as.numeric(Param.get_parameter(argv, "-xTwoRegion", 1));
	sigmaTwoRegion = as.numeric(Param.get_parameter(argv, "-sigmaTwoRegion", 1));
	nFourRegion = as.numeric(Param.get_parameter(argv, "-nFourRegion", 1));
	xFourRegionL = as.numeric(Param.get_parameter_ez(argv, "-xFourRegionL", 1));
	xFourRegionR = as.numeric(Param.get_parameter_ez(argv, "-xFourRegionR", 1));        
	sigmaFourRegion = as.numeric(Param.get_parameter(argv, "-sigmaFourRegion", 1));        
        
	nb = as.numeric(Param.get_parameter(argv, "-nb", 1));        
	rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1));
	hazardPanel = Param.get_parameter(argv, "-hazardPanel", 1);
        
        betaSim1 = as.numeric(Param.get_parameter_ez(argv, "-betaSim1", 1));
        betaSim2 = as.numeric(Param.get_parameter_ez(argv, "-betaSim2", 1));
        betaSim3 = as.numeric(Param.get_parameter_ez(argv, "-betaSim3", 1));        

        fdv = Param.get_parameter(argv, "-fdv", 1);
        fe = Param.get_parameter(argv, "-fe", 1);
	# ...................................................................................


        
	# ...................................................................................
        # . Check values :
	# ...................................................................................
        stopifnot(nb > 1);
        stopifnot(nTwoRegion >= 0);
        stopifnot(nFourRegion >= 0);

        stopifnot((nTwoRegion > 0) || (nFourRegion >0));  
        stopifnot(nFourRegion >= 0);        
        stopifnot(sigmaTwoRegion >= 0.0);
        stopifnot(sigmaFourRegion >= 0.0);        
        stopifnot((hazardPanel == 'twoRegion')
                  || (hazardPanel == 'fourRegion')
                  || (hazardPanel == 'NONE'));
        
        if (length(grep("\\.DFV$", fdv)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineGenerateSimDataCoxWithCov:\n");
          cat("Output file fdv = ", fdv, " does not have DFV extension.\n");
          stop();
        }

        if (length(grep("\\.DF$", fe)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineGenerateSimDataCoxWithCov:\n");
          cat("Output file fe = ", fe, " does not have DF extension.\n");
          stop();
        }        
	# ...................................................................................


        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       nTwoRegion = nTwoRegion,
                       xTwoRegion = xTwoRegion,
                       sigmaTwoRegion = sigmaTwoRegion,          
                       nFourRegion = nFourRegion,
                       xFourRegionL = xFourRegionL,
                       xFourRegionR = xFourRegionR,          
                       sigmaFourRegion = sigmaFourRegion,          
                       nb = nb,
                       rngSeed = rngSeed,
                       hazardPanel = hazardPanel,
                       betaSim1 = betaSim1,
                       betaSim2 = betaSim2,
                       betaSim3 = betaSim3,
                       fdv = fdv,
                       fe = fe   );

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineGenerateSimDataCoxWithCov.
# =================================================================================================






# =================================================================================================
# . InparamReg.getCommandLineSuperPcCoxUniWithCov : gets the command line arguments for 
# . ---------------------------------------------   run_super_pc_cox_uni_with_cov.r
# .
# . This version allows for an additional external covariate.
# .
# .    inparam = InparamReg.getCommandLineSuperPcCoxUniWithCov(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcCoxUniWithCov <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");

           cat("Description:\n");
           cat("Generates univariate, gene-by-gene Cox proportional hazard statistics\n");
           cat("for the given input data matrix. For each gene computes one of two measures of\n");
           cat("significance, one based on the fitted model score 2 * (l(beta*) - l(0)),\n");
           cat("and the other based on the score for beta = 0, U(0)^2 / J(0). Each of\n");
           cat("these scores should have a Chi-squared distribution with one degree of\n");
           cat("freedom, under the null hypothesis of no dependence of survival time on gene\n");
           cat("expression. Internally does feature selection on the selected score, and optionally.\n");
           cat("outputs the subsetted data matrix.\n");

           cat("This version allows for an additional external covariate.\n");

           cat("\n");           
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_cox_uni                                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n");
           cat("\n");           
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>SCORE AND FEATURE SELECTION PARAMETERS:                                    \n")
           cat("\n");
           cat("  -scoreType loglik : type of score used for computation of significance.    \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'loglik' : use score = 2 * (l(beta*) - l(0)).        \n");
           cat("                      - 'u0'     : use score = U(0)^2 / J(0).                \n");           
           cat("\n");           
           cat("   -methodFs p0 : method of feature selection.                               \n");
           cat("                  Allowed values :	                                     \n");
           cat("                     - 'p0'   : use the P-value threshold p0 for             \n");
           cat("                                selecting genes.                             \n");
           cat("                     - 'mtop' : use the parameter mtop for selecting         \n");
           cat("                                genes.                                       \n");
           cat("\n");                                                                          
           cat("      -p0 0.01  : threshold in P-values from Cox proportional hazards model. \n");
           cat("                  Only genes with p <= p0 are kept after feature selection.  \n")
           cat("                  The p-values are computed using the univariate score test. \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("\n");
           cat("      -typePval ZX : type of the P-value that is to be used for the feature  \n");
           cat("                     selection. Allowed options:                             \n");
           cat("                         model : P-value for overall model fitness.          \n");
           cat("                             X : P-value for gene effects.                   \n");       
           cat("                             Z : P-value for treatment effects.              \n");       
           cat("                            ZX : P-value for interaction effects.            \n");
           cat("\n");           
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");
           cat("       -fp foo.PVAL   : output file for scores and P-values for all genes.   \n");
           cat("                        Extensions can be PVAL, PVAL1, TSV or COXUNI.        \n");           
           cat("\n");                      
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");
           cat("\n");
           cat("  -flagFsOut yes : yes/no; if yes, write the feature-selected data matrix    \n");
           cat("                   to file (as specified by option -fs).                     \n");
           cat("\n");
           cat("       -fo foo.FLAT  : output file for data matrix subsetted to the selected \n");
           cat("                       features. Valid formats, indicated by the extension,  \n");
           cat("                       are: DF, DFV, FLAT.                                   \n");
           cat("                       Required if flagFsOut = 'yes', ignored otherwise.     \n");
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.

	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
	# ...................................................................................
        # . >>Feature selection parameters :
	# ...................................................................................
        scoreType = Param.get_parameter(argv, "-scoreType", 1);    # Flag for feature selection.
        methodFs = Param.get_parameter(argv, "-methodFs", 1);      # Feature selection method.

        p0 = as.numeric(Param.get_parameter(argv, "-p0", 1));      # P-value cutoff.
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.

        typePval = Param.get_parameter(argv, "-typePval", 1);      # P-value to be used for selection.
	# ...................................................................................
        # . >>Output : plots :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);      # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
	# ...................................................................................
        # . >>Output : general statistics and score files :
	# ...................................................................................
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.
        fp = Param.get_parameter(argv, "-fp", 1);    # Output file for P-values.
	# ...................................................................................
        # . >>Output : optional subsetted data matrix.
	# ...................................................................................        
        flagFsOut = Param.get_parameter(argv, "-flagFsOut", 1);     # Flag for output of feature selection.
        stopifnot((flagFsOut == 'yes') || (flagFsOut == 'no'));
        
        if (flagFsOut == 'yes') {
          fo = Param.get_parameter(argv, "-fo", 1);         # Output file for feature selected data matrix.
        } else {
          fo = 'NONE';                                      # Dummy assignment.
        }
	# ...................................................................................


	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (flagFsOut == 'yes') {
          if ((length(grep("\\.DF$", fo, perl = TRUE)) == 0)
              && (length(grep("\\.DFV$", fo, perl = TRUE)) == 0)
              && (length(grep("\\.FLAT$", fo, perl = TRUE)) == 0)) {
            cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");
            cat("The output data matrix file: fo = ", fo, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
            msg = "";
            stop(msg);
          }
        }

        if ((length(grep("\\.PVAL$", fp, perl = TRUE)) == 0)
	    && (length(grep("\\.PVAL1$", fp, perl = TRUE)) == 0)
	    && (length(grep("\\.TSV$", fp, perl = TRUE)) == 0)
	    && (length(grep("\\.COXUNI$", fp, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");
          cat("The output P-values file: fp = ", fp, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: PVAL, PVAL1, TSV, COXUNI.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");
          cat("The output stats file: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: STAT.\n");
          msg = "";
          stop(msg);
        }                
	# ...................................................................................        

        
        
	# ...................................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................................
        stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));

        if (scoreType == 'u0') {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");          
          cat("scoreType = u0 is not yet implemented.\n");
          cat("This should be implemented as part of optimization for performance in cross-validation.\n");
          cat("I am keeping this option as a placeholder!\n");
          cat("(J. Theilhaber. 12-8-2010.\n");

          stop();
        }
        
        stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
        stopifnot((p0 >= 0.0) && (p0 <= 1.0));
        stopifnot(mtop >= 1);

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
        if (is.null(allowedTypePval[[typePval]])) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");
          cat("typePval = ", typePval, " is not valid.\n", sep = "");
          cat("Valid: model, X, Z, ZX.\n", sep = "");
          stop();
        }
	# ......................................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,
                       tTrain = tTrain,
                       fs = fs,          
                       fp = fp,          
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       flagFsOut = flagFsOut,
                       fo = fo,
                       scoreType = scoreType,
                       methodFs = methodFs,          
                       p0 = p0,
                       mtop = mtop,
                       typePval = typePval);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcCoxUniWithCov.
# =================================================================================================





# =================================================================================================
# . InparamReg.getCommandLineSuperPcCoxWithCov : gets the command line arguments for 
# . ------------------------------------------   run_super_pc_cox_with_cov.r
# .
# . This version allows for an additional external covariate.
# .
# .    inparam = InparamReg.getCommandLineSuperPcCoxWithCov(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcCoxWithCov <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_cox_with_cov                                                  \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");           
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat("       -tTest testFlag      : factor defining the test set members           \n");
           cat("                              and all other samples :                        \n");
           cat("                                - test set members are indicated by          \n");
           cat("                                  label = test. There must be at least 2     \n");
           cat("                                  test set members, if any.                  \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the test set.       \n");
           cat("                                - if the value of tTest is NONE, than NO     \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  test set members (no test set is used).    \n");           
           cat("\n");           
           cat(">>SPC PARAMETERS:                                                            \n");
           cat("\n");
           cat("  -scoreType loglik : type of score used for computation of significance.    \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'loglik' : use score = 2 * (l(beta*) - l(0)).        \n");
           cat("                      - 'u0'     : use score = U(0)^2 / J(0).                \n");           
           cat("\n");           
           cat("   -methodFs p0 : method of feature selection. Allowed options :	     \n");
           cat("                     - 'p0'   : use the P-value threshold p0 for             \n");
           cat("                                selecting genes.                             \n");
           cat("                     - 'mtop' : use the parameter mtop for selecting         \n");
           cat("                                genes.                                       \n");
           cat("\n");                                                                          
           cat("      -p0 0.01  : threshold in P-values from Cox proportional hazards model. \n");
           cat("                  Only genes with p <= p0 are kept after feature selection.  \n")
           cat("                  The p-values are computed using the univariate score test. \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("\n");
           cat("      -K 2      : number of principal components to be used as covariates    \n");
           cat("                  in the Cox proportional hazard model for the survival data.\n");
           cat("\n");
           cat("      -typePval ZX : type of the P-value that is to be used for the feature  \n");
           cat("                     selection. Allowed options:                             \n");
           cat("                         model : P-value for overall model fitness.          \n");
           cat("                             X : P-value for gene effects.                   \n");       
           cat("                             Z : P-value for treatment effects.              \n");       
           cat("                            ZX : P-value for interaction effects.            \n");
           cat("\n");
           cat("       -hRC 0.5 : used for binary Z ({0, 1}) external covariate only,        \n");
           cat("                  ignored otherwise. hRC is the threshold for defining       \n");
           cat("                  sensitive patient samples, through the formula :           \n");
           cat("\n");           
           cat("                    log(hRpred(Z = 1)) - log(hRpred(Z = 0)) <= log(hRC)      \n");
           cat("\n");
           cat("                  where hRpred(Z) is the hazard ratio predicted for that     \n");
           cat("                  sample at the given value of Z. Typically hRC < 1 and is   \n");
           cat("                  determined by optimizing on cross-validation results.      \n");
           cat("                  For the samples declared sensitive, a Cox analysis is      \n");
           cat("                  made to compare survival times for the true Z = 1 vs the   \n");
           cat("                  the true Z = 0 smaples.                                    \n");
           cat("                  Note that for non-binary covariates, a dummy value         \n");
           cat("                  must still be given for this parameter (say, -hRC 1).      \n");
           cat("                  We must have hRC >= 0.                                     \n");           
           cat("\n");                                  
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");                      
           cat("       -fo foo.COXPH  : output file for sample-by-sample pcs and log-hazards.\n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("\n");
           cat("       -fv foo.PC     : output file for the principal component vectors.     \n");
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
	tTest = Param.get_parameter(argv, "-tTest", 1);      # Factor defining test sets.                
	# ...................................................................................
        # . >>Super pc parameters :
	# ...................................................................................
        scoreType = Param.get_parameter(argv, "-scoreType", 1);    # Flag for feature selection.        
        methodFs = Param.get_parameter(argv, "-methodFs", 1);      # Feature selection method.

        p0 = as.numeric(Param.get_parameter(argv, "-p0", 1));      # P-value cutoff.
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.

        K = as.numeric(Param.get_parameter(argv, "-K", 1));        # Number of PCs to be used.
        typePval = Param.get_parameter(argv, "-typePval", 1);      # P-value to be used for selection.

        hRC = as.numeric(Param.get_parameter(argv, "-hRC", 1));    # Hazard-ratio cutoff for predictive analysis.
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
        
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.        
        fo = Param.get_parameter(argv, "-fo", 1);    # Output file for sample-by-sample pcs and hazards.
        fv = Param.get_parameter(argv, "-fv", 1);    # Output file for the principal component vectors.
	# ...................................................................................


	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxWithCov:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxWithCov:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (flagPlotWrite == "yes") {
          if (length(grep("\\.PLOT$", fplot, perl = TRUE)) == 0) {
            cat("ERROR: from InparamReg.getCommandLineSuperPcCoxWithCov:\n");
            cat("The output plot file: fplot = ", fplot, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extension: PLOT.\n");
            msg = "";
            stop(msg);
          }
        }
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        if (scoreType == 'u0') {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");          
          cat("scoreType = u0 is not yet implemented.\n");
          cat("This should be implemented as part of optimization for performance in cross-validation.\n");
          cat("I am keeping this option as a placeholder!\n");
          cat("(J. Theilhaber. 12-8-2010.\n");

          stop();
        }
        
        stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
        stopifnot((p0 >= 0.0) && (p0 <= 1.0));
        stopifnot(mtop >= 1);
        stopifnot(K >= 1);

        allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
        if (is.null(allowedTypePval[[typePval]])) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxWithCov:\n");
          cat("typePval = ", typePval, " is not valid.\n", sep = "");
          cat("Valid: model, X, Z, ZX.\n", sep = "");
          stop();
        }

        stopifnot(hRC > 0.0);        
	# ...................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo, fv, fplot);    # Output files.
        bBuf = c(fx, fe);               # Input files.

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxWithCov:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       tTest = tTest,          
                       fs = fs,          
                       fo = fo,
                       fv = fv,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       scoreType = scoreType,          
                       methodFs = methodFs,          
                       p0 = p0,
                       mtop = mtop,
                       K = K,
                       typePval = typePval,
                       hRC = hRC);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcCoxWithCov.
# =================================================================================================




# =================================================================================================
# . InparamReg.getCommandLineSuperPcCoxCvWithCov : gets the command line arguments for 
# . --------------------------------------------   run_super_pc_cox_cv_with_cov.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineSuperPcCoxCvWithCov(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcCoxCvWithCov <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_cox_cv_with_cov                                               \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");                      
           cat("                              >> NOTE: for cross-validation, only binary     \n");
           cat("                                 covariate data {0, 1} is currently allowed. \n");
           cat("                                 This is checked prior to execution of the   \n");
           cat("                                 main cross-validatiom loop.                 \n");           
           cat("\n");                      
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -methodSplit vfoldStrict : how to split the data matrix into training  \n");
           cat("                           and test sets.                                    \n");
           cat("                           Allowed values: given, vfoldStrict                \n");
           cat("                           If value = given, a non-NONE value must be given  \n");
           cat("                           to option -tSplit (see below).                    \n");
           cat("\n");           
           cat("                           >>NOTE: methodSplit = vfold is obsolete, and no   \n");
           cat("                           longer allowed.                                   \n");           
           cat("\n");
           cat("      -ft 0.5            : required if methodSplit = vfold or vfoldStrict.   \n");
           cat("                           Fraction of training set instances                \n");
           cat("                           put into test set at each                         \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -ncv 10            : required if methodSplit = vfold. Number of vfold  \n");
           cat("                           resamplings.                                      \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfold. Initial random   \n");
           cat("                           number generator seed.                            \n");
           cat("\n");                      
           cat("      -tSplit testTrain  : factor defining how to splt the training set      \n");           
           cat("                           into subsets for the cross-validation.            \n");
           cat("                           Required if methodSplit = given, optional and     \n");
           cat("                           ignored otherwise.                                \n");
           cat("                           - In the field indicated by the (non-NONE) value,     \n");           
           cat("                           training set members are indicated by value = train   \n");
           cat("                           and test set by value = test. Values = NONE are       \n");
           cat("                           ignored. Any other values in this field are invalid.  \n");           
           cat("\n");           
           cat("      -parameterScan mtop : which parameter to scan in doing the cross-      \n");
           cat("                            validation. Allowed values: mtop, K              \n")
           cat("\n");
           cat(">>SPC PARAMETERS FOR THE CROSS_VALIDATION:                                   \n");
           cat(">>Parameters required if parameterScan = mtop, optional otherwise :          \n");
           cat("\n");           
           cat("      -K 2      : number of principal components to be used as covariates    \n");
           cat("                  in the Cox proportional hazard model for the survival data.\n");
           cat("                  Required if parameterScan = mtop, optional and ignored     \n");
           cat("                  otherwise.                                                 \n");
           cat("\n");
           cat("      -mtoplo 10  : lower bound on mtop values to be scanned.                 \n");
           cat("      -mtophi 500 : upper bound on mtop values to be scanned.                 \n");
           cat("      -mtopinc 50 : increment in mtop values to be scanned.                   \n");
           cat("\n");
           cat("\n");                      
           cat(">>Parameters required if parameterScan = K, optional otherwise :             \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values). Required if        \n");
           cat("                  parameterScan = K, optional and ignored otherwise.         \n");
           cat("\n");
           cat("      -Klo 1  : lower bound on K values to be scanned.                       \n");
           cat("      -Khi 10 : upper bound on K values to be scanned.                       \n");
           cat("      -Kinc 1 : increment in K values to be scanned.                         \n");           
           cat("\n");
           cat(">>Type of P-value used for feature selection :                               \n");
           cat("\n");
           cat("      -typePval ZX : type of the P-value that is to be used for the feature  \n");
           cat("                     selection. Allowed options:                             \n");
           cat("                         model : P-value for overall model fitness.          \n");
           cat("                             X : P-value for gene effects.                   \n");       
           cat("                             Z : P-value for treatment effects.              \n");       
           cat("                            ZX : P-value for interaction effects.            \n");
           cat("\n");                      
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Cross-validation parameters :
        # . >>How to split the data :
        # .................................................................................
        methodSplit = Param.get_parameter(argv, "-methodSplit", 1);      # Partition for CV loop.
#        stopifnot((methodSplit == 'given')
#                  || (methodSplit == 'vfold')
#                  || (methodSplit == 'vfoldStrict'));

        stopifnot((methodSplit == 'given')
                  || (methodSplit == 'vfoldStrict'));                     # Method vfold now obsolete.
        
        if (methodSplit =='vfold') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = as.numeric(Param.get_parameter(argv, "-ncv", 1));         # Number of resamplings.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.
        } else if (methodSplit =='vfoldStrict') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = 0;                                                        # Dummy.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.                    
        } else if (methodSplit == 'given') {
          ft = 0.0;                                                       # Dummy.
          ncv = 0;                                                        # Dummy.
          rngSeed = 123456;                                               # Dummy.
          tSplit = Param.get_parameter(argv, "-tSplit", 1);               # Factor for split,
        }
        # .................................................................................
        # . >>What to scan in the cross-validation loop :
        # .................................................................................
        parameterScan = Param.get_parameter(argv, "-parameterScan", 1);    # Parameter to be scanned.
        stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));

        if (parameterScan == 'mtop') {
          mtop = 0;                                                  # Dummy for the fixed value.
          K = as.numeric(Param.get_parameter(argv, "-K", 1));        # Number of pcs used.
          mtoplo = as.numeric(Param.get_parameter(argv, "-mtoplo", 1));     # Lower bound.
          mtophi = as.numeric(Param.get_parameter(argv, "-mtophi", 1));     # Upper bound.
          mtopinc = as.numeric(Param.get_parameter(argv, "-mtopinc", 1));   # Increment.
          Klo = 0;                                                    # Dummy.
          Khi = 0;                                                    # Dummy.
          Kinc = 0;                                                   # Dummy.
        } else if (parameterScan == 'K') {                            
          mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff used.
          K = 0;                                                     # Dummy for fixed value.
          mtoplo = 0;                                                # Dummy.
          mtophi = 0;                                                # Dummy.
          mtopinc = 0;                                               # Dummy.
          Klo = as.numeric(Param.get_parameter(argv, "-Klo", 1));    # Lower bound.
          Khi = as.numeric(Param.get_parameter(argv, "-Khi", 1));    # Lower bound.
          Kinc = as.numeric(Param.get_parameter(argv, "-Kinc", 1));  # Increment.          
        }

        typePval = Param.get_parameter(argv, "-typePval", 1);        # P-value to be used for selection.        
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);              # Output file for cv results.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCov:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCov:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }        
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters, and generate arrays
        # . continaing the discrete values :
	# ...................................................................................        
        if (parameterScan == 'mtop') {
          stopifnot(K > 0);          
          stopifnot(mtoplo > 0);
          stopifnot(mtophi >= mtoplo);
          stopifnot(mtopinc > 0);

          amtop = seq(from = mtoplo, to = mtophi, by = mtopinc);
          if (max(amtop) < mtophi) {
            amtop = c(amtop, mtophi);    # Always include mtophi.
          }

          aK = c(0);                     # Dummy.
        } else if (parameterScan == 'K') {
          stopifnot(mtop > 0);          
          stopifnot(Klo > 0);
          stopifnot(Khi >= Klo);
          stopifnot(Kinc > 0);

          amtop = c(0);                  # Dummy.                    

          aK = seq(from = Klo, to = Khi, by = Kinc);
          if (max(aK) < Khi) {
            aK = c(aK, Khi);             # Always include Khi.
          }
        }

        allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
        if (is.null(allowedTypePval[[typePval]])) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCov:\n");
          cat("typePval = ", typePval, " is not valid.\n", sep = "");
          cat("Valid: model, X, Z, ZX.\n", sep = "");
          stop();
        }        
	# ...................................................................................


	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCov:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       cvType = 'loop',
                       fx = fx,
                       fe = fe,
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       methodSplit = methodSplit,
                       ft = ft,
                       ncv = ncv,
                       rngSeed = rngSeed,
                       tSplit = tSplit,
                       parameterScan = parameterScan,
                       K = K,
                       mtoplo = mtoplo,
                       mtophi = mtophi,
                       mtopinc = mtopinc,                    
                       mtop = mtop,
                       amtop = amtop,
                       Klo = Klo,
                       Khi = Khi,
                       Kinc = Kinc,
                       aK = aK,
                       typePval = typePval,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcCoxCvWithCov.
# =================================================================================================





# =================================================================================================
# . InparamReg.getCommandLineSuperPcCoxCvWithCovSingle : gets the command line arguments for 
# . --------------------------------------------------   run_super_pc_cox_cv_with_cov_single.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineSuperPcCoxCvWithCovSingle(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcCoxCvWithCovSingle <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("Generates cross-validation of supervised principal components Cox model with\n");
           cat("external covariate, for a single value of the tuning parameters vector.     \n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_cox_cv_with_cov_single                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");                      
           cat("                              >> NOTE: for cross-validation, only binary     \n");
           cat("                                 covariate data {0, 1} is currently allowed. \n");
           cat("                                 This is checked prior to execution of the   \n");
           cat("                                 main cross-validatiom loop.                 \n");           
           cat("\n");                      
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -methodSplit vfoldStrict : how to split the data matrix into training  \n");
           cat("                           and test sets.                                    \n");
           cat("                           Allowed values: given, vfoldStrict                \n");
           cat("                           If value = given, a non-NONE value must be given  \n");
           cat("                           to option -tSplit (see below).                    \n");
           cat("\n");           
           cat("                           >>NOTE: methodSplit = vfold is obsolete, and no   \n");
           cat("                           longer allowed.                                   \n");           
           cat("\n");
           cat("      -ft 0.5            : required if methodSplit = vfold or vfoldStrict.   \n");
           cat("                           Fraction of training set instances                \n");
           cat("                           put into test set at each                         \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -ncv 10            : required if methodSplit = vfold. Number of vfold  \n");
           cat("                           resamplings.                                      \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfold. Initial random   \n");
           cat("                           number generator seed.                            \n");
           cat("\n");                      
           cat("      -tSplit testTrain  : factor defining how to splt the training set      \n");           
           cat("                           into subsets for the cross-validation.            \n");
           cat("                           Required if methodSplit = given, optional and     \n");
           cat("                           ignored otherwise.                                \n");
           cat("                           - In the field indicated by the (non-NONE) value,     \n");
           cat("                           training set members are indicated by value = train   \n");
           cat("                           and test set by value = test. Values = NONE are       \n");
           cat("                           ignored. Any other values in this field are invalid.  \n");
           cat("\n");           
           cat(">>SPC PARAMETERS FOR THE CROSS_VALIDATION:                                   \n");
           cat("\n");           
           cat("      -K 2      : number of principal components to be used as covariates    \n");
           cat("                  in the Cox proportional hazard model for the survival data.\n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("\n");
           cat("       -hRC 0.5 : used for binary Z ({0, 1}) external covariate only,        \n");
           cat("                  ignored otherwise. hRC is the threshold for defining       \n");
           cat("                  sensitive patient samples, through the formula :           \n");
           cat("\n");           
           cat("                    log(hRpred(Z = 1)) - log(hRpred(Z = 0)) <= log(hRC)      \n");
           cat("\n");
           cat("                  where hRpred(Z) is the hazard ratio predicted for that     \n");
           cat("                  sample at the given value of Z.                            \n");
           cat("                  Note that for non-binary covariates, a dummy value         \n");
           cat("                  must still be given for this parameter (say, -hRC 1).      \n");
           cat("                  We must have hRC >= 0.                                     \n");           
           cat("\n");                                             
           cat("\n");
           cat(">>Type of P-value used for feature selection :                               \n");
           cat("\n");
           cat("      -typePval ZX : type of the P-value that is to be used for the feature  \n");
           cat("                     selection. Allowed options:                             \n");
           cat("                         model : P-value for overall model fitness.          \n");
           cat("                             X : P-value for gene effects.                   \n");       
           cat("                             Z : P-value for treatment effects.              \n");       
           cat("                            ZX : P-value for interaction effects.            \n");
           cat("\n");                      
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");
           cat("       -fo foo.COXCV  : output file for sample-by-sample cross-validated     \n");
           cat("                        log-hazards and sensitivity predictions.             \n");
           cat("                        Extension must be COXCV.                             \n");
           cat("\n");                      
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Cross-validation parameters :
        # . >>How to split the data :
        # .................................................................................
        methodSplit = Param.get_parameter(argv, "-methodSplit", 1);      # Partition for CV loop.

        stopifnot((methodSplit == 'given')
                  || (methodSplit == 'vfoldStrict'));                     # Method vfold now obsolete.
        
        if (methodSplit =='vfold') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = as.numeric(Param.get_parameter(argv, "-ncv", 1));         # Number of resamplings.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.
        } else if (methodSplit =='vfoldStrict') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = 0;                                                        # Dummy.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.                    
        } else if (methodSplit == 'given') {
          ft = 0.0;                                                       # Dummy.
          ncv = 0;                                                        # Dummy.
          rngSeed = 123456;                                               # Dummy.
          tSplit = Param.get_parameter(argv, "-tSplit", 1);               # Factor for split,
        }
        # .................................................................................
        # . >>Parameters for feature selection :
        # .................................................................................
        K = as.numeric(Param.get_parameter(argv, "-K", 1));        # Number of pcs used.
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff used.
        hRC = as.numeric(Param.get_parameter(argv, "-hRC", 1));    # Hazard-ratio cutoff for predictive analysis.
        
        typePval = Param.get_parameter(argv, "-typePval", 1);      # P-value to be used for selection.
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for cv results.
        fo = Param.get_parameter(argv, "-fo", 1);    # Output file for cross-validated log-hazards.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovSingle:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovSingle:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }
        
        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovSingle:\n");
          cat("The output file name for the cross-validation statistics: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: STAT.\n");
          msg = "";
          stop(msg);
        }                
        
        if (length(grep("\\.COXCV$", fo, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovSingle:\n");
          cat("The output file name for the cross-validated log-hazards: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: COXCV.\n");
          msg = "";
          stop(msg);
        }                
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters, and generate arrays
        # . continaing the discrete values :
	# ...................................................................................        
        stopifnot(K > 0);          
        stopifnot(mtop > 0);
        stopifnot(hRC > 0.0);        
        
        allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
        if (is.null(allowedTypePval[[typePval]])) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxUniWithCovSingle:\n");
          cat("typePval = ", typePval, " is not valid.\n", sep = "");
          cat("Valid: model, X, Z, ZX.\n", sep = "");
          stop();
        }        
	# ...................................................................................


	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovSingle:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................


        
	# ...................................................................................
        # . Assignments for compatibility with loop version of cross-validation :
	# ...................................................................................
        parameterScan = 'mtop';
        
        mtoplo = mtop;
        mtophi = mtop;
        mtopinc = 1;
        amtop = c(mtop);

        Klo = K;
        Khi = K;
        Kinc = 1;
        aK = c(K);
	# ...................................................................................        

        
        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       cvType = 'single',
                       fx = fx,
                       fe = fe,
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       methodSplit = methodSplit,
                       ft = ft,
                       ncv = ncv,
                       rngSeed = rngSeed,
                       tSplit = tSplit,
                       parameterScan = parameterScan,
                       K = K,
                       mtoplo = mtoplo,
                       mtophi = mtophi,
                       mtopinc = mtopinc,                    
                       mtop = mtop,
                       amtop = amtop,
                       Klo = Klo,
                       Khi = Khi,
                       Kinc = Kinc,
                       aK = aK,
                       hRC = hRC,
                       typePval = typePval,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs,
                       fo = fo);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcCoxCvWithCovSingle.
# =================================================================================================






# =================================================================================================
# . InparamReg.getCommandLineBasicCoxCvWithCovSingle : gets the command line arguments for 
# . ------------------------------------------------   run_basic_cox_cv_with_cov_single.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineBasicCoxCvWithCovSingle(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineBasicCoxCvWithCovSingle <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("Generates cross-validation of basic multivariate Cox model with external     \n");
           cat("covariate (the covariates are the explicit gene expression values in the     \n");
           cat("input data matrix; no supervised principal components analysis is used here).\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_basic_cox_cv_with_cov                                                  \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat("        -flagQlist yes : yes/no. If yes, read contents of file fQlist (below)\n");
           cat("                         for a list of genes that will be used to reduce the \n");
           cat("                         input data matrix to the overlap between the list   \n");
           cat("                         and the genes present in the data matrix.           \n");
           cat("                         If there is no overlap, and error will be indicated.\n");           
           cat("\n");
           cat("        -fQlist foo.TSV : required if flagQlist = yes, ignored otherwise.    \n");
           cat("                          Contains the list of genes to be used in res-      \n");
           cat("                          tricting the features of the input data matrix.    \n");
           cat("                          Format of file contents is:                        \n");
           cat("                          #QUAL                                              \n");
           cat("                          genename1                                          \n");
           cat("                          genename2                                          \n");
           cat("                          #genename2                                         \n");           
           cat("                          . . .                                              \n");
           cat("                          All gene entries starting with # are ignored.      \n");          
           cat("\n");
           cat("        -flagCenter yes : yes/no. If yes, independently mean-center genes    \n");
           cat("                         in the training set. Values for the non-training set\n");
           cat("                         samples are individually centered using the trai-   \n");
           cat("                         ning set means for the given genes.                 \n");
           cat("\n");           
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");                      
           cat("                              >> NOTE: for cross-validation, only binary     \n");
           cat("                                 covariate data {0, 1} is currently allowed. \n");
           cat("                                 This is checked prior to execution of the   \n");
           cat("                                 main cross-validatiom loop.                 \n");           
           cat("\n");                      
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -methodSplit vfoldStrict : how to split the data matrix into training  \n");
           cat("                           and test sets.                                    \n");
           cat("                           Allowed values: given, vfoldStrict                \n");
           cat("                           If value = given, a non-NONE value must be given  \n");
           cat("                           to option -tSplit (see below).                    \n");
           cat("\n");           
           cat("                           >>NOTE: methodSplit = vfold is obsolete, and no   \n");
           cat("                           longer allowed.                                   \n");           
           cat("\n");
           cat("      -ft 0.5            : required if methodSplit = vfold or vfoldStrict.   \n");
           cat("                           Fraction of training set instances                \n");
           cat("                           put into test set at each                         \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -ncv 10            : required if methodSplit = vfold. Number of vfold  \n");
           cat("                           resamplings.                                      \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfold. Initial random   \n");
           cat("                           number generator seed.                            \n");
           cat("\n");                      
           cat("      -tSplit testTrain  : factor defining how to splt the training set      \n");           
           cat("                           into subsets for the cross-validation.            \n");
           cat("                           Required if methodSplit = given, optional and     \n");
           cat("                           ignored otherwise.                                \n");
           cat("                           - In the field indicated by the (non-NONE) value,     \n");
           cat("                           training set members are indicated by value = train   \n");
           cat("                           and test set by value = test. Values = NONE are       \n");
           cat("                           ignored. Any other values in this field are invalid.  \n");
           cat("\n");           
           cat(">>CUTOFFS:                                                                   \n");
           cat("\n");           
           cat("       -hRC 0.5 : used for binary Z ({0, 1}) external covariate only,        \n");
           cat("                  ignored otherwise. hRC is the threshold for defining       \n");
           cat("                  sensitive patient samples, through the formula :           \n");
           cat("\n");           
           cat("                    log(hRpred(Z = 1)) - log(hRpred(Z = 0)) <= log(hRC)      \n");
           cat("\n");
           cat("                  where hRpred(Z) is the hazard ratio predicted for that     \n");
           cat("                  sample at the given value of Z.                            \n");
           cat("                  Note that for non-binary covariates, a dummy value         \n");
           cat("                  must still be given for this parameter (say, -hRC 1).      \n");
           cat("                  We must have hRC >= 0.                                     \n");           
           cat("\n");                                             
           cat("\n");
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");
           cat("       -fo foo.COXCV  : output file for sample-by-sample cross-validated     \n");
           cat("                        log-hazards and sensitivity predictions.             \n");
           cat("                        Extension must be COXCV.                             \n");
           cat("\n");                      
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	flagQlist = Param.get_parameter(argv, "-flagQlist", 1);    # Will we restrict to a given gene list?

        if ((flagQlist != 'yes') && (flagQlist != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovSingle:\n");
          cat("flagQlist = ", flagQlist, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }

        if (flagQlist == 'yes') {
          fq = Param.get_parameter(argv, "-fq", 1);          # The file containing the gene list.
        } else {
	  fq = 'NONE';                                       # Dummy.
	}

	flagCenter = Param.get_parameter(argv, "-flagCenter", 1);    # Mean center values for genes?

        if ((flagCenter != 'yes') && (flagCenter != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovSingle:\n");
          cat("flagCenter = ", flagCenter, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }        
	# ...................................................................................                
        # . >>Survival data indicators :
	# ...................................................................................        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Cross-validation parameters :
        # . >>How to split the data :
        # .................................................................................
        methodSplit = Param.get_parameter(argv, "-methodSplit", 1);      # Partition for CV loop.

        stopifnot((methodSplit == 'given')
                  || (methodSplit == 'vfoldStrict'));                     # Method vfold now obsolete.
        
        if (methodSplit =='vfold') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = as.numeric(Param.get_parameter(argv, "-ncv", 1));         # Number of resamplings.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.
        } else if (methodSplit =='vfoldStrict') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = 0;                                                        # Dummy.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.                    
        } else if (methodSplit == 'given') {
          ft = 0.0;                                                       # Dummy.
          ncv = 0;                                                        # Dummy.
          rngSeed = 123456;                                               # Dummy.
          tSplit = Param.get_parameter(argv, "-tSplit", 1);               # Factor for split,
        }
        # .................................................................................
        # . >>Cutoffs :
        # .................................................................................
        hRC = as.numeric(Param.get_parameter(argv, "-hRC", 1));    # Hazard-ratio cutoff for predictive analysis.
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for cv results.
        fo = Param.get_parameter(argv, "-fo", 1);    # Output file for cross-validated log-hazards.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovSingle:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovSingle:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }
        
        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovSingle:\n");
          cat("The output file name for the cross-validation statistics: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: STAT.\n");
          msg = "";
          stop(msg);
        }                
        
        if (length(grep("\\.COXCV$", fo, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovSingle:\n");
          cat("The output file name for the cross-validated log-hazards: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: COXCV.\n");
          msg = "";
          stop(msg);
        }                
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters, and generate arrays
        # . continaing the discrete values :
	# ...................................................................................        
        stopifnot(hRC > 0.0);        
	# ...................................................................................


	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovSingle:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................


        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       cvType = 'single',
                       fx = fx,
                       fe = fe,
                       flagQlist = flagQlist,
                       fq = fq,
                       flagCenter = flagCenter,          
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       methodSplit = methodSplit,
                       ft = ft,
                       ncv = ncv,
                       rngSeed = rngSeed,
                       tSplit = tSplit,
                       hRC = hRC,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs,
                       fo = fo);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineBasicCoxCvWithCovSingle.
# =================================================================================================





# =================================================================================================
# . InparamReg.getCommandLineBasicCoxWithCov : gets the command line arguments for 
# . ----------------------------------------   run_basic_cox_with_cov.r
# .
# . This version allows for an additional external covariate.
# .
# .    inparam = InparamReg.getCommandLineBasicCoxWithCov(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineBasicCoxWithCov <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_basic_cox_with_cov                                                           \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");
           cat("\n");
           cat("        -flagQlist yes : yes/no. If yes, read contents of file fQlist (below)\n");
           cat("                         for a list of genes that will be used to reduce the \n");
           cat("                         input data matrix to the overlap between the list   \n");
           cat("                         and the genes present in the data matrix.           \n");
           cat("                         If there is no overlap, and error will be indicated.\n");           
           cat("\n");
           cat("        -fq foo.TSV    : required if flagQlist = yes, ignored otherwise.     \n");
           cat("                         Contains the list of genes to be used in res-       \n");
           cat("                         tricting the features of the input data matrix.     \n");
           cat("                         Format of file contents is:                         \n");
           cat("                         #QUAL                                               \n");
           cat("                         genename1                                           \n");
           cat("                         genename2                                           \n");
           cat("                         #genename2                                          \n");           
           cat("                         . . .                                               \n");
           cat("                         All gene entries starting with # are ignored.       \n");          
           cat("\n");
           cat("        -flagCenter yes : yes/no. If yes, independently mean-center genes    \n");
           cat("                         in the training set. Values for the non-training set\n");
           cat("                         samples are individually centered using the trai-   \n");
           cat("                         ning set means for the given genes.                 \n");
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");           
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat("       -tTest testFlag      : factor defining the test set members           \n");
           cat("                              and all other samples :                        \n");
           cat("                                - test set members are indicated by          \n");
           cat("                                  label = test. There must be at least 2     \n");
           cat("                                  test set members, if any.                  \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the test set.       \n");
           cat("                                - if the value of tTest is NONE, than NO     \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  test set members (no test set is used).    \n");           
           cat("\n");           
           cat(">>CUTOFFS:                                                                   \n");
           cat("\n");
           cat("       -hRC 0.5 : used for binary Z ({0, 1}) external covariate only,        \n");
           cat("                  ignored otherwise. hRC is the threshold for defining       \n");
           cat("                  sensitive patient samples, through the formula :           \n");
           cat("\n");           
           cat("                    log(hRpred(Z = 1)) - log(hRpred(Z = 0)) <= log(hRC)      \n");
           cat("\n");
           cat("                  where hRpred(Z) is the hazard ratio predicted for that     \n");
           cat("                  sample at the given value of Z. Typically hRC < 1 and is   \n");
           cat("                  determined by optimizing on cross-validation results.      \n");
           cat("                  For the samples declared sensitive, a Cox analysis is      \n");
           cat("                  made to compare survival times for the true Z = 1 vs the   \n");
           cat("                  the true Z = 0 smaples.                                    \n");
           cat("                  Note that for non-binary covariates, a dummy value         \n");
           cat("                  must still be given for this parameter (say, -hRC 1).      \n");
           cat("                  We must have hRC >= 0.                                     \n");           
           cat("\n");                                  
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");                      
           cat("       -fo foo.COXPH  : output file for sample-by-sample pcs and log-hazards.\n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("\n");
           cat("       -fqOut foo-QLIST.TSV : output file for genes actually used, and the   \n");
           cat("                              corresponding offsets that were subtracted     \n");
           cat("                              from the raw data matrix values.               \n");
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	flagQlist = Param.get_parameter(argv, "-flagQlist", 1);    # Will we restrict to a given gene list?

        if ((flagQlist != 'yes') && (flagQlist != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxWithCov:\n");
          cat("flagQlist = ", flagQlist, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }

        if (flagQlist == 'yes') {
          fq = Param.get_parameter(argv, "-fq", 1);          # The file containing the gene list.
        } else {
	  fq = 'NONE';                                       # Dummy.
	}

	flagCenter = Param.get_parameter(argv, "-flagCenter", 1);    # Mean center values for genes

        if ((flagCenter != 'yes') && (flagCenter != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxWithCov:\n");
          cat("flagCenter = ", flagCenter, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................                
        # . >>Survival data indicators :        
	# ...................................................................................        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining training set.
	tTest = Param.get_parameter(argv, "-tTest", 1);      # Factor defining test sets.        
	# ...................................................................................
        # . >>Cutoffs :
	# ...................................................................................
        hRC = as.numeric(Param.get_parameter(argv, "-hRC", 1));    # Hazard-ratio cutoff for predictive analysis.
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
        
        fs = Param.get_parameter(argv, "-fs", 1);          # Output file for summary statistics.        
        fo = Param.get_parameter(argv, "-fo", 1);          # Output file for sample-by-sample hazards.
        fqOut = Param.get_parameter(argv, "-fqOut", 1);    # Output file for genes and offsets used.
	# ...................................................................................


	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxWithCov:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxWithCov:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (flagPlotWrite == "yes") {
          if (length(grep("\\.PLOT$", fplot, perl = TRUE)) == 0) {
            cat("ERROR: from InparamReg.getCommandLineBasicCoxWithCov:\n");
            cat("The output plot file: fplot = ", fplot, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extension: PLOT.\n");
            msg = "";
            stop(msg);
          }
        }
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot(hRC > 0.0);        
	# ...................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo, fqOut, fplot);    # Output files.
        bBuf = c(fx, fe);                  # Input files.

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxWithCov:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       flagQlist = flagQlist,
                       fq = fq,
                       flagCenter = flagCenter,
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       tTest = tTest,          
                       fs = fs,          
                       fo = fo,
                       fqOut = fqOut,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       hRC = hRC);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineBasicCoxWithCov.
# =================================================================================================





# =================================================================================================
# . InparamReg.getCommandLineRocOnCoxph : gets the command line arguments for 
# . -----------------------------------   run_roc_on_coxph.r
# .
# . This version allows for an additional external covariate.
# .
# .    inparam = InparamReg.getCommandLineRocOnCoxph(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineRocOnCoxph <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("Does post-processing of COXPH or COXCV files generated by modeling or cross-validation  \n");
           cat("programs (see list below), on data with a binary {0, 1} external covariate.             \n");
           cat("Computes the hazard-ratio and sensitivity as a function of a threshold on the           \n");
           cat("predicted differential log-hazard ratio.                                                \n");
           cat("Plots the resulting ROC curves, and writes results to file in an augmented              \n");
           cat("COXPH format.                                                                           \n");
           cat("General command line syntax:\n");           
           cat("--------------------------------------------------------------------------------------  \n");
           cat("  run_roc_on_coxph                                                                      \n");
           cat("\n");
           cat(">>INPUT FILE:                                                                           \n");
           cat("\n");           
           cat("      -fx foo.COXPH : input file. Allowed extensions: COXPH, COXCV                      \n");
           cat("                      Must result from computation with :                               \n")
           cat("                        run_basic_cox_with_cov            COXPH                         \n");
           cat("                        run_super_pc_cox_with_cov         COXPH                         \n");
           cat("                      with a binary external covariate {0, 1}.                          \n");
           cat("\n");
           cat(">>FILTERS:                                                                              \n");
           cat("               -flagFilter no : yes/no; if yes, filter for either all-training or all-  \n");
           cat("                                test-set instances before doing the analysis.           \n");
           cat("                                A value of yes is valid only for COXPH files.           \n");
           cat("\n");
           cat("               -tFilter ttFoo : factor specifying the input file column which contains  \n");
           cat("                                the train/test entries.                                 \n");
           cat("                                Required if flagFilter = yes, ignored otherwise.        \n");
           cat("\n");
           cat("           -filterValue test  : train/test; specifies whether to use the training set   \n");
           cat("                                or the test set instances.                              \n");
           cat("                                If value = train, then only rows labeled with the word  \n");
           cat("                                train are used, if value = test, then only rows labeled \n");
           cat("                                with the word test are used. All other rows are         \n");
           cat("                                ignored.                                                \n");
           cat("                                Required if flagFilter = yes, ignored otherwise.        \n");
           cat("\n");           
           cat(">>SURVIVAL DATA SPECIFICATION:                                                          \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental                \n");
           cat("                                design file.                                            \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental             \n");
           cat("                                design file.                                            \n"); 
           cat("\n");
           cat(">>CUTOFFS AND BOOTSTRAP PARAMETERS FOR PREDICTIVE ESTIMATION :                          \n");
           cat("\n");
           cat("      -flaghRC internal : internal/external; mode of thresholding for defining          \n");
           cat("                          sensitive subsets.                                            \n");
           cat("           Description:                                                                        \n");
           cat("\n");
           cat("           internal : hRC is optimized independently for each sample. This option is to be     \n");
           cat("                      used on cross-validated log-hazard-ratios in the process of optimizing   \n");
           cat("                      tuning parameters with a training set.                                   \n");
           cat("           external : hRC = hRCExt is imposed externally. This is to be used in the validation \n");
           cat("                      phase, with the log-hazard-ratios determined by prediction with the      \n");
           cat("                      independently trained model.                                             \n");
           cat("\n");           
           cat("    -hRCExt 0.5 : externally defined cutoff used for binary Z ({0, 1})       \n");
           cat("                  external covariate only. Used in flaghRC = external,       \n");
           cat("                  ignored otherwise.                                         \n");           
           cat("                  hRCExt defines sensitive patient through the formula :     \n");
           cat("\n");           
           cat("                  log(hRpred(Z = 1)) - log(hRpred(Z = 0)) <= log(hRCExt)     \n");
           cat("\n");
           cat("\n");           
           cat("      -flagBoot yes : yes/no; generate bootstrap statistics as well?         \n");
           cat("\n");
           cat("         -nboot 100 : number of bootstrap resamplings; must be >= 5.         \n");
           cat("                      Required if flagBoot = yes, ignored otherwise.         \n");
           cat("\n");
           cat("    -rngSeed 123456 : random number seed for bootstrap resampling.           \n");
           cat("                      Required if flagBoot = yes, ignored otherwise.         \n");           
           cat("\n");
           cat("    -resamplingType bootstrap : type of resampling to be done.               \n");
           cat("                                Required if flagBoot = yes, ignored          \n");
           cat("                                otherwise.                                   \n");
           cat("         ................................................................... \n");
           cat("         Description:                                                        \n");
           cat("\n");           
           cat("         1) bootstrap :   all samples are resampled with replacement.        \n");
           cat("                          This is typically used to establish confidence     \n");
           cat("                          intervals on the estimated quantities.             \n");
           cat("\n");
           cat(".        2) permutation : the gene-expression expression attributes          \n");
           cat("                          (log-hazards) are randomly shuffled with respect   \n");
           cat("                          to the (time, censoring, covariate) triplets.      \n");
           cat("                          This is typically used to compute a P-value        \n");
           cat("                          for the significance of the estimates on the       \n");
           cat("                          actual data set.                                   \n");
           cat("         ................................................................... \n");           
           cat("\n");
           cat(">>PERMUTATION PARAMETERS FOR PREDICTIVE ESTIMATION :                         \n");
           cat("\n");
           cat("      -flagPermProg yes : yes/no; generate permutations for prognostic       \n");
           cat("                          estimates?                                         \n");           
           cat("\n");
           cat("       -npermProg 1000 : number of permutations for resampling of            \n");
           cat("                         prognostic estimates; must be >= 5.                 \n");
           cat("                         Required if flagPermProg = yes, ignored otherwise.  \n");
           cat("\n");
           cat("    -rngSeedProg 123456 : random number seed for permutation resampling of   \n");
           cat("                          prognostic estimates.                              \n");
           cat("                          Required if flagBoot = yes, ignored otherwise.     \n");           
           cat("\n");           
           cat("\n");
           cat(">>PLOT AND OUTPUT PARAMETERS :                                               \n");
           cat("\n");           
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");                      
           cat("     -fo foo-NEW.COXPH : output file containing the original fields of the   \n");
           cat("                         input COXPH file, augmented by log-hazard ratio     \n");
           cat("                         between covariate arms and sensitivity at the given \n");
           cat("                         differential log-hazard-ratio.                      \n");
           cat("                         Allowed extensions: COXPH                           \n");
           cat("\n");
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);            # Input COXPH file.
	# ...................................................................................
        # . >>Filter on test or training set :
	# ...................................................................................
	flagFilter = Param.get_parameter(argv, "-flagFilter", 1);     # Flag for filtering.

        stopifnot((flagFilter == 'no') || (flagFilter == 'yes'));

        if (flagFilter == 'yes') {
          tFilter = Param.get_parameter(argv, "-tFilter", 1);              # Factor for filtering.
          filterValue = Param.get_parameter(argv, "-filterValue", 1);      # Value for filtering.
        } else {
          tFilter = 'NONE';          # Dummy.
          filterValue = 'NONE';      # Dummy.
        }
	# ...................................................................................                
        # . >>Survival data indicators :        
	# ...................................................................................        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	# ...................................................................................
        # . >>Threshold for sensitive set :
	# ...................................................................................
        flaghRC = Param.get_parameter(argv, "-flaghRC", 1);            # Threshold mode.
        stopifnot((flaghRC == 'internal') || (flaghRC == 'external'));

        if (flaghRC == 'external') {
          hRCExt = as.numeric(Param.get_parameter(argv, "-hRCExt", 1));  # Ext. differential hazard-ratio cutoff.
        } else {
          hRCExt = 1.0;     # Dummy.
        }
	# ...................................................................................
        # . >>Bootstrap or permutation parameters for resampling of predictive estimates :
	# ...................................................................................
        flagBoot = Param.get_parameter(argv, "-flagBoot", 1);          # Generate bootstrap statistics?
        stopifnot((flagBoot == 'yes') || (flagBoot == 'no'));

        if (flagBoot == 'yes') {
          nboot = as.numeric(Param.get_parameter(argv, "-nboot", 1));         # Number of bootstrap resamplings.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1));     # Random number seed.
          resamplingType = Param.get_parameter(argv, "-resamplingType", 1);   # Resampling type.
          stopifnot((resamplingType == 'bootstrap')
                    || (resamplingType == 'permutation'));          
        } else {
          nboot = 1;                 # Dummy.
          rngSeed = 1;               # Dummy.
          resamplingType = 'NONE';   # Dummy.
        }
	# ...................................................................................
        # . >>Permutation parameters for resampling of prognostic estimates :
	# ...................................................................................
        flagPermProg = Param.get_parameter(argv, "-flagPermProg", 1);          # Generate bootstrap statistics?
        stopifnot((flagPermProg == 'yes') || (flagPermProg == 'no'));

        if (flagPermProg == 'yes') {
          npermProg = as.numeric(Param.get_parameter(argv, "-npermProg", 1));     # Number of permutations.
          rngSeedProg = as.numeric(Param.get_parameter(argv, "-rngSeedProg", 1)); # Random number seed.
        } else {
          npermProg = 1;             # Dummy.
          rngSeedProg = 1;           # Dummy.
        }        
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }

        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.        
        fo = Param.get_parameter(argv, "-fo", 1);    # Output file in augmented COXPH format.
	# ...................................................................................


        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        ex = File.getExt(fx);         # Input file extension.
        eo = File.getExt(fo);         # Output file extension.
        
        if ((ex != "COXPH") && (ex != "COXCV")) {
          cat("ERROR: from InparamReg.getCommandLineRocOnCoxph:\n");
          cat("The input file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: COXPH, COXCV.\n");
          msg = "";
          stop(msg);
        }

        if ((eo != "COXPH") && (eo != "COXCV")) {        
          cat("ERROR: from InparamReg.getCommandLineRocOnCoxph:\n");
          cat("The output file: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: COXPH.\n");
          msg = "";
          stop(msg);
        }
        
        if (flagPlotWrite == "yes") {
          if (length(grep("\\.PLOT$", fplot, perl = TRUE)) == 0) {
            cat("ERROR: from InparamReg.getCommandLineRocOnCoxph:\n");
            cat("The output plot file: fplot = ", fplot, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extension: PLOT.\n");
            msg = "";
            stop(msg);
          }
        }
	# ...................................................................................        


        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot(hRCExt > 0.0);

        if (flagBoot == 'yes') {
          if (nboot < 5) {
            cat("ERROR: from InparamReg.getCommandLineRocOnCoxph:\n");
            cat("nboot = ", nboot, " is less than 5. Valid : nboot >= 5.\n", sep = "");
            stop();
          }
        }

        if (flagPermProg == 'yes') {
          if (npermProg < 5) {
            cat("ERROR: from InparamReg.getCommandLineRocOnCoxph:\n");
            cat("npermProg = ", npermProg, " is less than 5. Valid : nboot >= 5.\n", sep = "");
            stop();
          }
        }

        if (flagFilter == 'yes') {
          if (ex != 'COXPH') {
            cat("ERROR: from InparamReg.getCommandLineRocOnCoxph:\n");
            cat("You chose flagFilter = ",
                flagFilter, " but the input file is not of the right type.\n", sep = '');
            cat("The input file has extension ", ex, " but only COXPH is compatible with\n", sep = ''):
            cat("a filter on test or training set.\n");
            stop();
          }

          if ((filterValue != 'train') && (filterValue != 'test')) {
            cat("ERROR: from InparamReg.getCommandLineRocOnCoxph:\n");
            cat("filterValue = ", filterValue, " is not valid.\n");
            cat("Valid: train, test.\n");
            stop();
          }
        }
	# ...................................................................................
        
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fo, fs, fplot);    # Output files.
        bBuf = c(fx);               # Input files.

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineRocOnCoxph:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       flagFilter = flagFilter,
                       tFilter = tFilter,
                       filterValue = filterValue,
                       tTime = tTime,
                       tStatus = tStatus,
                       flaghRC = flaghRC,
                       hRCExt = hRCExt,
                       flagBoot = flagBoot,
                       nboot = nboot,
                       rngSeed = rngSeed,
                       resamplingType = resamplingType,
                       flagPermProg = flagPermProg,
                       npermProg = npermProg,
                       rngSeedProg = rngSeedProg,
                       fo = fo,
                       fs = fs,          
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineRocOnCoxph.
# =================================================================================================





# =================================================================================================
# . InparamReg.getCommandLineCombScreenComputePval : gets the command line arguments for 
# . ----------------------------------------------   run_comb_screen_compute_pval.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineCombScreenComputePval(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineCombScreenComputePval <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("Computes P-values for Zalicus combinatory screen data matrix,                \n");
           cat("using the self-cross data set to generate reference distributions.           \n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_comb_screen_compute_pval                                               \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fC foo-comb.FLAT : file containing the combinatorial score data       \n");
           cat("                          for which we will generate P-values.               \n");
           cat("                          Allowed extension: FLAT                            \n");
           cat("\n");
           cat("      -fS foo-self.FLAT : file containing the self-cross data, from which    \n");
           cat("                          the reference distributionsa will be generated.    \n");
           cat("\n");
           cat(">>PROCESSING PARAMETERS:                                                     \n");
           cat("\n");                      
           cat("      -typeCombScore ADD_Volume : type of synergy score that will be         \n");
           cat("                                  extracted and analyzed to generate the P-  \n");
           cat("                                  values.                                    \n");
           cat("                                  Allowed values :                           \n");
           cat("                                     Synergy_Score, HSA_Volume, Best_CI,     \n");
           cat("                                     ADD_Volume.                             \n");
           cat("\n");
           cat("      -flagNaZero no : yes/no : if yes, replace all NAs in output array by   \n");
           cat("                                0s for score values, and 1s for P-values.    \n");
           cat("                                If no, keep NAs in output file.              \n");
           cat("\n");
           cat(">>OUTPUT FILES:                                                              \n");
           cat("\n");                                 
           cat("      -fR foo.RATIO  : output file for scores of the selected type, and      \n");
           cat("                       the corresponding P-values. A Gecko RATIO-format      \n");
           cat("                       is generated, with the scores \"sneaked-in\" as       \n");
           cat("                       log2Ratio values (this file can then be uploaded and  \n");
           cat("                       processed in Gecko).                                  \n");
           cat("                       Allowed extension : RATIO.                            \n");
           cat("\n");           
           cat("      -fL foo.LABEL  : output LABEL file, companion to RATIO file.           \n");
           cat("                       Allowed extension : LABEL.                            \n");
           cat("\n");
           cat("---------------------------------------------------------------------------- \n");
           cat(">> NOTE on origin of the input files :                                       \n");
           cat("   The input FLAT files are themselves generated by parsing and formating    \n");
           cat("   of the \"raw\" Chalice output file, using the Perl program :              \n");
           cat("   processChaliceIntoDataMatrix.pl                                           \n");
           cat("\n");           
           cat(" * A command line example is given below :                                   \n");
           cat("\n");
           cat("   processChaliceIntoDataMatrix.pl                                           \n");
           cat("       -x BSI201-zalicus-30cellLines-11-30-2011.TSV                          \n");
           cat("       -c SAR240550                                                          \n");
           cat("       -m GrowthInhibition                                                   \n");
           cat("       -t Best_CI+HSA_Volume+Synergy_Score+ADD_Volume                        \n");
           cat("       -n no                                                                 \n");
           cat("       -o  BSI201-zalicus-30cellLines-11-30-2011-combScores-withNA-ADD.FLAT  \n");
           cat("       -s  BSI201-zalicus-30cellLines-11-30-2011-selfCross-withNA-ADD.FLAT   \n");
           cat("\n");
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :        
	# ...................................................................................
	fC = Param.get_parameter(argv, "-fC", 1);    # Combination scores data.
	fS = Param.get_parameter(argv, "-fS", 1);    # Self-cross data.
	# ...................................................................................
        # . >>Processing parameters :
	# ...................................................................................
	typeCombScore = Param.get_parameter(argv, "-typeCombScore", 1);      # Type of combination score.
	flagNaZero = Param.get_parameter(argv, "-flagNaZero", 1);            # Convert NAs to 0s?
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
	fR = Param.get_parameter(argv, "-fR", 1);    # Output RATIO file.
	fL = Param.get_parameter(argv, "-fL", 1);    # Companion output LABEL file.
	# ...................................................................................


	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if (length(grep("\\.FLAT$", fC, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCombScreenComputePval:\n");
          cat("The input combination scores file: fC = ", fC, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.FLAT$", fS, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCombScreenComputePval:\n");
          cat("The input self-cross file: fS = ", fS, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: FLAT.\n");
          msg = "";
          stop(msg);
        }
        
        if (length(grep("\\.RATIO$", fR, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCombScreenComputePval:\n");
          cat("The output RATIO file: fR = ", fR, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: RATIO.\n");
          msg = "";
          stop(msg);
        }
        
        if (length(grep("\\.LABEL$", fL, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCombScreenComputePval:\n");
          cat("The output LABEL file: fL = ", fL, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: LABEL.\n");
          msg = "";
          stop(msg);
        }        
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the processing parameters :
	# ...................................................................................
        allowedCombScore = list('Synergy_Score' = 1,
                                'HSA_Volume' = 1,
                                'Best_CI' = 1,
                                'ADD_Volume' = 1);
   
        if (is.null(allowedCombScore[[typeCombScore]])) {
          cat("ERROR: from InparamReg.getCommandLineCombScreenComputePval:\n");
          cat("typeCombScore = ", typeCombScore, " is not valid.\n", sep = "");
          cat("Valid : ", names(allowedCombScore), "\n");
          stop();
        }
        
        stopifnot((flagNaZero == 'yes') || (flagNaZero == 'no'));
	# ...................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fR, fL);            # Output files.
        bBuf = c(fC, fS);            # Input files.

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineCombScreenComputePval:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................


        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fC = fC,
                       fS = fS,
                       typeCombScore = typeCombScore,
                       flagNaZero = flagNaZero,
                       fR = fR,          
                       fL = fL );

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineCombScreenComputePval.
# =================================================================================================







# =================================================================================================
# . InparamReg.getCommandLineSuperPcRegressCvSingle : gets the command line arguments for 
# . -----------------------------------------------   run_super_pc_regress_cv_single.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineSuperPcRegressCvSingle(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcRegressCvSingle <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           
           cat("Description:\n");
           cat("Performs cross-validation of a multivariate regression model\n");
           cat("of a given output variable on the gene expression values\n");
           cat("provided in an input data matrix. The model: \n");           
           cat("i) performs feature selection on genes using a univariate regression model,\n");
           cat("ii) then generates a multivariate regression model for the output variable,\n");
           cat("using the principal components the reduced feature set as covariates.\n");

           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_regress_cv_single                                             \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>OUTPUT VARIABLE AND TRAIN/TEST SPECIFICATION:                              \n");
           cat("\n");
           cat("       -tY tumorToControl     : factor for output variable in experimental   \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");
           cat("\n");
           cat(">>MODEL TYPE:                                                                \n")
           cat("\n");           
           cat("   -modelType lm : regerssion model to be used.                              \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'lm'     : linear model.                             \n");
           cat("                      - 'logistic' : logistic distribution.                  \n");           
           cat("\n");                      
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -methodSplit vfoldStrict : how to split the data matrix into training  \n");
           cat("                           and test sets.                                    \n");
           cat("                           Allowed values: given, vfoldStrict.               \n");
           cat("                           If value = given, a non-NONE value must be given  \n");
           cat("                           to option -tSplit (see below).                    \n");
           cat("\n");
           cat("      -ft 0.5            : required if methodSplit = vfold. Fraction of      \n");
           cat("                           training set instances put into test set at each  \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -ncv 10            : required if methodSplit = vfold. Number of vfold  \n");
           cat("                           resamplings.                                      \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfold. Initial random   \n");
           cat("                           number generator seed.                            \n");
           cat("\n");                      
           cat("      -tSplit testTrain  : factor defining how to split the training set     \n");           
           cat("                           into subsets for the cross-validation.            \n");
           cat("                           Required if methodSplit = given, optional and     \n");
           cat("                           ignored otherwise.                                \n");
           cat("                           - In the field indicated by the (non-NONE) value,     \n");           
           cat("                           training set members are indicated by value = train   \n");
           cat("                           and test set by value = test. Values = NONE are       \n");
           cat("                           ignored. Any other values in this field are invalid.  \n");           
           cat("\n");           
           cat(">>SPC PARAMETERS FOR THE CROSS_VALIDATION:                                   \n");
           cat("\n");           
           cat("      -K 2      : number of principal components to be used as covariates    \n");
           cat("                  in the regression  model for the output variable.          \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant regressionscores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("\n");           
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-regress', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("\n");
           cat("       -fo foo.TSV    : output file for sample-by-sample cross-validated     \n");
           cat("                        predictions, joined to complete experimental design. \n");
           cat("\n");                      
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	tY = Param.get_parameter(argv, "-tY", 1);            # Factor for output variable.               
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Model type :
        # .................................................................................
        modelType = Param.get_parameter(argv, "-modelType", 1);    # Flag for feature selection.
        stopifnot((modelType == 'lm') || (modelType == 'logistic'));
        # .................................................................................
        # . Cross-validation parameters :
        # . >>How to split the data :
        # .................................................................................
        methodSplit = Param.get_parameter(argv, "-methodSplit", 1);      # Partition for CV loop.
        stopifnot((methodSplit == 'given')
                  || (methodSplit == 'vfoldStrict'));                    # N.B. I suppressed vfold option.

        if (methodSplit =='vfold') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = as.numeric(Param.get_parameter(argv, "-ncv", 1));         # Number of resamplings.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.
        } else if (methodSplit =='vfoldStrict') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = 0;                                                        # Dummy.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.                              
        } else if (methodSplit == 'given') {
          ft = 0.0;                                                       # Dummy.
          ncv = 0;                                                        # Dummy.
          rngSeed = 123456;                                               # Dummy.
          tSplit = Param.get_parameter(argv, "-tSplit", 1);               # Factor for split,
        }
        # .................................................................................
        # . >>What to scan in the cross-validation loop :
        # .................................................................................
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff used.        
        K = as.numeric(Param.get_parameter(argv, "-K", 1));        # Number of pcs used.
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);              # Output file for cv results.
        fo = Param.get_parameter(argv, "-fo", 1);              # Output file for cross-validated predictions.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressCvSingle:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressCvSingle:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }        
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters, and generate arrays
        # . continaing the discrete values :
	# ...................................................................................        
        stopifnot(K > 0);          
        stopifnot(mtop > 0);          
	# ...................................................................................


	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcRegressCvSingle:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................


        
	# ...................................................................................
        # . Assignments for compatibility with loop version of cross-validation :
	# ...................................................................................
        parameterScan = 'mtop';
        
        mtoplo = mtop;
        mtophi = mtop;
        mtopinc = 1;
        amtop = c(mtop);

        Klo = K;
        Khi = K;
        Kinc = 1;
        aK = c(K);
	# ...................................................................................        

        
        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       cvType = 'single',
                       fx = fx,
                       fe = fe,
                       tY = tY,          
                       tTrain = tTrain,
                       modelType = modelType,          
                       methodSplit = methodSplit,
                       ft = ft,
                       ncv = ncv,
                       rngSeed = rngSeed,
                       tSplit = tSplit,
                       parameterScan = parameterScan,
                       K = K,
                       mtoplo = mtoplo,
                       mtophi = mtophi,
                       mtopinc = mtopinc,                    
                       mtop = mtop,
                       amtop = amtop,
                       Klo = Klo,
                       Khi = Khi,
                       Kinc = Kinc,
                       aK = aK,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs,
                       fo = fo);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcRegressCvSingle.
# =================================================================================================






# =================================================================================================
# . InparamReg.getCommandLineCoxnetWithCov : gets the command line arguments for 
# .---------------------------------------   run_coxnet_with_cov.r
# .
# . This version allows for an additional external covariate.
# .
# .    inparam = InparamReg.getCommandLineCoxnetWithCov(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineCoxnetWithCov <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_coxnet_with_cov                                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat("        -flagCenter yes : yes/no. If yes, independently mean-center genes    \n");
           cat("                         in the training set. Values for the non-training set\n");
           cat("                         samples are individually centered using the trai-   \n");
           cat("                         ning set means for the given genes.                 \n");
           cat("\n");           
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");           
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat("       -tTest testFlag      : factor defining the test set members           \n");
           cat("                              and all other samples :                        \n");
           cat("                                - test set members are indicated by          \n");
           cat("                                  label = test. There must be at least 2     \n");
           cat("                                  test set members, if any.                  \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the test set.       \n");
           cat("                                - if the value of tTest is NONE, than NO     \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  test set members (no test set is used).    \n");           
           cat("\n");           
           cat(">>REGRESSION PARAMETERS:                                                     \n");
           cat("\n");                      
           cat("      -flagFs yes : yes/no. If yes, do gene-by-gene feature selection before \n");
           cat("                    submitting the data matrix to coxnet modeling.           \n");
           cat("                    This effectively allows for two levels of feature        \n");
           cat("                    selection.                                               \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("                  This parameter is ignored if flagFs = no. Otherwise must be \n");
           cat("                  in the range 1 <= mtop <= p, where p = number of genes in  \n");
           cat("                  input data matrix.                                         \n");
           cat("\n");           
           cat("      -typePval ZX : type of the P-value that is to be used for feature      \n");
           cat("                     selection. This parameter is ignored if flagFs = no.    \n");
           cat("                     Otherwise allowed options:                              \n");
           cat("                         model : P-value for overall model fitness.          \n");
           cat("                             X : P-value for gene effects.                   \n");       
           cat("                             Z : P-value for treatment effects.              \n");       
           cat("                            ZX : P-value for interaction effects.            \n");
           cat("\n");
           cat("      -alpha 1.0 : elastic net parameter that determines lasso-ridge         \n");
           cat("                   regression penalty mixture :                              \n");
           cat("                   apha = 1.0, pure lasso, alpha = 0, pure ridge regression. \n");
           cat("                   Allowed range : 0 <= alpha <= 1.0                         \n");
           cat("\n");           
           cat("      -lambda 1.0e-3 : Lagrange multiplier for penalty term.                 \n");
           cat("                       Allowed range : lambda >= 0.                          \n");
           cat("\n");
           cat("       -hRC 0.5 : used for binary Z ({0, 1}) external covariate only,        \n");
           cat("                  ignored otherwise. hRC is the threshold for defining       \n");
           cat("                  sensitive patient samples, through the formula :           \n");
           cat("\n");           
           cat("                    log(hRpred(Z = 1)) - log(hRpred(Z = 0)) <= log(hRC)      \n");
           cat("\n");
           cat("                  where hRpred(Z) is the hazard ratio predicted for that     \n");
           cat("                  sample at the given value of Z. Typically hRC < 1 and is   \n");
           cat("                  determined by optimizing on cross-validation results.      \n");
           cat("                  For the samples declared sensitive, a Cox analysis is      \n");
           cat("                  made to compare survival times for the true Z = 1 vs the   \n");
           cat("                  the true Z = 0 smaples.                                    \n");
           cat("                  Note that for non-binary covariates, a dummy value         \n");
           cat("                  must still be given for this parameter (say, -hRC 1).      \n");
           cat("                  We must have hRC >= 0.                                     \n");           
           cat("\n");                                  
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the results         \n");
           cat("                       (to be used in an interactive context only, not       \n");
           cat("                        in batch mode).                                      \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");                      
           cat("       -fo foo.COXPH  : output file for sample-by-sample pcs and log-hazards.\n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics.                  \n");
           cat("\n");
           cat("  -flagFsOut yes : yes/no; if yes, write the data matrix subsetted to        \n");
           cat("                   selected genes to file specified by option -fv.           \n");
           cat("\n");
           cat("   -fv foo.FLAT  : output file for data matrix subsetted to the selected     \n");
           cat("                   features. Valid formats, indicated by the extension,      \n");
           cat("                   are: DF, DFV, FLAT.                                       \n");
           cat("                   Required if flagFsOut = 'yes', ignored otherwise.         \n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :        
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	flagCenter = Param.get_parameter(argv, "-flagCenter", 1);    # Mean center values for genes

        if ((flagCenter != 'yes') && (flagCenter != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetWithCov:\n");
          cat("flagCenter = ", flagCenter, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
	tTest = Param.get_parameter(argv, "-tTest", 1);      # Factor defining test sets.                
	# ...................................................................................
        # . >>Cox model parameters :
	# ...................................................................................
	flagFs = Param.get_parameter(argv, "-flagFs", 1);    # Flag for fisrt-level feature-selection.

        if ((flagFs != 'yes') && (flagFs != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetWithCov:\n");
          cat("flagFs = ", flagFs, " is not valid (must be yes/no).\n", sep = "");
          stop();
        }
                
        if (flagFs == 'yes') {
          mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.
          typePval = Param.get_parameter(argv, "-typePval", 1);      # P-value to be used for selection.          
        } else {
          mtop = 0;                                                  # Dummy value.
          typePval = 'NONE';                                         # Dummy value.
        }          

        alpha = as.numeric(Param.get_parameter(argv, "-alpha", 1));    # Determines mix of L1 and L2 penalties.
        lambda = as.numeric(Param.get_parameter(argv, "-lambda", 1));  # Overall Lagrange multiplier for penalty term.
        
        hRC = as.numeric(Param.get_parameter(argv, "-hRC", 1));    # Hazard-ratio cutoff for predictive analysis.
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
        
        fs = Param.get_parameter(argv, "-fs", 1);    # Output file for summary statistics.        
        fo = Param.get_parameter(argv, "-fo", 1);    # Output file for sample-by-sample hazards.
	# ...................................................................................
        # . >>Output : optional subsetted data matrix.
	# ...................................................................................        
        flagFsOut = Param.get_parameter(argv, "-flagFsOut", 1);     # Flag for output of feature selection.
        stopifnot((flagFsOut == 'yes') || (flagFsOut == 'no'));
        
        if (flagFsOut == 'yes') {
          fv = Param.get_parameter(argv, "-fv", 1);         # Output file for feature selected data matrix.
        } else {
          fv = 'NONE';                                      # Dummy assignment.
        }
	# ...................................................................................



	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetWithCov:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetWithCov:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (flagFsOut == 'yes') {
          if ((length(grep("\\.DF$", fv, perl = TRUE)) == 0)
              && (length(grep("\\.DFV$", fv, perl = TRUE)) == 0)
              && (length(grep("\\.FLAT$", fv, perl = TRUE)) == 0)) {
            cat("ERROR: from InparamReg.getCommandLineCoxnetWithCov:\n");
            cat("The output data matrix file: fv = ", fv, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
            msg = "";
            stop(msg);
          }
        }
        
        if (flagPlotWrite == "yes") {
          if (length(grep("\\.PLOT$", fplot, perl = TRUE)) == 0) {
            cat("ERROR: from InparamReg.getCommandLineCoxnetWithCov:\n");
            cat("The output plot file: fplot = ", fplot, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extension: PLOT.\n");
            msg = "";
            stop(msg);
          }
        }
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        if (flagFs == 'yes') {
          stopifnot(mtop >= 1);

          allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);

          if (is.null(allowedTypePval[[typePval]])) {
            cat("ERROR: from InparamReg.getCommandLineCoxnetWithCov:\n");
            cat("typePval = ", typePval, " is not valid.\n", sep = "");
            cat("Valid: model, X, Z, ZX.\n", sep = "");
            stop();
          }
        }
        
        stopifnot(alpha >= 0.0, alpha <= 1.0);
        stopifnot(lambda >= 0.0);        

        stopifnot(hRC > 0.0);        
	# ...................................................................................

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo, fv, fplot);    # Output files.
        bBuf = c(fx, fe);               # Input files.

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetWithCov:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       flagCenter = flagCenter,          
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       tTest = tTest,          
                       fs = fs,
                       fo = fo,
                       flagFsOut = flagFsOut,
                       fv = fv,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       flagFs = flagFs,
                       mtop = mtop,
                       alpha = alpha,
                       lambda = lambda,          
                       typePval = typePval,
                       hRC = hRC);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineCoxnetWithCov.
# =================================================================================================







# =================================================================================================
# . InparamReg.getCommandLineCoxnetCvWithCov : gets the command line arguments for 
# . ----------------------------------------   run_coxnet_cv_with_cov.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineCoxnetCvWithCov(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineCoxnetCvWithCov <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_coxnet_cv_with_cov                                                     \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");
           cat("\n");
           cat("        -flagCenter yes : yes/no. If yes, independently mean-center genes    \n");
           cat("                         in the training set. Values for the non-training set\n");
           cat("                         samples are individually centered using the trai-   \n");
           cat("                         ning set means for the given genes.                 \n");
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");                      
           cat("                              >> NOTE: for cross-validation, only binary     \n");
           cat("                                 covariate data {0, 1} is currently allowed. \n");
           cat("                                 This is checked prior to execution of the   \n");
           cat("                                 main cross-validatiom loop.                 \n");           
           cat("\n");                      
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -cvType loop : cross-validation mode. Allowed values : loop, single.     \n");
           cat("                   loop : generate cross-validation statistics for all values\n");
           cat("                          of lambda generated by the regularization paths    \n");
           cat("                          computation in glmnet.                             \n");
           cat("                 single : use a single value of lambda (specified below)   \n");
           cat("                          to generate a single slice of cross-validation     \n");
           cat("                          statistics.                                        \n");
           cat("\n");                      
           cat("      -methodSplit vfoldStrict : how to split the data matrix into training  \n");
           cat("                           and test sets.                                    \n");
           cat("                           Allowed values: given, vfoldStrict                \n");
           cat("                           If value = given, a non-NONE value must be given  \n");
           cat("                           to option -tSplit (see below).                    \n");
           cat("\n");           
           cat("                           >>NOTE: methodSplit = vfold is obsolete, and no   \n");
           cat("                           longer allowed.                                   \n");           
           cat("\n");
           cat("      -ft 0.5            : required if methodSplit = vfoldStrict.            \n");
           cat("                           Fraction of training set instances                \n");
           cat("                           put into test set at each                         \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfold. Initial random   \n");
           cat("                           number generator seed.                            \n");
           cat("\n");                      
           cat("      -tSplit testTrain  : factor defining how to splt the training set      \n");           
           cat("                           into subsets for the cross-validation.            \n");
           cat("                           Required if methodSplit = given, optional and     \n");
           cat("                           ignored otherwise.                                \n");
           cat("                           - In the field indicated by the (non-NONE) value,     \n");           
           cat("                           training set members are indicated by value = train   \n");
           cat("                           and test set by value = test. Values = NONE are       \n");
           cat("                           ignored. Any other values in this field are invalid.  \n");           
           cat("\n");
           cat(">>COX-MODEL PARAMETERS :                                                     \n");
           cat("\n");
           cat("      -flagFs yes : yes/no. If yes, do gene-by-gene feature selection before \n");
           cat("                    submitting the data matrix to coxnet modeling.           \n");
           cat("                    This effectively allows for two levels of feature        \n");
           cat("                    selection.                                               \n");
           cat("\n");           
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("                  mtop is fixed and is not varied in the cross-validation.   \n");
           cat("                  This parameter is ignored if flagFs = no. Otherwise must be \n");
           cat("                  in the range 1 <= mtop <= p, where p = number of genes in  \n");
           cat("                  input data matrix.                                         \n");           
           cat("\n");
           cat("      -typePval ZX : type of the P-value that is to be used for the feature  \n");
           cat("                     selection. Allowed options:                             \n");
           cat("                         model : P-value for overall model fitness.          \n");
           cat("                             X : P-value for gene effects.                   \n");       
           cat("                             Z : P-value for treatment effects.              \n");       
           cat("                            ZX : P-value for interaction effects.            \n");
           cat("                     This parameter is ignored if flagFs = no.               \n");
           cat("\n");                                 
           cat("      -alpha 1.0 : elastic net parameter that determines lasso-ridge         \n");
           cat("                   regression penalty mixture :                              \n");
           cat("                   apha = 1.0, pure lasso, alpha = 0, pure ridge regression. \n");
           cat("                   Allowed range : 0 <= alpha <= 1.0                         \n");
           cat("                   alpha is fixed and is not varied in the cross-validation. \n");                      
           cat("\n");
           cat("      -lamba 0.0183  : point value for the Lagrange multiplier for the penalty  \n");
           cat("                       term for generating a single-level set of results.       \n");
           cat("                       Note that cross-validation results are obtained for      \n");
           cat("                       all lambda values in the regularization path array       \n");
           cat("                       (automatically) generated by glmnet.                     \n");
           cat("                       This entry is required if cvType = single (see above)    \n");
           cat("                       and is ignored if cvType = loop.                         \n");
           cat("\n");
           cat("       -nlambdaIn 20 : number of values of lambda to generate for the glmnet    \n");
           cat("                       regularization paths. If value is literal NONE, then     \n");
           cat("                       the default value of 100 will be used.                   \n");
           cat("                       Adjusting this parameter makes sense when exploring in   \n");
           cat("                       cvType = loop mode, but not really for cvType = single   \n");
           cat("                       mode, where the option NONE should be used.              \n");
           cat("\n");
           cat("       -hRC 0.5 : used for binary Z ({0, 1}) external covariate only,        \n");
           cat("                  ignored otherwise. hRC is the threshold for defining       \n");
           cat("                  sensitive patient samples, through the formula :           \n");
           cat("\n");           
           cat("                    log(hRpred(Z = 1)) - log(hRpred(Z = 0)) <= log(hRC)      \n");
           cat("\n");
           cat("                  where hRpred(Z) is the hazard ratio predicted for that     \n");
           cat("                  sample at the given value of Z.                            \n");
           cat("                  Note that for non-binary covariates, a dummy value         \n");
           cat("                  must still be given for this parameter (say, -hRC 1).      \n");
           cat("                  We must have hRC >= 0.                                     \n");           
           cat("\n");                                             
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");
           cat("       -fo foo.COXCV  : output file for sample-by-sample cross-validated     \n");
           cat("                        log-hazards and sensitivity predictions.             \n");
           cat("                        Extension must be COXCV.                             \n");
           cat("                        Required if cvType = single, ignored otherwise.      \n");
           cat("\n");                                 
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	flagCenter = Param.get_parameter(argv, "-flagCenter", 1);    # Mean center values for genes
        
        if ((flagCenter != 'yes') && (flagCenter != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCov:\n");
          cat("flagCenter = ", flagCenter, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Cross-validation parameters :
        # . >>Mode of the cross-validation :
        # .................................................................................
        cvType = Param.get_parameter(argv, "-cvType", 1);

        stopifnot((cvType == 'loop') || (cvType == 'single'));
        # .................................................................................        
        # . >>How to split the data :
        # .................................................................................
        methodSplit = Param.get_parameter(argv, "-methodSplit", 1);      # Partition for CV loop.

        stopifnot((methodSplit == 'given')
                  || (methodSplit == 'vfoldStrict'));                     # Method vfold now obsolete.
        
        if (methodSplit =='vfoldStrict') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.                    
        } else if (methodSplit == 'given') {
          ft = 0.0;                                                       # Dummy.
          rngSeed = 123456;                                               # Dummy.
          tSplit = Param.get_parameter(argv, "-tSplit", 1);               # Factor for split,
        }
	# ...................................................................................
        # . >>Cox model parameters :
	# ...................................................................................
	flagFs = Param.get_parameter(argv, "-flagFs", 1);    # Flag for fisrt-level feature-selection.

        if ((flagFs != 'yes') && (flagFs != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCov:\n");
          cat("flagFs = ", flagFs, " is not valid (must be yes/no).\n", sep = "");
          stop();
        }
                
        if (flagFs == 'yes') {
          mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.
          typePval = Param.get_parameter(argv, "-typePval", 1);      # P-value to be used for selection.          
        } else {
          mtop = 0;                                                  # Dummy value.
          typePval = 'NONE';                                         # Dummy value.
        }          
        
        alpha = as.numeric(Param.get_parameter(argv, "-alpha", 1));      # Determines mix of L1 and L2 penalties.

        if (cvType == 'single') {
          lambda = as.numeric(Param.get_parameter(argv, "-lambda", 1));    # Point value of Lagrange multiplier for penalty term.
        } else {
          lambda = 0.0;                                                    # Dummy.
        }

        buf = Param.get_parameter(argv, "-nlambdaIn", 1);         # Number of lambda values to be generated for regularization paths.

        if (buf != 'NONE') {
          nlambdaIn = as.numeric(buf);                            # Convert to assigned value.
        } else {
          nlambdaIn = 100;                                        # Default value.
        }

        hRC = as.numeric(Param.get_parameter(argv, "-hRC", 1));       # Hazard-ratio cutoff for predictive analysis.        
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);              # Output file for cv results.

        fo = 'NONE';                                           # Place-holder.
        
        if (cvType == 'single') {
          fo = Param.get_parameter(argv, "-fo", 1)             # Output file for COXCV results.          
        }
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCov:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCov:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCov:\n");
          cat("The output stat summary file: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: STAT.\n");
          msg = "";
          stop(msg);
        }        

        if (cvType == 'single') {
          if (length(grep("\\.COXCV$", fo, perl = TRUE)) == 0) {
            cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCov:\n");
            cat("The output COXCV results file: fo = ", fo, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extension: COXCV.\n");
            msg = "";
            stop(msg);
          }
        }
	# ...................................................................................        



	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        if (flagFs == 'yes') {
          stopifnot(mtop >= 1);

          allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);

          if (is.null(allowedTypePval[[typePval]])) {
            cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCov:\n");
            cat("typePval = ", typePval, " is not valid.\n", sep = "");
            cat("Valid: model, X, Z, ZX.\n", sep = "");
            stop();
          }
        }
        
        stopifnot(alpha >= 0.0, alpha <= 1.0);
        stopifnot(lambda >= 0.0);

        stopifnot(nlambdaIn > 0);
        stopifnot(hRC > 0.0);        
	# ...................................................................................
        
        
	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCov:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       cvType = cvType,
                       fx = fx,
                       fe = fe,
                       flagCenter = flagCenter,          
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       methodSplit = methodSplit,
                       ft = ft,
                       rngSeed = rngSeed,
                       tSplit = tSplit,
                       flagFs = flagFs,
                       mtop = mtop,
                       alpha = alpha,
                       lambda = lambda,
                       nlambdaIn = nlambdaIn,
                       typePval = typePval,          
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs,
                       fo = fo);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineCoxnetCvWithCov.
# =================================================================================================









# =================================================================================================
# . InparamReg.getCommandLineCoxnetCvWithCovBoot : gets the command line arguments for 
# . -------------------------------------------------   run_coxnet_cv_with_cov_boot.
# .                                       
# .
# .    inparam = InparamReg.getCommandLineCoxnetCvWithCovBoot(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineCoxnetCvWithCovBoot <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("Does bootstrap resampling for a single level (mtop, lambda) of coxnet model  \n");
           cat("cross-validation.                                                            \n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_coxnet_cv_with_cov_boot                                                \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");
           cat("\n");
           cat("        -flagCenter yes : yes/no. If yes, independently mean-center genes    \n");
           cat("                         in the training set. Values for the non-training set\n");
           cat("                         samples are individually centered using the trai-   \n");
           cat("                         ning set means for the given genes.                 \n");
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");                      
           cat("                              >> NOTE: for cross-validation, only binary     \n");
           cat("                                 covariate data {0, 1} is currently allowed. \n");
           cat("                                 This is checked prior to execution of the   \n");
           cat("                                 main cross-validatiom loop.                 \n");           
           cat("\n");                      
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -ft 0.5            : for unique allowed methodSplit = vfoldStrict.     \n");
           cat("                           Fraction of training set instances                \n");
           cat("                           put into test set at each                         \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfoldStrict.            \n");
           cat("                           Initial random number generator seed.             \n");
           cat("\n");                      
           cat(">>BOOTSTRAP PARAMETERS:                                                      \n");           
           cat("\n");
           cat("      -bootType fullBoot : type of resampling to be done in the outer loop.   \n");
           cat("                           Two types are valid : fullBoot, splitOnly          \n");
           cat("\n");           
           cat("                           fullBoot : do full bootstrap resampling. Resample  \n");
           cat("                                      with replacement the training set       \n");
           cat("                                      members, then do the indicated cross-   \n");
           cat("                                      validation. Note that with this option  \n");
           cat("                                      splits necessarily are different for    \n");
           cat("                                      each resampling.                        \n");           
           cat("\n");
           cat("                           splitOnly : only the splits defining the folds are \n");
           cat("                                       randomly changed for each outer loop   \n");
           cat("                                       sampling. The overall training set     \n");
           cat("                                       itself is unchanged.                   \n");
           cat("\n");
           cat("                          permutaton : keep (t, s, z) together for each       \n");
           cat("                                       sample, but randomly shuffle the       \n");
           cat("                                       corresponding gene expression profiles.\n");
           cat("                                       This test against the null hypothesis  \n");
           cat("                                       of no significant association between  \n");
           cat("                                       outcome and gene expression.           \n");           
           cat("\n");
           cat("      -nboot 100  : number of bootstrap resamplings to be applied.           \n");
           cat("\n");
           cat("\n");                                            
           cat(">>COX-MODEL PARAMETERS :                                                     \n");
           cat("\n");
           cat("      -flagFs yes : yes/no. If yes, do gene-by-gene feature selection before \n");
           cat("                    submitting the data matrix to coxnet modeling.           \n");
           cat("                    This effectively allows for two levels of feature        \n");
           cat("                    selection.                                               \n");
           cat("\n");           
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("                  mtop is fixed and is not varied in the cross-validation.   \n");
           cat("                  This parameter is ignored if flagFs = no. Otherwise must be \n");
           cat("                  in the range 1 <= mtop <= p, where p = number of genes in  \n");
           cat("                  input data matrix.                                         \n");           
           cat("\n");
           cat("      -typePval ZX : type of the P-value that is to be used for the feature  \n");
           cat("                     selection. Allowed options:                             \n");
           cat("                         model : P-value for overall model fitness.          \n");
           cat("                             X : P-value for gene effects.                   \n");       
           cat("                             Z : P-value for treatment effects.              \n");       
           cat("                            ZX : P-value for interaction effects.            \n");
           cat("                     This parameter is ignored if flagFs = no.               \n");
           cat("\n");                                 
           cat("      -alpha 1.0 : elastic net parameter that determines lasso-ridge         \n");
           cat("                   regression penalty mixture :                              \n");
           cat("                   apha = 1.0, pure lasso, alpha = 0, pure ridge regression. \n");
           cat("                   Allowed range : 0 <= alpha <= 1.0                         \n");
           cat("                   alpha is fixed and is not varied in the cross-validation. \n");
           cat("\n");
           cat("      -lamba 0.0183  : point value for the Lagrange multiplier for the penalty  \n");
           cat("                       term for generating a single-level set of results.       \n");
           cat("                       Note that cross-validation results are obtained for      \n");
           cat("                       all lambda values in the regularization path array       \n");
           cat("                       (automatically) generated by glmnet.                     \n");
           cat("                       This entry is required if cvType = single (see above)    \n");
           cat("                       and is ignored if cvType = loop.                         \n");
           cat("\n");
           cat("       -nlambdaIn 20 : number of values of lambda to generate for the glmnet    \n");
           cat("                       regularization paths. If value is literal NONE, then     \n");
           cat("                       the default value of 100 will be used.                   \n");
           cat("                       Adjusting this parameter makes sense when exploring in   \n");
           cat("                       cvType = loop mode, but not really for cvType = single   \n");
           cat("                       mode, where the option NONE should be used.              \n");
           cat("\n");
           cat("       -flaghRCOpt : determines how the decision threshold hRC is determined.   \n");
           cat("                     Allowed values :                                           \n");
           cat("\n");
           cat("                      -  'no' : for all samplings, use the value hRC given on   \n");
           cat("                                the command line (see below).                   \n");
           cat("                      -  'yes': for all samplings, determine hRC on-the-fly,    \n");
           cat("                                as the value which maximizes significance of    \n");
           cat("                                the split on the sensitives. The command line   \n");
           cat("                                threshold hRC is ignored.                       \n");           
           cat("\n");           
           cat("       -hRC 0.5 : threshold on DloghR for declaring sensitive and resistant     \n");
           cat("                  groups. Used if flaghRCOpt = no, ignored if flaghRCOpt = yes. \n");
           cat("                  We must have hRC >= 0. Required only if flaghRCOpt = no       \n");
           cat("\n");                                             
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");
           cat("       -fo foo.CVBOOT  : output file for resampling-by-resampling CV         \n");
           cat("                         summary results.                                    \n");
           cat("                         Extension must be COXBOOT.                          \n");
           cat("\n");                                 
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	flagCenter = Param.get_parameter(argv, "-flagCenter", 1);    # Mean center values for genes
        
        if ((flagCenter != 'yes') && (flagCenter != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
          cat("flagCenter = ", flagCenter, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Cross-validation parameters :
        # . >>Mode of the cross-validation :
        # .................................................................................
        cvType = 'single';                                   # Only single type for the bootstrap.
        # .................................................................................        
        # . >>How to split the data :
        # .................................................................................
        methodSplit = 'vfoldStrict';                                    # Only split method allowed for bootstrap.
        ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
        rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
        # .................................................................................        
        # . >>Bootstrap parameters :
        # .................................................................................
        bootType = Param.get_parameter(argv, "-bootType", 1);      # Bootstrap type.

        if ((bootType != 'fullBoot')
            && (bootType != 'splitOnly')
            && (bootType != 'permutation')) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
          cat("bootType = ", bootType, " is not valid. Valid : fullBoot, splitOnly, permutation.\n", sep = "");
          stop();
        }

        nboot = as.numeric(Param.get_parameter(argv, "-nboot", 1)); # Number of bootstrap resamplings.
	# ...................................................................................
        # . >>Cox model parameters :
	# ...................................................................................
	flagFs = Param.get_parameter(argv, "-flagFs", 1);    # Flag for fisrt-level feature-selection.

        if ((flagFs != 'yes') && (flagFs != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
          cat("flagFs = ", flagFs, " is not valid (must be yes/no).\n", sep = "");
          stop();
        }
                
        if (flagFs == 'yes') {
          mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.
          typePval = Param.get_parameter(argv, "-typePval", 1);      # P-value to be used for selection.          
        } else {
          mtop = 0;                                                  # Dummy value.
          typePval = 'NONE';                                         # Dummy value.
        }          
        
        alpha = as.numeric(Param.get_parameter(argv, "-alpha", 1));      # Determines mix of L1 and L2 penalties.

        if (cvType == 'single') {
          lambda = as.numeric(Param.get_parameter(argv, "-lambda", 1));    # Point value of Lagrange multiplier for penalty term.
        } else {
          lambda = 0.0;                                                    # Dummy.
        }

        buf = Param.get_parameter(argv, "-nlambdaIn", 1);         # Number of lambda values to be generated for regularization paths.

        if (buf != 'NONE') {
          nlambdaIn = as.numeric(buf);                            # Convert to assigned value.
        } else {
          nlambdaIn = 100;                                        # Default value.
        }
        # ..................................................................................
        # . Decision threshold :
        # ..................................................................................        
	flaghRCOpt = Param.get_parameter(argv, "-flaghRCOpt", 1);    # Mean center values for genes
        
        if ((flaghRCOpt != 'yes') && (flaghRCOpt != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
          cat("flaghRCOpt = ", flaghRCOpt, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }
        
        if (flaghRCOpt == 'no') {
          hRC = as.numeric(Param.get_parameter(argv, "-hRC", 1));    # Hazard-ratio cutoff for predictive analysis.
        } else if (flaghRCOpt == 'yes') {
          hRC = 1.0;                                                 # Dummy value, as not used.
        } else {
          cat("ERROR: flaghRCOpt not valid. See code logic.\n");     # Failsafe.
          stop();
        }        
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);              # Output file for summary stats.
        fo = Param.get_parameter(argv, "-fo", 1)               # Output file for resample-by-resample results.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
          cat("The output stat summary file: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: STAT.\n");
          msg = "";
          stop(msg);
        }        

        if (length(grep("\\.CVBOOT$", fo, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
          cat("The output bootstrap CV results file: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: CVBOOT.\n");
          msg = "";
          stop(msg);
        }
	# ...................................................................................        


        

	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        if (flagFs == 'yes') {
          stopifnot(mtop >= 1);

          allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);

          if (is.null(allowedTypePval[[typePval]])) {
            cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
            cat("typePval = ", typePval, " is not valid.\n", sep = "");
            cat("Valid: model, X, Z, ZX.\n", sep = "");
            stop();
          }
        }
        
        stopifnot(alpha >= 0.0, alpha <= 1.0);
        stopifnot(lambda >= 0.0);

        stopifnot(nlambdaIn > 0);
        stopifnot(hRC > 0.0);

        stopifnot(nboot > 0);
	# ...................................................................................
        
        
	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineCoxnetCvWithCovBoot:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       cvType = cvType,
                       fx = fx,
                       fe = fe,
                       flagCenter = flagCenter,          
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       methodSplit = methodSplit,
                       ft = ft,
                       rngSeed = rngSeed,
                       bootType = bootType,
                       nboot = nboot,
                       flagFs = flagFs,
                       mtop = mtop,
                       alpha = alpha,
                       lambda = lambda,
                       nlambdaIn = nlambdaIn,
                       flaghRCOpt = flaghRCOpt,
                       hRC = hRC,
                       typePval = typePval,          
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs,
                       fo = fo);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineCoxnetCvWithCovBoot.
# =================================================================================================









# =================================================================================================
# . InparamReg.getCommandLineSuperPcCoxCvWithCovBoot : gets the command line arguments for 
# . ------------------------------------------------   run_super_pc_cox_cv_with_cov_boot.
# .                                       
# .
# .    inparam = InparamReg.getCommandLineSuperPcCoxCvWithCovBoot(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineSuperPcCoxCvWithCovBoot <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("Does bootstrap resampling for a single level (mtop, K) of spc Cox model      \n");
           cat("cross-validation.                                                            \n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_super_pc_cox_cv_with_cov_boot                                          \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");                      
           cat("                              >> NOTE: for cross-validation, only binary     \n");
           cat("                                 covariate data {0, 1} is currently allowed. \n");
           cat("                                 This is checked prior to execution of the   \n");
           cat("                                 main cross-validatiom loop.                 \n");           
           cat("\n");                      
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -ft 0.5            : for unique allowed methodSplit = vfoldStrict.     \n");
           cat("                           Fraction of training set instances                \n");
           cat("                           put into test set at each                         \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfoldStrict.            \n");
           cat("                           Initial random number generator seed.             \n");
           cat("\n");                      
           cat(">>BOOTSTRAP PARAMETERS:                                                      \n");           
           cat("\n");
           cat("      -bootType fullBoot : type of resampling to be done in the outer loop.   \n");
           cat("                           Two types are valid : fullBoot, splitOnly          \n");
           cat("\n");           
           cat("                           fullBoot : do full bootstrap resampling. Resample  \n");
           cat("                                      with replacement the training set       \n");
           cat("                                      members, then do the indicated cross-   \n");
           cat("                                      validation. Note that with this option  \n");
           cat("                                      splits necessarily are different for    \n");
           cat("                                      each resampling.                        \n");           
           cat("\n");
           cat("                           splitOnly : only the splits defining the folds are \n");
           cat("                                       randomly changed for each outer loop   \n");
           cat("                                       sampling. The overall training set     \n");
           cat("                                       itself is unchanged.                   \n");
           cat("\n");
           cat("                          permutaton : keep (t, s, z) together for each       \n");
           cat("                                       sample, but randomly shuffle the       \n");
           cat("                                       corresponding gene expression profiles.\n");
           cat("                                       This test against the null hypothesis  \n");
           cat("                                       of no significant association between  \n");
           cat("                                       outcome and gene expression.           \n");           
           cat("\n");
           cat("      -nboot 100  : number of bootstrap resamplings to be applied.           \n");
           cat("\n");
           cat("\n");                                            
           cat(">>COX-MODEL PARAMETERS :                                                     \n");
           cat("\n");
           cat("      -mtop 50  : keep the mtop genes with most significant Cox scores (i.e. \n");  
           cat("                  those with the mtop smallest P-values).                    \n");
           cat("                  mtop is fixed and is not varied in the cross-validation.   \n");
           cat("                  This Otherwise must be                                     \n");
           cat("                  in the range 1 <= mtop <= p, where p = number of genes in  \n");
           cat("                  input data matrix.                                         \n");
           cat("\n");           
           cat("      -K 1      : number of principal components to be used as covariates    \n");
           cat("                  in the Cox proportional hazard model for the survival data.\n");
           cat("\n");           
           cat("\n");
           cat("      -typePval ZX : type of the P-value that is to be used for the feature  \n");
           cat("                     selection. Allowed options:                             \n");
           cat("                         model : P-value for overall model fitness.          \n");
           cat("                             X : P-value for gene effects.                   \n");       
           cat("                             Z : P-value for treatment effects.              \n");       
           cat("                            ZX : P-value for interaction effects.            \n");
           cat("                     This parameter is ignored if flagFs = no.               \n");
           cat("\n");                                 
           cat("       -flaghRCOpt : determines how the decision threshold hRC is determined.   \n");
           cat("                     Allowed values :                                           \n");
           cat("\n");
           cat("                      -  'no' : for all samplings, use the value hRC given on   \n");
           cat("                                the command line (see below).                   \n");
           cat("                      -  'yes': for all samplings, determine hRC on-the-fly,    \n");
           cat("                                as the value which maximizes significance of    \n");
           cat("                                the split on the sensitives. The command line   \n");
           cat("                                threshold hRC is ignored.                       \n");           
           cat("\n");           
           cat("       -hRC 0.5 : threshold on DloghR for declaring sensitive and resistant     \n");
           cat("                  groups. Used if flaghRCOpt = no, ignored if flaghRCOpt = yes. \n");
           cat("                  We must have hRC >= 0. Required only if flaghRCOpt = no       \n");           
           cat("\n");                                                        
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");
           cat("       -fo foo.CVBOOT  : output file for resampling-by-resampling CV         \n");
           cat("                         summary results.                                    \n");
           cat("                         Extension must be COXBOOT.                          \n");
           cat("\n");                                 
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.
        
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Cross-validation parameters :
        # . >>Mode of the cross-validation :
        # .................................................................................
        cvType = 'single';                                   # Only single type for the bootstrap.
        # .................................................................................        
        # . >>How to split the data :
        # .................................................................................
        methodSplit = 'vfoldStrict';                                    # Only split method allowed for bootstrap.
        ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
        rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
        # .................................................................................        
        # . >>Bootstrap parameters :
        # .................................................................................
        bootType = Param.get_parameter(argv, "-bootType", 1);      # Bootstrap type.

        if ((bootType != 'fullBoot')
            && (bootType != 'splitOnly')
            && (bootType != 'permutation')) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovBoot:\n");
          cat("bootType = ", bootType, " is not valid. Valid : fullBoot, splitOnly, permutation.\n", sep = "");
          stop();
        }

        nboot = as.numeric(Param.get_parameter(argv, "-nboot", 1)); # Number of bootstrap resamplings.
	# ...................................................................................
        # . >>Cox model parameters :
	# ...................................................................................
        mtop = as.numeric(Param.get_parameter(argv, "-mtop", 1));  # Number of genes cutoff.
        typePval = Param.get_parameter(argv, "-typePval", 1);      # P-value to be used for selection.
        K = as.numeric(Param.get_parameter(argv, "-K", 1));        # Number of principal components.
        # ..................................................................................
        # . Decision threshold :
        # ..................................................................................        
	flaghRCOpt = Param.get_parameter(argv, "-flaghRCOpt", 1);    # Mean center values for genes
        
        if ((flaghRCOpt != 'yes') && (flaghRCOpt != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovBoot:\n");
          cat("flaghRCOpt = ", flaghRCOpt, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }

        if (flaghRCOpt == 'no') {
          hRC = as.numeric(Param.get_parameter(argv, "-hRC", 1));    # Hazard-ratio cutoff for predictive analysis.
        } else if (flaghRCOpt == 'yes') {
          hRC = 1.0;                                                 # Dummy value, as not used.
        } else {
          cat("ERROR: flaghRCOpt not valid. See code logic.\n");     # Failsafe.
          stop();
        }
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);              # Output file for summary stats.
        fo = Param.get_parameter(argv, "-fo", 1)               # Output file for resample-by-resample results.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovBoot:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovBoot:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovBoot:\n");
          cat("The output stat summary file: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: STAT.\n");
          msg = "";
          stop(msg);
        }        

        if (length(grep("\\.CVBOOT$", fo, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovBoot:\n");
          cat("The output bootstrap CV results file: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: CVBOOT.\n");
          msg = "";
          stop(msg);
        }
	# ...................................................................................        


        

	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot(mtop >= 1);
        stopifnot(K >= 1);        

        allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);

        if (is.null(allowedTypePval[[typePval]])) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovBoot:\n");
          cat("typePval = ", typePval, " is not valid.\n", sep = "");
          cat("Valid: model, X, Z, ZX.\n", sep = "");
          stop();
        }

        stopifnot(hRC > 0.0);
        stopifnot(nboot > 0);
	# ...................................................................................
        
        
	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineSuperPcCoxCvWithCovBoot:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       cvType = cvType,
                       fx = fx,
                       fe = fe,
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       methodSplit = methodSplit,
                       ft = ft,
                       rngSeed = rngSeed,
                       bootType = bootType,
                       nboot = nboot,
                       mtop = mtop,
                       typePval = typePval,          
                       K = K,
                       flaghRCOpt = flaghRCOpt,          
                       hRC = hRC,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs,
                       fo = fo);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineSuperPcCoxCvWithCovBoot.
# =================================================================================================







# =================================================================================================
# . InparamReg.getCommandLineGlmnetRegressCvSingle : gets the command line arguments for 
# . ----------------------------------------------   run_glmnet_regress_cv_single.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineGlmnetRegressCvSingle(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineGlmnetRegressCvSingle <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           
           cat("Description:\n");
           cat("Performs cross-validation of a multivariate regression model\n");
           cat("for prediction of given output variable on gene expression values\n");
           cat("provided in an input data matrix.\n");           
           cat("Uses glmnet (elastic net) model for prediction.   \n");
           cat("Cross-validation is done for a single value of the tuning parameter lambda.\n");

           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_glmnet_regress_cv_single                                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>OUTPUT VARIABLE AND TRAIN/TEST SPECIFICATION:                              \n");
           cat("\n");
           cat("       -tY tumorToControl     : factor for output variable in experimental   \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");
           cat("\n");
           cat(">>MODEL TYPE:                                                                \n")
           cat("\n");           
           cat("   -modelType lm : regression model to be used.                              \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'lm'     : linear model.                             \n");
           cat("                      - 'logistic' : logistic distribution.                  \n");           
           cat("\n");                      
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -methodSplit vfoldStrict : how to split the data matrix into training  \n");
           cat("                           and test sets.                                    \n");
           cat("                           Allowed values: vfoldStrict, given.                      \n");
           cat("                           If value = given, a non-NONE value must be given  \n");
           cat("                           to option -tSplit (see below).                    \n");
           cat("\n");
           cat("      -ft 0.5            : required if methodSplit = vfoldStrict. Fraction of \n");
           cat("                           training set instances put into test set at each  \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfold. Initial random   \n");
           cat("                           number generator seed.                            \n");
           cat("\n");                      
           cat("      -tSplit testTrain  : factor defining how to split the training set     \n");           
           cat("                           into subsets for the cross-validation.            \n");
           cat("                           Required if methodSplit = given, optional and     \n");
           cat("                           ignored otherwise.                                \n");
           cat("                           - In the field indicated by the (non-NONE) value,     \n");           
           cat("                           training set members are indicated by value = train   \n");
           cat("                           and test set by value = test. Values = NONE are       \n");
           cat("                           ignored. Any other values in this field are invalid.  \n");           
           cat("\n");
           cat(">>ELASTIC NET PARAMETERS FOR THE CROSS_VALIDATION:                           \n");
           cat("\n");
           cat("\n");                                 
           cat("      -alpha 1.0 : elastic net parameter that determines lasso-ridge         \n");
           cat("                   regression penalty mixture :                              \n");
           cat("                   apha = 1.0, pure lasso, alpha = 0, pure ridge regression. \n");
           cat("                   Allowed range : 0 <= alpha <= 1.0                         \n");
           cat("                   alpha is fixed and is not varied in the cross-validation. \n");
           cat("\n");
           cat("      -lamba 0.0183  : point value for the Lagrange multiplier for the penalty  \n");
           cat("                       term for generating a single-level set of results.       \n");
           cat("                       Note that cross-validation results are obtained for      \n");
           cat("                       all lambda values in the regularization path array       \n");
           cat("                       (automatically) generated by glmnet.                     \n");
           cat("                       lambda is fixed and is not varied in the                 \n");
           cat("                       cross-validation.                                        \n");
           cat("\n");           
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-regress', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("\n");
           cat("       -fo foo.TSV    : output file for sample-by-sample cross-validated     \n");
           cat("                        predictions, joined to complete experimental design. \n");
           cat("\n");                      
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	tY = Param.get_parameter(argv, "-tY", 1);            # Factor for output variable.               
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Model type :
        # .................................................................................
        modelType = Param.get_parameter(argv, "-modelType", 1);    # Flag for feature selection.
        stopifnot((modelType == 'lm') || (modelType == 'logistic'));
        # .................................................................................
        # . Cross-validation parameters :
        # . >>How to split the data :
        # .................................................................................
        methodSplit = Param.get_parameter(argv, "-methodSplit", 1);      # Partition for CV loop.
        stopifnot((methodSplit == 'given')
                  || (methodSplit == 'vfoldStrict'));                    # N.B. I suppressed vfold option.

        if (methodSplit =='vfoldStrict') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
          ncv = 0;                                                        # Dummy.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
          tSplit = 'NONE';                                                # Dummy.                              
        } else if (methodSplit == 'given') {
          ft = 0.0;                                                       # Dummy.
          ncv = 0;                                                        # Dummy.
          rngSeed = 123456;                                               # Dummy.
          tSplit = Param.get_parameter(argv, "-tSplit", 1);               # Factor for split,
        }
        # .................................................................................
        # . >>What to scan in the cross-validation loop :
        # .................................................................................
        alpha = as.numeric(Param.get_parameter(argv, "-alpha", 1));      # Determines mix of L1 and L2 penalties.
        lambda = as.numeric(Param.get_parameter(argv, "-lambda", 1));    # Point value of Lagrange multiplier for penalty term.        
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);              # Output file for cv results.
        fo = Param.get_parameter(argv, "-fo", 1);              # Output file for cross-validated predictions.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineGlmnetRegressCvSingle:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineGlmnetRegressCvSingle:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }        
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot(alpha >= 0.0, alpha <= 1.0);
        stopifnot(lambda >= 0.0);        
	# ...................................................................................


	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo);
        bBuf = c(fx, fe);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineGlmnetRegressCvSingle:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................


        
        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       cvType = 'single',
                       fx = fx,
                       fe = fe,
                       tY = tY,          
                       tTrain = tTrain,
                       modelType = modelType,          
                       methodSplit = methodSplit,
                       ft = ft,
                       rngSeed = rngSeed,
                       tSplit = tSplit,
                       alpha = alpha,
                       lambda = lambda,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs,
                       fo = fo);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineGlmnetRegressCvSingle.
# =================================================================================================







# =================================================================================================
# . InparamReg.getCommandLineCellLinePanelAnalysisAndExtraction : gets the command line arguments for 
# . -----------------------------------------------------------   run_cell_line_panel_analysis_and_extraction
# .                                       
# .
# .    inparam = InparamReg.getCommandLineCellLinePanelAnalysisAndExtraction(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineCellLinePanelAnalysisAndExtraction <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           
           cat("Description:\n");
           cat("Reads a file containing cell line compound sensitivity information.\n");
           cat("Generates cell line * compound data matrices for EC50 and efficacy proliferation variables.\n");
           cat("Generates a picture gallery of basic statistical analyses on the data.\n");

           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_cell_line_panel_analysis_and_extraction                                \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DF : name of data file, containg the compound sensitivity \n");
           cat("                        data. Allowed extensions: DF, FLAT, TSV, csv         \n");
           cat("                        Each row contains one record for a given cell line   \n");
           cat("                        and compound combination.                            \n");
           cat("                        See details below for required columns.              \n");
           cat("\n");
           cat(">>SUBSETS:                                                                   \n");
           cat("\n");                                 
           cat("    -flagSubsetComp yes : yes/no. If yes, read specified list of             \n");
           cat("                          compounds (see below) and use to subset the        \n");
           cat("                          raw data set to contain only compounds in the      \n");
           cat("                          list.                                              \n");
           cat("\n");
           cat("     -fcomp comp.TSV : required if flagSubsetComp = yes, ignored otherwise.  \n");
           cat("                      Contains list of compounds; one compound name per line,\n");
           cat("                      lines starting with # are ignored.                     \n");
           cat("\n");
           cat("    -flagSubsetCell no : yes/no. If yes, read specified list of cell lines   \n");
           cat("                         (see below) and use to subset the raw data set      \n");
           cat("                         to contain only cell lines in the list.             \n");
           cat("                              list.                                          \n");
           cat("\n");
           cat("     -fcomp cell.TSV : required if flagSubsetCell = yes, ignored otherwise.  \n");
           cat("                      Contains list of cell lines; one cell line name per    \n");
           cat("                      line, lines starting with # are ignored.               \n");
           cat("\n");
           cat(">>ANNOTATION:                                                                \n");
           cat("\n");                      
           cat("    -flagannotComp yes : yes/no. If yes, read a compound annotation file     \n");
           cat("                         (see below) and use to group compounds in the       \n");
           cat("                         graphic output.                                     \n");
           cat("\n");
           cat("    -fannotComp comp.CLASS : CLASS file for annotating the compounds.        \n");
           cat("                             Ignored if flagAnnotComp = no.                  \n");
           cat("\n");           
           cat("    -tannotComp moa : factor to be used in the CLASS file to annotate the    \n");
           cat("                      compounds (the internal CLASS_ label is ignored).      \n");
           cat("                      Ignored if flagAnnotComp = no.                         \n");
           cat("\n");           
           cat("\n");
           cat(">>PROCESSING PARAMETERS:                                                     \n");           
           cat("\n");
           cat("     -mainTitle ORI-subset4 : name for this processing run, which will       \n");
           cat("                              appear in the plots.                           \n");
           cat("\n");
           cat("       -treatNA keep   : How to deal with NAs (missing values).              \n");
           cat("                         Allowed Options:                                    \n");
           cat("\n");           
           cat("                       omit : build cell line * compound membership matrix,  \n");
           cat("                              then remove any cell lines which do not have a \n");
           cat("                              complete profile across all the compounds.     \n");
           cat("\n");           
           cat("                       keep : build cell line * compound membership matrix,  \n");
           cat("                              keep all cell lines, even those with NAs       \n");
           cat("                              for some compounds.                            \n");
           cat("\n");           
           cat("                    replace : build cell line * compound membership matrix.  \n");
           cat("                              Pad (replace) NA values by -5 for Log.qAC50    \n");
           cat("                              variables (equivalent ot 10 uM AC50) and by 0  \n");
           cat("                              for efficacy variables.                        \n");
           cat("\n");           
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -order comp_x_cell  : order of axes in the output data matrix :       \n");
           cat("                             Allowed options :                               \n");
           cat("                               comp_x_cell = compound * cell lines           \n");
           cat("                               cell_x_comp = cell lines * compound           \n");
           cat("\n");                      
           cat("       -fo foo.FLAT   : output file for cell line * compound data matrix.    \n");
           cat("                        Must have FLAT extension.                            \n");
           cat("\n");
           cat("       -fl foo.LABEL  : output file for companion labels.                    \n");
           cat("                        Must have LABEL extension.                           \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-regress', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");                      
           cat("---------------------------------------------------------------------------- \n");

           acStandard = CellLinePanel.getStandardDataColumns();

           cat("\n");
           cat(">>DETAILS :                                                                  \n");           
           cat("Required columns in input data file specified by -fx :                       \n");
           cat("---------------------------------------------------------------------------- \n");           
           cat(paste(acStandard, collapse = "     "));
           cat("\n");
           cat("---------------------------------------------------------------------------- \n");           

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files :
        # . Master input file :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);                            # Master cell line, compound sensitivity data file.
	# ...................................................................................        
        # . Auxiliary files :
        # . Compounds :
	# ...................................................................................        
	flagSubsetComp = Param.get_parameter(argv, "-flagSubsetComp", 1);    # Should we subset on a compound list?
        stopifnot((flagSubsetComp == 'yes') || (flagSubsetComp == 'no'));

        fcomp = 'NONE';                                                      # Dummy default.
        
        if (flagSubsetComp == 'yes') {
          fcomp = Param.get_parameter(argv, "-fcomp", 1);                    # List of compounds.
        }
	# ...................................................................................                
        # . Cell lines :
	# ...................................................................................        
	flagSubsetCell = Param.get_parameter(argv, "-flagSubsetCell", 1);    # Should we subset on a cell line list?
        stopifnot((flagSubsetCell == 'yes') || (flagSubsetCell == 'no'));

        fcell = 'NONE';                                                      # Dummy default.
        
        if (flagSubsetCell == 'yes') {
          fcell = Param.get_parameter(argv, "-fcell", 1);                    # List of cell lines.
        }
        # .................................................................................
        # . Compound annotation :
        # .................................................................................
        flagAnnotComp = Param.get_parameter(argv, "-flagAnnotComp", 1); 
        stopifnot((flagAnnotComp == 'yes') || (flagAnnotComp == 'no'));

        fannotComp = 'NONE';
        tannotComp = 'NONE';
        
        if (flagAnnotComp == 'yes') {
          fannotComp = Param.get_parameter(argv, "-fannotComp", 1);
          tannotComp = Param.get_parameter(argv, "-tannotComp", 1); 
        }
        # .................................................................................
        # . Title to label plots with :
        # .................................................................................
        mainTitle = Param.get_parameter(argv, "-mainTitle", 1);              # Main title for plots.        
        # .................................................................................
        # . Processing parameters :
        # .................................................................................
        treatNA = Param.get_parameter(argv, "-treatNA", 1);              # Flag for either omittimg or replacing NAs.

        stopifnot((treatNA == 'keep') || (treatNA == 'omit') || (treatNA == 'replace'));
	# ...................................................................................
        # . >>Output files :
        # . Data matrix and companion label file :
	# ...................................................................................
        order = Param.get_parameter(argv, "-order", 1);        # Order of axes.
        stopifnot((order == 'comp_x_cell') || (order == 'cell_x_comp'));
        
        fo = Param.get_parameter(argv, "-fo", 1);              # Output FLAT file.
        fl = Param.get_parameter(argv, "-fl", 1);              # Companion LABEL output file.
	# ...................................................................................                
        # . Graohics parameters :
	# ...................................................................................        
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
	# ...................................................................................        


        
	# ...................................................................................
        # . Check on file extensions :
        # . Input files :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.CELLPANEL", fx, perl = TRUE)) == 0)
            && (length(grep("\\.TSV", fx, perl = TRUE)) == 0)
            && (length(grep("\\.csv", fx, perl = TRUE)) == 0)
            ) {
          cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtraction:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, CELLPANEL, TSV, csv.\n");
          msg = "";
          stop(msg);
        }

        if (flagAnnotComp == 'yes') {
          if (length(grep("\\.CLASS$", fannotComp, perl = TRUE)) == 0) {
            cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtraction:\n");
            cat("The compound annotation file: fannotComp = ", fannotComp, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extension: CLASS.\n");
            msg = "";
          stop(msg);
          }
        }
	# ...................................................................................        
        # . Output files :
	# ...................................................................................
        if (length(grep("\\.FLAT$", fo, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtraction:\n");
          cat("The output data matrix file: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.LABEL$", fl, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtraction:\n");
          cat("The label output file: fl = ", fl, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: LABEL.\n");
          msg = "";
          stop(msg);
        }
	# ...................................................................................        

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fo, fl);
        bBuf = c(fx, fcomp, fcell);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtraction:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................


        
        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       flagSubsetComp = flagSubsetComp,
                       fcomp = fcomp,
                       flagSubsetCell = flagSubsetCell,
                       fcell = fcell,
                       flagAnnotComp = flagAnnotComp,
                       fannotComp = fannotComp,
                       tannotComp = tannotComp,          
                       mainTitle = mainTitle,
                       treatNA = treatNA,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       order = order,
                       fo = fo,
                       fl = fl);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineCellLinePanelAnalysisAndExtraction.
# =================================================================================================







# =================================================================================================
# . InparamReg.getCommandLineGlmnetRegress : gets the command line arguments for 
# . --------------------------------------   run_glmnet_regress.r
# .                                       
# .
# .    inparam = InparamReg.getCommandLineGlmnetRegress(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineGlmnetRegress <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           
           cat("Description:\n");
           cat("Builds a multivariate regression model\n");
           cat("for prediction of given output variable on gene expression values\n");
           cat("provided in an input data matrix.\n");           
           cat("Uses glmnet (elastic net) model for prediction.   \n");

           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_glmnet_regress                                                         \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");           
           cat("\n");
           cat(">>OUTPUT VARIABLE AND TRAIN/TEST SPECIFICATION:                              \n");
           cat("\n");
           cat("       -tY tumorToControl     : factor for output variable in experimental   \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");
           cat("\n");
           cat(">>MODEL TYPE:                                                                \n")
           cat("\n");           
           cat("   -modelType lm : regression model to be used.                              \n");
           cat("                      Allowed values :                                       \n");
           cat("                      - 'lm'     : linear model.                             \n");
           cat("                      - 'logistic' : logistic distribution.                  \n");           
           cat("\n");                      
           cat("\n");
           cat(">>GLMNET PARAMETERS :                                                        \n");
           cat("\n");                                 
           cat("      -alpha 1.0 : elastic net parameter that determines lasso-ridge         \n");
           cat("                   regression penalty mixture :                              \n");
           cat("                   apha = 1.0, pure lasso, alpha = 0, pure ridge regression. \n");
           cat("                   Allowed range : 0 <= alpha <= 1.0                         \n");
           cat("                   alpha is fixed and is not varied in the cross-validation. \n");
           cat("\n");
           cat("      -lamba 0.0183  : point value for the Lagrange multiplier for the penalty  \n");
           cat("                       term for generating a single-level set of results.       \n");
           cat("                       Note that cross-validation results are obtained for      \n");
           cat("                       all lambda values in the regularization path array       \n");
           cat("                       (automatically) generated by glmnet.                     \n");
           cat("                       lambda is fixed and is not varied in the                 \n");
           cat("                       cross-validation.                                        \n");
           cat("\n");
           cat("      -flagCv yes : yes/no; if yes, perform a cross-validation in the whole     \n");
           cat("                    range of lambda using the native glmnet package,            \n");
           cat("\n");
           cat("      -ft 0.5     : required if flagCv = yes. Fraction of                       \n");
           cat("                    training set instances put into test set at each            \n");
           cat("                    random sampling. Allowed values: 0 < ft < 1.                \n");
           cat("                    Adjustments are made so that cv training and test           \n");
           cat("                    sets each have at least 2 members.                          \n");
           cat("\n");           
           cat("     -rngSeed 123786 : required if flagCv = yes. Initial random number        \n");
           cat("                       generator seed. Value must be > 0 if cross-validation  \n");
           cat("                       is specified.                                          \n");           
           cat("\n");
           cat(">>OUTPUT FILES :                                                              \n");
           cat("\n");                      
           cat("       -fs foo.STAT   : output file for summary statistics.                   \n");
           cat("\n");                                            
           cat("       -fo foo.REGRESS : output file for sample-by-sample predictions.        \n");
           cat("                         This must have the extension REGRESS.                \n");           
           cat("\n");
           cat("       -flagFsOut yes : yes/no. Output data matrix subsetted to selected      \n");
           cat("                        features?                                             \n");
           cat("\n");           
           cat("       -fsub foo-sub.FLAT : output file for data matrix subsetted on the      \n");
           cat("                            genes selected by glmnet.                         \n");
           cat("                            This must have the extension FLAT.                \n");
           cat("                            Required if flagFsOut = yes, ignored otherwise.   \n");
           cat("\n");                         
           cat(">>PLOT PARAMETERS :                                                           \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-regress', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	tY = Param.get_parameter(argv, "-tY", 1);            # Factor for output variable.               
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Model type :
        # .................................................................................
        modelType = Param.get_parameter(argv, "-modelType", 1);    # Flag for feature selection.
        stopifnot((modelType == 'lm') || (modelType == 'logistic'));
        # .................................................................................
        # . >>glmnet parameters :
        # .................................................................................
        alpha = as.numeric(Param.get_parameter(argv, "-alpha", 1));      # Determines mix of L1 and L2 penalties.
        lambda = as.numeric(Param.get_parameter(argv, "-lambda", 1));    # Point value of Lagrange multiplier for penalty term.

        flagCv = Param.get_parameter(argv, "-flagCv", 1);                # Perform whole-range cross-validation?

        stopifnot((flagCv == 'yes') || (flagCv == 'no'));

        ft = 1;
        rngSeed = 0;
        
        if (flagCv == 'yes') {
          ft = as.numeric(Param.get_parameter(argv, "-ft", 1));            # Fraction into each fold.
          rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1));  # RNG seed.          
        }
	# ...................................................................................
        # . >>Output files :
	# ...................................................................................
        fs = Param.get_parameter(argv, "-fs", 1);              # Summary statistis.
        fo = Param.get_parameter(argv, "-fo", 1);              # Predictions.

        flagFsOut = Param.get_parameter(argv, "-flagFsOut", 1);   # Output subsetted data matrix?

        stopifnot((flagFsOut == 'yes') || (flagFsOut == 'no'));

        fsub = 'NONE';                                            # Place holder.
        
        if (flagFsOut == 'yes') {
          fsub = Param.get_parameter(argv, "-fsub", 1);           # Data matrix subsetted to selected features.
        }
	# ...................................................................................
        # . >>Plot parameters :
	# ...................................................................................        
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineGlmnetRegress:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineGlmnetRegress:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if ((length(grep("\\.REGRESS$", fo, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineGlmnetRegress:\n");
          cat("The regression predictions output file: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: REGRESS.\n");
          msg = "";
          stop(msg);
        }

        if (flagFsOut == 'yes') {
          if ((length(grep("\\.FLAT$", fsub, perl = TRUE)) == 0)) {
            cat("ERROR: from InparamReg.getCommandLineGlmnetRegress:\n");
            cat("The selected features output file: fsub = ", fsub, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extensions: FLAT.\n");
            msg = "";
            stop(msg);
          }
        }
	# ...................................................................................        

        
        
	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot(alpha >= 0.0, alpha <= 1.0);
        stopifnot(lambda >= 0.0);

        if (flagCv == 'yes') {
          stopifnot(ft > 0, ft < 1);
          stopifnot(rngSeed > 0);
        }
	# ...................................................................................


	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs, fo);              # Ouptut files.

        if (flagFsOut == 'yes') {
          aBuf = c(aBuf, fsub);
        }
        
        bBuf = c(fx, fe);              # Input files.

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineGlmnetRegress:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................


        
        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       fe = fe,
                       tY = tY,          
                       tTrain = tTrain,
                       modelType = modelType,          
                       alpha = alpha,
                       lambda = lambda,
                       flagCv = flagCv,
                       ft = ft,
                       rngSeed = rngSeed,          
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs,
                       fo = fo,
                       flagFsOut = flagFsOut,
                       fsub = fsub);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineGlmnetRegress.
# =================================================================================================







# ==================================================================================================================
# . InparamReg.getCommandLineCellLinePanelAnalysisAndExtractionNEW : gets the command line arguments for 
# . -----------------------------------------------------------   run_cell_line_panel_analysis_and_extraction_NEW
# .                                       
# .
# .    inparam = InparamReg.getCommandLineCellLinePanelAnalysisAndExtractionNEW(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# ===================================================================================================================

InparamReg.getCommandLineCellLinePanelAnalysisAndExtractionNEW <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           
           cat("Description:\n");
           cat("Reads a file containing cell line compound sensitivity information.\n");
           cat("Generates cell line * compound data matrices for EC50 and efficacy proliferation variables.\n");
           cat("Generates a picture gallery of basic statistical analyses on the data.\n");
           cat("This NEW version processes data saved from Spotfire and converted to UTF-8 from UTF16-LE.\n");

           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_cell_line_panel_analysis_and_extraction_NEW                            \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DF : name of data file, containg the compound sensitivity \n");
           cat("                        data. Allowed extensions: DF, FLAT, TSV, csv         \n");
           cat("                        Each row contains one record for a given cell line   \n");
           cat("                        and compound combination.                            \n");
           cat("                        See details below for required columns.              \n");
           cat("\n");
           cat(">>SUBSETS:                                                                   \n");
           cat("\n");                                 
           cat("    -flagSubsetComp yes : yes/no. If yes, read specified list of             \n");
           cat("                          compounds (see below) and use to subset the        \n");
           cat("                          raw data set to contain only compounds in the      \n");
           cat("                          list.                                              \n");
           cat("\n");
           cat("     -fcomp comp.TSV : required if flagSubsetComp = yes, ignored otherwise.  \n");
           cat("                      Contains list of compounds; one compound name per line,\n");
           cat("                      lines starting with # are ignored.                     \n");
           cat("\n");
           cat("    -flagSubsetCell no : yes/no. If yes, read specified list of cell lines   \n");
           cat("                         (see below) and use to subset the raw data set      \n");
           cat("                         to contain only cell lines in the list.             \n");
           cat("                              list.                                          \n");
           cat("\n");
           cat("     -fcomp cell.TSV : required if flagSubsetCell = yes, ignored otherwise.  \n");
           cat("                      Contains list of cell lines; one cell line name per    \n");
           cat("                      line, lines starting with # are ignored.               \n");
           cat("\n");
           cat(">>ANNOTATION:                                                                \n");
           cat("\n");                      
           cat("    -flagannotComp yes : yes/no. If yes, read a compound annotation file     \n");
           cat("                         (see below) and use to group compounds in the       \n");
           cat("                         graphic output.                                     \n");
           cat("\n");
           cat("    -fannotComp comp.CLASS : CLASS file for annotating the compounds.        \n");
           cat("                             Ignored if flagAnnotComp = no.                  \n");
           cat("\n");           
           cat("    -tannotComp moa : factor to be used in the CLASS file to annotate the    \n");
           cat("                      compounds (the internal CLASS_ label is ignored).      \n");
           cat("                      Ignored if flagAnnotComp = no.                         \n");
           cat("\n");           
           cat("\n");
           cat(">>PROCESSING PARAMETERS:                                                     \n");           
           cat("\n");
           cat("     -mainTitle ORI-subset4 : name for this processing run, which will       \n");
           cat("                              appear in the plots.                           \n");
           cat("\n");
           cat("       -treatNA keep   : How to deal with NAs (missing values).              \n");
           cat("                         Allowed Options:                                    \n");
           cat("\n");           
           cat("                       omit : build cell line * compound membership matrix,  \n");
           cat("                              then remove any cell lines which do not have a \n");
           cat("                              complete profile across all the compounds.     \n");
           cat("\n");           
           cat("                       keep : build cell line * compound membership matrix,  \n");
           cat("                              keep all cell lines, even those with NAs       \n");
           cat("                              for some compounds.                            \n");
           cat("\n");           
           cat("                    replace : build cell line * compound membership matrix.  \n");
           cat("                              Pad (replace) NA values by 10^-5 for aGI50     \n");
           cat("                              variables (10 uM) and by 0                     \n");
           cat("                              for efficacy variables.                        \n");
           cat("\n");           
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -order comp_x_cell  : order of axes in the output data matrix :       \n");
           cat("                             Allowed options :                               \n");
           cat("                               comp_x_cell = compound * cell lines           \n");
           cat("                               cell_x_comp = cell lines * compound           \n");
           cat("\n");                      
           cat("       -fo foo.FLAT   : output file for cell line * compound data matrix.    \n");
           cat("                        Must have FLAT extension.                            \n");
           cat("\n");
           cat("       -fl foo.LABEL  : output file for companion labels.                    \n");
           cat("                        Must have LABEL extension.                           \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-regress', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");                      
           cat("---------------------------------------------------------------------------- \n");

           acStandard = CellLinePanel.getStandardDataColumnsNEW();

           cat("\n");
           cat(">>DETAILS :                                                                  \n");           
           cat("Required columns in input data file specified by -fx :                       \n");
           cat("---------------------------------------------------------------------------- \n");           
           cat(paste(acStandard, collapse = "     "));
           cat("\n");
           cat("---------------------------------------------------------------------------- \n");           

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files :
        # . Master input file :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);                            # Master cell line, compound sensitivity data file.
	# ...................................................................................        
        # . Auxiliary files :
        # . Compounds :
	# ...................................................................................        
	flagSubsetComp = Param.get_parameter(argv, "-flagSubsetComp", 1);    # Should we subset on a compound list?
        stopifnot((flagSubsetComp == 'yes') || (flagSubsetComp == 'no'));

        fcomp = 'NONE';                                                      # Dummy default.
        
        if (flagSubsetComp == 'yes') {
          fcomp = Param.get_parameter(argv, "-fcomp", 1);                    # List of compounds.
        }
	# ...................................................................................                
        # . Cell lines :
	# ...................................................................................        
	flagSubsetCell = Param.get_parameter(argv, "-flagSubsetCell", 1);    # Should we subset on a cell line list?
        stopifnot((flagSubsetCell == 'yes') || (flagSubsetCell == 'no'));

        fcell = 'NONE';                                                      # Dummy default.
        
        if (flagSubsetCell == 'yes') {
          fcell = Param.get_parameter(argv, "-fcell", 1);                    # List of cell lines.
        }
        # .................................................................................
        # . Compound annotation :
        # .................................................................................
        flagAnnotComp = Param.get_parameter(argv, "-flagAnnotComp", 1); 
        stopifnot((flagAnnotComp == 'yes') || (flagAnnotComp == 'no'));

        fannotComp = 'NONE';
        tannotComp = 'NONE';
        
        if (flagAnnotComp == 'yes') {
          fannotComp = Param.get_parameter(argv, "-fannotComp", 1);
          tannotComp = Param.get_parameter(argv, "-tannotComp", 1); 
        }
        # .................................................................................
        # . Title to label plots with :
        # .................................................................................
        mainTitle = Param.get_parameter(argv, "-mainTitle", 1);              # Main title for plots.        
        # .................................................................................
        # . Processing parameters :
        # .................................................................................
        treatNA = Param.get_parameter(argv, "-treatNA", 1);              # Flag for either omittimg or replacing NAs.

        stopifnot((treatNA == 'keep') || (treatNA == 'omit') || (treatNA == 'replace'));
	# ...................................................................................
        # . >>Output files :
        # . Data matrix and companion label file :
	# ...................................................................................
        order = Param.get_parameter(argv, "-order", 1);        # Order of axes.
        stopifnot((order == 'comp_x_cell') || (order == 'cell_x_comp'));
        
        fo = Param.get_parameter(argv, "-fo", 1);              # Output FLAT file.
        fl = Param.get_parameter(argv, "-fl", 1);              # Companion LABEL output file.
	# ...................................................................................                
        # . Graohics parameters :
	# ...................................................................................        
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
	# ...................................................................................        


        
	# ...................................................................................
        # . Check on file extensions :
        # . Input files :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.CELLPANEL", fx, perl = TRUE)) == 0)
            && (length(grep("\\.TSV", fx, perl = TRUE)) == 0)
            && (length(grep("\\.csv", fx, perl = TRUE)) == 0)
            ) {
          cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtractionNEW:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, CELLPANEL, TSV, csv.\n");
          msg = "";
          stop(msg);
        }

        if (flagAnnotComp == 'yes') {
          if (length(grep("\\.CLASS$", fannotComp, perl = TRUE)) == 0) {
            cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtractionNEW:\n");
            cat("The compound annotation file: fannotComp = ", fannotComp, "\n", sep = "");
            cat("Does not have a valid extension. Allowed extension: CLASS.\n");
            msg = "";
          stop(msg);
          }
        }
	# ...................................................................................        
        # . Output files :
	# ...................................................................................
        if (length(grep("\\.FLAT$", fo, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtractionNEW:\n");
          cat("The output data matrix file: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.LABEL$", fl, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtractionNEW:\n");
          cat("The label output file: fl = ", fl, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: LABEL.\n");
          msg = "";
          stop(msg);
        }
	# ...................................................................................        

        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fo, fl);
        bBuf = c(fx, fcomp, fcell);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineCellLinePanelAnalysisAndExtractionNEW:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................


        
        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fx = fx,
                       flagSubsetComp = flagSubsetComp,
                       fcomp = fcomp,
                       flagSubsetCell = flagSubsetCell,
                       fcell = fcell,
                       flagAnnotComp = flagAnnotComp,
                       fannotComp = fannotComp,
                       tannotComp = tannotComp,          
                       mainTitle = mainTitle,
                       treatNA = treatNA,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,
                       order = order,
                       fo = fo,
                       fl = fl);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineCellLinePanelAnalysisAndExtractionNEW.
# =================================================================================================








# ==================================================================================================================
# . InparamReg.getCommandLineCellLineScreenSirnaAnalysis : gets the command line arguments for 
# . ----------------------------------------------------   run_cell_line_screen_sirna_analysis
# .                                       
# .
# .    inparam = InparamReg.getCommandLineCellLineScreenSirnaAnalysis(argv);
# .
# . In:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . Out:
# .     inparam : list containing the parameters.
# .
# ===================================================================================================================

InparamReg.getCommandLineCellLineScreenSirnaAnalysis <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("Description:\n");
           cat("Reads a file containing siRNA * cell line activity information.\n");
           cat("Generates gene * cell line data matrices for activity.\n");
           cat("Generates a picture gallery of basic statistical analyses on the data.\n");

           cat("\n");
           cat("General command line syntax:\n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_cell_line_screen_sirna_analysis                                        \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-siRNA-data.TSV : name of data file, containing the siRNA       \n");
           cat("                               activity data. Allowed extension: TSV         \n");
           cat("                               See details below for required columns.       \n");
           cat("\n");
           cat(">>ADDITIONAL DATA : positive and negative controls :                         \n");
           cat("\n");
           cat("       -posControl KIF11+CCND1 : list of positive control genes, joined by +. \n");
           cat("       -negControl EMPTY       : list of negative control genes, joined by +. \n");
           cat("\n");
           cat("                                 If either option is set to string NONE,      \n");
           cat("                                 the corresponding control category is not    \n");
           cat("                                 used.                                        \n");
           cat("\n");
           cat("       -flagZ  yes             : yes/no. Z-transform activity data on a cell-line-by  \n");
           cat("                                 basis before doing the analyses?                     \n");
           cat("                                 Z(x) = (x - med(xpos)) / (med(xneg) - med(xpos))     \n");           
           cat("\n");                                 
           cat(">>SELECTION PARAMETERS : for gene and cell line selection :                  \n");
           cat("\n");
           cat("       -activityMax   : upper bound on activity.                             \n");
           cat("       -pval0         : upper bound on RSA p-value.                          \n");
           cat("\n");
           cat("                        For each analyzed {gene * cell line} combination,    \n");
           cat("                        flags as selected those siRNAs which have :          \n");
           cat("\n");           
           cat("                           activity <= activityMax, pval <= pval0.           \n");
           cat("\n");           
           cat("                        Then tallies for each gene how many cell lines had   \n");
           cat("                        at least 1 siRNA thus flagged.                       \n");
           cat("\n");
           cat(">>OUTPUT :                                                                   \n");
           cat("\n");
           cat("       -dirOut fooOut : directory for all output files.                      \n");
           cat("\n");
           cat("       -fstem foo-ne  : stem name for all output files to be generated.      \n");
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("       -title FOO    : general title for plots.                              \n");           
           cat("\n");           
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-regress', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");                      
           cat("---------------------------------------------------------------------------- \n");

           #xxx acStandard = CellLineScreen.getStandardDataColumns();
           acStandard = "";

           cat("\n");
           cat(">>DETAILS :                                                                  \n");           
           cat("Required columns in input data file specified by -fx :                       \n");
           cat("---------------------------------------------------------------------------- \n");           
           cat(paste(acStandard, collapse = "     "));
           cat("\n");
           cat("---------------------------------------------------------------------------- \n");           

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files :
        # . Master input file :
	# ...................................................................................
	fX = Param.get_parameter(argv, "-fx", 1);                            # Master cell line, compound sensitivity data file.
        # .................................................................................
        # . Additional data parameters :
        # .................................................................................
        posControl = Param.get_parameter(argv, "-posControl", 1);            # Positive controls.
        negControl = Param.get_parameter(argv, "-negControl", 1);            # Positive controls.

        posControl = strsplit(posControl, split = "\\+", perl = TRUE);
        negControl = strsplit(negControl, split = "\\+", perl = TRUE);

        flagZ = Param.get_parameter(argv, "-flagZ", 1);                      # Z-transform data?
        stopifnot((flagZ == 'yes') || (flagZ == 'no'));

        if ((posControl == 'NONE') || (negControl == 'NONE')) {
          if (flagZ == 'yes') {
            cat("ERROR: from InparamReg.getCommandLineCellLineScreenSirnaAnalysis:\n");
            cat("flagZ = yes, but positive and/or negative controls have not been specified.\n");
            stop();            
          }
        }
        # .................................................................................
        # . Selection parameters :
        # .................................................................................
        activityMax = as.numeric(Param.get_parameter(argv, "-activityMax", 1));
        pval0 = as.numeric(Param.get_parameter(argv, "-pval0", 1));

        stopifnot((pval0 > 0) & (pval0 <= 1));
	# ...................................................................................
        # . >>Output files :
	# ...................................................................................
        dirOut = Param.get_parameter(argv, "-dirOut", 1);         # Output directory.
        fstem = Param.get_parameter(argv, "-fstem", 1);           # Stem name for all output files.
	# ...................................................................................                
        # . Graphics parameters :
	# ...................................................................................        
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        title = Param.get_parameter(argv, "-title", 1);        # General plot title.

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
	# ...................................................................................        


        
	# ...................................................................................
        # . Check on file extensions :
        # . Input files :
	# ...................................................................................
        if (length(grep("\\.TSV$", fX, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineCellLineScreenSirnaAnalysis:\n");
          cat("The input numerical data file: fX = ", fX, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: TSV.\n");
          msg = "";
          stop(msg);
        }
	# ...................................................................................        
        # . Output files :
	# ...................................................................................
        dirOut = gsub("\\/$", "", dirOut);
        
        if (!file.exists(dirOut)) {
          cat("ERROR: from InparamReg.getCommandLineCellLineScreenSirnaAnalysis:\n");
          cat("The specifed output directory: dirOut = ", dirOut, "\n", sep = "");
          cat("Does not exist.\n");
          msg = "";
          stop(msg);
        }
	# ...................................................................................


        
        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       fX = fX,
                       posControl = posControl,
                       negControl = negControl,
                       flagZ = flagZ,
                       activityMax = activityMax,
                       pval0 = pval0,
                       dirOut = dirOut,
                       fstem = fstem,
                       flagPlot = flagPlot,
                       title  = title,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineCellLineScreenSirnaAnalysis.
# =================================================================================================








# =================================================================================================
# . InparamReg.getCommandLineBasicCoxCvWithCovBoot : gets the command line arguments for 
# . ----------------------------------------------   run_basic_cox_cv_with_cov_boot.
# .                                       
# .
# .    inparam = InparamReg.getCommandLineBasicCoxCvWithCovBoot(argv);
# .
# . IN:
# .     argv : vector containing the command line arguments (i.e. argv[1] == executable name).
# .            If argv[2] == "-use", will display syntax of command line, then exit.
# .
# . OUT:
# .     inparam : list containing the parameters.
# .
# =================================================================================================

InparamReg.getCommandLineBasicCoxCvWithCovBoot <- function(argv)
{

	# ................................................................................................
	# . Indications for use:
	# ................................................................................................
	if (argv[2] == "-use") {
           cat("\n");
           cat("General command line syntax:\n");
           cat("Does bootstrap resampling for a single level (mtop, K) of spc Cox model      \n");
           cat("cross-validation.                                                            \n");
           cat("---------------------------------------------------------------------------- \n");
           cat("  run_basic_cox_cv_with_cov_boot                                          \n");
           cat("\n");
           cat(">>INPUT FILES:                                                               \n");
           cat("\n");           
           cat("      -fx foo-data.DFV : name of numerical data file, containg the gene      \n");
           cat("                         expression data. Allowed extensions: DF, DFV, FLAT  \n");
           cat("                                  DF : rows = samples, columns = genes.      \n");
           cat("                           DFV, FLAT : rows = genes, columns = samples.      \n");
           cat("\n");
           cat("        -fe foo-exp.DF : name of the experimental design file. Must have     \n");
           cat("                         a DF extension and be in data frame format.         \n");
           cat("                         - if the data file (-fx) is of format DF,           \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of rows in the data file.       \n");
           cat("                          - if the data file (-fx) is of format DFV or FLAT, \n");
           cat("                         the number of rows in the body of this file must    \n");
           cat("                         equal to the number of columns in the data file.    \n");
           cat("\n");
           cat("        -flagQlist yes : yes/no. If yes, read contents of file fQlist (below)\n");
           cat("                         for a list of genes that will be used to reduce the \n");
           cat("                         input data matrix to the overlap between the list   \n");
           cat("                         and the genes present in the data matrix.           \n");
           cat("                         If there is no overlap, and error will be indicated.\n");           
           cat("\n");
           cat("           -fq foo.TSV : required if flagQlist = yes, ignored otherwise.    \n");
           cat("                          Contains the list of genes to be used in res-      \n");
           cat("                          tricting the features of the input data matrix.    \n");
           cat("                          Format of file contents is:                        \n");
           cat("                          #QUAL                                              \n");
           cat("                          genename1                                          \n");
           cat("                          genename2                                          \n");
           cat("                          #genename2                                         \n");           
           cat("                          . . .                                              \n");
           cat("                          All gene entries starting with # are ignored.      \n");          
           cat("\n");
           cat("        -flagCenter yes : yes/no. If yes, independently mean-center genes    \n");
           cat("                         in the training set. Values for the non-training set\n");
           cat("                         samples are individually centered using the trai-   \n");
           cat("                         ning set means for the given genes.                 \n");
           cat("\n");
           cat(">>SURVIVAL DATA AND TRAIN/TEST SPECIFICATION:                                \n");
           cat("\n");
           cat("       -tTime Follow_up_years : factor for survival time in experimental     \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tStatus Status_binary : factor for censoring status in experimental  \n");
           cat("                                design file.                                 \n"); 
           cat("\n");
           cat("       -tCov ZTreat           : factor for additional external covariate,    \n");
           cat("                                which must define a numerical variable.      \n");
           cat("\n");                      
           cat("                              >> NOTE: for cross-validation, only binary     \n");
           cat("                                 covariate data {0, 1} is currently allowed. \n");
           cat("                                 This is checked prior to execution of the   \n");
           cat("                                 main cross-validatiom loop.                 \n");           
           cat("\n");                      
           cat("       -tTrain trainFlag      : factor defining the training set members     \n");
           cat("                                and all other samples :                      \n");
           cat("                                - training set members are indicated by      \n");
           cat("                                  label = train. There must be at least 2    \n");
           cat("                                  training set members.                      \n");           
           cat("                                - samples with any other label in that field \n");
           cat("                                  will not be include in the training set.   \n");
           cat("                                - if the value of tTrain is NONE, than ALL   \n");
           cat("                                  samples in the data matrix are used as     \n");
           cat("                                  training set members.                      \n");           
           cat("\n");
           cat(">>CROSS-VALIDATION PARAMETERS:                                               \n");           
           cat("\n");
           cat("      -ft 0.5            : for unique allowed methodSplit = vfoldStrict.     \n");
           cat("                           Fraction of training set instances                \n");
           cat("                           put into test set at each                         \n");
           cat("                           random sampling. Allowed values: 0 < ft < 1.      \n");
           cat("                           Adjustments are made so that cv training and test \n");
           cat("                           sets each have at least 2 members.                \n");
           cat("\n");
           cat("      -rngSeed 123786    : required if methodSplit = vfoldStrict.            \n");
           cat("                           Initial random number generator seed.             \n");
           cat("\n");                      
           cat(">>BOOTSTRAP PARAMETERS:                                                      \n");           
           cat("\n");
           cat("      -bootType fullBoot : type of resampling to be done in the outer loop.   \n");
           cat("                           Two types are valid : fullBoot, splitOnly          \n");
           cat("\n");           
           cat("                           fullBoot : do full bootstrap resampling. Resample  \n");
           cat("                                      with replacement the training set       \n");
           cat("                                      members, then do the indicated cross-   \n");
           cat("                                      validation. Note that with this option  \n");
           cat("                                      splits necessarily are different for    \n");
           cat("                                      each resampling.                        \n");           
           cat("\n");
           cat("                           splitOnly : only the splits defining the folds are \n");
           cat("                                       randomly changed for each outer loop   \n");
           cat("                                       sampling. The overall training set     \n");
           cat("                                       itself is unchanged.                   \n");
           cat("\n");
           cat("                          permutaton : keep (t, s, z) together for each       \n");
           cat("                                       sample, but randomly shuffle the       \n");
           cat("                                       corresponding gene expression profiles.\n");
           cat("                                       This test against the null hypothesis  \n");
           cat("                                       of no significant association between  \n");
           cat("                                       outcome and gene expression.           \n");           
           cat("\n");
           cat("      -nboot 100  : number of bootstrap resamplings to be applied.           \n");
           cat("\n");
           cat("\n");                                            
           cat(">>COX-MODEL PARAMETERS :                                                     \n");
           cat("\n");
           cat("       -flaghRCOpt : determines how the decision threshold hRC is determined.   \n");
           cat("                     Allowed values :                                           \n");
           cat("\n");
           cat("                      -  'no' : for all samplings, use the value hRC given on   \n");
           cat("                                the command line (see below).                   \n");
           cat("                      -  'yes': for all samplings, determine hRC on-the-fly,    \n");
           cat("                                as the value which maximizes significance of    \n");
           cat("                                the split on the sensitives. The command line   \n");
           cat("                                threshold hRC is ignored.                       \n");           
           cat("\n");           
           cat("       -hRC 0.5 : threshold on DloghR for declaring sensitive and resistant     \n");
           cat("                  groups. Used if flaghRCOpt = no, ignored if flaghRCOpt = yes. \n");
           cat("                  We must have hRC >= 0. Required only if flaghRCOpt = no       \n");           
           cat("\n");                                                        
           cat(">>OUTPUT :                                                                   \n");           
           cat("\n");
           cat("       -flagPlot yes : yes/no; if yes, generate plots of the cross-validation\n");
           cat("                       results (to be used in an interactive context only,   \n");
           cat("                       not in batch mode).                                   \n");
           cat("\n");
           cat("  -flagPlotWrite yes : yes/no. Required if flagPlot = yes. If yes, save      \n");
           cat("                        plots to file and do not query user interactively.   \n");
           cat("                        If no, generate plots interactively, and do not save \n");
           cat("                        them to file.                                        \n");
           cat("\n");
           cat("     -dirPlot foo/tmp : Required if flagPlotWrite = yes. Specifies directory \n");
           cat("                        where plot files are to be written. Plot file names  \n");
           cat("                        are generated with stem name 'temp-cox', and contain \n");
           cat("                        parts generated by random number generator.          \n");
           cat("\n");
           cat("      -fplot foo.PLOT : Required if flagPlotWrite = yes. Specifies the output\n");
           cat("                        file which lists the plot file names with the        \n");
           cat("                        corresponding titles. Must have PLOT extension.      \n");
           cat("\n");           
           cat("       -fs foo.STAT   : output file for summary statistics and for cross-    \n");
           cat("                        validation results.                                  \n");
           cat("                        Extension must be STAT.                              \n");           
           cat("\n");
           cat("       -fo foo.CVBOOT  : output file for resampling-by-resampling CV         \n");
           cat("                         summary results.                                    \n");
           cat("                         Extension must be COXBOOT.                          \n");
           cat("\n");                                 
           cat("\n");           
           cat("---------------------------------------------------------------------------- \n");

	   inparam = list(status = "exit");
	   return (inparam);	   
	}
	# ................................................................................................        



	# ...................................................................................
	# . Get the command line arguments:
        # . >>Input files and survival data indicators :
	# ...................................................................................
	fx = Param.get_parameter(argv, "-fx", 1);    # Numerical data file.
	fe = Param.get_parameter(argv, "-fe", 1);    # Experimental design file.

	flagQlist = Param.get_parameter(argv, "-flagQlist", 1);    # Will we restrict to a given gene list?

        if ((flagQlist != 'yes') && (flagQlist != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovSingle:\n");
          cat("flagQlist = ", flagQlist, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }

        if (flagQlist == 'yes') {
          fq = Param.get_parameter(argv, "-fq", 1);          # The file containing the gene list.
        } else {
	  fq = 'NONE';                                       # Dummy.
	}

	flagCenter = Param.get_parameter(argv, "-flagCenter", 1);    # Mean center values for genes?

        if ((flagCenter != 'yes') && (flagCenter != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovSingle:\n");
          cat("flagCenter = ", flagCenter, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }        
	# ...................................................................................                
        # . >>Survival data indicators :
	# ...................................................................................                
	tTime = Param.get_parameter(argv, "-tTime", 1);      # Factor for survival times.
	tStatus = Param.get_parameter(argv, "-tStatus", 1);  # Factor for censoring statuses.
	tCov = Param.get_parameter(argv, "-tCov", 1);        # Factor for external covariate.
        
	tTrain = Param.get_parameter(argv, "-tTrain", 1);    # Factor defining train/test sets.
        # .................................................................................
        # . Cross-validation parameters :
        # . >>Mode of the cross-validation :
        # .................................................................................
        cvType = 'single';                                   # Only single type for the bootstrap.
        # .................................................................................        
        # . >>How to split the data :
        # .................................................................................
        methodSplit = 'vfoldStrict';                                    # Only split method allowed for bootstrap.
        ft = as.numeric(Param.get_parameter(argv, "-ft", 1));           # Fraction into test.
        rngSeed = as.numeric(Param.get_parameter(argv, "-rngSeed", 1)); # RNG seed.
        # .................................................................................        
        # . >>Bootstrap parameters :
        # .................................................................................
        bootType = Param.get_parameter(argv, "-bootType", 1);      # Bootstrap type.

        if ((bootType != 'fullBoot')
            && (bootType != 'splitOnly')
            && (bootType != 'permutation')) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovBoot:\n");
          cat("bootType = ", bootType, " is not valid. Valid : fullBoot, splitOnly, permutation.\n", sep = "");
          stop();
        }

        nboot = as.numeric(Param.get_parameter(argv, "-nboot", 1)); # Number of bootstrap resamplings.
	# ...................................................................................
        # . >>Cox model parameters :
	# .
        # . Decision threshold :
        # ..................................................................................        
	flaghRCOpt = Param.get_parameter(argv, "-flaghRCOpt", 1);    # Mean center values for genes
        
        if ((flaghRCOpt != 'yes') && (flaghRCOpt != 'no')) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovBoot:\n");
          cat("flaghRCOpt = ", flaghRCOpt, " is not valid (must be yes/no).\n", sep = "");
          msg = "";
          stop(msg);
        }

        if (flaghRCOpt == 'no') {
          hRC = as.numeric(Param.get_parameter(argv, "-hRC", 1));    # Hazard-ratio cutoff for predictive analysis.
        } else if (flaghRCOpt == 'yes') {
          hRC = 1.0;                                                 # Dummy value, as not used.
        } else {
          cat("ERROR: flaghRCOpt not valid. See code logic.\n");     # Failsafe.
          stop();
        }
	# ...................................................................................
        # . >>Output :
	# ...................................................................................
        flagPlot = Param.get_parameter(argv, "-flagPlot", 1);  # Generate plots?

        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));

        flagPlotWrite = 'no';   # Place holder.
        dirPlot = '';           # Place holder.
        fplot = '';             # Place holder.
        
        if (flagPlot == 'yes') {
          flagPlotWrite = Param.get_parameter(argv, "-flagPlotWrite", 1);  # Save plots to file?
          stopifnot((flagPlotWrite == 'yes') || (flagPlotWrite == 'no'));

          if (flagPlotWrite =='yes') {
            dirPlot = Param.get_parameter(argv, "-dirPlot", 1);   # Directory to save plots.
            fplot = Param.get_parameter(argv, "-fplot", 1);       # File with listing of saved files.
          }
        }
                
        fs = Param.get_parameter(argv, "-fs", 1);              # Output file for summary stats.
        fo = Param.get_parameter(argv, "-fo", 1)               # Output file for resample-by-resample results.
	# ...................................................................................        

        
	# ...................................................................................
        # . Check on file extensions :
	# ...................................................................................
        if ((length(grep("\\.DF$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.DFV$", fx, perl = TRUE)) == 0)
            && (length(grep("\\.FLAT$", fx, perl = TRUE)) == 0)) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovBoot:\n");
          cat("The input numerical data file: fx = ", fx, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extensions: DF, DFV, FLAT.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.DF$", fe, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovBoot:\n");
          cat("The input experimental design file: fe = ", fe, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: DF.\n");
          msg = "";
          stop(msg);
        }

        if (length(grep("\\.STAT$", fs, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovBoot:\n");
          cat("The output stat summary file: fs = ", fs, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: STAT.\n");
          msg = "";
          stop(msg);
        }        

        if (length(grep("\\.CVBOOT$", fo, perl = TRUE)) == 0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovBoot:\n");
          cat("The output bootstrap CV results file: fo = ", fo, "\n", sep = "");
          cat("Does not have a valid extension. Allowed extension: CVBOOT.\n");
          msg = "";
          stop(msg);
        }
	# ...................................................................................        


        

	# ...................................................................................
        # . Check on the validity of the input parameters :
	# ...................................................................................
        stopifnot(hRC > 0.0);
        stopifnot(nboot > 0);
	# ...................................................................................
        
        
	# ......................................................
        stopifnot((flagPlot == 'yes') || (flagPlot == 'no'));
	# ......................................................
        
        
	# ...................................................................................        
        # . Check that none of the output file names overlap with the input file names:
	# ...................................................................................
        aBuf = c(fs);
        bBuf = c(fx, fe, fq);

        temp1 = sum(aBuf %in% bBuf);

        if (temp1 >0) {
          cat("ERROR: from InparamReg.getCommandLineBasicCoxCvWithCovBoot:\n");
          cat("some of the output files have the same name as some of the input files.\n", sep = "");
          cat("Check the file names on the command line.\n", sep = "");
          msg = "";
          stop(msg);
        }
	# ...................................................................................

        
	# ...................................................................................
	# . Package into a list :
	# ...................................................................................
	inparam = list(status = "ok",
                       cvType = cvType,
                       fx = fx,
                       fe = fe,
                       flagQlist = flagQlist,
                       fq = fq,
                       flagCenter = flagCenter,                    
                       tTime = tTime,
                       tStatus = tStatus,
                       tCov = tCov,          
                       tTrain = tTrain,
                       methodSplit = methodSplit,
                       ft = ft,
                       rngSeed = rngSeed,
                       bootType = bootType,
                       nboot = nboot,
                       flaghRCOpt = flaghRCOpt,          
                       hRC = hRC,
                       flagPlot = flagPlot,
                       flagPlotWrite = flagPlotWrite,
                       dirPlot = dirPlot,
                       fplot = fplot,          
                       fs = fs,
                       fo = fo);

	return (inparam);
	# ...................................................................................

}

# =================================================================================================
# . End of InparamReg.getCommandLineBasicCoxCvWithCovBoot.
# =================================================================================================
