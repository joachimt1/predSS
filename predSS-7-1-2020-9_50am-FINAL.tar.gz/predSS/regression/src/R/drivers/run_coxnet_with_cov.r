# =======================================================================================================
# . run_coxnet_with_cov : computes a Cox proportional hazard model on the indicated training set,
# . -------------------   using a mixture of gene-by-gene feature selection and the glmnet lasso.
# .                       Note that I am providing for two levels of (possibly redundant) feature selection.
# .
# . This version allows for an additional external covariate.
# .......................................................................................................
# . See the function:
# .
# .                   Inparamreg.getCommandLineCoxnetWithCov
# .
# . in module:
# .
# .                   InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Type :
# .
# .     run_coxnet_with_cov("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_coxnet_with_cov <- function(commandString)
{

	# .................................................................................
      	cat(" ..........  Begin execution of program: run_coxnet_with_cov\n");
   	# .................................................................................

        
        # ...............................................................
        options(warn = 1)  # Warning messages will be printed immediately.
        # ...............................................................
        

   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_coxnet_with_cov", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineCoxnetWithCov(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read the input data files to get the input data matrices :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");

        dfX = DataFrame.readDataMatrixFread(inparam$fx);  # Numerical data.
        dfE = read.table(file = inparam$fe);              # Experimental design.
   	# ..........................................................................................



   	# ..........................................................................................
        # . Check consistency of input data matrices :
   	# ..........................................................................................
        msg = Glmnet.checkDataMatricesForCoxWithCov(dfX, dfE, inparam);        

        if (msg != 'ok') {
          cat(msg, "\n", sep = "");
          stop();
        }
   	# ..........................................................................................



   	# ..........................................................................................
        # . Extract the training set from the input data matrices.
        # . Note that if tTrain = NONE, then all instances are used in
        # . training set.
   	# ..........................................................................................
        if (inparam$tTrain != 'NONE') {
          dfXTrain = dfX[dfE[[inparam$tTrain]] == 'train', ]; 
          dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ];
          # ....................................................................
          # . Fix for the special case of just one column in the data matrix :
          # ....................................................................       
          if (ncol(dfX) == 1) {
            dfXTrain = as.matrix(dfXTrain);
          }
          # ....................................................................                 
        } else {
          dfXTrain = dfX;
          dfETrain = dfE;
        }
        # .........................................................................................
        

        
   	# ..........................................................................................
        # . Extract the test set from the input data matrices, provided tTest != NONE.
        # . Otherwise set to NULL.
   	# ..........................................................................................
        if (inparam$tTest != 'NONE') {
          dfXTest = dfX[dfE[[inparam$tTest]] == 'test', ]; 
          dfETest = dfE[dfE[[inparam$tTest]] == 'test', ];

          atTest = dfETest[[inparam$tTime]];         # Survival times.
          asTest = dfETest[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
          azTest = dfETest[[inparam$tCov]];          # External covariate.
          # ....................................................................
          # . Fix for the special case of just one column in the data matrix :
          # ....................................................................       
          if (ncol(dfX) == 1) {
            dfXTest = as.matrix(dfXTest);
          }
          # ....................................................................                 
        } else {
          dfXTest = NULL;
          dfETest = NULL;

          atTest = NULL;
          asTest = NULL;
          azTest = NULL;          
        }
        # .........................................................................................
        

        
        
   	# ...............................................................................................
        # . >> COMPUTATION :
        # .
        # . Compute the Cox proportional hazard model on the training set :
        # ...............................................................................................
        cat(" ..........  Compute the Cox proportional hazard model on the training set.\n");

        atTrain = dfETrain[[inparam$tTime]];         # Survival times.
        asTrain = dfETrain[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
        azTrain = dfETrain[[inparam$tCov]];          # Additional external covariate.        
        
        gl = Glmnet.computeCoxWithCov(at = atTrain,
                                      as = asTrain,
                                      az = azTrain,                    
                                      dfX = dfXTrain,
                                      flagCenter = inparam$flagCenter,
                                      flagFs = inparam$flagFs,          
                                      typePval = inparam$typePval,          
                                      mtop = inparam$mtop,
                                      alpha = inparam$alpha,
                                      alambda = NULL,
                                      lambda = inparam$lambda,          
                                      flagVerbose = TRUE);
        # ......................................................................................
        # . Computation is done :
        # ......................................................................................        
        cat(" ..........  Computation done.\n");
        # ...............................................................................................



        # ...............................................................................................
        # . Go to training and test sets, compute the log-hazard ratios :
        # ...............................................................................................
        dsTrain = Glmnet.computeSignificanceOnCov(gl,
                                                  dfXTrain, atTrain, asTrain, azTrain,
                                                  inparam$hRC);

        if (inparam$tTest != 'NONE') {
          dsTest = Glmnet.computeSignificanceOnCov(gl,
                                                   dfXTest, atTest, asTest, azTest,
                                                   inparam$hRC);          
        } else {
          dsTest = NULL;
        }
        # ...............................................................................................        

        

   	# .............................................................................
        # . >>OUTPUT FILES :
        # . Write the statistical summary :
   	# .............................................................................
        GlmnetDiag.writeCoxSummaryWithCov(gl, dsTrain, dsTest, inparam$fs);
   	# .............................................................................        
        # . Write the estimated hazard ratios for *all* samples, including those
        # . not in the training set.
        # .............................................................................
        az = dfE[[inparam$tCov]];
        GlmnetDiag.writeCoxDataWithCov(gl, dfX, dfE, az, inparam$hRC, inparam$fo);
        # .............................................................................
        # . If indicated, write the data matrix for the selected genes :
        # .
        # . Note that we are subsetting the entire input data matrix,
        # . not just the training set. Also note that we are conserving the original,
        # . relative order of genes, so that they are *not* in the order
        # . given by indexSel.
        # ..............................................................................
        if (inparam$flagFsOut == 'yes') {        
          p = ncol(dfX);                         # Total number of genes.
          bufMask = (1:p) %in% gl$indexSelACT;   # Indicator function for final selected indices.
        
          dfXSel.noReorder = dfX[ , bufMask];    # Complete data matrix, subsetted to the selected genes.

          DataFrame.writeDataMatrix(dfXSel.noReorder, inparam$fv);
          cat(" ..........  Wrote subsetted data matrix to file: ", inparam$fv, "\n", sep = "");
        }
        # ...............................................................................................


        
   	# .............................................................................
        # . >>PLOTS :
   	# .............................................................................        
        if (inparam$flagPlot == 'yes') {
          # ............................................................................
          # . If flagPlotWrite = 'no', generate plots interactively.
          # . If flagPlotWrite = 'yes', save the plots one-by-one as jpeg files in 
          # . the indicated directory, and create an html file which refers to the
          # . images.
          # ............................................................................          
          sp = GlmnetDiag.plotCoxWithCov(at = atTrain, as = asTrain, az = azTrain,
                                         dfX = dfXTrain, gl = gl,
                                         hRC = inparam$hRC,
                                         flagWrite = inparam$flagPlotWrite,
                                         dirName = inparam$dirPlot, stemName = "temp-cox");
          # ............................................................................
          # . Plot test data if it was also specified :
          # ............................................................................
          if (inparam$tTest != 'NONE') {
            spTest = GlmnetDiag.plotCoxWithCovOnTest(at = atTest, as = asTest, az = azTest,
                                                     dfX = dfXTest, gl = gl,
                                                     hRC = inparam$hRC,
                                                     flagWrite = inparam$flagPlotWrite,
                                                     dirName = inparam$dirPlot, stemName = "temp-cox");

            sp = SuperPcDiag.addPlots(sp, spTest);            # Add the plots for the test data.
          }                      
          # ............................................................................
          # . Generate html file with plot file pointers:
          # ............................................................................          
          if (inparam$flagPlotWrite == 'yes') {
            SuperPcDiag.writePlotFile(sp = sp, fplot = inparam$fplot);
          }
          # ............................................................................          
        }
   	# .............................................................................

        
	# ............................................................
      	cat(" ..........  End of execution of run_coxnet_with_cov.\n");
   	# ............................................................


        # .................................................
        options(warn = 0)     # Reset warnings to default.
        # .................................................

        
   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================
