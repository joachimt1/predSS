# =======================================================================================================
# . run_generate_sim_data_cox_with_cov : generates files containing simulated data for testing out the
# . ------------------------------------   Cox models for supervised principal components. This version
# .                                        includes dependency on an external covariate.
# .                
# .......................................................................................................
# . See the function:
# .
# .                   Inparamreg.getCommandLineGenerateSimDataCoxWithCov
# .
# . in module:
# .
# .                   InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Useage:
# .
# .     run_generate_sim_data_cox_with_cov("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

#xxx library(MASS);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_generate_sim_data_cox_with_cov <- function(commandString)
{

	# .................................................................................
      	cat(" ..........  Begin execution of program: run_generate_sim_data_cox_with_cov\n");
   	# .................................................................................


        
   	# ...................................................................................................
	# . Get the command line parameters:
   	# ...................................................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_generate_sim_data_cox_with_cov", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineGenerateSimDataCoxWithCov(argv);

	if (inparam$status == "exit") {
	  return(0);                                     # This exits if no command line arguments provided.
	}
   	# ...................................................................................................



	# .....................................................................................................
	# . Generate the simulated data set :
	# .....................................................................................................
        dTrain = SuperPcSim.generateDataCoxWithCov(nTwoRegion = inparam$nTwoRegion,
                                                   xTwoRegion = inparam$xTwoRegion,
                                                   sigmaTwoRegion = inparam$sigmaTwoRegion,          
                                                   nFourRegion = inparam$nFourRegion,       
                                                   xFourRegionL = inparam$xFourRegionL,
                                                   xFourRegionR = inparam$xFourRegionR,          
                                                   sigmaFourRegion = inparam$sigmaFourRegion,          
                                                   nb = inparam$nb,                
                                                   rngSeed = inparam$rngSeed,           
                                                   hazardPanel = inparam$hazardPanel,       
                                                   betaSim1 = inparam$betaSim1,          
                                                   betaSim2 = inparam$betaSim2,          
                                                   betaSim3 = inparam$betaSim3);   
	# .....................................................................................................
	# . Display the gene expression data matrix :
	# .....................................................................................................
        buf = readline(">>Enter a carriage return to get first plot: ");    # Pause.

        Abuf = dTrain$A;
        
        if (nrow(Abuf) == 1) {
          Abuf = rbind(Abuf, Abuf);     # Trick to get to a single gene to display in the heat map.
        }         
        
        SuperPcDiag.plotGeneDataMatrix(ax = Abuf, caption = "Training set data matrix");
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
	# .....................................................................................................
	# . Display profiles from each region :
	# .....................................................................................................
        par(mfrow = c(2,1));
        
        if (inparam$nTwoRegion > 0) {
          xbuf = dTrain$dfX[ , 1];
          plot(xbuf, xlab = 'Index(sample)', ylab = 'gene expression', main = 'two-region gene 1');
        }

        if (inparam$nFourRegion > 0) {
          j1 = inparam$nTwoRegion + 1;
          xbuf = dTrain$dfX[ , j1];
          plot(xbuf, xlab = 'Index(sample)', ylab = 'gene expression', main = 'four-region gene 1');
        }        

        par(mfrow = c(1,1));

        buf = readline(">>Enter a carriage return to continue: ");    # Pause.        
	# .....................................................................................................
	# . Display survival times and generating covariate :
	# .....................................................................................................
        SuperPcSim.plotSurvivalTimesCoxWithCov(dTrain, inparam$hazardPanel,
                                               inparam$betaSim1, inparam$betaSim2, inparam$betaSim3);
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.        
	# .....................................................................................................




	# ....................................................................................
        # . Write to output files :
	# ....................................................................................
        dfXT = as.data.frame(t(dTrain$dfX));
        DataFrame.write(dfXT, inparam$fdv);
        DataFrame.write(dTrain$dfE, inparam$fe);

        cat(" ..........  Gene expression data written to file : ", inparam$fdv, "\n", sep = "");
        cat(" ..........  Survival data written to file : ", inparam$fe, "\n", sep = "");        
	# ....................................................................................

        

	# ...............................................................................
      	cat(" ..........  End of execution of run_generate_sim_data_cox_with_cov.\n");
   	# ...............................................................................


   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================
