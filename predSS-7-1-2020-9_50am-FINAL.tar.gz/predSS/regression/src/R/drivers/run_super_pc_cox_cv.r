# =======================================================================================================
# . run_super_pc_cox_cv : Does cross-validation of a Cox proportional hazard model on the indicated 
# . -------------------   training set, using supervised principal components analysis based on
# .                       feature selection and singular value decomposition.
# .
# .......................................................................................................
# . See the function:
# .
# .                   Inparamreg.getCommandLineSuperPcCoxCv
# .
# . in module:
# .
# .                   InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Type :
# .
# .     run_super_pc_cox_cv("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_super_pc_cox_cv <- function(commandString)
{

	# .................................................................................
      	cat(" ..........  Begin execution of program: run_super_pc_cox_cv\n");
   	# .................................................................................

        

   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_super_pc_cox_cv", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineSuperPcCoxCv(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read the input data files to get the input data matrices :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");

        dfX = DataFrame.readDataMatrix(inparam$fx);  # Numerical data.
        dfE = read.table(file = inparam$fe);         # Experimental design.
   	# ..........................................................................................



   	# ..........................................................................................
        # . Check consistency of input data matrices :
   	# ..........................................................................................        
        msg = SuperPc.checkDataMatricesForCoxCv(dfX, dfE, inparam);

        if (msg != 'ok') {
          cat(msg, "\n", sep = "");
          stop();
        }
   	# ..........................................................................................



   	# ..........................................................................................
        # . Extract the training set data from the input data matrices :
   	# ..........................................................................................            
        if (inparam$tTrain != 'NONE') {
          dfXTrain = dfX[dfE[[inparam$tTrain]] == 'train', ]; 
          dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ];
        } else {
          dfXTrain = dfX;
          dfETrain = dfE;
        }

        atTrain = dfETrain[[inparam$tTime]];         # Survival times.
        asTrain = dfETrain[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).

        if (inparam$methodSplit == 'given') {
          af = dfETrain[[inparam$tSplit]];           # Assigns to given train and test categories.
        } else if ((inparam$methodSplit == 'vfold')
                   || (inparam$methodSplit == 'vfoldStrict')) {
          af = rep('NONE', times = length(atTrain)); # Dummy.
        }
        # .........................................................................................
        


        
   	# ..................................................................................................
   	# . >> COMPUTATION :
   	# ..................................................................................................
      	cat(" ..........  Cross-validation with split method = ", inparam$methodSplit, "\n", sep = "");
     	cat(" ..........  Parameter scanned = ", inparam$parameterScan, "\n", sep = "");        

        cv = SuperPcCv.crossValidateCox(at = atTrain,
                                        as = asTrain,
                                        dfX = dfXTrain,
                                        methodSplit = inparam$methodSplit,
                                        af = af,
                                        ft = inparam$ft,
                                        ncv = inparam$ncv,
                                        rngSeed = inparam$rngSeed,
                                        scoreType = inparam$scoreType,
                                        mtop = inparam$mtop,
                                        K = inparam$K,
                                        parameterScan = inparam$parameterScan,
                                        amtop = inparam$amtop,
                                        aK = inparam$aK,
                                        flagVerbose = TRUE);
   	# ....................................................................................



  	# ................................................
        # . >>OUTPUT FILES :        
   	# ................................................
        #xxx SuperPcDiag.writeCoxCvSummary(cv, inparam$fs);                
        SuperPcDiag.writeCoxCv(cv, inparam$fs);        
   	# ................................................

        
  	# ..............................................................................
        # . >>PLOTS :
   	# ..............................................................................
        if (inparam$flagPlot == 'yes') {
          # ............................................................................
          # . If flagPlotWrite = 'no', generate plots interactively.
          # . If flagPlotWrite = 'yes', save the plots one-by-one as jpeg files in 
          # . the indicated directory, and create an html file which refers to the
          # . images.
          # ............................................................................          
          sp = SuperPcDiag.plotCoxCv(cv,
                                     flagWrite = inparam$flagPlotWrite,
                                     dirName = inparam$dirPlot, stemName = "temp-cox");
          # ............................................................................
          # . Generate html file with plot file pointers:
          # ............................................................................          
          if (inparam$flagPlotWrite == 'yes') {
            SuperPcDiag.writePlotFile(sp = sp, fplot = inparam$fplot);
          }
          # ............................................................................          
        }        
  	# ..............................................................................

        
	# ............................................................
      	cat(" ..........  End of execution of run_super_pc_cox_cv.\n");
   	# ............................................................


   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================
