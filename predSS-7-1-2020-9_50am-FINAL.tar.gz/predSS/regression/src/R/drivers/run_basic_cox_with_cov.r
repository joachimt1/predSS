# =======================================================================================================
# . run_basic_cox_with_cov : computes a Cox proportional hazard model on the indicated training set.
# . ----------------------   Uses explicit gene expression values as covariates (no supervised 
# .                          principal components).
# .
# . This version allows for an additional external covariate.
# .......................................................................................................
# . See the function:
# .
# .                   Inparamreg.getCommandLineBasicCoxWithCov
# .
# . in module:
# .
# .                   InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Type :
# .
# .     run_basic_cox_with_cov("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_basic_cox_with_cov <- function(commandString)
{

	# .................................................................................
      	cat(" ..........  Begin execution of program: run_basic_cox_with_cov\n");
   	# .................................................................................

        
        # ...............................................................
        options(warn = 1)  # Warning messages will be printed immediately.
        # ...............................................................
        

   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_basic_cox_with_cov", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineBasicCoxWithCov(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read the input data files to get the input data matrices :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");

        dfX = DataFrame.readDataMatrixFread(inparam$fx);  # Numerical data.
        dfE = read.table(file = inparam$fe);              # Experimental design.
   	# ..........................................................................................


        

   	# ..........................................................................................
        # . Filter the genes on a qualifier list, if indicated :
   	# ..........................................................................................
        aqEff = colnames(dfX);                         # Default gene list.
        
        if (inparam$flagQlist == 'yes') {
          aq = File.readQlist(inparam$fq);
          dfX = DataFrame.filterOnQlist(dfX, aq);
          aqEff = colnames(dfX);                       # Effective gene list.
        }

        nqEff = length(aqEff);
        cat(" ..........  The Cox model will be built using nqEff = ", nqEff, " genes.\n", sep = "");
   	# ..........................................................................................


        
   	# ..........................................................................................
        # . Check consistency of input data matrices :
   	# ..........................................................................................
        msg = BasicCox.checkDataMatricesForCoxWithCov(dfX, dfE, inparam);        

        if (msg != 'ok') {
          cat(msg, "\n", sep = "");
          stop();
        }
   	# ..........................................................................................



   	# ..........................................................................................
        # . Extract the training set from the input data matrices.
        # . Note that if tTrain = NONE, then all instances are used in
        # . training set.
   	# ..........................................................................................
        if (inparam$tTrain != 'NONE') {
          dfXTrain = dfX[dfE[[inparam$tTrain]] == 'train', ]; 
          dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ];
          # ....................................................................
          # . Fix for the special case of just one column in the data matrix :
          # ....................................................................       
          if (ncol(dfX) == 1) {
            dfXTrain = as.matrix(dfXTrain);
            colnames(dfXTrain) = colnames(dfX);
          }
          # ....................................................................       
        } else {
          dfXTrain = dfX;
          dfETrain = dfE;
        }
        # .........................................................................................

        

   	# ..........................................................................................
        # . Extract the test set from the input data matrices, provided tTest != NONE.
        # . Otherwise set to NULL.
   	# ..........................................................................................
        if (inparam$tTest != 'NONE') {
          dfXTest = dfX[dfE[[inparam$tTest]] == 'test', ]; 
          dfETest = dfE[dfE[[inparam$tTest]] == 'test', ];

          atTest = dfETest[[inparam$tTime]];         # Survival times.
          asTest = dfETest[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
          azTest = dfETest[[inparam$tCov]];          # External covariate.
          # ....................................................................
          # . Fix for the special case of just one column in the data matrix :
          # ....................................................................       
          if (ncol(dfX) == 1) {
            dfXTest = as.matrix(dfXTest);
            colnames(dfXTest) = colnames(dfX);
          }
          # ....................................................................                 
        } else {
          dfXTest = NULL;
          dfETest = NULL;

          atTest = NULL;
          asTest = NULL;
          azTest = NULL;          
        }
        # .........................................................................................
        
        
 
        
   	# ...............................................................................................
        # . >> COMPUTATION :
        # .
        # . Compute the Cox proportional hazard model on the training set :
        # ...............................................................................................
        cat(" ..........  Compute the Cox proportional hazard model on the training set.\n");

        atTrain = dfETrain[[inparam$tTime]];         # Survival times.
        asTrain = dfETrain[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
        azTrain = dfETrain[[inparam$tCov]];          # Additional external covariate.        

        bc = BasicCox.computeCoxWithCov(at = atTrain,
                                        as = asTrain,
                                        az = azTrain,                    
                                        dfX = dfXTrain,
                                        flagCenter = inparam$flagCenter);
        # ......................................................................................
        # . Compute baseline hazard, and add to current basic Cox model :
        # ......................................................................................        
        bh = BasicCox.computeBaselineHazardNoTiesWithCov(at = atTrain,
                                                         as = asTrain,
                                                         az = azTrain,
                                                         cSel = bc,
                                                         dfXSel = dfXTrain);

        bc$bh = bh;                                      # Add or set bh member
        # ......................................................................................
        # . Computation is done :
        # ......................................................................................        
        cat(" ..........  Computation done.\n");
        # ...............................................................................................




        # ...............................................................................................
        # . Go to training and test sets, compute the log-hazard ratios :
        # ...............................................................................................
        dsTrain = BasicCox.computeSignificanceOnCov(bc,
                                                    dfXTrain, atTrain, asTrain, azTrain,
                                                    inparam$hRC);

        if (inparam$tTest != 'NONE') {
          dsTest = BasicCox.computeSignificanceOnCov(bc,
                                                     dfXTest, atTest, asTest, azTest,
                                                     inparam$hRC);          
        } else {
          dsTest = NULL;
        }
        # ...............................................................................................        

        

   	# .............................................................................
        # . >>OUTPUT FILES :
        # . Write the statistical summary :
   	# .............................................................................
        BasicCoxDiag.writeCoxSummaryWithCov(bc, dsTrain, dsTest, inparam$fs);
   	# .............................................................................        
        # . Write the estimated hazard ratios for *all* samples, including those
        # . not in the training set.
        # .............................................................................
        az = dfE[[inparam$tCov]];                         # External covariate.        
        BasicCoxDiag.writeCoxDataMatrixWithCov(bc, dfX, dfE, az, inparam$hRC, inparam$fo);
   	# .............................................................................
        # . Write the genes actually used, and the corresponding offsets used :
   	# .............................................................................
        BasicCoxDiag.writeGeneOffsets(bc, inparam$fqOut);
   	# .............................................................................        



        
        
   	# .............................................................................
        # . >>PLOTS :
   	# .............................................................................        
        if (inparam$flagPlot == 'yes') {
          # ............................................................................
          # . If flagPlotWrite = 'no', generate plots interactively.
          # . If flagPlotWrite = 'yes', save the plots one-by-one as jpeg files in 
          # . the indicated directory, and create an html file which refers to the
          # . images.
          # ............................................................................          
          sp = BasicCoxDiag.plotCoxWithCov(at = atTrain, as = asTrain, az = azTrain,
                                           dfX = dfXTrain, bc = bc,
                                           hRC = inparam$hRC,
                                           flagWrite = inparam$flagPlotWrite,
                                           dirName = inparam$dirPlot, stemName = "temp-cox");
          # ............................................................................
          # . Plot test data if it was also specified :
          # ............................................................................
          if (inparam$tTest != 'NONE') {
            spTest = BasicCoxDiag.plotCoxWithCovOnTest(at = atTest, as = asTest, az = azTest,
                                                       dfX = dfXTest, bc = bc,
                                                       hRC = inparam$hRC,
                                                       flagWrite = inparam$flagPlotWrite,
                                                       dirName = inparam$dirPlot, stemName = "temp-cox");

            sp = SuperPcDiag.addPlots(sp, spTest);            # Add the plots for the test data.
          }            
          # ............................................................................
          # . Generate html file with plot file pointers:
          # ............................................................................          
          if (inparam$flagPlotWrite == 'yes') {
            SuperPcDiag.writePlotFile(sp = sp, fplot = inparam$fplot);
          }
          # ............................................................................          
        }
   	# .............................................................................

        
	# ............................................................
      	cat(" ..........  End of execution of run_basic_cox_with_cov.\n");
   	# ............................................................


        # .................................................
        options(warn = 0)     # Reset warnings to default.
        # .................................................

        
   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================
