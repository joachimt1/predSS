# =======================================================================================================
# . run_roc_on_coxph : post-processes a COXPH output file resulting from Cox models
# . ----------------   with a binary {0, 1}  external covariate. Generates ROCs, finds optimal threshold
# .                    on differential log-hazard ratio, and produces plots.
# .                          
# .
# . This version allows for an additional external covariate.
# .......................................................................................................
# . See the function:
# .
# .                   Inparamreg.getCommandLineRocOnCoxph()
# .
# . in module:
# .
# .                   InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Type :
# .
# .     run_roc_on_coxph("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_roc_on_coxph <- function(commandString)
{

	# ............................................................................
      	cat(" ..........  Begin execution of program: run_roc_on_coxph\n");
   	# ............................................................................

        
        # ...............................................................
        #xxx options(warn = 1);  # Warning messages will be printed immediately.
        options(warn = -1);      # Warning messages will be ignored.
        # ...............................................................
        

   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_roc_on_coxph", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineRocOnCoxph(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read both numerical and factor data from one file :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");

        dfX = read.table(file = inparam$fx, header = TRUE, comment.char = "");
   	# ..........................................................................................



        
   	# ..........................................................................................
        # . Check consistency of input data matrix :
   	# ..........................................................................................
        msg = SuperPc.checkDataMatricesForRocOnCoxph(dfX, inparam);        

        if (msg != 'ok') {
          cat(msg, "\n", sep = "");
          stop();
        }
   	# ..........................................................................................



   	# ..................................................................
        # . Filter to test or train instances, if a filter was specified :
   	# ..................................................................
        if (inparam$flagFilter == 'yes') {
          dfX = dfX[dfX[[inparam$tFilter]] == inparam$filterValue, ];
        }
   	# ..................................................................


        

   	# ..........................................................................................
        # . Extract the required variables from the input data frame :
   	# ..........................................................................................
        at = dfX[[inparam$tTime]];         # Survival times.
        as = dfX[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
        az = dfX$zActual;                  # External covariate z.
        
        aloghR = dfX$loghR_zactual;        # Predicted loghR for actual values of z.
        aloghR0 = dfX$loghR_z0;            # Predicted loghR for z = 0.
        aloghR1 = dfX$loghR_z1;            # Predicted loghR for z = 1.
        # .........................................................................................
        
 
        
   	# ...............................................................................................
        # . >> COMPUTATION :
        # . Compute the ROCs :
        # ...............................................................................................
        cat(" ..........  Compute the ROCs on the input data.\n");

        if (inparam$flaghRC == 'internal') {        
          cCov = SuperPc.computeCoxWithCovSignificanceOnSplit(at, as, az,
                                                              aloghR, aloghR0, aloghR1,
                                                              flagComputeRES = TRUE);            
        } else if (inparam$flaghRC == 'external') {
          cCov = SuperPc.computeCoxWithCovSignificanceOnSplitEXT(at, as, az,
                                                                 aloghR, aloghR0, aloghR1,
                                                                 inparam$hRCExt,
                                                                 flagComputeRES = TRUE);          
        }
        # ...............................................................................................


        
        # ...............................................................................................        
        # . Package into a cross-validation (cv) object :
        # ...............................................................................................
        cv = SuperPc.packagecCovIntoCv(cCov, at, as, az, aloghR, aloghR0, aloghR1);
        cat(" ..........  Computation done.\n");
        # ...............................................................................................


        # ......................................................................................
        # . Prognostic estimates :
        # . Perform permutation resampling if requested.
        # ......................................................................................
        if (inparam$flagPermProg == 'yes') {
          pgALL = SuperPcBoot.permuteOnProgIndexALLCov(at = at,
                                                       as = as,
                                                       az = az,
                                                       aloghR = aloghR,
                                                       nperm = inparam$npermProg,
                                                       rngSeed = inparam$rngSeedProg);
        }
        # .......................................................................................
        

        

        # ......................................................................................
        # . Predictive estimates :
        # . Perform bootstrap or permutation resampling if requested.
        # ......................................................................................
        if (inparam$flagBoot == 'yes') {
          bs = SuperPcBoot.computeCoxWithCovSignificanceOnSplit(at = at,
                                                                as = as,
                                                                az = az,
                                                                aloghR = aloghR,
                                                                aloghR0 = aloghR0,
                                                                aloghR1 = aloghR1,
                                                                flaghRC = inparam$flaghRC,
                                                                hRCExt = inparam$hRCExt,
                                                                nboot = inparam$nboot,
                                                                rngSeed = inparam$rngSeed,
                                                                resamplingType = inparam$resamplingType);
        }
        # .......................................................................................

        
        

   	# .............................................................................
        # . >>OUTPUT FILES :
        # . General statitics and optimal values :
   	# .............................................................................
        if (inparam$fs != 'NONE') {
          # ......................................................................................
          # . Write general prognostic/predictive information :
          # ......................................................................................          
          cat(" ..........  Calling BasicCoxDiag.generateCoxCvWithCovSummarySingle.\n", sep = "");

          FS = file(inparam$fs, "w");
          
          txtSummary = BasicCoxDiag.generateCoxCvWithCovSummarySingle(cv);
          cat(txtSummary, file = FS);
          cat("\n", file = FS);
          # ......................................................................................
          # . Write the more specific patient selection matrix :
          # ......................................................................................          
          txtPSM = BasicCoxDiag.formatCoxWithCovPSM(cv, fmtType = 'f');
          cat(txtPSM, file = FS);
          cat("\n", file = FS);
          # ......................................................................................
          # . Close file.
          # ......................................................................................                    
          close(FS);

          cat(" ..........  Wrote general statistics to file: ",  inparam$fs, "\n", sep = "");
          # ......................................................................................          
        }
  	# ............................................................................
        # . Permutation statistics for prognostic estimates:
        # . add the permutation statistics to the stats file.
  	# ............................................................................
        if (inparam$flagPermProg == 'yes') {
          BasicCoxDiag.writeCoxWithCovPermProg(pgALL, inparam$fs, flagAppend = 'yes');
        }           
  	# ............................................................................
        # . Bootstrap statistics for predictive estimates:
        # . add the bootstrap statistics to the stats file.
  	# ............................................................................
        if (inparam$flagBoot == 'yes') {
          BasicCoxDiag.writeCoxWithCovBootstrap(bs, inparam$fs, flagAppend = 'yes');
        }
   	# .............................................................................
        # . Write copy of COXPH input file, but augmented with a response category
        # . column (R , S) = (0, 1):
   	# .............................................................................        
        dfXRes =  BasicCoxDiag.addResponseGroup(dfX, inparam$hRCExt);

        DataFrame.writeFlat(dfXRes, fo = inparam$fo);

        cat(" ..........  Wrote output COXPH file with responseGroup column to file: ",
            inparam$fo, "\n", sep = "");
   	# .............................................................................

        


  	# ..............................................................................
        # . >>PLOTS :
   	# ..............................................................................
        if (inparam$flagPlot == 'yes') {
          # ............................................................................
          # . If flagPlotWrite = 'no', generate plots interactively.
          # . If flagPlotWrite = 'yes', save the plots one-by-one as jpeg files in 
          # . the indicated directory, and create an html file which refers to the
          # . images.
          # ............................................................................          
          sp = SuperPcDiag.plotCoxCvWithCovSingle(cv = cv,
                                                  hRC = inparam$hRCExt,
                                                  flagWrite = inparam$flagPlotWrite,
                                                  dirName = inparam$dirPlot, stemName = "temp-cox");
          # ............................................................................
          # . Plot bootstrap resampling output if it was generated :
          # ............................................................................
          if (inparam$flagBoot == 'yes') {
            spBoot = SuperPcDiag.plotCoxWithCovBootstrap(bs,
                                                         flagWrite = inparam$flagPlotWrite,
                                                         dirName = inparam$dirPlot, stemName = "temp-cox");

            sp = SuperPcDiag.addPlots(sp, spBoot);             # Add the bootstrap plots.
          }                      
          # ............................................................................
          # . Generate html file with plot file pointers:
          # ............................................................................          
          if (inparam$flagPlotWrite == 'yes') {
            SuperPcDiag.writePlotFile(sp = sp, fplot = inparam$fplot);
          }
          # ............................................................................          
        }        
  	# ..............................................................................

        
        
	# ............................................................
      	cat(" ..........  End of execution of run_roc_on_coxph.\n");
   	# ............................................................


        # .................................................
        options(warn = 0)     # Reset warnings to default.
        # .................................................

        
   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================
