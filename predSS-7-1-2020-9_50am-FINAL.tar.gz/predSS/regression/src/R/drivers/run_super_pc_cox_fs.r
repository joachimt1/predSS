# =======================================================================================================
# . run_super_pc_cox_fs : performs feature selection for the supervised pc Cox model.
# . -------------------   This is a standalone utility that outputs the data matrix susbetted
# .                       to the selected features, but does not generate a Cox model on its own.
# .
# .......................................................................................................
# . See the function:
# .
# .                   Inparamreg.getCommandLineSuperPcCoxFs
# .
# . in module:
# .
# .                   InparamReg.r
# .
# . for details of the command line syntax.
# .
# . Type :
# .
# .     run_super_pc_cox_fs("-use");
# .
# . displays the command line parameters.
# .
# ========================================================================================================

library(survival);

# ========================================================================================================
# . MAIN program:
# ========================================================================================================

run_super_pc_cox_fs <- function(commandString)
{

	# .................................................................................
      	cat(" ..........  Begin execution of program: run_super_pc_cox_fs\n");
   	# .................................................................................

        

   	# ...............................................................................
	# . Get the command line parameters:
   	# ...............................................................................
	if (nchar(commandString) == 0) {
	     argv = commandArgs();          
	} else if (commandString == "-use") {
	     argv = c("run_super_pc_cox_fs", "-use");              # Will just display syntax.
	} else {
	     argv = strsplit(commandString, split="\\s+", perl=TRUE)[[1]];
	}

	inparam = InparamReg.getCommandLineSuperPcCoxFs(argv);

	if (inparam$status == "exit") {
	  return(0);                     # This exits if no command line arguments provided.
	}
   	# ...............................................................................


        
   	# .........................................................................................
        # . Read the input data files to get the input data matrices :
   	# .........................................................................................
      	cat(" ..........  Reading input files.\n");

        dfX = DataFrame.readDataMatrix(inparam$fx);  # Numerical data.
        dfE = read.table(file = inparam$fe);         # Experimental design.
   	# ..........................................................................................



   	# ..........................................................................................
        # . Check consistency of input data matrices :
   	# ..........................................................................................        
        msg = SuperPc.checkDataMatricesForCoxFs(dfX, dfE, inparam);

        if (msg != 'ok') {
          cat(msg, "\n", sep = "");
          stop();
        }
   	# ..........................................................................................



   	# ..........................................................................................
        # . Extract the training set from the input data matrices.
        # . Note that if tTrain = NONE, then all instances are used in
        # . training set.
   	# ..........................................................................................
        if (inparam$tTrain != 'NONE') {
          dfXTrain = dfX[dfE[[inparam$tTrain]] == 'train', ]; 
          dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ];
        } else {
          dfXTrain = dfX;
          dfETrain = dfE;
        }
        # .........................................................................................

 
        
   	# ...............................................................................................
        # . >> COMPUTATION :
        # .
        # . Generate P-values for all the genes, and the feature selection index.
        # ...............................................................................................
        cat(" ..........  Generating P-values and feature selection index.\n");

        atTrain = dfETrain[[inparam$tTime]];         # Survival times.
        asTrain = dfETrain[[inparam$tStatus]];       # Censoring statuses (1 = not censored, 0 = censored).
        
        fs = SuperPc.computeCoxFs(at = atTrain,
                                  as = asTrain,
                                  dfX = dfXTrain,
                                  methodFs = inparam$methodFs,
                                  p0 = inparam$p0,
                                  mtop = inparam$mtop,
                                  flagVerbose = TRUE);

        cat(" ..........  P-values and index generated.\n");
        # ...............................................................................................


        
        # ...............................................................................................
        # . >> SELECTION :
        # .
        # . Subset the P-values array and the input data matrix to the selected features.
        # . Note that we are subsetting the entire input data matrox, not just the training set.
        # . Also note that we are conserving the original, relative order of genes, so that they
        # . are *not* in the order given by indexSel.
        # ...............................................................................................
        p = ncol(dfX);                      # Total number of genes.
        bufMask = (1:p) %in% fs$indexSel;   # Indicator function for selected indices.
        
        dfXSel.noReorder = dfX[ , bufMask]; # Complete data matrix, subsetted to the selected genes.
        apSel.noReorder = fs$ap[bufMask];   # Corresponding P-values.
        # ...............................................................................................

        

   	# .............................................................................
        # . >>OUTPUT FILES :
        # . Write the subsetted data matrix :
   	# .............................................................................
        DataFrame.writeDataMatrix(dfXSel.noReorder, inparam$fo);
        cat(" ..........  Wrote subsetted data matrix to file: ",
            inparam$fo, "\n", sep = "");
   	# .............................................................................        
        # . Write the statistical summary :
        # .............................................................................
        SuperPcDiag.writeCoxFsSummary(fs, inparam$fs);
        # .............................................................................
        # . Write all the P-values into a separate file.
        # .............................................................................
        ac = colnames(dfX);                       # The names of all the genes.
        #xxx dfBuf = cbind(ac, fs$ap);            # The corresponding P-values.
        dfBuf = data.frame(ac = ac, ap = fs$ap);  # The corresponding P-values.        
        colnames(dfBuf) = c('#QUAL', "PVAL");     # Bundle into one data frame.

        DataFrame.writeFlat(dfBuf, inparam$fp);   # Write to file.
        cat(" ..........  Wrote P-values to file: ", inparam$fp, "\n", sep = "");        
   	# .............................................................................

        
   	# .............................................................................
        # . >>PLOTS :
   	# .............................................................................        
        if (inparam$flagPlot == 'yes') {
          # ............................................................................
          # . If flagPlotWrite = 'no', generate plots interactively.
          # . If flagPlotWrite = 'yes', save the plots one-by-one as jpeg files in 
          # . the indicated directory, and create an html file which refers to the
          # . images.
          # ............................................................................          
          sp = SuperPcDiag.plotCoxFs(at = atTrain, as = asTrain, dfX = dfXTrain, fs = fs,
                                     flagWrite = inparam$flagPlotWrite,
                                     dirName = inparam$dirPlot, stemName = "temp-cox");
          # ............................................................................
          # . Generate html file with plot file pointers:
          # ............................................................................          
          if (inparam$flagPlotWrite == 'yes') {
            SuperPcDiag.writePlotFile(sp = sp, fplot = inparam$fplot);
          }
          # ............................................................................           
        }
   	# .............................................................................

        
	# ............................................................
      	cat(" ..........  End of execution of run_super_pc_cox_fs.\n");
   	# ............................................................


   	# ...........
        return (0);
   	# ...........

}

# ========================================================================================================
# . End of MAIN.
# ========================================================================================================
