# =================================================================================================
# . BasicCoxCv.r : functions for cross-validating the basic Cox models (direct dependency on
# . ------------   gene expression profiles as covariates).
# .
# =================================================================================================

library(survival);

# =================================================================================================
# . BasicCoxCv.crossValidateCoxWithCov : cross-validation of the Cox proportional hazard model over 
# . ----------------------------------   multiple splits of the data into training and test sets,
# .                                      with exploration of a range of model parameters.
# .                                      This version is with an external covariate.
# .                                      Direct dependency on gene expression levels as covariates).
# .                              
# .
# .   Syntax:
# .
# .            cv =  BasicCoxCv.crossValidateCoxWithCov(at, as, az, dfX,
# .                                                     methodSplit,
# .                                                     af, ft, ncv,
# .                                                     rngSeed, flagRngSeed,
# .                                                     flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .    flagCenter = 'yes', mean-center the columns (genes) of the input data matrix.
# .                  'no', do not mean-center the columns.
# .
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid). Note that only ONE split is ever
# .                               generated.
# .
# .                   - 'vfold' : use parameter ft (below) to do a vfold
# .                               split of the data matrix. Generate ncv
# .                               independent splits of the data matrix.
# .
# .             - 'vfoldStrict' : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, for methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfold' or 'vfoldStrict'. Allowed: 0 < ft < 1.
# .
# .           ncv = number of independent splots generated, under method 'vfold'.
# .
# .       rngSeed = initial random number seed. Must be integer > 0.
# .
# .   flagRngSeed = if TRUE, set initial random number seed to value rngSeed.
# .                 If FALSE, do not (re)set value.
# .
# .   Out:
# .    cv = list, with members :
# .
# .               alAll = log-likelihoods for entire data set.
# .             alTrain = log-likelihoods for just training set.
# .
# =================================================================================================

BasicCoxCv.crossValidateCoxWithCov  <- function(at, as, az, dfX, flagCenter,
                                                methodSplit,
                                                af, ft, ncv,
                                                rngSeed, flagRngSeed,
                                                flagVerbose)
{

      # ...........................................................................
      cat(" ..........  Entry in BasicCoxCv.crossValidateCoxWithCov.\n");
      # ...........................................................................


      
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.            
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (nt != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCov: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCov: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      
      if (nf != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCov: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCov: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((methodSplit == 'given')
                || (methodSplit == 'vfoldStrict'));     # methodSplit = vfold is obsolete.
      
      stopifnot(rngSeed > 0);
      stopifnot(flagRngSeed || !flagRngSeed);

      stopifnot((flagCenter == 'yes') || (flagCenter == 'no'));      
      # ...................................................................................


      
      # .......................................................................................
      # . Check on the external covariate :
      # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
      # . Note that this applies only to the cross-validation program, and not to the
      # . feature selection or model building cases.
      # .......................................................................................    
      msgBin = Cox.checkBinary(az);

      if (msgBin != 'ok') {
        cat("ERROR: from BasicCoxCv.crossValidateCoxWithCov:\n");
        cat("External covariate values must all be {0, 1}\n");
        cat(msgBin);
        cat("\n");
        stop();
      }
    # .......................................................................................



      
      # .........................................
      # . Initialize random number generator :
      # .........................................
      if (flagRngSeed) {
        set.seed(rngSeed);
      }
      # .........................................
      

      # ....................................................................
      cat(" ..........  Begin outer cross-validation loop\n", sep = "");
      # ....................................................................



      # ....................................................................................................
      # . >>CROSS-VALIDATION :
      # . Generate ncv independent splits of the data, and compute log-likelihoods for the designated
      # . range of the chosen parameter.
      # .
      # . >>PREAMBLE :
      # ....................................................................................................
      if (methodSplit == 'given') {
        ncvHere = 1;                        # We are using only the designated split in the data.
        aIndexSplit = NULL;                 # Will not be needed.        
      } else if (methodSplit == 'vfold') {
        ncvHere = ncv;                      # Generate all ncv independent samplings.
        aIndexSplit = NULL;                 # Will not be needed.                
      } else if (methodSplit == 'vfoldStrict') {
        cSplit = Stat.generateSplitsForVfold(n = n, ft = ft, flagRandom = TRUE);  # Generate truly disjoint groups.
        ncvHere = cSplit$ncv;
        aIndexSplit = cSplit$aIndexSplit;
      }
      # ....................................................................................................
      # . Begin cross-validation below :
      # ....................................................................................................      
      cat(" ..........  Total number of steps: ncvHere = ", ncvHere, "\n", sep = "");
      cat(" ..........  Start loop.\n", sep = "");            
      # ....................................................................................................
      # . >> MAIN LOOP :
      # ....................................................................................................
      t1 = proc.time()[3];              # Starting time.
      
      for (icv in 1:ncvHere) {
        cat("Start step = ", icv, " out of ", ncvHere, "\n", sep = "");
        
        ta = proc.time()[3];
        cvS =  BasicCoxCv.crossValidateCoxWithCovSingleSplit(at = at,
                                                             as = as,
                                                             az = az,          
                                                             dfX = dfX,
                                                             flagCenter = flagCenter,
                                                             methodSplit = methodSplit,
                                                             af = af,
                                                             ft = ft,
                                                             icv = icv,
                                                             aIndexSplit = aIndexSplit,
                                                             flagVerbose = flagVerbose);
        tb = proc.time()[3] - ta;
        cat("Processed step = ", icv, " out of ", ncvHere, ", time = ", tb, " s.\n", sep = "");
        # .....................................................................................
        # . Package intermediate results :
        # .....................................................................................
        if (icv == 1) {
          dlTrain = as.data.frame(matrix(cvS$alTrain, nrow = 1));
          dR2Train = as.data.frame(matrix(cvS$aR2Train, nrow = 1));          
          dcvPL = as.data.frame(matrix(cvS$acvPL, nrow = 1));
          dlRatioTest = as.data.frame(matrix(cvS$alRatioTest, nrow = 1));
          dpRatioTest = as.data.frame(matrix(cvS$apRatioTest, nrow = 1));
          dR2Test = as.data.frame(matrix(cvS$aR2Test, nrow = 1));                    
          dMrms = as.data.frame(matrix(cvS$aMrms, nrow = 1));

          aloghRBIG = cvS$aloghRBIG;
          aloghRBIG0 = cvS$aloghRBIG0;
          aloghRBIG1 = cvS$aloghRBIG1;          
          indexTestBIG = cvS$indexTest;          
        } else {
          dlTrain = rbind(dlTrain, cvS$alTrain);
          dR2Train= rbind(dR2Train, cvS$aR2Train);
          dcvPL = rbind(dcvPL, cvS$acvPL);
          dlRatioTest = rbind(dlRatioTest, cvS$alRatioTest);
          dpRatioTest = rbind(dpRatioTest, cvS$apRatioTest);
          dR2Test= rbind(dR2Test, cvS$aR2Test);          
          dMrms = rbind(dMrms, cvS$aMrms);

          aloghRBIG = rbind(aloghRBIG, cvS$aloghRBIG);     # Stack rows.
          aloghRBIG0 = rbind(aloghRBIG0, cvS$aloghRBIG0);  # Stack rows.
          aloghRBIG1 = rbind(aloghRBIG1, cvS$aloghRBIG1);  # Stack rows.
          indexTestBIG = c(indexTestBIG, cvS$indexTest);   # Add to end.          
        }

        ntrain = cvS$ntrain;      # These will be the same 
        ntest = cvS$ntest;        # for each resampling.
        # .....................................................................................   
      }
      # ..................................................................................
      # . Now that all the collected test-sets log-hazard-ratios have been assembled,
      # . restore the original order of sample indices.
      # ..................................................................................      
      aloghRBIG[indexTestBIG, ] = aloghRBIG;        
      aloghRBIG0[indexTestBIG, ] = aloghRBIG0;     
      aloghRBIG1[indexTestBIG, ] = aloghRBIG1;

      aDloghRBIG = aloghRBIG1 - aloghRBIG0;          # Predicted differential log-hazard.
      # ..................................................................................
      # . The outer cross-validation loop is done :
      # ..................................................................................            
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / ncvHere;                               # Time per split.

      cat(" ..........  Outer cross-validation loop done. Total time = ", t2, " s.", sep = "");
      cat(" Time = ", tau, " s per step.\n");      
      # ....................................................................................................      




      # ....................................................................................................
      # . Generate summary stats.
      # .
      # . Log-likelihood for training set alone :
      # .................................................................................................... 
      alTrainQ25 = apply(dlTrain, 2, quantile, probs = 0.25);   # First quartile log-likelihood for training set.
      alTrainMedian = apply(dlTrain, 2, median);                # Median log-likelihood for training set.
      alTrainQ75 = apply(dlTrain, 2, quantile, probs = 0.75);   # Third quartile log-likelihood for training set.
      alTrainSigmaMad = apply(dlTrain, 2, mad);                 # MAD std. deviation of log-likeli for train. set.
      # ....................................................................................................
      # . R2 for training set :
      # .................................................................................................... 
      aR2TrainQ25 = apply(dR2Train, 2, quantile, probs = 0.25);   # First quartile R2 for training set.
      aR2TrainMedian = apply(dR2Train, 2, median);                # Median R2 for training set.
      aR2TrainQ75 = apply(dR2Train, 2, quantile, probs = 0.75);   # Third quartile R2 for training set.
      aR2TrainSigmaMad = apply(dR2Train, 2, mad);                 # MAD std. deviation of R2 for train. set.     
      # ....................................................................................................      
      # . Cross-validated log-likelihood :
      # ....................................................................................................
      acvPLQ25 = apply(dcvPL, 2, quantile, probs = 0.25);       # First quartile cvPL for training set.
      acvPLMedian = apply(dcvPL, 2, median);                    # Median cvPL for training set.
      acvPLQ75 = apply(dcvPL, 2, quantile, probs = 0.75);       # Third quartile cvPL for training set.
      acvPLSigmaMad = apply(dcvPL, 2, mad);                     # MAD std. deviation of cvPL for training set.
      acvPL = apply(dcvPL, 2, sum);                             # The sum is the standard cross-validated pl.
      # ....................................................................................................      
      # . Log-likelihood for test set using training set derived parameters :
      # ....................................................................................................
      alRatioTestQ25 = apply(dlRatioTest, 2, quantile, probs = 0.25);  # First quartile lRatioTest.
      alRatioTestMedian = apply(dlRatioTest, 2, median);               # Median lRatioTest.
      alRatioTestQ75 = apply(dlRatioTest, 2, quantile, probs = 0.75);  # Third quartile lRatioTest.
      alRatioTestSigmaMad = apply(dlRatioTest, 2, mad);                # MAD std. deviation of lRatioTest.

      apRatioTestQ25 = apply(dpRatioTest, 2, quantile, probs = 0.25);  # First quartile lRatioTest.
      apRatioTestMedian = apply(dpRatioTest, 2, median);               # Median lRatioTest.
      apRatioTestQ75 = apply(dpRatioTest, 2, quantile, probs = 0.75);  # Third quartile lRatioTest.
      
      apRatioTestCombine = apply(dpRatioTest, 2, Stat.combinePvalMean);   # Combined P-values for log-likeli.
      # ....................................................................................................
      # . R2 for test set :
      # .................................................................................................... 
      aR2TestQ25 = apply(dR2Test, 2, quantile, probs = 0.25);   # First quartile R2 for test set.
      aR2TestMedian = apply(dR2Test, 2, median);                # Median R2 for test set.
      aR2TestQ75 = apply(dR2Test, 2, quantile, probs = 0.75);   # Third quartile R2 for test set.
      aR2TestSigmaMad = apply(dR2Test, 2, mad);                 # MAD std. deviation of R2 for train. set.
      # ....................................................................................................      
      # . Martingale residuals for the test set, using the training ste derived parameters :
      # ....................................................................................................      
      aMrmsQ25 = apply(dMrms, 2, quantile, probs = 0.25);  # First quartile for r.m.s. of Martingale res.
      aMrmsMedian = apply(dMrms, 2, median);               # Median Mrms.
      aMrmsQ75 = apply(dMrms, 2, quantile, probs = 0.75);  # Third quartile Mrms.
      aMrmsSigmaMad = apply(dMrms, 2, mad);                # MAD std. deviation Mrms.
      # ....................................................................................................


      # ....................................................................................................
      # . Generate single vectors of P-values and hazard ratios for the series of test sets generated 
      # . for all the feature selection levels :
      # ....................................................................................................
      nScan = ncol(aloghRBIG);      # Total number of feature selection levels.

      cat(" ..........  Compute significance of differences in survival times\n");
      cat("             for collected test samples predicted to be sensitive.\n");
      cat("             nScan = ", nScan, " feature selection levels will be tested.\n");            
      # .......................................................................................
      # . Generate nScan vectors and (n * nScan) arrays storing test results for each
      # . feature selection level:
      # .......................................................................................
      apR0 = c();
      ahR0 = c();
      apR1 = c();
      ahR1 = c();            

      cat(">>Progress: ");             # Dots will follow.
      
      for (j in 1:nScan) {
        cCov = SuperPc.computeCoxWithCovSignificanceOnSplit(at, as, az,
                                                            aloghRBIG[ , j],
                                                            aloghRBIG0[ , j],
                                                            aloghRBIG1[ , j],
                                                            flagComputeRES = TRUE);
        apR0[j] = cCov$cs0$pR;
        ahR0[j] = cCov$cs0$hR;

        apR1[j] = cCov$cs1$pR;
        ahR1[j] = cCov$cs1$hR;                
        
        if (j == 1) {
          aDloghRSortBIG = as.data.frame(matrix(cCov$aDloghRSort, nrow = n));
          indexSortBIG = as.data.frame(matrix(cCov$indexSort, nrow = n));
          
          apRSortBIG = as.data.frame(matrix(cCov$apRSort, nrow = n));           # Sensitive P-values.
          ahRSortBIG = as.data.frame(matrix(cCov$ahRSort, nrow = n));           # Sensitive hazard ratios.

          apRSortRESBIG = as.data.frame(matrix(cCov$apRSortRES, nrow = n));     # Resistants P-values.
          ahRSortRESBIG = as.data.frame(matrix(cCov$ahRSortRES, nrow = n));     # Resistants hazard ratios.
          
          aicMinBIG = c(cCov$icMin);
          apRMin = c(cCov$pRMin);
          ahRMin = c(cCov$hRMin);          
          ahRCBIG = c(cCov$hRC);          
        } else {
          aDloghRSortBIG = cbind(aDloghRSortBIG, cCov$aDloghRSort);
          indexSortBIG = cbind(indexSortBIG, cCov$indexSort);
          
          apRSortBIG = cbind(apRSortBIG, cCov$apRSort);                         # Sensitive P-values.
          ahRSortBIG = cbind(ahRSortBIG, cCov$ahRSort);                         # Sensitive hazard ratios.

          apRSortRESBIG = cbind(apRSortRESBIG, cCov$apRSortRES);                # Resistants P-values.     
          ahRSortRESBIG = cbind(ahRSortRESBIG, cCov$ahRSortRES);                # Resistants hazard ratios.          
          
          aicMinBIG = c(aicMinBIG, cCov$icMin);
          apRMin = c(apRMin, cCov$pRMin);       # Minimum P-value at optimal thresholding between z = 1 and z = 0 sub-populations.  
          ahRMin = c(ahRMin, cCov$hRMin);       # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.
          ahRCBIG = c(ahRCBIG, cCov$hRC);       # Optimal cut: subset at predicted
                                                # lambda(z = 1) / lambda(z = 0) <= hRC to minimize the P-value.
        }

        cat(".", sep = "");     # Progress indicator.
      }

      cat("\n");                # We are done.
      # ....................................................................................................


      
      # ....................................................................................................
      # . For quantities arising from the Z=1 to Z=0 comparisons, generate arrays in the
      # . original (unsorted) order 
      # ....................................................................................................
      apRUnSortBIG = apRSortBIG;         # Dummy assign, just to get allocation.
      ahRUnSortBIG = ahRSortBIG;         # Dummy assign, just to get allocation.
      arankBIG = indexSortBIG;           # Dummy assign, just to get allocation.

      apRUnSortRESBIG = apRSortRESBIG;   # Dummy assign, just to get allocation.
      ahRUnSortRESBIG = ahRSortRESBIG;   # Dummy assign, just to get allocation.
      
      nScan = ncol(indexSortBIG);        # Number of tuning parameter levels = number of columns.

      for (j in 1:nScan) {
        apRUnSortBIG[indexSortBIG[ , j], j] = apRSortBIG[ ,j];
        ahRUnSortBIG[indexSortBIG[ , j], j] = ahRSortBIG[ ,j];

        apRUnSortRESBIG[indexSortBIG[ , j], j] = apRSortRESBIG[ ,j];
        ahRUnSortRESBIG[indexSortBIG[ , j], j] = ahRSortRESBIG[ ,j];        
        
        abuf = 1:n;
        arankBIG[indexSortBIG[ , j], j] = abuf;  # For each sample in original order, its rank in terms of DloghR.
      }
      # ....................................................................................................      
      

      

      # ........................................................................................
      # . Package results :
      # ........................................................................................
      cv = list(methodSplit = methodSplit,
                ft = ft,
                ncvHere = ncvHere,             # Actual number of splits.
                rngSeed = rngSeed,
                nScan = cvS$nScan,
                ncv = ncvHere,
                n = n,
                ntrain = ntrain,
                ntest = ntest,
                p = p,
        
                alTrainQ25 = alTrainQ25,
                alTrainMedian = alTrainMedian,
                alTrainQ75 = alTrainQ75,
                alTrainSigmaMad = alTrainSigmaMad,

                aR2TrainQ25 = aR2TrainQ25,
                aR2TrainMedian = aR2TrainMedian,
                aR2TrainQ75 = aR2TrainQ75,
                aR2TrainSigmaMad = aR2TrainSigmaMad,
        
                acvPLQ25 = acvPLQ25,
                acvPLMedian = acvPLMedian,
                acvPLQ75 = acvPLQ75,
                acvPLSigmaMad = acvPLSigmaMad,
                acvPL = acvPL,
        
                alRatioTestQ25 = alRatioTestQ25,
                alRatioTestMedian = alRatioTestMedian,
                alRatioTestQ75 = alRatioTestQ75,
                alRatioTestSigmaMad = alRatioTestSigmaMad,

                apRatioTestQ25 = apRatioTestQ25,
                apRatioTestMedian = apRatioTestMedian,
                apRatioTestQ75 = apRatioTestQ75,
                apRatioTestCombine = apRatioTestCombine,

                aR2TestQ25 = aR2TestQ25,
                aR2TestMedian = aR2TestMedian,
                aR2TestQ75 = aR2TestQ75,
                aR2TestSigmaMad = aR2TestSigmaMad,
        
                aMrmsQ25 = aMrmsQ25,
                aMrmsMedian = aMrmsMedian,
                aMrmsQ75 = aMrmsQ75,
                aMrmsSigmaMad = aMrmsSigmaMad,
                # ................................................................................
                # . >> Prognostic tests :
                # ................................................................................
                apR0 = apR0,                      # nScan : P-values for PROGNOSTIC tests on Z=0 arm only.
                ahR0 = ahR0,                      # nScan : corresponding hR for PROGNOSTIC tests on Z=0 arm only.
        
                apR1 = apR1,                      # nScan : P-values for PROGNOSTIC tests on Z=1 arm only.
                ahR1 = ahR1,                      # nScan : corresponding hR for PROGNOSTIC tests on Z=1 arm only.
                # ................................................................................
                # . >> Time, censoring status and external covariate :
                # ................................................................................
                atBIG = at,                       # n : vector of survival times actually used.
                asBIG = as,                       # n : vector of censoring statuses actually used.
                azBIG = az,                       # n : vector of covariate values actually used.
                # ................................................................................
                # . >> UNSORTED arrays below :
                # ................................................................................
                aloghRBIG = aloghRBIG,            # n * nScan : each column contains predicted loghR for collected test sets, for actual values of Z.
                aloghRBIG0 = aloghRBIG0,          # n * nScan : each column contains predicted loghR for collected test sets, for Z = 0.
                aloghRBIG1 = aloghRBIG1,          # n * nScan : each column contains predicted loghR for collected test sets, for Z = 1.
                aDloghRBIG = aDloghRBIG,          # n * nScan : each column contains loghR(Z=1) - loghR(Z=0).

                apRUnSortBIG = apRUnSortBIG,      # n * nScan : each col. contains Z=1 to Z=0 P-value for threshold at this DloghR.
                ahRUnSortBIG = ahRUnSortBIG,      # n * nScan :  each col. contains Z=1 to Z=0 hR for threshold at this DloghR.
                arankBIG = arankBIG,              # n * nScan : in each col., for each sample in original order, its rank in terms of DloghR.
                # ................................................................................
                # . >> SORTED arrays below :
                # ................................................................................
                aDloghRSortBIG = aDloghRSortBIG,  # n * nScan : each column contains DloghR = loghR(Z=1) - loghR(Z=0), sorted in increasing order.
                indexSortBIG = indexSortBIG,      # n * nScan : each column contains the sort index: aDloghRSort =  aDloghR[indexSort].
                apRSortBIG = apRSortBIG,          # n * nScan : each column contains P-values for Z=1 to Z=0 comparisons, in sort order.
                ahRSortBIG = ahRSortBIG,          # n * nScan : each column contains hR's for Z=1 to Z=0 comparisons, in sort order.


                flagComputeRES = TRUE,            # Indicates whether computation of pR and hR profile has been done for the *resistant* subset.
                apRSortRESBIG = apRSortRESBIG,    # n * nScan : each column contains P-values for Z=1 to Z=0 comparisons, in sort order, for RESISTANT subset.
                ahRSortRESBIG = ahRSortRESBIG,    # n * nScan : each column contains hR's for Z=1 to Z=0 comparisons, in sort order, for RESISTANT subset.        
                # ................................................................................
                # . Quantities obtained for maximum P-values :
                # ................................................................................        
                ahRCBIG = ahRCBIG,                # nScan : optimal hR = hRC, for selecting patients predicted to be sensitive by hR <= hRC filter.        
                aicMinBIG = aicMinBIG,            # nScan : number of patients selected by hR <= hRC filter.
                apRMin = apRMin,                  # nScan : P-value for Z = 1 to Z = 1 comparisons, at best hRC.
                ahRMin = ahRMin                   # nScan : vector.
                # ................................................................................        
        );          

      class(cv) = 'basic.cox.cov.cv';
      # ........................................................................................      

      

      # ...........................................................
      cat(" ..........  Exit BasicCoxCv.crossValidateCoxWithCov.\n");
      # ...........................................................

      
      
      # .............
      return (cv);
      # .............

}

# ========================================================================================================
# . End of  BasicCoxCv.crossValidateCoxWithCov.
# ========================================================================================================      






# =================================================================================================
# . BasicCoxCv.crossValidateCoxWithCovSingleSplit : generates a split of the data into training and test 
# . --------------------------------------------   sets, and then computes log-likelihood-ratios for the 
# .                                                test set for a range of the supervised principal
# .                                                components parameters.
# .
# .   Syntax:
# .
# .      cv =  BasicCoxCv.crossValidateCoxWithCovSingleSplit(at, as, az, dfX,
# .                                                          methodSplit,
# .                                                          af, ft,
# .                                                          icv, aIndexSplit,
# .                                                          flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .    flagCenter = 'yes', mean-center the columns (genes) of the input data matrix.
# .                  'no', do not mean-center the columns.
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid).
# .
# .                   - 'vfold' : use parameter ft (below) to do a vfold
# .                               split of the data matrix.
# .
# .
# .            - 'vfoldStrict'  : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, under methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, under
# .                 methodSplit = 'vfold'. Allowed: 0 < ft < 1.
# .
# .
# .     >> Split counter and groups :
# .
# .           icv = defines the group to be removed under split method 'vfoldStrict'.
# .                 This parameter is ignored otherwise.
# .   aIndexSplit = list of disjoint arrays, defining the groups to be removed for that round
# .                 of cross validation. Used under split method 'vfoldStrict', ignored
# .                 otherwise.
# .
# .     >> General :
# .
# .   flagVerbose = if TRUE, prints progress on computation.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .       parameterScan = parameter that was scanned (mtop or K).
# .               nscan = number of discrete parameter values used.
# .               amtop = array of the nscan mtop values (for parameterScan = mtop).
# .                  aK = array of nscan K values (for parameterScan = K).
# .               alAll = log-likelihoods for entire data set.
# .             alTrain = log-likelihoods for just training set.
# .            aR2Train = R2 for just training set.
# .               acvPL = cross-validated partial likelihood.
# .         alRatioTest = log-likelihood ratio for test set, using training set model parameters.
# .         apRatioTest = P-values for log-likelihood-ratio for test set on train. set.
# .             aR2Test = R2 for just test set.
# .               aMrms = r.m.s. values of Martingale residuals for the test set, evaluated
# .                       using the training set model parameters.
# .
# =================================================================================================

BasicCoxCv.crossValidateCoxWithCovSingleSplit  <- function(at, as, az, dfX, flagCenter,
                                                           methodSplit,
                                                           af, ft,
                                                           icv,
                                                           aIndexSplit,
                                                           flagVerbose)
{

      # ...........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in BasicCoxCv.crossValidateCoxWithCovSingleSplit.\n");
      }
      # ...........................................................................

      
  
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.                  
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (nt != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovSingleSplit: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovSingleSplit: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }
      
      if (nz != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovSingleSplit: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      
      if (nf != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovSingleSplit: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovSingleSplit: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................        
      stopifnot((methodSplit == 'given')
                || (methodSplit == 'vfold')
                || (methodSplit == 'vfoldStrict'));

      if (methodSplit == 'vfold') {
        stopifnot((ft > 0.0) && (ft < 1.0));
      }

      if (methodSplit == 'vfoldStrict') {
        ncvBuf = length(aIndexSplit);

        if (icv > ncvBuf) {
          cat("ERROR: from BasicCoxCv.crossValidateCoxWithCovSingleSplit:\n");
          cat("icv = ", icv, " is greater than the number of groups to be cross-validated, ncv = ", ncvBuf, "\n", sep = "");
          stop();
        }
      }

      stopifnot((flagCenter == 'yes') || (flagCenter == 'no'));      
      # ...................................................................................

      

      # ...................................................................................
      # . Generate the indices for splitting the data into training and test set.
      # .
      # . >> methodSplit = given :
      # ...................................................................................
      if (methodSplit == 'given') {
        # ......................................................................
        # . Check all given entries are 'train', 'test' or 'NONE' :
        # ......................................................................
        indexInvalid = which((af != 'train') & (af != 'test') & (af != 'NONE'));

        if (length(indexInvalid) > 0) {
          msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovSingleSplit: ";        
          msg = paste("The train/test assignment vector contains some values which are neither ", sep = "");
          msg = paste("train, test or NONE. First detected invalid value = ", af[indexInvalid[1]], sep = "");
          stop(msg);
        }
        # ......................................................................
        # . Find the indices for the training and test subsets :
        # ......................................................................
        indexTrain = which(af == 'train');
        indexTest = which(af == 'test');

        ntrain = length(indexTrain);
        ntest = length(indexTest);        
        
        if (ntrain < 2) {
          msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovSingleSplit: ";
          msg = paste("Less than 2 training set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntrain = ", ntrain, sep = "");          
          stop(msg);
        }

        if (ntest < 2) {
          msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovSingleSplit: ";
          msg = paste("Less than 2 test set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntest = ", ntest, sep = "");          
          stop(msg);
        }        
        # ......................................................................        
      }
      # ...................................................................................      
      # . >> methodSplit = vfold :
      # .    The training set and the test set must each have at least 2 elements.
      # .    Note that we require above that n >= 4, so that this is always possible.
      # ...................................................................................
      if (methodSplit == 'vfold') {
        # ......................................................................                
        ntest = floor(n * ft);
        if (ntest < 2) {
          ntest = 2;               # At least 2 elements in the test set.
        }

        n1 = n - 1;
        if (ntest >= n1) {
          ntest = n - 2;           # At least 2 elements in the training set.
        }
            
        indexTest = sample(x = 1:n, size = ntest);
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }
      # ...................................................................................      
      # . >> methodSplit = vfoldStrict :
      # . Under this option the groups were predefined before the function call,
      # . by function Stat.generateSplitsForVfold(). We just retrieve the indices.
      # ...................................................................................
      if (methodSplit == 'vfoldStrict') {
        # ......................................................................                
        indexTest = aIndexSplit[[icv]];
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }      
      # ...................................................................................      



      # ...................................................................................
      # . Generate the training and test subsets :
      # ...................................................................................
      atTrain = at[indexTrain];       # Survival times.
      asTrain = as[indexTrain];       # Censoring statuses (1 = not censored, 0 = censored).
      azTrain = az[indexTrain];       # External covariate.
      dfXTrain = dfX[indexTrain, ];   # Data matrix of gene expression values.

      if (ncol(dfX) == 1) {
        dfXTrain = data.frame(dfXTrain);    # Special case for just one gene. Keep in data frame geometry.
      }

      atTest = at[indexTest];         # Survival times.
      asTest = as[indexTest];         # Censoring statuses (1 = not censored, 0 = censored).
      azTest = az[indexTest];         # External covariate.      
      dfXTest = dfX[indexTest, ];     # Data matrix of gene expression values.

      if (ncol(dfX) == 1) {
        dfXTest = data.frame(dfXTest);     # Special case for just one gene. Keep in data frame geometry.
      }      
      # ...................................................................................


      # ...................................................................................
      # . Adjust for special cases :
      # ...................................................................................
      if (length(indexTest) == 1) {
        dfXTest = matrix(dfXTest, nrow = 1);
      }
      # ...................................................................................      

     
      
      # ....................................................................................................
      # . Column-center the training data then generate univariate Cox scores for
      # . each gene separately.
      # ....................................................................................................
      axm = colMeans(dfXTrain);                                 # Save the p column means. zzzz
      dfXc = scale(dfXTrain, center = FALSE, scale = FALSE);    # Center each gene separately.
      #xxxx  dfXc = dfXTrain;                                   # J. Theilhaber. zzzz
      # .....................................................................................................


      # .........................................................................
      cat(" ..........  Begin inner cross-validation loop.\n", sep = "");
      # .........................................................................

      

      # .................................................................................................
      # . >> MAIN LOOP :
      # .................................................................................................
      alAll = c();             # Log-likelihoods for entire data set.
      alTrain = c();           # Log-likelihoods for just training set.
      aR2Train = c();          # R2 on training set.
      acvPL = c();             # Cross-validated log-likelihoods.
      alRatioTest = c();       # Log-likelihood-ratio for test set on training set parameters.
      apRatioTest = c();       # P-values for log-likelihood-ratio for test set on train. set.
      aR2Test = c();           # R2 on test set.
      aMrms = c();             # r.m.s. of Martingale res. for test set on train. set parameters.

      aScan = c(100);          # Just a DUMMY, for the moment (5-9-2011).
      nScan = length(aScan);   # Number of levels to be explored.
      il = 0;                  # Level counter.
        
      cat("Progress: ", sep = "");     # Progress indicator.
      t1 = proc.time()[3];              # Starting time.
      
      for (z in aScan) {
        # .......................................................................................
        # . Compute the Cox proportional hazard model on all the input covariates :
        # .......................................................................................
        #xxxx  flagCenter = 'yes';      # Now passed as argument.
        cSel = BasicCox.computeCoxWithCov(atTrain, asTrain, azTrain, dfXc, flagCenter);
        # .......................................................................................
        # . Compute the baseline hazard functions (here using an approximation that assumes
        # . no ties) :
        # .......................................................................................
        bh = BasicCox.computeBaselineHazardNoTiesWithCov(atTrain, asTrain, azTrain, cSel, dfXc);        
        # .......................................................................................
        # . Package all the results into a single spc.cox object :
        # .......................................................................................
        bcTrain = BasicCox.packageBasicCoxWithCov(n = n,
                                                  p = p,
                                                  axm = cSel$axm,
                                                  abeta = cSel$abeta,        
                                                  aseBeta = cSel$aseBeta,    
                                                  apBeta= cSel$apBeta,       
                                                  betaZ = cSel$betaZ,        
                                                  seBetaZ = cSel$seBetaZ,    
                                                  pBetaZ = cSel$pBetaZ,      
                                                  agamma = cSel$agamma,      
                                                  aseGamma = cSel$aseGamma,  
                                                  apGamma = cSel$apGamma,    
                                                  qR = cSel$qR,
                                                  pR = cSel$pR,
                                                  coxK = cSel$coxK,
                                                  bh = bh);        
        # .......................................................................................
        # . i. Estimate the log partial likelihood for *all* samples, using the coefficients 
        # .    derived only from the training set.
        # .......................................................................................
        llBuf = BasicCox.computeCoxLogLikelihoodWithCov(bcTrain,
                                                        atIn = at,
                                                        asIn = as,
                                                        azIn = az,          
                                                        dfXIn = dfX);
        lOutAll = llBuf$lOut;
        # .......................................................................................
        # . ii. Estimate the log partial likelihood for only *training set* samples, using the 
        # .     coefficients derived only from the training set.
        # .......................................................................................
        llBuf = BasicCox.computeCoxLogLikelihoodWithCov(bcTrain,
                                                        atIn = atTrain,
                                                        asIn = asTrain,
                                                        azIn = azTrain,          
                                                        dfXIn = dfXTrain);
        lOutTrain = llBuf$lOut;
        lRatioTrain = llBuf$lRatio;                       # Log-likelkihood ratio on training set.
        R2Train = 1.0 - exp(- lRatioTrain / ntrain);      # R2 for training set.
        # .......................................................................................
        # . Compute the cross-validated log partial likelihood (CVPL) contribution :
        # .......................................................................................        
        cvPL = lOutAll - lOutTrain;
        # .......................................................................................
        # . Compute a log likelihood ratio for the test set on its own, using the
        # . model derived from the training set :
        # .......................................................................................
        llBuf = BasicCox.computeCoxLogLikelihoodWithCov(bcTrain,
                                                        atIn = atTest,
                                                        asIn = asTest,
                                                        azIn = azTest,
                                                        dfXIn = dfXTest);
        lRatioTest = llBuf$lRatio;
        lTemp = max(lRatioTest, 0.0);                                # As lRatioTest need not always be non-negative.
        p21 = 2 * p + 1;                                             # Degrees of freedom.
        pRatioTest = pchisq(lTemp, df = p21, lower.tail = FALSE);    # p-value from likelihood ratio.

        R2Test = 1.0 - exp(- lTemp / ntest);                         # R2 for test set, with lTemp floored at 0.
        # .......................................................................................
        # . Compute the Martingale residuals for the test set, on the basis of the parameters
        # . estimated from the training set :
        # .......................................................................................
        slTest = BasicCox.computeCoxLogHazardWithCov(bcTrain,
                                                     dfXIn = dfXTest,
                                                     azIn = azTest);
        ahRTest = slTest$ahR;                       # Test set values of exp(beta * Y).

        if (ncol(ahRTest) == 1) {
          ahRTest = ahRTest[ , 1];                  # Special case for p = 1.
        }
        
        mr = BasicCox.computeMartingaleResiduals(bcTrain = bcTrain,
                                                 atIn = atTest,
                                                 asIn = asTest,
                                                 ahRIn = ahRTest);
        Mrms = mr$Mrms;
        # .......................................................................................
        # . >> FOR TWO-ARMED STUDIES :
        # . Additional predictions, predicated on all z = 0, or all z = 1, for the same
        # . gene expression data.
        # . Note that this is relevant only for two-armed studies, coded as z = 0 or 1.
        # .......................................................................................
        azIn0 = rep(0, times = length(azTest));  # All z = 0.
        azIn1 = rep(1, times = length(azTest));  # All z = 1.

        slTest0 = BasicCox.computeCoxLogHazardWithCov(bcTrain,
                                                      dfXIn = dfXTest,
                                                      azIn = azIn0);        

        slTest1 = BasicCox.computeCoxLogHazardWithCov(bcTrain,
                                                      dfXIn = dfXTest,
                                                      azIn = azIn1);                
        # .......................................................................................
        # . Generate the columns of the matrix of log-hazard-ratios
        # . [samples * feature-selection levels] for the test samples, for this given split.
        # . The final matrix will have dimensions ntest * nScan.
        # .......................................................................................
        if (il == 0) {
          aloghRBIG = matrix(slTest$aloghR[ , 1], nrow = nrow(slTest$aloghR));       # The first column.
          aloghRBIG0 = matrix(slTest0$aloghR[ , 1], nrow = nrow(slTest0$aloghR));    # The first column.
          aloghRBIG1 = matrix(slTest1$aloghR[ , 1], nrow = nrow(slTest1$aloghR));    # The first column.
        } else {
          aloghRBIG = cbind(aloghRBIG, slTest$aloghR[ , 1]);            # Subsequent columns.
          aloghRBIG0 = cbind(aloghRBIG0, slTest0$aloghR[ , 1]);         # Subsequent columns.
          aloghRBIG1 = cbind(aloghRBIG1, slTest1$aloghR[ , 1]);         # Subsequent columns.          
        }        
        # .......................................................................................
        # . Update arrays :
        # .......................................................................................
        alAll = c(alAll, lOutAll);
        alTrain = c(alTrain, lOutTrain);             # Log-likelihood on training set only.
        aR2Train = c(aR2Train, R2Train);             # R2 for training set.
        acvPL = c(acvPL, cvPL);                      # Cross-validated log-likelihood.
        alRatioTest = c(alRatioTest, lRatioTest);    # Log-likelihood ratio for test set.
        apRatioTest = c(apRatioTest, pRatioTest);    # p-value for test set fitted by training set coefficients.
        aR2Test = c(aR2Test, R2Test);                # R2 for test set fitted by training set coefficients.
        aMrms = c(aMrms, Mrms);                      # Martingale residuals for the test set.

        cat(".", sep = "");                          # Progress indicator.

        il = il + 1;
        if (il%%20 == 0) {
          cat(" : processed ", il, " levels out of ", nScan, ".\n", sep = "");
          cat("          ", sep = "");            # Spacer for next row of dots indicating progress.
        }
        # .......................................................................................          
      }
      # .......................................................................................
      # . Summarize times :
      # .......................................................................................        
      cat("\n", sep = "");

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / nScan;                                 # Time per parameter value.

      if (flagVerbose) {
        cat(" ..........  Inner cross-validation loop done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per scan value.\n");
      }
      # .............................................................................................

      

      # ...............................................
      # . Package results :
      # ...............................................
      cv = list(methodSplit = methodSplit,
                nScan = nScan,
                n = n,
                ntrain = ntrain,
                ntest = ntest,
                alAll = alAll,
                alTrain = alTrain,
                aR2Train = aR2Train,
                acvPL = acvPL,
                alRatioTest = alRatioTest,
                apRatioTest = apRatioTest,
                aR2Test = aR2Test,
                aMrms = aMrms,
                indexTest = indexTest,
                aloghRBIG = aloghRBIG,
                aloghRBIG0 = aloghRBIG0,
                aloghRBIG1 = aloghRBIG1);

      class(cv) = 'basic.cox.cv.single';
      # ...............................................


      # .............
      return (cv);
      # .............
      
}

# =================================================================================================
# . End of BasicCoxCv.crossValidateCoxWithCovSingleSplit.
# =================================================================================================







# =====================================================================================================================
# . BasicCoxCv.crossValidateCoxWithCovBoot : bootstrap of cross-validation of the Cox proportional hazard model over 
# . --------------------------------------    multiple splits of the data into training and test sets.
# .                                         This version is with an external covariate.
# .                                     
# .                              
# .
# .   Syntax:
# .
# .           cv =  BasicCoxCv.crossValidateCoxWithCovBoot(at, as, az, dfX,
# .                                                        flagCenter,
# .                                                        ft,
# .                                                        rngSeed,
# .                                                        bootType,
# .                                                        nboot,
# .                                                        flaghRCOpt, hRC,
# .                                                        flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .    flagCenter = 'yes', mean-center the columns (genes) of the input data matrix.
# .                  'no', do not mean-center the columns.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfoldStrict'. Allowed: 0 < ft < 1.
# .
# .       rngSeed = initial random number seed. Must be integer > 0.
# .
# .     >> Bootstrap parameters :
# .
# .       bootType = type of resampling to be done in the outer loop.
# .                  Two types are valid : fullBoot, splitOnly       
# .                
# .                           fullBoot : do full bootstrap resampling. Resample 
# .                                      with replacement the training set      
# .                                      members, then do the indicated cross-  
# .                                      validation. Note that with this option 
# .                                      splits necessarily are different for   
# .                                      resampling.                            
# .     
# .                           splitOnly : only the splits deining the folds are 
# .                                       randomly changed for each outer loop  
# .                                       sampling. The overall training set    
# .                                       itself is unchanged.
# .
# .                         permutation : permute the gene expression profiles
# .                                       with respect to the survival data
# .                                       and external covariate (i.e. (t, s, z)
# .                                       are kept in synch with each other, and 
# .                                       x randomly permuted).
# .     
# .          nboot = number of bootstrap resamplings to be applied.
# .
# .     >> Cox-model parameters :
# .
# .     >> Decision boundary :
# .
# .        flaghRCOpt = flag defining where the hRC threshold value used comes from.
# .                     Allowed values :
# .
# .                     -   'no' : use input value hRC given below.
# .                     -  'yes' : use value which maximizes significance of separation of treatment
# .                                arms for sensitives.
# .
# .               hRC = decision threshold. Used if fflaghRCOpt = 'no', ignored if flaghRCOpt = 'yes'.
# .
# .                      Note that DloghR <= log(hRC) defines sensitive samples, DloghR >= log(hRC)
# .                      defines resistant samples.
# .
# .
# .   flagVerbose = if TRUE, prints progress on computation in the innner cross-validation loop.
# .
# .
# .   Out:
# .    cv = list, with members defined in packaging at end of function body.
# .
# =====================================================================================================================

BasicCoxCv.crossValidateCoxWithCovBoot  <- function(at, as, az, dfX,
                                                    flagCenter,
                                                    ft, rngSeed, 
                                                    bootType, nboot,
                                                    flaghRCOpt,
                                                    hRC,
                                                    flagVerbose)
{

      # ...........................................................................
      cat(" ..........  Entry in BasicCoxCv.crossValidateCoxWithCovBoot.\n");
      # ...........................................................................


      
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.            

      if (nt != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovBoot: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovBoot: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovBoot: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      
      if (n < 4) {
        msg = "ERROR: from BasicCoxCv.crossValidateCoxWithCovBoot: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((bootType == 'fullBoot')
                || (bootType == 'splitOnly')
                || (bootType == 'permutation'));
      
      stopifnot(rngSeed > 0);
      stopifnot(nboot > 0);      

      stopifnot((flaghRCOpt == 'yes') || (flaghRCOpt == 'no'));      
      stopifnot(hRC > 0);
      stopifnot((flagCenter == 'yes') || (flagCenter == 'no'));            
      # ...................................................................................


      
      # .......................................................................................
      # . Check on the external covariate :
      # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
      # . Note that this applies only to the cross-validation program, and not to the
      # . feature selection or model building cases.
      # .......................................................................................    
      msgBin = Cox.checkBinary(az);

      if (msgBin != 'ok') {
        cat("ERROR: from BasicCoxCv.crossValidateCoxWithCovBoot:\n");
        cat("External covariate values must all be {0, 1}\n");
        cat(msgBin);
        cat("\n");
        stop();
      }
      # .......................................................................................



      # ...............................................................................
      # . Set fixed defaults to be used inside the bootstrap loop :
      # ...............................................................................
      cvType = 'single';
      methodSplit = 'vfoldStrict';
      af = rep('NONE', times = length(at));           # Dummy.

      set.seed(rngSeed);  # Actually (re)set in the calculation on the non-resampled data.      
      # ...............................................................................
        


      # ......................................................................................................
      # . Do a one-time cross-validation on the non-resampled data :
      # ......................................................................................................            
      cat(" ..........  Do one-time cross-validation on the actual (non-resampled) data set.\n", sep = "");

      cv = BasicCoxCv.crossValidateCoxWithCov(at = at,
                                              as = as,
                                              az = az,          
                                              dfX = dfX,
                                              flagCenter = flagCenter,
                                              methodSplit = 'vfoldStrict',          # Frozen to 'vfoldStrict'.
                                              af = af,                              # Not used, as methodSplit = 'vfoldStrict'.
                                              ft = ft,
                                              rngSeed = rngSeed,                    # Not used in call, as flagRngSeed = FALSE.
                                              flagRngSeed = TRUE,                   # Initializes the random number seed.
                                              flagVerbose = TRUE);
      # ......................................................................................................
      # . Gather statistics for this resampling step :
      # ......................................................................................................
      sumCObs = SuperPc.summarizeCoxWithCovOnSplit(cv$aDloghRSortBIG[ , 1],
                                                   cv$ahRSortBIG[ , 1],
                                                   cv$apRSortBIG[ , 1],                                               
                                                   cv$ahRSortRESBIG[ , 1],
                                                   cv$apRSortRESBIG[ , 1],
                                                   hRCIn = hRC,
                                                   flaghRCOpt = flaghRCOpt);        
      # .......................................................................................................

      


      
        
      # ..................................................................................................................
      # . MAIN RESAMPLING LOOP :
      # ..................................................................................................................
      index0 = 1:n;                # Fixed index for resampling.
      asumC = list();              # This will contain the results from the resampling runs.
      
      cat(" ..........  Begin the resampling loop.\n", sep = "");
      cat(" ..........  Resampling type : ", bootType, "\n", sep = "");
      
      t1 = proc.time()[3];              # Starting time.
      
      for (l in 1:nboot) {
        cat(">>##############################################################\n");
        cat(">>Bootstrap resampling step ", l, " out of ", nboot, "\n", sep = "");
        cat(">>##############################################################\n");        
        # ......................................................................................
        # . >>FULL BOOTSTRAP: resample with replacement. All features remain together.
        # . We are simulating a new data set from the same distribution as the input data set.
        # ......................................................................................
        if (bootType == 'fullBoot') {
          indexBuf = sample(index0, replace = TRUE);   # Sampling with replacement.
          
          atBuf = at[indexBuf];
          asBuf = as[indexBuf];
          azBuf = az[indexBuf];

          dfXBuf = dfX[indexBuf, ];
          # ...................................................................................
          # . Special case if dfX has only one column : we must reformat dfXBuf as a matrix.
          # ...................................................................................          
          if (ncol(dfX) == 1) {
            dfXBuf = matrix(dfXBuf, nrow = nrow(dfX), byrow = FALSE);      
            rownames(dfXBuf) = rownames(dfX)[indexBuf];
            colnames(dfXBuf) = colnames(dfX);
          }
          # ...................................................................................
        }
        # ......................................................................................        
        # . >>RESAMPLE SPLITS ONLY : we are gauging only the effects of generating variable
        # . fold selections in the internal cross-validation. The training set remains
        # . untouched.
        # ......................................................................................
        if (bootType == 'splitOnly') {
          atBuf = at;
          asBuf = as;
          azBuf = az;

          dfXBuf = dfX;
        }
        # ......................................................................................
        # . >>PERMUTATION:  shuffle gene expression profiles
        # . but keep survival and external co-variate in-place.
        # . We are simulating a data set under the null hypothesis of no association between
        # . survival and gene-expression.
        # ......................................................................................
        if (bootType == 'permutation') {
          indexBuf = sample(index0);                    # Permutation.
          
          atBuf = at;                                   # These stay in place.
          asBuf = as;                                   # These stay in place.
          azBuf = az;                                   # These stay in place.

          dfXBuf = dfX[indexBuf, ];                     # Shuffle gene expression profiles.
          # ...................................................................................
          # . Special case if dfX has only one column : we must reformat dfXBuf as a matrix.
          # ...................................................................................          
          if (ncol(dfX) == 1) {
            dfXBuf = matrix(dfXBuf, nrow = nrow(dfX), byrow = FALSE);      
            rownames(dfXBuf) = rownames(dfX)[indexBuf];
            colnames(dfXBuf) = colnames(dfX);
          }
          # ...................................................................................          
        }        
        # ......................................................................................
        # . The innner cross-validation is done here :
        # ......................................................................................                
        cv = BasicCoxCv.crossValidateCoxWithCov(at = atBuf,
                                                as = asBuf,
                                                az = azBuf,          
                                                dfX = dfXBuf,
                                                flagCenter = flagCenter,          
                                                methodSplit = 'vfoldStrict',          # Frozen to 'vfoldStrict'.
                                                af = af,                              # Not used, as methodSplit = 'vfoldStrict'.
                                                ft = ft,
                                                rngSeed = rngSeed,                    # Not used in call, as flagRngSeed = FALSE.
                                                flagRngSeed = FALSE,                  # Frozen to FALSE.
                                                flagVerbose = TRUE);
        # ......................................................................................
        # . Gather statistics for this resampling step :
        # ......................................................................................
        sumC = SuperPc.summarizeCoxWithCovOnSplit(cv$aDloghRSortBIG[ , 1],
                                                  cv$ahRSortBIG[ , 1],
                                                  cv$apRSortBIG[ , 1],                                               
                                                  cv$ahRSortRESBIG[ , 1],
                                                  cv$apRSortRESBIG[ , 1],
                                                  hRCIn = hRC,
                                                  flaghRCOpt = flaghRCOpt);                  

        asumC[[l]] = sumC;
        # ......................................................................................        
      }

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / nboot;                                 # Time per resampling.

      cat(" ..........  Bootstrap loop done. Total time = ", t2, " s.", sep = "");
      cat(" Time = ", tau, " s per resampling.\n");            
      # ..................................................................................................................


      

      # ........................................................................................
      # . Package results :
      # ........................................................................................
      cvBoot = list(n = n,                       # Number of samples.
                    bootType = bootType,         # Type of resampling done.
                    nboot = nboot,               # Number of resamplings.
                    rngSeed = rngSeed,           # Random number seed.
                    hRC = hRC,                   # Hazard ratio threshold for S and R calls.
                    sumCObs = sumCObs,           # Statistical summary for actual training set.
                    asumC = asumC);              # List contains series of summaries generated by resamplings.
            
      class(cvBoot) = 'glmnet.cox.cov.cv.boot';
      # ........................................................................................      

      

      # ................................................................
      cat(" ..........  Exit BasicCoxCv.crossValidateCoxWithCovBoot.\n");
      # ................................................................

      
      
      # ...............
      return (cvBoot);
      # ...............

}

# =====================================================================================================================
# . End of  BasicCoxCv.crossValidateCoxWithCovBoot.
# =====================================================================================================================


