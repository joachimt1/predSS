# =================================================================================================
# . SuperPc.r : functions to implement supervised principal components.
# . ---------   See: Prediction by supervised principal components.
# .             Eric Blair et al. Jour. Amer. Stat. Assoc. vol. 101, 118 (2006).
# .
# =================================================================================================

library(survival);

SuperPc.NZMAX = 5;      # Maximum number of distinct values for external covariate.

# =================================================================================================
# . SuperPc.computeCox : computes a de novo Cox proportional hazards model, given the
# . ------------------   input sample survival times and censoring statuses.
# .                             
# .
# .   Syntax:
# .
# .       spc = SuperPc.computeCox(at, as, dfX, methodFs, p0, mtop, K, flagVerbose);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .
# .     scoreType = type of score to be used for computing P-values.
# .                 Allowed values : 
# .                  - 'loglik' : use score = 2 * (l(beta*) - l(0)).
# .                  - 'u0'     : use score = U(0)^2 / J(0).
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values from Cox proportional hazards model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .   flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        spc = list, with members:
# .        msg                      # Output message. = 'ok' for normal execution,
# .                                 # else reports error or inconsistencies (e.g.
# .                                 # 0 features passed by filter).
# .        type                     # Type of spc calculation. Here = 'coxph'.
# .        methodFs                 # Feature selection method.                        
# .        mtop                     # Number of genes for feature selection.           
# .        p0                       # P-value threshold for feature selection.         
# .        n                        # Number of samples.                               
# .        p                        # Number of genes.
# .        ac                       # p : column names (gene names).
# .        axm                      # p : column means (gene-by-gene means).           
# .        indexSel                 # m : index of selected genes.                         
# .        m                        # Number of selected genes.                        
# .        pvalMin                  # Smallest univariate p-value selected.            
# .        pvalMax                  # Largest univariate p-value selected.             
# .        K                        # Number of pc's used in final Cox model.          
# .        abeta                    # K : Cox coefficients.
# .        aseBeta                  # K : standard errors for the Cox coefficients.                            
# .        ap                       # K : P-values for the Cox coefficents.            
# .        qR                       # Loglikelihood ratio statistic (df = K).          
# .        pR                       # P-value for loglikelihood ratio statistic.       
# .        av                       # p * K : pc vectors full p-gene expression space. 
# .        avtot                    # Summed gene loadings in p-gene expression space. 
# .        sv                       # Pass the results of the internal SVD.
# .        bh                       # Baseline hazard object. See function: 
# .                                 # >> SuperPc.computeBaselineHazardNoTies() for member details.
# ................................................................................................
# .               sv = SVD results :
# .                    sv$d = array of m singular values.
# .                    sv$u = array of left eigenvectors (prop. to principal compnents).
# .                    sv$v = array of right eigenvectors.
# .
# =================================================================================================

SuperPc.computeCox <- function(at, as, dfX, scoreType, methodFs, p0, mtop, K, flagVerbose)
{

      # ........................................................................
      stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);
      stopifnot(K >= 1);
      # ........................................................................


      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPc.computeCox.\n");
      }
      # ........................................................................      

      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................
      n = nrow(dfX);       # Number of samples.
      p = ncol(dfX);       # Number of genes.
      ac = colnames(dfX);  # Array of gene names.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.

      if (nt != n) {
        msg = "ERROR: from SuperPc.computeCox: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCox: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (mtop > p) {
        msg = "ERROR: from SuperPc.computeCox: ";
        msg = paste("mtop = ", mtop, " is greater than number of genes p = ", p, sep = "");
        stop(msg);
      }

      n1 = n - 1;
      rtemp = min(n1, p);    # Rank of the data matrix.

      if (K > rtemp) {
        msg = "ERROR: from SuperPc.computeCox: ";
        msg = paste("K = ", K, " is greater than the data matrix rank = ", rtemp, sep = "");
        stop(msg);
      }
      # ......................................................................................



      # .......................................................................................
      # . Column-center the data then generate univariate Cox scores for each gene separately.
      # .......................................................................................
      axm = colMeans(dfX);                                     # Save the p column means.
      
      dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.
      #xxxx coxS = Cox.computeOnDataFrameSimple(at, as, dfXc, flagVerbose = TRUE);     # Old.
      #xxxx coxS = Cox.computeOnDataFrameNoTiesParallel(at, as, dfXc, flagVerbose = TRUE);  # New.

      cat(" ..........  Generate scores using scoreType = ", scoreType, "\n", sep = "");
      
      if (scoreType == 'loglik') {      
        #xxxx coxS = Cox.computeOnDataFrameSimple(at, as, dfXc, flagVerbose = TRUE);                # log-likelihood score.
        coxS = Cox.computeOnDataFrameSimpleBeta(at, as, dfXc, flagVerbose = TRUE);                  # log-likelihood score.
      } else if (scoreType == 'u0') {
        #xxx coxS = Cox.computeOnDataFrameNoTiesParallel(at, as, dfXc, flagVerbose = TRUE);    # U0^2/J0 score.
        coxS = Cox.computeOnDataFrameNoTiesCHUNKED(at, as, dfXc, flagVerbose = TRUE);          # Wrapper for the above.
      } else {
        cat("ERROR: from SuperPc.computeCox: scoreType = ", scoreType, " is not valid.\n");    # Failsafe.
        cat("Please check program logic.\n");
        stop();
      }
      # ........................................................................................
      # .Compare with my own implementation of the U(0)^2 / J(0) calculation :
      # ........................................................................................      
      #xxxx cs = Cox.computeSingleNoTies(at, as, dfXc[ , 1]);      # Test for a single slice, first column.
      #xxxx Cox.plotUnivariateComparison(coxS, coxSnew);  # Plot the two sets of values.
      # .......................................................................................
      # . Perform the feature selection with the indicated method and parameters :
      # .......................................................................................      
      selF = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtop, coxS);
      # .......................................................................................
      # . Catch the unlikely case where remaining features less than principal components :
      # .......................................................................................            
      if (selF$m < K) {
        msg = "ERROR: from SuperPc.computeCox: ";        
        msg = paste(msg, "Remaining features m = ", selF$m, " less than principal components K = ",
                    K, sep = "");
        spc = list(msg = msg, m = selF$m);
        return (spc);
      }
      # .......................................................................................
      # . Do the svd and generate Cox proportional hazard model :
      # .......................................................................................
      cSel = SuperPc.computeCoxOnSelectedFeatures(at, as, selF$dfXSel, K);
      # .......................................................................................
      # . Compute the baseline hazard functions (here using an approximation that assumes
      # . no ties) :
      # .......................................................................................
      bh = SuperPc.computeBaselineHazardNoTies(at, as, cSel, selF$dfXSel);      
      # .......................................................................................
      # . Project back to orignal p-dimensional vector space:
      # .......................................................................................
      fullPc = SuperPc.projectToFull(p, cSel$avSel, cSel$avSelTot, selF$indexSel);
      # .......................................................................................

    
    

      # .......................................................................................
      # . Package the results (see also function SuperPc.packageSpcCox()) :
      # .......................................................................................
      msg = 'ok';
      
      spc = list(msg = msg,                   # Output message.
                 scoreType = scoreType,       # Type of score statistic used for feature selection.        
                 methodFs = methodFs,         # Feature selection method.                        
                 mtop = mtop,                 # Number of genes for feature selection.           
                 p0 = p0,                     # P-value threshold for feature selection.         
                 n   = n,                     # Number of samples.                               
                 p   = p,                     # Number of genes.
                 ac = ac,                     # p : column names (gene names).        
                 axm = axm,                   # p : column means (gene-by-gene means).
                 indexSel = selF$indexSel,    # Index of selected genes.                         
                 m = selF$m,                  # Number of selected genes.                        
                 pvalMin = selF$pvalMin,      # Smallest univariate p-value selected.            
                 pvalMax = selF$pvalMax,      # Largest univariate p-value selected.             
                 K = K,                       # Number of pc's used in final Cox model.          
                 abeta = cSel$abeta,          # K : the Cox coefficients.
                 aseBeta = cSel$aseBeta,      # K : standard errors for the Cox coefficients.
                 ap = cSel$ap,                # K : the P-values for the Cox coefficents.            
                 qR = cSel$qR,                # Loglikelihood ratio statistic (df = K).          
                 pR = cSel$pR,                # P-value for loglikelihood ratio statistic.
                 avSel = cSel$avSel,          # m * K : pc vectors in m-gene expression space.         
                 av = fullPc$av,              # p * K : pc vectors full p-gene expression space.
                 avSelTot = cSel$avSelTot,    # Summed gene loadings in m-gene expression space.    
                 avTot = fullPc$avTot,        # Summed gene loadings in p-gene expression space. 
                 sv = cSel$sv,                # Pass the results of the internal SVD.
                 coxK = cSel$coxK,            # Final Cox model on K principal components.
                 bh = bh);                    # Baseline hazard object.
      
      class(spc) = 'spc.cox';
      # .......................................................................................

      
      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Exit SuperPc.computeCox.\n");
      }
      # ........................................................................            

      
      # .............
      return (spc);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.computeCox.
# =================================================================================================




# =================================================================================================
# . SuperPc.getBaselineHazard : returns the baseline hazard member of an spc object, prevously
# . -------------------------    computed in SuperPc.computeCox.
# .
# . Syntax :
# .
# .     bh = SuperPc.getBaselineHazard(spc);
# .
# . In:
# .     spc = object computed by SuperPc.computeCox() or SuperPc.computeCoxWithCov() functions.
# .
# . Out:
# .      bh = baseline hazard object, with members defined in
# .           SuperPc.computeBaselineHazardNoTies().
# .
# =================================================================================================

SuperPc.getBaselineHazard <- function(spc)
{

      # ....................................................................................
      if ((class(spc) != "spc.cox") && (class(spc) != "spc.cox.cov")
          && (class(spc) != "glmnet.cox.cov")) {
        msg = "ERROR: from SuperPc.getBaselineHazard: ";
        msg = paste("The input spc is not of class: spc.cox, spc.cox.cov, glmnet.cox.cov");
        stop(msg);
      }
      # ...................................................................................


      # ................
      return (spc$bh);
      # ................

}

# =================================================================================================
# . End of SuperPc.getBaselineHazard.
# =================================================================================================




# =================================================================================================
# . SuperPc.computeCoxFs : generates the index for features selected under the univariate
# . --------------------   Cox proportional hazard scoring scheme. This is a utility function
# .                        that only does the feature selection, and does not generate the full
# .                        super pc Cox model. See SuperPc.computeCox() for the full model.
# .
# .   Syntax:
# .
# .       fs = SuperPc.computeCoxFs(at, as, dfX, methodFs, p0, mtop, flagVerbose);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values from Cox proportional hazards model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .   flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        fs = list, with members:
# .        msg                      # Output message. = 'ok' for normal execution,
# .                                 # else reports error or inconsistencies (e.g.
# .                                 # 0 features passed by filter).
# .        methodFs                 # Feature selection method.                        
# .        mtop                     # Number of genes for feature selection.           
# .        p0                       # P-value threshold for feature selection.         
# .        n                        # Number of samples.                               
# .        p                        # Number of genes.
# .        ac                       # p : column names (gene names).
# .        axm                      # p : column means (gene-by-gene means).
# .        ap                       # p : P-values for all the genes.
# .        m                        # Number of selected genes.                        
# .        indexSel                 # m : index of selected genes.
# .        pvalMin                  # Smallest univariate p-value selected.            
# .        pvalMax                  # Largest univariate p-value selected.
# .
# =================================================================================================

SuperPc.computeCoxFs <- function(at, as, dfX, methodFs, p0, mtop, flagVerbose)
{

      # ........................................................................
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);
      # ........................................................................


      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPc.computeCoxFs.\n");
      }
      # ........................................................................      

      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................
      n = nrow(dfX);       # Number of samples.
      p = ncol(dfX);       # Number of genes.
      ac = colnames(dfX);  # Array of gene names.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.

      if (nt != n) {
        msg = "ERROR: from SuperPc.computeCoxFs: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxFs: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (mtop > p) {
        msg = "ERROR: from SuperPc.computeCoxFs: ";
        msg = paste("mtop = ", mtop, " is greater than number of genes p = ", p, sep = "");
        stop(msg);
      }
      # ......................................................................................



      # .......................................................................................
      # . Column-center the data then generate univariate Cox scores for each gene separately.
      # .......................................................................................
      axm = colMeans(dfX);                                     # Save the p column means.
      
      dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.
      #xxxx coxS = Cox.computeOnDataFrameSimple(at, as, dfXc, flagVerbose = TRUE);    # Old.
      coxS = Cox.computeOnDataFrameNoTiesParallel(at, as, dfXc, flagVerbose = TRUE);  # New.
      # ........................................................................................
      # .Compare with my own implementation of the U(0)^2 / J(0) calculation :
      # ........................................................................................      
      #xxxx cs = Cox.computeSingleNoTies(at, as, dfXc[ , 1]);      # Test for a single slice, first column.
      #xxxx Cox.plotUnivariateComparison(coxS, coxSnew);  # Plot the two sets of values.
      # .......................................................................................
      # . Perform the feature selection with the indicated method and parameters :
      # .......................................................................................      
      selF = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtop, coxS);
      # .......................................................................................



      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      msg = 'ok';
      
      fs = list(msg = msg,                   # Output message.
                methodFs = methodFs,         # Feature selection method.                        
                mtop = mtop,                 # Number of genes for feature selection.           
                p0 = p0,                     # P-value threshold for feature selection.         
                n   = n,                     # Number of samples.                               
                p   = p,                     # Number of genes.
                ac = ac,                     # p : column names (gene names).        
                axm = axm,                   # p : column means (gene-by-gene means).
                ap = coxS$ap,                # p : P-values for all the genes.
                m = selF$m,                  # Number of selected genes.                        
                indexSel = selF$indexSel,    # m : index of selected genes.
                pvalMin = selF$pvalMin,      # Smallest univariate p-value selected.            
                pvalMax = selF$pvalMax );    # Largest univariate p-value selected.
      
      class(fs) = 'spc.cox.fs';
      # .......................................................................................

      
      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Exit SuperPc.computeCoxFs.\n");
      }
      # ........................................................................            

      
      # .............
      return (fs);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.computeCoxFs.
# =================================================================================================





# =================================================================================================
# . SuperPc.computeCoxUni : generates univariate, gene-by-gene Cox proportional hazard statistics 
# . ---------------------   for the given input data matrix. For each gene computes one of two measures of 
# .                         significance, one based on the fitted model score 2 * (l(beta*) - l(0)),
# .                         and the other based on the score for beta = 0, U(0)^2 / J(0). Each of
# .                         these scores has a Chi-squared distribution with one degree of freedom
# .                         under the null hypothesis of no dependence of survival time on gene
# .                         expression. Internally also does feature selection on the selected score.
# .
# . Note: this is a variant of computeCoxFs, but with the additional option of choosing between
# .       the two possible scores outlined above, the log-likelihood or the U0-based test scores.
# .
# .   Syntax:
# .
# .       fs = SuperPc.computeCoxUni(at, as, dfX, scoreType, methodFs, p0, mtop, flagVerbose);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     scoreType = type of score to be used for computing P-values.
# .                 Allowed values : 
# .                  - 'loglik' : use score = 2 * (l(beta*) - l(0)).
# .                  - 'u0'     : use score = U(0)^2 / J(0).
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values from Cox proportional hazards model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .   flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        fs = list, with members:
# .        msg                      # Output message. = 'ok' for normal execution,
# .                                 # else reports error or inconsistencies (e.g.
# .                                 # 0 features passed by filter).
# .        scoreType                # Type of score statistic used for feature selection.
# .        methodFs                 # Feature selection method.                        
# .        mtop                     # Number of genes for feature selection.           
# .        p0                       # P-value threshold for feature selection.         
# .        n                        # Number of samples.                               
# .        p                        # Number of genes.
# .        ac                       # p : column names (gene names).
# .        axm                      # p : column means (gene-by-gene means).
# .        ascore                   # p : scores for all the genes.
# .        ap                       # p : P-values  for all the genes.
# .        abeta                    # p : optimal beta (for logLikelihood) or beta = 0 (for u0) for all the genes.
# .        ascoreU0                 # p : U0 scores for all the genes.
# .        apU0                     # p : P-values based on U0 scores, for all the genes.
# .        m                        # Number of selected genes.                        
# .        indexSel                 # m : index of selected genes.
# .        pvalMin                  # Smallest univariate p-value selected.            
# .        pvalMax                  # Largest univariate p-value selected.
# .
# =================================================================================================

SuperPc.computeCoxUni <- function(at, as, dfX, scoreType, methodFs, p0, mtop, flagVerbose)
{

      # ........................................................................
      stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));      
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);
      # ........................................................................


      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPc.computeCoxUni.\n");
      }
      # ........................................................................      

      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................
      n = nrow(dfX);       # Number of samples.
      p = ncol(dfX);       # Number of genes.
      ac = colnames(dfX);  # Array of gene names.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.

      if (nt != n) {
        msg = "ERROR: from SuperPc.computeCoxUni: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxUni: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (mtop > p) {
        msg = "ERROR: from SuperPc.computeCoxUni: ";
        msg = paste("mtop = ", mtop, " is greater than number of genes p = ", p, sep = "");
        stop(msg);
      }
      # ......................................................................................



      # .......................................................................................
      # . Column-center the data then generate univariate Cox scores for each gene separately.
      # .......................................................................................
      axm = colMeans(dfX);                                     # Save the p column means.
      
      dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.

      cat(" ..........  Generate scores using scoreType = ", scoreType, "\n", sep = "");

      if (scoreType == 'loglik') {      
        coxS = Cox.computeOnDataFrameSimpleBeta(at, as, dfXc, flagVerbose = TRUE);        # log-likelihood score.
      } else if (scoreType == 'u0') {
        #xxx coxS = Cox.computeOnDataFrameNoTiesParallel(at, as, dfXc, flagVerbose = TRUE);  # U0^2/J0 score.
        coxS = Cox.computeOnDataFrameNoTiesCHUNKED(at, as, dfXc, flagVerbose = TRUE);        # Wrapper for the above.
      } else {
        cat("ERROR: from SuperPc.computeCoxUni: scoreType = ", scoreType, " is not valid.\n");    # Failsafe.
        cat("Please check program logic.\n");
        stop();
      }
      # .......................................................................................

      
      
      # .......................................................................................
      # . Perform feature selection with the indicated method and parameters,
      # .......................................................................................
      selF = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtop, coxS);
      # .......................................................................................



      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      msg = 'ok';
      
      fs = list(msg = msg,                   # Output message.
                scoreType = scoreType,       # Type of score statistic used for feature selection.        
                methodFs = methodFs,         # Feature selection method.                        
                mtop = mtop,                 # Number of genes for feature selection.           
                p0 = p0,                     # P-value threshold for feature selection.         
                n   = n,                     # Number of samples.                               
                p   = p,                     # Number of genes.
                ac = ac,                     # p : column names (gene names).        
                axm = axm,                   # p : column means (gene-by-gene means).
                ascore = coxS$ascore,        # p : scores for all the genes.
                ap = coxS$ap,                # p : P-values for all the genes.
                abeta = coxS$abeta,          # p : optimal beta (for logLikelihood) or beta = 0 (for u0) for all the genes.        
                m = selF$m,                  # Number of selected genes.                        
                indexSel = selF$indexSel,    # m : index of selected genes.
                pvalMin = selF$pvalMin,      # Smallest univariate p-value selected.            
                pvalMax = selF$pvalMax );    # Largest univariate p-value selected.
      
      class(fs) = 'spc.cox.fs';              # Actually, a superset of class 'fs'.
      # .......................................................................................

      
      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Exit SuperPc.computeCoxUni.\n");
      }
      # ........................................................................            

      
      # .............
      return (fs);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.computeCoxUni.
# =================================================================================================






# =================================================================================================
# . SuperPc.projectToFull : projects the principal component vectors in feature-selected space back 
# . ---------------------   to the full p-dimensional space.
# .                             
# .   Syntax:
# .
# .      fullPc = SuperPc.projectToFull(p, avSel, avSelTot, indexSel);
# .
# .   In:
# .             p = dimensionality of full-dimensional space.
# .
# .         avSel = m * K matrix of the K principal component vectors, each as a separate column.
# .
# .      avSelTot = m-dimensional vector of summed loadings for each gene (= avSel * beta, 
# .                 where beta = vector of Cox coeffcients).
# .
# .      indexSel = indices of genes in original index space 1..p, that were retained after
# .                 feature-selection.
# .
# .   Out:
# .
# .      fullPc = list, with members :
# .
# .            av = p * K matrix of the K principal component vectors, each as a separate column.
# .                 Rows for genes which were not among the selected features are all 0.
# .
# .         avTot = p-dimensional vector of summed loadings for each gene (= av * beta, 
# .                 where beta = vector of Cox coeffcients). Rows for genes which were not
# .                 among the selected features are all 0.
# .
# =================================================================================================

SuperPc.projectToFull <- function(p, avSel, avSelTot, indexSel)
{

      # ..................................
      m = nrow(avSel);
      K = ncol(avSel);

      stopifnot(length(indexSel) == m);
      stopifnot(m <= p);
      # ..................................      

      
      # .......................................................................................
      # . Project back to original p-dimensional vector space:
      # .......................................................................................
      av = matrix(c(0.0), nrow = p, ncol = K, byrow = TRUE);
      av[indexSel, ] = avSel;         # p * K : pc vectors in p-dimensional space.
      avTot = rep(0.0, times = p);
      avTot[indexSel] = avSelTot;     # Summed gene loadings in p-dimensional space.
      # .......................................................................................


      # ..........................................
      # . Package results :
      # ..........................................      
      fullPc = list(av = av, avTot = avTot);
      # ..........................................

}

# =================================================================================================
# . End of SuperPc.projectToFull.
# =================================================================================================



# =================================================================================================
# . SuperPc.packageSpcCox : creates an spc.cox object from the explicit inputs. Used in packaging
# . ---------------------   together partial results in the context of a cross-validation loop.
# .                             
# .   Syntax:
# .
# .      spc = SuperPc.packageSpcCox();
# .
# .   In:
# .
# .      methodFs =    Feature selection method.                        
# .          mtop =    Number of genes for feature selection.           
# .            p0 =    P-value threshold for feature selection.         
# .           n   =    Number of samples.                               
# .           p   =    Number of genes.                                 
# .           axm =    p : column means (gene-by-gene means).           
# .      indexSel =    Index of selected genes.                         
# .             m =    Number of selected genes.                        
# .       pvalMin =    Smallest univariate p-value selected.            
# .       pvalMax =    Largest univariate p-value selected.             
# .             K =    Number of pc's used in final Cox model.          
# .         abeta =    K : the Cox coefficients.
# .       aseBeta =    K : standard erros for the Cox coefficients.
# .            ap =    K : the P-values for the Cox coefficents.            
# .            qR =    Loglikelihood ratio statistic (df = K).          
# .            pR =    P-value for loglikelihood ratio statistic.
# .         avSel =    m * K : pc vectors in m-gene expression space.         
# .            av =    p * K : pc vectors full p-gene expression space.
# .      avSelTot =    Summed gene loadings in m-gene expression space.    
# .         avTot =    Summed gene loadings in p-gene expression space. 
# .            sv =    Pass the results of the internal SVD.
# .          coxK =    Final Cox model on K principal components.
# .            bh =    Baseline hazard object.
# .
# .   Out:
# .
# .          spc = object of class spc.cox.
# .
# =================================================================================================

SuperPc.packageSpcCox <- function(methodFs, mtop, p0,
                                  n, p, axm, indexSel, m,
                                  pvalMin, pvalMax,
                                  K, abeta, aseBeta, ap,
                                  qR, pR, avSel,
                                  av, avSelTot, avTot,
                                  sv, coxK, bh)
{

      # .......................................................................................
      # . Package the inputs :
      # .......................................................................................
      msg = 'ok';
      
      spc = list(msg = msg,                   # Output message.
                 type = 'coxph',              # Type of spc calculation.
                 methodFs = methodFs,         # Feature selection method.                        
                 mtop = mtop,                 # Number of genes for feature selection.           
                 p0 = p0,                     # P-value threshold for feature selection.         
                 n   = n,                     # Number of samples.                               
                 p   = p,                     # Number of genes.                                 
                 axm = axm,                   # p : column means (gene-by-gene means).           
                 indexSel = indexSel,         # Index of selected genes.                         
                 m = m,                       # Number of selected genes.                        
                 pvalMin = pvalMin,           # Smallest univariate p-value selected.            
                 pvalMax = pvalMax,           # Largest univariate p-value selected.             
                 K = K,                       # Number of pc's used in final Cox model.          
                 abeta = abeta,               # K : the Cox coefficients.
                 aseBeta = aseBeta,           # K : standard erros for the Cox coefficients.
                 ap = ap,                     # K : the P-values for the Cox coefficents.            
                 qR = qR,                     # Loglikelihood ratio statistic (df = K).          
                 pR = pR,                     # P-value for loglikelihood ratio statistic.
                 avSel = avSel,               # m * K : pc vectors in m-gene expression space.         
                 av = av,                     # p * K : pc vectors full p-gene expression space.
                 avSelTot = avSelTot,         # Summed gene loadings in m-gene expression space.    
                 avTot = avTot,               # Summed gene loadings in p-gene expression space. 
                 sv = sv,                     # Pass the results of the internal SVD.
                 coxK = coxK,                 # Final Cox model on K principal components.
                 bh = bh );                   # Baseline hazard object.
      
      class(spc) = 'spc.cox';
      # .......................................................................................

      
      # .............
      return (spc);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.packageSpcCox.
# =================================================================================================







# =================================================================================================
# . SuperPc.selectFeaturesCox : does feature selection, based on a precomputed set of univariate
# . -------------------------   Cox proportional hazard model scores.
# .                             
# .
# .   Syntax:
# .
# .       selF = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtop, coxS);
# .
# .   In:
# .           dfXc =data frame for the predictor variables, after column mean-centering.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values from Cox proportional hazards model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .          coxS = object returned by a call to Cox.computeOnDataFrameSimple(),
# .                 contains the univariate Cox scores.
# .
# .   Out:
# .        selF = list, with members:
# .
# .               indexSel            # Index of selected genes.                         
# .               m                   # Number of selected genes.                        
# .               pvalMin             # Smallest univariate p-value selected.            
# .               pvalMax             # Largest univariate p-value selected.             
# .               dfXSel              # Data frame subsetted to the selected features.
# . 
# =================================================================================================

SuperPc.selectFeaturesCox <- function(dfXc, methodFs, p0, mtop, coxS)
{

      # ........................................................................
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);
      # ........................................................................


      # ........................................................................
      p = ncol(dfXc);           # Number of genes in input data matrix.
      pS = length(coxS$ap);     # Number of genes from coxS object.

      if (pS != p) {
        msg = "ERROR: from SuperPc.selectFeaturesCox: ";
        msg = paste("coxS input has pS = ", pS, " genes. ", sep = "");
        msg = paste("Not the same as p = ", p, " in input data matrix dfXc.", sep = "");        
        stop(msg);
      }      
      # ........................................................................      


      # .......................................................................................
      # . Feature selection step:
      # .
      # . >> Method = p0 : subset to genes with P-value for Cox model <= p0.
      # .    The p-values are evaluated from the score test.
      # .
      # .    Return with m = 0 if the filter is too stringent and 0 genes are passed.
      # .......................................................................................
      if (methodFs == 'p0') {
        indexSel = which(coxS$ap <= p0);    # Indices of genes selected with p <= p0.
        m = length(indexSel);               # Number of genes selected.

        if (m == 0) {
          spc = list(msg = "ERROR: nothing passed the preliminary feature selection",
                     m = 0);
          return (spc);                     # Return as there is nothing to compute.
        }

        pvalMin = min(coxS$ap[indexSel]);   # Smallest p-value actually selected.        
        pvalMax = min(coxS$ap[indexSel]);   # Largest p-value actually selected.
      }
      # .......................................................................................
      # . >> Method = mtop : select the mtop genes with the most significant scores.
      # .......................................................................................
      if (methodFs == 'mtop') {
        sBuf = sort(coxS$ap, decreasing = FALSE, index.return = TRUE);
        indexSel = sBuf[["ix"]][1:mtop];           # Indices of genes selected.
        m = mtop;
        pvalMin = sBuf[["x"]][1];                  # Smallest p-value actually selected.        
        pvalMax = sBuf[["x"]][mtop];               # Largest p-value actually selected.
      }
      # .......................................................................................
      # . Now subset the data matrix to the selected genes :
      # .......................................................................................
      dfXSel = dfXc[ , indexSel];                           # Subsetted to the selected genes.
      acBuf = colnames(dfXc);
      
      if (length(indexSel) == 1) {
        dfXSel = as.matrix(dfXSel, nrow = nrow(dfXc))       # Special case for 1 gene selected.
        colnames(dfXSel) = acBuf[indexSel];
      }      
      # .......................................................................................


      # .......................................................................................
      # . Package results :
      # .......................................................................................
      selF = list(
        indexSel = indexSel,
        m = m,
        pvalMin = pvalMin,
        pvalMax = pvalMax,
        dfXSel = dfXSel   );
      # .......................................................................................

      
      # .............
      return (selF);
      # .............
      
}

# =================================================================================================
# . End of SuperPc.selectFeaturesCox.
# =================================================================================================





# =================================================================================================
# . SuperPc.computeCoxOnSelectedFeatures : computes a Cox proportional hazards model, given
# . ------------------------------------   an input data matrix which has already undergone
# .                                        feature selection, and the input survival times and
# .                                        censoring statuses.
# .   Syntax:
# .
# .       cSel = SuperPc.computeCoxOnSelectedFeatures(at, as, dfXSel, K);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .           dfXSel = n * m : data matrix of gene expression data, after mean-centering
# .                    and feature selection.
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .
# .   Out:
# .        cSel = list, with members:
# .
# .         abeta         # K-dimensional array : the Cox coefficients.
# .         aseBeta       # K-dimensional array : standard errors for the Cox coefficients.
# .         ap            # K-dimensional : P-values for the Cox coefficients.
# .         qR            # Loglikelihood ratio statistic (df = K).          
# .         pR            # P-value for loglikelihood ratio statistic.
# .         avSel         # m * K-dimensional array: the pc vectors in m-gene expression space.         
# .         avSelTot      # m-dimensional array: Summed gene loadings in m-gene expression space.    
# .         sv            # Pass the results of the internal SVD.
# .         coxK          # Final Cox model on K principal components.
# . 
# =================================================================================================

SuperPc.computeCoxOnSelectedFeatures <- function(at, as, dfXSel, K)
{

      # ...........................
      stopifnot(K >= 1);
      # ...........................


      # ....................
      n = nrow(dfXSel);      
      m = ncol(dfXSel);
      # ....................


      # .................................................................................
      # . Check on lengths of arrays :
      # .................................................................................      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.

      if (nt != n) {
        msg = "ERROR: from SuperPc.computeCoxOnSelectedFeatures: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxOnSelectedFeatures: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      # .................................................................................

      

      # .......................................................................................
      # . Catch the case where the matrix rank is smaller than the number of 
      # . principal components specified for the analysis.
      # .......................................................................................
      if (K >= m) {
        msg = paste("ERROR: from SuperPc.computeCoxOnSelectedFeatures: ", sep = "");
        msg = paste(msg, "Number K = ", K, " of principal components ",
                    " greater than or equal to the number of genes m = ", m, sep = "");
        stop(msg);
      }

      n1 = n - 1;

      if (K >= n1) {
        msg = paste("ERROR: from SuperPc.computeCoxOnSelectedFeatures: ", sep = "");
        msg = paste(msg, "Number K = ", K, " of principal components ",
                    " greater than or equal to the number of samples minus 1, n1 = ", n1, sep = "");
        stop(msg);
      }
      # .......................................................................................

      
      
      
      # .......................................................................................
      # .                                 T
      # . Perform the SVD :  X = U . D . V   on the subsetted data matrix.
      # .......................................................................................      
      sv = svd(dfXSel);                    # SVD on the subsetted data matrix.
      # .......................................................................................


    
      # .......................................................................................
      # . Compute a Cox proportional hazard model on the first K principal component.
      # .
      # . Note that we are using the expansion :
      # .
      # .              --          --                                              
      # .              |  -- x  --> |    
      # .              |      1     |                               
      # .              |  -- x  --> |   .      K             T     
      # .        X =   |      2     |   =     Sum   d   u   v                               
      # .        -     |   . . .    |        l = 1   l  -l  -l
      # .              |  -- x  --> |
      # .              |      n     |
      # .              --          --
      # .
      # . to approximate the sample vectors by the first K principal components.
      # . Here the u_l are n-dimensional and the v_l m-dimensional vectors.
      # .
      # . The coefficient for the i-th sample vector x_i for the l-th PC is thus d_l * u_li.
      # .......................................................................................
      dBuf = matrix(sv$d[1:K], nrow = n, ncol = K, byrow = TRUE);  # Spread onto n rows.
      
      uK = dBuf * sv$u[ , 1:K];            # n * K matrix: projections onto the first K principal components.
      coxK = coxph(Surv(at, as) ~ uK);     # Cox model on K variables.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);  # Likelihood ratio statistic.
      pR = pchisq(qR, df = K, lower.tail = FALSE);   # p-value from likelihood ratio.
      
      coxKsum = summary(coxK);
      coxKcoef = coxKsum$coef;             # Contains the K coefficients and P-values.
      abeta = coxKcoef[ , 1];              # The K Cox coefficients.
      aseBeta = coxKcoef[ , 3];            # Standard errors for the corfficients.
      ap = coxKcoef[ , 5];                 # The corresponding K P-values.
      # .......................................................................................
      # . Compute the loadings on the genes. These are just the components of the
      # . corresponding principal component vectors.
      # .......................................................................................      
      avSel = sv$v[ , 1:K];                # m * K : the first K pc's in the subspace of m selected genes.

      if (K == 1) {
        avSel = as.matrix(avSel);          # Must cast as matrix when K == 1.
      }

      rownames(avSel) = colnames(dfXSel);  # These are the selected gene names.
      colnames(avSel) = paste("pc", 1:K);  # Columns names are those of the pcs.
      
      avSelTot = avSel %*% abeta;          # Summed gene loadings in the subspace of m selected genes.
      # .......................................................................................



      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      cSel = list(abeta = abeta,           # K : the Cox coefficients.
                  aseBeta = aseBeta,       # K : standard errors for the Cox coefficients.
                  ap = ap,                 # K : P-values for the Cox coefficients.
                  qR = qR,                 # Loglikelihood ratio statistic (df = K).          
                  pR = pR,                 # P-value for loglikelihood ratio statistic.
                  avSel = avSel,           # m * K : pc vectors in m-gene expression space.         
                  avSelTot = avSelTot,     # Summed gene loadings in m-gene expression space.    
                  sv = sv,                 # Pass the results of the internal SVD.
                  coxK = coxK);            # Final Cox model on K principal components.

      class(cSel) = 'spc.cox.selected.features';
      # .......................................................................................

      
      # .............
      return (cSel);
      # .............
      

}

# =================================================================================================
# . End of SuperPc.computeCoxOnSelectedFeatures.
# =================================================================================================

      



# =================================================================================================
# . SuperPc.computeBaselineHazardNoTies : computes the baseline hazard function, using the results
# . -----------------------------------   of SuperPc.computeCoxOnSelectedFeatures(). This is
# .                                       a simplified form of the Breslow estimator that assumes
# .                                       that there are no ties in the data.
# .                                 
# .   Syntax:
# .
# .          bh = SuperPc.computeBaselineHazardNoTies(at, as, cSel, dfXSel);
# .
# .   In:
# .         at = n : vector of survival times (n = number of samples).
# .
# .         as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .       cSel = result of supervised principal components computation, returned
# .              by function SuperPc.computeCoxOnSelectedFeatures().
# .
# .     dfXSel = input data frame, subsetted to the feature-selected genes that
# .              were used in the supervised principal components calculation.
# .
# .   Out:
# .      bh = list with members :
# .
# .                       n =  Number of time points.
# .                  atSort =  Array of (sorted) time points.
# .         aLambdaBaseDiff =  Differential baseline hazard function, sorted order.
# .             aLambdaBase =  Baseline hazard function, sorted order.
# .                  aSBase =  Baseline survival function, sorted order.
# .                  aMSort =  Martingale residuals in sorted order.
# .                            All three aLambdaBaseDiff, aLambdaBase and
# .                            (sorted order == keyed on sorted time array, atSort).
# .                      aM =  Martingale residuals in original, unsorted order.
# .
# .................................................................................................
# . We are applying the Breslow estimator for the cumulative hazard function (see. Zhang ST 745,
# . p. 213) :
# .                           _                             _
# .                          |                               | 
# .                          |           dN(x)               | 
# .    Lambda  (t) =    sum  | ----------------------------- | 
# .          0         x < t |    n                          | 
# .                          |   sum   Y (x) exp(beta * z )  | 
# .                          |   l = 1  l                l   | 
# .                          |_                             _|
# .
# . where dN(x) = 1 if there was a death at time x, 0 otherwise (that is, if event was censored)
# .
# =================================================================================================

SuperPc.computeBaselineHazardNoTies <- function(at, as, cSel, dfXSel)
{

      # ........................................................................
      if (class(cSel) != "spc.cox.selected.features") {
        msg = "ERROR: from SuperPc.computeBaselineHazardNoTies: ";
        msg = paste("The input cSel is not of class spc.cox.selected.features.");
        stop(msg);
      }
      # ........................................................................


      # ....................
      n = nrow(dfXSel);      
      m = ncol(dfXSel);
      # ....................

      
      # ..............................................................................
      # . Check consistency of the input data matrix with the cSel object :
      # ..............................................................................      
      mHere = nrow(cSel$avSel);        # avSel is an m * K matrix.
      
      if (mHere != m) {
        msg = "ERROR: from SuperPc.computeBaselineHazardNoTies: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("features as in the input cSel object.", sep = "");
        msg = paste(" dfXSel has m = " , m, " genes.", sep = "");
        msg = paste(" cSel$avSel has = " , mHere, " genes.", sep = "");        
        stop(msg);
      }
      # ...............................................................................


      
      # ...................................................................................
      # . Compute the dot product beta * y for each sample, and henece the
      # . hazard ratio :
      # ...................................................................................
      Y = dfXSel %*% cSel$avSel;                        # n * K matrix of pc's.
      aloghR = Y %*% cSel$abeta;                        # n vector of log-hazard ratios beta * y.
      ahR = exp(aloghR);                                # n vector of hazard ratios exp(beta * y).
      # ...................................................................................
      

      # ...................................................................................
      # . Sort arrays so that samples are ordered with increasing event time :
      # ...................................................................................
      sBuf = sort(at, decreasing = FALSE, index.return = TRUE);    # Sort in increasing order.

      indexSort = sBuf[["ix"]];      # Sort index, used below in sorting the arrays.

      atSort = sBuf[["x"]];          # Sorted array of event times (i.e. sorted array at).
      asSort = as[indexSort];        # Sorted array of indicators (1 = death, 0 = censored) (i.e. deltas).
      ahRSort = ahR[indexSort];      # Sorted array of exp(beta * y).
      # ...................................................................................

      
      
      # ........................................................................................
      # . Build the occupation number array, YO, then use it to generate the denominator terms.
      # .
      # .                        ---------------------
      # .                        1   0   0   0   0   0
      # .    exp(beta * z)       1   1   0   0   0   0
      # .   -------------        1   1   1   0   0   0
      # .   |. . . . . . |  *    1   1   1   1   0   0  = n-array of denominator terms.
      # .   -------------        1   1   1   1   1   0 
      # .                        1   1   1   1   1   1 
      # .                        ---------------------
      # .
      # .      1 * n                    n * n                   1 * n
      # .
      # . Note that the numerators are just the status indicators (1 = death, 0 = censored).      
      # ........................................................................................
      YO = sapply(1:n, function(j){a = rep(0, times = n); a[j:n]= 1; return(a)});
      aBot = ahRSort %*% YO;                 # Denominators for contribution at event time atSort.
                                     
      aLambdaBaseDiff = asSort / aBot;       # Differential hazard estimate, for times atSort.
      aLambdaBase = cumsum(aLambdaBaseDiff); # Cumulative hazard function, for times atSort.
      aSBase = exp(-aLambdaBase);            # Estimate of baseline survival function, for times atSort.
      # ........................................................................................

      
      # ........................................................................................
      # . Compute the median survival time under baseline :
      # ........................................................................................
      temp1 = log(2.0);
      abufL = which(aLambdaBase >= temp1);
      abufR = which(aLambdaBase < temp1);

      if (length(abufL) > 0) {
        iL = max(abufL);
      } else {
        iL = 1;
      }
      
      if (length(abufR) > 0) {
        iR = min(abufR);
      } else {
        iR = n;
      }

      tBaseMed = 0.5 * (atSort[iL] + atSort[iR]);    # Interpolation.
      # ........................................................................................            


      
      # ...................................................................................
      # . Compute the Martingale residuals for the training set :
      # .
      # .    M  =  delta   - exp(beta * Z ) * Lambda0(x )
      # .     i         i                i             i
      # ...................................................................................
      aMSort = asSort - ahRSort * aLambdaBase;     # Martingale residuals in sorted order.
      aM = rep(0.0, times = n);                    # Dummy initial values.
      aM[indexSort] = aMSort;                      # Martingale residuals in original order.
      # ...................................................................................            

      
      # ...............................................................................
      # . Package the results for the baseline hazard functions :
      # ...............................................................................
      bh = list(n = n,                                   # Number of time points.
                atSort = atSort,                         # Array of (sorted) time points.
                aLambdaBaseDiff = aLambdaBaseDiff,       # Differential baseline hazard function.
                aLambdaBase = aLambdaBase,               # Baseline hazard function.
                aSBase = aSBase,                         # Baseline survival function.
                tBaseMed = tBaseMed,                     # Median survival time under baseline.
                aMSort = aMSort,                         # Martingale residuals in sorted order.
                aM = aM);                                # Martingale residuals in original order.
      
      class(bh) = 'spc.baseline.hazard';
      # ...............................................................................

      
      # ............
      return (bh);
      # ............
      
}

# =================================================================================================
# . End of SuperPc.computeBaselineHazardNoTies.
# =================================================================================================      




# =================================================================================================
# . SuperPc.computeCoxPcAndLogHazard : computes the principal components and log-hazard
# . --------------------------------   -ratios for an input data matrix with an arbitrary 
# .                                    set of samples (not necessarily the ones used in
# .                                    the training set).
# .
# .   Syntax:
# .
# .          s = SuperPc.computeCoxPcAndLogHazard(spc, dfXIn);
# .
# .   In:
# .        spc = result of supervised principal components computation, returned
# .              by function SuperPc.computeCox().
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .   Out:
# .      s = list with members :
# .
# .              Y = nIn * K matrix of principal components, where
# .                  nIn = number of rows in dfXIn.
# .
# .         aloghR = nIn vector of log-hazard ratios.
# .            ahR = nIn vector of hazard ratios.
# .          atMed = estimated median survival times.
# .
# =================================================================================================

SuperPc.computeCoxPcAndLogHazard <- function(spc, dfXIn)
{

      # ...........................................................
      if (class(spc) != "spc.cox") {
        msg = "ERROR: from SuperPc.computeCoxPcAndLogHazard: ";
        msg = paste("The input spc is not of class spc.cox.");
        stop(msg);
      }
      # ...........................................................      


      # ..............................................................................
      p = ncol(dfXIn);
      
      if (spc$p != p) {
        msg = "ERROR: from SuperPc.computeCoxPcAndLogHazard: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("features as in the training data matrix.", sep = "");
        msg = paste(" Test has p = " , p, " genes.", sep = "");
        msg = paste(" Training has spc$p = " , spc$p, " genes.", sep = "");        
        stop(msg);
      }
      # ...............................................................................


      
      # ...................................................................................
      # . Compute the principal components and the log-hazard ratios :
      # . center the data using the means computed on the training set,
      # . subset to the genes selected from computation on the training set
      # . compute the principal components, and finally determine the
      # . log-hazard ratios.
      # ...................................................................................
      # . 3-13-2011; J. Theilhaber: special option for nrow = 1.      
      # ...................................................................................
      dfXc = sweep(dfXIn, 2, spc$axm);                # Center each column separately.      
      dfXSel = dfXc[ , spc$indexSel];                 # nIn * m data matrix subsetted to the selected genes.

      if (nrow(dfXc) == 1) {
        dfXSel = matrix(dfXSel, nrow = 1);            # Special case for nrow = 1, to preserve matrix geometry.
      }
      
      Y = dfXSel %*% spc$avSel;                         # nIn * K matrix of pc's.
      colnames(Y) = paste("ypc", 1:spc$K, sep = "");    # Label the pc's.
      aloghR = Y %*% spc$abeta;                         # nIn vector of log-hazard ratios.
      ahR = exp(aloghR);                                # nIn vector of hazard ratios.
      # ...................................................................................
      # . Compute estimated median survival times :
      # ...................................................................................
      bh = SuperPc.getBaselineHazard(spc);               # Baseline hazard information.
      #xxx atMed = bh$tBaseMed * exp(-aloghR);           # Greater hazard -> shorter survival time.
      atMed = SuperPc.computeTMedOnBaseline(bh, aloghR)  # Median survival time estimates.                  
      # ...................................................................................
      

     
      # ..........................................................
      # . Package the results :
      # ..........................................................
      s = list(Y = Y, aloghR = aloghR, ahR = ahR, atMed = atMed);
      # ..........................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of SuperPc.computeCoxPcAndLogHazard.
# =================================================================================================      





# =================================================================================================
# . SuperPc.computeCoxLogLikelihood : computes the partial log-likelihood for an input data
# . -------------------------------   matrix with an arbitrary set of samples (not necessarily
# .                                   the ones used in the training set).
# .
# .   Syntax:
# .          ll = SuperPc.computeCoxLogLikelihood(spc, atIn, asIn, dfXIn);
# .
# .   In:
# .        spc = result of supervised principal components computation, returned
# .              by function SuperPc.computeCox().
# .
# .       atIn = n : vector of survival times (n = number of samples).
# .
# .       asIn = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .   Out:
# .     List ll, with members :
# .
# .                   lOut = l(beta = beta*)
# .                   lRatio = 2 * (l(beta = beta*) - l (beta = 0))
# .
# .      where l(beta) is the log partial likelihood evaluated for all the samples
# .      specified by the data {atIn, asIn, dfXIn}, with beta the K-dimensional
# .      coefficient vector for the K principal components (=  covariates),
# .      and where beta* is the MLE for beta estimated from the data in the training set
# .      which was used to compute spc.
# .
# .      Note that the log-likelihood ratio compares the model computed   
# .      with beta = beta* with a model with beta = 0 :                     
# .                                                                                  
# .                lRatio = 2 * (l(beta*) - l(0))                                         
# .                                                                                  
# .      Under the null hypothesis H0: beta = 0, and with beta* derived from the     
# .      actual input data set, or from a data set from the same population, we should    
# .      approximately have  lRatio ~ Chi2 with K degrees of freedom.
# .
# =================================================================================================

SuperPc.computeCoxLogLikelihood <- function(spc, atIn, asIn, dfXIn)
{

      # ...........................................................
      if (class(spc) != "spc.cox") {
        msg = "ERROR: from SuperPc.computeCoxLogLikelihood: ";
        msg = paste("The input spc is not of class spc.cox.");
        stop(msg);
      }
      # ...........................................................      


      # ...................................................................................
      # . Check for consistency :
      # ...................................................................................      
      nIn = nrow(dfXIn);      # Number of samples in input data matrix.
      p = ncol(dfXIn);        # Number of genes in input data matrix.
      
      if (spc$p != p) {
        msg = "ERROR: from SuperPc.computeCoxLogLikelihood: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("features as in the training data matrix.", sep = "");
        msg = paste(" Test has p = " , p, " genes.", sep = "");
        msg = paste(" Training has spc$p = " , spc$p, " genes.", sep = "");        
        stop(msg);
      }

      ntIn = length(atIn);   # Number of samples in survival time vector.
      nsIn = length(asIn);   # Number of samples in censoring status vector.

      if (ntIn != nIn) {
        msg = "ERROR: from SuperPc.computeCoxLogLikelihood: ";        
        msg = paste("The survival time vector atIn has ntIn = ", ntIn, "samples. ", sep = "");
        msg = paste("This is not the same as the nIn = ", nIn,
                    "samples in the data matrix dfXIn.", sep = "");        
        stop(msg);
      }

      if (nsIn != nIn) {
        msg = "ERROR: from SuperPc.computeCoxLogLikelihood: ";        
        msg = paste("The censoring status vector asIn has nsIn = ", nsIn, "samples. ", sep = "");
        msg = paste("This is not the same as the nIn = ", nIn,
                    "samples in the data matrix dfXIn.", sep = "");        
        stop(msg);
      }
      # ......................................................................................


      # ...............................................................................
      # . Calculate the principal components for the input data matrix :
      # ...............................................................................
      sl = SuperPc.computeCoxPcAndLogHazard(spc, dfXIn);
      # ...............................................................................
      # . Now compute the log partial likelihood l(beta = beta*), where beta is the 
      # . K-dimensional coefficient vector for the K principal components, and where 
      # . beta* is the MLE for beta estimated from the data in the training set that
      # . was used to compute spc.
      # ................................................................................
      coxMLE = coxph(Surv(atIn, asIn) ~ sl$Y,
                     init = spc$abeta,
                     control = coxph.control(iter.max = 0));   # No iterations.

      lOut = coxMLE$loglik[1];
      # ................................................................................
      # . In addition, compute a log-likelihood ratio, comparing the model computed
      # . above with beta = beta*, to a model with beta = 0 :
      # .
      # .      lRatio = 2 * (l(beta*) - l(0))
      # .
      # . Under the null hypothesis H0: beta = 0, and with beta* derived from the
      # . actual input data set, or from a data set from the same population, we should 
      # . approximately have  lRatio ~ Chi2 with K degrees of freedom.
      # ................................................................................
      abetaNull = rep(0.0, times = spc$K);
      
      coxNULL = coxph(Surv(atIn, asIn) ~ sl$Y,
                     init = abetaNull,
                     control = coxph.control(iter.max = 0));    # No iterations.

      lNull = coxNULL$loglik[1];
      lRatio = 2.0 * (lOut - lNull);               # Log likelihood ratio.
      # ................................................................................


      # ....................................................
      # . Package the results :
      # ....................................................
      ll = list(lOut = lOut, lRatio = lRatio);
      # ....................................................

      
      # .............
      return (ll);
      # .............
      
}

# =================================================================================================
# . End of SuperPc.computeCoxLogLikelihood.
# =================================================================================================





# =================================================================================================
# . SuperPc.computeCoxLogLikelihoodWithCov : computes the partial log-likelihood for an input data
# . --------------------------------------   matrix with an arbitrary set of samples (not necessarily
# .                                          the ones used in the training set).
# .
# .   Syntax:
# .          ll = SuperPc.computeCoxLogLikelihoodWithCov(spc, atIn, asIn, dfXIn);
# .
# .   In:
# .        spc = result of supervised principal components computation, returned
# .              by function SuperPc.computeCoxWithCov() or with method
# .              SuperPc.packageSpcCoxWithCov().
# .
# .       atIn = n : vector of survival times (n = number of samples).
# .
# .       asIn = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .       azIn = n : vector of covariate values.
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .   Out:
# .     List ll, with members :
# .
# .                   lOut = l(beta = beta*)
# .                   lRatio = 2 * (l(beta = beta*) - l (beta = 0))
# .
# .      where l(beta) is the log partial likelihood evaluated for all the samples
# .      specified by the data {atIn, asIn, dfXIn}, with beta the K-dimensional
# .      coefficient vector for the K principal components (=  covariates),
# .      and where beta* is the MLE for beta estimated from the data in the training set
# .      which was used to compute spc.
# .
# .      Note that the log-likelihood ratio compares the model computed   
# .      with beta = beta* with a model with beta = 0 :                     
# .                                                                                  
# .                lRatio = 2 * (l(beta*) - l(0))                                         
# .                                                                                  
# .      Under the null hypothesis H0: beta = 0, and with beta* derived from the     
# .      actual input data set, or from a data set from the same population, we should    
# .      approximately have  lRatio ~ Chi2 with K degrees of freedom.
# .
# =================================================================================================

SuperPc.computeCoxLogLikelihoodWithCov <- function(spc, atIn, asIn, azIn, dfXIn)
{

      # ...........................................................
      if (class(spc) != "spc.cox.cov") {
        msg = "ERROR: from SuperPc.computeCoxLogLikelihoodWithCov: ";
        msg = paste("The input spc is not of class spc.cox.cov.");
        stop(msg);
      }
      # ...........................................................      


      # ...................................................................................
      # . Check for consistency :
      # ...................................................................................      
      nIn = nrow(dfXIn);      # Number of samples in input data matrix.
      p = ncol(dfXIn);        # Number of genes in input data matrix.
      
      if (spc$p != p) {
        msg = "ERROR: from SuperPc.computeCoxLogLikelihoodWithCov: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("features as in the training data matrix.", sep = "");
        msg = paste(" Test has p = " , p, " genes.", sep = "");
        msg = paste(" Training has spc$p = " , spc$p, " genes.", sep = "");        
        stop(msg);
      }

      ntIn = length(atIn);   # Number of samples in survival time vector.
      nsIn = length(asIn);   # Number of samples in censoring status vector.
      nzIn = length(azIn);   # Number of samples in covariates vector.

      if (ntIn != nIn) {
        msg = "ERROR: from SuperPc.computeCoxLogLikelihoodWithCov: ";        
        msg = paste("The survival time vector atIn has ntIn = ", ntIn, "samples. ", sep = "");
        msg = paste("This is not the same as the nIn = ", nIn,
                    "samples in the data matrix dfXIn.", sep = "");        
        stop(msg);
      }

      if (nsIn != nIn) {
        msg = "ERROR: from SuperPc.computeCoxLogLikelihoodWithCov: ";        
        msg = paste("The censoring status vector asIn has nsIn = ", nsIn, "samples. ", sep = "");
        msg = paste("This is not the same as the nIn = ", nIn,
                    "samples in the data matrix dfXIn.", sep = "");        
        stop(msg);
      }

      if (nzIn != nIn) {
        msg = "ERROR: from SuperPc.computeCoxLogLikelihoodWithCov: ";        
        msg = paste("The covariate vector azIn has nzIn = ", nzIn, "samples. ", sep = "");
        msg = paste("This is not the same as the nIn = ", nIn,
                    "samples in the data matrix dfXIn.", sep = "");        
        stop(msg);
      }      
      # ......................................................................................


      # ...............................................................................
      # . Calculate the principal components for the input data matrix :
      # ...............................................................................
      sl = SuperPc.computeCoxPcAndLogHazardWithCov(spc, dfXIn, azIn);      
      # ...............................................................................
      # . Now compute the log partial likelihood l(beta = beta*), where beta is the 
      # . K-dimensional coefficient vector for the K principal components, and where 
      # . beta* is the MLE for beta estimated from the data in the training set that
      # . was used to compute spc.
      # ................................................................................
      abetaInit = c(spc$abeta, spc$betaZ, spc$agamma);     # Beta vectors : {1:K, K+1, K+2:2*K+1}.

      nuncens = sum(asIn);                                   # Number of uncensored observations.

      if ((nuncens > 0) && (ntIn > 1)) {
        coxMLE = coxph(Surv(atIn, asIn) ~ sl$Y + azIn + azIn * sl$Y,
                       init = abetaInit,
                       control = coxph.control(iter.max = 0));           # No iterations.
      } else {
        coxMLE = list(loglik = c(0.0));       # Stand-in, for case where all observations are censored,
                                              # or just one observation.
      }

      lOut = coxMLE$loglik[1];
      # ................................................................................
      # . In addition, compute a log-likelihood ratio, comparing the model computed
      # . above with beta = beta*, to a model with beta = 0 :
      # .
      # .      lRatio = 2 * (l(beta*) - l(0))
      # .
      # . Under the null hypothesis H0: beta = 0, and with beta* derived from the
      # . actual input data set, or from a data set from the same population, we should 
      # . approximately have  lRatio ~ Chi2 with K degrees of freedom.
      # ................................................................................
      K21 = 2 * spc$K + 1;
      abetaNull = rep(0.0, times = K21);                               # Beta vectors all 0.

      if ((nuncens > 0) && (ntIn > 1)) {      
        coxNULL = coxph(Surv(atIn, asIn) ~ sl$Y + azIn + azIn * sl$Y,
                        init = abetaNull,
                        control = coxph.control(iter.max = 0));    # No iterations.
      } else {
        coxNULL = list(loglik = c(0.0));     # Stand-in, for case where all observations are censored,
                                             # or just one observation.        
      }

      lNull = coxNULL$loglik[1];
      lRatio = 2.0 * (lOut - lNull);               # Log likelihood ratio.
      # ................................................................................


      # ....................................................
      # . Package the results :
      # ....................................................
      ll = list(lOut = lOut, lRatio = lRatio);
      # ....................................................

      
      # .............
      return (ll);
      # .............
      
}

# =================================================================================================
# . End of SuperPc.computeCoxLogLikelihoodWithCov.
# =================================================================================================








# =================================================================================================
# . SuperPc.computeMartingaleResiduals : computes Martingale residuals for a test set, using
# . ----------------------------------   hazard ratios and cumlative baseline hazard function
# .                                      computed using an independent (or the same) data set
# .                                      as trining set.
# .
# .   Syntax:
# .
# .        mr = SuperPc.computeMartingaleResiduals(spcTrain, atIn, asIn, ahRIn);
# .
# .   In:
# .              >>Training set :
# .
# .   spcTrain = result of supervised principal components computation, returned
# .              by function SuperPc.computeCox() or SuperPc.computeCoxWithCov().
# .
# .              >>Test set (which may be different or the same as the training set) :
# .
# .       atIn = nIn : vector of survival times (nIn = number of samples), not necessarily
# .                    the same as in spcTrain.
# .
# .       asIn = nIn : vector of censoring statuses (1 = not censored, 0 = censored).
# .                    The number of samples is not necessarily the same as in spcTrain.
# .
# .      ahRIn = result of computation of log hazard ratios for the test set.
# .              These are the values :
# .                             
# .                     exp(beta' . y  ), i = 1, 2, ... , nIn.
# .                                  i
# .
# .              This can be computed with (for no external covariate) :
# .
# .                  sl = SuperPc.computeCoxPcAndLogHazard(spc, dfXIn);
# .                  ahRIn = sl$ahR;
# .
# .              or with (with external covariate) :
# .
# .                  sl = SuperPc.computeCoxPcAndLogHazardWithCov(spc, dfXIn, azIn);
# .                  ahRIn = sl$ahR;
# .
# .              where dfXIn = input data frame with the nIn samples
# .              corresponding to atIn and asIn. dfXIn need not be the same
# .              data matrix as the one used in the training set, but it
# .              must have the same set of genes as in the training set.
# .              azIn is the corresponding vector of external covariates, for
# .              analysis with external covariate.
# .
# .   Out:
# .      mr = list with members :
# .             nIn = number of samples in input test set.
# .             atIn = nIn : input array of survival times.
# .             asIn = nIn : input array of censoring statuses.
# .             aM = nIn : output array of Martingale  residuals
# .                  for the input samples.
# .             Mrms = root-mean-square average of the Martingale residuals.
# .
# .................................................................................................
# . * The Martingale residuals are given by :
# .
# .           M  =  delta   - exp(beta' * Y ) * Lambda0(x )  ,   i = 1, 2, ...., nIn.
# .            i         i                 i             i
# .
# . where delta_i is the status indicator (delta_i = 1, not censored, delta_i = 0, censored),
# . beta = vector of coefficents, estimated from Cox proportional hazards model on the
# . training set, Y_i = V' * x_i = vector of principal components, computed using the principal
# . component vectors derived from the training set, and Lambda_0 is the baseline cumulative
# . hazard, also computed from the training set.
# .
# . * The root-mean-square value for the Martingale residuals is given by :
# .
# .                  1    nIn   2   1/2
# .       Mrms = ( -----  sum  M   )
# .                 nIn   i=1   i
# =================================================================================================

SuperPc.computeMartingaleResiduals <- function(spcTrain, atIn, asIn, ahRIn)
{

      # ...........................................................
      if ((class(spcTrain) != "spc.cox")
          && (class(spcTrain) != "spc.cox.cov")) {
        msg = "ERROR: from SuperPc.computeMartingaleResiduals: ";
        msg = paste("The input spcTrain is not of class spc.cox or class spc.cox.cov.");
        stop(msg);
      }
      # ...........................................................      


      # ...................................................................................
      # . Check for consistency :
      # ...................................................................................      
      ntIn = length(atIn);       # Number of samples in survival time vector.
      nsIn = length(asIn);       # Number of samples in censoring status vector.
      nhRIn = length(ahRIn);     # Number of samples in hazard ratio vector.

      nIn = ntIn;                # Should be the same for all three input arrays.

      if (nsIn != nIn) {
        msg = "ERROR: from SuperPc.computeMartingaleResiduals: ";        
        msg = paste("The censoring status vector asIn has nsIn = ", nsIn, "samples. ", sep = "");
        msg = paste("This is not the same as the ntIn = ", nIn,
                    "samples in the survival time array atIn.", sep = "");        
        stop(msg);
      }

      if (nhRIn != nIn) {
        msg = "ERROR: from SuperPc.computeMartingaleResiduals: ";        
        msg = paste("The hazard ratio vector ahRIn has nhRIn = ", nhRIn, "samples. ", sep = "");
        msg = paste("This is not the same as the ntIn = ", nIn,
                    "samples in the survival time array atIn.", sep = "");        
        stop(msg);
      }      
      # ......................................................................................


      
      # ......................................................................................
      # . Get the baseline hazard information :
      # ......................................................................................      
      bh = SuperPc.getBaselineHazard(spcTrain);
      atSort = bh$atSort;
      aLambdaBase = bh$aLambdaBase;
      # ......................................................................................
      # . Find the indices in the training set array atSort which correspond
      # . to the test survival times : for each test set survival time tTest,
      # . map to the grid point for the largest tSort < tTest.
      # .
      # . Note that values of tTest < min(atSort) get mapped to index = 1 in atSort.
      # ......................................................................................
      tmin = min(atSort);               # Floor for grid values.
      
      indexAtSort = sapply(1:nIn,
                          function(j){imax = ifelse(atIn[j] > tmin,
                                             max(which(atSort <= atIn[j])), 1);
                                      return(imax);});
      
      aLambdaBaseIn = aLambdaBase[indexAtSort];
      # ......................................................................................
      # . Compute the Martingale residuals for the test set :
      # .
      # .    M  =  delta   - exp(beta * Y ) * Lambda0(x )
      # .     i         i                i             i
      # ......................................................................................
      aM = asIn - ahRIn * aLambdaBaseIn;     # Martingale residuals in non-sorted order.
      Mrms = sqrt(mean(aM * aM));            # Root mean square value.
      # .......................................................................................
      

     
      # ..........................................................
      # . Package the results :
      # ..........................................................
      mr = list(at = atIn,
                as = asIn,
                aM = aM,
                Mrms = Mrms);
      # ..........................................................

      
      # ............
      return (mr);
      # ............
      
}

# =================================================================================================
# . End of SuperPc.computeMartingaleResiduals.
# =================================================================================================      




# =================================================================================================
# . SuperPc.checkDataMatricesForCox : checks compatibility of the numerical data frame and the
# . -------------------------------   experimental design data frame for Cox proportional hazard
# .                                   regression.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForCox(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                  methodFs = feature selection method.
# .                      mtop = number of features selected under feature selection
# .                             method `mtop'.
# .                         K = number of principal components used.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain (unless tTrain = NONE, in which case all instances
# .        become training set members).
# .      - if tTrain is not NONE, then for that factor, dfE has at least two instances with value
# .        'train'.
# .      - if tTest is not NONE, then for that factor, dfE has at least two instances with value
# .        'test'.
# .      - checks that mtop >= K.
# .
# =================================================================================================

SuperPc.checkDataMatricesForCox <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCox: inparam does not have member tTrain";
      stop(msg);
    }
    
    if (is.null(inparam$tTest)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCox: inparam does not have member tTest";
      stop(msg);
    }
    
    if (is.null(inparam$methodFs)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCox: inparam does not have member methodFs";
      stop(msg);
    }

    if (is.null(inparam$mtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCox: inparam does not have member mtop";
      stop(msg);
    }

    if (is.null(inparam$K)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCox: inparam does not have member K";
      stop(msg);
    }            
    # .......................................................................................    

    
    
    # .......................................................................................
    # . Check existence of training set and test set factors :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {
      if (is.null(dfE[[inparam$tTrain]])) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCox :\n", sep = "");
        msg = paste(msg, "the factor tTrain = ", inparam$tTrain,
                    " does not exist in the input experimental design.", sep = "");
        return (msg);
      }
    }

    if (inparam$tTest != 'NONE') {
      if (is.null(dfE[[inparam$tTest]])) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCox :\n", sep = "");
        msg = paste(msg, "the factor tTest = ", inparam$tTest,
                    " does not exist in the input experimental design.", sep = "");
        return (msg);
      }
    }    
    # .......................................................................................

    
    # .......................................................................................
    # . Check consistency of number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCox :\n", sep = "");      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................

    
    # .......................................................................................
    # . Check on the number of training set members.
    # . General case, with a not NONE factor specified :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {    
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    
      if (nTrain == 0) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCox :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                     inparam$tTrain , " = train." , sep = "");
        return (msg);
      }

      if (nTrain < 2) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCox :\n", sep = "");         
        msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                    " records with values for factor ", inparam$tTrain , " = train. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, all members retained :
    # .......................................................................................
    if (inparam$tTrain == 'NONE') {    
      nTrain = n;                               # All samples are training set members.
      nNone = 0;                                # Number of all other samples is 0.
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Check on the number of test set members.
    # . General case, with a not NONE factor specified :
    # .......................................................................................
    if (inparam$tTest != 'NONE') {    
      nTest = sum(dfE[[inparam$tTest]] == 'test');   # Number of testing set members.
    
      if (nTest == 0) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCox :\n", sep = "");
        msg = paste(msg, "you specified a test set, but ", sep = "");        
        msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                     inparam$tTest , " = test." , sep = "");
        return (msg);
      }

      if (nTest < 2) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCox :\n", sep = "");
        msg = paste(msg, "you specified a test set, but ", sep = "");        
        msg = paste(msg, "the input experimental design has only nTest = ", nTest,
                    " records with values for factor ", inparam$tTest , " = test. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................


    
    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");                
    # .......................................................................................        



    # .......................................................................................
    # . Check on number of features selected relative to the number of principal components :
    # .......................................................................................    
    if (inparam$methodFs == 'mtop') {
      if (inparam$mtop < inparam$K) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCox : ", sep = "");        
        msg = paste(msg, "the number of features to be selected, mtop = ", inparam$mtop,
                    ", is less than the number of principal components, K = " , inparam$K, ".", sep = "");
        return (msg);        
      }
    }

    if (nTrain < inparam$K) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCox : ", sep = "");        
      msg = paste(msg, "the number of samples in the training set, nTrain = ", nTrain,
        ", is less than the number of principal components, K = " , inparam$K, ".", sep = "");
      return (msg);        
    }
    # .......................................................................................
    

    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForCox.
# =================================================================================================




# =================================================================================================
# . SuperPc.checkDataMatricesForCoxCv : checks compatibility of the numerical data frame and the
# . ---------------------------------   experimental design data frame for cross-validation of
# .                                     Cox proportional hazard model.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForCoxCv(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                   tSplit = factor in dfE defining the further subdivision of the training
# .                            set members into train and test sets for the cross-validation.
# .                            values = 'train' denote the training set members in that group,
# .                            values = 'test' denote the test set members in that group.
# .                            values = 'NONE' are not included. All other values are invalid.
# .
# .                            If tSplit = 'NONE'itself, then checks on this field are not done
# .                            (it is ignored).
# .
# .             parameterScan = parameter to be scanned in CV (mtop or K).
# .                     amtop = array of mtop values to be scanned (when parameterScan = 'mtop').
# .                         K = fixed number of principal components used (when parameterScan = 'mtop').
# .                        aK = array of number of principal components to be scanned (when parameterScan = 'K').
# .                      mtop = fixed number of features used (when parameterScan = 'K').
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .      - dfE has factor tSplit (check done only if tSplit not equal to 'NONE').
# .      - for the indicated factor tSplit (for non-NONE value), values in dfE 
# .        are either 'train', 'test' or 'NONE', and that the resulting training and
# .        test sets each have at least two member.
# .
# =================================================================================================

SuperPc.checkDataMatricesForCoxCv <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$tSplit)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: inparam does not have member tSplit";
      stop(msg);
    }
    
    if (is.null(inparam$parameterScan)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: inparam does not have member parameterScan";
      stop(msg);
    }
    
    if (is.null(inparam$amtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: inparam does not have member amtop";
      stop(msg);
    }

    if (is.null(inparam$K)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: inparam does not have member K";
      stop(msg);
    }
    
    if (is.null(inparam$aK)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: inparam does not have member aK";
      stop(msg);
    }

    if (is.null(inparam$mtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: inparam does not have member mtop";
      stop(msg);
    }

    if (is.null(inparam$methodSplit)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: inparam does not have member methodSplit";
      stop(msg);
    }    
    # .......................................................................................    


    
    # .......................................................................................
    stopifnot((inparam$methodSplit == 'given') || (inparam$methodSplit == 'vfold')
              || (inparam$methodSplit == 'vfoldStrict'));
    # .......................................................................................

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }

    if (inparam$methodSplit == 'given') {
      if (is.null(dfE[[inparam$tSplit]])) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";              
        msg = paste(msg, "the factor inparam$tSplit = ", inparam$tSplit,
                         " does not exist in the input experimental design,", sep = "");
        msg = paste(msg, " but is required under methodSplit = given.", sep = "");
        return (msg);
      }
    }    
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;    # All samples are in the training set.
      nNone = 0;     # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                   " records with values for factor ", inparam$tTrain , " = train. " ,
                   " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................



    
    # .......................................................................................
    # . Check train/test split. Compute ntrainCV, ntestCV.
    # .
    # . >> methodSplit = given :
    # .......................................................................................
    if (inparam$methodSplit == 'given') {    
      if (inparam$tTrain != 'NONE') {        
        dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ]; # The training set is a subset.
      } else if (inparam$tTrain == 'NONE') {
        dfETrain = dfE;                                     # The training set is the entire set.
      }

      buf = dfETrain[[inparam$tSplit]];
      bufEx = buf[(buf != 'train') & (buf != 'test') & (buf != 'NONE')];

      if (length(bufEx) > 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";         
        msg = paste(msg, "the input experimental design for factor inparam$tSplit = ", inparam$tSplit,
                         "has invalid values, which are neither train, test or NONE.", sep = "");
        return (msg);
      }

      nTrainCv = sum(dfETrain[[inparam$tSplit]] == 'train');   # Number of cv training set members.
      nTestCv = sum(dfETrain[[inparam$tSplit]] == 'test');     # Number of cv test set members.      
    
      if (nTrainCv == 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";
        msg = paste(msg, "the input experimental design has 0 cv training set ",
                         "records with values for factor ",
                         inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTrainCv < 2) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";        
        msg = paste(msg, "the input experimental design has only nTrainCv = ", nTrainCv,
                         " records with values for factor ", inparam$tSplit , " = train. " ,
                         " The minimum number is 2. ", sep = "");
        return (msg);
      }

      if (nTestCv == 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";        
        msg = paste(msg, "the input experimental design has 0 cv test set ",
                    "records with values for factor ",
                    inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTestCv < 2) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCv: ";        
        msg = paste("the input experimental design has only nTestCv = ", nTestCv,
                    " records with values for factor ", inparam$tSplit , " = test. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . >> methodSplit = vfold :
    # .    The training set and the test set must each have at least 2 elements.
    # .    Note that we require above that nTrain >= 4, so that this is always possible.
    # ...................................................................................
    if (inparam$methodSplit == 'vfold') {
      nTestCv = floor(nTrain * inparam$ft);

      if (nTestCv < 2) {
        nTestCv = 2;                    # At least 2 elements in the test set.
      }

      n1 = nTrain - 1;

      if (nTestCv >= n1) {
        nTestCv = nTrain - 2;           # At least 2 elements in the training set.
      }

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }
    # .......................................................................................
    # . >> methodSplit = vfoldStrict :
    # .    
    # .    
    # ...................................................................................
    if (inparam$methodSplit == 'vfoldStrict') {
      csTemp = Stat.generateSplitsForVfold(nTrain, inparam$ft, flagRandom = FALSE);
      nTestCv = csTemp$ntest;

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }    
    # .....................................................................................

    

    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");

    cat("             Given cross-validation split of training set :\n", sep = "");      
    cat("             Training set : nTrainCv = ", nTrainCv, "\n", sep = "");
    cat("             Test set : nTestCv = ", nTestCv, "\n", sep = "");
    # .......................................................................................



    # .......................................................................................
    # . Check on constraints imposed by matrix rank.
    # . >>Case 1: scan mtop.
    # .......................................................................................
    if (inparam$parameterScan == 'mtop') {
      mtopMin = min(inparam$amtop);            # Smallest number of features used in scan.
      nTrainCv1 = nTrainCv - 1;                # Independent rows after mean-centering each column.
      rankMin = min(nTrainCv1, mtopMin);       # Minimum data matrix rank generated.
      
      if (inparam$K > rankMin) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCv : ", sep = "");
        msg = paste(msg, "for parameterScan = mtop, the number of principal components", sep = "");
        msg = paste(msg, " K = ", K, " is greater than the smallest matrix rank generated,", sep = "");
        msg = paste(msg, " rankMin = min(nTrainCv -1, mtopMin) = min(",
                         nTrainCv1, ", ", mtopMin, ")", sep = "");        
        return (msg);        
      }
    }
    # .......................................................................................    
    # . >>Case 2: scan K.
    # .......................................................................................
    if (inparam$parameterScan == 'K') {
      KMax = max(inparam$aK);
      nTrainCv1 = nTrainCv - 1;                # Independent rows after mean-centering each column.
      rankMin = min(nTrainCv1, inparam$mtop);  # Data matrix rank after feature selection.

      if (rankMin <= KMax) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCv : ", sep = "");
        msg = paste(msg, "for parameterScan = K, the maximum number of principal components", sep = "");
        msg = paste(msg, " KMax = ", KMax, " is greater than the matrix rank after feature selection,", sep = "");
        msg = paste(msg, " rankMin = min(nTrainCv -1, mtop) = min(",
                         nTrainCv1, ", ", inparam$mtop, ") = ", rankMin, sep = "");        
        return (msg);        
      }
    }
    # .......................................................................................            


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForCoxCv.
# =================================================================================================




# =================================================================================================
# . SuperPc.checkDataMatricesForCoxFs : checks compatibility of the numerical data frame and the
# . ---------------------------------   experimental design data frame for Cox proportional hazard
# .                                     regression feature selection.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForCoxFs(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain (unless tTrain = NONE, in which case all instances
# .        become training set members).
# .      - if tTrain is not NONE, then for that factor, dfE has at least two instances with value
# .        'train'.
# .
# =================================================================================================

SuperPc.checkDataMatricesForCoxFs <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxFs: inparam does not have member tTrain";
      stop(msg);
    }
    # .......................................................................................    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {
      if (is.null(dfE[[inparam$tTrain]])) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxFs :\n", sep = "");
        msg = paste(msg, "the factor tTrain = ", inparam$tTrain,
                    " does not exist in the input experimental design.", sep = "");
        return (msg);
      }
    }

    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxFs :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxFs :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................

    
    
    # .......................................................................................
    # . Check consistency of number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxFs :\n", sep = "");      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................

    
    # .......................................................................................
    # . Check on the number of training set members.
    # . General case, with a not NONE factor specified :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {    
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    
      if (nTrain == 0) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxFs :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                     inparam$tTrain , " = train." , sep = "");
        return (msg);
      }

      if (nTrain < 2) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxFs :\n", sep = "");         
        msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                    " records with values for factor ", inparam$tTrain , " = train. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, all members retained :
    # .......................................................................................
    if (inparam$tTrain == 'NONE') {    
      nTrain = n;                               # All samples are training set members.
      nNone = 0;                                # Number of all other samples is 0.
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");                
    # .......................................................................................        


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForCoxFs.
# =================================================================================================




# =================================================================================================
# . SuperPc.checkDataMatricesForRegressFs : checks compatibility of the numerical data frame and the
# . -------------------------------------   experimental design data frame for Cox proportional hazard
# .                                         regression feature selection.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForRegressFs(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain (unless tTrain = NONE, in which case all instances
# .        become training set members).
# .      - if tTrain is not NONE, then for that factor, dfE has at least two instances with value
# .        'train'.
# .
# =================================================================================================

SuperPc.checkDataMatricesForRegressFs <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressFs: inparam does not have member tTrain.";
      stop(msg);
    }

    if (is.null(inparam$tY)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressFs: inparam does not have member tY.";
      stop(msg);
    }    
    # .......................................................................................    

    
    
    # .......................................................................................
    # . Check existence of training set factor :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {
      if (is.null(dfE[[inparam$tTrain]])) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegressFs :\n", sep = "");
        msg = paste(msg, "the factor tTrain = ", inparam$tTrain,
                    " does not exist in the input experimental design.", sep = "");
        return (msg);
      }
    }

    if (is.null(dfE[[inparam$tY]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegressFs :\n", sep = "");
      msg = paste(msg, "the factor tY = ", inparam$tY,
                  " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    # .......................................................................................

    
    # .......................................................................................
    # . Check consistency of number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegressFs :\n", sep = "");      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................

    
    # .......................................................................................
    # . Check on the number of training set members.
    # . General case, with a not NONE factor specified :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {    
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    
      if (nTrain == 0) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegressFs :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                     inparam$tTrain , " = train." , sep = "");
        return (msg);
      }

      if (nTrain < 2) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegressFs :\n", sep = "");         
        msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                    " records with values for factor ", inparam$tTrain , " = train. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, all members retained :
    # .......................................................................................
    if (inparam$tTrain == 'NONE') {    
      nTrain = n;                               # All samples are training set members.
      nNone = 0;                                # Number of all other samples is 0.
    }
    # .......................................................................................



    # .......................................................................................
    # . For logistic models, check that the designated output variable is indeed
    # . binary, Y e {0, 1}.
    # .......................................................................................
    if (inparam$modelType == 'logistic') {
      msgBin = Cox.checkBinary(dfE[[inparam$tY]]);

      if (msgBin != 'ok') {
        cat("ERROR: from SuperPc.checkDataMatricesForRegressFs:\n", sep = "");
        cat("For the designated output variable factor tY = ", inparam$tY, "\n", sep = "");
        cat(msgBin);
        stop();
      }

      n1 = sum(dfE[[inparam$tY]]);    # Number of instances with y = 1.

      if (n1 == n) {
        cat("ERROR: from SuperPc.checkDataMatricesForRegressFs:\n", sep = "");
        cat("All values of output variable Y are equal to 1.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }

      if (n1 == 0) {
        cat("ERROR: from SuperPc.checkDataMatricesForRegressFs:\n", sep = "");
        cat("All values of output variable Y are equal to 0.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }            
    }
    # .......................................................................................        

    
    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");                
    # .......................................................................................        


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForRegressFs.
# =================================================================================================





# =================================================================================================
# . SuperPc.checkDataMatricesForRegress : checks compatibility of the numerical data frame and the
# . -----------------------------------   experimental design data frame for regression model.
# .                                 
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForRegress(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                  methodFs = feature selection method.
# .                      mtop = number of features selected under feature selection
# .                             method `mtop'.
# .                         K = number of principal components used.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain (unless tTrain = NONE, in which case all instances
# .        become training set members).
# .      - if tTrain is not NONE, then for that factor, dfE has at least two instances with value
# .        'train'.
# .      - checks that mtop >= K.
# .
# =================================================================================================

SuperPc.checkDataMatricesForRegress <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegress: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$tY)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegress: inparam does not have member tY.";
      stop(msg);
    }
    
    if (is.null(inparam$methodFs)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegress: inparam does not have member methodFs";
      stop(msg);
    }

    if (is.null(inparam$mtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegress: inparam does not have member mtop";
      stop(msg);
    }

    if (is.null(inparam$K)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegress: inparam does not have member K";
      stop(msg);
    }            
    # .......................................................................................    

    
    
    # .......................................................................................
    # . Check existence of training set factor :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {
      if (is.null(dfE[[inparam$tTrain]])) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegress :\n", sep = "");
        msg = paste(msg, "the factor tTrain = ", inparam$tTrain,
                    " does not exist in the input experimental design.", sep = "");
        return (msg);
      }
    }

    if (is.null(dfE[[inparam$tY]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegress :\n", sep = "");
      msg = paste(msg, "the factor tY = ", inparam$tY,
                  " does not exist in the input experimental design.", sep = "");
      return (msg);
    }    
    # .......................................................................................

    
    # .......................................................................................
    # . Check consistency of number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegress :\n", sep = "");      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................

    
    # .......................................................................................
    # . Check on the number of training set members.
    # . General case, with a not NONE factor specified :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {    
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    
      if (nTrain == 0) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegress :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                     inparam$tTrain , " = train." , sep = "");
        return (msg);
      }

      if (nTrain < 2) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegress :\n", sep = "");         
        msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                    " records with values for factor ", inparam$tTrain , " = train. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, all members retained :
    # .......................................................................................
    if (inparam$tTrain == 'NONE') {    
      nTrain = n;                               # All samples are training set members.
      nNone = 0;                                # Number of all other samples is 0.
    }
    # .......................................................................................



    # .......................................................................................
    # . For logistic models, check that the designated output variable is indeed
    # . binary, Y e {0, 1}.
    # .......................................................................................
    if (inparam$modelType == 'logistic') {
      if (inparam$tTrain != 'NONE') {        
        dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ]; # The training set is a subset.
      } else if (inparam$tTrain == 'NONE') {
        dfETrain = dfE;                                     # The training set is the entire set.
      }

      msgBin = Cox.checkBinaryNoNA(dfETrain[[inparam$tY]]);

      if (msgBin != 'ok') {
        cat("ERROR: from SuperPc.checkDataMatricesForRegress:\n", sep = "");
        cat("For the designated output variable factor tY = ", inparam$tY, "\n", sep = "");
        cat(msgBin);
        stop();
      }

      nall = nrow(dfETrain);
      n1 = sum(dfETrain[[inparam$tY]]);    # Number of instances with y = 1.

      if (n1 == nall) {
        cat("ERROR: from SuperPc.checkDataMatricesForRegress:\n", sep = "");
        cat("All values of output variable Y are equal to 1.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }

      if (n1 == 0) {
        cat("ERROR: from SuperPc.checkDataMatricesForRegress:\n", sep = "");
        cat("All values of output variable Y are equal to 0.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }      
    }
    # .......................................................................................        
    
    


    
    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");                
    # .......................................................................................        



    # .......................................................................................
    # . Check on number of features selected relative to the number of principal components :
    # .......................................................................................    
    if (inparam$methodFs == 'mtop') {
      if (inparam$mtop < inparam$K) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegress : ", sep = "");        
        msg = paste(msg, "the number of features to be selected, mtop = ", inparam$mtop,
                    ", is less than the number of principal components, K = " , inparam$K, ".", sep = "");
        return (msg);        
      }
    }

    if (nTrain < inparam$K) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegress : ", sep = "");        
      msg = paste(msg, "the number of samples in the training set, nTrain = ", nTrain,
        ", is less than the number of principal components, K = " , inparam$K, ".", sep = "");
      return (msg);        
    }
    # .......................................................................................
    

    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForRegress.
# =================================================================================================





# ========================================================================================================
# . SuperPc.checkDataMatricesForCoxCvWithCov : checks compatibility of the numerical data frame and the
# . ----------------------------------------   experimental design data frame for cross-validation of
# .                                            Cox proportional hazard model.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForCoxCvWithCov(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                   tSplit = factor in dfE defining the further subdivision of the training
# .                            set members into train and test sets for the cross-validation.
# .                            values = 'train' denote the training set members in that group,
# .                            values = 'test' denote the test set members in that group.
# .                            values = 'NONE' are not included. All other values are invalid.
# .
# .                            If tSplit = 'NONE'itself, then checks on this field are not done
# .                            (it is ignored).
# .
# .             parameterScan = parameter to be scanned in CV (mtop or K).
# .                     amtop = array of mtop values to be scanned (when parameterScan = 'mtop').
# .                         K = fixed number of principal components used (when parameterScan = 'mtop').
# .                        aK = array of number of principal components to be scanned (when parameterScan = 'K').
# .                      mtop = fixed number of features used (when parameterScan = 'K').
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .      - dfE has factor tSplit (check done only if tSplit not equal to 'NONE').
# .      - for the indicated factor tSplit (for non-NONE value), values in dfE 
# .        are either 'train', 'test' or 'NONE', and that the resulting training and
# .        test sets each have at least two member.
# .
# ========================================================================================================

SuperPc.checkDataMatricesForCoxCvWithCov <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$tSplit)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: inparam does not have member tSplit";
      stop(msg);
    }
    
    if (is.null(inparam$parameterScan)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: inparam does not have member parameterScan";
      stop(msg);
    }
    
    if (is.null(inparam$amtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: inparam does not have member amtop";
      stop(msg);
    }

    if (is.null(inparam$K)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: inparam does not have member K";
      stop(msg);
    }
    
    if (is.null(inparam$aK)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: inparam does not have member aK";
      stop(msg);
    }

    if (is.null(inparam$mtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: inparam does not have member mtop";
      stop(msg);
    }    
    # .......................................................................................    


    
    # .......................................................................................
    stopifnot((inparam$methodSplit == 'given') || (inparam$methodSplit == 'vfold')
              || (inparam$methodSplit == 'vfoldStrict'));
    # .......................................................................................

    

    # .......................................................................................
    # . Check existence of basic factors :
    # .......................................................................................
    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................
    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }

    if (inparam$methodSplit == 'given') {
      if (is.null(dfE[[inparam$tSplit]])) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";              
        msg = paste(msg, "the factor inparam$tSplit = ", inparam$tSplit,
                         " does not exist in the input experimental design,", sep = "");
        msg = paste(msg, " but is required under methodSplit = given.", sep = "");
        return (msg);
      }
    }    
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Check on bounds relating to the number of genes in the data matrix :
    # .......................................................................................
    if (inparam$parameterScan == 'mtop') {
      if (inparam$mtophi > p) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov:\n";
        msg = paste(msg, "Under option parameterScan = mtop\n", sep = "");
        msg = paste(msg, "the upper bound for mtop is mtophi = ", inparam$mtophi,
                    " which is greater than the number of genes, p = ", p, sep = "");
        return (msg);
      }
    }

    if (inparam$parameterScan == 'K') {
      if (inparam$mtop > p) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov:\n";
        msg = paste(msg, "Under option parameterScan = K\n", sep = "");
        msg = paste(msg, "the fixed value of mtop is mtop = ", inparam$mtop,
                    " which is greater than the number of genes, p = ", p, sep = "");
        return (msg);
      }
    }    
    # .......................................................................................    


    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;    # All samples are in the training set.
      nNone = 0;     # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                   " records with values for factor ", inparam$tTrain , " = train. " ,
                   " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................



    
    # .......................................................................................
    # . Check train/test split. Compute ntrainCV, ntestCV.
    # .
    # . >> methodSplit = given :
    # .......................................................................................
    if (inparam$methodSplit == 'given') {    
      if (inparam$tTrain != 'NONE') {        
        dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ]; # The training set is a subset.
      } else if (inparam$tTrain == 'NONE') {
        dfETrain = dfE;                                     # The training set is the entire set.
      }

      buf = dfETrain[[inparam$tSplit]];
      bufEx = buf[(buf != 'train') & (buf != 'test') & (buf != 'NONE')];

      if (length(bufEx) > 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";         
        msg = paste(msg, "the input experimental design for factor inparam$tSplit = ", inparam$tSplit,
                         "has invalid values, which are neither train, test or NONE.", sep = "");
        return (msg);
      }

      nTrainCv = sum(dfETrain[[inparam$tSplit]] == 'train');   # Number of cv training set members.
      nTestCv = sum(dfETrain[[inparam$tSplit]] == 'test');     # Number of cv test set members.      
    
      if (nTrainCv == 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";
        msg = paste(msg, "the input experimental design has 0 cv training set ",
                         "records with values for factor ",
                         inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTrainCv < 2) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";        
        msg = paste(msg, "the input experimental design has only nTrainCv = ", nTrainCv,
                         " records with values for factor ", inparam$tSplit , " = train. " ,
                         " The minimum number is 2. ", sep = "");
        return (msg);
      }

      if (nTestCv == 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";        
        msg = paste(msg, "the input experimental design has 0 cv test set ",
                    "records with values for factor ",
                    inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTestCv < 2) {
        msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov: ";        
        msg = paste("the input experimental design has only nTestCv = ", nTestCv,
                    " records with values for factor ", inparam$tSplit , " = test. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . >> methodSplit = vfold :
    # .    The training set and the test set must each have at least 2 elements.
    # .    Note that we require above that nTrain >= 4, so that this is always possible.
    # ...................................................................................
    if (inparam$methodSplit == 'vfold') {
      nTestCv = floor(nTrain * inparam$ft);

      if (nTestCv < 2) {
        nTestCv = 2;                    # At least 2 elements in the test set.
      }

      n1 = nTrain - 1;

      if (nTestCv >= n1) {
        nTestCv = nTrain - 2;           # At least 2 elements in the training set.
      }

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }
    # .......................................................................................
    # . >> methodSplit = vfoldStrict :
    # .    
    # .    
    # ...................................................................................
    if (inparam$methodSplit == 'vfoldStrict') {
      csTemp = Stat.generateSplitsForVfold(nTrain, inparam$ft, flagRandom = FALSE);
      nTestCv = csTemp$ntest;

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }    
    # .....................................................................................



    
    # .......................................................................................
    # . Check on the external covariate :
    # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
    # . Note that this applies only to the cross-validation program, and not to the
    # . feature selection or model building cases.
    # .......................................................................................    
    msgBin = Cox.checkBinary(dfE[[inparam$tCov]]);

    if (msgBin != 'ok') {
      msg = paste("ERROR: from SuperPc.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, msgBin);

      return(msg);
    }
    # .......................................................................................

    

    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");

    cat("             Given cross-validation split of training set :\n", sep = "");      
    cat("             Training set : nTrainCv = ", nTrainCv, "\n", sep = "");
    cat("             Test set : nTestCv = ", nTestCv, "\n", sep = "");
    # .......................................................................................



    # .......................................................................................
    # . Check on constraints imposed by matrix rank.
    # . >>Case 1: scan mtop.
    # .......................................................................................
    if (inparam$parameterScan == 'mtop') {
      mtopMin = min(inparam$amtop);            # Smallest number of features used in scan.
      nTrainCv1 = nTrainCv - 1;                # Independent rows after mean-centering each column.
      rankMin = min(nTrainCv1, mtopMin);       # Minimum data matrix rank generated.
      # ......................................................................................
      # . Degrees of freedom in the Cox model :
      # . Note that in the formula below I am overestimating the number of degrees of freedom of
      # . the model by writing df = 3 * K + 1, instead of the true value df = 2 * K + 1.
      # . I'm putting in the factor of 3 for safety, as convergence seems to break down
      # . even when the limit is not strictly reached.
      # ......................................................................................      
      dfBuf = 3 * inparam$K + 1;                # Safety factor intorduced; should really be 2 * K + 1.
      # ......................................................................................
      # . Now test :
      # ......................................................................................            
      if (dfBuf > rankMin) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCvWithCov : ", sep = "");
        msg = paste(msg, "for parameterScan = mtop, the number of degrees of freedom in the Cox model", sep = "");
        msg = paste(msg, " dfBuf = ", dfBuf, " (3 * K + 1 written for 2 * K + 1, introducing a safety factor) ",
                         "is greater than the smallest matrix rank generated,", sep = "");
        msg = paste(msg, " rankMin = min(nTrainCv -1, mtopMin) = min(",
                         nTrainCv1, ", ", mtopMin, ")", sep = "");        
        return (msg);        
      }
    }
    # .......................................................................................    
    # . >>Case 2: scan K.
    # .......................................................................................
    if (inparam$parameterScan == 'K') {
      # ......................................................................................
      # . Degrees of freedom in the Cox model :
      # . Note that in the formula below I am overestimating the number of degrees of freedom of
      # . the model by writing df = 3 * K + 1, instead of the true value df = 2 * K + 1.
      # . I'm putting in the factor of 3 for safety, as convergence seems to break down
      # . even when the limit is not strictly reached.
      # ......................................................................................            
      KMax = max(inparam$aK);

      dfBuf = 3 * KMax + 1;                    # Safety factor intorduced; should really be 2 * KMax + 1.
      # ......................................................................................
      # . Now test :
      # ......................................................................................                  
      nTrainCv1 = nTrainCv - 1;                # Independent rows after mean-centering each column.
      rankMin = min(nTrainCv1, inparam$mtop);  # Data matrix rank after feature selection.

      if (rankMin <= dfBuf) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCvWithCov : ", sep = "");
        msg = paste(msg, "for parameterScan = mtop, the maximum number of degrees of freedom in the Cox model", sep = "");
        msg = paste(msg, " dfBuf = ", dfBuf, " (3 * K + 1 written for 2 * K + 1, introducing a safety factor) ",
                         "is greater than the matrix rank after feature selection,", sep = "");
        msg = paste(msg, " rankMin = min(nTrainCv -1, mtop) = min(",
                         nTrainCv1, ", ", inparam$mtop, ") = ", rankMin, sep = "");        
        return (msg);        
      }
    }
    # .......................................................................................            


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForCoxCvWithCov.
# =================================================================================================






# ========================================================================================================
# . SuperPc.checkDataMatricesForCoxCvWithCovBoot : checks compatibility of the numerical data frame and the
# . --------------------------------------------   experimental design data frame for cross-validation of
# .                                                Cox proportional hazard model embedded in bootstrap
# .                                                resampling.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForCoxCvWithCovBoot(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .
# ========================================================================================================

SuperPc.checkDataMatricesForCoxCvWithCovBoot <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # ..................................................................................................
    # . Failsafe check on existence of required members :
    # ..................................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCovBoot: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$mtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCovBoot: inparam does not have member mtop";
      stop(msg);
    }

    if (is.null(inparam$typePval)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCovBoot: inparam does not have member typePval";
      stop(msg);
    }        
    # ...................................................................................................


    
    # ...................................................
    stopifnot(inparam$methodSplit == 'vfoldStrict');
    # ...................................................

    

    # .......................................................................................
    # . Check existence of basic factors :
    # .......................................................................................
    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................
    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCovBoot: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCovBoot: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................




    # .......................................................................................
    # . Check on feature selection level :
    # .......................................................................................
    if (inparam$mtop > p) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCovBoot :\n", sep = "");  
      msg = paste(msg, "mtop = ", mtop, " is > p = ", p, " = number of genes.\n", sep = "");
      return (msg);
    }      
    # .......................................................................................    


    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;    # All samples are in the training set.
      nNone = 0;     # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCovBoot: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxCvWithCovBoot: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                   " records with values for factor ", inparam$tTrain , " = train. " ,
                   " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................



    
    # .......................................................................................
    # . Check train/test split. Compute ntrainCV, ntestCV.
    # .
    # . >> methodSplit = vfoldStrict :
    # ...................................................................................
    if (inparam$methodSplit == 'vfoldStrict') {
      csTemp = Stat.generateSplitsForVfold(nTrain, inparam$ft, flagRandom = FALSE);
      nTestCv = csTemp$ntest;

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    } else {
      nTrainCv = nTrain;                # Not really exact; I'm too lazy to change.
    }
    # .....................................................................................



    
    # .......................................................................................
    # . Check on the external covariate :
    # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
    # . Note that this applies only to the cross-validation program, and not to the
    # . feature selection or model building cases.
    # .......................................................................................    
    msgBin = Cox.checkBinary(dfE[[inparam$tCov]]);

    if (msgBin != 'ok') {
      msg = paste("ERROR: from SuperPc.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, msgBin);

      return(msg);
    }
    # .......................................................................................

    

    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");

    cat("             Given cross-validation split of training set :\n", sep = "");      
    cat("             Training set : nTrainCv = ", nTrainCv, "\n", sep = "");
    cat("             Test set : nTestCv = ", nTestCv, "\n", sep = "");
    # .......................................................................................


    
    # .......................................................................................
    # . Check on constraints imposed by matrix rank.
    # .......................................................................................
    nTrainCv1 = nTrainCv - 1;                     # Independent rows after mean-centering each column.
    rankMin = min(nTrainCv1, inparam$mtop);       # Minimum data matrix rank generated.
    dfBuf = 2 * inparam$K + 1;                    # Degrees of freedom in the Cox model.

    if (dfBuf > rankMin) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxCvWithCov : ", sep = "");
      msg = paste(msg, "the number of degrees of freedom in the Cox model", sep = "");
      msg = paste(msg, " dfBuf = ", dfBuf, " ( = 2 * K + 1) ",
        "is greater than the smallest matrix rank generated,", sep = "");
      msg = paste(msg, " rankMin = min(nTrainCv -1, mtop) = min(",
        nTrainCv1, ", ", inparam$mtop, ")", sep = "");        
      return (msg);        
    }
    # .......................................................................................    

    
    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForCoxCvWithCovBoot.
# =================================================================================================





# =================================================================================================
# . SuperPc.computeLmOnTraining : computes a de novo linear regression model for the given outcome
# . ---------------------------   variable, based on the predictor variables in the input
# .                             data matrix, using supervised principal components.
# .
# .   Syntax:
# .
# .            spc = SuperPc.computeLmOnTraining(ay, dfX, theta, mtop);
# .
# .   In:
# .            ay = outcome vector, of length n, where n is the number
# .                 of samples.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes.
# .                 Thus successive rows correspond to successive
# .                 samples, and each column corresponds to a different
# .                 gene.
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'theta' : use the threshold parameter theta for selecting
# .                    genes.
# .                  - 'mtop' :use the cutoff parameter mtop for selecting genes.
# .
# .         theta = threshold in absolute value of the correlation coefficients
# .                 for retaining genes in the SVD calculation.
# .
# .          mtop = alternative feature-selection parameter : select the top mtop
# .                 genes, ranked in decreasing order of absolute value of the
# .                 correlation coefficient.
# .
# .   Out:
# .        spc = list, with members:
# .
# . flagPassedFilter = TRUE if some genes passed the filter, FALSE otherwise
# .                    (no computation results in the latter case).
# .                n = number of samples in training set.
# .                p = number of features (= genes) in training set.
# .              axm = length p : array of mean values, for each gene separately.
# .              ym = scalar : mean value of outcome vector.
# .          Ctheta = array of the indices of genes which passed the filter.
# .               m = number of genes retained after feature selection.
# .         rabsMin = smallest abs(corr.) kept after feature selection.
# .           gamma = regression coefficient on first principal component.
# .          sigma2 = MLE for the model variance.
# .              aL = length p : array of gene loadings for first principal component.
# .              sv = SVD results :
# .                   sv$d = array of m singular values.
# .                   sv$u = array of left eigenvectors (prop. to principal compnents).
# .                   sv$v = array of right eigenvectors.
# .
# =================================================================================================

SuperPc.computeLmOnTraining <- function(ay, dfX, methodFs, theta, mtop)
{

      # ........................................................................
      stopifnot((methodFs == 'theta') || (methodFs == 'mtop'));
      stopifnot((theta >= 0.0) && (theta <= 1.0));
      stopifnot(mtop >= 1);
      # ........................................................................

      
      
      # ........................................................................
      # . Determine nmber of samples, catch inconsistencies :
      # ........................................................................
      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.
      
      ny = length(ay);   # Number of samples in outcome vector.

      if (ny != n) {
        msg = "ERROR: from SuperPc.computeLmOnTraining:\n";
        msg = paste("The outcome vector ay has n = ", ny, "samples\n", sep = "");
        msg = paste("This is not the same as the n = ",
                    n, "samples in the data matrix dfX.\n", sep = "");        
        stop(msg);
      }
      # .........................................................................



      # .......................................................................................
      # . Center the data and then generate the gene-by-gene correlation coefficients.
      # . These are given by :
      # .
      # .                     T       
      # .                    x  . y   
      # .                     j       
      # .          s  =   --------------   ,  j = 1, 2, . . ., p,  p = number of genes.
      # .           j     || x  || ||y||
      # .                     j
      # .
      # . where both x_j and y are centered.
      # .......................................................................................      
      axm = colMeans(dfX);                              # There are p column means.
      ym = mean(ay);                                    # The single mean for the outcome data.

      dfXc = scale(dfX, center = TRUE, scale = FALSE);  # Center each column (= one gene) separately.
      ayc = ay - ym;                                    # Center the outcome vector.
      aynorm = sd(ayc);                                 # Scalar : sd of centered outcomes.

      axnorm = apply(dfXc, 2, sd);                      # These are the p norms ||x_j||.
      # ........................................................................
      # . Take the scalar product of each column with the centered outcome
      # . vector, then divide by ||x|| for the corresponding gene.
      # ........................................................................      
      botBuf = (length(ayc)* aynorm) * axnorm;
      ar = (ayc %*% dfXc) / botBuf;                    # Gene-by-gene corr. coefficients.
      # .......................................................................................

      

      # .......................................................................................
      # . Feature selection step:
      # .
      # . >> Method = theta : subset to genes with correlation with outcome above the
      # .    given threshold. Return with m = 0 if the filter is too stringent and 0 genes
      # .    are passed.
      # .......................................................................................
      if (methodFs == 'theta') {
        rBuf = abs(ar);
        Ctheta = which(rBuf > theta);            # List of indices to be retained.
        m = length(Ctheta);                      # Number of features to be used in SVD.

        if (m == 0) {
          spc = list(flagPassedFilter = FALSE, m = 0);
          return (spc);
        }
        
        rabsMin = min(rBuf[Ctheta]);             # Smallest abs(corr.) kept.
      }
      # .......................................................................................
      # . >> Method = mtop : select the top mtop genes, ranked in decreasing order of
      # .    absolute value of the correlation coefficient.
      # .......................................................................................
      if (methodFs == 'mtop') {
        sBuf = sort(abs(ar), decreasing = TRUE, index.return = TRUE);
        Ctheta = sBuf[["ix"]][1:mtop];            # Select the top mtop indices.
        m = mtop;
        rabsMin = sBuf[["x"]][mtop];              # Smallest abs(corr.) kept.
      }
      # .......................................................................................

      
      
      # .......................................................................................
      # .                                 T
      # . Perform the SVD :  X = U . D . V   on the subsetted data matrix.
      # .......................................................................................      
      dfXtheta = dfXc[ , Ctheta];            # Subsetted to the highly correlated genes.
      sv = svd(dfXtheta);                    # SVD on the subsetted data matrix.
      # .......................................................................................
      # . Regress the response y on the first principal component :
      # .......................................................................................      
      u1 = sv$u[ , 1];                       # First principal component (PC).
      gamma = sum(ayc * u1) / sum(u1 * u1);  # Regression on the first PC.
      ae = (ayc - gamma * u1)^2;             # Squared residuals.
      sigma2 = mean(ae);                     # MLE for the model variance.
      # .......................................................................................
      # . Compute the loadings on the genes :      
      # .......................................................................................      
      aLtheta = sv$v[ , 1] / sv$d[1];        # Loadings on the genes for the first PC.
      aL = rep(0, times = p);
      aL[Ctheta] = aLtheta;
      # .......................................................................................

      
    

      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      spc = list(flagPassedFilter = TRUE,
                 theta = theta,
                 n   = n,
                 p   = p,
                 axm = axm,
                 ym = ym,
                 Ctheta = Ctheta,
                 m = m,
                 rabsMin = rabsMin,
                 gamma = gamma,
                 sigma2 = sigma2,        
                 aL = aL,
                 sv = sv );

      class(spc) = 'spc';
      # .......................................................................................


      # .............
      return (spc);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.computeLmOnTraining.
# =================================================================================================



# =================================================================================================
# . SuperPc.computeLmOnTest : estimates the outcome vector, based on the input supervised principal
# . -----------------------   components model and the input predictor variables.
# .                   
# .   Syntax:
# .
# .            ay = SuperPc.computeLmOnTest(spc, ayTest, dfX);
# .
# .   In:
# .           spc = supervised principal components model, constructed by invoking
# .                 SuperPc.computeLmOnTraining on an appropriate training set.
# .
# .        ayTest = test outcome profile. If present, a relative mean-squared error
# .                 of the predicted outcome profile relative to the test profile is
# .                 computed. If absent, the error terms are set to dummy values,
# .                 flagErrorComputed is set to FALSE.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes.
# .                 Thus successive rows correspond to successive
# .                 samples, and each column corresponds to a different
# .                 gene.
# .
# .   Out:
# .               ayPred = predicted outcome vector, with length(ay) = nrow(dfX).
# .               errAbs = absolute mean square error.
# .               errRel = relative mean square error.
# .               Q = log-likelihood statistic for model on test data.
# .    flagErrorComputed = TRUE, if the error and log-likelihood statistics were
# .                        computed (that is, if ayTest was provided). Else FALSE.
# .
# .................................................................................................
# . The log likelihood ratio statistic for this model :
# .
# .                        P(y|theta_0)
# .         Q = - 2 . log(-------------- )
# .                        P(y|theta_1)
# .
# . where P(y|theta_0) = likelihood under a simple Gaussian model with y_i = mu = constant,
# . and P(y|theta_1) = likelihood under regressed Gaussian model, y_i = mu + gamma * u1_i.
# . Thus :
# .                               1                       1        n      -          
# .                      --------------------- exp(- ------------ sum    (y - y_i )^2 )
# .                      (2 pi sigma0^2)^(n/2)        2 sigma0^2  i = 1              
# .         Q = - 2 log(----------------------------------------------------------------  )
# .                               1                       1        n      ^      
# .                      --------------------- exp(- ------------ sum    (y_i - y_i )^2 )
# .                      (2 pi sigma1^2)^(n/2)        2 sigma1^2  i = 1
# .
# .
# . with sigma0^2 = MLE of variance under model 0, simply :
# .
# .                        1      n      -          
# .            sigma0^2 = ----   sum    (y - y_i )^2
# .                        n    i = 1
# .
# . so that the exponent in the numerator for the equation for Q is just -n/2.
# .     ^
# . and y_i the predicted values of y and sigma1^2 the correspoding variance under model 1.
# .
# =================================================================================================

SuperPc.computeLmOnTest <- function(spc, ayTest, dfX)
{

      # ........................................................................
      # . Catch errors :
      # ........................................................................
      if (class(spc) != "spc") {
        msg = "ERROR: from SuperPc.computeLmOnTest:\n";
        msg = paste("The input variable spc is not of class spc.\n");
        stop(msg);
      }
      
      if (!spc$flagPassedFilter) {
        msg = "ERROR: from SuperPc.computeLmOnTest:\n";
        msg = paste("The input spc has flagPassedFilter = FALSE.\n");
        msg = paste("The model is not useable because no genes passed the filter.\n");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.

      if (spc$p != p) {
        msg = "ERROR: from SuperPc.computeLmOnTest:\n";
        msg = paste("The test data matrix does not have the same number of\n");
        msg = paste("features (= genes) as were present in the training data matrix.\n");
        msg = paste("Test has p = " , p, " genes.\n");
        msg = paste("Training had p = " , spc$p, " genes.\n");        
        stop(msg);
      }

      if (!missing(ayTest)) {
        ny = length(ayTest);   # Number of samples in outcome vector.

        if (ny != n) {
          msg = "ERROR: from SuperPc.displayModel:\n";
          msg = paste("The outcome vector ayTest has n = ", ny, "samples\n", sep = "");
          msg = paste("This is not the same as the n = ",
                       n, "samples in the input data matrix dfX.\n", sep = "");        
          stop(msg);
        }
      }
      # .........................................................................



      # .......................................................................................
      # . Center the data using the means computed on the training set,
      # . subset to the genes selected from computation on the training set
      # . compute the first principal component, and finally determine the
      # . model predictions.
      # .......................................................................................      
      axm = spc$axm;                                    # There are p column means.

      dfXc = sweep(dfXIn, 2, spc$axm);                  # Center each column separately.            
      dfXtheta = dfXc[ , spc$Ctheta];                   # Subset to the selected genes.

      sv = spc$sv;                                      # The SVD results from the training.
      v1 = sv$v[ , 1];                                      # PC1 vector.
      d1 = sv$d[1];                                         # PC1 singular value.
      u1 = (as.matrix(dfXtheta) %*% sv$v[ , 1]) / sv$d[1];  # u1 = projection of v1.

      ayPred = spc$ym + spc$gamma * u1;                 # Model prediction.
      # .......................................................................................



      
      # ...............................................................................
      # . How does the prediction fit the test data?
      # ...............................................................................
      errAbs = 1.0;                   # Absolute mean square error.
      errRel = 1.0;                   # Relative mean square error.
      Q = 0.0;                        # Log likelihood ratio.
      flagErrorComputed = FALSE;
      
      if (!missing(ayTest)) {
        # ........................................................................
        # . Absolute error :
        # ........................................................................        
        top = (ayPred - ayTest)^2;    # Squared residuals relative to prediction.
        errAbs = mean(top);           # Absolute mean squared error.
        # ........................................................................
        # . Relative error :
        # ........................................................................        
        ymTest = mean(ayTest);
        bot = (ymTest - ayTest)^2;    # Squared residuals relative to test mean.        
        meanBot = mean(bot);

        if (meanBot > 0.0) {
          errRel = errAbs / meanBot;  # Like a likelihood ratio.
        } else {
          errRel = 1.0;
        }
        # ........................................................................
        # . Log likelihood ratio :
        # . Q = - 2 log(P(x|theta_0) / P(x|theta_1))
        # . See above for details.
        # ........................................................................
        sigma2Test = var(ayTest);

        Q = n * log(sigma2Test / spc$sigma2) + n - sum(top) / spc$sigma2;
        # ........................................................................
        flagErrorComputed = TRUE;
      }
      # ...............................................................................
      


      # .......................................................
      # . Package the results :
      # .......................................................
      spt = list(n      = n,
                 ayTest = ayTest,
                 ayPred = ayPred,
                 errAbs = errAbs,
                 errRel = errRel,
                 Q = Q,
                 flagErrorComputed = flagErrorComputed);

      class(spt) = "spt";
      # .......................................................

      
      # .............
      return (spt);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.computeLmOnTest.
# =================================================================================================





# =================================================================================================
# . SuperPc.computeRegressUni : generates univariate, gene-by-gene regression model statistics 
# . -------------------------   for the given input data matrix. For each gene computes a significance score
# .                             and P-value. Internally also does feature selection on the selected score.
# .
# .   Syntax:
# .
# .       fs = SuperPc.computeRegressUni(ay, dfX, modelType, methodFs, p0, mtop, flagVerbose);
# .
# .   In:
# .            ay = n : vector of output values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     modelType = type of regression model to be used :
# .                 Allowed values : 
# .                  - 'lm'       : linear model.
# .                  - 'logistic' : logistic distribution. 
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values from Cox proportional hazards model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .   flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        fs = list, with members:
# .        msg                      # Output message. = 'ok' for normal execution,
# .                                 # else reports error or inconsistencies (e.g.
# .                                 # 0 features passed by filter).
# .        modelType                # Regression model used.
# .        methodFs                 # Feature selection method.                        
# .        mtop                     # Number of genes for feature selection.           
# .        p0                       # P-value threshold for feature selection.         
# .        n                        # Number of samples.                               
# .        p                        # Number of genes.
# .        ac                       # p : column names (gene names).
# .        axm                      # p : column means (gene-by-gene means).
# .        ascore                   # p : scores for all the genes.
# .        ap                       # p : P-values  for all the genes.
# .        abeta                    # p : optimal beta (for logLikelihood) or beta = 0 (for u0) for all the genes.
# .        ascoreU0                 # p : U0 scores for all the genes.
# .        apU0                     # p : P-values based on U0 scores, for all the genes.
# .        m                        # Number of selected genes.                        
# .        indexSel                 # m : index of selected genes.
# .        pvalMin                  # Smallest univariate p-value selected.            
# .        pvalMax                  # Largest univariate p-value selected.
# .
# =================================================================================================

SuperPc.computeRegressUni <- function(ay, dfX, modelType, methodFs, p0, mtop, flagVerbose)
{

      # ........................................................................
      stopifnot((modelType == 'lm') || (modelType == 'logistic'));      
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);
      # ........................................................................


      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPc.computeRegressUni.\n");
      }
      # ........................................................................      

      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................
      n = nrow(dfX);       # Number of samples.
      p = ncol(dfX);       # Number of genes.
      ac = colnames(dfX);  # Array of gene names.
      
      ny = length(ay);   # Number of samples in output variable vector.

      if (ny != n) {
        msg = "ERROR: from SuperPc.computeRegressUni: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (mtop > p) {
        msg = "ERROR: from SuperPc.computeRegressUni: ";
        msg = paste("mtop = ", mtop, " is greater than number of genes p = ", p, sep = "");
        stop(msg);
      }
      # ......................................................................................



      # .......................................................................................
      # . Center both the outcome vector and the covariate data matrix, then generate
      # . univariate scores for each gene separately.
      # .......................................................................................
      axm = colMeans(dfX, na.rm = TRUE);                       # Save the p column means.
      ym = mean(ay, na.rm = TRUE);                             # The single mean for the outcome data.
      
      dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.
      ayc = ay - ym;                                           # Center the outcome vector.
      
      cat(" ..........  Generate scores using modelType = ", modelType, "\n", sep = "");

      if (modelType == 'lm') {      
        regS = Regress.computeLmUni(ayc, dfXc, flagVerbose = TRUE);          # Univariate linear model.
      } else if (modelType == 'logistic') {      
        regS = Regress.computeLogisticUni(ay, dfXc, flagVerbose = TRUE);     # Univariate logistic model.        
      } else {
        cat("ERROR: from SuperPc.computeRegressUni: modelType = ", modelType, " is not valid.\n");    # Failsafe.
        cat("Please check program logic.\n");
        stop();
      }
      # .......................................................................................

      
      
      # .......................................................................................
      # . Perform feature selection with the indicated method and parameters.
      # .......................................................................................
      selF = SuperPc.selectFeaturesRegress(dfXc, methodFs, p0, mtop, regS);
      # .......................................................................................



      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      msg = 'ok';
      
      fs = list(msg = msg,                   # Output message.
                modelType = modelType,       # Regression model used.
                methodFs = methodFs,         # Feature selection method.                        
                mtop = mtop,                 # Number of genes for feature selection.           
                p0 = p0,                     # P-value threshold for feature selection.         
                n   = n,                     # Number of samples.                               
                p   = p,                     # Number of genes.
                ac = ac,                     # p : column names (gene names).        
                axm = axm,                   # p : column means (gene-by-gene means).
                ascore = regS$ascore,        # p : scores for all the genes.
                ap = regS$ap,                # p : P-values for all the genes.
                aalpha = regS$aalpha,        # p : intercepts for all the genes.                
                abeta = regS$abeta,          # p : optimal beta for all the genes.        
                m = selF$m,                  # Number of selected genes.                        
                indexSel = selF$indexSel,    # m : index of selected genes.
                pvalMin = selF$pvalMin,      # Smallest univariate p-value selected.            
                pvalMax = selF$pvalMax );    # Largest univariate p-value selected.
      
      class(fs) = 'spc.regress.fs';              # Actually, a superset of class 'fs'.
      # .......................................................................................

      
      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Exit SuperPc.computeRegressUni.\n");
      }
      # ........................................................................            

      
      # .............
      return (fs);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.computeRegressUni.
# =================================================================================================







# =================================================================================================
# . SuperPc.selectFeaturesRegress : does feature selection, based on a precomputed set of univariate
# . -----------------------------   regression model scores.
# .                             
# .
# .   Syntax:
# .
# .          selF = SuperPc.selectFeaturesRegress(dfXc, methodFs, p0, mtop, regS);
# .
# .   In:
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .           dfXc =data frame for the predictor variables, after column mean-centering.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values as computed from regression model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Reg scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .          regS = object returned by a call to Regress.computeLmUni(),
# .                 contains the univariate regression model scores.
# .
# .   Out:
# .        selF = list, with members:
# .
# .               indexSel            # Index of selected genes.                         
# .               m                   # Number of selected genes.                        
# .               pvalMin             # Smallest univariate p-value selected.            
# .               pvalMax             # Largest univariate p-value selected.             
# .               dfXSel              # Data frame subsetted to the selected features.
# . 
# =================================================================================================

SuperPc.selectFeaturesRegress <- function(dfXc, methodFs, p0, mtop, regS)
{

      # ........................................................................
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);
      # ........................................................................


      # ........................................................................
      p = ncol(dfXc);           # Number of genes in input data matrix.
      pS = length(regS$ap);     # Number of genes from regS object.

      if (pS != p) {
        msg = "ERROR: from SuperPc.selectFeaturesRegress: ";
        msg = paste("regS input has pS = ", pS, " genes. ", sep = "");
        msg = paste("Not the same as p = ", p, " in input data matrix dfXc.", sep = "");        
        stop(msg);
      }      
      # ........................................................................      


      # .......................................................................................
      # . Feature selection step:
      # .
      # . >> Method = p0 : subset to genes with P-value for Cox model <= p0.
      # .    The p-values are evaluated from the score test.
      # .
      # .    Return with m = 0 if the filter is too stringent and 0 genes are passed.
      # .......................................................................................
      if (methodFs == 'p0') {
        indexSel = which(regS$ap <= p0);    # Indices of genes selected with p <= p0.
        m = length(indexSel);               # Number of genes selected.

        if (m == 0) {
          spc = list(msg = "ERROR: nothing passed the preliminary feature selection",
                     m = 0);
          return (spc);                     # Return as there is nothing to compute.
        }

        pvalMin = min(regS$ap[indexSel]);   # Smallest p-value actually selected.        
        pvalMax = min(regS$ap[indexSel]);   # Largest p-value actually selected.
      }
      # .......................................................................................
      # . >> Method = mtop : select the mtop genes with the most significant scores.
      # .......................................................................................
      if (methodFs == 'mtop') {
        sBuf = sort(regS$ap, decreasing = FALSE, index.return = TRUE);
        indexSel = sBuf[["ix"]][1:mtop];           # Indices of genes selected.
        m = mtop;
        pvalMin = sBuf[["x"]][1];                  # Smallest p-value actually selected.        
        pvalMax = sBuf[["x"]][mtop];               # Largest p-value actually selected.
      }
      # .......................................................................................
      # . Now subset the data matrix to the selected genes :
      # .......................................................................................
      dfXSel = dfXc[ , indexSel];                           # Subsetted to the selected genes.
      acBuf = colnames(dfXc);
      
      if (length(indexSel) == 1) {
        dfXSel = as.matrix(dfXSel, nrow = nrow(dfXc))       # Special case for 1 gene selected.
        colnames(dfXSel) = acBuf[indexSel];
      }      
      # .......................................................................................


      # .......................................................................................
      # . Package results :
      # .......................................................................................
      selF = list(
        indexSel = indexSel,
        m = m,
        pvalMin = pvalMin,
        pvalMax = pvalMax,
        dfXSel = dfXSel   );
      # .......................................................................................

      
      # .............
      return (selF);
      # .............
      
}

# =================================================================================================
# . End of SuperPc.selectFeaturesRegress.
# =================================================================================================




# =================================================================================================
# . SuperPc.computeRegress : generates a regression model for the output variable on the
# . ----------------------   gene expression data, using supervised principal components.
# .                             
# .
# .   Syntax:
# .
# .       spc = SuperPc.computeRegress(ay, dfX, modelType, methodFs, p0, mtop, K, flagVerbose);
# .
# .   In:
# .            ay = n : vector of output values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     modelType = type of regression model to be used :
# .                 Allowed values : 
# .                  - 'lm' : linear model.
# .                  - 'logistic' : logistic distribution. 
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values from Cox proportional hazards model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .   flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        spc = list, with members:
# .        msg                      # Output message. = 'ok' for normal execution,
# .                                 # else reports error or inconsistencies (e.g.
# .                                 # 0 features passed by filter).
# .        modelType                # Regression model used.
# .        methodFs                 # Feature selection method.                        
# .        mtop                     # Number of genes for feature selection.           
# .        p0                       # P-value threshold for feature selection.         
# .        n                        # Number of samples.                               
# .        p                        # Number of genes.
# .        ac                       # p : column names (gene names).
# .        ym                       # Value of mean for output variable.
# .        axm                      # p : column means (gene-by-gene means).           
# .        indexSel                 # m : index of selected genes.                         
# .        m                        # Number of selected genes.                        
# .        pvalMin                  # Smallest univariate p-value selected.            
# .        pvalMax                  # Largest univariate p-value selected.             
# .        K                        # Number of pc's used in final Cox model.          
# .        abeta                    # K : regression coefficients.
# .        aseBeta                  # K : standard errors for the regression coefficients.                       
# .        ap                       # K : P-values for the regression coefficents.            
# .        qR                       # Loglikelihood or F statistic statistic.          
# .        pR                       # P-value for loglikelihood or F statistic statistic.       
# .        av                       # p * K : pc vectors full p-gene expression space. 
# .        avtot                    # Summed gene loadings in p-gene expression space. 
# .        sv                       # Pass the results of the internal SVD.
# .        bh                       # Baseline hazard object. See function: 
# .                                 # >> SuperPc.computeBaselineHazardNoTies() for member details.
# ................................................................................................
# .               sv = SVD results :
# .                    sv$d = array of m singular values.
# .                    sv$u = array of left eigenvectors (prop. to principal compnents).
# .                    sv$v = array of right eigenvectors.
# .
# =================================================================================================

SuperPc.computeRegress <- function(ay, dfX, modelType, methodFs, p0, mtop, K, flagVerbose)
{

      # ........................................................................
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((modelType == 'lm') || (modelType == 'logistic')); 
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);
      stopifnot(K >= 1);
      # ........................................................................


      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPc.computeRegress.\n");
      }
      # ........................................................................      

      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................
      n = nrow(dfX);       # Number of samples.
      p = ncol(dfX);       # Number of genes.
      ac = colnames(dfX);  # Array of gene names.
      
      ny = length(ay);   # Number of samples in survival time vector.

      if (ny != n) {
        msg = "ERROR: from SuperPc.computeRegress: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (mtop > p) {
        msg = "ERROR: from SuperPc.computeRegress: ";
        msg = paste("mtop = ", mtop, " is greater than number of genes p = ", p, sep = "");
        stop(msg);
      }

      n1 = n - 1;
      rtemp = min(n1, p);    # Rank of the data matrix.

      if (K > rtemp) {
        msg = "ERROR: from SuperPc.computeRegress: ";
        msg = paste("K = ", K, " is greater than the data matrix rank = ", rtemp, sep = "");
        stop(msg);
      }
      # ......................................................................................



      # .......................................................................................
      # . Column-center the data then generate univariate Cox scores for each gene separately.
      # .......................................................................................
      axm = colMeans(dfX);                                     # Save the p column means.
      ym = mean(ay);                                           # The single mean for the outcome data.
      
      dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.
      ayc = ay - ym;                                           # Center the outcome vector.
      
      cat(" ..........  Generating univariate scores using modelType = ", modelType, "\n", sep = "");

      if (modelType == 'lm') {      
        regS = Regress.computeLmUni(ayc, dfXc, flagVerbose = TRUE);          # Univariate linear model.
      } else if (modelType == 'logistic') {      
	#xxx  regS = Regress.computeLogisticUni(ay, dfXc, flagVerbose = TRUE);     # Univariate logistic model.        
        regS = Regress.computeLogisticUniMASKED(ay, dfXc, flagVerbose = TRUE);     # Univariate logistic model.   J. Theilhaber
      } else {
        cat("ERROR: from SuperPc.computeRegress: modelType = ", modelType, " is not valid.\n");    # Failsafe.
        cat("Please check program logic.\n");
        stop();
      }
      # .......................................................................................
      # . Perform the feature selection with the indicated method and parameters :
      # .......................................................................................
      selF = SuperPc.selectFeaturesRegress(dfXc, methodFs, p0, mtop, regS);      
      # .......................................................................................
      # . Catch the unlikely case where remaining features less than principal components :
      # .......................................................................................            
      if (selF$m < K) {
        msg = "ERROR: from SuperPc.computeRegress: ";        
        msg = paste(msg, "Remaining features m = ", selF$m, " less than principal components K = ",
                    K, sep = "");
        spc = list(msg = msg, m = selF$m);
        return (spc);
      }
      # .......................................................................................
      # . Do the svd and generate multivariate regression model :
      # . - for linear regression, use centered output variable.
      # . - for logistic regression, use raw binary {0, 1} output variable.
      # .......................................................................................
      if (modelType == 'lm') {      
        cSel = SuperPc.computeRegressOnSelectedFeatures(ayc, selF$dfXSel, modelType, K);
      } else if (modelType == 'logistic') {
        cSel = SuperPc.computeRegressOnSelectedFeatures(ay, selF$dfXSel, modelType, K);        
      }
      # .......................................................................................
      # . Compute the baseline hazard functions (here using an approximation that assumes
      # . no ties) :
      # .......................................................................................
      #xxxxx bh = SuperPc.computeBaselineHazardNoTies(at, as, cSel, selF$dfXSel);      
      # .......................................................................................
      # . Project back to orignal p-dimensional vector space:
      # .......................................................................................
      fullPc = SuperPc.projectToFull(p, cSel$avSel, cSel$avSelTot, selF$indexSel);
      # .......................................................................................

    
    

      # .......................................................................................
      # . Package the results (see also function SuperPc.packageSpcRegress()) :
      # .......................................................................................
      msg = 'ok';
      
      spc = list(msg = msg,                   # Output message.
                 ay = ay,                     # Actual vaues of output variable.
                 modelType = modelType,       # Regression model used.
                 methodFs = methodFs,         # Feature selection method.                        
                 mtop = mtop,                 # Number of genes for feature selection.           
                 p0 = p0,                     # P-value threshold for feature selection.         
                 n   = n,                     # Number of samples.                               
                 p   = p,                     # Number of genes.
                 ac = ac,                     # p : column names (gene names).
                 ym = ym,                     # Value of mean for output variable.
                 axm = axm,                   # p : column means (gene-by-gene means).
                 indexSel = selF$indexSel,    # Index of selected genes.                         
                 m = selF$m,                  # Number of selected genes.                        
                 pvalMin = selF$pvalMin,      # Smallest univariate p-value selected.            
                 pvalMax = selF$pvalMax,      # Largest univariate p-value selected.             
                 K = K,                       # Number of pc's used in final Cox model.          
                 abeta = cSel$abeta,          # K : the regression coefficients, excl. intercept.    
                 aseBeta = cSel$aseBeta,      # K : standard errors for the regression coefficients. 
                 ap = cSel$ap,                # K : the P-values for the regression coefficents.
                 beta0 = cSel$beta0,          # Intercept coefficient.
                 seBeta0 = cSel$seBeta0,      # Standard error for intercept.
                 pBeta0 = cSel$pBeta0,        # P-value for intercept non-zero.
                 qR = cSel$qR,                # Loglikelihood or F statistic for overall model.
                 df1 = cSel$df1,              # df1 degrees of freedom for F-statistic.
                 df2 = cSel$df2,              # df2 degrees of freedom for F-statistic.                
                 pR = cSel$pR,                # P-value for overall model against H0: abeta = 0.
                 avSel = cSel$avSel,          # m * K : pc vectors in m-gene expression space.         
                 av = fullPc$av,              # p * K : pc vectors full p-gene expression space.
                 avSelTot = cSel$avSelTot,    # Summed gene loadings in m-gene expression space.    
                 avTot = fullPc$avTot,        # Summed gene loadings in p-gene expression space. 
                 sv = cSel$sv,                # Pass the results of the internal SVD.
                 regK = cSel$regK);           # Final regression model on K principal components.
      
      class(spc) = 'spc.regress';
      # .......................................................................................

      
      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Exit SuperPc.computeRegress.\n");
      }
      # ........................................................................            

      
      # .............
      return (spc);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.computeRegress.
# =================================================================================================






# =================================================================================================
# . SuperPc.computeRegressOnSelectedFeatures : computes a regression model, given an input data
# . ----------------------------------------   post-feature selection, and the output variable
# .                                            values.
# .
# .   Syntax:
# .
# .       cSel = SuperPc.computeRegressOnSelectedFeatures(ay, dfXSel, modelType, K);
# .
# .   In:
# .            ay = n : vector of output values (n = number of samples).
# .
# .           dfXSel = n * m : data matrix of gene expression data, after mean-centering
# .                    and feature selection.
# .
# .
# .     modelType = type of regression model to be used :
# .                 Allowed values : 
# .                  - 'lm' : linear model.
# .                  - 'logistic' : logistic distribution. 
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .
# .   Out:
# .        cSel = list, with members:
# .
# .         modelType     # Type of regression model used.
# .         abeta         # K-dimensional array : the regression coefficients.
# .         aseBeta       # K-dimensional array : standard errors for the regression coefficients.
# .         ap            # K-dimensional : P-values for the regression coefficients.
# .         qR            # F statistic for overall model, against H0: abeta = 0.
# .         pR            # P-value for F statistic.
# .         avSel         # m * K-dimensional array: the pc vectors in m-gene expression space.         
# .         avSelTot      # m-dimensional array: Summed gene loadings in m-gene expression space.    
# .         sv            # Pass the results of the internal SVD.
# .         regK          # Final regression model on K principal components.
# . 
# =================================================================================================

SuperPc.computeRegressOnSelectedFeatures <- function(ay, dfXSel, modelType, K)
{

      # ...........................................................
      stopifnot(K >= 1);
      stopifnot((modelType == 'lm') || (modelType == 'logistic'));      
      # ...........................................................


      # ....................
      n = nrow(dfXSel);      
      m = ncol(dfXSel);
      # ....................


      # .......................................................................................
      # . Catch inconsistencies in specification of input arrays or parameters.
      # .......................................................................................      
      ny = length(ay);   # Number of samples in survival time vector.

      if (ny != n) {
        msg = "ERROR: from SuperPc.computeRegressOnSelectedFeatures: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (modelType == 'logistic') {
        msgBin = Cox.checkBinary(ay);

        if (msgBin != 'ok') {
          cat("ERROR: from SuperPc.computeRegressOnSelectedFeatures:\n", sep = "");
          cat("Output variable array ay is not binary.\n", sep = "");
          cat(msgBin);
          stop();
        }

        n1 = sum(ay);                    # Number of instances with y = 1.

        if ((n1 == n) || (n1 == 0)) {
          cat("ERROR: from SuperPc.computeRegressOnSelectedFeatures:\n", sep = "");          
          cat("All values of output variable Y are equal to 1 or all are equal to 0.\n", sep = "");
          cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
          stop();
        }
      }      
      # .......................................................................................

      
      
      # .......................................................................................
      # . Catch the case where the matrix rank is smaller than the number of 
      # . principal components specified for the analysis.
      # .......................................................................................
      if (K > m) {                                                                        # J. Theilhaber.
        msg = paste("ERROR: from SuperPc.computeRegressOnSelectedFeatures: ", sep = "");
        msg = paste(msg, "Number K = ", K, " of principal components ",
                    " greater than number of genes m = ", m, sep = "");
        stop(msg);
      }

      n1 = n - 1;

      if (K >= n1) {
        msg = paste("ERROR: from SuperPc.computeRegressOnSelectedFeatures: ", sep = "");
        msg = paste(msg, "Number K = ", K, " of principal components ",
                    " greater than or equal to the number of samples minus 1, n1 = ", n1, sep = "");
        stop(msg);
      }
      # .......................................................................................
      
      
      
      # .......................................................................................
      # .                                 T
      # . Perform the SVD :  X = U . D . V   on the subsetted data matrix.
      # .......................................................................................      
      sv = svd(dfXSel);                    # SVD on the subsetted data matrix.
      # .......................................................................................


    
      # .......................................................................................
      # . Compute a regression model on the first K principal components :
      # .
      # . Note that we are using the expansion :
      # .
      # .              --          --                                              
      # .              |  -- x  --> |    
      # .              |      1     |                               
      # .              |  -- x  --> |   .      K             T     
      # .        X =   |      2     |   =     Sum   d   u   v                               
      # .        -     |   . . .    |        l = 1   l  -l  -l
      # .              |  -- x  --> |
      # .              |      n     |
      # .              --          --
      # .
      # . to approximate the sample vectors by the first K principal components.
      # . Here the u_l are n-dimensional and the v_l m-dimensional vectors.
      # .
      # . The coefficient for the i-th sample vector x_i for the l-th PC is thus d_l * u_li.
      # .......................................................................................
      dBuf = matrix(sv$d[1:K], nrow = n, ncol = K, byrow = TRUE);  # Spread onto n rows.
      
      uK = dBuf * sv$u[ , 1:K];       # n * K matrix: projections onto the first K principal components.

      if (modelType == 'lm') {            
        regK = lm(ay ~ uK);                                # Linear model, 1 + K coefficients.
      } else if (modelType == 'logistic') {
        regK = glm(ay ~ uK, family = binomial("logit"));   # Logistic regression model, 1 + K coefficients.
      } else {
        cat("ERROR: from SuperPc.computeRegressOnSelectedFeatures:\n");
        cat("modelType = ", modelType, " is not valid.\n");              # Failsafe.
        cat("Please check program logic.\n");
        stop();
      }
      # .......................................................................................
      # . Extract coefficients, standard errors and P-values from the model :
      # . >> 1. Linear regression model :
      # .......................................................................................
      if (modelType == 'lm') {
        regKsum = summary(regK);

        qR = regKsum$fstatistic[['value']];    # F-statistic.
        df1 = regKsum$df[1];                   # K + 1.
        df2 = regKsum$df[2];                   # n - K - 1.
        pR = pf(qR, df1 = df1, df2 = df2, lower.tail = FALSE);     # p-value from likelihood ratio.
        
        regKcoef = regKsum$coefficients;
        K1 = K + 1;        
        
        abetaRaw = regKcoef[ , 1];           # The K + 1 coefficients (including intercept).
        beta0 = abetaRaw[1];                 # Intercept coefficient.
        abeta = abetaRaw[2:K1];              # Exclude the y intercept coefficient.
        
        aseBetaRaw = regKcoef[ , 2];         # Standard errors for the K + 1 coefficients.
        seBeta0 = aseBetaRaw[1];             # Standard error for intercept.
        aseBeta = aseBetaRaw[2:K1];          # Exclude the y intercept error.
        
        apRaw = regKcoef[ , 4];              # The corresponding K + 1 P-values against beta = 0.
        pBeta0 = apRaw[1];                   # P-value for intercept.
        ap = apRaw[2:K1];                    # Exclude the y intercept P-value.
      }
      # .......................................................................................
      # . >> 2. Logistic regression model :
      # .......................................................................................
      if (modelType == 'logistic') {
        regKsum = summary(regK);
        # ................................................................................
        # . Compute likelihood ratio test statistic against null model with
        # . interecept term beta0 nonzero and beta = 0.
        # ................................................................................        
        lFull = - 0.5 * regKsum$deviance;              # Log-likelihood under full model.
        n1 = sum(ay);                                  # Number of instances with y = 1.
        n0 = n - n1;                                   # Number of instances with y = 0.
        beta0Star = log(n1 / (n - n1));                # Optimal beta0, when beta = 0.        
        lNull = n0 * log(n0) + n1 * log(n1) - n * log(n);     # Log-likelihood with (beta0, beta = 0).
        #xxx temp1 = Logistic.loglik(rep(0.0, times = n), ay, abeta = c(beta0Star, 0.0));  # Same.
        
        qR = 2.0 * (lFull - lNull);                    # Likelihood ratio statistic. 
        pR = pchisq(qR, df = K, lower.tail = FALSE);   # p-value from likelihood ratio.

        df1 = regKsum$df[1];                           # Not really useful for logistic model,
        df2 = regKsum$df[2];                           # but I'm keeping for consistency.
        # ................................................................................
        # . Retrieve individual coefficients : 
        # ................................................................................        
        regKcoef = regKsum$coefficients;
        K1 = K + 1;        
        
        abetaRaw = regKcoef[ , 1];           # The K + 1 coefficients (including intercept).
        beta0 = abetaRaw[1];                 # Intercept coefficient.        
        abeta = abetaRaw[2:K1];              # Exclude the y intercept coefficient.
        
        aseBetaRaw = regKcoef[ , 2];         # Standard errors for the K + 1 coefficients.
        seBeta0 = aseBetaRaw[1];             # Standard error for intercept.        
        aseBeta = aseBetaRaw[2:K1];          # Exclude the y intercept error.
        
        apRaw = regKcoef[ , 4];              # The corresponding K + 1 P-values against beta = 0.
        pBeta0 = apRaw[1];                   # P-value for intercept.        
        ap = apRaw[2:K1];                    # Exclude the y intercept P-value.
        # ................................................................................                
      }      
      # .......................................................................................
      # . Compute the loadings on the genes. These are just the components of the
      # . corresponding principal component vectors.
      # .......................................................................................      
      avSel = sv$v[ , 1:K];                # m * K : the first K pc's in the subspace of m selected genes.

      if (K == 1) {
        avSel = as.matrix(avSel);          # Must cast as matrix when K == 1.
      }

      rownames(avSel) = colnames(dfXSel);  # These are the selected gene names.
      colnames(avSel) = paste("pc", 1:K);  # Columns names are those of the pcs.

      avSelTot = avSel %*% abeta;          # Summed gene loadings in the subspace of m selected genes.
      # .......................................................................................



      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      cSel = list(modelType = modelType,   # Model type.
                  abeta = abeta,           # K : the regression coefficients.
                  aseBeta = aseBeta,       # K : standard errors for the regression coefficients.
                  ap = ap,                 # K : P-values for the regression coefficients.
                  beta0 = beta0,           # Intercept coefficient.
                  seBeta0 = seBeta0,       # Standard error for intercept.
                  pBeta0 = pBeta0,         # P-value for intercept non-zero.
                  qR = qR,                 # F or LR statistic for overall model, against H0: abeta = 0.
                  df1 = df1,               # df1 degrees of freedom for F-statistic.
                  df2 = df2,               # df2 degrees of freedom for F-statistic.        
                  pR = pR,                 # P-value for F statistic.
                  avSel = avSel,           # m * K : pc vectors in m-gene expression space.         
                  avSelTot = avSelTot,     # Summed gene loadings in m-gene expression space.    
                  sv = sv,                 # Pass the results of the internal SVD.
                  regK = regK);            # Final regression model on K principal components.

      class(cSel) = 'spc.regress.selected.features';
      # .......................................................................................

      
      # .............
      return (cSel);
      # .............
      

}

# =================================================================================================
# . End of SuperPc.computeRegressOnSelectedFeatures.
# =================================================================================================

      




# =================================================================================================
# . SuperPc.computeRegressPcAndOutputVariable : computes the principal components and predicted
# . -----------------------------------------   output variable for an input data matrix with an arbitrary 
# .                                             set of samples (not necessarily the ones used in
# .                                             the training set).
# .
# .   Syntax:
# .
# .          s = SuperPc.computeRegressPcAndOutputVariable(spc, dfXIn);
# .
# .   In:
# .        spc = result of supervised principal components computation, returned
# .              by function SuperPc.computeRegress().
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .   Out:
# .      s = list with members :
# .
# .              Y = nIn * K matrix of principal components, where nIn = number of rows in dfXIn.
# .            axi = nIn-length vector of prognostic indices:  xi = beta0 + beta * x
# .         ayPred = nIn-length vector of predicted output variable values.
# .        aPyPred = nIn-length vector of estimated P(y = 1|x) values
# .                  (non-zero for logistic regression; set to dummy all-zero
# .                  values for linear regression).
# .
# =================================================================================================

SuperPc.computeRegressPcAndOutputVariable <- function(spc, dfXIn)
{

      # ...............................................................................
      if (class(spc) != "spc.regress") {
        msg = "ERROR: from SuperPc.computeRegressPcAndOutputVariable: ";
        msg = paste("The input spc is not of class spc.regress.");
        stop(msg);
      }

      stopifnot((spc$modelType == 'lm') || (spc$modelType == 'logistic'));  # Failsafe.
      # ................................................................................


      # ..............................................................................
      p = ncol(dfXIn);
      
      if (spc$p != p) {
        msg = "ERROR: from SuperPc.computeRegressPcAndOutputVariable: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("features as in the training data matrix.", sep = "");
        msg = paste(" Test has p = " , p, " genes.", sep = "");
        msg = paste(" Training has spc$p = " , spc$p, " genes.", sep = "");        
        stop(msg);
      }
      # ...............................................................................


      
      # ...................................................................................
      # . Compute the principal components and the log-hazard ratios :
      # . center the data using the means computed on the training set,
      # . subset to the genes selected from computation on the training set
      # . compute the principal components, and finally determine the
      # . log-hazard ratios.
      # ...................................................................................
      # . 3-13-2011; J. Theilhaber: special option for nrow = 1.      
      # ...................................................................................
      dfXc = sweep(dfXIn, 2, spc$axm);                # Center each column separately.      
      dfXSel = dfXc[ , spc$indexSel];                 # nIn * m data matrix subsetted to the selected genes.

      if (nrow(dfXc) == 1) {
        dfXSel = matrix(dfXSel, nrow = 1);            # Special case for nrow = 1, to preserve matrix geometry.
      }

      if (length(spc$indexSel) == 1) {
        dfXSel = matrix(dfXSel, ncol = 1);            # Special case for ncol = 1, to preserve matrix geometry. J. Theilhaber.
        rownames(dfXSel) = rownames(dfXc);            # Must explicitly transfer row names as well. J. Theilhaber.
      }
      # ...................................................................................
      # . Linear regression model :
      # ...................................................................................
      flagDone = FALSE;                                   # Failsafe.
      
      if (spc$modelType == 'lm') {
        Y = dfXSel %*% spc$avSel;                         # nIn * K matrix of pc's.
        colnames(Y) = paste("ypc", 1:spc$K, sep = "");    # Label the pc's.

        aPyPred = rep(0.0, times = nrow(dfXIn));          # Dummy probability vector (not used here).        
        ayPred = spc$ym + Y %*% spc$abeta;                # nIn-length vector of predicted y values.
        axi = ayPred;                                     # Prognostic index and predicted values are identical.

        flagDone = TRUE;
      }
      # ...................................................................................
      # . Logistic regression model :
      # ...................................................................................
      if (spc$modelType == 'logistic') {
        Y = dfXSel %*% spc$avSel;                                    # nIn * K matrix of pc's.
        colnames(Y) = paste("ypc", 1:spc$K, sep = "");               # Label the pc's.

        axi = spc$beta0 + Y %*% spc$abeta;                           # nIn-length vector of logit(P(y = 1|x)) values.
        aPyPred = ifelse(axi > -50, 1.0 / (1.0 + exp(-axi)), 0.0);   # Estimates of P(y = 1|x).
        ayPred = ifelse(aPyPred >= 0.5, 1, 0);                       # MAP estimates for y values.

        flagDone = TRUE;        
      }

      stopifnot(flagDone);                                            # Failsafe.
      # ...................................................................................
      

     
      # ...............................................................................
      # . Package the results :
      # ...............................................................................
      s = list(Y = Y,                    # n * K array of projections against PC axes.
               axi = axi,                # Prognostic index:  xi = beta0 + beta * x
               ayPred = ayPred,          # Predictions (= xi for lm, = {0,1} for logistic).
               aPyPred = aPyPred);       # Estimator for P(y=1|x) (used only for logistic).
      
      class(s) = 'spc.regress.estimate';
      # ..............................................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of SuperPc.computeRegressPcAndOutputVariable.
# =================================================================================================      






# =================================================================================================
# . SuperPc.regressGetErrors : extracts error terms from the result of a regression model
# . ------------------------   calculation.
# .
# .   Syntax:
# .
# .          eR = SuperPc.regressGetErrors(spc, sl, ay);
# .
# .   In:
# .        spc = result of supervised principal components computation, returned
# .              by function SuperPc.computeRegress().
# .
# .         sl = contains prediction results, as calculated by
# .              SuperPc.computeRegressPcAndOutputVariable().
# .
# .         ay = actual output variable values.
# .
# .   Out:
# .      eR = list with relevant members depending on model type :
# .
# .     ............................................................................................
# .      >> 1) For spc$modelType = 'lm' :
# .
# .          sigma = the square root of the estimated variance of the random error,
# .                  which is given by the estimator :
# .
# .                          2     1     n    2
# .                     sigma  = -----  Sum  R [i]
# .                              n - p  i=1   
# .
# .                  where R[i] is the i-th residual.
# .
# .             R2 = fraction of the variance explained by the model (coefficient of
# .                  determination), R^2 = 1 - Sum(R[i]^2) / Sum((y[i]- ybar)^2,
# .                  where ybar = mean(y).
# .
# .           eps2 = relative error term : estimated variance of the random error,
# .                  relative to the raw variance of the output variable
# .
# .                             Sum(R[i]^2)
# .                  eps2 =  -------------------- =  1  - R2
# .                           Sum((y[i]- ybar)^2
# .
# .           ares = array of n residuals.
# .
# .     ............................................................................................
# .      >> 2) For spc$modelType = 'logistic' :
# .
# .................................................................................................
# . * Also see doc page for function: summary.lm
# . * Example:
# .
# .         sl = SuperPc.computeRegressPcAndOutputVariable(spc, dfX);
# .         eR = SuperPc.regressGetErrors(spc, sl, ay);
# .
# =================================================================================================

SuperPc.regressGetErrors <- function(spc, sl, ay)
{

      # .................................................................
      if (class(spc) != "spc.regress") {
        cat("ERROR: from SuperPc.regressGetErrors:\n");
        cat("The input spc object is not of class spc.regress\n");
        stop();
      }

      if (class(sl) != "spc.regress.estimate") {
        cat("ERROR: from SuperPc.regressGetErrors:\n");
        cat("The input sl object is not of class spc.regress.estimate\n");
        stop(msg);
      }      
      # ..................................................................

      
      
      # ...............................................................................
      # . Consistency checks :
      # ...............................................................................      
      if ((spc$modelType != 'lm') && (spc$modelType != 'logistic')) {
        cat("ERROR: from SuperPc.regressGetErrors:\n");
        cat("The model type in the input spc is not valid.\n");
        cat("spc$modelType = ", spc$modelType, "\n", sep = "");
        cat("Valid modelType = lm, logistic. Check program logic, as this should not occur.\n");
        stop();
      }

      n = spc$n;
      
      if (length(sl$ayPred) != n) {
        cat("ERROR: from SuperPc.regressGetErrors:\n");
        cat("Inconsistent array lengths:\n");
        cat("length(sl$ayPred) = ", length(sl$ayPred), "not the same as \n", sep = "");
        cat("spc$n = ", n, "\n", sep = "");        
        stop();
      }

      if (length(ay) != spc$n) {
        cat("ERROR: from SuperPc.regressGetErrors:\n");
        cat("Inconsistent array lengths:\n");
        cat("length(ay) = ", length(ay), "not the same as \n", sep = "");
        cat("spc$n = ", n, "\n", sep = "");        
        stop();
      }      
      # ................................................................................

      

     
      # ........................................................................................
      # . Linear regression model :
      # ........................................................................................      
      if (spc$modelType == 'lm') {
        # .......................................................................................
        # . Results specific to linear regression :
        # .......................................................................................        
        sumReg = summary(spc$regK);          # summary.lm for regression object.

        sigma = sumReg$sigma;                # Estimate of sd of noise term.
        R2 = sumReg$r.squared;               # R2 : fraction of variance explained by model.
        eps2 = 1 - sumReg$r.squared;         # eps2 : fraction of variance not explained by model.

        ares = sumReg$residuals;             # Residuals.

        pval = pf(sumReg$fstatistic[1],
                  df1 = 1,
                  df2 = sumReg$fstatistic[3], lower.tail = FALSE);   # P-value.
        # .......................................................................................
        # . Set the results specific to logistic regression to dummy values :
        # .......................................................................................        
        A = 0.0; 
        ALo = 0.0;
        AHi = 0.0;
        errCount = 0.0;
        errRateLo95 = 0.0;
        errRate = 0.0;
        errRateHi95 = 0.0;
        # .......................................................................................        
      }
      # ..........................................................................................


      
      # ........................................................................................
      # . Logistic regression model :
      # ........................................................................................      
      if (spc$modelType == 'logistic') {
        # .......................................................................................
        # . Results specific to logistic regression :
        # . 1. AUC statistics :
        # .......................................................................................                
        ax0 = sl$aPyPred[ay == 0];
        ax1 = sl$aPyPred[ay == 1];

        n0 = length(ax0);
        n1 = length(ax1);

        if ((n0 == 0) || (n1 == 0)) {                        # Failsafe.
          cat("ERROR: from SuperPc.regressGetErrors:\n");    
          cat("Values in ay are all 0 or all 1.\n");
          stop();
        }
        
        w = wilcox.test(ax1, ax0);                       # Wilcoxon rank-sum test.
        A = w$statistic / (n0 * n1);                     # Area under curve.
        pval = w$p.value;                                # P-value.
        auc = Stat.aucROCTest(A, n0, n1, prob = 0.95);   # Generate the confidence interval for A.
        
        ALo = auc$ALo;
        AHi = auc$AHi;        
        pvalBuf = auc$pval;                              # Should be same as pval above.
        # .......................................................................................
        # . 2. Error count :
        # .......................................................................................
        errCount = sum(sl$ayPred != ay);                          # Total errors.
        errRate = errCount / n;
        sigmaErrRate = sqrt(errRate * (1.0 - errRate) / n);       # Binomial estimate of sd.
        errRateLo95 = max(0.0, errRate - 1.96 * sigmaErrRate);    # 95% confidence interval.
        errRateHi95 = min(1.0, errRate + 1.96 * sigmaErrRate);    # 
        # .......................................................................................
        # . Set the results specific to linear regression to dummy values :
        # .......................................................................................        
        sigma = 0.0; 
        R2 = 0.0;    
        eps2 = 1.0;  
        ares = c(0.0);
        # .......................................................................................
      }
      # ........................................................................................              
      


      
      # .........................................................................
      # . Package the results :
      # .........................................................................
      eR = list(modelType = spc$modelType,
                sigma = sigma,
                R2 = R2,
                eps2 = eps2,
                pval = pval,
                ares = ares,
                A = A,
                ALo = ALo,
                AHi = AHi,
                errCount = errCount,
                errRateLo95 = errRateLo95,
                errRate = errRate,        
                errRateHi95 = errRateHi95
               );
      # .........................................................................


      # ............
      return(eR);
      # ............
      
}

# =================================================================================================
# . End of SuperPc.regressGetErrors.
# =================================================================================================







# =================================================================================================
# . SuperPc.checkDataMatricesForRegressCv : checks compatibility of the numerical data frame and the
# . -------------------------------------   experimental design data frame for cross-validation of
# .                                         regression models.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForRegressCv(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                   tSplit = factor in dfE defining the further subdivision of the training
# .                            set members into train and test sets for the cross-validation.
# .                            values = 'train' denote the training set members in that group,
# .                            values = 'test' denote the test set members in that group.
# .                            values = 'NONE' are not included. All other values are invalid.
# .
# .                            If tSplit = 'NONE'itself, then checks on this field are not done
# .                            (it is ignored).
# .
# .             parameterScan = parameter to be scanned in CV (mtop or K).
# .                     amtop = array of mtop values to be scanned (when parameterScan = 'mtop').
# .                         K = fixed number of principal components used (when parameterScan = 'mtop').
# .                        aK = array of number of principal components to be scanned (when parameterScan = 'K').
# .                      mtop = fixed number of features used (when parameterScan = 'K').
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .      - dfE has factor tSplit (check done only if tSplit not equal to 'NONE').
# .      - for the indicated factor tSplit (for non-NONE value), values in dfE 
# .        are either 'train', 'test' or 'NONE', and that the resulting training and
# .        test sets each have at least two member.
# .
# =================================================================================================

SuperPc.checkDataMatricesForRegressCv <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .................................................................................................
    # . Failsafe check on existence of required members :
    # .................................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$tSplit)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: inparam does not have member tSplit";
      stop(msg);
    }
    
    if (is.null(inparam$parameterScan)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: inparam does not have member parameterScan";
      stop(msg);
    }
    
    if (is.null(inparam$amtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: inparam does not have member amtop";
      stop(msg);
    }

    if (is.null(inparam$K)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: inparam does not have member K";
      stop(msg);
    }
    
    if (is.null(inparam$aK)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: inparam does not have member aK";
      stop(msg);
    }

    if (is.null(inparam$mtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: inparam does not have member mtop";
      stop(msg);
    }    
    # .......................................................................................    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }

    if (is.null(dfE[[inparam$tY]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegressCv:\n", sep = "");
      msg = paste(msg, "the factor tY = ", inparam$tY,
                  " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (inparam$methodSplit == 'given') {
      if (is.null(dfE[[inparam$tSplit]])) {
        msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";              
        msg = paste(msg, "the factor inparam$tSplit = ", inparam$tSplit,
                         " does not exist in the input experimental design,", sep = "");
        msg = paste(msg, " but is required under methodSplit = given.", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;                                       # All samples are in the training set.
      nNone = 0;                                        # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                       " records with values for factor ", inparam$tTrain , " = train. " ,
                       " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Check train/test split. Compute ntrainCV, ntestCV.
    # .
    # . >> methodSplit = given :
    # .......................................................................................
    if (inparam$methodSplit == 'given') {    
      if (inparam$tTrain != 'NONE') {        
        dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ]; # The training set is a subset.
      } else if (inparam$tTrain == 'NONE') {
        dfETrain = dfE;                                     # The training set is the entire set.
      }

      buf = dfETrain[[inparam$tSplit]];
      bufEx = buf[(buf != 'train') & (buf != 'test') & (buf != 'NONE')];

      if (length(bufEx) > 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";         
        msg = paste(msg, "the input experimental design for factor inparam$tSplit = ", inparam$tSplit,
                         "has invalid values, which are neither train, test or NONE.", sep = "");
        return (msg);
      }

      nTrainCv = sum(dfETrain[[inparam$tSplit]] == 'train');   # Number of cv training set members.
      nTestCv = sum(dfETrain[[inparam$tSplit]] == 'test');     # Number of cv test set members.      
    
      if (nTrainCv == 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";
        msg = paste(msg, "the input experimental design has 0 cv training set ",
                         "records with values for factor ",
                         inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTrainCv < 2) {
        msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";        
        msg = paste(msg, "the input experimental design has only nTrainCv = ", nTrainCv,
                         " records with values for factor ", inparam$tSplit , " = train. " ,
                         " The minimum number is 2. ", sep = "");
        return (msg);
      }

      if (nTestCv == 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";        
        msg = paste(msg, "the input experimental design has 0 cv test set ",
                    "records with values for factor ",
                    inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTestCv < 2) {
        msg = "ERROR: from SuperPc.checkDataMatricesForRegressCv: ";        
        msg = paste("the input experimental design has only nTestCv = ", nTestCv,
                    " records with values for factor ", inparam$tSplit , " = test. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . >> methodSplit = vfold :
    # .    The training set and the test set must each have at least 2 elements.
    # .    Note that we require above that nTrain >= 4, so that this is always possible.
    # ...................................................................................
    if (inparam$methodSplit == 'vfold') {
      nTestCv = floor(nTrain * inparam$ft);

      if (nTestCv < 2) {
        nTestCv = 2;                    # At least 2 elements in the test set.
      }

      n1 = nTrain - 1;

      if (nTestCv >= n1) {
        nTestCv = nTrain - 2;           # At least 2 elements in the training set.
      }

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }
    # .......................................................................................
    # . >> methodSplit = vfoldStrict :
    # .    
    # .    
    # ...................................................................................
    if (inparam$methodSplit == 'vfoldStrict') {
      csTemp = Stat.generateSplitsForVfold(nTrain, inparam$ft, flagRandom = FALSE);
      nTestCv = csTemp$ntest;

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }    
    # .....................................................................................



    # .......................................................................................
    # . For logistic models, check that the designated output variable is indeed
    # . binary, Y e {0, 1}.
    # .......................................................................................
    if (inparam$modelType == 'logistic') {
      if (inparam$tTrain != 'NONE') {        
        dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ]; # The training set is a subset.
      } else if (inparam$tTrain == 'NONE') {
        dfETrain = dfE;                                     # The training set is the entire set.
      }

      msgBin = Cox.checkBinaryNoNA(dfETrain[[inparam$tY]]);

      if (msgBin != 'ok') {
        cat("ERROR: from SuperPc.checkDataMatricesForRegressCv:\n", sep = "");
        cat("For the designated output variable factor tY = ", inparam$tY, "\n", sep = "");
        cat(msgBin);
        stop();
      }

      nall = nrow(dfETrain);
      n1 = sum(dfETrain[[inparam$tY]]);    # Number of instances with y = 1.

      if (n1 == nall) {
        cat("ERROR: from SuperPc.checkDataMatricesForRegressCv:\n", sep = "");
        cat("All values of output variable Y are equal to 1.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }

      if (n1 == 0) {
        cat("ERROR: from SuperPc.checkDataMatricesForRegressCv:\n", sep = "");
        cat("All values of output variable Y are equal to 0.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }      
    }
    # .......................................................................................        
    
    
    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");

    cat("             Given cross-validation split of training set :\n", sep = "");      
    cat("             Training set : nTrainCv = ", nTrainCv, "\n", sep = "");
    cat("             Test set : nTestCv = ", nTestCv, "\n", sep = "");
    # .......................................................................................



    # .......................................................................................
    # . Check on constraints imposed by matrix rank.
    # . >>Case 1: scan mtop.
    # .......................................................................................
    if (inparam$parameterScan == 'mtop') {
      mtopMin = min(inparam$amtop);            # Smallest number of features used in scan.
      nTrainCv1 = nTrainCv - 1;                # Independent rows after mean-centering each column.
      rankMin = min(nTrainCv1, mtopMin);       # Minimum data matrix rank generated.
      
      if (inparam$K > rankMin) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegressCv : ", sep = "");
        msg = paste(msg, "for parameterScan = mtop, the number of principal components", sep = "");
        msg = paste(msg, " K = ", K, " is greater than the smallest matrix rank generated,", sep = "");
        msg = paste(msg, " rankMin = min(nTrainCv -1, mtopMin) = min(",
                         nTrainCv1, ", ", mtopMin, ")", sep = "");        
        return (msg);        
      }
    }
    # .......................................................................................    
    # . >>Case 2: scan K.
    # .......................................................................................
    if (inparam$parameterScan == 'K') {
      KMax = max(inparam$aK);
      nTrainCv1 = nTrainCv - 1;                # Independent rows after mean-centering each column.
      rankMin = min(nTrainCv1, inparam$mtop);  # Data matrix rank after feature selection.

      if (inparam$mtop <= KMax) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRegressCv : ", sep = "");
        msg = paste(msg, "for parameterScan = K, the maximum number of principal components", sep = "");
        msg = paste(msg, " KMax = ", KMax, " is greater than the matrix rank after feature selection,", sep = "");
        msg = paste(msg, " rankMin = min(nTrainCv -1, mtop) = min(",
                         nTrainCv1, ", ", inparam$mtop, ")", sep = "");        
        return (msg);        
      }
    }
    # .......................................................................................            


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForRegressCv.
# =================================================================================================





# =================================================================================================
# . SuperPc.packageSpcRegress : creates an spc.regress object from the explicit inputs. Used in packaging
# . -------------------------   together partial results in the context of a cross-validation loop.
# .                             
# .   Syntax:
# .
# .      spc = SuperPc.packageSpcRegress();
# .
# .   In:
# .
# .           msg =    Message, default = 'ok' if not present.
# .            ay =    Training set values for output variable.
# .     modelType =    Type of regression model used.
# .      methodFs =    Feature selection method.                        
# .          mtop =    Number of genes for feature selection.           
# .            p0 =    P-value threshold for feature selection.         
# .             n =    Number of samples.                               
# .             p =    Number of genes.
# .            ac =    Column names. Default = NULL if not present.
# .            ym =    Value of mean for output variable.
# .           axm =    p : column means (gene-by-gene means).           
# .      indexSel =    Index of selected genes.                         
# .             m =    Number of selected genes.                        
# .       pvalMin =    Smallest univariate p-value selected.            
# .       pvalMax =    Largest univariate p-value selected.             
# .             K =    Number of pc's used in final Cox model.          
# .         abeta =    K : the regression coefficients.
# .       aseBeta =    K : standard erros for the regression coefficients.
# .            ap =    K : the P-values for the regression coefficents.
# .         beta0 =    Intercept coefficient.
# .       seBeta0 =    Standard error for intercept.
# .        pBeta0 =    P-value for intercept non-zero.
# .            qR =    Loglikelihood or F statistic for overall model.
# .           df1 =    df1 degrees of freedom for F-statistic.
# .           df2 =    df2 degrees of freedom for F-statistic.                
# .            pR =    P-value for overall model against H0: abeta = 0.
# .         avSel =    m * K : pc vectors in m-gene expression space.         
# .            av =    p * K : pc vectors full p-gene expression space.
# .      avSelTot =    Summed gene loadings in m-gene expression space.    
# .         avTot =    Summed gene loadings in p-gene expression space. 
# .            sv =    Pass the results of the internal SVD.
# .          regK =    Final regression model on K principal components.
# .
# .   Out:
# .
# .          spc = object of class spc.
# .
# =================================================================================================

SuperPc.packageSpcRegress <- function(msg = 'ok',
                                      ay,
                                      modelType,
                                      methodFs,
                                      mtop,
                                      p0,
                                      n,
                                      p,
                                      ac = NULL,
                                      ym,
                                      axm,
                                      indexSel,
                                      m,
                                      pvalMin,
                                      pvalMax,
                                      K,
                                      abeta,
                                      aseBeta,
                                      ap,
                                      beta0,
                                      seBeta0,
                                      pBeta0,
                                      qR,
                                      df1,
                                      df2,
                                      pR,
                                      avSel,
                                      av,
                                      avSelTot,
                                      avTot,
                                      sv,
                                      regK)
{

      # .......................................................................................
      # . Package the inputs :
      # .......................................................................................
      spc = list(msg = msg,                   # Output message.
                 ay = ay,                     # Training set values for output variable.
                 modelType = modelType,       # Regressino model used.
                 methodFs = methodFs,         # Feature selection method.                        
                 mtop = mtop,                 # Number of genes for feature selection.           
                 p0 = p0,                     # P-value threshold for feature selection.         
                 n   = n,                     # Number of samples.                               
                 p   = p,                     # Number of genes.
                 ac  = ac,                    # Column names.
                 ym  = ym,                    # Value of mean for the output variable.
                 axm = axm,                   # p : column means (gene-by-gene means).           
                 indexSel = indexSel,         # Index of selected genes.                         
                 m = m,                       # Number of selected genes.                        
                 pvalMin = pvalMin,           # Smallest univariate p-value selected.            
                 pvalMax = pvalMax,           # Largest univariate p-value selected.             
                 K = K,                       # Number of pc's used in final regression model.          
                 abeta = abeta,               # K : the regression coefficients.
                 aseBeta = aseBeta,           # K : standard errors for the regression coefficients.
                 ap = ap,                     # K : the P-values for the regression coefficents.
                 beta0 = beta0,               # Intercept coefficient.
                 seBeta0 = seBeta0,           # Standard error for intercept.
                 pBeta0 = pBeta0,             # P-value for intercept non-zero.        
                 qR = qR,                     # Loglikelihood or F statistic for overall model.
                 df1 = df1,                   # df1 degrees of freedom for F-statistic.
                 df2 = df2,                   # df2 degrees of freedom for F-statistic.
                 pR = pR,                     # P-value for loglikelihood ratio statistic.
                 avSel = avSel,               # m * K : pc vectors in m-gene expression space.         
                 av = av,                     # p * K : pc vectors full p-gene expression space.
                 avSelTot = avSelTot,         # Summed gene loadings in m-gene expression space.    
                 avTot = avTot,               # Summed gene loadings in p-gene expression space. 
                 sv = sv,                     # Pass the results of the internal SVD.
                 regK = regK);                # Final regression model on K principal components.
      
      class(spc) = 'spc.regress';
      # .......................................................................................

      
      # .............
      return (spc);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.packageSpcRegress.
# =================================================================================================







# =================================================================================================
# . SuperPc.computeRegressResiduals : computes the residuals for a test set, using the regression
# . -------------------------------   model parameters computed using an independent (or the same)
# .                                   data set as training set.
# .
# .   Syntax:
# .          res = SuperPc.computeRegressResiduals(spcTrain, ayIn, dfXIn);
# .
# .   In:
# .        spcTrain = result of regression model computation, returned by the function
# .                   SuperPc.computeRegress().
# .
# .       ayIn = n : vector of survival times (n = number of samples).
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .   Out:
# .     res = list with members :
# .
# .              nIn = number of samples in input test set.
# .             ayIn = nIn : input array of output variables.
# .               aR = nIn : output array of residuals for the input samples.
# .             Rrms = root-mean-square value for the residuals.
# .            epsR2 = relative error term : estimated variance of the random error,
# .                    relative to the total variance of the output variable; equal to
# .                    1 - R2; see details below.
# .               R2 = fraction of the variance explained by the model (coefficient of
# .                    determination); equal to 1 - epsR2; see details below.
# .................................................................................................
# . >>Details:
# .
# . * The root-mean-square of the residuals is given by :
# .
# .                      1    nIn   2      1/2
# .           Rrms = ( -----  sum  R [i]   )
# .                     nIn   i=1     
# .
# . where the i-th residual R[i] is given by :
# .
# .        R[i] =  yPred  -  y  
# .                     i     i
# .
# . where yPred[i] is the value of the output variable predicted by the regression model,
# . and y[i] the value for the test set.
# .
# .
# . * Regarding the other quantities :
# .
# .      epsR2 = relative error term : estimated variance of the random error,
# .              relative to the total variance of the output variable
# .
# .                                  Sum(R[i]^2) / nIn          
# .                 epsR2 =  ---------------------------------- =  1  - R2       (1)
# .                           (Sum((y[i]- ybar)^2) / (nIn - 1)  
# .
# .              where ybar = mean(y) and y[i] its the actual observed value.
# .
# .         R2 = fraction of the variance explained by the model (coefficient of
# .              determination), given by :
# .
# .
# .                                      Sum(R[i]^2) / nIn          
# .                   R^2 = 1 -  ----------------------------------              (2)
# .                               (Sum((y[i]- ybar)^2) / (nIn - 1)  
# .
# .
# .              Note that this definition is slightly different from the usual one that
# .              applies when y[i] is the actual training set :
# .
# .
# .                                      Sum(R[i]^2)
# .                   R^2 = 1 -  -----------------------                          (3)
# .                                (Sum((y[i]- ybar)^2)
# .
# .
# .              We are using Eq.(3) because in most cases this function will be
# .              applied to a test set.
# .
# =================================================================================================

SuperPc.computeRegressResiduals <- function(spcTrain, ayIn, dfXIn)
{

      # ...............................................................
      if (class(spcTrain) != "spc.regress") {
        msg = "ERROR: from SuperPc.computeRegressResiduals: ";
        msg = paste("The input spcTrain is not of class spc.regress.");
        stop(msg);
      }
      # ................................................................  


      # ...................................................................................
      # . Check for consistency :
      # ...................................................................................      
      nIn = nrow(dfXIn);      # Number of samples in input data matrix.
      p = ncol(dfXIn);        # Number of genes in input data matrix.

      if (spcTrain$p != p) {
        msg = "ERROR: from SuperPc.computeRegressResiduals: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("features as in the training data matrix.", sep = "");
        msg = paste(" Test has p = " , p, " genes.", sep = "");
        msg = paste(" Training has spcTrain$p = " , spc$p, " genes.", sep = "");        
        stop(msg);
      }

      nyIn = length(ayIn);   # Number of samples in output variable vector.

      if (nyIn != nIn) {
        msg = "ERROR: from SuperPc.computeRegressResiduals: ";        
        msg = paste("The output variable vector ayIn has nyIn = ", nyIn, "samples. ", sep = "");
        msg = paste("This is not the same as the nIn = ", nIn,
                    "samples in the data matrix dfXIn.", sep = "");        
        stop(msg);
      }

      if (nIn < 2) {
        msg = "ERROR: from SuperPc.computeRegressResiduals: ";
        msg = paste(" The input data has only one sample, nIn = ", nIn, sep = "");
        msg = paste(" a minimum of 2 is required.", sep = "");
        stop(msg);
      }
      # ......................................................................................


      
      # ...............................................................................
      # . Calculate the model predictions, based on the learned model parameters
      # . and the input covariates :
      # ...............................................................................
      s = SuperPc.computeRegressPcAndOutputVariable(spcTrain, dfXIn);
      # ...............................................................................
      # . Compute the residuals and their rms value :
      # ...............................................................................
      aR = s$ayPred - ayIn;
      sumR2 = sum(aR * aR);                   # Sum of residuals squared.

      Rrms = sqrt(sumR2 / nIn);               # Root mean square value.
      epsR2 = (sumR2 / nIn) / var(ayIn);      # Relative error term.
      R2 = 1.0 - epsR2;                       # Coefficient of determination.
      # ................................................................................


      # ....................................................
      # . Package the results :
      # ....................................................
      res = list(nIn = nIn,
                 ayIn = ayIn,
                 aR = aR,
                 Rrms = Rrms,
                 epsR2 = epsR2,
                 R2 = R2);
      # ....................................................

      
      # .............
      return (res);
      # .............
      
}

# =================================================================================================
# . End of SuperPc.computeRegressResiduals.
# =================================================================================================





# =================================================================================================
# . SuperPc.computeCoxUniWithCov : generates univariate, gene-by-gene Cox proportional hazard statistics 
# . ----------------------------   for the given input data matrix. For each gene computes one of two measures of 
# .                                significance, one based on the fitted model score 2 * (l(beta*) - l(0)),
# .                                and the other based on the score for beta = 0, U(0)^2 / J(0). Each of
# .                                these scores have a Chi-squared distribution with one degree of freedom
# .                                under the null hypothesis of no dependence of survival time on gene
# .                                expression. Internally also does feature selection on the selected score.
# .
# . Note: this is a variant of computeCoxFs, but with the additional option of choosing between
# .       the two possible scores outlined above, the log-likelihood or the U0-based test scores.
# .
# . Note 2: this ``WithCov'' version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .       fs = SuperPc.computeCoxUniWithCov(at, as, az, dfX,
# .                                         scoreType, methodFs, p0, mtop,
# .                                         typePval, flagVerbose);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     scoreType = type of score to be used for computing P-values.
# .                 Allowed values : 
# .                  - 'loglik' : use score = 2 * (l(beta*) - l(0)).
# .                  - 'u0'     : use score = U(0)^2 / J(0).
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values from Cox proportional hazards model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .      typePval = type of the P-value that is to be used for the feature selection.
# .                 Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .   flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .
# .   Out:
# .        fs = list, with members:
# .        msg                      # Output message. = 'ok' for normal execution,
# .                                 # else reports error or inconsistencies (e.g.
# .                                 # 0 features passed by filter).
# .        scoreType                # Type of score statistic used for feature selection.
# .        methodFs                 # Feature selection method.                        
# .        mtop                     # Number of genes for feature selection.           
# .        p0                       # P-value threshold for feature selection.         
# .        n                        # Number of samples.                               
# .        p                        # Number of genes.
# .        ac                       # p : column names (gene names).
# .        axm                      # p : column means (gene-by-gene means).
# .        ascore                   # p : scores for all the genes.
# .        ap                       # p : P-values  for all the genes.
# .        abeta                    # p : optimal beta (for logLikelihood) or beta = 0 (for u0) for all the genes.
# .        ascoreU0                 # p : U0 scores for all the genes.
# .        apU0                     # p : P-values based on U0 scores, for all the genes.
# .        m                        # Number of selected genes.                        
# .        indexSel                 # m : index of selected genes.
# .        pvalMin                  # Smallest univariate p-value selected.            
# .        pvalMax                  # Largest univariate p-value selected.
# .
# =================================================================================================

SuperPc.computeCoxUniWithCov <- function(at, as, az, dfX,
                                         scoreType, methodFs, p0, mtop,
                                         typePval,
                                         flagVerbose)
{

      # ........................................................................
      stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));      
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);

      allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
      if (is.null(allowedTypePval[[typePval]])) {
        cat("ERROR: from SuperPc.computeCoxUniWithCov:\n");
        cat("typePval = ", typePval, " is not valid.\n", sep = "");
        cat("Valid: model, X, Z, ZX.\n", sep = "");
        stop();
      }
      # ........................................................................

     

      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPc.computeCoxUniWithCov.\n");
      }
      # ........................................................................      

      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................
      n = nrow(dfX);       # Number of samples.
      p = ncol(dfX);       # Number of genes.
      ac = colnames(dfX);  # Array of gene names.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.

      if (nt != n) {
        msg = "ERROR: from SuperPc.computeCoxUniWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxUniWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPc.computeCoxUniWithCov: ";
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      

      if (mtop > p) {
        msg = "ERROR: from SuperPc.computeCoxUniWithCov: ";
        msg = paste("mtop = ", mtop, " is greater than number of genes p = ", p, sep = "");
        stop(msg);
      }
      # ......................................................................................



      # .......................................................................................
      # . Column-center the data then generate univariate Cox scores for each gene separately.
      # .......................................................................................
      axm = colMeans(dfX);                                     # Save the p column means.
      
      dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.

      cat(" ..........  Generate scores using scoreType = ", scoreType, "\n", sep = "");

      if (scoreType == 'loglik') {      
        coxS = Cox.computeOnDataFrameSimpleBetaWithCov(at, as, az, dfXc, flagVerbose = TRUE);   # log-likelihood score.
      } else if (scoreType == 'u0') {
        cat("ERROR: from SuperPc.computeCoxUniWithCov:\n");
        cat("scoreType = u0 not yet implemented!\n");
        cat("You must still code for it and place appropriate function call here.\n");
        cat("J. Theilhaber. 12-12-2010.\n");
        stop();
        coxS = Cox.computeOnDataFrameNoTiesParallel(at, as, dfXc, flagVerbose = TRUE);           # U0^2/J0 score.
      } else {
        cat("ERROR: from SuperPc.computeCoxUniWithCov: scoreType = ", scoreType, " is not valid.\n");    # Failsafe.
        cat("Please check program logic.\n");
        stop();
      }
      # .......................................................................................

      
      
      # .......................................................................................
      # . Perform feature selection with the indicated method and parameters,
      # .......................................................................................
      #xxx Test for compatibility with old method. #zzz
      #xxx selF = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtop, coxS); #zzz

      selF = SuperPc.selectFeaturesCoxWithCov(dfXc, methodFs, p0, mtop, coxS, typePval);
      # .......................................................................................



      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      msg = 'ok';
      
      fs = list(msg = msg,                   # Output message.
                scoreType = scoreType,       # Type of score statistic used for feature selection.        
                methodFs = methodFs,         # Feature selection method.                        
                mtop = mtop,                 # Number of genes for feature selection.
                typePval = typePval,         # Type of P-value used for selection.
                p0 = p0,                     # P-value threshold for feature selection.         
                n   = n,                     # Number of samples.                               
                p   = p,                     # Number of genes.
                ac = ac,                     # p : column names (gene names).        
                axm = axm,                   # p : column means (gene-by-gene means).
                ascore = coxS$ascore,        # p : scores for all the genes.
                ap = coxS$ap,                # p : model P-values for all the genes.

                abetaX = coxS$abetaX,        # Coefficients for x effects.
                abetaZ = coxS$abetaZ,        # Coefficients for z effects.
                abetaZX = coxS$abetaZX,      # Coefficients for z * x interaction.

                apX = coxS$apX,              # P-values for x coefficients.
                apZ = coxS$apZ,              # P-values for z coefficients.
                apZX = coxS$apZX,            # P-values for z * x interaction coefficients.

                aseBetaX = coxS$aseBetaX,    # Coefficients for x effects.
                aseBetaZ = coxS$aseBetaZ,    # Coefficients for z effects.
                aseBetaZX = coxS$aseBetaZX,  # Coefficients for z * x interaction.
        
                m = selF$m,                  # Number of selected genes.                        
                indexSel = selF$indexSel,    # m : index of selected genes.
                pvalMin = selF$pvalMin,      # Smallest univariate p-value selected.            
                pvalMax = selF$pvalMax );    # Largest univariate p-value selected.
      
      class(fs) = 'spc.cox.fs';              # Actually, a superset of class 'fs'.
      # .......................................................................................

      
      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Exit SuperPc.computeCoxUniWithCov.\n");
      }
      # ........................................................................            

      
      # .............
      return (fs);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.computeCoxUniWithCov.
# =================================================================================================




# =================================================================================================
# . SuperPc.checkDataMatricesForCoxUniWithCov : checks compatibility of the numerical data frame and the
# . -----------------------------------------   experimental design data frame for Cox proportional hazard
# .                                             regression feature selection.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForCoxUniWithCov(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain (unless tTrain = NONE, in which case all instances
# .        become training set members).
# .      - if tTrain is not NONE, then for that factor, dfE has at least two instances with value
# .        'train'.
# .
# =================================================================================================

SuperPc.checkDataMatricesForCoxUniWithCov <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxUniWithCov: inparam does not have member tTrain";
      stop(msg);
    }
    # .......................................................................................    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {
      if (is.null(dfE[[inparam$tTrain]])) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxUniWithCov :\n", sep = "");
        msg = paste(msg, "the factor tTrain = ", inparam$tTrain,
                    " does not exist in the input experimental design.", sep = "");
        return (msg);
      }
    }

    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxUniWithCov :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxUniWithCov :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxUniWithCov :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................

    
    
    # .......................................................................................
    # . Check consistency of number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxUniWithCov :\n", sep = "");      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................

    
    # .......................................................................................
    # . Check on the number of training set members.
    # . General case, with a not NONE factor specified :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {    
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    
      if (nTrain == 0) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxUniWithCov :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                     inparam$tTrain , " = train." , sep = "");
        return (msg);
      }

      if (nTrain < 2) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxUniWithCov :\n", sep = "");         
        msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                    " records with values for factor ", inparam$tTrain , " = train. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, all members retained :
    # .......................................................................................
    if (inparam$tTrain == 'NONE') {    
      nTrain = n;                               # All samples are training set members.
      nNone = 0;                                # Number of all other samples is 0.
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");                
    # .......................................................................................        


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForCoxUniWithCov.
# =================================================================================================





# =================================================================================================
# . SuperPc.checkDataMatricesForCoxWithCov : checks compatibility of the numerical data frame and the
# . --------------------------------------   experimental design data frame for Cox proportional hazard
# .                                          regression.
# .
# . This version allows for an additional external covariate.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForCoxWithCov(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                  methodFs = feature selection method.
# .                      mtop = number of features selected under feature selection
# .                             method `mtop'.
# .                         K = number of principal components used.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain (unless tTrain = NONE, in which case all instances
# .        become training set members).
# .      - if tTrain is not NONE, then for that factor, dfE has at least two instances with value
# .        'train'.
# .      - checks that mtop >= K.
# .
# =================================================================================================

SuperPc.checkDataMatricesForCoxWithCov <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxWithCov: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$tTest)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxWithCov: inparam does not have member tTest";
      stop(msg);
    }
    
    if (is.null(inparam$methodFs)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxWithCov: inparam does not have member methodFs";
      stop(msg);
    }

    if (is.null(inparam$mtop)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxWithCov: inparam does not have member mtop";
      stop(msg);
    }

    if (is.null(inparam$K)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForCoxWithCov: inparam does not have member K";
      stop(msg);
    }            
    # .......................................................................................    

    

    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {
      if (is.null(dfE[[inparam$tTrain]])) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov :\n", sep = "");
        msg = paste(msg, "the factor tTrain = ", inparam$tTrain,
                         " does not exist in the input experimental design.", sep = "");
        return (msg);
      }
    }

    if (inparam$tTest != 'NONE') {        
      if (is.null(dfE[[inparam$tTest]])) {
         msg = "ERROR: from SuperPc.checkDataMatricesForCoxWithCov: ";      
         msg = paste(msg, "the factor inparam$tTest = ", inparam$tTest,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }
    
    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................




    
    
    # .......................................................................................
    # . Check consistency of number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov :\n", sep = "");      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................

    
    
    # .......................................................................................
    # . Check on the number of training set members.
    # . General case, with a not NONE factor specified :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {    
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    
      if (nTrain == 0) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                     inparam$tTrain , " = train." , sep = "");
        return (msg);
      }

      if (nTrain < 2) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov :\n", sep = "");         
        msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                    " records with values for factor ", inparam$tTrain , " = train. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, all members retained :
    # .......................................................................................
    if (inparam$tTrain == 'NONE') {    
      nTrain = n;                               # All samples are training set members.
      nNone = 0;                                # Number of all other samples is 0.
    }
    # .......................................................................................


    # .......................................................................................
    # . Check on the number of test set members.
    # .......................................................................................
    if (inparam$tTest != 'NONE') {    
      nTest = sum(dfE[[inparam$tTrain]] == 'test');     # Number of test set members.
    
      if (nTest == 0) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor tTest = ",
                     inparam$tTest , " = test." , sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, no test set specified:
    # .......................................................................................
    if (inparam$tTest == 'NONE') {    
      nTest = 0;
    }
    # .......................................................................................



    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");

    if (inparam$tTest != 'NONE') {
      cat("             Number of samples in test set : nTest = ", nTest, "\n", sep = "");
    }      
    
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");                
    # .......................................................................................        



    # .......................................................................................
    # . Check on number of features selected relative to the number of principal components :
    # .......................................................................................    
    if (inparam$methodFs == 'mtop') {
      if (inparam$mtop < inparam$K) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov : ", sep = "");        
        msg = paste(msg, "the number of features to be selected, mtop = ", inparam$mtop,
                    ", is less than the number of principal components, K = " , inparam$K, ".", sep = "");
        return (msg);        
      }
    }

    if (nTrain < inparam$K) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForCoxWithCov : ", sep = "");        
      msg = paste(msg, "the number of samples in the training set, nTrain = ", nTrain,
        ", is less than the number of principal components, K = " , inparam$K, ".", sep = "");
      return (msg);        
    }
    # .......................................................................................



    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForCoxWithCov.
# =================================================================================================





# =================================================================================================
# . SuperPc.computeCoxWithCov : computes a de novo Cox proportional hazards model, given the
# . -------------------------   input sample survival times and censoring statuses.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .       spc = SuperPc.computeCoxWithCov(at, as, az, dfX,
# .                                       methodFs, p0, mtop, K,
# .                                       typePval, flagVerbose);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     scoreType = type of score to be used for computing P-values.
# .                 Allowed values : 
# .                  - 'loglik' : use score = 2 * (l(beta*) - l(0)).
# .                  - 'u0'     : use score = U(0)^2 / J(0).
# .
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values from Cox proportional hazards model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .      typePval = type of the P-value that is to be used for the feature selection.
# .                 Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .   flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        spc = list, with members:
# .        msg                      # Output message. = 'ok' for normal execution,
# .                                 # else reports error or inconsistencies (e.g.
# .                                 # 0 features passed by filter).
# .        type                     # Type of spc calculation. Here = 'coxph'.
# .        methodFs                 # Feature selection method.                        
# .        mtop                     # Number of genes for feature selection.           
# .        p0                       # P-value threshold for feature selection.         
# .        n                        # Number of samples.                               
# .        p                        # Number of genes.
# .        ac                       # p : column names (gene names).
# .        axm                      # p : column means (gene-by-gene means).           
# .        indexSel                 # m : index of selected genes.                         
# .        m                        # Number of selected genes.                        
# .        pvalMin                  # Smallest univariate p-value selected.            
# .        pvalMax                  # Largest univariate p-value selected.             
# .        K                        # Number of pc's used in final Cox model.          
# .        abeta                    # K : Cox coefficients.
# .        aseBeta                  # K : standard errors for the Cox coefficients.                            
# .        ap                       # K : P-values for the Cox coefficents.            
# .        qR                       # Loglikelihood ratio statistic (df = K).          
# .        pR                       # P-value for loglikelihood ratio statistic.       
# .        av                       # p * K : pc vectors full p-gene expression space. 
# .        avtot                    # Summed gene loadings in p-gene expression space. 
# .        sv                       # Pass the results of the internal SVD.
# .        bh                       # Baseline hazard object. See function: 
# .                                 # >> SuperPc.computeBaselineHazardNoTies() for member details.
# ................................................................................................
# .               sv = SVD results :
# .                    sv$d = array of m singular values.
# .                    sv$u = array of left eigenvectors (prop. to principal compnents).
# .                    sv$v = array of right eigenvectors.
# .
# =================================================================================================

SuperPc.computeCoxWithCov <- function(at, as, az, dfX,
                                      scoreType, methodFs, p0, mtop, K, typePval,
                                      flagVerbose)
{

      # ........................................................................
      stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));        
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);
      stopifnot(K >= 1);

      allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
      if (is.null(allowedTypePval[[typePval]])) {
        cat("ERROR: from SuperPc.computeCoxWithCov:\n");
        cat("typePval = ", typePval, " is not valid.\n", sep = "");
        cat("Valid: model, X, Z, ZX.\n", sep = "");
        stop();
      }            
      # ........................................................................


      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPc.computeCoxWithCov.\n");
      }
      # ........................................................................      

      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................
      n = nrow(dfX);       # Number of samples.
      p = ncol(dfX);       # Number of genes.
      ac = colnames(dfX);  # Array of gene names.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.      

      if (nt != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCov: ";
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      
      if (mtop > p) {
        msg = "ERROR: from SuperPc.computeCoxWithCov: ";
        msg = paste("mtop = ", mtop, " is greater than number of genes p = ", p, sep = "");
        stop(msg);
      }

      n1 = n - 1;
      rtemp = min(n1, p);    # Rank of the data matrix.

      if (K > rtemp) {
        msg = "ERROR: from SuperPc.computeCoxWithCov: ";
        msg = paste("K = ", K, " is greater than the data matrix rank = ", rtemp, sep = "");
        stop(msg);
      }
      # ......................................................................................



      # .......................................................................................
      # . Column-center the data then generate univariate Cox scores for each gene separately.
      # .......................................................................................
      axm = colMeans(dfX);                                     # Save the p column means.
      
      dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.

      if (scoreType == 'loglik') {
        coxS = Cox.computeOnDataFrameSimpleBetaWithCov(at, as, az, dfXc, flagVerbose = TRUE);  # log-likelihood score.
      } else if (scoreType == 'u0') {
        cat("ERROR: from SuperPc.computeCoxUniWithCov:\n");
        cat("ERROR: scoreType = u0 not yet implemented!\n");
        cat("You must still code for it and place appropriate function call here.\n");
        cat("J. Theilhaber. 12-12-2010.\n");
        stop();
        coxS = Cox.computeOnDataFrameNoTiesParallel(at, as, dfXc, flagVerbose = TRUE);  # New.
      } else {
        cat("ERROR: from SuperPc.computeCoxWithCov: scoreType = ", scoreType, " is not valid.\n");    # Failsafe.
        cat("Please check program logic.\n");
        stop();
      }
      # ........................................................................................
      # .Compare with my own implementation of the U(0)^2 / J(0) calculation :
      # ........................................................................................      
      #xxxx cs = Cox.computeSingleNoTies(at, as, dfXc[ , 1]);      # Test for a single slice, first column.
      #xxxx Cox.plotUnivariateComparison(coxS, coxSnew);  # Plot the two sets of values.
      # .......................................................................................
      # . Perform the feature selection with the indicated method and parameters :
      # .......................................................................................      
      #xxx  selF = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtop, coxS);
      selF = SuperPc.selectFeaturesCoxWithCov(dfXc, methodFs, p0, mtop, coxS, typePval)      
      # .......................................................................................
      # . Catch the unlikely case where remaining features less than principal components :
      # .......................................................................................            
      if (selF$m < K) {
        msg = "ERROR: from SuperPc.computeCoxWithCov: ";        
        msg = paste(msg, "Remaining features m = ", selF$m, " less than principal components K = ",
                    K, sep = "");
        spc = list(msg = msg, m = selF$m);
        return (spc);
      }
      # .......................................................................................
      # . Do the svd and generate Cox proportional hazard model :
      # .......................................................................................
      cSel = SuperPc.computeCoxOnSelectedFeaturesWithCov(at, as, az, selF$dfXSel, K);
      # .......................................................................................
      # . Compute the baseline hazard functions (here using an approximation that assumes
      # . no ties) :
      # .......................................................................................
      bh = SuperPc.computeBaselineHazardNoTiesWithCov(at, as, az, cSel, selF$dfXSel);      
      # .......................................................................................
      # . Project back to orignal p-dimensional vector space:
      # .......................................................................................
      fullPc = SuperPc.projectToFullWithCov(p,
                                            cSel$avSel,
                                            cSel$avSelTot,
                                            cSel$avSelIntTot,        
                                            selF$indexSel);
      # .......................................................................................


      # .......................................................................................
      # . Get the genes that were selected by the computation :
      # .......................................................................................
      agFs = colnames(selF$dfXSel);          # Genes selected by the feature selection.
      # .......................................................................................            
    
    

      # .......................................................................................
      # . Package the results (see also function SuperPc.packageSpcCoxWithCov()) :
      # .......................................................................................
      msg = 'ok';
      
      spc = list(msg = msg,                   # Output message.
                 methodFs = methodFs,         # Feature selection method.                        
                 mtop = mtop,                 # Number of genes for feature selection.           
                 p0 = p0,                     # P-value threshold for feature selection.         
                 n   = n,                     # Number of samples.                               
                 p   = p,                     # Number of genes.
                 ac = ac,                     # p : column names (gene names).        
                 axm = axm,                   # p : column means (gene-by-gene means).
                 indexSel = selF$indexSel,    # Index of selected genes.
                 agFs = agFs,                 # Genes selected by the first-pass feature selection.        
                 m = selF$m,                  # Number of selected genes.                        
                 pvalMin = selF$pvalMin,      # Smallest univariate p-value selected.            
                 pvalMax = selF$pvalMax,      # Largest univariate p-value selected.             
                 K = K,                       # Number of pc's used in final Cox model.
                 typePval = typePval,         # Type of P-value used for selection.        
                 abeta = cSel$abeta,          # K : the Cox coefficients.
                 aseBeta = cSel$aseBeta,       # K : standard errors for the Cox coefficients.
                 apBeta= cSel$apBeta,          # K : P-values for the Cox coefficients.
                 betaZ = cSel$betaZ,           # External covariate Cox coeff.
                 seBetaZ = cSel$seBetaZ,       # External covariate coeff std. err.
                 pBetaZ = cSel$pBetaZ,         # External covariate coeff std. err.        
                 agamma = cSel$agamma,         # K : the interaction terms.
                 aseGamma = cSel$aseGamma,     # K : standard errors for interaction terms.
                 apGamma = cSel$apGamma,       # K : P-values for interaction terms.    
                 qR = cSel$qR,                 # Loglikelihood ratio statistic (df = 2 * K + 1).
                 pR = cSel$pR,                 # P-value for loglikelihood ratio statistic.
                 avSel = cSel$avSel,           # m * K : pc vectors in m-gene expression space.         
                 av = fullPc$av,               # p * K : pc vectors full p-gene expression space.
                 avSelTot = cSel$avSelTot,        # Summed gene loadings for direct terms, m-gene space.
                 avSelIntTot = cSel$avSelIntTot,  # Summed gene loadings for interaction terms, m-gene space.
                 avTot = fullPc$avTot,          # Summed gene loadings, direct effects, in p-space.
                 avIntTot = fullPc$avIntTot,    # Summed gene loadings, interaction effects, in p-space.         
                 sv = cSel$sv,                  # Pass the results of the internal SVD.
                 coxK = cSel$coxK,              # Final Cox model on K principal components.
                 bh = bh);                      # Baseline hazard object.
      
      class(spc) = 'spc.cox.cov';
      # .......................................................................................

      
      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Exit SuperPc.computeCoxWithCov.\n");
      }
      # ........................................................................            

      
      # .............
      return (spc);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.computeCoxWithCov.
# =================================================================================================






# =================================================================================================
# . SuperPc.computeCoxOnSelectedFeaturesWithCov : computes a Cox proportional hazards model, given
# . -------------------------------------------   an input data matrix which has already undergone
# .                                               feature selection, and the input survival times and
# .                                               censoring statuses.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .       cSel = SuperPc.computeCoxOnSelectedFeaturesWithCov(at, as, az, dfXSel, K);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfXSel = n * m : data matrix of gene expression data, after mean-centering
# .                    and feature selection.
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .
# .   Out:
# .        cSel = list, with members:
# .
# .         abeta         # K Cox coefficients for the principal components.
# .         aseBeta       # K std. err. for the principal components coeffs.
# .         apBeta        # K P-values for the principal components coeffs.
# .
# .         betaZ         # Coeff. for the external covariate.
# .         seBetaZ       # Std. err. for external covariate coeff.
# .         pBetaZ        # P-values for external covaraite coeff.
# .      
# .         agamma        # K interaction terms coeffs.
# .         aseGamma      # K std. err. for interaction terms coeffs.
# .         apGamma       # K P-values for the interaction terms.
# .
# .         qR            # Loglikelihood ratio statistic (df = 2 * K + 1).          
# .         pR            # P-value for loglikelihood ratio statistic.
# .         avSel         # m * K-dimensional array: the pc vectors in m-gene expression space.         
# .         avSelTot      # m-dimensional array: Summed gene loadings in m-gene expression space.    
# .         sv            # Pass the results of the internal SVD.
# .         coxK          # Final Cox model on K principal components.
# . 
# =================================================================================================

SuperPc.computeCoxOnSelectedFeaturesWithCov <- function(at, as, az, dfXSel, K)
{

      # ...........................
      stopifnot(K >= 1);
      # ...........................


      # ....................
      n = nrow(dfXSel);      
      m = ncol(dfXSel);
      # ....................


      # .................................................................................
      # . Check on lengths of arrays :
      # .................................................................................      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.      

      if (nt != n) {
        msg = "ERROR: from SuperPc.computeCoxOnSelectedFeaturesWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxOnSelectedFeaturesWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPc.computeCoxOnSelectedFeaturesWithCov: ";
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      # .................................................................................

      

      # .......................................................................................
      # . Catch the case where the matrix rank is smaller than the number of 
      # . principal components specified for the analysis.
      # .......................................................................................
      if (K >= m) {
        msg = paste("ERROR: from SuperPc.computeCoxOnSelectedFeaturesWithCov: ", sep = "");
        msg = paste(msg, "Number K = ", K, " of principal components ",
                    " greater than or equal to the number of genes m = ", m, sep = "");
        stop(msg);
      }

      n1 = n - 1;

      if (K >= n1) {
        msg = paste("ERROR: from SuperPc.computeCoxOnSelectedFeaturesWithCov: ", sep = "");
        msg = paste(msg, "Number K = ", K, " of principal components ",
                    " greater than or equal to the number of samples minus 1, n1 = ", n1, sep = "");
        stop(msg);
      }
      # .......................................................................................

      
      
      
      # .......................................................................................
      # .                                 T
      # . Perform the SVD :  X = U . D . V   on the subsetted data matrix.
      # .......................................................................................      
      sv = svd(dfXSel);                    # SVD on the subsetted data matrix.
      # .......................................................................................


    
      # .......................................................................................
      # . Compute a Cox proportional hazard model on the first K principal component.
      # .
      # . Note that we are using the expansion :
      # .
      # .              --          --                                              
      # .              |  -- x  --> |    
      # .              |      1     |                               
      # .              |  -- x  --> |   .      K             T     
      # .        X =   |      2     |   =     Sum   d   u   v                               
      # .        -     |   . . .    |        l = 1   l  -l  -l
      # .              |  -- x  --> |
      # .              |      n     |
      # .              --          --
      # .
      # . to approximate the sample vectors by the first K principal components.
      # . Here the u_l are n-dimensional and the v_l m-dimensional vectors.
      # .
      # . The coefficient for the i-th sample vector x_i for the l-th PC is thus d_l * u_li.
      # .......................................................................................
      dBuf = matrix(sv$d[1:K], nrow = n, ncol = K, byrow = TRUE);  # Spread onto n rows.
      
      uK = dBuf * sv$u[ , 1:K];            # n * K matrix: projections onto the first K principal components.
      # .......................................................................................
      # . Cox proportional hazard model with dependence on the principal components and on
      # . the external covariate, with interaction terms included.
      # . Coeffcients are returned in order (here for say K = 3) :
      # . uK1, uK2, uK3, az, uK1:az, uK2:az, uK3:az
      # .......................................................................................      
      coxK = coxph(Surv(at, as) ~ uK + az + az * uK);     # Cox model on 2 * K + 1 variables.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);       # Likelihood ratio statistic.
      dfTemp = 2 * K + 1;                                 # Degrees of freedom.
      pR = pchisq(qR, df = dfTemp, lower.tail = FALSE);   # p-value from likelihood ratio.
      
      coxKsum = summary(coxK);
      coxKcoef = coxKsum$coef;        # Contains 2 * K + 1 coefficients and P-values.
      # ..................................................................................
      # . Extract the various coefficients, std. errs. and attendant P-values :
      # ..................................................................................      
      abeta = coxKcoef[1:K , 1];       # K Cox coefficients for the principal components.
      aseBeta = coxKcoef[1:K , 3];     # K std. err. for the principal components coeffs.
      apBeta = coxKcoef[1:K , 5];      # K P-values for the principal components coeffs.

      K1 = K + 1;

      betaZ = coxKcoef[K1 , 1];        # Coeff. for the external covariate.
      seBetaZ = coxKcoef[K1 , 3];      # Std. err. for external covariate coeff.
      pBetaZ = coxKcoef[K1 , 5];       # P-value for external covariate coeff.

      Ka = K + 2;
      Kb = 2 * K + 1;
      
      agamma = coxKcoef[Ka:Kb , 1];     # K interaction terms coeffs.
      aseGamma = coxKcoef[Ka:Kb , 3];   # K std. err. for interaction terms coeffs.
      apGamma = coxKcoef[Ka:Kb , 5];    # K P-values for the interaction terms.
      # .......................................................................................
      # . Compute the loadings on the genes. These are just the components of the
      # . corresponding principal component vectors times the Cox coefficients,
      # . with separate sums for the direct and the interaction terms.
      # .
      # . Thus if x is the gene expression vector, then :
      # .
      # .     lambda(t|x, z) = lambda_0(t) *
      # .
      # .                           T                            T
      # .                      exp(a  . x  +  betaZ . z  +  z . b . x)
      # .
      # .  where vectors a and b are determined by :
      # .
      # .               a = VK . beta
      # .               b = VK . gamma
      # .
      # .  with VK = (v1, v2, ... , vK).
      # .......................................................................................      
      avSel = sv$v[ , 1:K];                # m * K : the first K pc's in the subspace of m selected genes.

      if (K == 1) {
        avSel = as.matrix(avSel);          # Must cast as matrix when K == 1.
      }

      rownames(avSel) = colnames(dfXSel);  # These are the selected gene names.
      colnames(avSel) = paste("pc", 1:K);  # Columns names are those of the pcs.
      
      avSelTot = avSel %*% abeta;      # Summed gene loadings in subspace of m selected genes, for direct terms.
      avSelIntTot = avSel %*% agamma;  # Summed gene loadings in subspace of m selected genes, for inter. terms.
      # .......................................................................................



      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      cSel = list(abeta = abeta,           # K : the Cox coefficients.
                  aseBeta = aseBeta,       # K : standard errors for the Cox coefficients.
                  apBeta= apBeta,          # K : P-values for the Cox coefficients.
                  betaZ = betaZ,           # External covariate Cox coeff.
                  seBetaZ = seBetaZ,       # External covariate coeff std. err.
                  pBetaZ = pBetaZ,         # External covariate coeff std. err.        
                  agamma = agamma,         # K : the interaction terms.
                  aseGamma = aseGamma,     # K : standard errors for interaction terms.
                  apGamma= apGamma,        # K : P-values for interaction terms.    
                  qR = qR,                 # Loglikelihood ratio statistic (df = K).          
                  pR = pR,                 # P-value for loglikelihood ratio statistic.
                  avSel = avSel,           # m * K : pc vectors in m-gene expression space.         
                  avSelTot = avSelTot,         # Summed gene loadings for direct terms, m-gene space.
                  avSelIntTot = avSelIntTot,   # Summed gene loadings for interaction terms, m-gene space.         
                  sv = sv,                 # Pass the results of the internal SVD.
                  coxK = coxK);            # Final Cox model on K principal components.

      class(cSel) = 'spc.cox.selected.features';
      # .......................................................................................

      
      # .............
      return (cSel);
      # .............
      

}

# =================================================================================================
# . End of SuperPc.computeCoxOnSelectedFeaturesWithCov.
# =================================================================================================






# =================================================================================================
# . SuperPc.computeBaselineHazardNoTiesWithCov : computes the baseline hazard function, using the results
# . ------------------------------------------   of SuperPc.computeCoxOnSelectedFeaturesWithCov(). This is
# .                                       a simplified form of the Breslow estimator that assumes
# .                                       that there are no ties in the data.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .          bh = SuperPc.computeBaselineHazardNoTiesWithCov(at, as, cSel, dfXSel);
# .
# .   In:
# .         at = n : vector of survival times (n = number of samples).
# .
# .         as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .         az = n : vector for external covariate.
# .
# .       cSel = result of supervised principal components computation, returned
# .              by function SuperPc.computeCoxOnSelectedFeatures().
# .
# .     dfXSel = input data frame, subsetted to the feature-selected genes that
# .              were used in the supervised principal components calculation.
# .
# .   Out:
# .      bh = list with members :
# .
# .                       n =  Number of time points.
# .                  atSort =  Array of (sorted) time points.
# .         aLambdaBaseDiff =  Differential baseline hazard function, sorted order.
# .             aLambdaBase =  Baseline hazard function, sorted order.
# .                  aSBase =  Baseline survival function, sorted order.
# .                  aMSort =  Martingale residuals in sorted order.
# .                            All three aLambdaBaseDiff, aLambdaBase and
# .                            (sorted order == keyed on sorted time array, atSort).
# .                      aM =  Martingale residuals in original, unsorted order.
# .
# .................................................................................................
# . We are applying the Breslow estimator for the cumulative hazard function (see. Zhang ST 745,
# . p. 213) :
# .                           _                             _
# .                          |                               | 
# .                          |           dN(x)               | 
# .    Lambda  (t) =    sum  | ----------------------------- | 
# .          0         x < t |    n                          | 
# .                          |   sum   Y (x) exp(beta * z )  | 
# .                          |   l = 1  l                l   | 
# .                          |_                             _|
# .
# . where dN(x) = 1 if there was a death at time x, 0 otherwise (that is, if event was censored)
# .
# =================================================================================================

SuperPc.computeBaselineHazardNoTiesWithCov <- function(at, as, az, cSel, dfXSel)
{

      # ........................................................................
      if (class(cSel) != "spc.cox.selected.features") {
        msg = "ERROR: from SuperPc.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("The input cSel is not of class spc.cox.selected.features.");
        stop(msg);
      }
      # ........................................................................


      # ....................
      n = nrow(dfXSel);      
      m = ncol(dfXSel);
      # ....................


      
      # .................................................................................
      # . Check on lengths of arrays :
      # .................................................................................      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.      

      if (nt != n) {
        msg = "ERROR: from SuperPc.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPc.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      # .................................................................................

      

      
      # ..............................................................................
      # . Check consistency of the input data matrix with the cSel object :
      # ..............................................................................      
      mHere = nrow(cSel$avSel);        # avSel is an m * K matrix.
      
      if (mHere != m) {
        msg = "ERROR: from SuperPc.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("features as in the input cSel object.", sep = "");
        msg = paste(" dfXSel has m = " , m, " genes.", sep = "");
        msg = paste(" cSel$avSel has = " , mHere, " genes.", sep = "");        
        stop(msg);
      }
      # ...............................................................................


      
      # ...................................................................................
      # . Compute the log-hazard ratio for each sample :
      # .
      # .                      lambda(t|xi, z)
      # .       aloghR  =  log ---------------
      # .                        lambda (t)
      # .                              0
      # . where xi = vector or principal components and z = external covariate.
      # .      
      # . We first compute the n * K matrix of principal componenst.
      # .
      # .           -                       -
      # .           |xi    xi    . . . xi   |
      # .           |  11    12          1K |
      # .       Y = |                       |
      # .           | . . .      . . .   .  |
      # .           |                       |
      # .           |xi    xi    . . . xi   |
      # .           |  n1    n2          nK |
      # .           -                       -
      # .
      # . where :
      # .               T
      # .     xi    =  v  . x   ,  l = 1, 2, . . ., K
      # .       il      l    i
      # .
      # . where v  is the l-the principal component vector (n components)
      # .        l
      # . and x  the i-th sample vector (n components).
      # .      i
      # .      
      # . We then compute the log-hazard ratios for all the samples, given by :
      # .
      # .                T                            T
      # .   aloghR   = xi  . beta  + beta  . z  + z xi  . gamma  , i = 1, 2, . . ., n.
      # .         i      i               Z    i       i
      # .
      # ...................................................................................
      Y = dfXSel %*% cSel$avSel;                        # n * K matrix of principal components.
      zY = sweep(Y, 1, az, FUN = "*");                  # n * K matrix. i-th row is z_i * xi_i.

      aBuf1 =  Y %*% cSel$abeta;                        # n vector, direct terms beta * y.
      aBuf2 =  zY %*% cSel$agamma;                      # n vector, interaction terms gamma * z * y.

      aloghR = aBuf1 + cSel$betaZ * az + aBuf2;         # n vector, log-hazard ratios.
      ahR = exp(aloghR);                                # n vector of hazard ratios exp(beta * y).
      # ...................................................................................
      

      # ...................................................................................
      # . Sort arrays so that samples are ordered with increasing event time :
      # ...................................................................................
      sBuf = sort(at, decreasing = FALSE, index.return = TRUE);    # Sort in increasing order.

      indexSort = sBuf[["ix"]];      # Sort index, used below in sorting the arrays.

      atSort = sBuf[["x"]];          # Sorted array of event times (i.e. sorted array at).
      asSort = as[indexSort];        # Sorted array of indicators (1 = death, 0 = censored) (i.e. deltas).
      ahRSort = ahR[indexSort];      # Sorted array of exp(beta * y).
      # ...................................................................................

      
      
      # ........................................................................................
      # . Build the occupation number array, YO, then use it to generate the denominator terms.
      # .
      # .                        ---------------------
      # .                        1   0   0   0   0   0
      # .    exp(beta * z)       1   1   0   0   0   0
      # .   -------------        1   1   1   0   0   0
      # .   |. . . . . . |  *    1   1   1   1   0   0  = n-array of denominator terms.
      # .   -------------        1   1   1   1   1   0 
      # .                        1   1   1   1   1   1 
      # .                        ---------------------
      # .
      # .      1 * n                    n * n                   1 * n
      # .
      # . Note that the numerators are just the status indicators (1 = death, 0 = censored).      
      # ........................................................................................
      YO = sapply(1:n, function(j){a = rep(0, times = n); a[j:n]= 1; return(a)});
      aBot = ahRSort %*% YO;                 # Denominators for contribution at event time atSort.
                                     
      aLambdaBaseDiff = asSort / aBot;       # Differential hazard estimate, for times atSort.
      aLambdaBase = cumsum(aLambdaBaseDiff); # Cumulative hazard function, for times atSort.
      aSBase = exp(-aLambdaBase);            # Estimate of baseline survival function, for times atSort.
      # ........................................................................................

      
      # ........................................................................................
      # . Compute the median survival time under baseline :
      # ........................................................................................
      abufL = which(aSBase >= 0.5);
      abufR = which(aSBase < 0.5);

      if (length(abufL) > 0) {
        iL = max(abufL);
      } else {
        iL = 1;
      }
      
      if (length(abufR) > 0) {
        iR = min(abufR);
      } else {
        iR = n;
      }

      tBaseMed = 0.5 * (atSort[iL] + atSort[iR]);    # Interpolation.
      # ........................................................................................            


      # ...................................................................................
      # . Compute the Martingale residuals for the training set :
      # .
      # .    M  =  delta   - exp(beta * Z ) * Lambda0(x )
      # .     i         i                i             i
      # ...................................................................................
      aMSort = asSort - ahRSort * aLambdaBase;     # Martingale residuals in sorted order.
      aM = rep(0.0, times = n);                    # Dummy initial values.
      aM[indexSort] = aMSort;                      # Martingale residuals in original order.
      # ...................................................................................            

      
      # ...............................................................................
      # . Package the results for the baseline hazard functions :
      # ...............................................................................
      bh = list(n = n,                                   # Number of time points.
                atSort = atSort,                         # Array of (sorted) time points.
                aLambdaBaseDiff = aLambdaBaseDiff,       # Differential baseline hazard function.
                aLambdaBase = aLambdaBase,               # Baseline hazard function.
                aSBase = aSBase,                         # Baseline survival function.
                tBaseMed = tBaseMed,                     # Median survival time under baseline.
                aMSort = aMSort,                         # Martingale residuals in sorted order.
                aM = aM);                                # Martingale residuals in original order.
      
      class(bh) = 'spc.baseline.hazard';
      # ...............................................................................

      
      # ............
      return (bh);
      # ............
      
}

# =================================================================================================
# . End of SuperPc.computeBaselineHazardNoTiesWithCov.
# =================================================================================================      



# =================================================================================================
# . SuperPc.projectToFullWithCov : projects the principal component vectors in feature-selected space back 
# . ----------------------------   to the full p-dimensional space.
# .                             
# .   Syntax:
# .
# .      fullPc = SuperPc.projectToFullWithCov(p, avSel, avSelTot, avSelIntTot, indexSel);
# .
# .   In:
# .             p = dimensionality of full-dimensional space.
# .
# .         avSel = m * K matrix of the K principal component vectors, each as a separate column.
# .
# .      avSelTot = m-dimensional vector of summed loadings for each gene (= avSel * beta, 
# .                 where beta = vector of Cox coefficients), direct effects.
# .
# .   avSelIntTot = m-dimensional vector of summed loadings for each gene (= avSel * gamma, 
# .                 where beta = vector of Cox coefficients), interaction effects.
# .
# .      indexSel = indices of genes in original index space 1..p, that were retained after
# .                 feature-selection.
# .
# .   Out:
# .
# .      fullPc = list, with members :
# .
# .            av = p * K matrix of the K principal component vectors, each as a separate column.
# .                 Rows for genes which were not among the selected features are all 0.
# .
# .         avTot = p-dimensional vector of summed loadings for each gene (= av * beta, 
# .                 where beta = vector of Cox coeffcients) for the *direct* effects.
# .                 Rows for genes which were not among the selected features are all-0.
# .
# .      avIntTot = p-dimensional vector of summed loadings for each gene (= av * gamma, 
# .                 where beta = vector of Cox coeffcients) for the *interaction* effects.
# .                 Rows for genes which were not among the selected features are all-0.
# .
# =================================================================================================

SuperPc.projectToFullWithCov <- function(p, avSel, avSelTot, avSelIntTot, indexSel)
{

      # ..................................
      m = nrow(avSel);
      K = ncol(avSel);

      stopifnot(length(indexSel) == m);
      stopifnot(m <= p);
      # ..................................      

      
      # .......................................................................................
      # . Project back to original p-dimensional vector space:
      # .......................................................................................
      av = matrix(c(0.0), nrow = p, ncol = K, byrow = TRUE);
      av[indexSel, ] = avSel;              # p * K : pc vectors in p-dimensional space.

      avTot = rep(0.0, times = p);
      avTot[indexSel] = avSelTot;          # Summed gene loadings in p-space, direct effects.

      avIntTot = rep(0.0, times = p);
      avIntTot[indexSel] = avSelIntTot;    # Summed gene loadings in p-space, interaction effects.
      # .......................................................................................


      # ..........................................................
      # . Package results :
      # ..........................................................
      fullPc = list(av = av, avTot = avTot, avIntTot = avIntTot);
      # ..........................................................

}

# =================================================================================================
# . End of SuperPc.projectToFullWithCov.
# =================================================================================================




# =================================================================================================
# . SuperPc.computeCoxPcAndLogHazardWithCov : computes the principal components and log-hazard
# . ---------------------------------------   -ratios for an input data matrix with an arbitrary 
# .                                           set of samples (not necessarily the ones used in
# .                                           the training set).
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .          s = SuperPc.computeCoxPcAndLogHazardWithCov(spc, dfXIn, azIn);
# .
# .   In:
# .        spc = result of supervised principal components computation, returned
# .              by function SuperPc.computeCoxWithCov().
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .       azIn = input vector of covariate values. It must have the same number of rows as dfX.
# .              Samples need not be the same as in the training set.
# .
# .   Out:
# .      s = list with members :
# .
# .              Y = nIn * K matrix of principal components, where
# .                  nIn = number of rows in dfXIn.
# .
# .         aloghR = nIn vector of log-hazard ratios.
# .            ahR = nIn vector of hazard ratios.
# .          atMed = estimated median survival times.
# .
# =================================================================================================

SuperPc.computeCoxPcAndLogHazardWithCov <- function(spc, dfXIn, azIn)
{

      # ...........................................................
      if (class(spc) != "spc.cox.cov") {
        msg = "ERROR: from SuperPc.computeCoxPcAndLogHazardWithCov: ";
        msg = paste(msg, "The input spc is not of class spc.cox.cov");
        stop(msg);
      }
      # ...........................................................      


      # ..............................................................................
      p = ncol(dfXIn);
      n = nrow(dfXIn);
      
      if (spc$p != p) {
        msg = "ERROR: from SuperPc.computeCoxPcAndLogHazardWithCov: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste(msg, "features as in the training data matrix.", sep = "");
        msg = paste(msg, " Test has p = " , p, " genes.", sep = "");
        msg = paste(msg, " Training has spc$p = " , spc$p, " genes.", sep = "");
        stop(msg);
      }

      nz = length(azIn);

      if (nz != n) {
        cat("ERROR: from SuperPc.computeCoxPcAndLogHazardWithCov:\n");
        cat("Input external covariate array az has nz = ", nz, " elements. ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }      
      # ...............................................................................


      
      # ...................................................................................
      # . Compute the principal components and the log-hazard ratios :
      # . center the data using the means computed on the training set,
      # . subset to the genes selected from computation on the training set
      # . compute the principal components, and finally determine the
      # . log-hazard ratios.
      # .
      # ...................................................................................
      # . We first compute the n * K matrix of principal componenst.
      # .
      # .           -                       -
      # .           |xi    xi    . . . xi   |
      # .           |  11    12          1K |
      # .       Y = |                       |
      # .           | . . .      . . .   .  |
      # .           |                       |
      # .           |xi    xi    . . . xi   |
      # .           |  n1    n2          nK |
      # .           -                       -
      # .
      # . where :
      # .               T
      # .     xi    =  v  . x   ,  l = 1, 2, . . ., K
      # .       il      l    i
      # .
      # . where v  is the l-the principal component vector (n components)
      # .        l
      # . and x  the i-th sample vector (n components).
      # .      i
      # .      
      # . We then compute the log-hazard ratios for all the samples, given by :
      # .
      # .                T                            T
      # .   aloghR   = xi  . beta  + beta  . z  + z xi  . gamma  , i = 1, 2, . . ., n.
      # .         i      i               Z    i       i
      # .
      # ...................................................................................
      # . 3-13-2011; J. Theilhaber: special option for nrow = 1.
      # ...................................................................................
      dfXc = sweep(dfXIn, 2, spc$axm);                # Center each column separately.      
      dfXSel = dfXc[ , spc$indexSel];                 # nIn * m data matrix subsetted to the selected genes.

      if (nrow(dfXc) == 1) {
        dfXSel = matrix(dfXSel, nrow = 1);            # Special case for nrow = 1, to preserve matrix geometry.
      }
      
      Y = dfXSel %*% spc$avSel;                        # n * K matrix of principal components.
      colnames(Y) = paste("ypc", 1:spc$K, sep = "");   # Label the pc's.      
      zY = sweep(Y, 1, azIn, FUN = "*");               # n * K matrix. i-th row is z_i * xi_i.

      aBuf1 =  Y %*% spc$abeta;                        # n vector, direct terms beta * y.
      aBuf2 =  zY %*% spc$agamma;                      # n vector, interaction terms gamma * z * y.

      aloghR = aBuf1 + spc$betaZ * azIn + aBuf2;       # n vector, log-hazard ratios.
      ahR = exp(aloghR);                               # n vector of hazard ratios exp(beta * y).
      # ...................................................................................
      # . Compute estimated median survival times :
      # ...................................................................................
      bh = SuperPc.getBaselineHazard(spc);               # Baseline hazard information.
      #xxxx  atMed = bh$tBaseMed * exp(-aloghR);         # Greater hazard -> shorter survival time.
      atMed = SuperPc.computeTMedOnBaseline(bh, aloghR)  # Median survival time estimates.            
      # ...................................................................................


     
      # ..........................................................
      # . Package the results :
      # ..........................................................
      s = list(Y = Y, aloghR = aloghR, ahR = ahR, atMed = atMed);
      # ..........................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of SuperPc.computeCoxPcAndLogHazardWithCov.
# =================================================================================================      





# =================================================================================================
# . SuperPc.computeCoxPcAndLogHazardWithCovAndPred : computes the principal components and log-hazard
# . ----------------------------------------------   -ratios for an input data matrix with an arbitrary 
# .                                               set of samples (not necessarily the ones used in
# .                                               the training set).
# .
# . >>Predictor version : this version generates actual values of the hazard ratio, and in addition
# . also generates predictions for all distinct values of the external covariate Z
# . (up to SuperPc.NZMAX values).
# .
# .   Syntax:
# .
# .          s = SuperPc.computeCoxPcAndLogHazardWithCovAndPred(spc, dfXIn, azIn, hRC);
# .
# .   In:
# .        spc = result of supervised principal components computation, returned
# .              by function SuperPc.computeCoxWithCov().
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .       azIn = input vector of covariate values. It must have the same number of rows as dfX.
# .              Samples need not ne the same as in the training set.
# .
# .
# .       hRC = cutoff on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .
# .   Out:
# .      s = list with members :
# .
# .       flagPred = TRUE, if prediction using the distinct values in azIn are made,
# .                  FALSE otherwise. Prediction is made provided the number of dictinct
# .                  values is no greater than SuperPc.NZMAX.
# .        flagBin = always FALSE if flagPred = FALSE. If TRUE, indicates that in addition
# .                  prediction was made for a binary external covariate ({0, 1}), and
# .                  includes in addition the differential log-hazard-ratio, and a flag
# .                  for samples predicted to be sensitive.
# .             az = copy of array of input values.
# .           azNR = array of distinct values of the external covariate.
# .              Y = nIn * K matrix of principal components, where
# .                  nIn = number of rows in dfXIn.
# .
# .         aloghR = nIn * L vector of log-hazard ratios; L = 1 if flagPred = FALSE
# .                  (no prediction, just estimated log-hazard ratio for training set values);
# .                  L = 1 + nzNR, if flagPred = TRUE, where nzNR = number of disctinct values
# .                  in azIn.
# .            ahR = nIn * L vector of hazard ratios (see above for definition of L).
# .          atMed = nIn * L estimated median survival times (see above for definition of L).
# .          azMin = absent if flagPred = FALSE, present if flagPred = TRUE.
# .                  Value of Z which minimizes estimated risk for that instance.
# .
# =================================================================================================

SuperPc.computeCoxPcAndLogHazardWithCovAndPred <- function(spc, dfXIn, azIn, hRC)
{

      # ..................................................................
      if (class(spc) != "spc.cox.cov") {
        msg = "ERROR: from SuperPc.computeCoxPcAndLogHazardWithCovAndPred: ";
        msg = paste(msg, "The input spc is not of class spc.cox.cov");
        stop(msg);
      }
      # ...................................................................


      # ..............................................................................
      p = ncol(dfXIn);
      n = nrow(dfXIn);
      
      if (spc$p != p) {
        msg = "ERROR: from SuperPc.computeCoxPcAndLogHazardWithCovAndPred: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste(msg, "features as in the training data matrix.", sep = "");
        msg = paste(msg, " Test has p = " , p, " genes.", sep = "");
        msg = paste(msg, " Training has spc$p = " , spc$p, " genes.", sep = "");
        stop(msg);
      }

      nz = length(azIn);

      if (nz != n) {
        cat("ERROR: from SuperPc.computeCoxPcAndLogHazardWithCovAndPred:\n");
        cat("Input external covariate array az has nz = ", nz, " elements. ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }

      stopifnot(hRC >= 0.0);      
      # ...............................................................................



      # ...................................................................................
      # . Preamble : test that there are not too many dictinct external covariate values.
      # . Assemble matrix of covariate values.
      # ...................................................................................
      flagPred = TRUE;          # Provisionally true.      

      azNR = unique(azIn);      # Array of distinct values of the external covariate.
      nzNR = length(azNR);      # Number of dictinct values.
      
      if (nzNR > SuperPc.NZMAX) {
        cat("WARNING : from SuperPc.computeCoxPcAndLogHazardWithCovAndPred:\n");
        cat("There are too many distinct values nzNR of the covariate.\n");
        cat("I found nzNR = ", nzNR, ", but allowed max. is SuperPc.NZMAX = ", SuperPc.NZMAX, "\n", sep = "");
        cat("I will generate hazard ratios only for the input covariate vector.\n");
        flagPred = FALSE;
      }

      if (flagPred) {
        azBuf = matrix(azNR, nrow = n, ncol = nzNR, byrow = TRUE);
        azMat = cbind(azIn, azBuf);
      } else {
        azMat = azIn;        
      }
      # ...................................................................................       



     
      # ...................................................................................
      # . Compute the n * K matrix of principal components :
      # .
      # .           -                       -
      # .           |xi    xi    . . . xi   |
      # .           |  11    12          1K |
      # .       Y = |                       |
      # .           | . . .      . . .   .  |
      # .           |                       |
      # .           |xi    xi    . . . xi   |
      # .           |  n1    n2          nK |
      # .           -                       -
      # .
      # . where :
      # .               T
      # .     xi    =  v  . x   ,  l = 1, 2, . . ., K
      # .       il      l    i
      # .
      # . where v  is the l-the principal component vector (n components)
      # .        l
      # . and x  the i-th sample vector (n components).
      # .      i
      # ...................................................................................
      # . 3-13-2011; J. Theilhaber: special option for nrow = 1.      
      # ...................................................................................
      dfXc = sweep(dfXIn, 2, spc$axm);                # Center each column separately.      
      dfXSel = dfXc[ , spc$indexSel];                 # nIn * m data matrix subsetted to the selected genes.

      if (nrow(dfXc) == 1) {
        dfXSel = matrix(dfXSel, nrow = 1);            # Special case for nrow = 1, to preserve matrix geometry.
      }
      
      Y = dfXSel %*% spc$avSel;                        # n * K matrix of principal components.
      colnames(Y) = paste("ypc", 1:spc$K, sep = "");   # Label the pc's.            
      # ...................................................................................



      # ...................................................................................
      # . Compute the log-hazard ratios for all the samples. These are given by :
      # .
      # .                T                            T
      # .   aloghR   = xi  . beta  + beta  . z  + z xi  . gamma  , i = 1, 2, . . ., n.
      # .         i      i               Z    i       i
      # .
      # ...................................................................................      
      sM = SuperPc.computeCoxLogHazardOnPcForMultipleCov(spc, Y, azMat);
      # ...................................................................................


      # ...................................................................................
      # . In the case of multiple instances of covariate z, for each sample in turn,
      # . find the covariate value that minimizes the risk for that sample :
      # ...................................................................................
      if (flagPred) {
        ajMin = apply(sM$aloghR[ , -1], 1, which.min);                # We are excluding the actyal values from the comparison.
        azMin = sapply(1:n, function(i){azMat[i, 1 + ajMin[i]]});     # This retrieves the value of z for which the risk is minimized.
      }
      # ...................................................................................      
      

      # ...................................................................................
      # . Generate column names for the output matrices :
      # ...................................................................................
      abuf = c("actual");

      if (flagPred) {
        abuf = c(abuf, as.character(azNR));
      }

      colnames(sM$aloghR) = paste("loghR_z", abuf, sep = "");
      colnames(sM$ahR) = paste("hR_z", abuf, sep = "");
      colnames(sM$atMed) = paste("tMed_z", abuf, sep = "");
      # ...................................................................................


      
      # ...................................................................................
      # . For binary external covariates only:
      # . For all samples generate the predicted differential log-hazard-ratios,
      # . DloghR = loghR_z1 - loghRz_0, and flag as sensitive the samples with
      # . DloghR <= log(hRC).
      # ...................................................................................
      flagBin = FALSE;
      
      if (flagPred) {
        msg = Cox.checkBinary(azIn);

        if (msg == 'ok') {
          aDloghRz = sM$aloghR[ ,"loghR_z1"] - sM$aloghR[ ,"loghR_z0"];   # Predicted differential log-hazard-ratio.

          temp1 = log(hRC);                                               # Log-hazard-ratio threshold.
          aflagSensitiveZ = ifelse(aDloghRz <= temp1, 1, 0);              # Flag = 1 defines samples as sensitive.
          flagBin = TRUE;        
        }
      }
      # ...................................................................................      
      

     
      # ......................................................................
      # . Package the results :
      # ......................................................................
      s = list(flagPred = flagPred,
               flagBin = flagBin,        
               az = azIn,
               azNR = azNR,
               Y = Y,
               aloghR = sM$aloghR,
               ahR = sM$ahR,
               atMed = sM$atMed);

      if (flagPred) {
        s = c(s, list(azMin = azMin));
      }

      if (flagBin) {
        s = c(s, list(aDloghRz = aDloghRz, aflagSensitiveZ = aflagSensitiveZ));
      }
      # .......................................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of SuperPc.computeCoxPcAndLogHazardWithCovAndPred.
# =================================================================================================      





# =================================================================================================
# . SuperPc.computeCoxLogHazardOnPcForMultipleCov : computes the log-hazard-ratios given an input
# . ---------------------------------------------   matrix of projections onto the principal
# .                                                 component vectors, and for a series of  external
# .                                                 covariates (not necessarily the ones used in
# .                                                 the training set).
# .
# .   Syntax:
# .
# .          s = SuperPc.computeCoxLogHazardOnPcForMultipleCov(spc, Y, azMat);
# .
# .   In:
# .        spc = result of supervised principal components computation, returned
# .              by function SuperPc.computeCoxWithCov().
# .
# .          Y = n * K input matrix,containing projections onto the K principal component
# .              vectors for an arbitrary set of n samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .      azMat = n * L input matrix of external covariate values.
# .              The values in the matrix are arbitrary, and to be used e.g. for prediction
# .              of response to treatment type.
# .
# .   Out:
# .      s = list with members :
# .
# .              Y = nIn * K matrix of principal components, where
# .                  nIn = number of rows in dfXIn.
# .
# .         aloghR = nIn vector of log-hazard ratios.
# .            ahR = nIn vector of hazard ratios.
# .          atMed = estimated median survival times.
# .
# ................................................................................................
# . >> Note that the matrix Y is given by the n * K matrix of principal components :
# .
# .           -                       -
# .           |xi    xi    . . . xi   |
# .           |  11    12          1K |
# .       Y = |                       |
# .           | . . .      . . .   .  |
# .           |                       |
# .           |xi    xi    . . . xi   |
# .           |  n1    n2          nK |
# .           -                       -
# .
# . where :
# .               T
# .     xi    =  v  . x   ,  l = 1, 2, . . ., K
# .       il      l    i
# .
# . where v  is the l-the principal component vector (n components)
# .        l
# . and x  the i-th sample vector (n components).
# .      i
# . This matrix must be precomputed before calling
# . SuperPc.computeCoxLogHazardOnPcForMultipleCov().
# .
# .
# . >>We then compute here the log-hazard ratios for all the samples, given by :
# .
# .                T                            T
# .   aloghR   = xi  . beta  + beta  . z  + z xi  . gamma  , i = 1, 2, . . ., n.
# .         i      i               Z    i       i
# .
# =================================================================================================

SuperPc.computeCoxLogHazardOnPcForMultipleCov <- function(spc, Y, azMat)
{

      # ...........................................................
      if (class(spc) != "spc.cox.cov") {
        msg = "ERROR: from SuperPc.computeCoxLogHazardOnPcForMultipleCov: ";
        msg = paste(msg, "The input spc is not of class spc.cox.cov");
        stop(msg);
      }
      # ...........................................................      


      # ..............................................................................
      K = ncol(Y);           # Number of principal component projections in Y.
      n = nrow(Y);           # Number of samples in Y.
      
      if (spc$K != K) {
        cat("ERROR: from SuperPc.computeCoxLogHazardOnPcForMultipleCov:\n");
        cat("Input data matrix Y does not have the same number of \n");
        cat("principal components as in the training data matrix.\n");
        cat("Y has K = " , K, " columns.");
        cat("Training had spc$K = " , spc$K, " principal components.");
        stop(msg);
      }

      nz = nrow(azMat);

      if (nz != n) {
        cat("ERROR: from SuperPc.computeCoxLogHazardOnPcForMultipleCov:\n");
        cat("Input external covariate array az has nz = ", nz, " rows. ",
            "not same as input matrix Y with n = ", n, " rows.\n", sep = "");
        stop();
      }      
      # ...............................................................................


      
      # ...................................................................................
      # . Compute the log-hazard ratios.
      # . For the i-th sample, with projection xi_i onto the K principal components,
      # . and for an input value z_i for the external covariate, the log-hazard ratio
      # . is given by :
      # .
      # .                T                             T
      # .   aloghR   = xi  . beta  + beta  . z  + z  xi  . gamma  , 
      # .         i      i               Z    i    i   i
      # .
      # .              ----------    ----------   --------------
      # .              gene          treatment    interaction
      # .              expression    effects      effects
      # .              effects
      # .
      # . which we compute for i = 1, 2, . . ., n.
      # .
      # ...................................................................................
      L = ncol(azMat);                             # Number of columns in azMat.
      
      aBuf1 =  Y %*% spc$abeta;                    # n-vector : gene expression effects.
      aBufM1 = matrix(aBuf1, nrow = n, ncol = L);  # Spread to the L columns --> n * L matrix.
      
      aBufM2 = spc$betaZ * azMat;                  # n * L matrix, treatment effects.
      
      aBuf3 =  Y %*% spc$agamma;                   # n-vector : interaction effects.
      aBufM3 = sapply(1:L, function(j){a = azMat[ ,j] * aBuf3; return(a);});

      aloghR = aBufM1 + aBufM2 + aBufM3;           # n * L matrix, log-hazard ratios.
      ahR = exp(aloghR);                           # n * L matrix, hazard ratios.

      bh = SuperPc.getBaselineHazard(spc);               # Baseline hazard information.
      atMed = SuperPc.computeTMedOnBaseline(bh, aloghR)  # Median survival time extimates.      
      # ...................................................................................


     
      # ..........................................................
      # . Package the results :
      # ..........................................................
      s = list(aloghR = aloghR, ahR = ahR, atMed = atMed);
      # ..........................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of SuperPc.computeCoxLogHazardOnPcForMultipleCov.
# =================================================================================================      




# =================================================================================================
# . SuperPc.computeTMedOnBaseline : estimates median survival times given the baseline hazard
# . -----------------------------   functions, and a matrix of log-hazard ratios.
# .
# . Syntax:
# .
# .    atMed = SuperPc.computeTMedOnBaseline(bh, aloghR);
# .
# . In:
# .
# .   bh = baseline hazard object. Computed by : SuperPc.computeBaselineHazardNoTies()
# .        and can be fetched once computed with: bh = SuperPc.getBaselineHazard(spc)
# .
# .   aloghR = n * L matrix of log-hazard ratios.
# .
# .
# . Out:
# .
# .   atMed = n * L array of estimated median survival times.
# .................................................................................................
# . Details :
# .
# . * Under the Cox model, the survival function is given by :
# .
# .                              T
# .        S(t) = exp( - exp(beta * z) Lambda  (t) )
# .                                          0
# .
# . where beta = vector of regression coefficients (Cox coefficients), z = general set of
# . covariates and Lambda_0(t) = baseline cumulative hazard function.
# .
# . The input array aloghR corresponds to the values of the log-hazard ratio function :
# .
# .                         T
# .            aloghR = beta  * z
# .
# . for n samples across L columns.
# .
# . The median survival time for a given log-hazard ratio is determined by solving for:
# .
# .                                                T
# .           Lambda  (t    ) = log(2) * exp(- beta  * z) = log(2) * exp(- aloghR)
# .                 0   Med
# .
# =================================================================================================

SuperPc.computeTMedOnBaseline <- function(bh, aloghR)
{

      # .....................................................................................
      # . Get the baseline attributes :
      # .....................................................................................  
      atSort = bh$atSort;              # Array of time points sorted in increasing order.
      aLambdaBase = bh$aLambdaBase;    # Corresponding baseline cumulative hazard function.

      n = nrow(aloghR);
      atMed = sapply(1:n,
                     function(i){SuperPc.computeTMedForOneRow(aLambdaBase, atSort, aloghR[i,])});

      L = ncol(aloghR);
      
      if (L > 1) {
        atMed = t(atMed);                # Transpose to make this an n * L matrix whene L > 1.
      }        
      # ......................................................................................


      # ..............
      return (atMed);
      # ..............      
  
}

# =================================================================================================
# . End of SuperPc.computeTMedUsingBaseline.
# =================================================================================================



# =================================================================================================
# . SuperPc.computeTMedForOneRow : computes the estimated median survival times, given the baseline
# . ----------------------------   cumulative hazard function, and a single vector of log-hazard 
# .                                ratios.
# .
# . Syntax:
# .
# .   atMedRow = SuperPc.computeTMedForOneRow(aLambdaBase, atSort, aloghRRow);
# .
# . In:
# .
# .   aLambdaBase = nc : baseline cumulative hazard function.
# .        atSort = nc : corresponding time points, sorted in increasing order.
# .      aloghRRow = L : a vector of log-hazard ratio values.
# .
# . Out:
# .
# .      atMedRow = L : the L median survival times, corresponding to the L input
# .                     log-hazard ratios.
# .
# =================================================================================================

SuperPc.computeTMedForOneRow <- function(aLambdaBase, atSort, aloghRRow)
{

       # ................................................
       # . Get basic array attributes :
       # ................................................
       nc = length(aLambdaBase);
       L = length(aloghRRow);
       # ................................................

       
       # .......................................................................................
       # . Replicate baseline cumulative hazard function :
       # .......................................................................................
       aLambdaBaseRep = matrix(aLambdaBase, ncol = nc, nrow = L, byrow = TRUE);  # L * nc matrix. 
       # ........................................................................................
       # . Use input hazard ratios to adjust for value at median of baseline
       # . hazard cumulative function:
       # ........................................................................................
       abufQ = log(2.0) * exp(- aloghRRow);                        # Array of length L.
       # ........................................................................................
       # . Sweep out values for median, then generate L vectors of lower and upper indices :
       # ........................................................................................       
       dLambda = sweep(aLambdaBaseRep, 1, abufQ, FUN = "-");          # L * nc matrix. 

       abufL = sapply(1:L, function(i){aIndex = which(dLambda[i,] < 0.0);
                                       ifelse(length(aIndex) > 0, max(aIndex), 1)});
       abufR = sapply(1:L, function(i){aIndex = which(dLambda[i,] >= 0.0);
                                       ifelse(length(aIndex) > 0, min(aIndex), nc)});       
       # .......................................................................................
       # . Gather the corresponding times :
       # .......................................................................................
       atMedL = atSort[abufL];
       atMedR = atSort[abufR];       
       atMedRow = 0.5 * (atMedL + atMedR);        # Interpolation.
       # ........................................................................................

       
       # ..................
       return (atMedRow);
       # ..................

}
       
# =================================================================================================
# . End of SuperPc.computeTMedForOneRow.
# =================================================================================================






# =================================================================================================
# . SuperPc.packageSpcCoxWithCov : creates an spc.cox.cov object from the explicit inputs. Used in packaging
# . ----------------------------   together partial results in the context of a cross-validation loop.
# .                             
# .   Syntax:
# .
# .      spc = SuperPc.packageSpcCoxWithCov();
# .
# .   In:
# .
# .      methodFs =    Feature selection method.                        
# .          mtop =    Number of genes for feature selection.           
# .            p0 =    P-value threshold for feature selection.         
# .           n   =    Number of samples.                               
# .           p   =    Number of genes.                                 
# .           axm =    p : column means (gene-by-gene means).           
# .      indexSel =    Index of selected genes.
# .          agFs =    Names of selected genes.
# .             m =    Number of selected genes.                        
# .       pvalMin =    Smallest univariate p-value selected.            
# .       pvalMax =    Largest univariate p-value selected.             
# .             K =    Number of pc's used in final Cox model.
# .         abeta =    K : the Cox coefficients.
# .       aseBeta =    K : standard errors for the Cox coefficients.
# .        apBeta =    K : P-values for the Cox coefficients.
# .         betaZ =    External covariate Cox coeff.
# .       seBetaZ =    External covariate coeff std. err.
# .        pBetaZ =    External covariate coeff std. err.        
# .        agamma =    K : the interaction terms.
# .      aseGamma =    K : standard errors for interaction terms.
# .       apGamma =    K : P-values for interaction terms.    
# .            ap =    K : the P-values for the Cox coefficents.            
# .            qR =    Loglikelihood ratio statistic (df = K).          
# .            pR =    P-value for loglikelihood ratio statistic.
# .         avSel =    m * K : pc vectors in m-gene expression space.         
# .            av =    p * K : pc vectors full p-gene expression space.
# .      avSelTot =    Summed gene loadings in m-gene expression space.    
# .         avTot =    Summed gene loadings in p-gene expression space. 
# .            sv =    Pass the results of the internal SVD.
# .          coxK =    Final Cox model on K principal components.
# .            bh =    Baseline hazard object.
# .
# .   Out:
# .
# .          spc = object of class spc.cox.cov
# .
# =================================================================================================

SuperPc.packageSpcCoxWithCov <- function(methodFs, mtop, p0,
                                         n, p, axm, indexSel, agFs, m,
                                         pvalMin, pvalMax,
                                         K,
                                         abeta, aseBeta, apBeta,
                                         betaZ, seBetaZ, pBetaZ,
                                         agamma, aseGamma, apGamma,
                                         qR, pR, avSel,
                                         av, avSelTot, avTot,
                                         sv, coxK, bh)
{

      # .......................................................................................
      # . Package the inputs :
      # .......................................................................................
      msg = 'ok';
      
      spc = list(msg = msg,                   # Output message.
                 type = 'coxph',              # Type of spc calculation.
                 methodFs = methodFs,         # Feature selection method.                        
                 mtop = mtop,                 # Number of genes for feature selection.           
                 p0 = p0,                     # P-value threshold for feature selection.         
                 n   = n,                     # Number of samples.                               
                 p   = p,                     # Number of genes.                                 
                 axm = axm,                   # p : column means (gene-by-gene means).           
                 indexSel = indexSel,         # Index of selected genes.
                 agFs = agFs,                 # Names of selected genes.
                 m = m,                       # Number of selected genes.                        
                 pvalMin = pvalMin,           # Smallest univariate p-value selected.            
                 pvalMax = pvalMax,           # Largest univariate p-value selected.             
                 K = K,                       # Number of pc's used in final Cox model.          
                 abeta = abeta,               # K : the Cox coefficients.
                 aseBeta = aseBeta,           # K : standard errors for the Cox coefficients.
                 apBeta= apBeta,              # K : P-values for the Cox coefficients.
                 betaZ = betaZ,               # External covariate Cox coeff.
                 seBetaZ = seBetaZ,           # External covariate coeff std. err.
                 pBetaZ = pBetaZ,             # External covariate coeff std. err.        
                 agamma = agamma,             # K : the interaction terms.
                 aseGamma = aseGamma,         # K : standard errors for interaction terms.
                 apGamma = apGamma,           # K : P-values for interaction terms.            
                 qR = qR,                     # Loglikelihood ratio statistic (df = K).          
                 pR = pR,                     # P-value for loglikelihood ratio statistic.
                 avSel = avSel,               # m * K : pc vectors in m-gene expression space.         
                 av = av,                     # p * K : pc vectors full p-gene expression space.
                 avSelTot = avSelTot,         # Summed gene loadings in m-gene expression space.    
                 avTot = avTot,               # Summed gene loadings in p-gene expression space. 
                 sv = sv,                     # Pass the results of the internal SVD.
                 coxK = coxK,                 # Final Cox model on K principal components.
                 bh = bh );                   # Baseline hazard object.
      
      class(spc) = 'spc.cox.cov';
      # .......................................................................................

      
      # .............
      return (spc);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.packageSpcCoxWithCov.
# =================================================================================================








# =========================================================================================================
# . SuperPc.computeCoxSignificanceOnSplit : given a Cox regression model, and an input set of survival 
# . -------------------------------------   data and gene expression data (not necessarily the same
# .                                         that was used in training for the model), computes a
# .                                         statistical significance for the resulting model.
# .
# .   Syntax:
# .
# .       cs = SuperPc.computeCoxSignificanceOnSplit(at, as, dfX, spc);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .           spc = result of supervised principal components computation, returned
# .                 by function SuperPc.computeCox(). This was computed on a data matrix
# .                 and survival data that may be different from at, as and dfX provided here
# .                 (test set). However, the number of features (ncol(dfX)) in each must be the same
# .                 in training and test gene expression data matrices.
# .
# .   Out:
# .          cs = list with members :
# .
# .                 n = number of samples.
# .                 p = number of genes.
# .                pR = P-value that obtains from Cox analysis on the two groups (high risk
# .                     and low risk) that result from splitting on the median of the predicted
# .                     log-hazard-ratios.
# .
# .                hR = the hazard ratio between high-risk and low-risk groups.
# .              hRLo = lower confidence limit for hR (-one std dev in log-harzard-ratio).
# .              hRHi = upper confidence limit for hR (+one std dev in log-harzard-ratio).
# .
# ..........................................................................................................
# . * Details :
# .
# .       Computation of the statistical significance is based on :
# .
# .         i. Computing predicted log-hazard-ratio for each sample in the test set,
# .            based on the input gene expression data, and the pre-computed model
# .            parameters.
# .
# .        ii. Splitting the samples into two groups, based on whether or not their predicted
# .            log-hazard-ratio is greater than (high risk) or less than (low risk) the median
# .            of the predicted log-hazard-ratios.
# .
# .       iii. Performing a Cox regression analysis, using the two risk groups and the input
# .            test survival data. The p-value is from the score test (which obtains the same
# .            value as the logrank test).
# .
# ==========================================================================================================

SuperPc.computeCoxSignificanceOnSplit <- function(at, as, dfX, spc)
{

      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      if (class(spc) != "spc.cox") {
        msg = "ERROR: from SuperPc.computeCoxSignificanceOnSplit: ";
        msg = paste("The input spc is not of class spc.cox.\n");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.

      if (nt != n) {
        msg = "ERROR: from SuperPc.computeCoxSignificanceOnSplit: ";
        msg = paste(msg, "The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxSignificanceOnSplit: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }
      
      if (spc$p != p) {
        msg = "ERROR: from SuperPc.computeCoxSignificanceOnSplit: ";        
        msg = paste(msg, "The input data matrix does not have the same number of ");
        msg = paste(msg, "genes as in the supervised pc. ");
        msg = paste(msg, "Input has p = " , p, " genes. ");
        msg = paste(msg, "Spc has p = " , spc$p, " genes.");
        stop(msg);
      }
      # ...............................................................................................

      
      
      # ...................................................................................
      # . Compute the principal components and the log-hazard ratios, using the training
      # . set-derived column means and principal component vectors.
      # . This call returns :
      # .          sl$Y = n * K matrix of principal components.
      # .     sl$aloghR = n vector of log-hazard-ratios.
      # .        sl$ahR = n vector of hazard-ratios.      
      # ...................................................................................      
      sl = SuperPc.computeCoxPcAndLogHazard(spc, dfX);
      # ...................................................................................
      


      # ...........................................................................................
      # . Discretize the sample set into high-risk and low-risk groups on the
      # . basis of log-hazard-ratio, with a cut at the median log-hazard-ratio.
      # ...........................................................................................
      aloghRMed = median(sl$aloghR);                           # Select median as cut value.
      aRiskGroup = ifelse(sl$aloghR < aloghRMed, -1, 1);       # Discretize into low and high risk.

#      fitBuf = survfit(Surv(at, as) ~ aRiskGroup);
#      dBuf = survdiff(Surv(at, as) ~ aRiskGroup);              # Logrank test on the discretized data.
#      pLR = pchisq(dBuf$chisq, df = 1, lower.tail = FALSE);    # P-value for logrank test.
      # ...........................................................................................
      # . Directly use a Cox proportional hazard model :
      # ...........................................................................................
      coxK = coxph(Surv(at, as) ~ aRiskGroup);         # Cox model on 1 variable.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);    # Likelihood ratio statistic.
      pR = pchisq(qR, df = 1, lower.tail = FALSE);     # p-value from likelihood ratio.
      
      coxKsum = summary(coxK);
      coxKcoef = coxKsum$coef;                         # Contains the coefficient and P-value.
      
      beta = coxKcoef[ , 1];                           # The Cox coefficient.
      seBeta = coxKcoef[ , 3];                         # Standard error for the coefficient.
      pBeta = coxKcoef[ , 5];                          # The corresponding P-value.
      # .......................................................................................
      # . Compute the hazard ratio between high-risk (+1) and low risk (-1) groups,
      # . and its confidence limits for +/- one std. dev. in the log-hazard-ratio.
      # .......................................................................................
      loghR = 2.0 * beta;
      loghRLo = 2.0 * (beta - seBeta);
      loghRHi = 2.0 * (beta + seBeta);

      hR = exp(loghR);
      hRLo = exp(loghRLo);
      hRHi = exp(loghRHi);      
      # .......................................................................................            

      
      
      # .........................................
      # . Package the results into a list :
      # .........................................
      cs = list(n = n,
                p = p,
                pR = pR,
                hR = hR,
                hRLo = hRLo,
                hRHi = hRHi);

      class(cs) = "spc.cox.significance";
      # .........................................
      
     
      # ...........
      return (cs);
      # ...........

}

# ==========================================================================================================
# . End of SuperPc.computeCoxSignificanceOnSplit.
# ==========================================================================================================






# =========================================================================================================
# . SuperPc.computeCoxSignificanceOnSplitLoghR : given input set of survival data and a corresponding
# . -----------------------------------------    log-hazard-ratio vector, computes a
# .                                              statistical significance for the underlying model
# .                                              using a simple MEDIAN split.
# .
# .   Syntax:
# .
# .       cs = SuperPc.computeCoxSignificanceOnSplitLoghR(at, as, aloghR);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .        aloghR = n : vector of log-hazard-ratios, typically predicted by a Cox model.
# .
# .   Out:
# .          cs = list with members :
# .
# .                 n = number of samples.
# .                pR = P-value that obtains from Cox analysis on the two groups (high risk
# .                     and low risk) that result from splitting on the median of the predicted
# .                     log-hazard-ratios.
# .
# .                hR = the hazard ratio between high-risk and low-risk groups.
# .              hRLo = lower confidence limit for hR (-one std dev in log-harzard-ratio).
# .              hRHi = upper confidence limit for hR (+one std dev in log-harzard-ratio).
# .
# ..........................................................................................................
# . * Details :
# .
# .       Computation of the statistical significance is based on :
# .
# .         i. Splitting the samples into two groups, based on whether or not their
# .            log-hazard-ratio is greater than (high risk) or less than (low risk) the median
# .            of the predicted log-hazard-ratios.
# .
# .       iii. Performing a Cox regression analysis, using the two risk groups and the input
# .            test survival data. The p-value is from the score test (which obtains the same
# .            value as the logrank test).
# .
# ==========================================================================================================

SuperPc.computeCoxSignificanceOnSplitLoghR <- function(at, as, aloghR)
{

      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nl = length(aloghR);  # Number of samples in log-hazard-ratio vector.

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxSignificanceOnSplitLoghR: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl != n) {
        msg = "ERROR: from SuperPc.computeCoxSignificanceOnSplitLoghR: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR has nl = ", nl, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      # ...............................................................................................

      


      # ...........................................................................................
      # . Discretize the sample set into high-risk and low-risk groups on the
      # . basis of log-hazard-ratio, with a cut at the median log-hazard-ratio.
      # ...........................................................................................
      aloghRMed = median(aloghR);                               # Select median as cut value.
      aRiskGroup = ifelse(aloghR < aloghRMed, -1, 1);           # Discretize into low and high risk.
      # ...........................................................................................
      # . Directly use a Cox proportional hazard model :
      # ...........................................................................................
      coxK = coxph(Surv(at, as) ~ aRiskGroup);         # Cox model on 1 variable.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);    # Likelihood ratio statistic.
      pR = pchisq(qR, df = 1, lower.tail = FALSE);     # p-value from likelihood ratio.
      
      coxKsum = summary(coxK);
      coxKcoef = coxKsum$coef;                         # Contains the coefficient and P-value.
      
      beta = coxKcoef[ , 1];                           # The Cox coefficient.
      seBeta = coxKcoef[ , 3];                         # Standard error for the coefficient.
      pBeta = coxKcoef[ , 5];                          # The corresponding P-value.
      # .......................................................................................
      # . Compute the hazard ratio between high-risk (+1) and low risk (-1) groups,
      # . and its confidence limits for +/- one std. dev. in the log-hazard-ratio.
      # .......................................................................................
      loghR = 2.0 * beta;
      loghRLo = 2.0 * (beta - seBeta);
      loghRHi = 2.0 * (beta + seBeta);

      hR = exp(loghR);
      hRLo = exp(loghRLo);
      hRHi = exp(loghRHi);      
      # .......................................................................................            

      
      
      # .........................................
      # . Package the results into a list :
      # .........................................
      cs = list(n = n,
                pR = pR,
                hR = hR,
                hRLo = hRLo,
                hRHi = hRHi);

      class(cs) = "spc.cox.significance";
      # .........................................
      
     
      # ...........
      return (cs);
      # ...........

}

# ==========================================================================================================
# . End of SuperPc.computeCoxSignificanceOnSplitLoghR.
# ==========================================================================================================




# =========================================================================================================
# . SuperPc.computeCoxSignificanceOnSplitLoghRQUANT : given input set of survival data and a corresponding
# . -----------------------------------------------   log-hazard-ratio vector, computes a
# .                                                   statistical significance for the underlying model
# .                                                   using a simple quantile split (compare lowest and highest
# .                                                   quantiles).
# .   Syntax:
# .
# .       cs = SuperPc.computeCoxSignificanceOnSplitLoghRQUANT(at, as, aloghR, nq);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .        aloghR = n : vector of log-hazard-ratios, typically predicted by a Cox model.
# .
# .       nq = number of quantile groups to be used : if nq = 2, split at median,
# .            if nq = 3, split at tertiles, etc. Usually we will use nq = 3.
# .            Note that we must have nq > 1.
# .
# .   Out:
# .          cs = list with members :
# .
# .                 n = number of samples.
# .                pR = P-value that obtains from Cox analysis on the two groups (high risk
# .                     and low risk) that result from splitting on the quantiles of the predicted
# .                     log-hazard-ratios.
# .
# .                hR = the hazard ratio between high-risk and low-risk groups.
# .              hRLo = lower confidence limit for hR (-one std dev in log-harzard-ratio).
# .              hRHi = upper confidence limit for hR (+one std dev in log-harzard-ratio).
# .
# ..........................................................................................................
# . * Details :
# .
# .       Computation of the statistical significance is based on :
# .
# .         i. Splitting the samples into two groups, based on whether or not their
# .            log-hazard-ratio is in the highest quantile (high risk) or in the lowest quantile
# .            (low risk) of the predicted log-hazard-ratios.
# .
# .       iii. Performing a Cox regression analysis, using the two risk groups and the input
# .            test survival data. The p-value is from the score test (which obtains the same
# .            value as the logrank test).
# .
# ==========================================================================================================

SuperPc.computeCoxSignificanceOnSplitLoghRQUANT <- function(at, as, aloghR, nq = 3)
{

      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nl = length(aloghR);  # Number of samples in log-hazard-ratio vector.

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxSignificanceOnSplitLoghRQUANT: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl != n) {
        msg = "ERROR: from SuperPc.computeCoxSignificanceOnSplitLoghRQUANT: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR has nl = ", nl, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nq <= 1) {
        cat("ERROR: from SuperPc.computeCoxSignificanceOnSplitLoghRQUANT:\n");        
        cat("nq = ", nq, " is not valid. Valid: nq > 1 ", sep = "");
        stop();
      }              
      # ...............................................................................................

      


      # ...........................................................................................
      # . Discretize the sample set into high-risk and low-risk groups :
      # . Split on designated quantiles the  predicted log-hazard-ratio.
      # , Note that I've included a rather arbitrary way of dealing with ties.
      # ........................................................................................
      indexBuf = order(aloghR);

      arank = 1:n;                                # Initialize.
      arank[order(aloghR)] = 1:n;                 # Ranks, with arbitrary breaking of ties.
      aloghR = aloghR + 1.0e-9 * arank;           # Breaks ties (numerical factor is pretty arbitrary).
      
      if (nq == 2) {
        loghRMed = median(aloghR);                         # Select median as threshold value.
        aRiskGroup = ifelse(aloghR < loghRMed, -1, 1);     # Discretize into low and high-risk
      } else {
        nq1 = nq - 1;
        aq = (1:nq1) / nq;                                         # Quantiles.
        aqVal = quantile(aloghR, probs = aq);                      # Quantile values.
        min1 = min(aloghR) - 1.0;                                  # Min - 1.
        max1 = max(aloghR) + 1.0;                                  # Max = 1.
        abreak = c(min1, aqVal, max1);                             # This will define nq groups.
        alab = 1:nq;                                               # Labels for the groups.
        aRiskGroup = cut(aloghR, breaks = abreak, labels = alab);  # Assign the labels to all samples.
      }
      # ........................................................................................
      # . Reduce to extreme quantiles :
      # ........................................................................................
      if (nq == 2) {
        atBuf = at;
        asBuf = as;
        aRiskGroupBuf = aRiskGroup;
      } else {
        atBuf = at[(aRiskGroup == 1) | (aRiskGroup == nq)];
        asBuf = as[(aRiskGroup == 1) | (aRiskGroup == nq)];
        aRiskGroupBuf = aRiskGroup[(aRiskGroup == 1) | (aRiskGroup == nq)];
        aRiskGroupBuf = as.numeric(aRiskGroupBuf);
      }      
      # ...........................................................................................
      # . Directly use a Cox proportional hazard model :
      # ...........................................................................................
      coxK = coxph(Surv(atBuf, asBuf) ~ aRiskGroupBuf);         # Cox model on 1 variable.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);    # Likelihood ratio statistic.
      pR = pchisq(qR, df = 1, lower.tail = FALSE);     # p-value from likelihood ratio.
      
      coxKsum = summary(coxK);
      coxKcoef = coxKsum$coef;                         # Contains the coefficient and P-value.
      
      beta = coxKcoef[ , 1];                           # The Cox coefficient.
      seBeta = coxKcoef[ , 3];                         # Standard error for the coefficient.
      pBeta = coxKcoef[ , 5];                          # The corresponding P-value.
      # .......................................................................................
      # . Compute the hazard ratio between high-risk (+1) and low risk (-1) groups,
      # . and its confidence limits for +/- one std. dev. in the log-hazard-ratio.
      # .......................................................................................
      loghR = 2.0 * beta;
      loghRLo = 2.0 * (beta - seBeta);
      loghRHi = 2.0 * (beta + seBeta);

      hR = exp(loghR);
      hRLo = exp(loghRLo);
      hRHi = exp(loghRHi);      
      # .......................................................................................            

      
      
      # .........................................
      # . Package the results into a list :
      # .........................................
      cs = list(n = n,
                nq = nq,
                pR = pR,
                hR = hR,
                hRLo = hRLo,
                hRHi = hRHi);

      class(cs) = "spc.cox.significance";
      # .........................................
      
     
      # ...........
      return (cs);
      # ...........

}

# ==========================================================================================================
# . End of SuperPc.computeCoxSignificanceOnSplitLoghRQUANT.
# ==========================================================================================================







# =========================================================================================================
# . SuperPc.computeCoxWithCovSignificanceOnSplit : given input set of survival data and a corresponding
# . --------------------------------------------   log-hazard-ratio vectors, computes a
# .                                                statistical significance for the underlying model.
# .
# . This version establishes the threshold hRC defining the sensitive subset internally, via otpimization.
# . See SuperPc.computeCoxWithCovSignificanceOnSplitEXT() for using an externally
# . defined threshold hRCExt to define the sensitive subset.
# .
# .........................................................................................................
# .
# . >>Note : this is taylored for two-arm studies, with values of the external covariate z = 0, 1.
# .
# .   Syntax:
# .
# .       cCov = SuperPc.computeCoxWithCovSignificanceOnSplit(at, as, az,
# .                                                           aloghR,
# .                                                           aloghR0,
# .                                                           aloghR1,
# .                                                           flagComputeRES);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .            az = n : vector of external covariates. Values of z must be binary,
# .                     z in {0, 1}. An internal check is performed and an exception
# .                     occurs if there are non-binary values.
# .
# .        aloghR = n : vector of log-hazard-ratios, as predicted by the Cox model
# .                     for the *actual* values of the external covariate.
# .       aloghR0 = n : vector of log-hazard-ratios, as predicted by the Cox model
# .                     for the all values of the external covariate set to z = 0
# .                     (log-hazard-ratios predicted for baseline treatment).
# .       aloghR1 = n : vector of log-hazard-ratios, as predicted by the Cox model
# .                     for the all values of the external covariate set to z = 1
# .                     (log-hazard-ratios predicted for new treatment).
# .
# .    flagComputeRES : flag for whether to compute the inter-treatment arm for the *resistant*
# .                     subset as well as for the sensitive subset.               
# .
# .   Out:
# .          cCov = list with members :
# .
# .                 See final packaging before return statement below for
# .                 description of members.
# .
# ..........................................................................................................
# . * Details :
# .
# .       Computation of the statistical significance is based on :
# .
# .         i. Splitting the samples into two groups, based on whether or not their
# .            log-hazard-ratio is greater than (high risk) or less than (low risk) the median
# .            of the predicted log-hazard-ratios.
# .
# .       iii. Performing a Cox regression analysis, using the two risk groups and the input
# .            test survival data. The p-value is from the score test (which obtains the same
# .            value as the logrank test).
# .
# ==========================================================================================================

SuperPc.computeCoxWithCovSignificanceOnSplit <- function(at, as, az, aloghR, aloghR0, aloghR1,
                                                         flagComputeRES)
{

      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nz = length(az);      # Number of samples in external covariate vector.
      
      nl = length(aloghR);  # Number of samples in log-hazard-ratio vector.
      nl0 = length(aloghR0);  # Number of samples in log-hazard-ratio vector for z = 0.
      nl1 = length(aloghR1);  # Number of samples in log-hazard-ratio vector for z = 1.

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      
      if (nl != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR has nl = ", nl, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl0 != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR0 has nl0 = ", nl0, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl1 != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR1 has nl1 = ", nl1, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      stopifnot(is.logical(flagComputeRES));      
      # ...............................................................................................


      
      # ...............................................................................................
      # . Checks on input parameters :
      # ...............................................................................................      
      msg = Cox.checkBinary(az);

      if (msg != 'ok') {
        cat("ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit:\n");
        cat(msg, "\n", sep = "");
        stop();
      }
      # ...............................................................................................
      

      
      # ...........................................................................................
      # . >> GENE EXPRESSION EFFECTS :
      # . For each treatment arm separately, ask whether the predicted log-hazard ratios
      # . correlate with the survival times.
      # .
      # . 1. Baseline: z= 0.
      # ...........................................................................................
      at0 = at[az == 0];
      as0 = as[az == 0];      
      aloghR_buf0 = aloghR[az == 0];        # The actual values for z = 0.

      n0 = length(at0);

      if (n0 < 2) {
        cat("ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit:\n");
        cat("Less than 2 elements for z = 0 arrays.\n");
        stop();
      }
      
      #xxxx cs0 = Cox.computeCoxOnSplitLoghR(at0, as0, aloghR_buf0);   # J. Theilhaber.
      cs0 = SuperPc.computeCoxSignificanceOnSplitLoghRQUANT(at0, as0, aloghR_buf0, nq = 3);      
      # ...........................................................................................
      # . 2. Alternate treatment: z= 1.
      # ...........................................................................................
      at1 = at[az == 1];
      as1 = as[az == 1];      
      aloghR_buf1 = aloghR[az == 1];        # The actual values for z = 1.

      n1 = length(at1);

      if (n1 < 2) {
        cat("ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit:\n");
        cat("Less than 2 elements for z = 1 arrays.\n");
        stop();
      }
      
      #xxxx cs1 = Cox.computeCoxOnSplitLoghR(at1, as1, aloghR_buf1);  # J. Theilhaber.
      cs1 = SuperPc.computeCoxSignificanceOnSplitLoghRQUANT(at1, as1, aloghR_buf1, nq = 3);
      # ...........................................................................................      


      # ...........................................................................................
      # . >> TREATMENT * GENE-EXPRESSSION EFFECTS :
      # .
      # . Difference in predicted log-hazard for treated versus untreated patients:
      # . DloghR = predicted relative log-hazard = loghR1 - loghR0.
      # . When aDloghR < 0, the treated patients are predicted to do better than the
      # . untreated patients.
      # ...........................................................................................
      aDloghR = aloghR1 - aloghR0;
      # ...................................................................................
      # . Sort the arrays so that samples are ordered with increasing relative log-hazard :
      # ...................................................................................
      sBuf = sort(aDloghR,
                  decreasing = FALSE,
                  index.return = TRUE);    # Sort in increasing order.

      indexSort = sBuf[["ix"]];      # Sort index, used below in sorting the arrays.

      aDloghRSort = sBuf[["x"]];     # Sorted array of relative log-hazards.
      atSort = at[indexSort];        # Sorted array of indicators (1 = death, 0 = censored) (i.e. deltas).      
      asSort = as[indexSort];        # Sorted array of indicators (1 = death, 0 = censored) (i.e. deltas).
      azSort = az[indexSort];        # Sorted array of indicators (1 = death, 0 = censored) (i.e. deltas).      
      # ...................................................................................
      # . Walk through the sorted list, left-to-right, computing significance of difference
      # . of survival in the treatment arms as a function of predicted relative log-hazard.
      # . At the extreme right boundary, *all* samples are included and we are computing
      # . the overall treament effect.
      # . 
      # . Below: abufR is a 5 * n matrix, with in each row :
      # .
      # .   nc = array of total number of samples used in test.
      # .   pR = array of P-value from comparing z = 0 to z = 1 samples with i <= ic,
      # .        where ic = array index.
      # .   hR = array of hazard ratios; hR = lambda(z = 1) / lambda(z = 0).
      # . hRLo = array of lower confidence limits for hazard ratios [exp(loghR - se)].
      # . hRHi = array of upper confidence limits for hazard ratios [exp(loghR + se)].
      # .
      # .......................................................................................      
      abufR = sapply(1:n, function(ic){Cox.computeBinaryCoxOnThreshold(atSort,
                                                                       asSort,
                                                                       azSort,
                                                                       ic,
                                                                       keep.below = TRUE);});
      # ...................................................................................
      # . Also compute the hazard ratio and P-value profile for the "resistant" subset, if 
      # . it was required. Note that this calculation is optional and can be turned off
      # . for speed of computation in the main optimization loops, which depend
      # . only on the hazard ratio and P-value for the *sensitive* population.
      # ...................................................................................
      if (flagComputeRES) {
        abufRRES = sapply(1:n, function(ic){Cox.computeBinaryCoxOnThreshold(atSort,
                          asSort,
                          azSort,
                          ic,
                          keep.below = FALSE);});
      }      
      # ...................................................................................



      
      # ...................................................................................
      # . Cox analysis of all patients.
      # . This is already contained in abufR[ ,n], but we are reproducing the calculation
      # . for logical convenience :
      # ...................................................................................
      csAll = Cox.computeBinaryCoxOnThreshold(atSort,
                                              asSort,
                                              azSort,
                                              n,
                                              keep.below = TRUE);
      # ...................................................................................      


      
      # ...................................................................................
      # . Cox analysis for establishing GLOBAL significance of model predictions:
      # . regress observed survival times against predicted differential-log-hazard ratios.
      # ...................................................................................
      dfXBuf = data.frame(aDloghR = aDloghR);
      flagCenter = 'no';
      
      cModel = BasicCox.computeCoxWithCov(at = at,
                                          as = as,
                                          az = az,
                                          dfX = dfXBuf,
                                          flagCenter = flagCenter);
      # ...................................................................................      


     
      
      # ...................................................................................
      # . >> Extract arrays and determine optimal predicted differential hazard-ratio threshold.
      # .
      # . hRC : optimal predicted differential hazard-ratio threshold.
      # .
      # . * Details : this threshold is used to subset the samples so as
      # . to mazimize significance in the comparison of survival times for
      # . z = 0 and z = 1 groups. The selection is biased toward small hazard ratios
      # . lambda(z = 1) /lambda(z = 0), so as to select for sensitive patients,
      # . likely to benefit from the z = 1 treatment arm.
      # . To do the selection, we use the *predicted* differential log-hazard ratio,
      # . hRpred = lambda(z = 1) /lambda(z = 0), and require :
      # .
      # .                   hRpred <= hRC.
      # ...............................................................................................
      apRSort = as.numeric(abufR[2, ]);  # P-values from comparing z = 0 to z = 1 samples with i <= ic.
      ahRSort = as.numeric(abufR[3, ]);  # hazard ratios; hR = lambda(z = 1) / lambda(z = 0).

      icMin = which.min(apRSort);        # Index for cut which maximizes significance.
      pRMin = min(apRSort);              # Minimum P-value.
      hRMin = ahRSort[icMin];            # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.
      hRC = exp(aDloghRSort[icMin]);     # The corresponding predicted differential hazard-ratio threshold.
      # ................................................................................................
      # . Extract arrays for the *resistant* subset as well :
      # ................................................................................................
      if (flagComputeRES) {
        apRSortRES = as.numeric(abufRRES[2, ]);  # P-values from comparing z = 0 to z = 1 samples with i >= ic.
        ahRSortRES = as.numeric(abufRRES[3, ]);  # hazard ratios; hR = lambda(z = 1) / lambda(z = 0).
      } else {
        apRSortRES = NULL;                       # Not computed here.
        ahRSortRES = NULL;                       # Not computed here.
      }      
      # ................................................................................................

      
      
      # ..................................................................................................
      # . Package the results into a list :
      # ..................................................................................................
      cCov = list(n = n,                           # Total number of samples.
                  cs0 = cs0,                       # Gene expression effects, z = 0 panel.
                  cs1 = cs1,                       # Gene expression effects, z = 1 panel.
                  csAll = csAll,                   # z = 1 versus z = 0 for all patients.
                  aDloghRSort = aDloghRSort,       # n: predicted lambda(z = 1) / lambda(z = 0), sorted increasing.
                  indexSort = indexSort,           # n: sort index for predicted differential log-hazard-ratio.
                  apRSort = apRSort,               # n: P-values for 1 to 0 comparisons at i <= ic.
                  ahRSort = ahRSort,               # n: hazard ratios for 1 to 0 for comparisons at i <= ic.
                  flagComputeRES = flagComputeRES, # Indicates whether apRSortRES, ahRSortRES were calculated.
                  apRSortRES = apRSortRES,         # n: P-values for 1 to 0 comparisons at i >= ic.
                  ahRSortRES = ahRSortRES,         # n: hazard ratios for 1 to 0 for comparisons at i >= ic.        
                  flaghRC = 'internal',      # Externally given threshold value.        
                  icMin = icMin,             # Index at which minimum P-value occurs.
                  pRMin = pRMin,             # Minimum P-value at optimal thresholding between z = 1 and z = 0 sub-populations.
                  hRMin = hRMin,             # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.        
                  hRC = hRC,                 # Optimal cut: subset at predicted lambda(z = 1) / lambda(z = 0) <= hRC to minimize the P-value.
                  cModel = cModel);          # Cox regression of surv. times on DloghR: how predictive is the overall model?

      class(cCov) = "spc.cox.cov.significance";
      # ....................................................................................................
      
     
      # .............
      return (cCov);
      # .............

}

# ==========================================================================================================
# . End of SuperPc.computeCoxWithCovSignificanceOnSplit.
# ==========================================================================================================








# =========================================================================================================
# . SuperPc.computeCoxWithCovSignificanceOnSplitEXT : given input set of survival data and a corresponding
# . -----------------------------------------------   log-hazard-ratio vectors, computes a
# .                                                   statistical significance for the underlying model.
# .
# . This version is similar to: SuperPc.computeCoxWithCovSignificanceOnSplit(), but used an externally
# . defined threshold hRCExt to define the sensitive subset.
# .
# .........................................................................................................
# . >>Note : this is taylored for two-arm studies, with values of the external covariate z = 0, 1.
# .
# .   Syntax:
# .
# .       cCov = SuperPc.computeCoxWithCovSignificanceOnSplitEXT(at, as, az,
# .                                                              aloghR,
# .                                                              aloghR0,
# .                                                              aloghR1,
# .                                                              hRCExt.
# .                                                              flagComputeRES);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .            az = n : vector of external covariates. Values of z must be binary,
# .                     z in {0, 1}. An internal check is performed and an exception
# .                     occurs if there are non-binary values.
# .
# .        aloghR = n : vector of log-hazard-ratios, as predicted by the Cox model
# .                     for the *actual* values of the external covariate.
# .       aloghR0 = n : vector of log-hazard-ratios, as predicted by the Cox model
# .                     for the all values of the external covariate set to z = 0
# .                     (log-hazard-ratios predicted for baseline treatment).
# .       aloghR1 = n : vector of log-hazard-ratios, as predicted by the Cox model
# .                     for the all values of the external covariate set to z = 1
# .                     (log-hazard-ratios predicted for new treatment).
# .
# .         hRCExt    : externally imposed threshold for defining the sensitive subsets.
# .
# .    flagComputeRES : flag for whether to compute the inter-treatment arm for the *resistant*
# .                     subset as well as for the sensitive subset.               
# .
# .   Out:
# .          cCov = list with members :
# .
# .                 See final packaging before return statement below for
# .                 description of members.
# .
# ..........................................................................................................
# . * Details :
# .
# .       Computation of the statistical significance is based on :
# .
# .         i. Splitting the samples into two groups, based on whether or not their
# .            log-hazard-ratio is greater than (high risk) or less than (low risk) the median
# .            of the predicted log-hazard-ratios.
# .
# .       iii. Performing a Cox regression analysis, using the two risk groups and the input
# .            test survival data. The p-value is from the score test (which obtains the same
# .            value as the logrank test).
# .
# ==========================================================================================================

SuperPc.computeCoxWithCovSignificanceOnSplitEXT <- function(at, as, az, aloghR, aloghR0, aloghR1, hRCExt,
                                                            flagComputeRES)
{

      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nz = length(az);      # Number of samples in external covariate vector.
      
      nl = length(aloghR);  # Number of samples in log-hazard-ratio vector.
      nl0 = length(aloghR0);  # Number of samples in log-hazard-ratio vector for z = 0.
      nl1 = length(aloghR1);  # Number of samples in log-hazard-ratio vector for z = 1.

      if (ns != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplitEXT: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplitEXT: ";
        msg = paste(msg, "The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      
      if (nl != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplitEXT: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR has nl = ", nl, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl0 != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplitEXT: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR0 has nl0 = ", nl0, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl1 != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplitEXT: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR1 has nl1 = ", nl1, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      stopifnot(is.logical(flagComputeRES));
      # ...............................................................................................


      
      # ...............................................................................................
      # . Checks on input parameters :
      # ...............................................................................................      
      msg = Cox.checkBinary(az);

      if (msg != 'ok') {
        cat("ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplitEXT:\n");
        cat(msg, "\n", sep = "");
        stop();
      }

      if (hRCExt <= 0) {
        cat("ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplitEXT:\n");
        cat("hRCExt = ", hRCExt, " <= 0. Valid> hRCExt > 0.\n", sep = "");
        stop();
      }      
      # ...............................................................................................
      

      
      # ...........................................................................................
      # . >> GENE EXPRESSION EFFECTS :
      # . For each treatment arm separately, ask whether the predicted log-hazard ratios
      # . correlate with the survival times.
      # .
      # . 1. Baseline: z= 0.
      # ...........................................................................................
      at0 = at[az == 0];
      as0 = as[az == 0];      
      aloghR_buf0 = aloghR[az == 0];        # The actual values for z = 0.

      n0 = length(at0);

      if (n0 < 2) {
        cat("ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplitEXT:\n");
        cat("Less than 2 elements for z = 0 arrays.\n");
        stop();
      }
      
      #xxx cs0 = Cox.computeCoxOnSplitLoghR(at0, as0, aloghR_buf0);    # J. Theilhaber.
      cs0 = SuperPc.computeCoxSignificanceOnSplitLoghRQUANT(at0, as0, aloghR_buf0, nq = 3);                  
      # ...........................................................................................
      # . 2. Alternate treatment: z= 1.
      # ...........................................................................................
      at1 = at[az == 1];
      as1 = as[az == 1];      
      aloghR_buf1 = aloghR[az == 1];        # The actual values for z = 1.

      n1 = length(at1);

      if (n1 < 2) {
        cat("ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplitEXT:\n");
        cat("Less than 2 elements for z = 1 arrays.\n");
        stop();
      }
      
      #xxx cs1 = Cox.computeCoxOnSplitLoghR(at1, as1, aloghR_buf1);     # J. Theilhaber.
      cs1 = SuperPc.computeCoxSignificanceOnSplitLoghRQUANT(at1, as1, aloghR_buf1, nq = 3);                  
      # ...........................................................................................      


      # ...........................................................................................
      # . >> TREATMENT * GENE-EXPRESSSION EFFECTS :
      # .
      # . Difference in predicted log-hazard for treated versus untreated patients:
      # . DloghR = predicted relative log-hazard = loghR1 - loghR0.
      # . When aDloghR < 0, the treated patients are predicted to do better than the
      # . untreated patients.
      # ...........................................................................................
      aDloghR = aloghR1 - aloghR0;
      # ...................................................................................
      # . Sort the arrays so that samples are ordered with increasing relative log-hazard :
      # ...................................................................................
      sBuf = sort(aDloghR,
                  decreasing = FALSE,
                  index.return = TRUE);    # Sort in increasing order.

      indexSort = sBuf[["ix"]];      # Sort index, used below in sorting the arrays.

      aDloghRSort = sBuf[["x"]];     # Sorted array of relative log-hazards.
      atSort = at[indexSort];        # Sorted array of indicators (1 = death, 0 = censored) (i.e. deltas).      
      asSort = as[indexSort];        # Sorted array of indicators (1 = death, 0 = censored) (i.e. deltas).
      azSort = az[indexSort];        # Sorted array of indicators (1 = death, 0 = censored) (i.e. deltas).      
      # ...................................................................................
      # . Walk through the sorted list, left-to-right, computing significance of difference
      # . of survival in the treatment arms as a function of predicted relative log-hazard.
      # . At the extreme right boundary, *all* samples are included and we are computing
      # . the overall treament effect.
      # . 
      # . Below: abufR is a 5 * n matrix, with in each row :
      # .
      # .   nc = array of total number of samples used in test.
      # .   pR = array of P-value from comparing z = 0 to z = 1 samples with i <= ic,
      # .        where ic = array index.
      # .   hR = array of hazard ratios; hR = lambda(z = 1) / lambda(z = 0).
      # . hRLo = array of lower confidence limits for hazard ratios [exp(loghR - se)].
      # . hRHi = array of upper confidence limits for hazard ratios [exp(loghR + se)].
      # .
      # ...................................................................................      
      abufR = sapply(1:n, function(ic){Cox.computeBinaryCoxOnThreshold(atSort,
                                                                       asSort,
                                                                       azSort,
                                                                       ic,
                                                                       keep.below = TRUE);});
      # ...................................................................................
      # . Also compute the hazard ratio and P-value profile for the "resistant" subset, if 
      # . it was required. Note that this calculation is optional and can be turned off
      # . for speed of computation in the main optimization loops, which depend
      # . only on the hazard ratio and P-value for the *sensitive* population.
      # ...................................................................................
      if (flagComputeRES) {
        abufRRES = sapply(1:n, function(ic){Cox.computeBinaryCoxOnThreshold(atSort,
                          asSort,
                          azSort,
                          ic,
                          keep.below = FALSE);});
      }
      # ...................................................................................



      
      # ...................................................................................
      # . Cox analysis of all patients.
      # . This is already contained in abufR[ ,n], but we are reproducing the calculation
      # . for logical convenience :
      # ...................................................................................
      csAll = Cox.computeBinaryCoxOnThreshold(atSort,
                                              asSort,
                                              azSort,
                                              n,
                                              keep.below = TRUE);
      # ...................................................................................      



      # ...................................................................................
      # . Cox analysis for establishing GLOBAL significance of model predictions:
      # . regress observed survival times against predicted differential-log-hazard ratios.
      # ...................................................................................
      dfXBuf = data.frame(aDloghR = aDloghR);
      flagCenter = 'no';
      
      cModel = BasicCox.computeCoxWithCov(at = at,
                                          as = as,
                                          az = az,
                                          dfX = dfXBuf,
                                          flagCenter = flagCenter);
      # ...................................................................................      


      
      
      # ...................................................................................
      # . >> Extract arrays and determine optimal predicted differential hazard-ratio threshold.
      # .
      # . hRC : here is set to the EXTERNALLY specified differential hazard-ratio threshold.
      # .
      # . * Details : this threshold is used to subset the samples so as
      # . to mazimize significance in the comparison of survival times for
      # . z = 0 and z = 1 groups. The selection is biased toward small hazard ratios
      # . lambda(z = 1) /lambda(z = 0), so as to select for sensitive patients,
      # . likely to benefit from the z = 1 treatment arm.
      # . To do the selection, we use the *predicted* differential log-hazard ratio,
      # . hRpred = lambda(z = 1) /lambda(z = 0), and require :
      # .
      # .                   hRpred <= hRC.
      # ...............................................................................................
      apRSort = as.numeric(abufR[2, ]);  # P-values from comparing z = 0 to z = 1 samples with i <= ic.
      ahRSort = as.numeric(abufR[3, ]);  # hazard ratios; hR = lambda(z = 1) / lambda(z = 0).

      loghRCExt = log(hRCExt);
      aiBuf = which(aDloghRSort <= loghRCExt);  # Samples with predicted differential hazard ratio below threshold.

      if (length(aiBuf) == 0) {
        icMin = 0;                         # No sensitive subset exists under the specified threshold.
        pRMin = 1.0;                       # Dummy (non-significant) value.
        hRMin = 1.0;                       # Dummy (non-significant) value.
      } else {
        icMin = max(aiBuf);
        pRMin = apRSort[icMin];            # Minimum P-value.
        hRMin = ahRSort[icMin];            # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.
      }
        
      hRC = hRCExt;                        # Set to external value.
      # ................................................................................................
      # . Extract arrays for the *resistant* subset as well :
      # ................................................................................................
      if (flagComputeRES) {
        apRSortRES = as.numeric(abufRRES[2, ]);  # P-values from comparing z = 0 to z = 1 samples with i >= ic.
        ahRSortRES = as.numeric(abufRRES[3, ]);  # hazard ratios; hR = lambda(z = 1) / lambda(z = 0).
      } else {
        apRSortRES = NULL;                       # Not computed here.
        ahRSortRES = NULL;                       # Not computed here.
      }        
      # ................................................................................................      

      
      
      # ..................................................................................................
      # . Package the results into a list :
      # ..................................................................................................
      cCov = list(n = n,                           # Total number of samples.
                  cs0 = cs0,                       # Gene expression effects, z = 0 panel.
                  cs1 = cs1,                       # Gene expression effects, z = 1 panel.
                  csAll = csAll,                   # z = 1 versus z = 0 for all patients.
                  aDloghRSort = aDloghRSort,       # n: predicted lambda(z = 1) / lambda(z = 0), sorted increasing.
                  indexSort = indexSort,           # n: sort index for predicted differential log-hazard-ratio.
                  apRSort = apRSort,               # n: P-values for 1 to 0 comparisons at i <= ic.
                  ahRSort = ahRSort,               # n: hazard ratios for 1 to 0 for comparisons at i <= ic.
                  flagComputeRES = flagComputeRES, # Indicates whether apRSortRES, ahRSortRES were calculated.
                  apRSortRES = apRSortRES,         # n: P-values for 1 to 0 comparisons at i >= ic.
                  ahRSortRES = ahRSortRES,         # n: hazard ratios for 1 to 0 for comparisons at i >= ic.        
                  flaghRC = 'external',            # Externally given threshold value.
                  icMin = icMin,             # Largest index at which DloghR <= hRCExt occurs.
                  pRMin = pRMin,             # P-value at given thresholding between z = 1 and z = 0 sub-populations.
                  hRMin = hRMin,             # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.
                  hRC = hRC,                 # Optimal cut: subset at predicted lambda(z = 1) / lambda(z = 0) <= hRC to minim. the P-value.
                  cModel = cModel);          # Cox regression of surv. times on DloghR: how predictive is the overall model?        

      class(cCov) = "spc.cox.cov.significance";
      # ....................................................................................................
      
     
      # .............
      return (cCov);
      # .............

}

# ==========================================================================================================
# . End of SuperPc.computeCoxWithCovSignificanceOnSplitEXT.
# ==========================================================================================================










# =========================================================================================================
# . SuperPc.summarizeCoxWithCovOnSplit : compute hazard ratios for sensitive and resistant populations
# . ----------------------------------   for indicated threshold.
# .
# .  Syntax :
# .
# .        sumC = SuperPc.summarizeCoxWithCovOnSplit(aDloghRSort,
# .                                                  ahRSortSEN,
# .                                                  apRSortSEN,                                               
# .                                                  ahRSortRES,
# .                                                  apRSortRES,
# .                                                  hRCIn,
# .                                                  flaghRCOpt);
# .
# .
# .  In :
# .
# .            aDloghRSort = array of length n. Values of DloghR sorted in increasing order.
# .             ahRSortSEN = array of length n. Corresponding values of hR(S).
# .             apRSortSEN = array of length n. Corresponding values of pR(S).
# .             ahRSortRES = array of length n. Corresponding values of hR(R).
# .             apRSortRES = array of length n. Corresponding values of pR(R).
# .
# .                   hRCIn = externally provided decision threshold, defining sensitives and resistants.
# .
# .             flaghRCOpt = flag defining where the hRC value used comes from.
# .                          Allowed values :
# .
# .                            -   'no' : use input value, hRC = hRCIn.
# .                            -  'yes' : use value : hRC = argmin { apRSortSEN[DloghRSort <= hRC'] }
# .                                                          hRC'
# .                                       which maximizes significance of the separation of treatment
# .                                       arms for this one realization.
# .
# .                           The value of hRC internally used is included in the returned values.
# .                           Note that the threshold hRC defines :
# .
# .                            DloghR <= log(hRC) --> sensitive
# .                            DloghR >= log(hRC) --> resistant
# .
# .  Out :
# .
# .              sumC = list, with members indicated below in packaging statement.
# .
# ..........................................................................................................
# . Note that is similar to :   SuperPc.computeCoxWithCovSignificanceOnSplitEXT()
# . but assumes that the hazard ratio profiles hR(S), hR(R), as a function of DloghR, have already
# . been calculated.
# .
# ==========================================================================================================

SuperPc.summarizeCoxWithCovOnSplit <- function(aDloghRSort,
                                               ahRSortSEN,
                                               apRSortSEN,                                               
                                               ahRSortRES,
                                               apRSortRES,
                                               hRCIn,
                                               flaghRCOpt)
{

         # ...........................................................................................
         # . Check on values :
         # ...........................................................................................
         n = length(aDloghRSort);

         n1 = length(ahRSortSEN);
         stopifnot(n1 == n);

         n1 = length(apRSortSEN);
         stopifnot(n1 == n);

         n1 = length(ahRSortRES);
         stopifnot(n1 == n);                  

         n1 = length(apRSortRES);
         stopifnot(n1 == n);

         if (n > 1) {
           nbuf1 = n - 1;
           abuf = aDloghRSort[2:n] - aDloghRSort[1:nbuf1];

           if (min(abuf) < 0.0) {
             cat("ERROR: from SuperPc.summarizeCoxWithCovOnSplit:\n");
             cat("Input aDloghR sequence is not monotone non-decreasing.\n");
             stop();
           }
         }

         stopifnot(hRCIn > 0.0);

         stopifnot((flaghRCOpt == 'yes') || (flaghRCOpt == 'no'));
         # ...........................................................................................


         
         # ...........................................................................................
         # . Set the threshold :
         # . >> 1. Use externally provided value :
         # ...........................................................................................
         if (flaghRCOpt == 'no') {
           hRC = hRCIn;
         }
         # ...........................................................................................         
         # . >> 2. Or get the value that maximizes significance of split on sensitives :
         # ...........................................................................................
         if (flaghRCOpt == 'yes') {
           ipvalmin = which.min(apRSortSEN);    # Index for smallest P-value.
           hRC = exp(aDloghRSort[ipvalmin]);    # Corresponding differential prognostic index.
         }         
         # ...........................................................................................                    
  

         
         # ........................................................
         # . Hazard ratio and P-value for all samples together :
         # ........................................................
         hR_all = ahRSortSEN[n];
         pR_all = apRSortSEN[n];         
         # ........................................................


         
         # ...........................................................................................
         # . Extract hazard ratios and P-values at the indicated threshold.
         # .
         # . >>1. Look at threshold in relation to range :
         # ...........................................................................................
         loghRC = log(hRC);                  # Log of the indicated decision threshold.
         maxDloghR = max(aDloghRSort);       # Upper and lower bounds
         minDloghR = min(aDloghRSort);       # on differential log-hazard-ratio.
         # ..................................................................
         # . >>2. Extract values :
         # .
         # . a. All patients declared sensitive :
         # ..................................................................         
         if (loghRC >= maxDloghR) {
           hR_S = ahRSortSEN[n];             # Sensitives are all samples.
           pR_S = apRSortSEN[n];             # Sensitives are all samples.           
           hR_R = 1.0;                       # Dummy non-significant values.
           pR_R = 1.0;                       # Dummy non-significant values.
           nS = n;
           nR = 0;
         }
         # ..................................................................
         # . b. All patients declared resistant :
         # ..................................................................
         if (loghRC <= minDloghR) {
           hR_S = 1.0;                       # Dummy non-significant values.
           pR_S = 1.0;                       # Dummy non-significant values.           
           hR_R = ahRSortRES[1];             # Resistants are all samples.
           pR_R = apRSortRES[1];             # Resistants are all samples.
           nS = 0;
           nR = n;
         }
         # ..................................................................
         # . c. Threshold is inside range :
         # ..................................................................
         if ((loghRC > minDloghR) && (loghRC < maxDloghR)) {
           ic = max(which(aDloghRSort <= loghRC)); 
           hR_S = ahRSortSEN[ic];
           pR_S = apRSortSEN[ic];            
           hR_R = ahRSortRES[ic];
           pR_R = apRSortRES[ic];
           nS = ic;
           nR = n - nS + 1;                 # Resistants calculation includes overlap of 1 with sensitives.
         }
         # ...........................................................................................

         

         # ........................................................
         # . Ratios of interest :
         # ........................................................
         ratio_hR_S_to_R = hR_S / hR_R;
         ratio_hR_S_to_all = hR_S / hR_all;
         ratio_hR_R_to_all = hR_R / hR_all;                  
         # ........................................................
         
         

         # ...........................................................................................
         # . Compute areas-under-curves (AUCs) for sensitive and resistant profiles, and
         # . resulting area-between curves (abc) :
         # ...........................................................................................
         ahRSortSEN = ifelse(is.na(ahRSortSEN), 1.0, ahRSortSEN);    # Set NAs to 1.         
         aucS =  Cox.computehRROCArea(ahRSortSEN);                   # Area under sensitives ROC.

         ahRSortRES = ifelse(is.na(ahRSortRES), 1.0, ahRSortRES);    # Set NAs to 1.
         aucR =  Cox.computehRROCArea(ahRSortRES);                   # Area under resistants ROC.
         
         abc = aucR - aucS;                                          # Area between curves.
         # ...........................................................................................



         # .....................................................................................................
         # . Package the results :
         # .....................................................................................................
         sumC = list( pR_all = pR_all,                               # P-value for Z = 1 to Z = 0, all samples.
                      hR_all = hR_all,                               # Hazard ratio hR(all) for Z = 1 to Z = 0, all samples.
                      n = n,                                         # Total number of samples.
                      hRCIn = hRCIn,                                 # External input threshold.
                      hRC = hRC,                                     # Threshold actually used.
                      nS = nS,                                       # Number of sensitives.
                      nR = nR,                                       # Number of resistants.           
                      hR_S = hR_S,                                   # hR(S) for given threshold hRC.
                      pR_S = pR_S,                                   # pR(S) for given threhold hRC.
                      hR_R = hR_R,                                   # hR(R) for given threshold hRC.
                      pR_R = pR_R,                                   # pR(R) for given threshold hRC.
                      ratio_hR_S_to_R = ratio_hR_S_to_R,             # hR(S) / hR(R)
                      ratio_hR_S_to_all = ratio_hR_S_to_all,         # hR(S) / hR(all).
                      ratio_hR_R_to_all = ratio_hR_R_to_all,         # hR(R) / hR(all)
                      aucS = aucS,                                   # AUC for sensitives.
                      aucR = aucR,                                   # AUC for resistants.
                      abc = abc);                                    # ABC = AUC(R) - AUC(S).
         # ......................................................................................................



         # ...............
         return (sumC);
         # ...............
         
}

# =========================================================================================================
# . End of SuperPc.summarizeCoxWithCovOnSplit.
# =========================================================================================================

  




# =================================================================================================
# . SuperPc.selectFeaturesCoxWithCov : does feature selection, based on a precomputed set of univariate
# . --------------------------------   Cox proportional hazard model scores. This version
# .                                    assumes that an external covariate is present.
# .
# .   Syntax:
# .
# .      selF = SuperPc.selectFeaturesCoxWithCov(dfXc, methodFs, p0, mtop, coxS, typePval);
# .
# .   In:
# .           dfXc =data frame for the predictor variables, after column mean-centering.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'p0' : use the P-value threshold p0 for selecting genes.
# .                   
# .                  - 'mtop' : use the parameter mtop for selecting genes.
# .
# .          p0   = threshold in P-values from Cox proportional hazards model.
# .                 Only genes with p <= p0 are kept after feature selection.
# .                 The p-values are computed using the univariate score test.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .          coxS = object returned by a call to Cox.computeOnDataFrameSimpleBetaWithCov(),
# .                 contains the gene-by-gene Cox scores (with external covariate in the
# .                 models).
# .
# .      typePval = type of the P-value that is to be used for the feature selection.
# .                 Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .   Out:
# .        selF = list, with members:
# .
# .               indexSel            # Index of selected genes.                         
# .               m                   # Number of selected genes.                        
# .               pvalMin             # Smallest univariate p-value selected.            
# .               pvalMax             # Largest univariate p-value selected.             
# .               dfXSel              # Data frame subsetted to the selected features.
# . 
# =================================================================================================

SuperPc.selectFeaturesCoxWithCov <- function(dfXc, methodFs, p0, mtop, coxS, typePval)
{

      # ........................................................................
      # . Check on values :
      # ........................................................................  
      stopifnot((methodFs == 'p0') || (methodFs == 'mtop'));
      stopifnot((p0 >= 0.0) && (p0 <= 1.0));
      stopifnot(mtop >= 1);

      if (class(coxS) !=  "cox.uni.cov") {
        cat("ERROR: from SuperPc.selectFeaturesCoxWithCov:\n");
        cat("coxS is not of class cox.uni.cov.\n");
        cat("[see: Cox.computeOnDataFrameSimpleBetaWithCov]\n");
        stop();
      }

      allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
      if (is.null(allowedTypePval[[typePval]])) {
        cat("ERROR: from SuperPc.selectFeaturesCoxWithCov:\n");
        cat("typePval = ", typePval, " is not valid.\n", sep = "");
        cat("Valid: model, X, Z, ZX.\n", sep = "");
        stop();
      }
      # ........................................................................


      
      # ........................................................................
      p = ncol(dfXc);           # Number of genes in input data matrix.
      pS = length(coxS$ap);     # Number of genes from coxS object.

      if (pS != p) {
        msg = "ERROR: from SuperPc.selectFeaturesCoxWithCov: ";
        msg = paste("coxS input has pS = ", pS, " genes. ", sep = "");
        msg = paste("Not the same as p = ", p, " in input data matrix dfXc.", sep = "");        
        stop(msg);
      }      
      # ........................................................................


      # ........................................................................
      # . Choose the P-value array to be used for the feature selection:
      # ........................................................................
      if (typePval == 'model') {
        apBuf = coxS$ap;
      } else if (typePval == 'X') {
        apBuf = coxS$apX;        
      } else if (typePval == 'Z') {
        apBuf = coxS$apZ;
      } else if (typePval == 'ZX') {
        apBuf = coxS$apZX;        
      }
      # ........................................................................      

      

      # .......................................................................................
      # . Feature selection step:
      # .
      # . >> Method = p0 : subset to genes with P-value for Cox model <= p0.
      # .    The p-values are evaluated from the score test.
      # .
      # .    Return with m = 0 if the filter is too stringent and 0 genes are passed.
      # .......................................................................................
      if (methodFs == 'p0') {
        indexSel = which(apBuf <= p0);    # Indices of genes selected with p <= p0.
        m = length(indexSel);                  # Number of genes selected.

        if (m == 0) {
          spc = list(msg = "ERROR: nothing passed the preliminary feature selection",
                     m = 0);
          return (spc);                     # Return as there is nothing to compute.
        }

        pvalMin = min(apBuf[indexSel]);   # Smallest p-value actually selected.        
        pvalMax = min(apBuf[indexSel]);   # Largest p-value actually selected.
      }
      # .......................................................................................
      # . >> Method = mtop : select the mtop genes with the most significant scores.
      # .......................................................................................
      if (methodFs == 'mtop') {
        sBuf = sort(apBuf, decreasing = FALSE, index.return = TRUE);
        indexSel = sBuf[["ix"]][1:mtop];           # Indices of genes selected.
        m = mtop;
        pvalMin = sBuf[["x"]][1];                  # Smallest p-value actually selected.        
        pvalMax = sBuf[["x"]][mtop];               # Largest p-value actually selected.
      }
      # .......................................................................................
      # . Now subset the data matrix to the selected genes :
      # .......................................................................................
      dfXSel = dfXc[ , indexSel];                           # Subsetted to the selected genes.
      acBuf = colnames(dfXc);
      
      if (length(indexSel) == 1) {
        dfXSel = as.matrix(dfXSel, nrow = nrow(dfXc))       # Special case for 1 gene selected.
        colnames(dfXSel) = acBuf[indexSel];        
      }
      # .......................................................................................


      # .......................................................................................
      # . Package results :
      # .......................................................................................
      selF = list(typePval = typePval,
                  indexSel = indexSel,
                  m = m,
                  pvalMin = pvalMin,
                  pvalMax = pvalMax,
                  dfXSel = dfXSel   );

      class(selF) = "selected.features";
      # .......................................................................................

      
      # .............
      return (selF);
      # .............
      
}

# =================================================================================================
# . End of SuperPc.selectFeaturesCoxWithCov.
# =================================================================================================







# =================================================================================================
# . SuperPc.selectFeaturesNOOP : Assign "NOOP" (identity) selection. Can be used if no first-pass 
# . --------------------------   feature selection was requested. 
# .
# .   Syntax:
# .
# .      selF = SuperPc.selectFeaturesNOOP(dfXc);
# .
# .   In:
# .           dfXc = data frame for the predictor variables.
# .                  This is of dimension n * p, where p = number of genes;
# .                  each row corresponds to a samples, and each column to a
# .                  gene.
# .
# .   Out:
# .        selF = list, with members:
# .
# .               typePval            # equal to 'NONE' (dummy value).
# .               indexSel            # Index of selected genes: here equal to all, 1:p.            
# .               m                   # Number of selected genes: here equal to p.
# .               pvalMin             # Smallest univariate p-value selected (--> 1).           
# .               pvalMax             # Largest univariate p-value selected (--> 1)    
# .               dfXSel              # Data frame subsetted to the selected features:
# .                                     here identical to input data matrix.
# . 
# =================================================================================================

SuperPc.selectFeaturesNOOP <- function(dfXc)
{

      # ........................................................................
      p = ncol(dfXc);           # Number of genes in input data matrix.
      # ........................................................................


      # .......................................................................................
      # . Assign values :
      # .......................................................................................
      typePval = 'NONE';        # Dummy value.
      
      indexSel = 1:p;           # Indices of genes selected. In this case ALL genes.
      m = length(indexSel);     # Number of genes selected: here equal to p.

      pvalMin = 1.0;            # Dummy value.
      pvalMax = 1.0;            # Dummy value.

      dfXSel = dfXc;            # No subsetting: data matrix is same as for input.
      # .......................................................................................


      # .......................................................................................
      # . Package results :
      # .......................................................................................
      selF = list(typePval = typePval,
                  indexSel = indexSel,
                  m = m,
                  pvalMin = pvalMin,
                  pvalMax = pvalMax,
                  dfXSel = dfXSel   );

      class(selF) = "selected.features";
      # .......................................................................................

      
      # .............
      return (selF);
      # .............
      
}

# =================================================================================================
# . End of SuperPc.selectFeaturesNOOP.
# =================================================================================================









# =================================================================================================
# . SuperPc.computeSignificanceOnCov : for a super pc Cox model,computes log-hazard ratios
# . --------------------------------   for all input instances, determines a sensitive patient
# .                                    subset based on the differential log-hazard-ratio threshold,
# .                                    and computes Cox models comparing Z = 0 and Z = 1 arms,
# .                                    for all patients, and for the sensitive subset of patients.
# .
# . Syntax:
# .
# .    ds = SuperPc.computeSignificanceOnCov(spc, dfX, at, as, az, hRC);
# .
# . In:
# .
# .      spc = basic.cox.cov object, returned by SuperPc.computeCoxWithCov().
# .
# .     dfX = input data matrix; need not be the same as generated the
# .           Cox model, but must have the same number of genes.
# .
# .      at = vector of survival times.
# .      as = vector of censoring statuses.
# .      az = vector of external covariate values.
# .     hRC = threshold on differential log-hazard ratio, for determining sensitive patients.
# .
# . Out: list ds, with members :
# .
# .        hRC = threshold of predicted differential log-hazard ratio.
# .       nAll = total number of samples.
# .      csAll = significance scores for all samples, in Z = 1 to Z = 0 comparison.
# .      nSens = number of sensitive patients, defined at threshold hRC (can be 0).
# .     csSens = significance scores for sensitive patient samples, in Z = 1 to
# .              Z = 0 comparison.
# .
# .
# =================================================================================================

SuperPc.computeSignificanceOnCov <- function(spc, dfX, at, as, az, hRC)
{


        # ....................................................................
        if (class(spc) != "spc.cox.cov") {
          msg = "ERROR: from SuperPc.computeSignificanceOnCov: ";
          msg = paste(msg, "The input spc is not of class spc.cox.cov");
          stop(msg);
        }

        n = nrow(dfX);     # Number of samples.
        p = ncol(dfX);     # Number of genes.
      
        nt = length(at);   # Number of samples in survival time vector.
        ns = length(as);   # Number of samples in censoring status vector.
        nz = length(az);   # Number of samples in external covariate vector.
      
        if (nt != n) {
          msg = "ERROR: from SuperPc.computeSignificanceOnCov: ";
          msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
          msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
          stop(msg);
        }

        if (ns != n) {
          msg = "ERROR: from SuperPc.computeSignificanceOnCov: ";
          msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
          msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
          stop(msg);
        }

        if (nz != n) {
          msg = "ERROR: from SuperPc.computeSignificanceOnCov: ";          
          msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
          msg = paste("This is not the same as the n = ", n,
                      "samples in the data matrix dfX.", sep = "");        
          stop(msg);
        }
      
        if (spc$p != p) {
          msg = "ERROR: from SuperPcDiag.plotCoxWithCovOnTest: ";                
          msg = paste("The input data matrix does not have the same number of ");
          msg = paste("genes as in the supervised pc. ");
          msg = paste("Input has p = " , p, " genes. ");
          msg = paste("Spc has p = " , spc$p, " genes.");
          stop(msg);
        }

        stopifnot(hRC >= 0.0);      
        # .....................................................................

        
      
        # .............................................................
        # . Compute significance, Surv(at, as) ~ az, for all samples.
        # .............................................................  
        csAll = Cox.computeBinaryCox(at, as, az);
        # .............................................................        

        
        # .......................................................................................
        # . Compute the log harzard ratios, using the model;
        # . determine sensitive patients based on the specified threshold.
        # .......................................................................................  
        sl = SuperPc.computeCoxPcAndLogHazardWithCovAndPred(spc, dfX, az, hRC);      
        # .......................................................................................

        
        # ................................................................
        # . Subset to sensitive samples only :
        # ................................................................
        aSens = (sl$aflagSensitiveZ == 1);   # Mask for sensitive patients.
        nSens = sum(aSens);

        if (nSens > 0) {
          atSens = at[aSens];
          asSens = as[aSens];
          azSens = az[aSens];
        } else {
          atSens = c();
          asSens = c();
          azSens = c();
        }
        # .................................................................
        

        # .............................................................
        # . Compute significance, Surv(at, as) ~ az, for sensitive samples.
        # .............................................................
        if (nSens > 0) {
          csSens = Cox.computeBinaryCox(atSens, asSens, azSens);
        } else {
          csSens =NULL;
        }
        # .............................................................


        # .............................................................
        # . Package the results :
        # .............................................................
        ds = list(hRC = hRC,
                  nAll = n,
                  csAll = csAll,
                  nSens = nSens,
                  csSens = csSens);
        # .............................................................        

}

# =================================================================================================
# . End of SuperPc.computeSignificanceWithCov.
# =================================================================================================






# =================================================================================================
# . SuperPc.checkDataMatricesForRocOnCoxph : checks entries in data frame loaded for post-processing
# . --------------------------------------   of COXPH file into ROCs.
# .                                          
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForRocOnCoxph(dfX, inparam);
# .
# .  In:
# .             dfX = combined numerical and factor data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTime = factor in dfX defining survival times.
# .                 tStatus = factor in dfX defining censoring status.
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX has factors tTime, tStatus, and factors from the required COXPH columns :
# .
# =================================================================================================

SuperPc.checkDataMatricesForRocOnCoxph <- function(dfX, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTime)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRocOnCoxph: inparam does not have member tTime";
      stop(msg);
    }

    if (is.null(inparam$tStatus)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForRocOnCoxph: inparam does not have member tStatus";
      stop(msg);
    }
    # .......................................................................................    

    

    # .......................................................................................
    # . Check existence of externally provided factors :
    # .......................................................................................
    if (is.null(dfX[[inparam$tTime]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRocOnCoxph :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfX[[inparam$tStatus]])) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRocOnCoxph :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    # .......................................................................................

    
    # .......................................................................................
    # . Check existence of factors standard for COXPH format :
    # .......................................................................................    
    if (is.null(dfX$zActual)) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRocOnCoxph :\n", sep = "");
      msg = paste(msg, "the factor zActual does not exist in the input experimental design,", sep = "");
      msg = paste(msg, "but is required in COXPH files.", sep = "");      
      return (msg);
    }

    if (is.null(dfX$loghR_zactual)) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRocOnCoxph :\n", sep = "");
      msg = paste(msg, "the factor loghR_zactual does not exist in the input experimental design,", sep = "");
      msg = paste(msg, "but is required in COXPH files.", sep = "");      
      return (msg);
    }

    if (is.null(dfX$loghR_z0)) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRocOnCoxph :\n", sep = "");
      msg = paste(msg, "the factor loghR_z0 does not exist in the input experimental design,", sep = "");
      msg = paste(msg, "but is required in COXPH files.", sep = "");      
      return (msg);
    }
    
    if (is.null(dfX$loghR_z1)) {
      msg = paste("ERROR:  from SuperPc.checkDataMatricesForRocOnCoxph :\n", sep = "");
      msg = paste(msg, "the factor loghR_z1 does not exist in the input experimental design,", sep = "");
      msg = paste(msg, "but is required in COXPH files.", sep = "");      
      return (msg);
    }        
    # .......................................................................................

    
    # .......................................................................................
    # . Check on factor and values if a filter was specified :
    # .......................................................................................
    if (inparam$flagFilter == 'yes') {
      if (is.null(dfX[[inparam$tFilter]])) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRocOnCoxph :\n", sep = "");
        msg = paste(msg, "the factor tFilter = ", inparam$tFilter,
                    " which is necessary for train or test filtering ",
                    " does not exist in the input experimental design.", sep = "");
        return (msg);
      }

      abuf = dfX[[inparam$tFilter]];                             # All values for that factor.
      nfilter = length(abuf[abuf == inparam$filterValue]);    # Number for specified value (train or test).

      if (nfilter == 0) {
        msg = paste("ERROR:  from SuperPc.checkDataMatricesForRocOnCoxph :\n", sep = "");
        msg = paste(msg, "for the factor tFilter = ", inparam$tFilter,
                    " I found 0 values corresponding to filterValue = ", inparam$filterValue,
                    sep = "");
        return (msg);
      }
    }
    # .......................................................................................        


    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    n = nrow(dfX);
    
    cat(" ..........  Summary for input data matrix:\n", sep = "");
    cat("             Raw number of samples : n = ", n, "\n", sep = "");

    if (inparam$flagFilter == 'yes') {
      cat("             Number of samples for value = ",
          inparam$filterValue, ": nfilter = ", nfilter, "\n", sep = "");      
    }
    # .......................................................................................        

    

    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForRocOnCoxph.
# =================================================================================================





# =================================================================================================
# . SuperPc.packagecCovIntoCv :
# . -------------------------   
# .
# . Packages output from :
# .
# .     SuperPc.computeCoxWithCovSignificanceOnSplit()
# .
# . into a form compatible with a cross-validation (cv) object, as returned :
# .
# .     BasicCoxCv.crossValidateCoxWithCov();
# .     SuperPc.crossValidateCoxWithCov();
# .
# .................................................................................................
# . Syntax :
# . 
# .         cv = SuperPc.packagecCovIntoCv(cCov, at, as, az, aloghR, aloghR0, aloghR1);
# .
# . In :
# .
# .        cCov = object returned by SuperPc.computeCoxWithCovSignificanceOnSplit().
# .          at = array of survival times used to generate cCov (see below).
# .          as = array of censoring statuses used to generate cCov (see below).
# .          az = array of external covariates used to generate cCov (see below).
# . Out:
# .
# .          cv = cross-validation object (corresponding to a single feature selection level).
# .   
# .................................................................................................
# .  Example :
# .
# .  # Generate ROCs :
# .  cCov = SuperPc.computeCoxWithCovSignificanceOnSplit(at, as, az, aloghR, aloghR0, aloghR1);
# .
# .  # Package into a cross-validation (cv) object.
# .  cv = SuperPc.packagecCovIntoCv(cCov);     
# .
# ,  Note that the resulting cv contains results for just one feature selection level.
# =================================================================================================

SuperPc.packagecCovIntoCv <- function(cCov, at, as, az, aloghR, aloghR0, aloghR1)
{

      # ........................................................................................
      if (class(cCov) != "spc.cox.cov.significance") {
        cat("ERROR: from SuperPc.packagecCovIntoCv:\n");
        cat("The input cCov is not of class spc.cox.cov.significance");
        stop();
      }

      n = cCov$n;
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.

      nl = length(aloghR);  # Number of samples in log-hazard-ratio vector.
      nl0 = length(aloghR0);  # Number of samples in log-hazard-ratio vector for z = 0.
      nl1 = length(aloghR1);  # Number of samples in log-hazard-ratio vector for z = 1.
      
      if (nt != n) {
        msg = "ERROR: from SuperPc.packagecCovIntoCv:: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPc.packagecCovIntoCv:: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPc.packagecCovIntoCv:: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      
      if (nl != n) {
        msg = "ERROR: from SuperPc.packagecCovIntoCv:: ";        
        msg = paste(msg, "The log-hazard-ratio vector aloghR has nl = ", nl, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl0 != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR0 has nl0 = ", nl0, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl1 != n) {
        msg = "ERROR: from SuperPc.computeCoxWithCovSignificanceOnSplit: ";        
        msg = paste(msg, "The log-hazard-ratio vector aloghR1 has nl1 = ", nl1, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }                  
      # ........................................................................................      


      

      # ........................................................................................
      # . Generate the arrays that will be needed in the final package:
      # ........................................................................................
      apR0 = c();
      ahR0 = c();
      apR1 = c();
      ahR1 = c();            
    
      #xxx cCov = SuperPc.computeCoxWithCovSignificanceOnSplit(at, as, az,
      #xxx                                                     aloghRBIG[ , j],
      #xxx                                                     aloghRBIG0[ , j],
      #xxx                                                     aloghRBIG1[ , j]);
      apR0[1] = cCov$cs0$pR;
      ahR0[1] = cCov$cs0$hR;

      apR1[1] = cCov$cs1$pR;
      ahR1[1] = cCov$cs1$hR;                
        
      aDloghRSortBIG = as.data.frame(matrix(cCov$aDloghRSort, nrow = n));
      indexSortBIG = as.data.frame(matrix(cCov$indexSort, nrow = n));
      apRSortBIG = as.data.frame(matrix(cCov$apRSort, nrow = n));
      ahRSortBIG = as.data.frame(matrix(cCov$ahRSort, nrow = n));

      flagComputeRES = cCov$flagComputeRES;
      
      if (flagComputeRES) {
        apRSortRESBIG = as.data.frame(matrix(cCov$apRSortRES, nrow = n));
        ahRSortRESBIG = as.data.frame(matrix(cCov$ahRSortRES, nrow = n));
      } else {
        apRSortRESBIG = NULL;       # Not computed.
        ahRSortRESBIG = NULL;       # Not computed.
      }
      
      aicMinBIG = c(cCov$icMin);
      apRMin = c(cCov$pRMin);
      ahRMin = c(cCov$hRMin);          
      ahRCBIG = c(cCov$hRC);
      # ..........................................................................................
      # . Cox analysis which includes all patients in the study :
      # ..........................................................................................
      hRAll = cCov$csAll$hR;
      hRAllLo = cCov$csAll$hRLo;
      hRAllHi = cCov$csAll$hRHi;
      pRAll = cCov$csAll$pR;
      # ..........................................................................................
      # . These are defined directly from the parameters :
      # ..........................................................................................      
      aloghRBIG = as.data.frame(matrix(aloghR, nrow = n));
      aloghRBIG0 = as.data.frame(matrix(aloghR0, nrow = n));      
      aloghRBIG1 = as.data.frame(matrix(aloghR1, nrow = n));

      aDloghRBIG = aloghRBIG1 - aloghRBIG0;
      # ....................................................................................................


      
      # ....................................................................................................
      # . For quantities arising from the Z=1 to Z=0 comparisons, generate arrays in the
      # . original (unsorted) order 
      # ....................................................................................................
      apRUnSortBIG = apRSortBIG;       # Dummy assign, just to get allocation.
      ahRUnSortBIG = ahRSortBIG;       # Dummy assign, just to get allocation.
      arankBIG = indexSortBIG;         # Dummy assign, just to get allocation.
      
      nScan = 1;                       # Number of tuning parameter levels = number of columns.

      for (j in 1:nScan) {
        apRUnSortBIG[indexSortBIG[ , j], j] = apRSortBIG[ ,j];
        ahRUnSortBIG[indexSortBIG[ , j], j] = ahRSortBIG[ ,j];

        abuf = 1:n;
        arankBIG[indexSortBIG[ , j], j] = abuf;  # For each sample in original order, its rank in terms of DloghR.
      }
      # ....................................................................................................      
      

      

      # ........................................................................................
      # . Package results : assign dummy or NULL results whene necessary.
      # ........................................................................................
      p = 1;                            # Dummy placeholder.
      
      cv = list(methodSplit = "NONE",
                ft = 1.0,
                ncvHere = 1,             # Actual number of splits.
                rngSeed = 1,
                nScan = 1,
                ncv = 1,
                n = n,
                ntrain = n,
                ntest = n,
                p = p,
        
                alTrainQ25 = NULL,
                alTrainMedian = NULL,
                alTrainQ75 = NULL,
                alTrainSigmaMad = NULL,

                aR2TrainQ25 = NULL,
                aR2TrainMedian = NULL,
                aR2TrainQ75 = NULL,
                aR2TrainSigmaMad = NULL,
        
                acvPLQ25 = NULL,
                acvPLMedian = NULL,
                acvPLQ75 = NULL,
                acvPLSigmaMad = NULL,
                acvPL = NULL,
        
                alRatioTestQ25 = NULL,
                alRatioTestMedian = NULL,
                alRatioTestQ75 = NULL,
                alRatioTestSigmaMad = NULL,

                apRatioTestQ25 = NULL,
                apRatioTestMedian = NULL,
                apRatioTestQ75 = NULL,
                apRatioTestCombine = NULL,

                aR2TestQ25 = NULL,
                aR2TestMedian = NULL,
                aR2TestQ75 = NULL,
                aR2TestSigmaMad = NULL,
        
                aMrmsQ25 = NULL,
                aMrmsMedian = NULL,
                aMrmsQ75 = NULL,
                aMrmsSigmaMad = NULL,
                # ................................................................................
                # . >> Prognostic tests :
                # ................................................................................
                apR0 = apR0,                      # nScan : P-values for PROGNOSTIC tests on Z=0 arm only.
                ahR0 = ahR0,                      # nScan : corresponding hR for PROGNOSTIC tests on Z=0 arm only.
        
                apR1 = apR1,                      # nScan : P-values for PROGNOSTIC tests on Z=1 arm only.
                ahR1 = ahR1,                      # nScan : corresponding hR for PROGNOSTIC tests on Z=1 arm only.
                # ..........................................................................................
                # . Cox analysis which includes all patients in the study :
                # ..........................................................................................
                hRAll = hRAll,
                hRAllLo = hRAllLo,
                hRAllHi = hRAllHi,
                pRAll = pRAll,
                # ................................................................................
                # . >> Time, censoring status and external covariate :
                # ................................................................................
                atBIG = at,                       # n : vector of survival times actually used.
                asBIG = as,                       # n : vector of censoring statuses actually used.
                azBIG = az,                       # n : vector of covariate values actually used.
                # ................................................................................
                # . >> UNSORTED arrays below :
                # ................................................................................
                aloghRBIG = aloghRBIG,            # n * nScan : each column contains predicted loghR for collected test sets, for actual values of Z.
                aloghRBIG0 = aloghRBIG0,          # n * nScan : each column contains predicted loghR for collected test sets, for Z = 0.
                aloghRBIG1 = aloghRBIG1,          # n * nScan : each column contains predicted loghR for collected test sets, for Z = 1.
                aDloghRBIG = aDloghRBIG,          # n * nScan : each column contains loghR(Z=1) - loghR(Z=0).

                apRUnSortBIG = apRUnSortBIG,      # n * nScan : each col. contains Z=1 to Z=0 P-value for threshold at this DloghR.
                ahRUnSortBIG = ahRUnSortBIG,      # n * nScan :  each col. contains Z=1 to Z=0 hR for threshold at this DloghR.
                arankBIG = arankBIG,              # n * nScan : in each col., for each sample in original order, its rank in terms of DloghR.
                # ................................................................................
                # . >> SORTED arrays below :
                # ................................................................................
                aDloghRSortBIG = aDloghRSortBIG,  # n * nScan : each column contains DloghR = loghR(Z=1) - loghR(Z=0), sorted in increasing order.
                indexSortBIG = indexSortBIG,      # n * nScan : each column contains the sort index: aDloghRSort =  aDloghR[indexSort].
                apRSortBIG = apRSortBIG,          # n * nScan : each column contains P-values for Z=1 to Z=0 comparisons, in sort order.
                ahRSortBIG = ahRSortBIG,          # n * nScan : each column contains hR's for Z=1 to Z=0 comparisons, in sort order.

                flagComputeRES = flagComputeRES,  # Indicates whether computation of pR and hR profile has been done for the *resistant* subset.
                apRSortRESBIG = apRSortRESBIG,    # n * nScan : each column contains P-values for Z=1 to Z=0 comparisons, in sort order, for RESISTANT subset.
                ahRSortRESBIG = ahRSortRESBIG,    # n * nScan : each column contains hR's for Z=1 to Z=0 comparisons, in sort order, for RESISTANT subset.
                # ................................................................................
                # . Quantities obtained for maximum P-values :
                # ................................................................................        
                ahRCBIG = ahRCBIG,                # nScan : optimal hR = hRC, for selecting patients predicted to be sensitive by hR <= hRC filter.        
                aicMinBIG = aicMinBIG,            # nScan : number of patients selected by hR <= hRC filter.
                apRMin = apRMin,                  # nScan : P-value for Z = 1 to Z = 1 comparisons, at best hRC.
                ahRMin = ahRMin,                   # nScan : vector.
                # ................................................................................
                # . This is the model for survival times regressed against DloghR and Z.
                # ................................................................................
                cModel = cCov$cModel
                # ................................................................................                
        );          

      cv$cvType = 'single';
      
      class(cv) = 'basic.cox.cov.cv';
      # ........................................................................................      

    

      # .............
      return (cv);
      # .............
  
}

# =================================================================================================
# . End of SuperPc.packagecCovIntoCv.
# =================================================================================================






# =========================================================================================================
# . SuperPc.computeLeftRightStats : this is essentially a utility function to be used for generating
# . -----------------------------   ROCs in linear regression or other models.
# .
# .  * Given an input array y, and an index j0, this function computes the "left" and
# .    "right" statistics :
# .
# .            yL = mean of all y for which j <= j0 .
# .            sL = standard deviation of all y for which j <= j0 .
# .            yR = mean of all y for which j >= j0 .
# .            sR = standard deviation of all y for which j >= j0 .
# .        pvalLR = P-value; t-test between left and right populations (not quite consistent, as it
# .                 counts point j0 in both groups).
# .
# .   Syntax:
# .
# .       lr = SuperPc.computeLeftRightStats(y, j);
# .
# .   In:
# .            y = input array, of length n > 0.
# .
# .            j0 = index for split, must be in range 1 <= j <= n.
# .
# .   Out:
# .          lr = list with members {yR, sR, yL, sL} as defined above.
# .
# ==========================================================================================================

SuperPc.computeLeftRightStats <- function(y, j0)
{

      # ........................................
      # . Check on values :
      # ........................................  
      n = length(y);
      stopifnot(j0 >= 1, j0 <= n);
      # ........................................


      
      # ........................................................................................
      # . Compute the running left-and-right statistics :
      # ........................................................................................
      yL = mean(y[1:j0]);   # Mean of all y for which j <= j0 .
      sL = sd(y[1:j0]);     # Standard deviation of all y for which j <= j0 .
      yR = mean(y[j0:n]);   # Mean of all y for which j >= j0 .      
      sR = sd(y[j0:n]);     # standard deviation of all y for which j >= j0 .

      buf = t.test(y[1:j0], y[j0:n], var.equal = TRUE);   # t-test between the two groups.
      pvalLR = buf$p.value;                               # Note that the j0 element is in both groups.
      # ........................................................................................


      
      # .........................................
      # . Package the results :
      # .........................................
      lr = list(yL = yL,
                sL = sL,
                yR = yR,
                sR = sR,
                pvalLR = pvalLR);
      # .........................................
      
     
      # ...........
      return (lr);
      # ...........

}

# ==========================================================================================================
# . End of SuperPc.computeLeftRightStats.
# ==========================================================================================================






# =========================================================================================================
# . SuperPc.computeLeftRightCoxStats : this is essentially a utility function to be used for generating
# . --------------------------------   ROCs in linear regression or other models.
# .
# .  * Given input arrays of time and censoring statues (at, as), and an index j0, this function computes the "left" and
# .    "right" statistics :
# .
# .            tL = median survival time for all samples for which j <= j0 .
# .            tR = median survival time for all samples for which j >= j0.
# .           hLR = hazard ratio for comparison of samples with j <= j0 and j >= j0.
# .        pvalLR = P-value; not quite consistent, as it counts point j0 in both groups.
# .
# .   Syntax:
# .
# .       lr = SuperPc.computeLeftRightCoxStats(at, as, j);
# .
# .   In:
# .            at = input times array, of length n > 0.
# .            as = input censoring array, of length n > 0.
# .
# .            j0 = index for split, must be in range 1 <= j <= n.
# .
# .   Out:
# .          lr = list with members {tL, tR, loghLR, pvalLR} as defined above.
# .
# ==========================================================================================================

SuperPc.computeLeftRightCoxStats <- function(at, as, j0)
{

      # ........................................
      # . Check on values :
      # ........................................  
      n = length(at);
      stopifnot(j0 >= 1, j0 <= n);
      # ........................................


      
      # ........................................................................................
      # . Compute the running left-and-right statistics :
      # ........................................................................................
      atL = at[1:j0];
      asL = as[1:j0];      

      atR = at[j0:n];
      asR = as[j0:n];            

      #xxx bufL = Cox.computeTimes(atL, asL);
      #xxx bufR = Cox.computeTimes(atR, asR);

      tL = median(atL);            # Crude statistic for LHS events. Note that this is NOT the median time-to-event.
      tR = median(atR);            # Crude statistic for RHS events. Note that this is NOT the median time-to-event.
      # ........................................................................................
      # . Compare left and right populations : note that I've kept sample j0 common to *both*
      # . L and R groups. This may not make perfect sense, but I'm too lazy to change.
      # . Model is loghR = beta * z, where z = 0 for L and 1 for R samples.
      # ........................................................................................      
      atBuf = c(atL, atR);                                                      # Concatenate L and R times.
      asBuf = c(asL, asR);                                                      # Concatenate L and R censoring statuses.
      abinBuf = c(rep(0, times = length(atL)), rep(1, times = length(atR)));    # L and R indicator : L = 0, R = 1.

      coxB = coxph(Surv(atBuf, asBuf) ~ abinBuf);
      coxBsum = summary(coxB);
      coxBcoef = coxBsum$coef;                          # Contains the coefficient and P-value.
      
      loghLR = coxBcoef[ , 1];                          # The Cox coefficient = log-hazard-ratio for R relative to L.
      #xxxx hLR = exp(beta);                            # Hazard ratio of R relative to L.
      pvalLR = coxBcoef[ , 5];                          # The corresponding P-value.
      # ........................................................................................


      
      # .........................................
      # . Package the results :
      # .........................................
      lr = list(tL = tL,
                tR = tR,
                loghLR = loghLR,
                pvalLR = pvalLR);
      # .........................................
      
     
      # ...........
      return (lr);
      # ...........

}

# ==========================================================================================================
# . End of SuperPc.computeLeftRightCoxStats.
# ==========================================================================================================




# =================================================================================================
# . SuperPc.checkDataMatricesForGlmnetRegressCv : checks compatibility of the numerical data frame and the
# . ------------------------------------------   experimental design data frame for cross-validation of
# .                                              regression models using glmnet.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForGlmnetRegressCv(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                   tSplit = factor in dfE defining the further subdivision of the training
# .                            set members into train and test sets for the cross-validation.
# .                            values = 'train' denote the training set members in that group,
# .                            values = 'test' denote the test set members in that group.
# .                            values = 'NONE' are not included. All other values are invalid.
# .
# .                            If tSplit = 'NONE'itself, then checks on this field are not done
# .                            (it is ignored).
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .      - dfE has factor tSplit (check done only if tSplit not equal to 'NONE').
# .      - for the indicated factor tSplit (for non-NONE value), values in dfE 
# .        are either 'train', 'test' or 'NONE', and that the resulting training and
# .        test sets each have at least two member.
# .
# =================================================================================================

SuperPc.checkDataMatricesForGlmnetRegressCv <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .................................................................................................
    # . Failsafe check on existence of required members :
    # .................................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$tSplit)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: inparam does not have member tSplit";
      stop(msg);
    }

    if (is.null(inparam$alpha)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: inparam does not have member alpha";
      stop(msg);
    }

    if (is.null(inparam$lambda)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: inparam does not have member lambda";
      stop(msg);
    }        
    # .......................................................................................    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }

    if (is.null(dfE[[inparam$tY]])) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";      
      msg = paste(msg, "the factor tY = ", inparam$tY,
                  " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (inparam$methodSplit == 'given') {
      if (is.null(dfE[[inparam$tSplit]])) {
        msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";              
        msg = paste(msg, "the factor inparam$tSplit = ", inparam$tSplit,
                         " does not exist in the input experimental design,", sep = "");
        msg = paste(msg, " but is required under methodSplit = given.", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;                                       # All samples are in the training set.
      nNone = 0;                                        # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                       " records with values for factor ", inparam$tTrain , " = train. " ,
                       " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Check train/test split. Compute ntrainCV, ntestCV.
    # .
    # . >> methodSplit = given :
    # .......................................................................................
    if (inparam$methodSplit == 'given') {    
      if (inparam$tTrain != 'NONE') {        
        dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ]; # The training set is a subset.
      } else if (inparam$tTrain == 'NONE') {
        dfETrain = dfE;                                     # The training set is the entire set.
      }

      buf = dfETrain[[inparam$tSplit]];
      bufEx = buf[(buf != 'train') & (buf != 'test') & (buf != 'NONE')];

      if (length(bufEx) > 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";         
        msg = paste(msg, "the input experimental design for factor inparam$tSplit = ", inparam$tSplit,
                         "has invalid values, which are neither train, test or NONE.", sep = "");
        return (msg);
      }

      nTrainCv = sum(dfETrain[[inparam$tSplit]] == 'train');   # Number of cv training set members.
      nTestCv = sum(dfETrain[[inparam$tSplit]] == 'test');     # Number of cv test set members.      
    
      if (nTrainCv == 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";
        msg = paste(msg, "the input experimental design has 0 cv training set ",
                         "records with values for factor ",
                         inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTrainCv < 2) {
        msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";        
        msg = paste(msg, "the input experimental design has only nTrainCv = ", nTrainCv,
                         " records with values for factor ", inparam$tSplit , " = train. " ,
                         " The minimum number is 2. ", sep = "");
        return (msg);
      }

      if (nTestCv == 0) {
        msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";        
        msg = paste(msg, "the input experimental design has 0 cv test set ",
                    "records with values for factor ",
                    inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTestCv < 2) {
        msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv: ";        
        msg = paste("the input experimental design has only nTestCv = ", nTestCv,
                    " records with values for factor ", inparam$tSplit , " = test. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . >> methodSplit = vfoldStrict :
    # .    
    # .    
    # ...................................................................................
    if (inparam$methodSplit == 'vfoldStrict') {
      csTemp = Stat.generateSplitsForVfold(nTrain, inparam$ft, flagRandom = FALSE);
      nTestCv = csTemp$ntest;

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }    
    # .....................................................................................



    # .......................................................................................
    # . For logistic models, check that the designated output variable is indeed
    # . binary, Y e {0, 1}.
    # .......................................................................................
    if (inparam$modelType == 'logistic') {
      msgBin = Cox.checkBinary(dfE[[inparam$tY]]);

      if (msgBin != 'ok') {
        cat("ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv:\n", sep = "");
        cat("For the designated output variable factor tY = ", inparam$tY, "\n", sep = "");
        cat(msgBin);
        stop();
      }

      n1 = sum(dfE[[inparam$tY]]);    # Number of instances with y = 1.

      if (n1 == n) {
        cat("ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv:\n", sep = "");
        cat("All values of output variable Y are equal to 1.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }

      if (n1 == 0) {
        cat("ERROR: from SuperPc.checkDataMatricesForGlmnetRegressCv:\n", sep = "");
        cat("All values of output variable Y are equal to 0.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }      
    }
    # .......................................................................................        
    
    
    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");

    cat("             Given cross-validation split of training set :\n", sep = "");      
    cat("             Training set : nTrainCv = ", nTrainCv, "\n", sep = "");
    cat("             Test set : nTestCv = ", nTestCv, "\n", sep = "");
    # .......................................................................................



    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForGlmnetRegressCv.
# =================================================================================================






# =================================================================================================
# . SuperPc.checkDataMatricesForGlmnetRegress : checks compatibility of the numerical data frame and the
# . ------------------------------------------   experimental design data frame for
# .                                              regression models using glmnet.
# .
# .  Syntax :
# . 
# .             msg = SuperPc.checkDataMatricesForGlmnetRegress(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .      - dfE has factor tSplit (check done only if tSplit not equal to 'NONE').
# .      - for the indicated factor tSplit (for non-NONE value), values in dfE 
# .        are either 'train', 'test' or 'NONE', and that the resulting training and
# .        test sets each have at least two member.
# .
# =================================================================================================

SuperPc.checkDataMatricesForGlmnetRegress <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .................................................................................................
    # . Failsafe check on existence of required members :
    # .................................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegress: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$alpha)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegress: inparam does not have member alpha";
      stop(msg);
    }

    if (is.null(inparam$lambda)) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegress: inparam does not have member lambda";
      stop(msg);
    }        
    # .......................................................................................    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegress: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }

    if (is.null(dfE[[inparam$tY]])) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegress: ";      
      msg = paste(msg, "the factor tY = ", inparam$tY,
                  " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegress: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;                                       # All samples are in the training set.
      nNone = 0;                                        # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegress: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from SuperPc.checkDataMatricesForGlmnetRegress: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                       " records with values for factor ", inparam$tTrain , " = train. " ,
                       " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................


    

    # .......................................................................................
    # . For logistic models, check that the designated output variable is indeed
    # . binary, Y e {0, 1}.
    # .......................................................................................
    if (inparam$modelType == 'logistic') {
      msgBin = Cox.checkBinary(dfE[[inparam$tY]]);

      if (msgBin != 'ok') {
        cat("ERROR: from SuperPc.checkDataMatricesForGlmnetRegress:\n", sep = "");
        cat("For the designated output variable factor tY = ", inparam$tY, "\n", sep = "");
        cat(msgBin);
        stop();
      }

      n1 = sum(dfE[[inparam$tY]]);    # Number of instances with y = 1.

      if (n1 == n) {
        cat("ERROR: from SuperPc.checkDataMatricesForGlmnetRegress:\n", sep = "");
        cat("All values of output variable Y are equal to 1.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }

      if (n1 == 0) {
        cat("ERROR: from SuperPc.checkDataMatricesForGlmnetRegress:\n", sep = "");
        cat("All values of output variable Y are equal to 0.\n", sep = "");
        cat("We cannot train without a mix of 0 and 1 values.\n", sep = "");
        stop();
      }      
    }
    # .......................................................................................        
    
    
    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");
    # .......................................................................................



    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of SuperPc.checkDataMatricesForGlmnetRegress.
# =================================================================================================
