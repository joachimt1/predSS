# =================================================================================================
# . BasicCox.r : functions to implement the basic Cox models on gene expression data.
# . ----------   These are the counterparts to many implemented in package SuperPc.r,
# .              but do not rely on supervised primcipal components : regression is done
# .              directly on the individual gene expression levels.
# .
# =================================================================================================

library(survival);

BasicCox.NZMAX = 5;      # Maximum number of distinct values for external covariate.

# ========================================================================================================
# . BasicCox.checkDataMatricesForCoxCvWithCov : checks compatibility of the numerical data frame and the
# . -----------------------------------------   experimental design data frame for cross-validation of
# .                                            Cox proportional hazard model.
# .
# .  Syntax :
# . 
# .             msg = BasicCox.checkDataMatricesForCoxCvWithCov(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                   tSplit = factor in dfE defining the further subdivision of the training
# .                            set members into train and test sets for the cross-validation.
# .                            values = 'train' denote the training set members in that group,
# .                            values = 'test' denote the test set members in that group.
# .                            values = 'NONE' are not included. All other values are invalid.
# .
# .                            If tSplit = 'NONE'itself, then checks on this field are not done
# .                            (it is ignored).
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .      - dfE has factor tSplit (check done only if tSplit not equal to 'NONE').
# .      - for the indicated factor tSplit (for non-NONE value), values in dfE 
# .        are either 'train', 'test' or 'NONE', and that the resulting training and
# .        test sets each have at least two member.
# .
# ========================================================================================================

BasicCox.checkDataMatricesForCoxCvWithCov <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$tSplit)) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: inparam does not have member tSplit";
      stop(msg);
    }
    # .......................................................................................    


    
    # .......................................................................................
    stopifnot((inparam$methodSplit == 'given') || (inparam$methodSplit == 'vfold')
              || (inparam$methodSplit == 'vfoldStrict'));
    # .......................................................................................

    

    # .......................................................................................
    # . Check existence of basic factors :
    # .......................................................................................
    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................
    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }

    if (inparam$methodSplit == 'given') {
      if (is.null(dfE[[inparam$tSplit]])) {
        msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";              
        msg = paste(msg, "the factor inparam$tSplit = ", inparam$tSplit,
                         " does not exist in the input experimental design,", sep = "");
        msg = paste(msg, " but is required under methodSplit = given.", sep = "");
        return (msg);
      }
    }    
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................


    
    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;    # All samples are in the training set.
      nNone = 0;     # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                   " records with values for factor ", inparam$tTrain , " = train. " ,
                   " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................



    
    # .......................................................................................
    # . Check train/test split. Compute ntrainCV, ntestCV.
    # .
    # . >> methodSplit = given :
    # .......................................................................................
    if (inparam$methodSplit == 'given') {    
      if (inparam$tTrain != 'NONE') {        
        dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ]; # The training set is a subset.
      } else if (inparam$tTrain == 'NONE') {
        dfETrain = dfE;                                     # The training set is the entire set.
      }

      buf = dfETrain[[inparam$tSplit]];
      bufEx = buf[(buf != 'train') & (buf != 'test') & (buf != 'NONE')];

      if (length(bufEx) > 0) {
        msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";         
        msg = paste(msg, "the input experimental design for factor inparam$tSplit = ", inparam$tSplit,
                         "has invalid values, which are neither train, test or NONE.", sep = "");
        return (msg);
      }

      nTrainCv = sum(dfETrain[[inparam$tSplit]] == 'train');   # Number of cv training set members.
      nTestCv = sum(dfETrain[[inparam$tSplit]] == 'test');     # Number of cv test set members.      
    
      if (nTrainCv == 0) {
        msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";
        msg = paste(msg, "the input experimental design has 0 cv training set ",
                         "records with values for factor ",
                         inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTrainCv < 2) {
        msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";        
        msg = paste(msg, "the input experimental design has only nTrainCv = ", nTrainCv,
                         " records with values for factor ", inparam$tSplit , " = train. " ,
                         " The minimum number is 2. ", sep = "");
        return (msg);
      }

      if (nTestCv == 0) {
        msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";        
        msg = paste(msg, "the input experimental design has 0 cv test set ",
                    "records with values for factor ",
                    inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTestCv < 2) {
        msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov: ";        
        msg = paste("the input experimental design has only nTestCv = ", nTestCv,
                    " records with values for factor ", inparam$tSplit , " = test. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . >> methodSplit = vfold :
    # .    The training set and the test set must each have at least 2 elements.
    # .    Note that we require above that nTrain >= 4, so that this is always possible.
    # ...................................................................................
    if (inparam$methodSplit == 'vfold') {
      nTestCv = floor(nTrain * inparam$ft);

      if (nTestCv < 2) {
        nTestCv = 2;                    # At least 2 elements in the test set.
      }

      n1 = nTrain - 1;

      if (nTestCv >= n1) {
        nTestCv = nTrain - 2;           # At least 2 elements in the training set.
      }

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }
    # .......................................................................................
    # . >> methodSplit = vfoldStrict :
    # .    
    # .    
    # ...................................................................................
    if (inparam$methodSplit == 'vfoldStrict') {
      csTemp = Stat.generateSplitsForVfold(nTrain, inparam$ft, flagRandom = FALSE);
      nTestCv = csTemp$ntest;

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }    
    # .....................................................................................



    
    # .......................................................................................
    # . Check on the external covariate :
    # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
    # . Note that this applies only to the cross-validation program, and not to the
    # . feature selection or model building cases.
    # .......................................................................................    
    msgBin = Cox.checkBinary(dfE[[inparam$tCov]]);

    if (msgBin != 'ok') {
      msg = paste("ERROR: from BasicCox.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, msgBin);

      return(msg);
    }
    # .......................................................................................

    

    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");

    cat("             Given cross-validation split of training set :\n", sep = "");      
    cat("             Training set : nTrainCv = ", nTrainCv, "\n", sep = "");
    cat("             Test set : nTestCv = ", nTestCv, "\n", sep = "");
    # .......................................................................................



    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of BasicCox.checkDataMatricesForCoxCvWithCov.
# =================================================================================================






# =================================================================================================
# . BasicCox.computeCoxWithCov : computes a Cox proportional hazards model, given
# . --------------------------   an explicit input data matrix.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .       cSel = BasicCox.computeCoxWithCov(at, as, az, dfX, flagCenter);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = n * m : data matrix of gene expression data.
# .
# .    flagCenter = 'yes', mean-center the columns (genes) of the input data matrix.
# .                  'no', do not mean-center the columns.
# .
# .
# .   Out:
# .        cSel = list, with members:
# .
# .         abeta         # m Cox coefficients for the genes.
# .         aseBeta       # m std. err. for the gene-by-gene coeffs.
# .         apBeta        # m P-values for the gene-by-gene coeffs.
# .
# .         betaZ         # Coeff. for the external covariate.
# .         seBetaZ       # Std. err. for external covariate coeff.
# .         pBetaZ        # P-values for external covaraite coeff.
# .      
# .         agamma        # m interaction terms coeffs.
# .         aseGamma      # m std. err. for interaction terms coeffs.
# .         apGamma       # m P-values for the interaction terms.
# .
# .         qR            # Loglikelihood ratio statistic (df = 2 * K + 1).          
# .         pR            # P-value for loglikelihood ratio statistic.
# .         coxK          # Final Cox model on K principal components.
# . 
# =================================================================================================

BasicCox.computeCoxWithCov <- function(at, as, az, dfX, flagCenter)
{

      # ....................
      n = nrow(dfX);      
      m = ncol(dfX);
      # ....................


      # .................................................................................
      # . Check on lengths of arrays :
      # .................................................................................      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.      

      if (nt != n) {
        msg = "ERROR: from BasicCox.computeCoxWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from BasicCox.computeCoxWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from BasicCox.computeCoxWithCov: ";
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      stopifnot((flagCenter == 'yes') || (flagCenter == 'no'));
      # .................................................................................

      

      # .......................................................................................
      # . If requested, mean-center the columns (genes) of the input data matrix :
      # .......................................................................................
      if (flagCenter == 'yes') {
        axm = colMeans(dfX);                                     # Save the column means.
        dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.
      } else {
        axm = rep(0.0, times = m);                               # The values subtracted are 0.
        dfXc = as.matrix(dfX);                                   # No centering.
      }
      # .......................................................................................

      

      # .......................................................................................
      # . Cox proportional hazard model with dependence on the genes and on
      # . the external covariate, with interaction terms included.
      # . Coeffcients are returned in order (here for say m = 3) :
      # . x1, x2, x3, az, x1:az, x2:az, x3:az
      # .......................................................................................      
      coxK = coxph(Surv(at, as) ~ dfXc + az + az * dfXc);       # Cox model on 2 * m + 1 variables.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);       # Likelihood ratio statistic.
      dfTemp = 2 * m + 1;                                 # Degrees of freedom.
      pR = pchisq(qR, df = dfTemp, lower.tail = FALSE);   # p-value from likelihood ratio.
      
      coxKsum = summary(coxK);
      coxKcoef = coxKsum$coef;        # Contains 2 * m + 1 coefficients and P-values.
      # ..................................................................................
      # . Extract the various coefficients, std. errs. and attendant P-values :
      # ..................................................................................      
      abeta = coxKcoef[1:m , 1];       # m Cox coefficients for the genes.
      aseBeta = coxKcoef[1:m , 3];     # m std. err. for the gene-by-gene coeffs.
      apBeta = coxKcoef[1:m , 5];      # m P-values for the gene-by-gene coeffs.

      m1 = m + 1;

      betaZ = coxKcoef[m1 , 1];        # Coeff. for the external covariate.
      seBetaZ = coxKcoef[m1 , 3];      # Std. err. for external covariate coeff.
      pBetaZ = coxKcoef[m1 , 5];       # P-value for external covariate coeff.

      ma = m + 2;
      mb = 2 * m + 1;
      
      agamma = coxKcoef[ma:mb , 1];     # m interaction terms coeffs.
      aseGamma = coxKcoef[ma:mb , 3];   # m std. err. for interaction terms coeffs.
      apGamma = coxKcoef[ma:mb , 5];    # m P-values for the interaction terms.
      # .......................................................................................
      # . If x is the gene expression vector, then the Cox model computed is :
      # .
      # .     lambda(t|x, z) = lambda_0(t) *
      # .
      # .                              T                                T
      # .                      exp(beta  . x  +  betaZ . z  +  z . gamma . x)
      # .
      # .......................................................................................      



      # ..................................................
      # . Retrieve column (gene) names for packaging :
      # ..................................................
      ac = colnames(dfX)
      # ..................................................

      

      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      cSel = list(n = n,                   # Number of samples.
                  m = m,                   # Number of genes.
                  flagCenter = flagCenter, # Was data column (gene) - centered?
                  ac = ac,                 # Data matrix column (gene) names.
                  axm = axm,               # Values used for mean-centering (= 0 if flagCenter = no).
                  abeta = abeta,           # m : the gene Cox coefficients.
                  aseBeta = aseBeta,       # m : standard errors for the gene Cox coefficients.
                  apBeta= apBeta,          # m : P-values for the gene Cox coefficients.
                  betaZ = betaZ,           # External covariate Cox coeff.
                  seBetaZ = seBetaZ,       # External covariate coeff std. err.
                  pBetaZ = pBetaZ,         # External covariate coeff P-value.
                  agamma = agamma,         # m : the interaction terms.
                  aseGamma = aseGamma,     # m : standard errors for interaction terms.
                  apGamma= apGamma,        # m : P-values for interaction terms.    
                  qR = qR,                 # Loglikelihood ratio statistic (df = 2 * m + 1).
                  pR = pR,                 # P-value for loglikelihood ratio statistic.
                  coxK = coxK);            # Final Cox model.

      class(cSel) = 'basic.cox.cov';
      # .......................................................................................

      
      # .............
      return (cSel);
      # .............
      

}

# =================================================================================================
# . End of BasicCox.computeCoxWithCov.
# =================================================================================================







# =================================================================================================
# . BasicCox.computeBaselineHazardNoTiesWithCov : computes the baseline hazard function, using the results
# . -------------------------------------------   of BasicCox.computeCoxWithCov(). This is
# .                                               a simplified form of the Breslow estimator that assumes
# .                                               that there are no ties in the data.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .          bh = BasicCox.computeBaselineHazardNoTiesWithCov(at, as, cSel, dfXSel);
# .
# .   In:
# .         at = n : vector of survival times (n = number of samples).
# .
# .         as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .         az = n : vector for external covariate.
# .
# .       cSel = result of supervised principal components computation, returned
# .              by function BasicCox.computeCoxWithCov().
# .
# .     dfXSel = input data frame, subsetted to the feature-selected genes that
# .              were used in the supervised principal components calculation.
# .
# .   Out:
# .      bh = list with members :
# .
# .                       n =  Number of time points.
# .                  atSort =  Array of (sorted) time points.
# .         aLambdaBaseDiff =  Differential baseline hazard function, sorted order.
# .             aLambdaBase =  Baseline hazard function, sorted order.
# .                  aSBase =  Baseline survival function, sorted order.
# .                  aMSort =  Martingale residuals in sorted order.
# .                            All three aLambdaBaseDiff, aLambdaBase and
# .                            (sorted order == keyed on sorted time array, atSort).
# .                      aM =  Martingale residuals in original, unsorted order.
# .
# .................................................................................................
# . We are applying the Breslow estimator for the cumulative hazard function (see. Zhang ST 745,
# . p. 213) :
# .                           _                             _
# .                          |                               | 
# .                          |           dN(x)               | 
# .    Lambda  (t) =    sum  | ----------------------------- | 
# .          0         x < t |    n                          | 
# .                          |   sum   Y (x) exp(beta * z )  | 
# .                          |   l = 1  l                l   | 
# .                          |_                             _|
# .
# . where dN(x) = 1 if there was a death at time x, 0 otherwise (that is, if event was censored)
# .
# =================================================================================================

BasicCox.computeBaselineHazardNoTiesWithCov <- function(at, as, az, cSel, dfXSel)
{

      # ..................................................................................
      if ((class(cSel) != "basic.cox.cov") && (class(cSel) != "glmnet.cox.cov.sel")) {
        msg = "ERROR: from BasicCox.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("The input cSel is not of class: basic.cox.cov, glmnet.cox.cov.sel");
        stop(msg);
      }
      # ..................................................................................


      # ....................
      n = nrow(dfXSel);      
      m = ncol(dfXSel);
      # ....................


      
      # .................................................................................
      # . Check on lengths of arrays :
      # .................................................................................      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.      

      if (nt != n) {
        msg = "ERROR: from BasicCox.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from BasicCox.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from BasicCox.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      # .................................................................................

      

      
      # ..............................................................................
      # . Check consistency of the input data matrix with the cSel object
      # . and with the array of mean values used for centering.
      # ..............................................................................      
      mHere = length(cSel$abeta);        # abeta : gene-by-gene Cox coefficients.
      
      if (mHere != m) {
        msg = "ERROR: from BasicCox.computeBaselineHazardNoTiesWithCov: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("genes as in the input cSel object.", sep = "");
        msg = paste(" dfXSel has m = " , m, " genes.", sep = "");
        msg = paste(" cSel$avSel has = " , mHere, " genes.", sep = "");        
        stop(msg);
      }

#      mBuf = length(axm);

#      if (mBuf != m) {
#        msg = "ERROR: from BasicCox.computeBaselineHazardNoTiesWithCov: ";
#        msg = paste("Input data matrix does not have the same number of ", sep = "");
#        msg = paste("genes as the array of mean values .", sep = "");
#        msg = paste(" dfXSel has m = " , m, " genes.", sep = "");
#        msg = paste(" axm has = " , mBuf, " genes.", sep = "");        
#        stop(msg);
#      }      
      # ...............................................................................


      
      
      # ...................................................................................
      # . Compute the log-hazard ratio for each sample :
      # .
      # .                      lambda(t|xi, z)
      # .       aloghR  =  log ---------------
      # .                        lambda (t)
      # .                              0
      # . where xi = vector or principal components and z = external covariate.
      # .      
      # . We first compute the n * K matrix of principal componenst.
      # .
      # .           -                       -
      # .           |xi    xi    . . . xi   |
      # .           |  11    12          1K |
      # .       Y = |                       |
      # .           | . . .      . . .   .  |
      # .           |                       |
      # .           |xi    xi    . . . xi   |
      # .           |  n1    n2          nK |
      # .           -                       -
      # .
      # . where :
      # .               T
      # .     xi    =  v  . x   ,  l = 1, 2, . . ., K
      # .       il      l    i
      # .
      # . where v  is the l-the principal component vector (n components)
      # .        l
      # . and x  the i-th sample vector (n components).
      # .      i
      # .      
      # . We then compute the log-hazard ratios for all the samples, given by :
      # .
      # .                T                            T
      # .   aloghR   = xi  . beta  + beta  . z  + z xi  . gamma  , i = 1, 2, . . ., n.
      # .         i      i               Z    i       i
      # .
      # ...................................................................................
      # . Y = n * m matrix of gene expression values.
      # ...................................................................................      
      #xxx Y = sweep(dfXSel, 2, axm);                   # Center columns (genes) on offsets.
      Y = dfXSel;                                       # I'm assuming the columns already centered.
      zY = sweep(Y, 1, az, FUN = "*");                  # n * m matrix. i-th row is z_i * xi_i.

      aBuf1 =  Y %*% cSel$abeta;                        # n vector, direct terms beta * y.
      aBuf2 =  zY %*% cSel$agamma;                      # n vector, interaction terms gamma * z * y.

      aloghR = aBuf1 + cSel$betaZ * az + aBuf2;         # n vector, log-hazard ratios.
      ahR = exp(aloghR);                                # n vector of hazard ratios exp(beta * y).
      # ...................................................................................
      

      # ...................................................................................
      # . Sort arrays so that samples are ordered with increasing event time :
      # ...................................................................................
      sBuf = sort(at, decreasing = FALSE, index.return = TRUE);    # Sort in increasing order.

      indexSort = sBuf[["ix"]];      # Sort index, used below in sorting the arrays.

      atSort = sBuf[["x"]];          # Sorted array of event times (i.e. sorted array at).
      asSort = as[indexSort];        # Sorted array of indicators (1 = death, 0 = censored) (i.e. deltas).
      ahRSort = ahR[indexSort];      # Sorted array of exp(beta * y).
      # ...................................................................................

      
      
      # ........................................................................................
      # . Build the occupation number array, YO, then use it to generate the denominator terms.
      # .
      # .                        ---------------------
      # .                        1   0   0   0   0   0
      # .    exp(beta * z)       1   1   0   0   0   0
      # .   -------------        1   1   1   0   0   0
      # .   |. . . . . . |  *    1   1   1   1   0   0  = n-array of denominator terms.
      # .   -------------        1   1   1   1   1   0 
      # .                        1   1   1   1   1   1 
      # .                        ---------------------
      # .
      # .      1 * n                    n * n                   1 * n
      # .
      # . Note that the numerators are just the status indicators (1 = death, 0 = censored).      
      # ........................................................................................
      YO = sapply(1:n, function(j){a = rep(0, times = n); a[j:n]= 1; return(a)});
      aBot = ahRSort %*% YO;                 # Denominators for contribution at event time atSort.
                                     
      aLambdaBaseDiff = asSort / aBot;       # Differential hazard estimate, for times atSort.
      aLambdaBase = cumsum(aLambdaBaseDiff); # Cumulative hazard function, for times atSort.
      aSBase = exp(-aLambdaBase);            # Estimate of baseline survival function, for times atSort.
      # ........................................................................................

      
      # ........................................................................................
      # . Compute the median survival time under baseline :
      # ........................................................................................
      abufL = which(aSBase >= 0.5);
      abufR = which(aSBase < 0.5);

      if (length(abufL) > 0) {
        iL = max(abufL);
      } else {
        iL = 1;
      }
      
      if (length(abufR) > 0) {
        iR = min(abufR);
      } else {
        iR = n;
      }

      tBaseMed = 0.5 * (atSort[iL] + atSort[iR]);    # Interpolation.
      # ........................................................................................            


      # ...................................................................................
      # . Compute the Martingale residuals for the training set :
      # .
      # .    M  =  delta   - exp(beta * Z ) * Lambda0(x )
      # .     i         i                i             i
      # ...................................................................................
      aMSort = asSort - ahRSort * aLambdaBase;     # Martingale residuals in sorted order.
      aM = rep(0.0, times = n);                    # Dummy initial values.
      aM[indexSort] = aMSort;                      # Martingale residuals in original order.
      # ...................................................................................            

      
      # ...............................................................................
      # . Package the results for the baseline hazard functions :
      # ...............................................................................
      bh = list(n = n,                                   # Number of time points.
                atSort = atSort,                         # Array of (sorted) time points.
                aLambdaBaseDiff = aLambdaBaseDiff,       # Differential baseline hazard function.
                aLambdaBase = aLambdaBase,               # Baseline hazard function.
                aSBase = aSBase,                         # Baseline survival function.
                tBaseMed = tBaseMed,                     # Median survival time under baseline.
                aMSort = aMSort,                         # Martingale residuals in sorted order.
                aM = aM);                                # Martingale residuals in original order.
      
      class(bh) = 'basic.cox.baseline.hazard';
      # ...............................................................................

      
      # ............
      return (bh);
      # ............
      
}

# =================================================================================================
# . End of BasicCox.computeBaselineHazardNoTiesWithCov.
# =================================================================================================      








# =================================================================================================
# . BasicCox.packageBasicCoxWithCov : creates an basic.cox.cov object from the explicit inputs. Used in packaging
# . -------------------------------   together partial results in the context of a cross-validation loop.
# .                             
# .   Syntax:
# .
# .      bc = BasicCox.packageBasicCoxWithCov();
# .
# .   In:
# .
# .           n   =    Number of samples.                               
# .           p   =    Number of genes.                                 
# .           axm =    p : column means (gene-by-gene means).           
# .         abeta =    K : the Cox coefficients.
# .       aseBeta =    K : standard errors for the Cox coefficients.
# .        apBeta =    K : P-values for the Cox coefficients.
# .         betaZ =    External covariate Cox coeff.
# .       seBetaZ =    External covariate coeff std. err.
# .        pBetaZ =    External covariate coeff std. err.        
# .        agamma =    K : the interaction terms.
# .      aseGamma =    K : standard errors for interaction terms.
# .       apGamma =    K : P-values for interaction terms.    
# .            ap =    K : the P-values for the Cox coefficents.            
# .            qR =    Loglikelihood ratio statistic (df = K).          
# .            pR =    P-value for loglikelihood ratio statistic.
# .          coxK =    Final Cox model on K principal components.
# .            bh =    Baseline hazard object.
# .
# .   Out:
# .
# .          bc = object of class basic.cox.cov
# .
# =================================================================================================

BasicCox.packageBasicCoxWithCov <- function(n, p, axm,
                                            abeta, aseBeta, apBeta,
                                            betaZ, seBetaZ, pBetaZ,
                                            agamma, aseGamma, apGamma,
                                            qR, pR,
                                            coxK, bh)
{

      # .......................................................................................
      # . Package the inputs :
      # .......................................................................................
      msg = 'ok';
      
      bc = list(msg = msg,                   # Output message.
                type = 'coxph',              # Type of regression.
                n   = n,                     # Number of samples.                               
                p   = p,                     # Number of genes.                                 
                axm = axm,                   # p : column means (gene-by-gene means).           
                abeta = abeta,               # K : the Cox coefficients.
                aseBeta = aseBeta,           # K : standard errors for the Cox coefficients.
                apBeta= apBeta,              # K : P-values for the Cox coefficients.
                betaZ = betaZ,               # External covariate Cox coeff.
                seBetaZ = seBetaZ,           # External covariate coeff std. err.
                pBetaZ = pBetaZ,             # External covariate coeff std. err.        
                agamma = agamma,             # K : the interaction terms.
                aseGamma = aseGamma,         # K : standard errors for interaction terms.
                apGamma = apGamma,           # K : P-values for interaction terms.            
                qR = qR,                     # Loglikelihood ratio statistic (df = K).          
                pR = pR,                     # P-value for loglikelihood ratio statistic.
                coxK = coxK,                 # Final Cox model on K principal components.
                bh = bh );                   # Baseline hazard object.
      
      class(bc) = 'basic.cox.cov';
      # .......................................................................................

      
      # .............
      return (bc);
      # .............
  
}

# =================================================================================================
# . End of BasicCox.packageBasicCoxWithCov.
# =================================================================================================






# =================================================================================================
# . BasicCox.computeCoxLogLikelihoodWithCov : computes the partial log-likelihood for an input data
# . --------------------------------------   matrix with an arbitrary set of samples (not necessarily
# .                                          the ones used in the training set).
# .
# .   Syntax:
# .          ll = BasicCox.computeCoxLogLikelihoodWithCov(bc, atIn, asIn, dfXIn);
# .
# .   In:
# .        bc = result of Cox regression model computation, returned
# .              by function BasicCox.computeCoxWithCov() or with method
# .              BasicCox.packageCoxWithCov().
# .
# .       atIn = n : vector of survival times (n = number of samples).
# .
# .       asIn = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .       azIn = n : vector of covariate values.
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .   Out:
# .     List ll, with members :
# .
# .                   lOut = l(beta = beta*)
# .                   lRatio = 2 * (l(beta = beta*) - l (beta = 0))
# .
# .      where l(beta) is the log partial likelihood evaluated for all the samples
# .      specified by the data {atIn, asIn, dfXIn}, with beta the K-dimensional
# .      coefficient vector for the K principal components (=  covariates),
# .      and where beta* is the MLE for beta estimated from the data in the training set
# .      which was used to compute bc.
# .
# .      Note that the log-likelihood ratio compares the model computed   
# .      with beta = beta* with a model with beta = 0 :                     
# .                                                                                  
# .                lRatio = 2 * (l(beta*) - l(0))                                         
# .                                                                                  
# .      Under the null hypothesis H0: beta = 0, and with beta* derived from the     
# .      actual input data set, or from a data set from the same population, we should    
# .      approximately have  lRatio ~ Chi2 with K degrees of freedom.
# .
# =================================================================================================

BasicCox.computeCoxLogLikelihoodWithCov <- function(bc, atIn, asIn, azIn, dfXIn)
{

      # ...........................................................
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCox.computeCoxLogLikelihoodWithCov: ";
        msg = paste("The input bc is not of class basic.cox.cov.");
        stop(msg);
      }
      # ...........................................................      


      # ...................................................................................
      # . Check for consistency :
      # ...................................................................................      
      nIn = nrow(dfXIn);      # Number of samples in input data matrix.
      p = ncol(dfXIn);        # Number of genes in input data matrix.
      
      if (bc$p != p) {
        msg = "ERROR: from BasicCox.computeCoxLogLikelihoodWithCov: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("features as in the training data matrix.", sep = "");
        msg = paste(" Test has p = " , p, " genes.", sep = "");
        msg = paste(" Training has bc$p = " , bc$p, " genes.", sep = "");        
        stop(msg);
      }

      ntIn = length(atIn);   # Number of samples in survival time vector.
      nsIn = length(asIn);   # Number of samples in censoring status vector.
      nzIn = length(azIn);   # Number of samples in covariates vector.

      if (ntIn != nIn) {
        msg = "ERROR: from BasicCox.computeCoxLogLikelihoodWithCov: ";        
        msg = paste("The survival time vector atIn has ntIn = ", ntIn, "samples. ", sep = "");
        msg = paste("This is not the same as the nIn = ", nIn,
                    "samples in the data matrix dfXIn.", sep = "");        
        stop(msg);
      }

      if (nsIn != nIn) {
        msg = "ERROR: from BasicCox.computeCoxLogLikelihoodWithCov: ";        
        msg = paste("The censoring status vector asIn has nsIn = ", nsIn, "samples. ", sep = "");
        msg = paste("This is not the same as the nIn = ", nIn,
                    "samples in the data matrix dfXIn.", sep = "");        
        stop(msg);
      }

      if (nzIn != nIn) {
        msg = "ERROR: from BasicCox.computeCoxLogLikelihoodWithCov: ";        
        msg = paste("The covariate vector azIn has nzIn = ", nzIn, "samples. ", sep = "");
        msg = paste("This is not the same as the nIn = ", nIn,
                    "samples in the data matrix dfXIn.", sep = "");        
        stop(msg);
      }      
      # ......................................................................................



      # ...............................................................................
      # . Now compute the log partial likelihood l(beta = beta*), where beta is the 
      # . K-dimensional coefficient vector for the K principal components, and where 
      # . beta* is the MLE for beta estimated from the data in the training set that
      # . was used to compute spc.
      # ................................................................................
      Y = sweep(dfXIn, 2, bc$axm);                          # Mean-center the genes, using the mean from the training set.

      if (ncol(Y) == 1) {
        Y = Y[ , 1];                                        # For 1 gene, convert to numeric for compatibility with coxph below.
      }
      
      abetaInit = c(bc$abeta, bc$betaZ, bc$agamma);         # Beta vectors : {1:p, p+1, p+2:2*p+1}.
      nuncens = sum(asIn);                                  # Number of uncensored observations.

      if ((nuncens > 0) && (ntIn > 1)) {
        coxMLE = coxph(Surv(atIn, asIn) ~ Y + azIn + azIn * Y,
                       init = abetaInit,
                       control = coxph.control(iter.max = 0));           # No iterations.
      } else {
        coxMLE = list(loglik = c(0.0));       # Stand-in, for case where all observations are censored,
                                              # or just one observation.
      }

      lOut = coxMLE$loglik[1];
      # ................................................................................
      # . In addition, compute a log-likelihood ratio, comparing the model computed
      # . above with beta = beta*, to a model with beta = 0 :
      # .
      # .      lRatio = 2 * (l(beta*) - l(0))
      # .
      # . Under the null hypothesis H0: beta = 0, and with beta* derived from the
      # . actual input data set, or from a data set from the same population, we should 
      # . approximately have  lRatio ~ Chi2 with 2 * p + 1 degrees of freedom.
      # ................................................................................
      p21 = 2 * bc$p + 1;
      abetaNull = rep(0.0, times = p21);                               # Beta vectors all 0.

      if ((nuncens > 0) && (ntIn > 1)) {      
        coxNULL = coxph(Surv(atIn, asIn) ~ Y + azIn + azIn * Y,
                        init = abetaNull,
                        control = coxph.control(iter.max = 0));    # No iterations.
      } else {
        coxNULL = list(loglik = c(0.0));     # Stand-in, for case where all observations are censored,
                                             # or just one observation.        
      }

      lNull = coxNULL$loglik[1];
      lRatio = 2.0 * (lOut - lNull);               # Log likelihood ratio.
      # ................................................................................


      # ....................................................
      # . Package the results :
      # ....................................................
      ll = list(lOut = lOut, lRatio = lRatio);
      # ....................................................

      
      # .............
      return (ll);
      # .............
      
}

# =================================================================================================
# . End of BasicCox.computeCoxLogLikelihoodWithCov.
# =================================================================================================






# =================================================================================================
# . BasicCox.computeCoxLogHazardWithCov : computes the log-hazard ratios for an input data matrix 
# . -----------------------------------   with an arbitrary set of samples (not necessarily the ones 
# .                                       used in the training set).
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .          s = BasicCox.computeCoxLogHazardWithCov(bc, dfXIn, azIn);
# .
# .   In:
# .         bc = result of basic Cox multivariate computation, returned
# .              by function BasicCox.computeCoxWithCov().
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .       azIn = input vector of covariate values. It must have the same number of rows as dfX.
# .              Samples need not be the same as in the training set.
# .
# .   Out:
# .      s = list with members :
# .
# .              Y = nIn * p data matrix after mean-centering with the training set means.
# .                  nIn = number of rows in dfXIn.
# .
# .         aloghR = nIn vector of log-hazard ratios.
# .            ahR = nIn vector of hazard ratios.
# .          atMed = estimated median survival times.
# .
# =================================================================================================

BasicCox.computeCoxLogHazardWithCov <- function(bc, dfXIn, azIn)
{

      # ...........................................................
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCox.computeCoxLogHazardWithCov: ";
        msg = paste(msg, "The input bc is not of class basic.cox.cov");
        stop(msg);
      }
      # ...........................................................      


      # ..............................................................................
      p = ncol(dfXIn);
      n = nrow(dfXIn);
      
      if (bc$p != p) {
        msg = "ERROR: from BasicCox.computeCoxLogHazardWithCov: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste(msg, "features as in the training data matrix.", sep = "");
        msg = paste(msg, " Test has p = " , p, " genes.", sep = "");
        msg = paste(msg, " Training has bc$p = " , bc$p, " genes.", sep = "");
        stop(msg);
      }

      nz = length(azIn);

      if (nz != n) {
        cat("ERROR: from BasicCox.computeCoxLogHazardWithCov:\n");
        cat("Input external covariate array az has nz = ", nz, " elements. ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }      
      # ...............................................................................


      
      # ...................................................................................
      # . Compute the log-hazard ratios :
      # . first center the data using the means computed on the training set,
      # ...................................................................................
      Y = sweep(dfXIn, 2, bc$axm);                     # Center each column separately.      
      zY = sweep(Y, 1, azIn, FUN = "*");               # n * p matrix. i-th row is z_i * xi_i.

      if (ncol(Y) == 1) {
        aBuf1 =  Y * bc$abeta;                         # Special case for p = 1.
      } else {
        aBuf1 =  Y %*% bc$abeta;                       # n vector, direct terms beta * y.
      }

      if (ncol(Y) == 1) {
        aBuf2 =  zY * bc$agamma;                       # Special case for p = 1.
      } else {      
        aBuf2 =  zY %*% bc$agamma;                     # n vector, interaction terms gamma * z * y.
      }

      aloghR = aBuf1 + bc$betaZ * azIn + aBuf2;        # n vector, log-hazard ratios.
      ahR = exp(aloghR);                               # n vector of hazard ratios exp(beta * y).
      # ...................................................................................
      # . Compute estimated median survival times :
      # ...................................................................................
      bh = BasicCox.getBaselineHazard(bc);               # Baseline hazard information.
      atMed = SuperPc.computeTMedOnBaseline(bh, aloghR)  # Median survival time estimates.            
      # ...................................................................................


     
      # ..........................................................
      # . Package the results :
      # ..........................................................
      s = list(Y = Y, aloghR = aloghR, ahR = ahR, atMed = atMed);
      # ..........................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of SuperPc.computeCoxLogHazardWithCov.
# =================================================================================================      






# =================================================================================================
# . BasicCox.getBaselineHazard : returns the baseline hazard member of an bc object, prevously
# . -------------------------    computed in BasicCox.computeCox.
# .
# . Syntax :
# .
# .     bh = BasicCox.getBaselineHazard(bc);
# .
# . In:
# .     bc = object computed by BasicCox.computeCox() or BasicCox.computeCoxWithCov() functions.
# .
# . Out:
# .      bh = baseline hazard object, with members defined in
# .           BasicCox.computeBaselineHazardNoTies().
# .
# =================================================================================================

BasicCox.getBaselineHazard <- function(bc)
{

      # ............................................................................
      if ((class(bc) != "basic.cox") && (class(bc) != "basic.cox.cov")) {
        msg = "ERROR: from BasicCox.getBaselineHazard: ";
        msg = paste("The input bc is not of class basic.cox or class basic.cox.cov.");
        stop(msg);
      }

      if (is.null(bc$bh)) {
        cat("ERROR: from BasicCox.getBaselineHazard:\n");
        cat("The baseline hazard object bh was not assigned.\n");
        cat("See function BasicCox.computeBaselineHazardNoTies() for its computation.\n");
        msg ="";
        stop();
      }
      # .............................................................................


      # ................
      return (bc$bh);
      # ................

}

# =================================================================================================
# . End of BasicCox.getBaselineHazard.
# =================================================================================================






# =================================================================================================
# . BasicCox.computeMartingaleResiduals : computes Martingale residuals for a test set, using
# . ----------------------------------   hazard ratios and cumlative baseline hazard function
# .                                      computed using an independent (or the same) data set
# .                                      as trining set.
# .
# .   Syntax:
# .
# .        mr = BasicCox.computeMartingaleResiduals(bcTrain, atIn, asIn, ahRIn);
# .
# .   In:
# .              >>Training set :
# .
# .   bcTrain = result of supervised principal components computation, returned
# .              by function BasicCox.computeCox() or BasicCox.computeCoxWithCov().
# .
# .              >>Test set (which may be different or the same as the training set) :
# .
# .       atIn = nIn : vector of survival times (nIn = number of samples), not necessarily
# .                    the same as in bcTrain.
# .
# .       asIn = nIn : vector of censoring statuses (1 = not censored, 0 = censored).
# .                    The number of samples is not necessarily the same as in bcTrain.
# .
# .      ahRIn = result of computation of log hazard ratios for the test set.
# .              These are the values :
# .                             
# .                     exp(beta' . y  ), i = 1, 2, ... , nIn.
# .                                  i
# .
# .              This can be computed with (for no external covariate) :
# .
# .                  sl = BasicCox.computeCoxPcAndLogHazard(bc, dfXIn);
# .                  ahRIn = sl$ahR;
# .
# .              or with (with external covariate) :
# .
# .                  sl = BasicCox.computeCoxPcAndLogHazardWithCov(bc, dfXIn, azIn);
# .                  ahRIn = sl$ahR;
# .
# .              where dfXIn = input data frame with the nIn samples
# .              corresponding to atIn and asIn. dfXIn need not be the same
# .              data matrix as the one used in the training set, but it
# .              must have the same set of genes as in the training set.
# .              azIn is the corresponding vector of external covariates, for
# .              analysis with external covariate.
# .
# .   Out:
# .      mr = list with members :
# .             nIn = number of samples in input test set.
# .             atIn = nIn : input array of survival times.
# .             asIn = nIn : input array of censoring statuses.
# .             aM = nIn : output array of Martingale  residuals
# .                  for the input samples.
# .             Mrms = root-mean-square average of the Martingale residuals.
# .
# .................................................................................................
# . * The Martingale residuals are given by :
# .
# .           M  =  delta   - exp(beta' * Y ) * Lambda0(x )  ,   i = 1, 2, ...., nIn.
# .            i         i                 i             i
# .
# . where delta_i is the status indicator (delta_i = 1, not censored, delta_i = 0, censored),
# . beta = vector of coefficents, estimated from Cox proportional hazards model on the
# . training set, Y_i = V' * x_i = vector of principal components, computed using the principal
# . component vectors derived from the training set, and Lambda_0 is the baseline cumulative
# . hazard, also computed from the training set.
# .
# . * The root-mean-square value for the Martingale residuals is given by :
# .
# .                  1    nIn   2   1/2
# .       Mrms = ( -----  sum  M   )
# .                 nIn   i=1   i
# =================================================================================================

BasicCox.computeMartingaleResiduals <- function(bcTrain, atIn, asIn, ahRIn)
{

      # .....................................................................................
      if ((class(bcTrain) != "basic.cox")
          && (class(bcTrain) != "basic.cox.cov")) {
        msg = "ERROR: from BasicCox.computeMartingaleResiduals: ";
        msg = paste("The input bcTrain is not of class basic.cox or class basic.cox.cov.");
        stop(msg);
      }
      # .....................................................................................
      


      # ...................................................................................
      # . Check for consistency :
      # ...................................................................................      
      ntIn = length(atIn);       # Number of samples in survival time vector.
      nsIn = length(asIn);       # Number of samples in censoring status vector.
      nhRIn = length(ahRIn);     # Number of samples in hazard ratio vector.

      nIn = ntIn;                # Should be the same for all three input arrays.

      if (nsIn != nIn) {
        msg = "ERROR: from BasicCox.computeMartingaleResiduals: ";        
        msg = paste(msg, "The censoring status vector asIn has nsIn = ", nsIn, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the ntIn = ", nIn,
                    "samples in the survival time array atIn.", sep = "");        
        stop(msg);
      }

      if (nhRIn != nIn) {
        msg = "ERROR: from BasicCox.computeMartingaleResiduals: ";        
        msg = paste(msg, "The hazard ratio vector ahRIn has nhRIn = ", nhRIn, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the ntIn = ", nIn,
                    "samples in the survival time array atIn.", sep = "");        
        stop(msg);
      }      
      # ......................................................................................


      
      # ......................................................................................
      # . Get the baseline hazard information :
      # ......................................................................................      
      bh = BasicCox.getBaselineHazard(bcTrain);
      atSort = bh$atSort;
      aLambdaBase = bh$aLambdaBase;
      # ......................................................................................
      # . Find the indices in the training set array atSort which correspond
      # . to the test survival times : for each test set survival time tTest,
      # . map to the grid point for the largest tSort < tTest.
      # .
      # . Note that values of tTest < min(atSort) get mapped to index = 1 in atSort.
      # ......................................................................................
      tmin = min(atSort);               # Floor for grid values.
      
      indexAtSort = sapply(1:nIn,
                          function(j){imax = ifelse(atIn[j] > tmin,
                                             max(which(atSort <= atIn[j])), 1);
                                      return(imax);});
      
      aLambdaBaseIn = aLambdaBase[indexAtSort];
      # ......................................................................................
      # . Compute the Martingale residuals for the test set :
      # .
      # .    M  =  delta   - exp(beta * Y ) * Lambda0(x )
      # .     i         i                i             i
      # ......................................................................................
      aM = asIn - ahRIn * aLambdaBaseIn;     # Martingale residuals in non-sorted order.
      Mrms = sqrt(mean(aM * aM));            # Root mean square value.
      # .......................................................................................
      

     
      # ..........................................................
      # . Package the results :
      # ..........................................................
      mr = list(at = atIn,
                as = asIn,
                aM = aM,
                Mrms = Mrms);
      # ..........................................................

      
      # ............
      return (mr);
      # ............
      
}

# =================================================================================================
# . End of BasicCox.computeMartingaleResiduals.
# =================================================================================================      






# =================================================================================================
# . BasicCox.checkDataMatricesForCoxWithCov : checks compatibility of the numerical data frame and the
# . --------------------------------------   experimental design data frame for Cox proportional hazard
# .                                          regression.
# .
# . This version allows for an additional external covariate.
# .
# .  Syntax :
# . 
# .             msg = BasicCox.checkDataMatricesForCoxWithCov(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                  methodFs = feature selection method.
# .                      mtop = number of features selected under feature selection
# .                             method `mtop'.
# .                         K = number of principal components used.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain (unless tTrain = NONE, in which case all instances
# .        become training set members).
# .      - if tTrain is not NONE, then for that factor, dfE has at least two instances with value
# .        'train'.
# .      - checks that mtop >= K.
# .
# =================================================================================================

BasicCox.checkDataMatricesForCoxWithCov <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxWithCov: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$tTest)) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxWithCov: inparam does not have member tTest";
      stop(msg);
    }    
    # .......................................................................................    

    

    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {
      if (is.null(dfE[[inparam$tTrain]])) {
        msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxWithCov :\n", sep = "");
        msg = paste(msg, "the factor tTrain = ", inparam$tTrain,
                         " does not exist in the input experimental design.", sep = "");
        return (msg);
      }
    }

    if (inparam$tTest != 'NONE') {        
      if (is.null(dfE[[inparam$tTest]])) {
         msg = "ERROR: from BasicCox.checkDataMatricesForCoxWithCov: ";      
         msg = paste(msg, "the factor inparam$tTest = ", inparam$tTest,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }
    
    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxWithCov :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxWithCov :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxWithCov :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................




    
    
    # .......................................................................................
    # . Check consistency of number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxWithCov :\n", sep = "");      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................

    
    
    # .......................................................................................
    # . Check on the number of training set members.
    # . General case, with a not NONE factor specified :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {    
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    
      if (nTrain == 0) {
        msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                     inparam$tTrain , " = train." , sep = "");
        return (msg);
      }

      if (nTrain < 2) {
        msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxWithCov :\n", sep = "");         
        msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                    " records with values for factor ", inparam$tTrain , " = train. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, all members retained :
    # .......................................................................................
    if (inparam$tTrain == 'NONE') {    
      nTrain = n;                               # All samples are training set members.
      nNone = 0;                                # Number of all other samples is 0.
    }
    # .......................................................................................


    
    # .......................................................................................
    # . Check on the number of test set members.
    # .......................................................................................
    if (inparam$tTest != 'NONE') {    
      nTest = sum(dfE[[inparam$tTrain]] == 'test');     # Number of test set members.
    
      if (nTest == 0) {
        msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor tTest = ",
                     inparam$tTest , " = test." , sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, no test set specified:
    # .......................................................................................
    if (inparam$tTest == 'NONE') {    
      nTest = 0;
    }
    # .......................................................................................


    
    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");

    if (inparam$tTest != 'NONE') {
      cat("             Number of samples in test set : nTest = ", nTest, "\n", sep = "");
    }      
    
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");                
    # .......................................................................................        


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of BasicCox.checkDataMatricesForCoxWithCov.
# =================================================================================================





# =================================================================================================
# . BasicCox.computeCoxLogHazardWithCovAndPred : computes the log-hazard-ratios
# . ------------------------------------------   for an input data matrix with an arbitrary 
# .                                              set of samples (not necessarily the ones used in
# .                                              the training set), based on the basic Cox model
# .                                              calculation.
# .
# . >>Predictor version : this version generates actual values of the hazard ratio, and in addition
# . also generates predictions for all distinct values of the external covariate Z
# . (up to BasicCox.NZMAX values).
# .
# .   Syntax:
# .
# .          s = BasicCox.computeCoxLogHazardWithCovAndPred(bc, dfXIn, azIn, hRC);
# .
# .   In:
# .         bc = result of basic Cox multivariate computation, returned
# .              by function BasicCox.computeCoxWithCov().
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .       azIn = input vector of covariate values. It must have the same number of rows as dfX.
# .              Samples need not ne the same as in the training set.
# .
# .
# .       hRC = cutoff on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .
# .   Out:
# .      s = list with members :
# .
# .       flagPred = TRUE, if prediction using the distinct values in azIn are made,
# .                  FALSE otherwise. Prediction is made provided the number of dictinct
# .                  values is no greater than BasicCox.NZMAX.
# .        flagBin = always FALSE if flagPred = FALSE. If TRUE, indicates that in addition
# .                  prediction was made for a binary external covariate ({0, 1}), and
# .                  includes in addition the differential log-hazard-ratio, and a flag
# .                  for samples predicted to be sensitive.
# .             az = copy of array of input values.
# .           azNR = array of distinct values of the external covariate.
# .
# .              Y = nIn * p data matrix after mean-centering with the training set means.
# .                  nIn = number of rows in dfXIn.
# .
# .         aloghR = nIn * L vector of log-hazard ratios; L = 1 if flagPred = FALSE
# .                  (no prediction, just estimated log-hazard ratio for training set values);
# .                  L = 1 + nzNR, if flagPred = TRUE, where nzNR = number of disctinct values
# .                  in azIn.
# .            ahR = nIn * L vector of hazard ratios (see above for definition of L).
# .          atMed = nIn * L estimated median survival times (see above for definition of L).
# .          azMin = absent if flagPred = FALSE, present if flagPred = TRUE.
# .                  Value of Z which minimizes estimated risk for that instance.
# .
# =================================================================================================

BasicCox.computeCoxLogHazardWithCovAndPred <- function(bc, dfXIn, azIn, hRC)
{

      # ..................................................................
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCox.computeCoxLogHazardWithCovAndPred: ";
        msg = paste(msg, "The input bc is not of class basic.cox.cov");
        stop(msg);
      }
      # ...................................................................


      # ..............................................................................
      p = ncol(dfXIn);
      n = nrow(dfXIn);
      
      if (bc$m != p) {
        msg = "ERROR: from BasicCox.computeCoxLogHazardWithCovAndPred: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste(msg, "features as in the training data matrix.", sep = "");
        msg = paste(msg, " Test has p = " , p, " genes.", sep = "");
        msg = paste(msg, " Training has bc$m = " , bc$m, " genes.", sep = "");
        stop(msg);
      }

      nz = length(azIn);

      if (nz != n) {
        cat("ERROR: from BasicCox.computeCoxLogHazardWithCovAndPred:\n");
        cat("Input external covariate array az has nz = ", nz, " elements. ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }

      stopifnot(hRC >= 0.0);      
      # ...............................................................................



      # ...................................................................................
      # . Preamble : test that there are not too many dictinct external covariate values.
      # . Assemble matrix of covariate values.
      # ...................................................................................
      flagPred = TRUE;          # Provisionally true.      

      azNR = unique(azIn);      # Array of distinct values of the external covariate.
      nzNR = length(azNR);      # Number of dictinct values.
      
      if (nzNR > BasicCox.NZMAX) {
        cat("WARNING : from BasicCox.computeCoxLogHazardWithCovAndPred:\n");
        cat("There are too many distinct values nzNR of the covariate.\n");
        cat("I found nzNR = ", nzNR, ", but allowed max. is BasicCox.NZMAX = ", BasicCox.NZMAX, "\n", sep = "");
        cat("I will generate hazard ratios only for the input covariate vector.\n");
        flagPred = FALSE;
      }

      if (flagPred) {
        azBuf = matrix(azNR, nrow = n, ncol = nzNR, byrow = TRUE);
        azMat = cbind(azIn, azBuf);
      } else {
        azMat = azIn;        
      }
      # ...................................................................................       



     
      # ...................................................................................
      # . Compute the n * K matrix of principal components :
      # .
      # .           -                       -
      # .           |xi    xi    . . . xi   |
      # .           |  11    12          1K |
      # .       Y = |                       |
      # .           | . . .      . . .   .  |
      # .           |                       |
      # .           |xi    xi    . . . xi   |
      # .           |  n1    n2          nK |
      # .           -                       -
      # .
      # . where :
      # .               T
      # .     xi    =  v  . x   ,  l = 1, 2, . . ., K
      # .       il      l    i
      # .
      # . where v  is the l-the principal component vector (n components)
      # .        l
      # . and x  the i-th sample vector (n components).
      # .      i
      # ...................................................................................
      # . 3-13-2011; J. Theilhaber: special option for nrow = 1.      
      # ...................................................................................
#      dfXc = sweep(dfXIn, 2, spc$axm);                # Center each column separately.      
#      dfXSel = dfXc[ , spc$indexSel];                 # nIn * m data matrix subsetted to the selected genes.

#      if (nrow(dfXc) == 1) {
#        dfXSel = matrix(dfXSel, nrow = 1);            # Special case for nrow = 1, to preserve matrix geometry.
#      }
      
#      Y = dfXSel %*% spc$avSel;                        # n * K matrix of principal components.
#      colnames(Y) = paste("ypc", 1:spc$K, sep = "");   # Label the pc's.
      # ...................................................................................      
      # . Center the data using the means computed on the training set :
      # ...................................................................................
      Y = sweep(dfXIn, 2, bc$axm);                     # Center each column separately.            
      # ...................................................................................



      # ...................................................................................
      # . Compute the log-hazard ratios for all the samples. These are given by :
      # .
      # .                T                            T
      # .   aloghR   = xi  . beta  + beta  . z  + z xi  . gamma  , i = 1, 2, . . ., n.
      # .         i      i               Z    i       i
      # .
      # ...................................................................................      
      sM = BasicCox.computeCoxLogHazardForMultipleCov(bc, Y, azMat);
      # ...................................................................................


      # ...................................................................................
      # . In the case of multiple instances of covariate z, for each sample in turn,
      # . find the covariate value that minimizes the risk for that sample :
      # ...................................................................................
      if (flagPred) {
        ajMin = apply(sM$aloghR[ , -1], 1, which.min);                # We are excluding the actyal values from the comparison.
        azMin = sapply(1:n, function(i){azMat[i, 1 + ajMin[i]]});     # This retrieves the value of z for which the risk is minimized.
      }
      # ...................................................................................      
      

      # ...................................................................................
      # . Generate column names for the output matrices :
      # ...................................................................................
      abuf = c("actual");

      if (flagPred) {
        abuf = c(abuf, as.character(azNR));
      }

      colnames(sM$aloghR) = paste("loghR_z", abuf, sep = "");
      colnames(sM$ahR) = paste("hR_z", abuf, sep = "");
      colnames(sM$atMed) = paste("tMed_z", abuf, sep = "");
      # ...................................................................................


      
      # ...................................................................................
      # . For binary external covariates only:
      # . For all samples generate the predicted differential log-hazard-ratios,
      # . DloghR = loghR_z1 - loghRz_0, and flag as sensitive the samples with
      # . DloghR <= log(hRC).
      # ...................................................................................
      flagBin = FALSE;
      
      if (flagPred) {
        msg = Cox.checkBinary(azIn);

        if (msg == 'ok') {
          aDloghRz = sM$aloghR[ ,"loghR_z1"] - sM$aloghR[ ,"loghR_z0"];   # Predicted differential log-hazard-ratio.

          temp1 = log(hRC);                                               # Log-hazard-ratio threshold.
          aflagSensitiveZ = ifelse(aDloghRz <= temp1, 1, 0);              # Flag = 1 defines samples as sensitive.
          flagBin = TRUE;        
        }
      }
      # ...................................................................................      
      

     
      # ......................................................................
      # . Package the results :
      # ......................................................................
      s = list(flagPred = flagPred,
               flagBin = flagBin,        
               az = azIn,
               azNR = azNR,
               Y = Y,
               aloghR = sM$aloghR,
               ahR = sM$ahR,
               atMed = sM$atMed);

      if (flagPred) {
        s = c(s, list(azMin = azMin));
      }

      if (flagBin) {
        s = c(s, list(aDloghRz = aDloghRz, aflagSensitiveZ = aflagSensitiveZ));
      }
      # .......................................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of BasicCox.computeCoxLogHazardWithCovAndPred.
# =================================================================================================      





# =================================================================================================
# . BasicCox.computeCoxLogHazardForMultipleCov : computes the log-hazard-ratios given an input
# . ------------------------------------------   data matrix that is already column-centered,
# .                                              and for a series of  external
# .                                              covariates (not necessarily the ones used in
# .                                              the training set).
# .
# .   Syntax:
# .
# .          s = BasicCox.computeCoxLogHazardForMultipleCov(bc, Y, azMat);
# .
# .   In:
# .         bc = result of basic Cox computation, returned
# .              by function BasicCox.computeCoxWithCov().
# .
# .          Y = n * p input data matrix, after column centering with the training set means,
# .              vectors for an arbitrary set of n samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .      azMat = n * L input matrix of external covariate values.
# .              The values in the matrix are arbitrary, and to be used e.g. for prediction
# .              of response to treatment type.
# .
# .   Out:
# .      s = list with members :
# .
# .              Y = nIn * p data matrix,  after column centering with the training set means.
# .                  nIn = number of rows in dfXIn.
# .
# .         aloghR = nIn vector of log-hazard ratios.
# .            ahR = nIn vector of hazard ratios.
# .          atMed = estimated median survival times.
# .
# ................................................................................................
# . >> Note that the matrix Y is given by the n * K matrix of principal components :
# .
# .           -                       -
# .           |xi    xi    . . . xi   |
# .           |  11    12          1K |
# .       Y = |                       |
# .           | . . .      . . .   .  |
# .           |                       |
# .           |xi    xi    . . . xi   |
# .           |  n1    n2          nK |
# .           -                       -
# .
# . where :
# .               T
# .     xi    =  v  . x   ,  l = 1, 2, . . ., K
# .       il      l    i
# .
# . where v  is the l-the principal component vector (n components)
# .        l
# . and x  the i-th sample vector (n components).
# .      i
# . This matrix must be precomputed before calling
# . BasicCox.computeCoxLogHazardForMultipleCov().
# .
# .
# . >>We then compute here the log-hazard ratios for all the samples, given by :
# .
# .                T                            T
# .   aloghR   = xi  . beta  + beta  . z  + z xi  . gamma  , i = 1, 2, . . ., n.
# .         i      i               Z    i       i
# .
# =================================================================================================

BasicCox.computeCoxLogHazardForMultipleCov <- function(bc, Y, azMat)
{

      # ....................................................................
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCox.computeCoxLogHazardForMultipleCov: ";
        msg = paste(msg, "The input bc is not of class basic.cox.cov");
        stop(msg);
      }
      # .....................................................................


      # ..............................................................................
      p = ncol(Y);           # Number of genes in Y.
      n = nrow(Y);           # Number of samples in Y.
      
      if (bc$m != p) {
        cat("ERROR: from BasicCox.computeCoxLogHazardForMultipleCov:\n");
        cat("Input data matrix Y does not have the same number of \n");
        cat("genes as in the training data matrix.\n");
        cat("Y has p = " , p, " genes.");
        cat("Training had bc$m = " , bc$m, " genes.");
        stop(msg);
      }

      nz = nrow(azMat);

      if (nz != n) {
        cat("ERROR: from BasicCox.computeCoxLogHazardForMultipleCov:\n");
        cat("Input external covariate array az has nz = ", nz, " rows. ",
            "not same as input matrix Y with n = ", n, " rows.\n", sep = "");
        stop();
      }      
      # ...............................................................................


      
      # ...................................................................................
      # . Compute the log-hazard ratios.
      # . For the i-th sample, with projection xi_i onto the K principal components,
      # . and for an input value z_i for the external covariate, the log-hazard ratio
      # . is given by :
      # .
      # .                T                             T
      # .   aloghR   = xi  . beta  + beta  . z  + z  xi  . gamma  , 
      # .         i      i               Z    i    i   i
      # .
      # .              ----------    ----------   --------------
      # .              gene          treatment    interaction
      # .              expression    effects      effects
      # .              effects
      # .
      # . which we compute for i = 1, 2, . . ., n.
      # .
      # ...................................................................................
      L = ncol(azMat);                             # Number of columns in azMat.
      
      #xxx aBuf1 =  Y %*% spc$abeta;                    # n-vector : gene expression effects.
      if (ncol(Y) == 1) {
        aBuf1 =  Y * bc$abeta;                         # Special case for p = 1.
      } else {
        aBuf1 =  Y %*% bc$abeta;                       # n vector, direct terms beta * y.
      }
      
      aBufM1 = matrix(aBuf1, nrow = n, ncol = L);  # Spread to the L columns --> n * L matrix.
      
      aBufM2 = bc$betaZ * azMat;                   # n * L matrix, treatment effects.
      
      #xxxx aBuf3 =  Y %*% spc$agamma;                   # n-vector : interaction effects.
      if (ncol(Y) == 1) {
        aBuf3 =  Y * bc$agamma;                       # Special case for p = 1.
      } else {      
        aBuf3 =  Y %*% bc$agamma;                     # n vector, interaction terms gamma * z * y.
      }
      
      aBufM3 = sapply(1:L, function(j){a = azMat[ ,j] * aBuf3; return(a);});

      aloghR = aBufM1 + aBufM2 + aBufM3;           # n * L matrix, log-hazard ratios.
      ahR = exp(aloghR);                           # n * L matrix, hazard ratios.

      bh = BasicCox.getBaselineHazard(bc);                # Baseline hazard information.
      atMed = SuperPc.computeTMedOnBaseline(bh, aloghR)    # Median survival time extimates.      
      # ...................................................................................


     
      # ..........................................................
      # . Package the results :
      # ..........................................................
      s = list(aloghR = aloghR, ahR = ahR, atMed = atMed);
      # ..........................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of BasicCox.computeCoxLogHazardForMultipleCov.
# =================================================================================================      





# =================================================================================================
# . BasicCox.computeSignificanceOnCov : for a given basic Cox model,computes log-hazard ratios
# . ---------------------------------   for all input instances, determines a sensitive patient
# .                                     subset based on the differential log-hazard-ratio threshold,
# .                                     and computes Cox models comparing Z = 0 and Z = 1 arms,
# .                                     for all patients, and for the sensitive subset of patients.
# .
# . Syntax:
# .
# .    ds = BasicCox.computeSignificanceOnCov(bc, dfX, at, as, az, hRC);
# .
# . In:
# .
# .      bc = basic.cox.cov object, returned by BasicCox.computeCoxWithCov().
# .
# .     dfX = input data matrix; need not be the same as generated the
# .           Cox model, but must have the same number of genes.
# .
# .      at = vector of survival times.
# .      as = vector of censoring statuses.
# .      az = vector of external covariate values.
# .     hRC = threshold on differential log-hazard ratio, for determining sensitive patients.
# .
# . Out: list ds, with members :
# .
# .        hRC = threshold of predicted differential log-hazard ratio.
# .       nAll = total number of samples.
# .      csAll = significance scores for all samples, in Z = 1 to Z = 0 comparison.
# .      nSens = number of sensitive patients, defined at threshold hRC (can be 0).
# .     csSens = significance scores for sensitive patient samples, in Z = 1 to
# .              Z = 0 comparison.
# .
# .
# =================================================================================================

BasicCox.computeSignificanceOnCov <- function(bc, dfX, at, as, az, hRC)
{


        # .....................................................................................
        if (class(bc) != "basic.cox.cov") {
          msg = "ERROR: from BasicCox.computeSignificanceOnCov: ";
          msg = paste(msg, "The input bc is not of class: basic.cox.cov");
          stop(msg);
        }

        n = nrow(dfX);     # Number of samples.
        p = ncol(dfX);     # Number of genes.
      
        nt = length(at);   # Number of samples in survival time vector.
        ns = length(as);   # Number of samples in censoring status vector.
        nz = length(az);   # Number of samples in external covariate vector.
      
        if (nt != n) {
          msg = "ERROR: from BasicCox.computeSignificanceOnCov: ";
          msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
          msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
          stop(msg);
        }

        if (ns != n) {
          msg = "ERROR: from BasicCox.computeSignificanceOnCov: ";
          msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
          msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
          stop(msg);
        }

        if (nz != n) {
          msg = "ERROR: from BasicCox.computeSignificanceOnCov: ";          
          msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
          msg = paste("This is not the same as the n = ", n,
                      "samples in the data matrix dfX.", sep = "");        
          stop(msg);
        }
      
        if (bc$m != p) {
          msg = "ERROR: from BasicCoxDiag.plotCoxWithCovOnTest: ";                
          msg = paste("The input data matrix does not have the same number of ");
          msg = paste("genes as in the supervised pc. ");
          msg = paste("Input has p = " , p, " genes. ");
          msg = paste("Bc has m = " , bc$m, " genes.");
          stop(msg);
        }

        stopifnot(hRC >= 0.0);      
        # ........................................................................................

        
      
        # .............................................................
        # . Compute significance, Surv(at, as) ~ az, for all samples.
        # .............................................................  
        csAll = Cox.computeBinaryCox(at, as, az);
        # .............................................................        

        
        # .......................................................................................
        # . Compute the log harzard ratios, using the model;
        # . determine sensitive patients based on the specified threshold.
        # .......................................................................................  
        sl = BasicCox.computeCoxLogHazardWithCovAndPred(bc, dfX, az, hRC);
        # .......................................................................................

        
        # ................................................................
        # . Subset to sensitive samples only :
        # ................................................................
        aSens = (sl$aflagSensitiveZ == 1);   # Mask for sensitive patients.
        nSens = sum(aSens);

        if (nSens > 0) {
          atSens = at[aSens];
          asSens = as[aSens];
          azSens = az[aSens];
        } else {
          atSens = c();
          asSens = c();
          azSens = c();
        }
        # .................................................................
        

        # .............................................................
        # . Compute significance, Surv(at, as) ~ az, for sensitive samples.
        # .............................................................
        if (nSens > 0) {
          csSens = Cox.computeBinaryCox(atSens, asSens, azSens);
        } else {
          csSens =NULL;
        }
        # .............................................................


        # .............................................................
        # . Package the results :
        # .............................................................
        ds = list(hRC = hRC,
                  nAll = n,
                  csAll = csAll,
                  nSens = nSens,
                  csSens = csSens);
        # .............................................................        

}

# =================================================================================================
# . End of BasicCox.computeSignificanceWithCov.
# =================================================================================================




# ========================================================================================================
# . BasicCox.checkDataMatricesForCoxCvWithCovBoot : checks compatibility of the numerical data frame and the
# . -----------------------------------------   experimental design data frame for cross-validation of
# .                                            Cox proportional hazard model.
# .
# .  Syntax :
# . 
# .             msg = BasicCox.checkDataMatricesForCoxCvWithCovBoot(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                   tSplit = factor in dfE defining the further subdivision of the training
# .                            set members into train and test sets for the cross-validation.
# .                            values = 'train' denote the training set members in that group,
# .                            values = 'test' denote the test set members in that group.
# .                            values = 'NONE' are not included. All other values are invalid.
# .
# .                            If tSplit = 'NONE'itself, then checks on this field are not done
# .                            (it is ignored).
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .      - dfE has factor tSplit (check done only if tSplit not equal to 'NONE').
# .      - for the indicated factor tSplit (for non-NONE value), values in dfE 
# .        are either 'train', 'test' or 'NONE', and that the resulting training and
# .        test sets each have at least two member.
# .
# ========================================================================================================

BasicCox.checkDataMatricesForCoxCvWithCovBoot <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # .......................................................................................
    # . Failsafe check on existence of required members :
    # .......................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCovBoot: inparam does not have member tTrain";
      stop(msg);
    }
    # .......................................................................................    



    # ...................................................
    stopifnot(inparam$methodSplit == 'vfoldStrict');
    # ...................................................


    

    # .......................................................................................
    # . Check existence of basic factors :
    # .......................................................................................
    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from BasicCox.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................
    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCovBoot: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCovBoot: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................


    
    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;    # All samples are in the training set.
      nNone = 0;     # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCovBoot: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from BasicCox.checkDataMatricesForCoxCvWithCovBoot: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                   " records with values for factor ", inparam$tTrain , " = train. " ,
                   " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................



    
    # .......................................................................................
    # . Check train/test split. Compute ntrainCV, ntestCV.
    # .
    # . >> methodSplit = vfoldStrict :
    # ...................................................................................
    if (inparam$methodSplit == 'vfoldStrict') {
      csTemp = Stat.generateSplitsForVfold(nTrain, inparam$ft, flagRandom = FALSE);
      nTestCv = csTemp$ntest;

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }  else {
      nTrainCv = nTrain;                # Not really exact; I'm too lazy to change.
    }  
    # .....................................................................................



    
    # .......................................................................................
    # . Check on the external covariate :
    # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
    # . Note that this applies only to the cross-validation program, and not to the
    # . feature selection or model building cases.
    # .......................................................................................    
    msgBin = Cox.checkBinary(dfE[[inparam$tCov]]);

    if (msgBin != 'ok') {
      msg = paste("ERROR: from BasicCox.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, msgBin);

      return(msg);
    }
    # .......................................................................................

    

    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");

    cat("             Given cross-validation split of training set :\n", sep = "");      
    cat("             Training set : nTrainCv = ", nTrainCv, "\n", sep = "");
    cat("             Test set : nTestCv = ", nTestCv, "\n", sep = "");
    # .......................................................................................



    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of BasicCox.checkDataMatricesForCoxCvWithCovBoot.
# =================================================================================================


