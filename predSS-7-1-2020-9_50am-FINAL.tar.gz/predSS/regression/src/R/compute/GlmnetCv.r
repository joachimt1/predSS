# =================================================================================================
# . GlmnetCv.r : functions for cross-validating supervised principal components.
# . -----------   
# .
# =================================================================================================

library(survival);




# =================================================================================================
# . GlmnetCv.crossValidateCoxWithCov : cross-validation of the Cox proportional hazard model over 
# . ---------------------------------   multiple splits of the data into training and test sets,
# .                                     with exploration of a range of model parameters.
# .                                     This version is with an external covariate.
# .                              
# .
# .   Syntax:
# .
# .            cv =  GlmnetCv.crossValidateCoxWithCov(at, as, az, dfX,
# .                                                   methodSplit,
# .                                                   af, ft,
# .                                                   rngSeed, flagRngSeed,
# .                                                   flagFs, mtop, typePval,
# .                                                   alpha, lambda, nlambda,
# .                                                   flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid). Note that only ONE split is ever
# .                               generated.
# .

# .             - 'vfoldStrict' : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, for methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfoldStrict'. Allowed: 0 < ft < 1.
# .
# .       rngSeed = initial random number seed. Must be integer > 0.
# .
# .   flagRngSeed = if TRUE, set initial random number seed to value rngSeed.
# .                 If FALSE, do not (re)set value.
# .
# .  Cox-model parameters :
# .
# .        flagFs = yes/no. If yes, under each split do a first level of feature
# .                 selection.
# .
# .          mtop = if flagFs = yes, for each split keep the mtop genes with most 
# .                 significant Cox scores (i.e. those with the mtop smallest P-values).
# .                 Ignored if flagFs = no.
# .
# .      typePval = if flagFs = yes, type of the P-value that is to be used for the 
# .                 feature selection. Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .                 Ignored if flagFs = no.
# .
# .        alpha = elastic net parameter that determines lasso-ridge         
# .                regression penalty mixture :                              
# .                apha = 1.0, pure lasso, alpha = 0, pure ridge regression. 
# .                Allowed range : 0 <= alpha <= 1.0                         
# .                alpha is fixed and is not varied in the cross-validation.                       
# .          
# .       lambda = point value for the Lagrange multiplier for the penalty 
# .                term for generating a single-level set of results.      
# .                Note that cross-validation results are obtained for     
# .                all lambda values in the regularization path array      
# .               (automatically) generated by glmnet.                   
# .
# .    nlambdaIn = external, input number of lambda values to generate in the regularization paths.
# .                Note that if the coordinate descent method does not converge for
# .                any value of lambda, the generation of lambda values is interrupted.
# .                This may result in an *internal* value of nlambda that is smaller than the
# .                external one. A warning message is printed if this is the case, but execution
# .                should proceed unimpeded, unless the resulting nlambda = 0.
# .
# .   flagVerbose = if TRUE, prints progress on computation in the innner cross-validation loop.
# .
# .
# .   Out:
# .    cv = list, with members defined in packaging at end of function body.
# .
# =================================================================================================

GlmnetCv.crossValidateCoxWithCov  <- function(at, as, az, dfX,
                                              flagCenter,
                                              cvType,
                                              methodSplit,
                                              af, ft,
                                              rngSeed, flagRngSeed,
                                              flagFs, mtop, typePval,
                                              alpha, lambda, nlambdaIn,
                                              flagVerbose)
{

      # ...........................................................................
      cat(" ..........  Entry in GlmnetCv.crossValidateCoxWithCov.\n");
      # ...........................................................................


      
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.            
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (nt != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCov: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCov: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      
      if (nf != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCov: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCov: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((cvType == 'loop') || (cvType == 'single'));
      stopifnot((methodSplit == 'given') || (methodSplit == 'vfoldStrict')); 

      stopifnot((flagCenter == 'yes') || (flagCenter == 'no'));      
      stopifnot((flagFs == 'yes') || (flagFs == 'no'));

      if (flagFs == 'yes') {
        stopifnot(mtop > 0);
        stopifnot(mtop <= p);

        allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
        if (is.null(allowedTypePval[[typePval]])) {
          cat("ERROR: from GlmnetCv.crossValidateCoxWithCov:\n");
          cat("typePval = ", typePval, " is not valid.\n", sep = "");
          cat("Valid: model, X, Z, ZX.\n", sep = "");
          stop();
        }        
      }

      stopifnot(rngSeed > 0);
      stopifnot(flagRngSeed || !flagRngSeed);

      stopifnot(lambda >= 0.0);
      stopifnot(nlambdaIn > 0);
      # ...................................................................................


      
      # .......................................................................................
      # . Check on the external covariate :
      # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
      # . Note that this applies only to the cross-validation program, and not to the
      # . feature selection or model building cases.
      # .......................................................................................    
      msgBin = Cox.checkBinary(az);

      if (msgBin != 'ok') {
        cat("ERROR: from GlmnetCv.crossValidateCoxWithCov:\n");
        cat("External covariate values must all be {0, 1}\n");
        cat(msgBin);
        cat("\n");
        stop();
      }
    # .......................................................................................



      
      # .........................................
      # . Initialize random number generator :
      # .........................................
      if (flagRngSeed) {
        set.seed(rngSeed);
      }
      # .........................................


      
      # ................................................................................................
      # . Precomputation : call glmnet on all the data, so as to generate the lambda sequence :
      # ................................................................................................
      cat(" ..........  Generating lambda sequence by pre-computing on entire data set.\n");
      
      gl = Glmnet.computeCoxWithCov(at = at,
                                    as = as,
                                    az = az,
                                    dfX = dfX,
                                    flagCenter = flagCenter,
                                    flagFs = flagFs,
                                    mtop = mtop,
                                    typePval = typePval,
                                    alpha = alpha,
                                    alambda = NULL,
                                    nlambda = nlambdaIn,
                                    lambda = lambda,
                                    flagVerbose = flagVerbose);

      alambda = gl$alambdaOut;                                         # Actual lambda sequence generated by glmnet.
      nlambda = length(alambda);                                       # Actual number of lambda values generated by glmnet.

      if (nlambda == 0) {
        cat("ERROR: from GlmnetCv.crossValidateCoxWithCov:\n");
        cat("glmnet coordinate descent failed to converge for any lambda values.\n");
        stop();
      }
      
      if (nlambda < nlambdaIn) {
        cat(" ..........  WARNING: from GlmnetCv.crossValidateCoxWithCov:\n");
        cat("             glmnet coordinate descent converged for only the first ", nlambda,
            "             values of lambda, smaller than the external value specified, nlambdaIn = ", nlambdaIn, "\n", sep = "");
        cat("             Continue the computation with these nlambda values.\n", sep = "");
      }

      cat(" ..........  Lambda sequence generated has nlambda = ", nlambda, " values.\n");
      # ..................................................................................................

      

      # ....................................................................................................
      cat(" ..........  Begin cross-validation loop.\n", sep = "");
      # ....................................................................................................

      
      

      # ....................................................................................................
      # . >>CROSS-VALIDATION :
      # . Generate ncv independent splits of the data, and compute log-likelihoods for the designated
      # . range of the chosen parameter.
      # .
      # . >>PREAMBLE :
      # ....................................................................................................
      if (methodSplit == 'given') {
        ncvHere = 1;                        # We are using only the designated split in the data.
        aIndexSplit = NULL;                 # Will not be needed.
        afold = NULL;                       # Will not be needed.                
      } else if (methodSplit == 'vfoldStrict') {
        cSplit = Stat.generateSplitsForVfold(n = n, ft = ft, flagRandom = TRUE);  # Generate truly disjoint groups.
        ncvHere = cSplit$ncv;
        aIndexSplit = cSplit$aIndexSplit;   # Maps: fold --> set of samples.
        afold = cSplit$afold;               # Maps: sample --> fold.
      }

      agFs = list();         # Fold-by-fold list of genes selected by first-pass feature selection.
      agACT =list();         # Fold-by-fold list of genes selected by elastic net following first-pass feature selection.
      # ....................................................................................................
      # . Begin cross-validation below :
      # ....................................................................................................      
      cat(" ..........  Total number of steps: ncvHere = ", ncvHere, "\n", sep = "");
      cat(" ..........  Start loop.\n", sep = "");
      # ....................................................................................................
      # . >> MAIN LOOP :
      # ....................................................................................................
      t1 = proc.time()[3];              # Starting time.
      
      for (icv in 1:ncvHere) {
        cat("Start step = ", icv, " out of ", ncvHere, "\n", sep = "");
        
        ta = proc.time()[3];
        cvS =  GlmnetCv.crossValidateCoxWithCovSingleSplit(at = at,
                                                           as = as,
                                                           az = az,          
                                                           dfX = dfX,
                                                           flagCenter = flagCenter,
                                                           cvType = cvType,
                                                           methodSplit = methodSplit,
                                                           af = af,
                                                           flagFs = flagFs,
                                                           mtop = mtop,
                                                           typePval = typePval,          
                                                           alpha = alpha,
                                                           alambda = alambda,
                                                           lambda = lambda,
                                                           icv = icv,
                                                           aIndexSplit = aIndexSplit,
                                                           flagVerbose = flagVerbose);

        tb = proc.time()[3] - ta;
        cat("Processed step = ", icv, " out of ", ncvHere, ", time = ", tb, " s.\n", sep = "");
        # .....................................................................................
        # . Package intermediate results : note that we always subset to the columns for values
        # . of lambda which converged for all folds.
        # .....................................................................................
        if (icv == 1) {
          aloghRBIG = cvS$aloghRBIG;
          aloghRBIG0 = cvS$aloghRBIG0;
          aloghRBIG1 = cvS$aloghRBIG1;          
          indexTestBIG = cvS$indexTest;
          alambdaBIG = cvS$alambdaOut;
        } else {
          ncolBIG = ncol(aloghRBIG);                         # Number of colums so far in collected test results.
          ncolHere = ncol(cvS$aloghRBIG);                    # Columns that converged on glmnet for this fold.

          if (ncolHere == 0) {
            cat("ERROR: from GlmnetCv.crossValidateCoxWithCov:\n");
            cat("For fold icv = ", icv, "\n", sep = "");
            cat("glmnet coordinate descent failed to converge for any lambda values.\n");
            stop();
          }
          # ................................................................................................
          # . >> 1. Same number of lambda values (always starting from the largest): 
          # ................................................................................................
          if (ncolHere == ncolBIG) {
            aloghRBIG = rbind(aloghRBIG, cvS$aloghRBIG);                    # Use all columns
            aloghRBIG0 = rbind(aloghRBIG0, cvS$aloghRBIG0);                 # and stack rows.
            aloghRBIG1 = rbind(aloghRBIG1, cvS$aloghRBIG1);
            alambdaBIG = alambda[1:ncolBIG];                                # Same.
          } else if (ncolHere < ncolBIG) {
            aloghRBIG = rbind(aloghRBIG[ , 1:ncolHere], cvS$aloghRBIG);     # Use only leftmost columns
            aloghRBIG0 = rbind(aloghRBIG0[ , 1:ncolHere], cvS$aloghRBIG0);  # in collected set, and
            aloghRBIG1 = rbind(aloghRBIG1[ , 1:ncolHere], cvS$aloghRBIG1);  # stack rows.
            alambdaBIG = alambda[1:ncolHere];                               # Leftmost subset.
          } else if (ncolHere > ncolBIG) {
            aloghRBIG = rbind(aloghRBIG, cvS$aloghRBIG[ , 1:ncolBIG]);      # Use only leftmost columns
            aloghRBIG0 = rbind(aloghRBIG0, cvS$aloghRBIG0[ , 1:ncolBIG]);   # in set from this fold, and
            aloghRBIG1 = rbind(aloghRBIG1, cvS$aloghRBIG1[ , 1:ncolBIG]);   # stack rows.
            alambdaBIG = alambda[1:ncolBIG];                                # Leftmost subset.            
          }

          indexTestBIG = c(indexTestBIG, cvS$indexTest);                    # Add this group of indices to end.
        }

        ntrain = cvS$ntrain;      # These will be the same 
        ntest = cvS$ntest;        # for each resampling.
        # ................................................................................................
        # . Save gene lists for this fold :
        # ................................................................................................
        agFs[[icv]] = cvS$agFs;
        agACT[[icv]] = cvS$agACT;                  
        # ..........................................................................................................
      }
      # ..................................................................................
      # . Now that all the collected test-sets log-hazard-ratios have been assembled,
      # . restore the original order of sample indices.
      # ..................................................................................
      arBuf = rownames(aloghRBIG);                   # Get the permuted rownames.
      
      aloghRBIG[indexTestBIG, ] = aloghRBIG;        
      aloghRBIG0[indexTestBIG, ] = aloghRBIG0;     
      aloghRBIG1[indexTestBIG, ] = aloghRBIG1;
      aDloghRBIG = aloghRBIG1 - aloghRBIG0;          # Predicted differential log-hazard.

      arSink = c();
      arSink[indexTestBIG] = arBuf;

      rownames(aloghRBIG) = arSink;                  # Assign back original order.
      rownames(aloghRBIG0) = arSink;                 # Assign back original order.
      rownames(aloghRBIG1) = arSink;                 # Assign back original order.
      rownames(aDloghRBIG) = arSink;                 # Assign back original order.
      # ..................................................................................
      # . Reset values of lambda to common leftmost subset across all folds.
      # ..................................................................................
      if (length(alambdaBIG) < nlambda) {
        cat(" ..........  WARNING: from GlmnetCv.crossValidateCoxWithCov:\n");
        cat("             The number of lambda values for common leftmost subset across all folds is smaller\n");
        cat("             than the value established by coordinate descent with all samples.\n");
        cat("             Number from coordinate descent with all samples: nlambda = ", nlambda, "\n", sep = "");
        cat("             Number from all folds leftmost subset: nlambdaBIG = ", length(alambdaBIG), "\n", sep = "");
        cat("             Set final lambda values to leftmost subset values.\n");
      }
      
      alambda = alambdaBIG; 
      nlambda = length(alambdaBIG);
      # ..................................................................................
      # . The outer cross-validation loop is done :
      # ..................................................................................            
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / ncvHere;                               # Time per split.

      cat(" ..........  Outer cross-validation loop done. Total time = ", t2, " s.", sep = "");
      cat(" Time = ", tau, " s per step.\n");      
      # ....................................................................................................



      # ....................................................................................................
      # . Consolidate selected gene lists into fold-membership matrices.
      # . >> 1. First-pass feature selected genes.
      # ....................................................................................................      
      agFsUnion = sort(unique(unlist(agFs)));
      agFsMat = matrix(0, nrow = length(agFsUnion), ncol = ncvHere);

      for (icv in 1:ncvHere) {      
        buf = ifelse(agFsUnion %in% agFs[[icv]], 1, 0);
        agFsMat[ , icv] = buf;
      }

      rownames(agFsMat) = agFsUnion;
      colnames(agFsMat) = paste("fold_", 1:ncvHere, sep = "");
      # ....................................................................................................            
      # . >> 2. Active genes.
      # ....................................................................................................      
      agACTUnion = sort(unique(unlist(agACT)));
      agACTMat = matrix(0, nrow = length(agACTUnion), ncol = ncvHere);

      for (icv in 1:ncvHere) {      
        buf = ifelse(agACTUnion %in% agACT[[icv]], 1, 0);
        agACTMat[ , icv] = buf;
      }

      rownames(agACTMat) = agACTUnion;
      colnames(agACTMat) = paste("fold_", 1:ncvHere, sep = "");      
      # ....................................................................................................

      


      # ....................................................................................................
      # . For cvType = single, collapse the results from the cross-validation loop to those for
      # . just the one value of the tuning parameter that was specified :
      # ....................................................................................................
      lambdaActual = NULL;                                             # Relevant to cvType = single only.
      
      if (cvType == 'single') {
        jlambda = Glmnet.findLambdaIndex(lambda, alambda);    # Nearest-index approximation.
        lambdaActual = alambda[jlambda];                      # Actual value of lambda for cross-validation.

        bufhRBIG = aloghRBIG[ , jlambda];
        bufhRBIG0 = aloghRBIG0[ , jlambda];
        bufhRBIG1 = aloghRBIG1[ , jlambda];
        bufDBIG = aDloghRBIG[ , jlambda];                               # Nota bene. This had been missed.
        
        aloghRBIG = as.matrix(bufhRBIG, nrow = length(bufhRBIG));
        aloghRBIG0 = as.matrix(bufhRBIG0, nrow = length(bufhRBIG0));
        aloghRBIG1 = as.matrix(bufhRBIG1, nrow = length(bufhRBIG1));
        aDloghRBIG = as.matrix(bufDBIG, nrow = length(bufDBIG));        # Nota bene. This had been missed.
      }        
      # ....................................................................................................
     




      # ....................................................................................................
      # . Generate single vectors of P-values and hazard ratios for the series of test sets generated 
      # . for all the feature selection levels :
      # ....................................................................................................
      nScan = ncol(aloghRBIG);      # Total number of feature selection levels.

      cat(" ..........  Compute significance of differences in survival times\n");
      cat("             for collected test samples predicted to be sensitive.\n");
      cat("             nScan = ", nScan, " feature selection levels will be tested.\n");            
      # .......................................................................................
      # . Generate nScan vectors and (n * nScan) arrays storing test results for each
      # . feature selection level:
      # .......................................................................................
      apR0 = c();
      ahR0 = c();
      apR1 = c();
      ahR1 = c();            

      cat(">>Progress: ");             # Dots will follow.

      flagCR = FALSE;                  # Flag for carriage returns.
      
      for (j in 1:nScan) {
        cCov = SuperPc.computeCoxWithCovSignificanceOnSplit(at, as, az,
                                                            aloghRBIG[ , j],
                                                            aloghRBIG0[ , j],
                                                            aloghRBIG1[ , j],
                                                            flagComputeRES = TRUE);            
        apR0[j] = cCov$cs0$pR;
        ahR0[j] = cCov$cs0$hR;

        apR1[j] = cCov$cs1$pR;
        ahR1[j] = cCov$cs1$hR;                
        
        if (j == 1) {
          aDloghRSortBIG = as.data.frame(matrix(cCov$aDloghRSort, nrow = n));
          indexSortBIG = as.data.frame(matrix(cCov$indexSort, nrow = n));

          apRSortBIG = as.data.frame(matrix(cCov$apRSort, nrow = n));           # Sensitives P-values.     
          ahRSortBIG = as.data.frame(matrix(cCov$ahRSort, nrow = n));           # Sensitives hazard ratios.

          apRSortRESBIG = as.data.frame(matrix(cCov$apRSortRES, nrow = n));     # Resistants P-values.
          ahRSortRESBIG = as.data.frame(matrix(cCov$ahRSortRES, nrow = n));     # Resistants hazard ratios.
          
          aicMinBIG = c(cCov$icMin);
          apRMin = c(cCov$pRMin);
          ahRMin = c(cCov$hRMin);          
          ahRCBIG = c(cCov$hRC);          
        } else {
          aDloghRSortBIG = cbind(aDloghRSortBIG, cCov$aDloghRSort);
          indexSortBIG = cbind(indexSortBIG, cCov$indexSort);

          apRSortBIG = cbind(apRSortBIG, cCov$apRSort);                         # Sensitives P-values.     
          ahRSortBIG = cbind(ahRSortBIG, cCov$ahRSort);                         # Sensitives hazard ratios.

          apRSortRESBIG = cbind(apRSortRESBIG, cCov$apRSortRES);                # Resistants P-values.     
          ahRSortRESBIG = cbind(ahRSortRESBIG, cCov$ahRSortRES);                # Resistants hazard ratios.
          
          aicMinBIG = c(aicMinBIG, cCov$icMin);
          apRMin = c(apRMin, cCov$pRMin);       # Minimum P-value at optimal thresholding between z = 1 and z = 0 sub-populations.  
          ahRMin = c(ahRMin, cCov$hRMin);       # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.
          ahRCBIG = c(ahRCBIG, cCov$hRC);       # Optimal cut: subset at predicted
                                                # lambda(z = 1) / lambda(z = 0) <= hRC to minimize the P-value.
        }

        cat(".", sep = "");     # Progress indicator.
        flagCR = TRUE;        

        if (j%%20 == 0) {
          cat("Processed ", j, " instances out of ", nScan, " so far.\n");
          flagCR = FALSE;
        }        
      }

      cat("\n");                # We are done.
      # ....................................................................................................


      
      # ....................................................................................................
      # . For quantities arising from the Z=1 to Z=0 comparisons, generate arrays in the
      # . original (unsorted) order 
      # ....................................................................................................
      apRUnSortBIG = apRSortBIG;       # Dummy assign, just to get allocation.
      ahRUnSortBIG = ahRSortBIG;       # Dummy assign, just to get allocation.
      arankBIG = indexSortBIG;         # Dummy assign, just to get allocation.

      apRUnSortRESBIG = apRSortRESBIG; # Dummy assign, just to get allocation.
      ahRUnSortRESBIG = ahRSortRESBIG; # Dummy assign, just to get allocation.
      
      nScan = ncol(indexSortBIG);        # Number of tuning parameter levels = number of columns.

      for (j in 1:nScan) {
        apRUnSortBIG[indexSortBIG[ , j], j] = apRSortBIG[ ,j];
        ahRUnSortBIG[indexSortBIG[ , j], j] = ahRSortBIG[ ,j];

        apRUnSortRESBIG[indexSortBIG[ , j], j] = apRSortRESBIG[ ,j];
        ahRUnSortRESBIG[indexSortBIG[ , j], j] = ahRSortRESBIG[ ,j];        

        abuf = 1:n;
        arankBIG[indexSortBIG[ , j], j] = abuf;  # For each sample in original order, its rank in terms of DloghR.
      }
      # ....................................................................................................      
      

      

      # ........................................................................................
      # . Package results :
      # ........................................................................................
      cv = list(cvType = cvType,
                nScan = nScan,
                methodSplit = methodSplit,
                ft = ft,
                ncvHere = ncvHere,             # Actual number of splits.
                rngSeed = rngSeed,
                afold = afold,                 # For method vfoldStrict: maps sample --> fold.
                flagFs = flagFs,
                mtop = mtop,
                typePval = typePval,        
                nScan = cvS$nScan,
                nlambda = nlambda,
                alambda = alambda,
                lambda = lambda,
                ncv = ncvHere,
                n = n,
                ntrain = ntrain,
                ntest = ntest,
                p = p,
                fitB = gl$fitB,                   # Glmnet regularization paths for all data.
                # ................................................................................
                # . >> Prognostic tests :
                # ................................................................................
                apR0 = apR0,                      # nScan : P-values for PROGNOSTIC tests on Z=0 arm only.
                ahR0 = ahR0,                      # nScan : corresponding hR for PROGNOSTIC tests on Z=0 arm only.
        
                apR1 = apR1,                      # nScan : P-values for PROGNOSTIC tests on Z=1 arm only.
                ahR1 = ahR1,                      # nScan : corresponding hR for PROGNOSTIC tests on Z=1 arm only.
                # ................................................................................
                # . >> Time, censoring status and external covariate :
                # ................................................................................
                atBIG = at,                       # n : vector of survival times actually used.
                asBIG = as,                       # n : vector of censoring statuses actually used.
                azBIG = az,                       # n : vector of covariate values actually used.
                # ................................................................................
                # . >> UNSORTED arrays below :
                # ................................................................................
                aloghRBIG = aloghRBIG,            # n * nScan : each column contains predicted loghR for collected test sets, for actual values of Z.
                aloghRBIG0 = aloghRBIG0,          # n * nScan : each column contains predicted loghR for collected test sets, for Z = 0.
                aloghRBIG1 = aloghRBIG1,          # n * nScan : each column contains predicted loghR for collected test sets, for Z = 1.
                aDloghRBIG = aDloghRBIG,          # n * nScan : each column contains loghR(Z=1) - loghR(Z=0).

                apRUnSortBIG = apRUnSortBIG,      # n * nScan : each col. contains Z=1 to Z=0 P-value for threshold at this DloghR.
                ahRUnSortBIG = ahRUnSortBIG,      # n * nScan :  each col. contains Z=1 to Z=0 hR for threshold at this DloghR.
                arankBIG = arankBIG,              # n * nScan : in each col., for each sample in original order, its rank in terms of DloghR.
                # ................................................................................
                # . >> SORTED arrays below :
                # ................................................................................
                aDloghRSortBIG = aDloghRSortBIG,  # n * nScan : each column contains DloghR = loghR(Z=1) - loghR(Z=0), sorted in increasing order.
                indexSortBIG = indexSortBIG,      # n * nScan : each column contains the sort index: aDloghRSort =  aDloghR[indexSort].
                apRSortBIG = apRSortBIG,          # n * nScan : each column contains P-values for Z=1 to Z=0 comparisons, in sort order.
                ahRSortBIG = ahRSortBIG,          # n * nScan : each column contains hR's for Z=1 to Z=0 comparisons, in sort order.

                flagComputeRES = TRUE,            # Indicates whether computation of pR and hR profile has been done for the *resistant* subset.
                apRSortRESBIG = apRSortRESBIG,    # n * nScan : each column contains P-values for Z=1 to Z=0 comparisons, in sort order, for RESISTANT subset.
                ahRSortRESBIG = ahRSortRESBIG,    # n * nScan : each column contains hR's for Z=1 to Z=0 comparisons, in sort order, for RESISTANT subset.
                # ................................................................................
                # . Quantities obtained for maximum P-values :
                # ................................................................................        
                ahRCBIG = ahRCBIG,                # nScan : optimal hR = hRC, for selecting patients predicted to be sensitive by hR <= hRC filter.        
                aicMinBIG = aicMinBIG,            # nScan : number of patients selected by hR <= hRC filter.
                apRMin = apRMin,                  # nScan : P-value for Z = 1 to Z = 1 comparisons, at best hRC.
                ahRMin = ahRMin,                  # nScan : vector.
                # ................................................................................
                # . Membership matrices for selected genes * fold :
                # ................................................................................
                agFsMat = agFsMat,                # First-pass feature selected genes.
                agACTMat = agACTMat               # Active genes.
                # ................................................................................                
        );          

      class(cv) = 'glmnet.cox.cov.cv';
      # ........................................................................................      

      

      # ...........................................................
      cat(" ..........  Exit GlmnetCv.crossValidateCoxWithCov.\n");
      # ...........................................................

      
      
      # .............
      return (cv);
      # .............

}

# ========================================================================================================
# . End of  GlmnetCv.crossValidateCoxWithCov.
# ========================================================================================================      









# =================================================================================================
# . GlmnetCv.crossValidateCoxWithCovSingleSplit : generates a split of the data into training and test 
# . --------------------------------------------   sets, and then computes log-likelihood-ratios for the 
# .                                                test set for a range of the supervised principal
# .                                                components parameters.
# .
# .   Syntax:
# .
# .     cv = GlmnetCv.crossValidateCoxWithCovSingleSplit(at,
# .                                                      as,
# .                                                      az,
# .                                                      dfX,
# .                                                      flagCenter,
# .                                                      cvType,
# .                                                      methodSplit,
# .                                                      af,
# .                                                      flagFs,
# .                                                      mtop,
# .                                                      typePval,
# .                                                      alpha,
# .                                                      alambda,
# .                                                      lambda,
# .                                                      icv,
# .                                                      aIndexSplit,
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .        cvType = type of cross validation : loop or single.
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid).
# .
# .            - 'vfoldStrict'  : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, under methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .
# .     >> Model parameters:
# .
# .
# .
# .     >> Split counter and groups :
# .
# .           icv = defines the group to be removed under split method 'vfoldStrict'.
# .                 This parameter is ignored otherwise.
# .   aIndexSplit = list of disjoint arrays, defining the groups to be removed for that round
# .                 of cross validation. Used under split method 'vfoldStrict', ignored
# .                 otherwise.
# .
# .     >> Type of P-value used for the first-pass feature selection:
# .
# .      typePval = type of the P-value that is to be used for the feature selection.
# .                 Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .     >> General :
# .
# .   flagVerbose = if TRUE, prints progress on computation.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .
# =================================================================================================

GlmnetCv.crossValidateCoxWithCovSingleSplit  <- function(at,
                                                         as,
                                                         az,
                                                         dfX,
                                                         flagCenter,
                                                         cvType,
                                                         methodSplit,
                                                         af,
                                                         flagFs,
                                                         mtop,
                                                         typePval,
                                                         alpha,
                                                         alambda,
                                                         lambda,
                                                         icv,
                                                         aIndexSplit,
                                                         flagVerbose)
{

      # ...........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in GlmnetCv.crossValidateCoxWithCovSingleSplit.\n");
      }
      # ...........................................................................

      
  
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.                  
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (nt != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }
      
      if (nz != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      
      if (nf != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................


      

      # .................................................................................................
      # . Check on the validity of some of the other input parameters :
      # .................................................................................................
      stopifnot((cvType == 'loop') || (cvType == 'single'));      
      stopifnot((methodSplit == 'given') || (methodSplit == 'vfoldStrict'));

      stopifnot((flagCenter == 'yes') || (flagCenter == 'no'));
      stopifnot((flagFs == 'yes') || (flagFs == 'no'));      

      if (flagFs == 'yes') {
        stopifnot(mtop >= 1);
        stopifnot(mtop <= p);

        allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
        if (is.null(allowedTypePval[[typePval]])) {
          cat("ERROR: from GlmnetCv.crossValidateCoxWithCov:\n");
          cat("typePval = ", typePval, " is not valid.\n", sep = "");
          cat("Valid: model, X, Z, ZX.\n", sep = "");
          stop();
        }      
      }

      if (methodSplit == 'vfoldStrict') {
        ncvBuf = length(aIndexSplit);

        if (icv > ncvBuf) {
          cat("ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit:\n");
          cat("icv = ", icv, " is greater than the number of groups to be cross-validated, ncv = ", ncvBuf, "\n", sep = "");
          stop();
        }
      }

      stopifnot(alpha >= 0.0, alpha <= 1.0);

      if (!is.null(alambda)) {
        nbuf = length(alambda);
        stopifnot(nbuf > 0);               # Failsafe.
        if (nbuf > 1) {
          nbuf1 = nbuf - 1;
          abuf = alambda[1:nbuf1] - alambda[2:nbuf];

          if (min(abuf) <= 0.0) {
              cat("ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit:\n");
              cat("Input lambda sequence is not strictly decreasng.\n");
              stop();
          }
        }
      } else {
        cat("ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit:\n");
        cat("Input lambda sequence array alambda is NULL.\n");
        stop();
      }
      # ................................................................................................


      

      # .................................................................................................
      # . Generate the indices for splitting the data into training and test set.
      # .
      # . >> methodSplit = given :
      # .................................................................................................
      if (methodSplit == 'given') {
        # ......................................................................
        # . Check all given entries are 'train', 'test' or 'NONE' :
        # ......................................................................
        indexInvalid = which((af != 'train') & (af != 'test') & (af != 'NONE'));

        if (length(indexInvalid) > 0) {
          msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit: ";        
          msg = paste("The train/test assignment vector contains some values which are neither ", sep = "");
          msg = paste("train, test or NONE. First detected invalid value = ", af[indexInvalid[1]], sep = "");
          stop(msg);
        }
        # ......................................................................
        # . Find the indices for the training and test subsets :
        # ......................................................................
        indexTrain = which(af == 'train');
        indexTest = which(af == 'test');

        ntrain = length(indexTrain);
        ntest = length(indexTest);        
        
        if (ntrain < 2) {
          msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit: ";
          msg = paste("Less than 2 training set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntrain = ", ntrain, sep = "");          
          stop(msg);
        }

        if (ntest < 2) {
          msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit: ";
          msg = paste("Less than 2 test set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntest = ", ntest, sep = "");          
          stop(msg);
        }        
        # ......................................................................        
      }
      # ...................................................................................      
      # . >> methodSplit = vfoldStrict :
      # . Under this option the groups were predefined before the function call,
      # . by function Stat.generateSplitsForVfold(). We just retrieve the indices.
      # ...................................................................................
      if (methodSplit == 'vfoldStrict') {
        # ......................................................................                
        indexTest = aIndexSplit[[icv]];
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }      
      # ....................................................................................................



      # ...................................................................................
      # . Generate the training and test subsets :
      # ...................................................................................
      atTrain = at[indexTrain];       # Survival times.
      asTrain = as[indexTrain];       # Censoring statuses (1 = not censored, 0 = censored).
      azTrain = az[indexTrain];       # External covariate.
      dfXTrain = dfX[indexTrain, ];   # Data matrix of gene expression values.

      atTest = at[indexTest];         # Survival times.
      asTest = as[indexTest];         # Censoring statuses (1 = not censored, 0 = censored).
      azTest = az[indexTest];         # External covariate.      
      dfXTest = dfX[indexTest, ];     # Data matrix of gene expression values.        
      # ...................................................................................

      

      # ...................................................................................
      # . Adjust for special case of LOOCV :
      # ...................................................................................
      if (length(indexTest) == 1) {
        dfXTest = matrix(dfXTest, nrow = 1);
        colnames(dfXTest) = colnames(dfX);
      }
      # ...................................................................................      



      # ...................................................................................................
      # . Compute the model on the training set :
      # . note that by the nature of the glmnet computation, this returns coefficients for
      # . all lambda values in the regularization path (as defined by the input array alambda)
      # . simultaneously.
      # ...................................................................................................
      glTrain = Glmnet.computeCoxWithCov(at = atTrain,
                                         as = asTrain,
                                         az = azTrain,                    
                                         dfX = dfXTrain,
                                         flagCenter = flagCenter,
                                         flagFs = flagFs,
                                         mtop = mtop,        
                                         typePval = typePval,          
                                         alpha = alpha,
                                         alambda = alambda,
                                         nlambda = NULL,
                                         lambda = lambda,          
                                         flagVerbose = TRUE);

      if (glTrain$nlambdaOut == 0) {
        cat("ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit:\n");
        cat("glmnet coordinate descent on this fold failed to converge for any lambda values.\n");
        stop();
      }

      nlambdaHere = length(alambda);
      
      if (glTrain$nlambdaOut < nlambdaHere) {
        cat(" ..........  WARNING: from GlmnetCv.crossValidateCoxWithCovSingleSplit:\n");
        cat("             For this fold glmnet coordinate descent converged for only the first ", glTrain$nlambdaOut,
            " values of lambda, smaller than the template value specified, nlambdaHere = ", nlambdaHere, "\n", sep = "");
        cat("             Continue the computation with these values.\n", sep = "");
      }
      # ...................................................................................................
      # . Make predictions on the test set, using the training set model :
      # . note that this is done for all lambda values in the regularization path simultaneously.
      # . The resulting matrices have dimensions [ntest * nlambda].
      # ...................................................................................................
      azIn0 = rep(0, times = length(azTest));                                  # Array with all Z = 0.
      azIn1 = rep(1, times = length(azTest));                                  # Array with all Z = 1.
      
      aloghRBIG = Glmnet.computeCoxLogHazardWithCovBIG(glTrain,
                                                       dfXIn = dfXTest,
                                                       azIn = azTest);    # Predictions for actual values.

      aloghRBIG0 = Glmnet.computeCoxLogHazardWithCovBIG(glTrain,
                                                        dfXIn = dfXTest,
                                                        azIn = azIn0);    # Predictions for all-Z = 0 values.

      aloghRBIG1 = Glmnet.computeCoxLogHazardWithCovBIG(glTrain,
                                                        dfXIn = dfXTest,
                                                        azIn = azIn1);    # Predictions for all-Z = 1 values.
      # .......................................................................................................

      

      # ......................................................................................
      # . Package results :
      # ......................................................................................
      cv = list(cvType = cvType,                    # Type of cross-validation (loop, single).
                methodSplit = methodSplit,          # Splitting method.
                flagFs = flagFs,                    # Do first-pass feature selection?
                mtop = mtop,                        # How many genes to retain if yes.
                typePval = typePval,                # Selection P-value for first-pass feature selection.
                n = n,                              # Number of samples.
                ntrain = ntrain,                    # Number in training set.
                ntest = ntest,                      # Number in test set.
                alambdaOut = glTrain$alambdaOut,    # Lambda sequence actually used.
                nlambdaOut = glTrain$nlambdaOut,    # Number of lambdas actually used.
                indexTest = indexTest,              # Test items indices in original array.
                aloghRBIG = aloghRBIG,              # log-hazard-ratio for actual Z values.
                aloghRBIG0 = aloghRBIG0,            # log-hazard-ratio all-Z=0 values.
                aloghRBIG1 = aloghRBIG1,            # log-hazard-ratio all-Z=1 values.
                agFs = glTrain$agFs,                # Genes selected by the first-pass feature selection.
                agACT = glTrain$agACT);             # Genes further selected by elastic net.

      class(cv) = 'glmnet.cox.cv';
      # ......................................................................................


      # .............
      return (cv);
      # .............
      
}

# =================================================================================================
# . End of GlmnetCv.crossValidateCoxWithCovSingleSplit.
# =================================================================================================








# =====================================================================================================================
# . GlmnetCv.crossValidateCoxWithCovBoot : bootstrap of cross-validation of the Cox proportional hazard model over 
# . ------------------------------------   multiple splits of the data into training and test sets.
# .                                        This version is with an external covariate.
# .                                     
# .                              
# .
# .   Syntax:
# .
# .            cv =  GlmnetCv.crossValidateCoxWithCovBoot(at, as, az, dfX,
# .                                                       ft,
# .                                                       rngSeed,
# .                                                       bootType,
# .                                                       nboot,
# .                                                       flagFs, mtop, typePval,
# .                                                       alpha, lambda, nlambda,
# .                                                       flaghRCOpt, hRC,
# .                                                       flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfoldStrict'. Allowed: 0 < ft < 1.
# .
# .       rngSeed = initial random number seed. Must be integer > 0.
# .
# .     >> Bootstrap parameters :
# .
# .       bootType = type of resampling to be done in the outer loop.
# .                  Two types are valid : fullBoot, splitOnly       
# .                
# .                           fullBoot : do full bootstrap resampling. Resample 
# .                                      with replacement the training set      
# .                                      members, then do the indicated cross-  
# .                                      validation. Note that with this option 
# .                                      splits necessarily are different for   
# .                                      resampling.                            
# .     
# .                           splitOnly : only the splits deining the folds are 
# .                                       randomly changed for each outer loop  
# .                                       sampling. The overall training set    
# .                                       itself is unchanged.
# .
# .                         permutation : permute the gene expression profiles
# .                                       with respect to the survival data
# .                                       and external covariate (i.e. (t, s, z)
# .                                       are kept in synch with each other, and 
# .                                       x randomly permuted).
# .     
# .          nboot = number of bootstrap resamplings to be applied.
# .
# .     >> Cox-model parameters :
# .
# .        flagFs = yes/no. If yes, under each split do a first level of feature
# .                 selection.
# .
# .          mtop = if flagFs = yes, for each split keep the mtop genes with most 
# .                 significant Cox scores (i.e. those with the mtop smallest P-values).
# .                 Ignored if flagFs = no.
# .
# .      typePval = if flagFs = yes, type of the P-value that is to be used for the 
# .                 feature selection. Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .                 Ignored if flagFs = no.
# .
# .        alpha = elastic net parameter that determines lasso-ridge         
# .                regression penalty mixture :                              
# .                apha = 1.0, pure lasso, alpha = 0, pure ridge regression. 
# .                Allowed range : 0 <= alpha <= 1.0                         
# .                alpha is fixed and is not varied in the cross-validation.                       
# .          
# .       lambda = point value for the Lagrange multiplier for the penalty 
# .                term for generating a single-level set of results.      
# .                Note that cross-validation results are obtained for     
# .                all lambda values in the regularization path array      
# .               (automatically) generated by glmnet.                   
# .
# .    nlambdaIn = external, input number of lambda values to generate in the regularization paths.
# .                Note that if the coordinate descent method does not converge for
# .                any value of lambda, the generation of lambda values is interrupted.
# .                This may result in an *internal* value of nlambda that is smaller than the
# .                external one. A warning message is printed if this is the case, but execution
# .                should proceed unimpeded, unless the resulting nlambda = 0.
# .
# .     >> Decision boundary :
# .
# .        flaghRCOpt = flag defining where the hRC threshold value used comes from.
# .                     Allowed values :
# .
# .                     -   'no' : use input value hRC given below.
# .                     -  'yes' : use value which maximizes significance of separation of treatment
# .                                arms for sensitives.
# .
# .               hRC = decision threshold. Used if fflaghRCOpt = 'no', ignored if flaghRCOpt = 'yes'.
# .
# .                      Note that DloghR <= log(hRC) defines sensitive samples, DloghR >= log(hRC)
# .                      defines resistant samples.
# .
# .   flagVerbose = if TRUE, prints progress on computation in the innner cross-validation loop.
# .
# .
# .   Out:
# .    cv = list, with members defined in packaging at end of function body.
# .
# =====================================================================================================================

GlmnetCv.crossValidateCoxWithCovBoot  <- function(at, as, az, dfX,
                                                  flagCenter,
                                                  ft,
                                                  rngSeed, 
                                                  bootType, nboot,
                                                  flagFs, mtop, typePval,
                                                  alpha, lambda, nlambdaIn,
                                                  flaghRCOpt,                                                  
                                                  hRC,
                                                  flagVerbose)
{

      # ...........................................................................
      cat(" ..........  Entry in GlmnetCv.crossValidateCoxWithCovBoot.\n");
      # ...........................................................................


      
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.            

      if (nt != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovBoot: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovBoot: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovBoot: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      
      if (n < 4) {
        msg = "ERROR: from GlmnetCv.crossValidateCoxWithCovBoot: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((bootType == 'fullBoot')
                || (bootType == 'splitOnly')
                || (bootType == 'permutation'));
      
      stopifnot((flagCenter == 'yes') || (flagCenter == 'no'));      
      stopifnot((flagFs == 'yes') || (flagFs == 'no'));

      if (flagFs == 'yes') {
        stopifnot(mtop > 0);
        stopifnot(mtop <= p);

        allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
        if (is.null(allowedTypePval[[typePval]])) {
          cat("ERROR: from GlmnetCv.crossValidateCoxWithCovBoot:\n");
          cat("typePval = ", typePval, " is not valid.\n", sep = "");
          cat("Valid: model, X, Z, ZX.\n", sep = "");
          stop();
        }        
      }

      stopifnot(rngSeed > 0);
      stopifnot(nboot > 0);      
      stopifnot(lambda >= 0.0);
      stopifnot(nlambdaIn > 0);

      stopifnot((flaghRCOpt == 'yes') || (flaghRCOpt == 'no'));            
      stopifnot(hRC > 0);      
      # ...................................................................................


      
      # .......................................................................................
      # . Check on the external covariate :
      # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
      # . Note that this applies only to the cross-validation program, and not to the
      # . feature selection or model building cases.
      # .......................................................................................    
      msgBin = Cox.checkBinary(az);

      if (msgBin != 'ok') {
        cat("ERROR: from GlmnetCv.crossValidateCoxWithCovBoot:\n");
        cat("External covariate values must all be {0, 1}\n");
        cat(msgBin);
        cat("\n");
        stop();
      }
      # .......................................................................................



      # ...............................................................................
      # . Set fixed defaults to be used inside the bootstrap loop :
      # ...............................................................................
      cvType = 'single';
      methodSplit = 'vfoldStrict';
      af = rep('NONE', times = length(at));           # Dummy.

      set.seed(rngSeed);  # Actually (re)set in the calculation on the non-resampled data.      
      # ...............................................................................
        


      # ......................................................................................................
      # . Do a one-time cross-validation on the non-resampled data :
      # ......................................................................................................            
      cat(" ..........  Do one-time cross-validation on the actual (non-resampled) data set.\n", sep = "");

      cv = GlmnetCv.crossValidateCoxWithCov(at = at,
                                            as = as,
                                            az = az,          
                                            dfX = dfX,
                                            flagCenter = flagCenter,
                                            cvType = 'single',                    # Frozen to 'single'.
                                            methodSplit = 'vfoldStrict',          # Frozen to 'vfoldStrict'.
                                            af = af,                              # Not used, as methodSplit = 'vfoldStrict'.
                                            ft = ft,
                                            rngSeed = rngSeed,                    # Not used in call, as flagRngSeed = FALSE.
                                            flagRngSeed = TRUE,                   # Initializes the random number seed.
                                            flagFs = flagFs,
                                            mtop = mtop,
                                            typePval = typePval,          
                                            alpha = alpha,
                                            lambda = lambda,
                                            nlambdaIn = nlambdaIn,
                                            flagVerbose = TRUE);
      # ......................................................................................................
      # . Gather statistics for this resampling step :
      # ......................................................................................................
      sumCObs = SuperPc.summarizeCoxWithCovOnSplit(cv$aDloghRSortBIG[ , 1],
                                                   cv$ahRSortBIG[ , 1],
                                                   cv$apRSortBIG[ , 1],                                               
                                                   cv$ahRSortRESBIG[ , 1],
                                                   cv$apRSortRESBIG[ , 1],
                                                   hRCIn = hRC,
                                                   flaghRCOpt = flaghRCOpt);
      # .......................................................................................................

      


      
        
      # ..................................................................................................................
      # . MAIN RESAMPLING LOOP :
      # ..................................................................................................................
      index0 = 1:n;                # Fixed index for resampling.
      asumC = list();              # This will contain the results from the resampling runs.
      
      cat(" ..........  Begin the resampling loop.\n", sep = "");
      cat(" ..........  Resampling type : ", bootType, "\n", sep = "");
      
      t1 = proc.time()[3];              # Starting time.
      
      for (l in 1:nboot) {
        cat(">>##############################################################\n");
        cat(">>Bootstrap resampling step ", l, " out of ", nboot, "\n", sep = "");
        cat(">>##############################################################\n");        
        # ......................................................................................
        # . >>FULL BOOTSTRAP: resample with replacement. All features remain together.
        # . We are simulating a new data set from the same distribution as the input data set.
        # ......................................................................................
        if (bootType == 'fullBoot') {
          indexBuf = sample(index0, replace = TRUE);   # Sampling with replacement.
          
          atBuf = at[indexBuf];
          asBuf = as[indexBuf];
          azBuf = az[indexBuf];

          dfXBuf = dfX[indexBuf, ];

        }
        # ......................................................................................        
        # . >>RESAMPLE SPLITS ONLY : we are gauging only the effects of generating variable
        # . fold selections in the internal cross-validation. The training set remains
        # . untouched.
        # ......................................................................................
        if (bootType == 'splitOnly') {
          atBuf = at;
          asBuf = as;
          azBuf = az;

          dfXBuf = dfX;
        }
        # ......................................................................................
        # . >>PERMUTATION:  shuffle gene expression profiles
        # . but keep survival and external co-variate in-place.
        # . We are simulating a data set under the null hypothesis of no association between
        # . survival and gene-expression.
        # ......................................................................................
        if (bootType == 'permutation') {
          indexBuf = sample(index0);                    # Permutation.
          
          atBuf = at;                                   # These stay in place.
          asBuf = as;                                   # These stay in place.
          azBuf = az;                                   # These stay in place.

          dfXBuf = dfX[indexBuf, ];                     # Shuffle gene expression profiles.
        }        
        # ......................................................................................
        # . The innner cross-validation is done here :
        # ......................................................................................                
        cv = GlmnetCv.crossValidateCoxWithCov(at = atBuf,
                                              as = asBuf,
                                              az = azBuf,          
                                              dfX = dfXBuf,
                                              flagCenter = flagCenter,
                                              cvType = 'single',                    # Frozen to 'single'.
                                              methodSplit = 'vfoldStrict',          # Frozen to 'vfoldStrict'.
                                              af = af,                              # Not used, as methodSplit = 'vfoldStrict'.
                                              ft = ft,
                                              rngSeed = rngSeed,                    # Not used in call, as flagRngSeed = FALSE.
                                              flagRngSeed = FALSE,                  # Frozen to FALSE.
                                              flagFs = flagFs,
                                              mtop = mtop,
                                              typePval = typePval,          
                                              alpha = alpha,
                                              lambda = lambda,
                                              nlambdaIn = nlambdaIn,
                                              flagVerbose = TRUE);
        # ......................................................................................
        # . Gather statistics for this resampling step :
        # ......................................................................................
        sumC = SuperPc.summarizeCoxWithCovOnSplit(cv$aDloghRSortBIG[ , 1],
                                                  cv$ahRSortBIG[ , 1],
                                                  cv$apRSortBIG[ , 1],                                               
                                                  cv$ahRSortRESBIG[ , 1],
                                                  cv$apRSortRESBIG[ , 1],
                                                  hRCIn = hRC,
                                                  flaghRCOpt = flaghRCOpt);

        asumC[[l]] = sumC;
        # ......................................................................................        
      }

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / nboot;                                 # Time per resampling.

      cat(" ..........  Bootstrap loop done. Total time = ", t2, " s.", sep = "");
      cat(" Time = ", tau, " s per resampling.\n");            
      # ..................................................................................................................


      

      # ........................................................................................
      # . Package results :
      # ........................................................................................
      cvBoot = list(n = n,                       # Number of samples.
                    bootType = bootType,         # Type of resampling done.
                    nboot = nboot,               # Number of resamplings.
                    rngSeed = rngSeed,           # Random number seed.
                    hRC = hRC,                   # Hazard ratio threshold for S and R calls.
                    sumCObs = sumCObs,           # Statistical summary for actual training set.
                    asumC = asumC);              # List contains series of summaries generated by resamplings.
            
      class(cvBoot) = 'glmnet.cox.cov.cv.boot';
      # ........................................................................................      

      

      # ................................................................
      cat(" ..........  Exit GlmnetCv.crossValidateCoxWithCovBoot.\n");
      # ................................................................

      
      
      # ...............
      return (cvBoot);
      # ...............

}

# =====================================================================================================================
# . End of  GlmnetCv.crossValidateCoxWithCovBoot.
# =====================================================================================================================






# =================================================================================================
# . GlmnetCv.crossValidateRegress : cross-validation of the regression model over 
# . ------------------------------   multiple splits of the data into training and test sets,
# .                                  with exploration of a range of model parameters.
# .                              
# .
# .   Syntax:
# .
# .            cv =  GlmnetCv.crossValidateRegress(ay, dfX,
# .                                                modelType,
# .                                                methodSplit,
# .                                                af, ft, rngSeed,
# .                                                alpha, lambda,
# .                                                flagVerbose)
# .
# .   In:
# .            ay = n : vector of output values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     modelType = type of regression model to be used :
# .                 Allowed values : 
# .                  - 'lm' : linear model.
# .                  - 'logistic' : logistic distribution. 
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid). Note that only ONE split is ever
# .                               generated.
# .
# .             - 'vfoldStrict' : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, for methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfold'. Allowed: 0 < ft < 1.
# .
# .        rgSeed = seed for random number generator.
# .
# .     >> Fixed-values parameters:
# .
# .         alpha = elastic net parameter that determines lasso-ridge 
# .                         regression penalty mixture :              
# .                         apha = 1.0, pure lasso, alpha = 0, pure ridge regression.
# .                         Allowed range : 0 <= alpha <= 1.0                        
# .                         alpha is fixed and is not varied in the cross-validation.
# .           
# .        lambba =  point value for the Lagrange multiplier for the penalty 
# .                            term for generating a single-level set of results.
# .                             Note that cross-validation results are obtained for
# .                             all lambda values in the regularization path array 
# .                             (automatically) generated by glmnet.               
# .                             lambda is fixed and is not varied in the           
# .                             cross-validation.                                  
# .
# .   flagVerbose = if TRUE, prints progress on computation in the innner cross-validation loop.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .           modelType = type of regression model.
# .
# .            aRrmsQ25 = First quartile for r.m.s. of residuals of test set on training set.
# .         aRrmsMedian = Median Rrms.
# .            aRrmsQ75 =  Third quartile Rrms.
# .       aRrmsSigmaMad =  MAD std. deviation Rrms.
# .
# .            aepsR2Q25 = First quartile epsR2.
# .         aepsR2Median = Median epsR2.
# .           aepsR2Q75  = Third quartile epsR2.
# .      aepsR2SigmaMad  = MAD std. deviation epsR2.
# .
# .         amlog10pRQ25 = First quartile mlog10pR.
# .      amlog10pRMedian = Median mlog10pR.
# .         amlog10pRQ75 = Third quartile mlog10pR.
# .    amlog10pRSigmaMad = MAD std. deviation mlog10pR.
# .
# =================================================================================================

GlmnetCv.crossValidateRegress  <- function(ay, dfX,
                                           modelType,
                                           methodSplit,
                                           af, ft, rngSeed,
                                           alpha, lambda,
                                           flagVerbose)
{

      # ...........................................................................
      cat(" ..........  Entry in GlmnetCv.crossValidateRegress.\n");
      # ...........................................................................


      
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);                   # Number of samples in data matrix.
      p = ncol(dfX);
      arowName = rownames(dfX);        # Array of row names.
      
      ny = length(ay);   # Number of samples in output variable vector.
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (ny != n) {
        msg = "ERROR: from GlmnetCv.crossValidateRegress: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      

      if (nf != n) {
        msg = "ERROR: from GlmnetCv.crossValidateRegress: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from GlmnetCv.crossValidateRegress: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((modelType == 'lm') || (modelType == 'logistic'));
      stopifnot((methodSplit == 'given')
                || (methodSplit == 'vfoldStrict'));      # methodSplit is obsolete.
      
      if (methodSplit == 'vfoldStrict') {
        stopifnot((ft > 0.0) && (ft < 1.0));
      }

      stopifnot(rngSeed > 0);
      # ...................................................................................


      # .........................................
      # . Initialize random number generator :
      # .........................................      
      set.seed(rngSeed);                  
      # .........................................
      

      # ..........................................................
      cat(" ..........  Begin cross-validation loop.\n");
      # ..........................................................



      # ....................................................................................................
      # . >>CROSS-VALIDATION :
      # . Generate ncv independent splits of the data, and compute log-likelihoods for the designated
      # . range of the chosen parameter.
      # .
      # . >>PREAMBLE :
      # ....................................................................................................
      if (methodSplit == 'given') {
        ncvHere = 1;                        # We are using only the designated split in the data.
        aIndexSplit = NULL;                 # Will not be needed.        
      } else if (methodSplit == 'vfoldStrict') {
        cSplit = Stat.generateSplitsForVfold(n = n, ft = ft, flagRandom = TRUE);  # Generate truly disjoint groups.
        ncvHere = cSplit$ncv;
        aIndexSplit = cSplit$aIndexSplit;
      }      
      # ....................................................................................................
      # . Begin cross-validation below :
      # ....................................................................................................      
      cat(" ..........  Total number of steps: ncvHere = ", ncvHere, "\n", sep = "");
      cat(" ..........  Start loop.\n", sep = "");            
      # ....................................................................................................
      # . >> MAIN LOOP :
      # ....................................................................................................
      t1 = proc.time()[3];              # Starting time.
      
      for (icv in 1:ncvHere) {
        cat("Start step = ", icv, " out of ", ncvHere, "\n", sep = "");
        
        ta = proc.time()[3];
        cvS =  GlmnetCv.crossValidateRegressSingleSplit(ay = ay,
                                                        dfX = dfX,
                                                        modelType = modelType,
                                                        methodSplit = methodSplit,
                                                        af = af,
                                                        ft = ft,
                                                        alpha = alpha,
                                                        lambda = lambda,
                                                        icv = icv,
                                                        aIndexSplit = aIndexSplit,          
                                                        flagVerbose = flagVerbose);
        tb = proc.time()[3] - ta;
        cat("Processed step = ", icv, " out of ", ncvHere, ", time = ", tb, " s.\n", sep = "");
        # .....................................................................................
        # . Package intermediate results :
        # .....................................................................................
        if (icv == 1) {
          dRrms = as.data.frame(matrix(cvS$aRrms, nrow = 1));
          depsR2 = as.data.frame(matrix(cvS$aepsR2, nrow = 1));
          dpR = as.data.frame(matrix(cvS$apR, nrow = 1));

          axiBIG = cvS$axiBIG;
          ayPredBIG = cvS$ayPredBIG;
          aPyPredBIG = cvS$aPyPredBIG;          
          indexTestBIG = cvS$indexTest;          
        } else {
          dRrms = rbind(dRrms, cvS$aRrms);
          depsR2 = rbind(depsR2, cvS$aepsR2);
          dpR = rbind(dpR, cvS$apR);

          axiBIG = rbind(axiBIG, cvS$axiBIG);                # Stack rows.          
          ayPredBIG = rbind(ayPredBIG, cvS$ayPredBIG);       # Stack rows.
          aPyPredBIG = rbind(aPyPredBIG, cvS$aPyPredBIG);    # Stack rows.          
          indexTestBIG = c(indexTestBIG, cvS$indexTest);     # Add to end.                    
        }

        ntrain = cvS$ntrain;      # These will be the same 
        ntest = cvS$ntest;        # for each resampling.
        # .....................................................................................   
      }
      # ..................................................................................
      # . Now that all the collected test-sets log-hazard-ratios have been assembled,
      # . restore the original order of sample indices.
      # .
      # . Note that for methodSplit = 'given', not all samples will have been recycled 
      # . as on-the-fly test samples, and matrix ayPredBIG will have rows that are
      # . all-NAs.
      # ..................................................................................
      arHOLD = rownames(ayPredBIG);                  # Hold the test sample names here.

      axiBuf = matrix(NA, nrow = n, ncol = ncol(axiBIG));
      axiBuf[indexTestBIG, ] = axiBIG;               # Assign numerical values.
      axiBIG = axiBuf;
      
      ayBuf = matrix(NA, nrow = n, ncol = ncol(ayPredBIG));
      ayBuf[indexTestBIG, ] = ayPredBIG;             # Assign numerical values.
      ayPredBIG = ayBuf;

      aPyBuf = matrix(NA, nrow = n, ncol = ncol(aPyPredBIG));
      aPyBuf[indexTestBIG, ] = aPyPredBIG;           # Assign numerical values.
      aPyPredBIG = aPyBuf;

      arBuf = rep(NA, times = n);
      arBuf[indexTestBIG] = arHOLD;                  # Unpermute the row names.

      rownames(axiBIG) = arBuf;                      # Assign the unpermuted row names.      
      rownames(ayPredBIG) = arBuf;                   # Assign the unpermuted row names.
      rownames(aPyPredBIG) = arBuf;                  # Assign the unpermuted row names.      
      # ..................................................................................
      # . The outer cross-validation loop is done :
      # ..................................................................................
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / ncvHere;                               # Time per split.

      cat(" ..........  Outer cross-validation loop done. Total time = ", t2, " s.", sep = "");
      cat(" Time = ", tau, " s per step.\n");      
      # ....................................................................................................      




      # ....................................................................................................
      # . Generate summary stats.
      # . >>r.m.s residuals:
      # . Note that all these statistics on individual test sets are somewhat obsolete, and are
      # . meaningful only for the linear regression model (modelType = 'lm').
      # . For logistic regression, all values are dummy values.
      # . See below for the 'true' statistics generated on the collected cross-validated predictions.
      # ....................................................................................................
      aRrmsQ25 = apply(dRrms, 2, quantile, probs = 0.25);  # First quartile for r.m.s. of res.
      aRrmsMedian = apply(dRrms, 2, median);               # Median Rrms.
      aRrmsQ75 = apply(dRrms, 2, quantile, probs = 0.75);  # Third quartile Rrms.
      aRrmsSigmaMad = apply(dRrms, 2, mad);                # MAD std. deviation Rrms.
      # ....................................................................................................
      # . >>relative error squared:
      # ....................................................................................................
      aepsR2Q25 = apply(depsR2, 2, quantile, probs = 0.25);  # First quartile epsR2.
      aepsR2Median = apply(depsR2, 2, median);               # Median epsR2.
      aepsR2Q75 = apply(depsR2, 2, quantile, probs = 0.75);  # Third quartile epsR2.
      aepsR2SigmaMad = apply(depsR2, 2, mad);                # MAD std. deviation epsR2.
      # ....................................................................................................
      # . >>model P-values :
      # . First transform P-values into xi = -log10(P), the compute quantiles :
      # ....................................................................................................
      if (nrow(dpR) > 1) {
        dmlog10pR = apply(dpR, 2, Stat.getMlog10);
      } else {
        pBuf = dpR[1, ];
        dmlog10pR = ifelse(pBuf > 0.0, - log(pBuf, base = 10.0), 20.0);   # 20 is a standin for - log10(0).
        dmlog10pR = as.data.frame(dmlog10pR);                             # Convert to data frame.
      }

      amlog10pRQ25 = apply(dmlog10pR, 2, quantile, probs = 0.25);  # First quartile mlog10pR.
      amlog10pRMedian = apply(dmlog10pR, 2, median);               # Median mlog10pR.
      amlog10pRQ75 = apply(dmlog10pR, 2, quantile, probs = 0.75);  # Third quartile mlog10pR.
      amlog10pRSigmaMad = apply(dmlog10pR, 2, mad);                # MAD std. deviation mlog10pR.
      # ....................................................................................................



      # ....................................................................................................
      # . Generate single vectors of P-values and hazard ratios for the series of test sets generated 
      # . for all the feature selection levels :
      # ....................................................................................................
      nScan = ncol(ayPredBIG);        # Total number of feature selection levels.

      cat(" ..........  Compute significance of prediction on collected test \n");
      cat("             sets relative to actual output values.               \n");
      cat("             nScan = ", nScan, " feature selection levels will be tested.\n");            
      # .......................................................................................
      # . Generate nScan vectors and (n * nScan) arrays storing test results for each
      # . feature selection level:
      # .......................................................................................
      apPred = c();                    # P-values for significance of the predictions.
      aR2Pred = c();                   # R2-values for prediction models.
      aAlphaPred = c();                # y-intercepts for regression lines.
      aBetaPred = c();                 # Slopes for regression lines.
      aSigmaPred = c();                # Estimated standard dev in prediction noise.      

      aaucPred = c();                  # AUC for logistic regression.
      aaucPredLo95 = c();              # Lower bound on CI for AUC for logistic regression.
      aaucPredHi95 = c();              # Upper bound on CI for AUC for logistic regression.
      
      aerrMAP = c();                   # MAP error logistic regression.                      
      aerrMAPLo95 = c();               # Lower bound on CI for MAP error logistic regression.
      aerrMAPHi95 = c();               # Upper bound on CI for MAP error logistic regression.

      cat(">>Progress: ");             # Dots will follow.
      
      for (j in 1:nScan) {
        # .....................................................................................
        # . For each set of predictions generated at the given feature selection level,
        # . compute statistical measures of accuracy in prediction of observed values.
        # . Generate a P-value and associated values (coefficients, AUCs, etc).
        # .
        # . >> LINEAR REGRESSION MODEL :
        # . For each set of predictions generated at the given feature selection level,
        # . generate a linear regression of the observed values on the predicted values. 
        # . This results in a P-value and intercept and slope coefficients.
        # .....................................................................................
        if (modelType == 'lm') {
          ayPred = ayPredBIG[, j];       # The vector of predictions for the j-th feature selection level.

          fl = lm(ay ~ ayPred, na.action = 'na.omit');     # Regress observed on predicted. Omit NAs.
          fls = summary(fl);
        
          fscore = fls$fstatistic[1];       # F-statistic.
          alpha.lm = fl$coefficients[1];    # y-intercept of regression line.      
          beta.lm = fl$coefficients[2];     # Slope of regression line.
          R2 = fls$r.squared;               # R2 value.
          sigma.lm = fls$sigma;             # Estimate of standard dev. of noise.          

          numNA = length(which(is.na(ayPred)));                              # Number of NAs.
          n2 = length(ayPred) - 2 - numNA;                                   # df = n - 2.
          pval = pf(fscore, df1 = 1, df2 = n2, lower.tail = FALSE);          # Corresponding p-value.
          # ................................................................
          # . Assigned statistical metrics :
          # ................................................................                    
          apPred[j] = pval;              # P-values for significance of the predictions.
          aR2Pred[j] = R2;               # R2-values for prediction models.
          aAlphaPred[j] = alpha.lm;      # y-intercepts for regression lines.
          aBetaPred[j] = beta.lm;        # Slopes for regression lines.
          aSigmaPred[j] = sigma.lm;      # Standard deviation of noise.          
          # ................................................................
          # . Dummy values :
          # ................................................................
          aaucPred[j] = 0.5;             # Dummy value.
          aaucPredLo95[j] = 0.5;         # Dummy value.
          aaucPredHi95[j] = 0.5;         # Dummy value.
          aerrMAP[j] = 1.0;              # Dummy value.
          aerrMAPLo95[j] = 1.0;          # Dummy value.
          aerrMAPHi95[j] = 1.0;          # Dummy value.                    
          # ................................................................           
          cat(".", sep = "");            # Progress indicator.
        }
        # .....................................................................................                
        # . >> LOGISTIC REGRESSION MODEL :
        # . For each set of predictions generated at the given feature selection level,
        # . compute the AUC for detection of class 1 versus class 0, and the associated
        # . P-value (from the Wilcoxon test). Also compute a linear regression model
        # . of the observed output values on the cross-validated prognostic indices (PIs).
        # . This results in a P-value (not used here) and intercept and slope coefficients.
        # .....................................................................................        
        if (modelType == 'logistic') {
          axi = axiBIG[, j];               # Vector of cv'ed PIs for the j-th feature selection level.          
          aPyPred = aPyPredBIG[, j];       # Vector of est. P(y=1|x) for the j-th feature selection level.
          # ..............................................................
          # . For methodSplit = 'given', not all samples were re-cycled as
          # . test values. Therefore filter out NAs before doing roc calculations.
          # ..............................................................
          indexNoNA = which(!is.na(aPyPred));   # Index of calculated values.

          if (length(indexNoNA) > 0) {
            aPyPredBuf = aPyPred[indexNoNA];    # Filter down to calculated values.
            ayBuf = ay[indexNoNA];
            axiBuf = axi[indexNoNA];
          } else {
            aPyPredBuf = aPyPred;               # Or keep all.
            ayBuf = ay;
            axiBuf = axi;
          }
          # ..............................................................
          # . ROC and error statistics computation :
          # ..............................................................          
          #xxxx roc = Stat.basicROC(aPyPredBuf, ayBuf,
          roc = Stat.basicROC(axiBuf, ayBuf,
                              flagPval = TRUE,
                              flagConfInterval = FALSE,    # Not needed here.
                              flagNormalModel = FALSE,     # Not needed here.
                              prob = 0.95);
          
          aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);
          # ................................................................
          # . Generate a logistic model on the CV prognostic index :
          # ................................................................
          fl = glm(ay ~ axi, family = binomial("logit"), na.action = 'na.omit');   # Omit NAs.
          fls = summary(fl);
          acoef = fls$coefficients;     # Coefficients array.
          alpha.logit = acoef[1, 1];    # Intercept.
          beta.logit = acoef[2, 1];     # Slope for x-dependency.
          pbeta = acoef[2, 4];          # P-value for x-dependency.
          # ................................................................
          # . Assigned statistical metrics :
          # ................................................................                    
          apPred[j] = roc$pval;          # P-values for significance of the predictions.

          aaucPred[j] = roc$auc;         # AUC.
          aaucPredLo95[j] = aucStats$ALo;# Lower bound on CI for AUC.
          aaucPredHi95[j] = aucStats$AHi;# Upper bound on CI for AUC.
          
          aerrMAP[j] = roc$errMAP;       # MAP error logistic regression.                      
          aerrMAPLo95[j] = roc$errMAPLo; # Lower bound on CI for MAP error logistic regression. 
          aerrMAPHi95[j] = roc$errMAPHi; # Upper bound on CI for MAP error logistic regression. 
          
          aAlphaPred[j] = alpha.logit;   # y-intercepts for regression lines.
          aBetaPred[j] = beta.logit;     # Slopes for regression lines.
          # ................................................................
          # . Dummy values :
          # ................................................................          
          aR2Pred[j] = 1.0;              # Dummy value.
          aSigmaPred[j] = 0.0;           # Dummy value.          
          # ................................................................ 
          cat(".", sep = "");            # Progress indicator.
        }
        # .....................................................................................        
      }
      cat("\n");                # We are done.
      # ....................................................................................................
      # . Determine the feature selection level which minimizes the P-value. In cases of a tie, always
      # . choose the simplest model (smallest value of j):
      # ....................................................................................................
      pvalMin = min(apPred);                      # Smallest P-value.
      jmin = min(which(apPred == pvalMin));       # This resolves ties, if any, in favor of the simplest model.
     
      mtopMin = 0;                                # Dummy.
      KMin = 0;                                   # Dummy.

      ayPredMin = ayPredBIG[, jmin];                 # Vector of CVed predictions at the best tuning parameters.
      aPyPredMin = aPyPredBIG[, jmin];               # Vector of CVed est. P(y=1|x) at best tuning parameters.
      axiMin = axiBIG[, jmin];                       # Vector of PIs at best tuning parameters.           
      alphaPredMin = aAlphaPred[jmin];               # Corresponding intercept.
      betaPredMin = aBetaPred[jmin];                 # Corresponding slope.
      nPredMin = length(which(!is.na(ayPredMin)));   # Num.samples for which CVed values act. generated (non-NAs).
      # ....................................................................................................




      # ....................................................................................................
      # . FAILSAFE CHECK (this should be completely redundant) : check that the non-NA names for the
      # . cross-validated predictions are the same as those of the input data matrix!
      # ....................................................................................................
      abuf1 = arowName;
      abuf2 = names(ayPredMin);

      indexNA = which(is.na(ayPredMin));
      
      if (length(indexNA) > 0) {
        abuf1 = abuf1[-indexNA];   # Remove NAs.
        abuf2 = abuf2[-indexNA];   # Remove NAs.
      }

      errCount = sum(abuf2 != abuf1);       # Find discordant entries.

      if (errCount > 0) {
        cat("ERROR: from GlmnetCv.crossValidateRegress:\n");
        cat("Logical error: row names in ayPredMin not same as row names in input data matrix dfX.\n");
        cat("Check assignment of ayPred in GlmnetCv.crossValidateRegressSingleSplit().\n");
        stop();
      }
      # ....................................................................................................      




      # ....................................................................................................
      # . To pass fold-assignments :
      # ....................................................................................................
      if (methodSplit == 'vfoldStrict') {
        afold = cSplit$afold;
      } else if (methodSplit == 'given') {
        afold = af;
      } else {
        afold = rep(0, times = n);        
      }
      # ....................................................................................................      

      
     

      # .......................................................................
      # . Package results :
      # .......................................................................
      cv = list(modelType = modelType,
                parameterScan = 'lambda',
                ay = ay,
                methodSplit = methodSplit,
                ft = ft,
                rngSeed = rngSeed,
                afold = afold,
                aScan = c(lambda),                # Just one value.        
                nScan = 1,                        # Just one value.
                alpha = alpha,
                lambda = lambda,
                ncv = ncvHere,
                n = n,
                arowName = arowName,
                ntrain = ntrain,
                ntest = ntest,
                p = p,
                aRrmsQ25 = aRrmsQ25,
                aRrmsMedian = aRrmsMedian,
                aRrmsQ75 = aRrmsQ75,
                aRrmsSigmaMad = aRrmsSigmaMad,
                aepsR2Q25 = aepsR2Q25,
                aepsR2Median = aepsR2Median,
                aepsR2Q75 = aepsR2Q75,
                aepsR2SigmaMad = aepsR2SigmaMad,
                amlog10pRQ25 = amlog10pRQ25,
                amlog10pRMedian = amlog10pRMedian,
                amlog10pRQ75 = amlog10pRQ75,
                amlog10pRSigmaMad = amlog10pRSigmaMad,
                apPred = apPred,
                aR2Pred = aR2Pred,
                aAlphaPred = aAlphaPred,
                aBetaPred = aBetaPred,
                aSigmaPred = aSigmaPred,        
                aaucPred = aaucPred,
                aaucPredLo95 = aaucPredLo95,
                aaucPredHi95 = aaucPredHi95,              
                aerrMAP = aerrMAP,
                aerrMAPLo95 = aerrMAPLo95,
                aerrMAPHi95 = aerrMAPHi95,        
                jmin = jmin,
                ayPredMin = ayPredMin,
                aPyPredMin = aPyPredMin,
                axiMin = axiMin,        
                alphaPredMin = alphaPredMin,
                betaPredMin = betaPredMin,
                nPredMin = nPredMin
              );
        
      
      class(cv) = 'glmnet.regress.cv';
      # .......................................................................      

      

      # ...........................................................
      cat(" ..........  Exit GlmnetCv.crossValidateRegress.\n");
      # ...........................................................

      
      
      # .............
      return (cv);
      # .............

}

# ========================================================================================================
# . End of  GlmnetCv.crossValidateRegress.
# ========================================================================================================





# =================================================================================================
# . GlmnetCv.crossValidateRegressSingleSplit : generates a split of the data into training and test 
# . -----------------------------------------   sets, and then computes log-likelihood-ratios for the 
# .                                             test set for a range of the supervised principal
# .                                             components parameters.
# .
# .   Syntax:
# .
# .      cv =  GlmnetCv.crossValidateRegressSingleSplit(ay, dfX,
# .                                                     modelType,
# .                                                     methodSplit,
# .                                                     af, ft,
# .                                                     alpha, lambda,
# .                                                     icv, aindexSplit,
# .                                                     flagVerbose)
# .
# .   In:
# .            ay = n : vector of output values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     modelType = type of regression model to be used :
# .                 Allowed values : 
# .                  - 'lm' : linear model.
# .                  - 'logistic' : logistic distribution. 
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid).
# .
# .            - 'vfoldStrict'  : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, under methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, under
# .                 methodSplit = 'vfold'. Allowed: 0 < ft < 1.
# .
# .
# .     >> Fixed-values parameters:
# .
# .
# .         alpha = elastic net parameter that determines lasso-ridge 
# .                         regression penalty mixture :              
# .                         apha = 1.0, pure lasso, alpha = 0, pure ridge regression.
# .                         Allowed range : 0 <= alpha <= 1.0                        
# .                         alpha is fixed and is not varied in the cross-validation.
# .           
# .         lambda = point value for the Lagrange multiplier for the penalty 
# .                             term for generating a single-level set of results.
# .                             Note that cross-validation results are obtained for
# .                             all lambda values in the regularization path array 
# .                             (automatically) generated by glmnet.               
# .                             lambda is fixed and is not varied in the           
# .                             cross-validation.
# .
# .
# .     >> Split counter and groups :
# .
# .           icv = defines the group to be removed under split method 'vfoldStrict'.
# .                 This parameter is ignored otherwise.
# .   aIndexSplit = list of disjoint arrays, defining the groups to be removed for that round
# .                 of cross validation. Used under split method 'vfoldStrict', ignored
# .                 otherwise.
# .
# .
# .     >> General :
# .
# .   flagVerbose = if TRUE, prints progress on computation.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .       parameterScan = parameter that was scanned (mtop or K).
# .               nscan = number of discrete parameter values used.
# .               amtop = array of the nscan mtop values (for parameterScan = mtop).
# .                  aK = array of nscan K values (for parameterScan = K).
# .               aRrms = array of r.m.s. values of residuals for the test set, evaluated
# .                       using the training set model parameters.
# .              aepsR2 = array of relative error terms (residual variance / original variance).
# .                 apR = array of model P-values.
# .
# =================================================================================================

GlmnetCv.crossValidateRegressSingleSplit  <- function(ay, dfX,
                                                      modelType,
                                                      methodSplit,
                                                      af, ft,
                                                      alpha, lambda,
                                                      icv,
                                                      aIndexSplit,
                                                      flagVerbose)
{

      # ...........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in GlmnetCv.crossValidateRegressSingleSplit.\n");
      }
      # ...........................................................................

      
  
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      ny = length(ay);   # Number of samples in output variable vector.
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (ny != n) {
        msg = "ERROR: from GlmnetCv.crossValidateRegressSingleSplit: ";        
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      

      if (nf != n) {
        msg = "ERROR: from GlmnetCv.crossValidateRegressSingleSplit: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from GlmnetCv.crossValidateRegressSingleSplit: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((modelType == 'lm') || (modelType == 'logistic'));       
      stopifnot((methodSplit == 'given') || (methodSplit == 'vfoldStrict'));

      if (methodSplit == 'vfoldStrict') {
        ncvBuf = length(aIndexSplit);

        if (icv > ncvBuf) {
          cat("ERROR: from GlmnetCv.crossValidateRegressSingleSplit:\n");
          cat("icv = ", icv, " is greater than the number of groups to be cross-validated, ncv = ", ncvBuf, "\n", sep = "");
          stop();
        }
      }

      stopifnot(alpha >= 0, alpha <= 1.0);
      stopifnot(lambda >= 0.0);
      # ...................................................................................

      

      # ...................................................................................
      # . Generate the indices for splitting the data into training and test set.
      # .
      # . >> methodSplit = given :
      # ...................................................................................
      if (methodSplit == 'given') {
        # ......................................................................
        # . Check all given entries are 'train', 'test' or 'NONE' :
        # ......................................................................
        indexInvalid = which((af != 'train') & (af != 'test') & (af != 'NONE'));

        if (length(indexInvalid) > 0) {
          msg = "ERROR: from GlmnetCv.crossValidateRegressSingleSplit: ";        
          msg = paste("The train/test assignment vector contains some values which are neither ", sep = "");
          msg = paste("train, test or NONE. First detected invalid value = ", af[indexInvalid[1]], sep = "");
          stop(msg);
        }
        # ......................................................................
        # . Find the indices for the training and test subsets :
        # ......................................................................
        indexTrain = which(af == 'train');
        indexTest = which(af == 'test');

        ntrain = length(indexTrain);
        ntest = length(indexTest);        
        
        if (ntrain < 2) {
          msg = "ERROR: from GlmnetCv.crossValidateRegressSingleSplit: ";
          msg = paste("Less than 2 training set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntrain = ", ntrain, sep = "");          
          stop(msg);
        }

        if (ntest < 2) {
          msg = "ERROR: from GlmnetCv.crossValidateRegressSingleSplit: ";
          msg = paste("Less than 2 test set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntest = ", ntest, sep = "");          
          stop(msg);
        }        
        # ......................................................................        
      }
      # ...................................................................................      
      # . >> methodSplit = vfoldStrict :
      # . Under this option the groups were predefined before the function call,
      # . by function Stat.generateSplitsForVfold(). We just retrieve the indices.
      # ...................................................................................
      if (methodSplit == 'vfoldStrict') {
        # ......................................................................                
        indexTest = aIndexSplit[[icv]];
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }            
      # ...................................................................................      



      # ...................................................................................
      # . Generate the training and test subsets :
      # ...................................................................................
      ayTrain = ay[indexTrain];       # Output variable values.
      dfXTrain = dfX[indexTrain, ];   # Data matrix of gene expression values.

      ayTest = ay[indexTest];         # Output variable values.
      dfXTest = dfX[indexTest, ];     # Data matrix of gene expression values.        
      # ...................................................................................
      # . Adjust for special cases :
      # ...................................................................................
      if (length(indexTest) == 1) {
        dfXTest = matrix(dfXTest, nrow = 1);
      }
      # ...................................................................................      


      
      
      # ....................................................................................................
      # . Column-center the training data then generate univariate regression scores for
      # . each gene separately.
      # ....................................................................................................
      axm = colMeans(dfXTrain);                                # Save the p column means.
      ym = mean(ayTrain);                                      # The single mean for the outcome data.
      
      dfXc = scale(dfXTrain, center = TRUE, scale = FALSE);    # Center each gene separately.
      ayc = ayTrain - ym;                                      # Center the outcome vector.
      # .....................................................................................................


      

      # .................................................................................................
      # . >> MAIN COMPUTATION :
      # .................................................................................................
      t1 = proc.time()[3];              # Starting time.
      # .......................................................................................
      # . Compute the Cox proportional hazard model on all the input covariates :
      # .......................................................................................
      if (modelType == 'lm') {      
        fitLm = glmnet(x = dfXc, y = ayc, family = "gaussian", alpha = alpha, standardize = FALSE);           
      } else if (modelType == 'logistic') {
        fitLogit = glmnet(x = dfXc, y = ayTrain, family = "binomial", alpha = alpha, standardize = FALSE);                     
      }
      # ........................................................................................
      # . Compute the model predictions on the test set :
      # . This call returns :
      # .        axi = ntest : vector of prognostic indices xi = beta0 + beta . x
      # .     ayPred = ntest : vector of predicted output values.
      # .    aPyPred = ntest : vector of estimated P(y = 1|x) values 
      # .                         (dummy values = 0 for modelType = 'lm').
      # .........................................................................................
      dfXTestC = sweep(dfXTest, 2, axm);           # Center each column separately, using the training values.
      
      if (modelType == 'lm') {
        aPyPred = rep(0.0, times = nrow(dfXTestC));  # Dummy probability vector (not used here).        
        ayPred = ym + predict(fitLm,                 # nTest-length vector of predicted y values.
                              newx = dfXTestC,
                              s = c(lambda),
                              type = "response");
        axi = ayPred;                               # Here prognostic index and predicted values are identical.
      } else if (modelType == 'logistic') {
        aPyPred = predict(fitLogit,                 # Estimates of P(y = 1|x).
                          newx = dfXTestC,
                          s = c(lambda),
                          type = "response");
        ayPred = predict(fitLogit,                  # MAP estimates for y values.
                         newx = dfXTestC,
                         s = c(lambda),
                         type = "class");
        axi = predict(fitLogit,                     # nIn-length vector of logit(P(y = 1|x)) values.
                      newx = dfXTestC,
                      s = c(lambda),
                      type = "link");
      }
      # .......................................................................................
      # . Generate the columns of the matrix for the computed values, for each of the
      # . variables axi, ayPred and aPyPred. This creates a matrix of dimensions
      # . [samples * feature-selection levels] for the test samples, for this given split.
      # . The final matrix will have dimensions ntest * nScan.
      # .......................................................................................
      axiBIG = matrix(axi, nrow = length(axi));                 # The first column.
      rownames(axiBIG) = rownames(axi);
          
      ayPredBIG = matrix(ayPred, nrow = length(ayPred));        # The first column.
      rownames(ayPredBIG) = rownames(ayPred);

      aPyPredBIG = matrix(aPyPred, nrow = length(aPyPred));     # The first column.
      rownames(aPyPredBIG) = rownames(aPyPred);          
      # .......................................................................................
      # . Compute the residuals for the test set, using the model derived from
      # . the training set.
      # . Note that we are doing this for only the linear regression model, and that
      # . this is a holdover from an earlier measure of corss-validation.
      # .......................................................................................
      if (modelType == 'lm') {
        # ...............................................................................
        # . Compute the residuals and their rms value :
        # ...............................................................................
        aR = ayPred - ayTest;
        sumR2 = sum(aR * aR);                   # Sum of residuals squared.

        Rrms = sqrt(sumR2 / ntest);             # Root mean square value.
        epsR2 = (sumR2 / ntest) / var(ayTest);  # Relative error term.
        R2 = 1.0 - epsR2;                       # Coefficient of determination.
        pR = 1.0;                               # Dummy value.
      } else if (modelType == 'logistic') {
        Rrms = 1.0;                    # Dummy values.
        epsR2 = 1.0;
        pR = 1.0;
      }
      # .......................................................................................
      # . One-element arrays :
      # .......................................................................................
      aRrms = c(Rrms);
      aepsR2 = c(epsR2);
      apR = c(pR);        
      # .......................................................................................
      # . Summarize times :
      # .......................................................................................        
      cat("\n", sep = "");

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).

      if (flagVerbose) {
        cat(" ..........  Fold done. Time = ", t2, " s.", sep = "");
      }
      # .............................................................................................

      

      # ...............................................
      # . Package results :
      # ...............................................
      cv = list(methodSplit = methodSplit,
                n = n,
                ntrain = ntrain,
                ntest = ntest,
                aRrms = aRrms,
                aepsR2 = aepsR2,
                apR = apR,
                indexTest = indexTest,
                axiBIG = axiBIG,
                ayPredBIG = ayPredBIG,
                aPyPredBIG = aPyPredBIG);

      class(cv) = 'glmnet.regress.cv.single';
      # ...............................................


      # .............
      return (cv);
      # .............
      
}

# =================================================================================================
# . End of GlmnetCv.crossValidateRegressSingleSplit.
# =================================================================================================

