# =================================================================================================
# . Glmnet.r : functions for glmnet integration into the framework.
# . --------   
# .
# =================================================================================================

library(glmnet);
library(survival);

Glmnet.NZMAX = 5;      # Maximum number of distinct values for external covariate.

# =================================================================================================
# . Glmnet.checkDataMatricesForCoxWithCov : checks compatibility of the numerical data frame and the
# . --------------------------------------   experimental design data frame for Cox proportional hazard
# .                                          regression.
# .
# . This version allows for an additional external covariate.
# .
# .  Syntax :
# . 
# .             msg = Glmnet.checkDataMatricesForCoxWithCov(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                      mtop = number of features selected under feature selection
# .                             method `mtop'.
# .                     alpha = L1 and L2 penalty mix factor.
# .                    lambda = Lagrange multiplier for penalty.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain (unless tTrain = NONE, in which case all instances
# .        become training set members).
# .      - if tTrain is not NONE, then for that factor, dfE has at least two instances with value
# .        'train'.
# .
# =================================================================================================

Glmnet.checkDataMatricesForCoxWithCov <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # ................................................................................................
    # . Failsafe check on existence of required members :
    # ................................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxWithCov: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$mtop)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxWithCov: inparam does not have member mtop";
      stop(msg);
    }

    if (is.null(inparam$alpha)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxWithCov: inparam does not have member alpha";
      stop(msg);
    }

    if (is.null(inparam$lambda)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxWithCov: inparam does not have member lambda";
      stop(msg);
    }                
    # ................................................................................................

    

    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {
      if (is.null(dfE[[inparam$tTrain]])) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");
        msg = paste(msg, "the factor tTrain = ", inparam$tTrain,
                         " does not exist in the input experimental design.", sep = "");
        return (msg);
      }
    }

    if (inparam$tTest != 'NONE') {        
      if (is.null(dfE[[inparam$tTest]])) {
         msg = "ERROR: from Glmnet.checkDataMatricesForCoxWithCov: ";      
         msg = paste(msg, "the factor inparam$tTest = ", inparam$tTest,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }
    
    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................




    
    
    # .......................................................................................
    # . Check consistency of number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................

    
    
    # .......................................................................................
    # . Check on the number of training set members.
    # . General case, with a not NONE factor specified :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {    
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    
      if (nTrain == 0) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                     inparam$tTrain , " = train." , sep = "");
        return (msg);
      }

      if (nTrain < 2) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");         
        msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                    " records with values for factor ", inparam$tTrain , " = train. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, all members retained :
    # .......................................................................................
    if (inparam$tTrain == 'NONE') {    
      nTrain = n;                               # All samples are training set members.
      nNone = 0;                                # Number of all other samples is 0.
    }
    # .......................................................................................


    # .......................................................................................
    # . Check on the number of test set members.
    # .......................................................................................
    if (inparam$tTest != 'NONE') {    
      nTest = sum(dfE[[inparam$tTrain]] == 'test');     # Number of test set members.
    
      if (nTest == 0) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "the input experimental design has 0 records with values for factor tTest = ",
                     inparam$tTest , " = test." , sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . Special case, no test set specified:
    # .......................................................................................
    if (inparam$tTest == 'NONE') {    
      nTest = 0;
    }
    # .......................................................................................


    # .......................................................................................
    # . Check on feature selection level :
    # .......................................................................................
    if (inparam$flagFs == 'yes') {
      if (inparam$mtop <= 0) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "mtop = ", mtop, " is <= 0.\n" , sep = "");
        return (msg);
      }

      if (inparam$mtop > p) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "mtop = ", mtop, " is > p = ", p, " = number of genes.\n", sep = "");
        return (msg);
      }      
    }
    # .......................................................................................    

    

    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");

    if (inparam$tTest != 'NONE') {
      cat("             Number of samples in test set : nTest = ", nTest, "\n", sep = "");
    }      
    
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");                
    # .......................................................................................        


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of Glmnet.checkDataMatricesForCoxWithCov.
# =================================================================================================







# =================================================================================================
# . Glmnet.computeCoxWithCov : computes a de novo Cox proportional hazards model, given the
# . -------------------------   input sample survival times and censoring statuses.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .        gl = Glmnet.computeCoxWithCov(at, as, az, dfX,
# .                                      flagCenter,
# .                                      flagFs,
# .                                      mtop, typePval,
# .                                      alpha, alambda,
# .                                      lambda, nlambda,
# .                                      flagVerbose);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .    flagCenter = 'yes', mean-center the columns (genes) of the input data matrix.
# .                  'no', do not mean-center the columns.
# .
# .        flagFs = 'yes', perform first-level feature selection before submitting to coxnet.
# .                 'no',  perform coxnet with all genes as input.
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .                 Ignored if flagFs = 'no'.
# .
# .      typePval = type of the P-value that is to be used for the feature selection.
# .                 Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .                  Ignored if flagFs = 'no'.
# .
# .         alpha = elastic net parameter that determines the mix of L1 and L2
# .                 penalties :
# .                 alpha = 1 : pure lasso
# .                 alpha = 0 : pure ridge regression.
# .
# .       alambda = array of lambda values (in decreasing order) that will generate the regularization paths.
# .                 With alambda = NULL, glmnet automatically generates a lambda sequence (recommended option).
# .
# .      nlambda = number of lambda values to generate in the regularization paths. Note alambda and
# .                nlambda cannot be simultaneously non-NULL.
# .
# .        lambda = single value for Lagrange multiplier for penalty function, for point-wise computation of
# .                 Cox coefficients.
# .                 lambda >= 0.
# .
# .
# .   flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        gl = list, with members as specified in packaging step at function end (see below).
# .
# =================================================================================================

Glmnet.computeCoxWithCov <- function(at, as, az, dfX,
                                     flagCenter,
                                     flagFs, mtop, typePval,
                                     alpha,
                                     alambda = NULL,
                                     nlambda = NULL,
                                     lambda,
                                     flagVerbose)
{

      # ........................................................................
      stopifnot(alpha >= 0.0, alpha <= 1.0);

      stopifnot(is.null(alambda) || is.null(nlambda));
      
      if (!is.null(alambda)) {
        nbuf = length(alambda);
        stopifnot(nbuf > 0);
        if (nbuf > 1) {
          nbuf1 = nbuf - 1;
          abuf = alambda[1:nbuf1] - alambda[2:nbuf];

          if (min(abuf) <= 0.0) {
              cat("ERROR: from Glmnet.computeCoxWithCov:\n");
              cat("Input lambda sequence is not strictly decreasng.\n");
              stop();
          }
        }
      }

      if (!is.null(nlambda)) {
        stopifnot(nlambda > 0);
      }
      
      stopifnot(lambda >= 0.0);
      stopifnot((flagCenter == 'yes') || (flagCenter == 'no'));
      stopifnot((flagFs == 'yes') || (flagFs == 'no'));

      if (flagFs == 'yes') {
        stopifnot(mtop >= 1);      
        allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
        
        if (is.null(allowedTypePval[[typePval]])) {
          cat("ERROR: from Glmnet.computeCoxWithCov:\n");
          cat("typePval = ", typePval, " is not valid.\n", sep = "");
          cat("Valid: model, X, Z, ZX.\n", sep = "");
          stop();
        }
      }        
      # ........................................................................


      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in Glmnet.computeCoxWithCov.\n");
      }
      # ........................................................................      

      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................
      n = nrow(dfX);       # Number of samples.
      p = ncol(dfX);       # Number of genes.
      ac = colnames(dfX);  # Array of gene names.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.      

      if (nt != n) {
        msg = "ERROR: from Glmnet.computeCoxWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from Glmnet.computeCoxWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from Glmnet.computeCoxWithCov: ";
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (flagFs == 'yes') {
        if (mtop > p) {
          msg = "ERROR: from Glmnet.computeCoxWithCov: ";
          msg = paste("mtop = ", mtop, " is greater than number of genes p = ", p, sep = "");
          stop(msg);
        }
      }
      # ......................................................................................


     
      # .......................................................................................
      # . If requested, mean-center the columns (genes) of the input data matrix :
      # .......................................................................................
      if (flagCenter == 'yes') {
        axm = colMeans(dfX);                                     # Save the column means.
        dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.
      } else {
        axm = rep(0.0, times = p);                               # The values subtracted are 0.
        dfXc = as.matrix(dfX);                                   # No centering.
      }
      # .......................................................................................

      

      # ..............................................................................................
      # . FIRST PASS FEATURE SELECTION :
      # . >> 1. Actual feature selection is done here :
      # ..............................................................................................
      if (flagFs == 'yes') {
        # ............................................................................................   
        # . Generate Cox scores for each gene separately.
        # ............................................................................................   
        coxS = Cox.computeOnDataFrameSimpleBetaWithCov(at, as, az, dfXc, flagVerbose = TRUE);
        # ............................................................................................
        # . Perform the feature selection with the indicated method and parameters :
        # ............................................................................................
        methodFs = "mtop";    # Fixed.
        p0 = 1.0;             # Fixed.
        selF = SuperPc.selectFeaturesCoxWithCov(dfXc, methodFs, p0, mtop, coxS, typePval);
        # ............................................................................................       
      }
      # .............................................................................................. 
      # . >> Or, 2. Assign "NOOP" (identity) selection, if no first-pass feature selection was requested :
      # ..............................................................................................
      if (flagFs == 'no') {
        selF = SuperPc.selectFeaturesNOOP(dfXc);
      }
      # ..............................................................................................



      
      # .......................................................................................
      # . >> COXNET MODEL BUILDING :
      # . Generate the Cox proportional hazard model, using glmnet on the selected features :
      # .......................................................................................
      cSel = Glmnet.computeCoxOnSelectedFeaturesWithCov(at, as, az, selF$dfXSel,
                                                        alpha,
                                                        alambda, nlambda, lambda, flagVerbose);
      # .......................................................................................
      # . Collapse the selected features onto the active gene set, thereby imposing a
      # . second layer of feature selection :
      # .......................................................................................
      selFACT = Glmnet.collapseSelectedOnActive(selF, cSel);      
      # .......................................................................................
      # . Compute the baseline hazard functions (here using an approximation that assumes
      # . no ties) :
      # .......................................................................................
      bh = BasicCox.computeBaselineHazardNoTiesWithCov(at, as, az, cSel, selFACT$dfXSel);
      # .......................................................................................
      # . Project back to orignal p-dimensional vector space:
      # .......................................................................................
      fullP = Glmnet.projectToFullWithCov(p,
                                          cSel$abeta,
                                          cSel$agamma,        
                                          selFACT$indexSel);
      # .......................................................................................



      # .......................................................................................
      # . Get the genes that were selected by the computation :
      # .......................................................................................
      agFs = colnames(selF$dfXSel);          # Genes selected by the first-pass feature selection.
      agACT = colnames(selFACT$dfXSel);      # Genes further selected by elastic net.
      # .......................................................................................            

    
    

      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      msg = 'ok';
      
      gl = list(msg = msg,                   # Output message.
                flagCenter = flagCenter,     # Center genes (yes/no).
                alpha = alpha,               # L1 and L2 penalty mix coefficient.
                lambda = lambda,             # Lagrange multiplier for penalty term.
                mtop = mtop,                 # Number of genes for feature selection.           
                n   = n,                     # Number of samples.                               
                p   = p,                     # Number of genes.
                ac = ac,                     # p : column names (gene names).        
                axm = axm,                   # p : column means (gene-by-gene means).
                indexSel = selF$indexSel,          # Index of genes selected by mtop filter.
                indexSelACT = selFACT$indexSel,    # Index of active genes, selected by mtop AND glmnet.
                agFs = agFs,                  # Genes selected by the first-pass feature selection.
                agACT = agACT,                # Genes further selected by elastic net.
                m = selFACT$m,                # Number of selected genes.                        
                typePval = typePval,          # Type of P-value used for selection.        
                abeta = cSel$abeta,           # The Cox coefficients.
                aseBeta = cSel$aseBeta,       # Standard errors for the Cox coefficients.
                apBeta= cSel$apBeta,          # P-values for the Cox coefficients.
                betaZ = cSel$betaZ,           # External covariate Cox coeff.
                seBetaZ = cSel$seBetaZ,       # External covariate coeff std. err.
                pBetaZ = cSel$pBetaZ,         # External covariate coeff std. err.        
                agamma = cSel$agamma,         # The interaction terms.
                aseGamma = cSel$aseGamma,     # Standard errors for interaction terms.
                apGamma = cSel$apGamma,       # P-values for interaction terms.    
                qR = cSel$qR,                 # Loglikelihood ratio statistic.
                pR = cSel$pR,                 # P-value for loglikelihood ratio statistic.

                nlambdaOut = cSel$nlambdaOut, # Number of lambda values actually used.
                alambdaOut = cSel$alambdaOut, # Actual lambda values used (in decreasing order left to right).
                betaZBIG = cSel$betaZBIG,     # nlambda : Coeff. for the external covariate for all lambda.
                abetaBIG = cSel$abetaBIG,     # mtop * nlambda : Cox coefficients for genes for all lambda.
                agammaBIG = cSel$agammaBIG,   # mtop * nlambda : interaction terms coeffs. for all lambda.

                abetaTot = fullP$abetaTot,    # Cox coefficients, direct effects, in p-space.
                agammaTot = fullP$agammaTot,  # Cox coeffcients, interaction effects, in p-space.         
                fitB = cSel$fitB,             # glmnet coxnet model.
                bh = bh);                     # Baseline hazard object.
      
      class(gl) = 'glmnet.cox.cov';
      # .......................................................................................

      
      # ........................................................................
      if (flagVerbose) {
        cat(" ..........  Exit Glmnet.computeCoxWithCov.\n");
      }
      # ........................................................................            

      
      # .............
      return (gl);
      # .............
  
}

# =================================================================================================
# . End of Glmnet.computeCoxWithCov.
# =================================================================================================







# =================================================================================================
# . Glmnet.computeCoxOnSelectedFeaturesWithCov : computes a Cox proportional hazards model, given
# . ------------------------------------------   an input data matrix which has already undergone
# .                                              feature selection, and the input survival times and
# .                                              censoring statuses.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .       cSel = Glmnet.computeCoxOnSelectedFeaturesWithCov(at, as, az, dfXSel,
# .                                                         alpha, alambda, lambda, flagVerbose);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfXSel = n * m : data matrix of gene expression data, after mean-centering
# .                    and feature selection.
# .
# .            alpha = L1 and L2 penalty mix factor.
# .
# .       alambda = array of lambda values (in decreasing order) that will generate the regularization paths.
# .                 With alambda = NULL, glmnet automatically generates a lambda sequence (recommended option).
# .
# .      nlambda = number of lambda values to generate in the regularization paths. Note alambda and
# .                nlambda cannot be simultaneously non-NULL.
# .
# .
# .            lambda = Lagrange multiplier for penalty.
# .
# .       flagVerbose = logical flag, TRUE = verbose mode.
# .
# .
# .   Out:
# .        cSel = list, with members defined in final packaging step (see below).
# . 
# =================================================================================================

Glmnet.computeCoxOnSelectedFeaturesWithCov <- function(at, as, az, dfXSel,
                                                       alpha,
                                                       alambda = NULL,
                                                       nlambda = NULL,                                                       
                                                       lambda, flagVerbose)
{

      # ........................................................................... 
      if (flagVerbose) {
        cat(" ..........  Entry in Glmnet.computeCoxOnSelectedFeaturesWithCov.\n");
      }
      # ...........................................................................
      
  
      # .............................................................................
      stopifnot(alpha >= 0.0, alpha <= 1.0);

      stopifnot(is.null(alambda) || is.null(nlambda));    # They cannot both be non-NULL.
      
      if (!is.null(alambda)) {
        nbuf = length(alambda);
        stopifnot(nbuf > 0);
        if (nbuf > 1) {
          nbuf1 = nbuf - 1;
          abuf = alambda[1:nbuf1] - alambda[2:nbuf];

          if (min(abuf) <= 0.0) {
              cat("ERROR: from Glmnet.computeCoxOnSelectedFeaturesWithCov:\n");
              cat("Input lambda sequence is not strictly decreasng.\n");
              stop();
          }
        }
      }
      
      if (!is.null(nlambda)) {
        stopifnot(nlambda > 0);
      }
      
      stopifnot(lambda >= 0.0);      
      # ..............................................................................


      # ....................
      n = nrow(dfXSel);      
      m = ncol(dfXSel);
      # ....................


      # .................................................................................
      # . Check on lengths of arrays :
      # .................................................................................      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.      

      if (nt != n) {
        msg = "ERROR: from Glmnet.computeCoxOnSelectedFeaturesWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from Glmnet.computeCoxOnSelectedFeaturesWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from Glmnet.computeCoxOnSelectedFeaturesWithCov: ";
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      # .................................................................................


      
      # .......................................................................................
      # . Package the data so that we can directly submit to glmnet.
      # .
      # . Survival information, includig censoring :
      # .......................................................................................
      ay = Surv(at, as);        
      # .......................................................................................
      # . The gene expression data matrix, and same for interaction terms :
      # .......................................................................................      
      ax = as.matrix(dfXSel);                                # X values.
      azx = sweep(ax, 1, az, FUN = "*");                     # Z * X values.
      colnames(azx) = paste("Z.", colnames(ax), sep = "");   # Rename columns.
      # .......................................................................................
      # . Package all together :
      # .......................................................................................
      axB = cbind(Z = az, ax, azx);                          # dimensions = n * (2* m + 1)
      # .......................................................................................
      # . Penalty factors : exclude external covariate from shrinkage :
      # .......................................................................................
      af = rep(1.0, times = ncol(axB));
      af[1] = 0.0;                                           # No penalty on Z.
      # .......................................................................................       


      # .......................................................................................
      # . Compute the regularized Cox proportional hazard model, based on the general
      # . Cox proportional hazard model :
      # .
      # .     lambda(t|x, z) = lambda_0(t) *
      # .
      # .                           T                                T
      # .                   exp(beta  . x  +  betaZ . z  +  z . gamma . x)
      # .
      # . Note that glmnet computes the regularization paths for a complete range of
      # . values of lambda.
      # .......................................................................................
      if (flagVerbose) {
        cat(" ..........  Computing regularization paths with glmnet.\n");
      }
      # ...........................................................................
      # . >> 1. Both alambda and nlambda are unspecified :
      # ...........................................................................      
      if (is.null(alambda) && is.null(nlambda)) {
        fitB = glmnet(axB, ay, family = "cox",
                      alpha = alpha,
                      standardize = FALSE,
                      penalty.factor = af,
                      maxit = 1000);
      # ...........................................................................
      # . >> 2. nlambda (number of values) is specified :
      # ...........................................................................              
      } else if (is.null(alambda) && !is.null(nlambda)) {
        fitB = glmnet(axB, ay, family = "cox",
                      alpha = alpha,
                      nlambda = nlambda,
                      standardize = FALSE,
                      penalty.factor = af,
                      maxit = 1000);
      # ...........................................................................
      # . >> 3. alambda (array of values) is specified :
      # ...........................................................................                      
      } else if (!is.null(alambda) && is.null(nlambda)) {
        fitB = glmnet(axB, ay, family = "cox",
                      alpha = alpha,
                      lambda = alambda, 
                      standardize = FALSE,
                      penalty.factor = af,
                      maxit = 1000);
      # ...........................................................................
      # . >> 4. Failsafe :
      # ...........................................................................                              
      } else {
        cat("ERROR: from Glmnet.computeCoxOnSelectedFeaturesWithCov:\n");
        cat("nlambda and alambda cannot both be non-NULL (failsafe).\n");
        stop();
      }
      # ...........................................................................
      
      abetaB = coef(fitB, s = lambda);            # 1 + 2 * m coefficients (possibly many zero).
      # .......................................................................................
      # . Compute a P-value for the entire model, based on likelihood ratio test
      # . (this is a kind of placeholder -- altough the assumed sampling distribution
      # . for qR is admittedly wrong in this context, since beta is obtained
      # . not just from maximization of the log-likelihood by itself, but from maximization
      # . of the log-likelihood under the L1-L2 penalty constraint as well).
      # .......................................................................................            
      dfTemp = sum(abetaB != 0.0);                       # Degrees of freedom.

      val = Glmnet.interpolateOnLambda(fitB, lambda);    # Interpolate to retrieve deviance ratio.
            
      qR =  fitB$nulldev * val$dev.ratio;                 # Likelihood ratio statistic.
      pR = pchisq(qR, df = dfTemp, lower.tail = FALSE);   # p-value from likelihood ratio.      
      # ..................................................................................
      # . Extract the various coefficients, std. errs. and attendant P-values :
      # ..................................................................................
      betaZ = abetaB[1];               # Coeff. for the external covariate.
      seBetaZ = 0.0;                   # DUMMY: Std. err. for external covariate coeff.
      pBetaZ = 1.0;                    # DUMMY: P-value for external covariate coeff.

      ma = m + 1;
      abeta = abetaB[2:ma];            # m Cox coefficients for genes.
      aseBeta = rep(0.0, times = m);   # DUMMY: std. err. for genes.
      apBeta = rep(1.0, times = m);    # DUMMY: P-values for genes.

      mb = m + 2;
      mc = 2 * m + 1;
      agamma = abetaB[mb:mc];          # m interaction terms coeffs.
      aseGamma = rep(0.0, times = m);  # DUMMY: std. err. for interaction terms coeffs.
      apGamma = rep(1.0, times = m);   # DUMMY: P-values for the interaction terms.
      # .......................................................................................
      # . Filter down to keep only genes with non-zero effects in direct or interaction
      # . terms or both ("active" genes) :
      # .......................................................................................
      aflagDir = (abeta != 0.0);        # Direct terms.
      aflagInt = (agamma != 0.0);       # Interaction terms.
      aflagA = aflagDir | aflagInt;     # Flags all active genes.
      mACT = sum(aflagA);               # Number of active genes.
      
      if (mACT == 0) {
        cat("WARNING: from Glmnet.computeCoxOnSelectedFeaturesWithCov:\n");
        cat("No active genes were left after regularization.\n");
        indexACT = NULL;                # Index of active genes in the subsetted list
      } else {
        indexAll = 1:m;                 # All genes in current (perhaps already feat.sel.) list.
        indexACT = indexAll[aflagA];    # Index of active genes in the subsetted list.
      }
      # .......................................................................................
      # . Collapse all Cox coefficients to active values only :
      # .......................................................................................
      if (mACT > 0) {
        abeta = abeta[indexACT];        # Active subset only.
        agamma = agamma[indexACT];      # Active subset only.
      } else {
        abeta = NULL;                   # No active genes.
        agamma = NULL;                  # No active genes.
      }
      # .......................................................................................


      # .......................................................................................
      # . Collect the Cox coefficents for *all* the values of lambda which genearted the
      # . regularization paths :
      # .......................................................................................
      ma = m + 1;
      mb = m + 2;
      mc = 2 * m + 1;

      nlambdaOut = length(fitB$lambda);          # Number of lambda values actually used.
      alambdaOut = fitB$lambda;                  # Actual lambda values used (in decreasing order left to right).
      betaZBIG = fitB$beta[1, ];                 # Coeff. for the external covariate.
      abetaBIG = fitB$beta[2:ma, ];              # m Cox coefficients for genes.
      agammaBIG = fitB$beta[mb:mc, ];            # m interaction terms coeffs.
      # .......................................................................................            
      



      # .......................................................................................
      # . Package the results :
      # .......................................................................................
      cSel = list(m = m,                   # Input number of genes.
                  mACT = mACT,             # Final number of active genes (0 <= mACT <= m).
                  indexACT = indexACT,     # Index of active genes, in input data matrix.
                  abeta = abeta,           # mACT : the Cox coefficients.
                  aseBeta = aseBeta,       # mACT : standard errors for the Cox coefficients.
                  apBeta= apBeta,          # mACT : P-values for the Cox coefficients.
                  betaZ = betaZ,           # External covariate Cox coeff.
                  seBetaZ = seBetaZ,       # External covariate coeff std. err.
                  pBetaZ = pBetaZ,         # External covariate coeff std. err.        
                  agamma = agamma,         # mACT : the interaction terms.
                  aseGamma = aseGamma,     # mACT : standard errors for interaction terms.
                  apGamma= apGamma,        # mACT : P-values for interaction terms.    
                  qR = qR,                 # Loglikelihood ratio statistic.
                  pR = pR,                 # P-value for loglikelihood ratio statistic.
                  nlambdaOut = nlambdaOut, # Number of lambda values used.
                  alambdaOut = alambdaOut, # Actual lambda values used (in decreasing order left to right).
                  betaZBIG = betaZBIG,     # nlambda : Coeff. for the external covariate for all lambda.
                  abetaBIG = abetaBIG,     # m * nlambda : Cox coefficients for genes for all lambda.
                  agammaBIG = agammaBIG,   # m * nlambda : interaction terms coeffs. for all lambda.
                  fitB = fitB);            # Results of glmnet calculation.

      class(cSel) = 'glmnet.cox.cov.sel';
      # .......................................................................................

      
      # .............
      return (cSel);
      # .............
      

}

# =================================================================================================
# . End of Glmnet.computeCoxOnSelectedFeaturesWithCov.
# =================================================================================================




# =================================================================================================
# . Glmnet.interpolateOnLambda : interpolates on lambda to retrieve deviance ratio, etc.
# . --------------------------
# .
# . Syntax :
# .
# .       val = Glmnet.interpolateOnLambda(fitB, lambda);
# .
# . In :
# .
# .       fitB = glmnet object returned by a call to glmnet.
# .
# .       lambda = specified value fo lambda.
# .
# . Out :
# .
# =================================================================================================

Glmnet.interpolateOnLambda <- function(fitB, lambda)
{

      # ....................................................................
      if ((class(fitB)[1] != "glmnet") && (class(fitB)[2] != "glmnet")) {
        cat("ERROR: from Glmnet.interpolateOnLambda:\n");
        cat("fitB is not of class glmnet.\n");
        stop();
      }
      # ....................................................................

      
      # ...............................................................      
      nlambda = length(fitB$lambda);    # Total number of array points.
      # ...............................................................
  

  
      # ......................................................................
      # . Find indices of entries below input value
      # . (remember that internal array is in decreasing order) :
      # ......................................................................
      indexLo = which(fitB$lambda > lambda);

      flag = "internal";                # Default.
      
      if (length(indexLo) == 0) {
        ilo = 1;                         # Lamba is bigger than all internal 
        ihi = 1;                         # array values.
        flag = "left";  
      } else {
        ilo = max(indexLo);

        if (ilo < nlambda) {
          ihi = ilo + 1;                 # Lambda falls between two internal values.
        } else {
          ihi = ilo;                     # Lambda is smaller than all internal
          flag = "right";                # array values.           
        }                 
      }

      if (flag == "left") {
        dev.ratio = fitB$dev[1];
      } else if (flag == "right") {
        dev.ratio = fitB$dev[nlambda];
      } else {
        lambdaLo = fitB$lambda[ilo];
        lambdaHi = fitB$lambda[ihi];

        dev.ratio.Lo = fitB$dev[ilo];     # Nota bene : $dev may have changed to $dev.ratio
        dev.ratio.Hi = fitB$dev[ihi];     # in later versions of glmnet.

        dlambda = lambdaLo - lambdaHi;
        fHi = (lambdaLo - lambda) / dlambda;
        fLo = (lambda - lambdaHi) / dlambda;

        dev.ratio = fLo * dev.ratio.Lo + fHi * dev.ratio.Hi;
      }
      # ......................................................................


      # .........................................
      # . Package results :
      # .........................................
      val = list(dev.ratio = dev.ratio);
      # .........................................


      # ..............
      return (val);
      # ..............
}

# =================================================================================================
# . End of Glmnet.interpolateOnLambda.
# =================================================================================================





# =================================================================================================
# . Glmnet.collapseSelectedOnActive : collapses a selected features object onto the list
# . -------------------------------   of genes determined to be active by glmnet. This in effect
# .                                   instantiates a second level of feature selection.
# .
# .   Syntax:
# .
# .       selFOut = Glmnet.collapseSelectedOnActive(selF, cSel);
# .
# .   In:
# .
# .          selF = selected features object, returned by a call to:
# .                   SuperPc.selectFeaturesCoxWithCov();
# .                 Class must be:
# .                   "selected.features"
# .
# .          cSel = Cox model computation object returned by a call to:
# .                   Glmnet.computeCoxOnSelectedFeaturesWithCov();
# .                 Class must be:
# .                   "glmnet.cox.cov.sel"
# .                 The cSel object must have been generated using selF.
# .                 We do some checking on the basis of 
# .
# .   Out:
# .        cSel = selected features object. List, with members defined in final
# .               packaging step, as can be seen below.
# . 
# =================================================================================================

Glmnet.collapseSelectedOnActive <- function(selF, cSel)
{

      # ................................................................................
      if (class(selF) != "selected.features") {
        cat("ERROR: from Glmnet.collapseSelectedOnActive:\n");
        cat("Class of input selF = ", class(selF), " is not valid.\n", sep = "");
        stop();
      }

      if (class(cSel) != "glmnet.cox.cov.sel") {
        cat("ERROR: from Glmnet.collapseSelectedOnActive:\n");
        cat("Class of input cSel = ", class(cSel), " is not valid.\n", sep = "");
        stop();
      }

      if (cSel$m != selF$m) {
        cat("ERROR: from Glmnet.collapseSelectedOnActive:\n");
        cat("The number of features in selF object, m = ", selF$m, "\n", sep = "");
        cat("not the same as in the cSel object, m = ", cSel$m, "\n", sep = "");
        stop();
      }
      # ................................................................................


      # ................................................................................
      # . Subset the (global) index array and data matrix to the active genes.
      # ................................................................................      
      if (cSel$mACT > 0) {
        m = cSel$mACT;
        indexSel = selF$indexSel[cSel$indexA];
        dfXSel = selF$dfXSel[ , cSel$indexA];

        if (length(cSel$indexA) == 1) {
          dfXSel = as.matrix(dfXSel, nrow = nrow(selF$dfXSel));         # Special adjustment for 1 gene selected.
          colnames(dfXSel)[1] = colnames(selF$dfXSel)[cSel$indexA];
        }        
      } else {
        m = 0;
        indexSel = NULL;
        dfXSel = NULL;
      }

      pvalMin = 1.0;     # DUMMY value, as we cannot determine here.
      pvalMax = 1.0;     # DUUMY value, as we cannot determine here.

      typePval = selF$typePval;        # Replicate.
      # ................................................................................


      # .......................................................................................
      # . Package results :
      # .......................................................................................
      selFOut = list(typePval = typePval,
                     indexSel = indexSel,
                     m = m,
                     pvalMin = pvalMin,
                     pvalMax = pvalMax,
                     dfXSel = dfXSel   );

      class(selFOut) = "selected.features";
      # .......................................................................................

      
      # ................
      return (selFOut);
      # ................
      
  
}

# =================================================================================================
# . End of Glmnet.collapseSelectedOnActive.
# =================================================================================================






# =================================================================================================
# . Glmnet.projectToFullWithCov : projects the principal component vectors in feature-selected space back 
# . ----------------------------   to the full p-dimensional space.
# .                             
# .   Syntax:
# .
# .      fullP = Glmnet.projectToFullWithCov(p, abeta, agamma, indexSel);
# .
# .   In:
# .             p = dimensionality of full-dimensional space.
# .
# .         abeta = m-dimensional vector of Cox coefficients for direct effects, where
# .                 m = number of genes after all rounds of feature selection.        
# .
# .        agamma = m-dimensional vector ofCox coefficients for interaction effects,
# .                 where m = number of genes after all rounds of feature selection.        
# .
# .      indexSel = indices of genes in original index space 1..p, that were retained after
# .                 feature-selection.
# .
# .   Out:
# .
# .   fullP = list, with members :
# .
# .      abetaTot = p-dimensional vector of Cox coefficients for direct effects.
# .                 Components for genes which were not among the selected features are 0.
# .
# .     agammaTot = p-dimensional vector of Cox coeffcients for interaction effects.
# .                 Components for genes which were not among the selected features are 0.
# .
# =================================================================================================

Glmnet.projectToFullWithCov <- function(p, abeta, agamma, indexSel)
{

      # ...................................................................
      m = length(abeta);                     # Number of feature-selected genes implied.
      stopifnot(length(agamma) == m);
      stopifnot(length(indexSel) == m);
      stopifnot(m <= p);
      # ....................................................................

      
      # .......................................................................................
      # . Project back to original p-dimensional vector space:
      # .......................................................................................
      abetaTot = rep(0.0, times = p);
      abetaTot[indexSel] = abeta;          # Cox coeffcients in p-space, direct effects.

      agammaTot = rep(0.0, times = p);
      agammaTot[indexSel] = agamma;        # Cox coeffcients in p-space, interaction effects.
      # .......................................................................................


      # ................................................................
      # . Package results :
      # ................................................................
      fullP = list(abetaTot = abetaTot, agammaTot = agammaTot);
      # ................................................................

}

# =================================================================================================
# . End of Glmnet.projectToFullWithCov.
# =================================================================================================






# =================================================================================================
# . Glmnet.computeSignificanceOnCov : for a given glmnet-processed Cox model,computes log-hazard ratios
# . -------------------------------   for all input instances, determines a sensitive patient
# .                                   subset based on the differential log-hazard-ratio threshold,
# .                                   and computes Cox models comparing Z = 0 and Z = 1 arms,
# .                                   for all patients, and for the sensitive subset of patients.
# .
# . Syntax:
# .
# .    ds = Glmnet.computeSignificanceOnCov(gl, dfX, at, as, az, hRC);
# .
# . In:
# .
# .      gl = glmnet.cox.cov object, returned by Glmnet.computeCoxWithCov().
# .
# .     dfX = input data matrix; need not be the same as generated the
# .           Cox model, but must have the same number of genes.
# .
# .      at = vector of survival times.
# .      as = vector of censoring statuses.
# .      az = vector of external covariate values.
# .     hRC = threshold on differential log-hazard ratio, for determining sensitive patients.
# .
# . Out: list ds, with members :
# .
# .        hRC = threshold of predicted differential log-hazard ratio.
# .       nAll = total number of samples.
# .      csAll = significance scores for all samples, in Z = 1 to Z = 0 comparison.
# .      nSens = number of sensitive patients, defined at threshold hRC (can be 0).
# .     csSens = significance scores for sensitive patient samples, in Z = 1 to
# .              Z = 0 comparison.
# .
# .
# =================================================================================================

Glmnet.computeSignificanceOnCov <- function(gl, dfX, at, as, az, hRC)
{


        # .....................................................................................
        if (class(gl) != "glmnet.cox.cov") {
          msg = "ERROR: from Glmnet.computeSignificanceOnCov: ";
          msg = paste(msg, "The input gl is not of class: glmnet.cox.cov");
          stop(msg);
        }

        n = nrow(dfX);     # Number of samples.
        p = ncol(dfX);     # Number of genes.
      
        nt = length(at);   # Number of samples in survival time vector.
        ns = length(as);   # Number of samples in censoring status vector.
        nz = length(az);   # Number of samples in external covariate vector.
      
        if (nt != n) {
          msg = "ERROR: from Glmnet.computeSignificanceOnCov: ";
          msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
          msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
          stop(msg);
        }

        if (ns != n) {
          msg = "ERROR: from Glmnet.computeSignificanceOnCov: ";
          msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
          msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
          stop(msg);
        }

        if (nz != n) {
          msg = "ERROR: from Glmnet.computeSignificanceOnCov: ";          
          msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
          msg = paste("This is not the same as the n = ", n,
                      "samples in the data matrix dfX.", sep = "");        
          stop(msg);
        }
      
        if (gl$p != p) {
          msg = "ERROR: from Glmnet.computeSignificanceOnCov: ";                    
          msg = paste("The input data matrix does not have the same number of ");
          msg = paste("genes as in gl object. ");
          msg = paste("Input has p = " , p, " genes. ");
          msg = paste("gl has p = " , gl$p, " genes.");
          stop(msg);
        }

        stopifnot(hRC >= 0.0);      
        # ........................................................................................

        
      
        # .............................................................
        # . Compute significance, Surv(at, as) ~ az, for all samples.
        # .............................................................  
        csAll = Cox.computeBinaryCox(at, as, az);
        # .............................................................        

        
        # .......................................................................................
        # . Compute the log harzard ratios, using the model;
        # . determine sensitive patients based on the specified threshold.
        # .......................................................................................  
        sl = Glmnet.computeCoxLogHazardWithCovAndPred(gl, dfX, az, hRC);
        # .......................................................................................

        
        # ................................................................
        # . Subset to sensitive samples only :
        # ................................................................
        aSens = (sl$aflagSensitiveZ == 1);   # Mask for sensitive patients.
        nSens = sum(aSens);

        if (nSens > 0) {
          atSens = at[aSens];
          asSens = as[aSens];
          azSens = az[aSens];
        } else {
          atSens = c();
          asSens = c();
          azSens = c();
        }
        # .................................................................
        

        # .............................................................
        # . Compute significance, Surv(at, as) ~ az, for sensitive samples.
        # .............................................................
        if (nSens > 0) {
          csSens = Cox.computeBinaryCox(atSens, asSens, azSens);
        } else {
          csSens =NULL;
        }
        # .............................................................


        # .............................................................
        # . Package the results :
        # .............................................................
        ds = list(hRC = hRC,
                  nAll = n,
                  csAll = csAll,
                  nSens = nSens,
                  csSens = csSens);
        # .............................................................        

}

# =================================================================================================
# . End of Glmnet.computeSignificanceWithCov.
# =================================================================================================








# =================================================================================================
# . Glmnet.computeCoxLogHazardWithCovAndPred :  computes the log-hazard-ratios
# .------------------------------------------   for an input data matrix with an arbitrary 
# .                                             set of samples (not necessarily the ones used in
# .                                             the training set), based on the basic Cox model
# .                                             calculation.
# .
# . >>Predictor version : this version generates actual values of the hazard ratio, and in addition
# . also generates predictions for all distinct values of the external covariate Z
# . (up to Glmnet.NZMAX values).
# .
# .   Syntax:
# .
# .          s = Glmnet.computeCoxLogHazardWithCovAndPred(gl, dfXIn, azIn, hRC);
# .
# .   In:
# .         gl = result of basic Cox multivariate computation, returned
# .              by function Glmnet.computeCoxWithCov().
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .       azIn = input vector of covariate values. It must have the same number of rows as dfX.
# .              Samples need not ne the same as in the training set.
# .
# .
# .       hRC = cutoff on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .
# .   Out:
# .      s = list with members :
# .
# .       flagPred = TRUE, if prediction using the distinct values in azIn are made,
# .                  FALSE otherwise. Prediction is made provided the number of dictinct
# .                  values is no greater than Glmnet.NZMAX.
# .        flagBin = always FALSE if flagPred = FALSE. If TRUE, indicates that in addition
# .                  prediction was made for a binary external covariate ({0, 1}), and
# .                  includes in addition the differential log-hazard-ratio, and a flag
# .                  for samples predicted to be sensitive.
# .             az = copy of array of input values.
# .           azNR = array of distinct values of the external covariate.
# .
# .              Y = nIn * p data matrix after mean-centering with the training set means.
# .                  nIn = number of rows in dfXIn.
# .
# .         aloghR = nIn * L vector of log-hazard ratios; L = 1 if flagPred = FALSE
# .                  (no prediction, just estimated log-hazard ratio for training set values);
# .                  L = 1 + nzNR, if flagPred = TRUE, where nzNR = number of disctinct values
# .                  in azIn.
# .            ahR = nIn * L vector of hazard ratios (see above for definition of L).
# .          atMed = nIn * L estimated median survival times (see above for definition of L).
# .          azMin = absent if flagPred = FALSE, present if flagPred = TRUE.
# .                  Value of Z which minimizes estimated risk for that instance.
# .
# =================================================================================================

Glmnet.computeCoxLogHazardWithCovAndPred <- function(gl, dfXIn, azIn, hRC)
{

      # ..................................................................
      if (class(gl) != "glmnet.cox.cov") {
        msg = "ERROR: from Glmnet.computeCoxLogHazardWithCovAndPred: ";
        msg = paste(msg, "The input gl is not of class glmnet.cox.cov");
        stop(msg);
      }
      # ...................................................................


      # ..............................................................................
      p = ncol(dfXIn);
      n = nrow(dfXIn);
      
      if (gl$p != p) {
        msg = "ERROR: from Glmnet.computeCoxLogHazardWithCovAndPred: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste(msg, "features as in the training data matrix.", sep = "");
        msg = paste(msg, " Test has p = " , p, " genes.", sep = "");
        msg = paste(msg, " Training has gl$p = " , gl$p, " genes.", sep = "");
        stop(msg);
      }

      nz = length(azIn);

      if (nz != n) {
        cat("ERROR: from Glmnet.computeCoxLogHazardWithCovAndPred:\n");
        cat("Input external covariate array az has nz = ", nz, " elements. ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }

      stopifnot(hRC >= 0.0);      
      # ...............................................................................



      # ...................................................................................
      # . Preamble : test that there are not too many dictinct external covariate values.
      # . Assemble matrix of covariate values.
      # ...................................................................................
      flagPred = TRUE;          # Provisionally true.      

      azNR = unique(azIn);      # Array of distinct values of the external covariate.
      nzNR = length(azNR);      # Number of dictinct values.
      
      if (nzNR > Glmnet.NZMAX) {
        cat("WARNING : from Glmnet.computeCoxLogHazardWithCovAndPred:\n");
        cat("There are too many distinct values nzNR of the covariate.\n");
        cat("I found nzNR = ", nzNR, ", but allowed max. is Glmnet.NZMAX = ", Glmnet.NZMAX, "\n", sep = "");
        cat("I will generate hazard ratios only for the input covariate vector.\n");
        flagPred = FALSE;
      }

      if (flagPred) {
        azBuf = matrix(azNR, nrow = n, ncol = nzNR, byrow = TRUE);
        azMat = cbind(azIn, azBuf);
      } else {
        azMat = azIn;        
      }
      # ...................................................................................       



     
      # ..........................................................................................................
      # . Generate the subsetted data matrix :
      # ..........................................................................................................
      dfXc = sweep(dfXIn, 2, gl$axm);                # Center each column separately on the entire data matrix.
      dfXSel = dfXc[ , gl$indexSelACT];              # nIn * m data matrix subsetted to the selected ACTIVE genes.

      if (nrow(dfXc) == 1) {
        dfXSel = matrix(dfXSel, nrow = 1);           # Special case for nrow = 1, to preserve matrix geometry.
      }

      if (length(gl$indexSelACT) == 1) {
        dfXSel = as.matrix(dfXSel, nrow = nrow(dfXc));
        colnames(dfXSel) = colnames(dfXc)[gl$indexSelACT];
      }

      Y = dfXSel;                                    # Cox model is on gene expression values.
      # ............................................................................................................



      # ...................................................................................
      # . Compute the log-hazard ratios for all the samples. These are given by :
      # .
      # .                T                            T
      # .   aloghR   = xi  . beta  + beta  . z  + z xi  . gamma  , i = 1, 2, . . ., n.
      # .         i      i               Z    i       i
      # .
      # ...................................................................................      
      sM = Glmnet.computeCoxLogHazardForMultipleCov(gl, Y, azMat);
      # ...................................................................................


      # ...................................................................................
      # . In the case of multiple instances of covariate z, for each sample in turn,
      # . find the covariate value that minimizes the risk for that sample :
      # ...................................................................................
      if (flagPred) {
        ajMin = apply(sM$aloghR[ , -1], 1, which.min);                # We are excluding the actyal values from the comparison.
        azMin = sapply(1:n, function(i){azMat[i, 1 + ajMin[i]]});     # This retrieves the value of z for which the risk is minimized.
      }
      # ...................................................................................      
      

      # ...................................................................................
      # . Generate column names for the output matrices :
      # ...................................................................................
      abuf = c("actual");

      if (flagPred) {
        abuf = c(abuf, as.character(azNR));
      }

      colnames(sM$aloghR) = paste("loghR_z", abuf, sep = "");
      colnames(sM$ahR) = paste("hR_z", abuf, sep = "");
      colnames(sM$atMed) = paste("tMed_z", abuf, sep = "");
      # ...................................................................................


      
      # ...................................................................................
      # . For binary external covariates only:
      # . For all samples generate the predicted differential log-hazard-ratios,
      # . DloghR = loghR_z1 - loghRz_0, and flag as sensitive the samples with
      # . DloghR <= log(hRC).
      # ...................................................................................
      flagBin = FALSE;
      
      if (flagPred) {
        msg = Cox.checkBinary(azIn);

        if (msg == 'ok') {
          aDloghRz = sM$aloghR[ ,"loghR_z1"] - sM$aloghR[ ,"loghR_z0"];   # Predicted differential log-hazard-ratio.

          temp1 = log(hRC);                                               # Log-hazard-ratio threshold.
          aflagSensitiveZ = ifelse(aDloghRz <= temp1, 1, 0);              # Flag = 1 defines samples as sensitive.
          flagBin = TRUE;        
        }
      }
      # ...................................................................................      
      

     
      # ......................................................................
      # . Package the results :
      # ......................................................................
      s = list(flagPred = flagPred,
               flagBin = flagBin,        
               az = azIn,
               azNR = azNR,
               Y = Y,
               aloghR = sM$aloghR,
               ahR = sM$ahR,
               atMed = sM$atMed);

      if (flagPred) {
        s = c(s, list(azMin = azMin));
      }

      if (flagBin) {
        s = c(s, list(aDloghRz = aDloghRz, aflagSensitiveZ = aflagSensitiveZ));
      }
      # .......................................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of Glmnet.computeCoxLogHazardWithCovAndPred.
# =================================================================================================      







# =================================================================================================
# . Glmnet.computeCoxLogHazardForMultipleCov : computes the log-hazard-ratios given an input
# . ----------------------------------------   data matrix that is already column-centered,
# .                                              and for a series of  external
# .                                              covariates (not necessarily the ones used in
# .                                              the training set).
# .
# .   Syntax:
# .
# .          s = Glmnet.computeCoxLogHazardForMultipleCov(gl, Y, azMat);
# .
# .   In:
# .         gl = result of basic Cox computation, returned
# .              by function Glmnet.computeCoxWithCov().
# .
# .          Y = n * p input data matrix, after column centering with the training set means,
# .              vectors for an arbitrary set of n samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .      azMat = n * L input matrix of external covariate values.
# .              The values in the matrix are arbitrary, and to be used e.g. for prediction
# .              of response to treatment type.
# .
# .   Out:
# .      s = list with members :
# .
# .              Y = nIn * p data matrix,  after column centering with the training set means.
# .                  nIn = number of rows in dfXIn.
# .
# .         aloghR = nIn vector of log-hazard ratios.
# .            ahR = nIn vector of hazard ratios.
# .          atMed = estimated median survival times.
# .
# ................................................................................................
# . >> Note that the matrix Y is given by the n * p matrix of gene expresison values :
# .
# .           -                       -
# .           | x     x    . . .  x   |
# .           |  11    12          1p |
# .       Y = |                       |
# .           | . . .      . . .   .  |
# .           |                       |
# .           | x     x    . . .  x   |
# .           |  n1    n2          np |
# .           -                       -
# .
# . and x  the i-th sample vector (n components).
# .      i
# . This matrix must be precomputed before calling
# . Glmnet.computeCoxLogHazardForMultipleCov().
# .
# .
# . >>We then compute here the log-hazard ratios for all the samples, given by :
# .
# .                T                            T
# .   aloghR   =  x  . beta  + beta  . z  + z  x  . gamma  , i = 1, 2, . . ., n.
# .         i      i               Z    i       i
# .
# =================================================================================================

Glmnet.computeCoxLogHazardForMultipleCov <- function(gl, Y, azMat)
{

      # ....................................................................
      if (class(gl) != "glmnet.cox.cov") {
        msg = "ERROR: from Glmnet.computeCoxLogHazardForMultipleCov: ";
        msg = paste(msg, "The input gl is not of class glmnet.cox.cov");
        stop(msg);
      }
      # .....................................................................


      # ..............................................................................
      p = ncol(Y);           # Number of genes in Y.
      n = nrow(Y);           # Number of samples in Y.
      
      if (gl$m != p) {
        cat("ERROR: from Glmnet.computeCoxLogHazardForMultipleCov:\n");
        cat("Input data matrix Y does not have the same number of \n");
        cat("genes as in gl object.\n");
        cat("Y has p = " , p, " genes.");
        cat("gl object had gl$m = " , gl$m, " genes.");
        stop(msg);
      }

      nz = nrow(azMat);

      if (nz != n) {
        cat("ERROR: from Glmnet.computeCoxLogHazardForMultipleCov:\n");
        cat("Input external covariate array az has nz = ", nz, " rows. ",
            "not same as input matrix Y with n = ", n, " rows.\n", sep = "");
        stop();
      }      
      # ...............................................................................


      
      # ...................................................................................
      # . Compute the log-hazard ratios.
      # . For the i-th sample, with gene expression vector xi_i,
      # . and for an input value z_i for the external covariate, the log-hazard ratio
      # . is given by :
      # .
      # .                T                             T
      # .   aloghR   =  x  . beta  + beta  . z  + z   x  . gamma  , 
      # .         i      i               Z    i    i   i
      # .
      # .              ----------    ----------   --------------
      # .              gene          treatment    interaction
      # .              expression    effects      effects
      # .              effects
      # .
      # . which we compute for i = 1, 2, . . ., n.
      # .
      # ...................................................................................
      L = ncol(azMat);                             # Number of columns in azMat.

      if (ncol(Y) == 1) {
        aBuf1 =  Y * gl$abeta;                         # Special case for p = 1.
      } else {
        aBuf1 =  Y %*% gl$abeta;                       # n vector, direct terms beta * y.
      }
      
      aBufM1 = matrix(aBuf1, nrow = n, ncol = L);  # Spread to the L columns --> n * L matrix.
      aBufM2 = gl$betaZ * azMat;                   # n * L matrix, treatment effects.
      
      if (ncol(Y) == 1) {
        aBuf3 =  Y * gl$agamma;                       # Special case for p = 1.
      } else {      
        aBuf3 =  Y %*% gl$agamma;                     # n vector, interaction terms gamma * z * y.
      }
      
      aBufM3 = sapply(1:L, function(j){a = azMat[ ,j] * aBuf3; return(a);});

      aloghR = aBufM1 + aBufM2 + aBufM3;           # n * L matrix, log-hazard ratios.
      ahR = exp(aloghR);                           # n * L matrix, hazard ratios.

      bh = SuperPc.getBaselineHazard(gl);                # Baseline hazard information.
      atMed = SuperPc.computeTMedOnBaseline(bh, aloghR)    # Median survival time extimates.      
      # ...................................................................................


     
      # ..........................................................
      # . Package the results :
      # ..........................................................
      s = list(aloghR = aloghR, ahR = ahR, atMed = atMed);
      # ..........................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of Glmnet.computeCoxLogHazardForMultipleCov.
# =================================================================================================      





# =================================================================================================
# . Glmnet.computeCoxLogHazardWithCovBIG :  computes the log-hazard-ratios
# . ------------------------------------    for an input data matrix with an arbitrary 
# .                                         set of samples (not necessarily the ones used in
# .                                         the training set). This is done for ALL values
# .                                         of lambda generated by the regularization paths
# .                                         of the model.
# .
# .   Syntax:
# .
# .          s = Glmnet.computeCoxLogHazardWithCovBIG(gl, dfXIn, azIn);
# .
# .   In:
# .         gl = result of basic Cox multivariate computation, returned
# .              by function Glmnet.computeCoxWithCov().
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .       azIn = input vector of covariate values. It must have the same number of rows as dfX.
# .              Samples need not ne the same as in the training set.
# .
# .   Out:
# .
# .     aloghR = nIn * nlambda matrix of log-hazard ratios, where nIn = number of
# .              samples and nlambda = number of values of lambda in the regularization path.
# .
# =================================================================================================

Glmnet.computeCoxLogHazardWithCovBIG <- function(gl, dfXIn, azIn)
{

      # ..................................................................
      if (class(gl) != "glmnet.cox.cov") {
        msg = "ERROR: from Glmnet.computeCoxLogHazardWithCovBIG: ";
        msg = paste(msg, "The input gl is not of class glmnet.cox.cov");
        stop(msg);
      }
      # ...................................................................


      # ..............................................................................
      p = ncol(dfXIn);
      n = nrow(dfXIn);
      
      if (gl$p != p) {
        msg = "ERROR: from Glmnet.computeCoxLogHazardWithCovBIG: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste(msg, "features as in the training data matrix.", sep = "");
        msg = paste(msg, " Test has p = " , p, " genes.", sep = "");
        msg = paste(msg, " Training has gl$p = " , gl$p, " genes.", sep = "");
        stop(msg);
      }

      nz = length(azIn);

      if (nz != n) {
        cat("ERROR: from Glmnet.computeCoxLogHazardWithCovBIG:\n");
        cat("Input external covariate array az has nz = ", nz, " elements. ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }
      # ...............................................................................



     
      # ..........................................................................................................
      # . Generate the subsetted data matrix :
      # ..........................................................................................................
      dfXc = sweep(dfXIn, 2, gl$axm);                    # Center each column separately on the entire data matrix.
      dfXSel = dfXc[ , gl$indexSel];                     # nIn * m data matrix subsetted to the FIRST-PASS feature selected genes.

      if (nrow(dfXc) == 1) {
        dfXSel = matrix(dfXSel, nrow = 1);               # Special case for nrow = 1, to preserve matrix geometry.
        colnames(dfXSel) = colnames(dfXc)[gl$indexSel];
      } else if (length(gl$indexSel) == 1) {
        dfXSel = as.matrix(dfXSel, nrow = nrow(dfXc));
        colnames(dfXSel) = colnames(dfXc)[gl$indexSel];
      }
      # ..........................................................................................................
      # . Package the data :
      # ..........................................................................................................
      ax = as.matrix(dfXSel);                                # X values.
      azx = sweep(ax, 1, azIn, FUN = "*");                   # Z * X values.
      colnames(azx) = paste("Z.", colnames(ax), sep = "");   # Rename columns.
      axB = cbind(Z = azIn, ax, azx);                          # dimensions = n * (2* m + 1)
      # ..........................................................................................................
      # . Finally compute the log-hazard ratios. Note that :
      # .   axB = nIn * (2m + 1) matrix.
      # .   gl$fitB$beta = (2m + 1) * nlambda matrix.
      # .
      # .   aloghR = nIn * nlambda matrix.
      # ..........................................................................................................      
      aloghR = as.matrix(axB %*% gl$fitB$beta);
      # ...................................................................................

      
      # ................
      return (aloghR);
      # ................
      
}

# =================================================================================================
# . End of Glmnet.computeCoxLogHazardWithCovBIG.
# =================================================================================================      








# ========================================================================================================
# . Glmnet.checkDataMatricesForCoxCvWithCov : checks compatibility of the numerical data frame and the
# . ----------------------------------------   experimental design data frame for cross-validation of
# .                                            Cox proportional hazard model.
# .
# .  Syntax :
# . 
# .             msg = Glmnet.checkDataMatricesForCoxCvWithCov(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .                   tSplit = factor in dfE defining the further subdivision of the training
# .                            set members into train and test sets for the cross-validation.
# .                            values = 'train' denote the training set members in that group,
# .                            values = 'test' denote the test set members in that group.
# .                            values = 'NONE' are not included. All other values are invalid.
# .
# .                            If tSplit = 'NONE'itself, then checks on this field are not done
# .                            (it is ignored).
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .      - dfE has factor tSplit (check done only if tSplit not equal to 'NONE').
# .      - for the indicated factor tSplit (for non-NONE value), values in dfE 
# .        are either 'train', 'test' or 'NONE', and that the resulting training and
# .        test sets each have at least two member.
# .
# ========================================================================================================

Glmnet.checkDataMatricesForCoxCvWithCov <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # ..................................................................................................
    # . Failsafe check on existence of required members :
    # ..................................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$tSplit)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: inparam does not have member tSplit";
      stop(msg);
    }
    
    if (is.null(inparam$flagFs)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: inparam does not have member flagFs";
      stop(msg);
    }
    
    if (is.null(inparam$mtop)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: inparam does not have member mtop";
      stop(msg);
    }

    if (is.null(inparam$typePval)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: inparam does not have member typePval";
      stop(msg);
    }        
    # ...................................................................................................


    
    # .......................................................................................
    stopifnot((inparam$methodSplit == 'given') || (inparam$methodSplit == 'vfoldStrict'));
    # .......................................................................................

    

    # .......................................................................................
    # . Check existence of basic factors :
    # .......................................................................................
    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................
    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }

    if (inparam$methodSplit == 'given') {
      if (is.null(dfE[[inparam$tSplit]])) {
        msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";              
        msg = paste(msg, "the factor inparam$tSplit = ", inparam$tSplit,
                         " does not exist in the input experimental design,", sep = "");
        msg = paste(msg, " but is required under methodSplit = given.", sep = "");
        return (msg);
      }
    }    
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................




    # .......................................................................................
    # . Check on feature selection level :
    # .......................................................................................
    if (inparam$flagFs == 'yes') {
      if (inparam$mtop <= 0) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "mtop = ", mtop, " is <= 0.\n" , sep = "");
        return (msg);
      }

      if (inparam$mtop > p) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCov :\n", sep = "");  
        msg = paste(msg, "mtop = ", mtop, " is > p = ", p, " = number of genes.\n", sep = "");
        return (msg);
      }      
    }
    # .......................................................................................    


    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;    # All samples are in the training set.
      nNone = 0;     # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                   " records with values for factor ", inparam$tTrain , " = train. " ,
                   " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................



    
    # .......................................................................................
    # . Check train/test split. Compute ntrainCV, ntestCV.
    # .
    # . >> methodSplit = given :
    # .......................................................................................
    if (inparam$methodSplit == 'given') {    
      if (inparam$tTrain != 'NONE') {        
        dfETrain = dfE[dfE[[inparam$tTrain]] == 'train', ]; # The training set is a subset.
      } else if (inparam$tTrain == 'NONE') {
        dfETrain = dfE;                                     # The training set is the entire set.
      }

      buf = dfETrain[[inparam$tSplit]];
      bufEx = buf[(buf != 'train') & (buf != 'test') & (buf != 'NONE')];

      if (length(bufEx) > 0) {
        msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";         
        msg = paste(msg, "the input experimental design for factor inparam$tSplit = ", inparam$tSplit,
                         "has invalid values, which are neither train, test or NONE.", sep = "");
        return (msg);
      }

      nTrainCv = sum(dfETrain[[inparam$tSplit]] == 'train');   # Number of cv training set members.
      nTestCv = sum(dfETrain[[inparam$tSplit]] == 'test');     # Number of cv test set members.      
    
      if (nTrainCv == 0) {
        msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";
        msg = paste(msg, "the input experimental design has 0 cv training set ",
                         "records with values for factor ",
                         inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTrainCv < 2) {
        msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";        
        msg = paste(msg, "the input experimental design has only nTrainCv = ", nTrainCv,
                         " records with values for factor ", inparam$tSplit , " = train. " ,
                         " The minimum number is 2. ", sep = "");
        return (msg);
      }

      if (nTestCv == 0) {
        msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";        
        msg = paste(msg, "the input experimental design has 0 cv test set ",
                    "records with values for factor ",
                    inparam$tSplit , " = train." , sep = "");
        return (msg);
      }

      if (nTestCv < 2) {
        msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov: ";        
        msg = paste("the input experimental design has only nTestCv = ", nTestCv,
                    " records with values for factor ", inparam$tSplit , " = test. " ,
                    " The minimum number is 2. ", sep = "");
        return (msg);
      }
    }
    # .......................................................................................
    # . >> methodSplit = vfold :
    # .    The training set and the test set must each have at least 2 elements.
    # .    Note that we require above that nTrain >= 4, so that this is always possible.
    # ...................................................................................
    if (inparam$methodSplit == 'vfold') {
      nTestCv = floor(nTrain * inparam$ft);

      if (nTestCv < 2) {
        nTestCv = 2;                    # At least 2 elements in the test set.
      }

      n1 = nTrain - 1;

      if (nTestCv >= n1) {
        nTestCv = nTrain - 2;           # At least 2 elements in the training set.
      }

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }
    # .......................................................................................
    # . >> methodSplit = vfoldStrict :
    # .    
    # .    
    # ...................................................................................
    if (inparam$methodSplit == 'vfoldStrict') {
      csTemp = Stat.generateSplitsForVfold(nTrain, inparam$ft, flagRandom = FALSE);
      nTestCv = csTemp$ntest;

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }    
    # .....................................................................................



    
    # .......................................................................................
    # . Check on the external covariate :
    # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
    # . Note that this applies only to the cross-validation program, and not to the
    # . feature selection or model building cases.
    # .......................................................................................    
    msgBin = Cox.checkBinary(dfE[[inparam$tCov]]);

    if (msgBin != 'ok') {
      msg = paste("ERROR: from Glmnet.checkDataMatricesForCoxCvWithCov :\n", sep = "");
      msg = paste(msg, msgBin);

      return(msg);
    }
    # .......................................................................................

    

    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");

    cat("             Given cross-validation split of training set :\n", sep = "");      
    cat("             Training set : nTrainCv = ", nTrainCv, "\n", sep = "");
    cat("             Test set : nTestCv = ", nTestCv, "\n", sep = "");
    # .......................................................................................


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of Glmnet.checkDataMatricesForCoxCvWithCov.
# =================================================================================================





# ======================================================================================================
# . Glmnet.findLambdaIndex : finds the index in the input array for which the array value most closely 
# . ----------------------   matches the given input value of lambda.
# .
# . Syntax :
# .
# .       ilambda = Glmnet.findLambdaIndex(lambda, alambda);
# .
# . In :
# .
# .       lambda = specified value of lambda.
# .
# .       alambda = array of lambda values as returned by glmnet. Sorted according to
# .                 *decreasing* values of lambda.
# .
# . Out :
# .
# .       ilambda = nearest index.
# .
# =======================================================================================================

Glmnet.findLambdaIndex <- function(lambda, alambda)
{

      # ...............................................................      
      nlambda = length(alambda);    # Total number of array points.

      if (nlambda > 1) {
        nbuf1 = nlambda - 1;
        abuf = alambda[1:nbuf1] - alambda[2:nlambda];

        if (min(abuf) <= 0.0) {
          cat("ERROR: from GlmnetCv.crossValidateCoxWithCovSingleSplit:\n");
          cat("Input lambda sequence is not strictly decreasng.\n");
          stop();
        }
      }
      # ...............................................................
      
      
  
      # ......................................................................
      # . Find indices of entries below input value
      # . (remember that internal array is in decreasing order) :
      # ......................................................................
      indexLo = which(alambda > lambda);

      flag = "internal";                # Default.
      
      if (length(indexLo) == 0) {
        ilo = 1;                         # Lamba is bigger than all internal 
        ihi = 1;                         # array values.
        flag = "left";  
      } else {
        ilo = max(indexLo);

        if (ilo < nlambda) {
          ihi = ilo + 1;                 # Lambda falls between two internal values.
        } else {
          ihi = ilo;                     # Lambda is smaller than all internal
          flag = "right";                # array values.           
        }                 
      }

      if (flag == "left") {
        ilambda = 1;
      } else if (flag == "right") {
        ilambda = nlambda;
      } else {
        lambdaLo = alambda[ilo];
        lambdaHi = alambda[ihi];

        dLo = lambdaLo - lambda;
        dHi = lambda - lambdaHi;

        if (dLo <= dHi) {
          ilambda = ilo;
        } else {
          ilambda = ihi;
        }
      }
      # ......................................................................


      # ................
      return (ilambda);
      # ................
      
}

# =================================================================================================
# . End of Glmnet.findLambdaIndex.
# =================================================================================================





# ======================================================================================================
# . Glmnet.findNumberActiveGenes : for a given glmnet coefficient matrix generated by computation of the 
# . ----------------------------   regularization paths for a model with external covaraite, find the number of
# .                                active genes for each value of lambda.
# .
# . Syntax :
# .
# .        amACT = Glmnet.findNumberActiveGenes(gl);
# .
# . In :
# .
# .       gl = result returned by Glmnet.computeCoxWithCov().
# .
# . Out :
# .
# .      amACT = array of length gl$nlambdaOut, giving the number of active genes (those 
# .              with non-zero direct or interaction term coefficients). These values correspond to the lambdas 
# .              used in the model, given by array gl$alambdaOut.
# .
# =======================================================================================================

Glmnet.findNumberActiveGenes <- function(gl)
{

      # ..................................................................
      if (class(gl) != "glmnet.cox.cov") {
        cat("ERROR: from Glmnet.findNumberActiveGenes:\n");
        cat("The input gl is not of class glmnet.cox.cov\n");
        stop();
      }
      # ...................................................................



      # ...................................................................................................
      # . Collect the Cox coefficents for all the values of lambda which generated the
      # . regularization paths :
      # ...................................................................................................
      m21 = nrow(gl$fitB$beta);                  # Total number of Cox coefficents, = 2 * m + 1.
      nlambdaOut = gl$nlambdaOut;                # Number of lambda values actually used.
      
      if (m21%%2 != 1) {
        cat("ERROR: from Glmnet.findNumberActiveGenes:\n");
        cat("Something funny: the number of Cox coefficients is not odd.\n");
        cat("m21 = ", m21, " should be equal to 2 * m + 1.\n");
        stop();
      }

      m = (m21 - 1) / 2;                         # Number of genes in the model.
      
      ma = m + 1;
      mb = m + 2;
      mc = 2 * m + 1;

      betaZBIG = gl$fitB$beta[1, ];                     # Coeff. for the external covariate. Not used here.
      abetaBIG = as.matrix(gl$fitB$beta[2:ma, ]);       # m * nlambdaOut : coefficients for direct terms.
      agammaBIG = as.matrix(gl$fitB$beta[mb:mc, ]);     # m * nlambdaOut : coefficients for interaction terms.

      abetaFlag = (abetaBIG != 0.0);             # m * nlambdaOut : indicator for non-zero direct terms.
      agammaFlag = (agammaBIG != 0.0);           # m * nlambdaOut : indicator for non-zero interaction terms.

      aFlag = abetaFlag | agammaFlag;            # m * nlambdaOut : indicator for non-zero direct OR interaction terms.
      amACT = apply(aFlag, 2, sum);              # nlambdaOut : array of number of active genes.
      # ...................................................................................................      


      # ................
      return (amACT);
      # ................

}

# ======================================================================================================
# . End of Glmnet.findNumberActiveGenes.
# ======================================================================================================








# ========================================================================================================
# . Glmnet.checkDataMatricesForCoxCvWithCovBoot : checks compatibility of the numerical data frame and the
# . -------------------------------------------   experimental design data frame for cross-validation of
# .                                               Cox proportional hazard model embedded in bootstrap
# .                                               resampling.
# .
# .  Syntax :
# . 
# .             msg = Glmnet.checkDataMatricesForCoxCvWithCovBoot(dfX, dfE, inparam);
# .
# .  In:
# .             dfX = numerical data frame.
# .             dfE = experimental design data frame.
# .         inparam = list of input parameters, with at least members :
# .
# .                   tTrain = factor in dfE defining the training set members :
# .                            value = 'train' denotes the training set members,
# .                            all other values are excluded from the training set.
# .                            For the special value: tTrain = NONE, all members
# .                            are considered part of the training set.
# .
# .  Out :
# .             msg = 'ok', if no errors found, else string describing
# .                   first error encountered.
# .
# .  The function checks that :
# .
# .      - dfX and dFE have the same number of rows (= same number of samples).
# .      - dfE has factor tTrain.
# .      - for the indicated factor tTrain, dfE has at least two instances with value
# .        'train'.
# .
# ========================================================================================================

Glmnet.checkDataMatricesForCoxCvWithCovBoot <- function(dfX, dfE, inparam)
{

    # .................................
    msg = 'ok';   # Provisionally ok.
    # .................................


    
    # ..................................................................................................
    # . Failsafe check on existence of required members :
    # ..................................................................................................
    if (is.null(inparam$tTrain)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCovBoot: inparam does not have member tTrain";
      stop(msg);
    }

    if (is.null(inparam$flagFs)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCovBoot: inparam does not have member flagFs";
      stop(msg);
    }
    
    if (is.null(inparam$mtop)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCovBoot: inparam does not have member mtop";
      stop(msg);
    }

    if (is.null(inparam$typePval)) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCovBoot: inparam does not have member typePval";
      stop(msg);
    }        
    # ...................................................................................................


    
    # ...................................................
    stopifnot(inparam$methodSplit == 'vfoldStrict');
    # ...................................................

    

    # .......................................................................................
    # . Check existence of basic factors :
    # .......................................................................................
    if (is.null(dfE[[inparam$tTime]])) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, "the factor tTime = ", inparam$tTime,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }

    if (is.null(dfE[[inparam$tStatus]])) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, "the factor tStatus = ", inparam$tStatus,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }
    
    if (is.null(dfE[[inparam$tCov]])) {
      msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, "the factor tCov = ", inparam$tCov,
        " does not exist in the input experimental design.", sep = "");
      return (msg);
    }        
    # .......................................................................................
    

    
    
    # .......................................................................................
    # . Check existence of factors :
    # .......................................................................................    
    if (inparam$tTrain != 'NONE') {        
      if (is.null(dfE[[inparam$tTrain]])) {
         msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCovBoot: ";      
         msg = paste(msg, "the factor inparam$tTrain = ", inparam$tTrain,
                     " does not exist in the input experimental design.", sep = "");
         return (msg);
      }
    }
    # .......................................................................................
    # . Check consistency for number of records :
    # .......................................................................................
    p = ncol(dfX);      # Number of genes.
    n = nrow(dfX);      # Total number of samples.
    nE = nrow(dfE);     # Must be the same here.

    if (nE != n) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCovBoot: ";      
      msg = paste(msg, "the input experimental design has nE = ", nE, " samples, ",
                  " not the same as the numerical data matrix, n = ", n, sep = "");
      return (msg);
    }
    # .......................................................................................




    # .......................................................................................
    # . Check on feature selection level :
    # .......................................................................................
    if (inparam$flagFs == 'yes') {
      if (inparam$mtop <= 0) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCovBoot :\n", sep = "");  
        msg = paste(msg, "mtop = ", mtop, " is <= 0.\n" , sep = "");
        return (msg);
      }

      if (inparam$mtop > p) {
        msg = paste("ERROR:  from Glmnet.checkDataMatricesForCoxWithCovBoot :\n", sep = "");  
        msg = paste(msg, "mtop = ", mtop, " is > p = ", p, " = number of genes.\n", sep = "");
        return (msg);
      }      
    }
    # .......................................................................................    


    
    # .......................................................................................
    # . Check on number of training set members :
    # .......................................................................................
    if (inparam$tTrain != 'NONE') {        
      nTrain = sum(dfE[[inparam$tTrain]] == 'train');   # Number of training set members.
      nNone = sum(dfE[[inparam$tTrain]] != 'train');    # Number of all other samples.
    } else if (inparam$tTrain == 'NONE') {
      nTrain = n;    # All samples are in the training set.
      nNone = 0;     # None are left over.
    }
    
    if (nTrain == 0) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCovBoot: ";      
      msg = paste(msg, "the input experimental design has 0 records with values for factor ",
                  inparam$tTrain , " = train." , sep = "");
      return (msg);
    }

    if (nTrain < 4) {
      msg = "ERROR: from Glmnet.checkDataMatricesForCoxCvWithCovBoot: ";      
      msg = paste(msg, "the input experimental design has only nTrain = ", nTrain,
                   " records with values for factor ", inparam$tTrain , " = train. " ,
                   " The minimum number is 4. ", sep = "");
      return (msg);
    }
    # .......................................................................................



    
    # .......................................................................................
    # . Check train/test split. Compute ntrainCV, ntestCV.
    # .
    # . >> methodSplit = vfoldStrict :
    # ...................................................................................
    if (inparam$methodSplit == 'vfoldStrict') {
      csTemp = Stat.generateSplitsForVfold(nTrain, inparam$ft, flagRandom = FALSE);
      nTestCv = csTemp$ntest;

      nTrainCv = nTrain - nTestCv;      # Training set for cross-validation is balance.
    }    
    # .....................................................................................



    
    # .......................................................................................
    # . Check on the external covariate :
    # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
    # . Note that this applies only to the cross-validation program, and not to the
    # . feature selection or model building cases.
    # .......................................................................................    
    msgBin = Cox.checkBinary(dfE[[inparam$tCov]]);

    if (msgBin != 'ok') {
      msg = paste("ERROR: from Glmnet.checkDataMatricesForCoxCvWithCovBoot :\n", sep = "");
      msg = paste(msg, msgBin);

      return(msg);
    }
    # .......................................................................................

    

    
    # .......................................................................................
    # . Display tally of samples :
    # .......................................................................................
    cat(" ..........  Summary for input data matrices:\n", sep = "");
    cat("             Number of samples in training set : nTrain = ", nTrain, "\n", sep = "");
    cat("             Number of samples not in training set : nNone = ", nNone, "\n", sep = "");
    cat("             Total number of samples : n = ", n, "\n", sep = "");
    cat("             Total number of genes (features) : p = ", p, "\n", sep = "");

    cat("             Given cross-validation split of training set :\n", sep = "");      
    cat("             Training set : nTrainCv = ", nTrainCv, "\n", sep = "");
    cat("             Test set : nTestCv = ", nTestCv, "\n", sep = "");
    # .......................................................................................


    # .............
    return (msg);
    # .............

}

# =================================================================================================
# . End of Glmnet.checkDataMatricesForCoxCvWithCovBoot.
# =================================================================================================







# =================================================================================================
# . Glmnet.computeRegress : builds an elastic net regression model on the given training set.
# . ---------------------   
# .                         
# .
# .   Syntax:
# .
# .      gl =  Glmnet.computeRegress(ay,
# .                                  dfX,
# .                                  modelType,
# .                                  alpha,
# .                                  lambda,
# .                                  flagCv,
# .                                  nfolds,
# .                                  rngSeed,
# .                                  flagVerbose)
# .
# .   In:
# .            ay = n : vector of output values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     modelType = type of regression model to be used :
# .                 Allowed values : 
# .                  - 'lm' : linear model.
# .                  - 'logistic' : logistic distribution. 
# .
# .     >> Fixed-values parameters:
# .
# .
# .         alpha = elastic net parameter that determines lasso-ridge 
# .                         regression penalty mixture :              
# .                         apha = 1.0, pure lasso, alpha = 0, pure ridge regression.
# .                         Allowed range : 0 <= alpha <= 1.0                        
# .                         alpha is fixed and is not varied in the cross-validation.
# .           
# .         lambda = point value for the Lagrange multiplier for the penalty 
# .                  term for generating a single-level set of results.
# .                  Note that models are in fact obtained for
# .                  all lambda values in the regularization path array 
# .                  (automatically) generated by glmnet.
# .
# .         flagCv = yes/no; do a cross-validation over the entire regularization path?
# .
# .             ft = fraction put into each fold. Must be in range 0 < ft < 1 if flagCv = 'yes',
# .                  ignored otherwise.
# .
# .        rngSeed = seed for random number generator. Must be > 0 if flagCv = 'yes', ignored
# .                  otherwise.
# .
# .     >> General :
# .
# .   flagVerbose = if TRUE, prints progress on computation.
# .
# .
# .   Out:
# .
# =================================================================================================

Glmnet.computeRegress  <- function(ay,
                                   dfX,
                                   modelType,
                                   alpha,
                                   lambda,
                                   flagCv,
                                   ft,
                                   rngSeed,
                                   flagVerbose)
{

      # ...........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in Glmnet.computeRegress.\n");
      }
      # ...........................................................................

      
  
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      ac = colnames(dfX);             # Array of gene names.
      arowName = rownames(dfX);       # Array of sample names.
      
      ny = length(ay);   # Number of samples in output variable vector.

      if (ny != n) {
        msg = "ERROR: from Glmnet.computeRegress: ";        
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      

      if (n < 4) {
        msg = "ERROR: from Glmnet.computeRegress: ";        
        msg = paste("The number of samples in the data matrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      
      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((modelType == 'lm') || (modelType == 'logistic'));       
      stopifnot(alpha >= 0, alpha <= 1.0);
      stopifnot(lambda >= 0.0);
      stopifnot((flagCv == 'yes') || (flagCv == 'no'));

      if (flagCv == 'yes') {
        stopifnot(ft >0, ft < 1);
        stopifnot(rngSeed > 0);
      }
      # ...................................................................................

      


      
      
      # ....................................................................................................
      # . Column-center the training data then generate univariate regression scores for
      # . each gene separately.
      # ....................................................................................................
      axm = colMeans(dfX);                                     # Save the p column means.
      ym = mean(ay);                                           # The single mean for the outcome data.
      
      dfXc = scale(dfX, center = TRUE, scale = FALSE);         # Center each gene separately.
      ayc = ay - ym;                                           # Center the outcome vector.
      # .....................................................................................................



      # ...........................................................................
      if (flagVerbose) {
        cat(" ..........  Computing full glmnet regression model.\n");
      }
      # ...........................................................................
       
      

      # .................................................................................................
      # . >> MAIN COMPUTATION :
      # . Compute the elastic net regression model :
      # .................................................................................................
      if (modelType == 'lm') {      
        fitG = glmnet(x = dfXc, y = ayc, family = "gaussian", alpha = alpha, standardize = FALSE);
      } else if (modelType == 'logistic') {
        fitG = glmnet(x = dfXc, y = ay, family = "binomial", alpha = alpha, standardize = FALSE);
      }
      # .................................................................................................
      # . Get the regression coefficents at the specified value of lambda :
      # .................................................................................................
      abetaBuf = coef(fitG, s = lambda);            # 1 + p regression coefficients, possibly many 0.
      abeta = abetaBuf[2:length(abetaBuf)];         # p regression coefficients, excluding beta_0.
      beta0 = abetaBuf[1];                          # intercept term.

      indexSel = which(abeta != 0.0);               # Index of selected genes.
      m = length(indexSel);                         # Number of selected genes.
      # .................................................................................................


      
      # ...................................................................................................
      if (flagVerbose) {
        cat(" ..........  Glmnet computation done.\n");
        cat(" ..........  The glmnet model has selected m = ", m, " genes out of p = ", p, "\n", sep = "");
      }
      # ...................................................................................................



      
      # ..................................................................................................................
      # . Cross-validation over a range of values, if requested, using the native glmnet function :
      # ..................................................................................................................
      cv.fitG = NULL;
      afold = NULL;
      nfolds = 0;

      if (flagCv == 'yes') {
        # .................................................................................................................
        # . Determine the fold assignments :
        # .................................................................................................................
        set.seed(rngSeed);                                                           # Initialize the random number generator.
        cSplit = Stat.generateSplitsForVfold(n = n, ft = ft, flagRandom = TRUE);     # Generate disjoint groups.
        afold = cSplit$afold;
        ncv = cSplit$ncv;

        if (flagVerbose) {
          cat(" ..........  Performing cross-validation of glmnet regression model.\n");          
          cat(" ..........  Doing = ", cSplit$ncv, "-fold cross-validation for each lambda in entire range of lambda.\n", sep = "");
        }        
        # .................................................................................................................
        # . Do the cross-validation :
        # .................................................................................................................                
        if (modelType == 'lm') {
          cv.fitG = cv.glmnet(x = dfXc, y = ayc,
                             family = "gaussian",  alpha = alpha,
                             standardize = FALSE, foldid = cSplit$afold, type.measure = "mse");          
        } else if (modelType == 'logistic') {
          cv.fitG = cv.glmnet(x = dfXc, y = ay,
                              family = "binomial", alpha = alpha,
                              standardize = FALSE, foldid = cSplit$afold, type.measure = "auc");                  
        }
        # .................................................................................................................
        cat(" ..........  Cross-validation done.\n");        
      }
      # ...................................................................................................................
      
      

      
      # .............................................................................................
      # . Package results :
      # .............................................................................................
      msg = 'ok';      
      gl = list(msg = msg,                   # Output message.
                ay = ay,                     # Actual values of output variable.
                arowName = arowName,         # Sample names.
                modelType = modelType,       # Regression model used.
                alpha = alpha,               # L1/L2 parameter.
                lambda = lambda,             # Penalty term.
                n   = n,                     # Number of samples.                               
                p   = p,                     # Number of genes.
                ac = ac,                     # p : column names (gene names).
                ym = ym,                     # Value of mean for output variable.
                axm = axm,                   # p : column means (gene-by-gene means).
                indexSel = indexSel,         # Index of selected genes.                         
                m = m,                       # Number of selected genes.                        
                abeta = abeta,               # p : the regression coefficients, excl. intercept.    
                beta0 = beta0,               # Intercept coefficient.
                fitG = fitG,                 # Final glmnet model.
                flagCv = flagCv,             # Was a cross-validation also done?
                ncv = ncv,                   # Number of folds used.
                rngSeed = rngSeed,           # Random number seed for cross-validation.
                afold = afold,               # Fold assignments (NULL if oflagCv = 'no').
                cv.fitG = cv.fitG);          # Cross-validated object.

      class(gl) = 'glmnet.regress';
      # ..............................................................................................

      

      # .............
      return (gl);
      # .............
      
}

# =================================================================================================
# . End of Glmnet.computeRegress.
# =================================================================================================
















# =================================================================================================
# . Glmnet.computeRegressOutputVariable : computes the principal components and predicted
# . -----------------------------------   output variable for an input data matrix with an arbitrary 
# .                                       set of samples (not necessarily the ones used in
# .                                       the training set).
# .
# .   Syntax:
# .
# .          s = Glmnet.computeRegressOutputVariable(gl, dfXIn);
# .
# .   In:
# .        gl = result of supervised principal components computation, returned
# .              by function Glmnet.computeRegress().
# .
# .      dfXIn = input data frame with an arbitrary set of samples (not
# .              necessarily the ones used in the training set), but with
# .              the same set of genes as in the training set.
# .
# .   Out:
# .      s = list with members :
# .
# .            axi = nIn-length vector of prognostic indices:  xi = beta0 + beta * x
# .         ayPred = nIn-length vector of predicted output variable values.
# .        aPyPred = nIn-length vector of estimated P(y = 1|x) values
# .                  (non-zero for logistic regression; set to dummy all-zero
# .                  values for linear regression).
# .
# =================================================================================================

Glmnet.computeRegressOutputVariable <- function(gl, dfXIn)
{

      # ...............................................................................
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from Glmnet.computeRegressOutputVariable: ";
        msg = paste("The input gl is not of class glmnet.regress.");
        stop(msg);
      }

      stopifnot((gl$modelType == 'lm') || (gl$modelType == 'logistic'));  # Failsafe.
      # ................................................................................


      # ..............................................................................
      p = ncol(dfXIn);
      
      if (gl$p != p) {
        msg = "ERROR: from Glmnet.computeRegressOutputVariable: ";
        msg = paste("Input data matrix does not have the same number of ", sep = "");
        msg = paste("features as in the training data matrix.", sep = "");
        msg = paste(" Test has p = " , p, " genes.", sep = "");
        msg = paste(" Training has gl$p = " , gl$p, " genes.", sep = "");        
        stop(msg);
      }
      # ...............................................................................



      # ...............................................................................
      # . Compute the model predictions on the test set :
      # . This call returns :
      # .        axi = ntest : vector of prognostic indices xi = beta0 + beta . x
      # .     ayPred = ntest : vector of predicted output values.
      # .    aPyPred = ntest : vector of estimated P(y = 1|x) values 
      # .                         (dummy values = 0 for modelType = 'lm').
      # ...............................................................................
      dfXc = sweep(dfXIn, 2, gl$axm);                  # Center each column separately, using the training values.
      # ...................................................................................
      # . Linear regression model :
      # ...................................................................................
      flagDone = FALSE;                                # Failsafe.
      
      if (gl$modelType == 'lm') {
        aPyPred = rep(0.0, times = nrow(dfXc));        # Dummy probability vector (not used here).
        
        ayPred = gl$ym + predict(gl$fitG,              # n-length vector of predicted y values.
                                newx = dfXc,
                                s = c(gl$lambda),
                                type = "response");
        axi = ayPred;                                  # Here prognostic index and predicted values are identical.
        flagDone = TRUE;        
      }
      # ...................................................................................
      # . Logistic regression model :
      # ...................................................................................
      if (gl$modelType == 'logistic') {
        aPyPred = predict(gl$fitG,                  # Estimates of P(y = 1|x).
                          newx = dfXc,
                          s = c(gl$lambda),
                          type = "response");
        
        ayPred = predict(gl$fitG,                   # MAP estimates for y values.
                         newx = dfXc,
                         s = c(gl$lambda),
                         type = "class");
        
        axi = predict(gl$fitG,                      # nIn-length vector of logit(P(y = 1|x)) values.
                      newx = dfXc,
                      s = c(gl$lambda),
                      type = "link");
        # .............................................................................
        # . Make sure these are numerical one-dimensional vectors :
        # .............................................................................        
        aPyPred = as.numeric(aPyPred);
        ayPred = as.numeric(ayPred);
        axi = as.numeric(axi);        
        # .............................................................................        
        flagDone = TRUE;                
      }

      stopifnot(flagDone);                                            # Failsafe.      
      # ...................................................................................

     
      # ...............................................................................
      # . Package the results :
      # ...............................................................................
      s = list(axi = axi,                # Prognostic index:  xi = beta0 + beta * x
               ayPred = ayPred,          # Predictions (= xi for lm, = {0,1} for logistic).
               aPyPred = aPyPred);       # Estimator for P(y=1|x) (used only for logistic).
      
      class(s) = 'glmnet.regress.estimate';
      # ..............................................................................

      
      # ..........
      return (s);
      # ..........
      
}

# =================================================================================================
# . End of Glmnet.computeRegressOutputVariable.
# =================================================================================================      


