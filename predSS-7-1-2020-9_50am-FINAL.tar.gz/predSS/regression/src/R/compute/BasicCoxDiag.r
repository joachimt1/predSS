# =================================================================================================
# . BasicCoxDiag.r : diagnostic functions for direct Cox models.
# . --------------
# .
# =================================================================================================

BasicCoxDiag.MSELMAX = 1000;      # Maximum number of genes to be ddisplayed in a heat map.

# =========================================================================================================================
# . BasicCoxDiag.writeCoxCvWithCovSingle : writes Cox cross-validation results to the specified file. This version is
# . ------------------------------------   for cross-validation on a single level of tuning parameters.
# .                          
# .   Syntax:
# .           BasicCoxDiag.writeCoxCvWithCovSingle(cv, hRC, flagQlist, aqEff, fs);
# .
# .   In:
# .        cv = result of a cross-validation calculation, returned by call to
# .             BasicCoxCv.crossValidateCoxWithCov().
# .
# .       hRC = external threshold on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# . flagQlist = yes/no. If yes, indicates that a Qlist filter was used on the genes in the input
# .             data matrix.
# .
# .       aq = list of genes used as covariates.
# .
# .       fs = output file name.
# .
# =========================================================================================================================

BasicCoxDiag.writeCoxCvWithCovSingle <- function(cv, hRC, flagQlist, aq, fs)
{

      # ...........................................................
      if (class(cv) != "basic.cox.cov.cv") {
        msg = "ERROR: from BasicCoxDiag.writeCoxCvWithCovSingle: ";
        msg = paste("The input cv is not of class basic.cox.cov.cv.");
        stop(msg);
      }
      # ...........................................................

      
      # ................................................................
      cat(" ..........  Entry in BasicCoxDiag.writeCoxCvWithCovSingle.\n");
      # ................................................................


      # ................................................................
      # . Some simple failsafes here :
      # ................................................................      
      if (cv$cvType != 'single'){
        cat("ERROR: from BasicCoxDiag.writeCoxCvWithCovSingle:\n");
        cat("cross-validation type in input cv is not single.\n");
        stop();
      }

      if (cv$nScan != 1){
        cat("ERROR: from BasicCoxDiag.writeCoxCvWithCovSingle:\n");
        cat("Inconsistency: cross-validation type is single, but nScan = ",
            nScan, " != 1.\n", sep = "");
        stop();
      }

      stopifnot(hRC >= 0.0);

      stopifnot((flagQlist == 'yes') || (flagQlist == 'no'));
      # ................................................................      


      # ................................................................
      # . Open output file :
      # ................................................................
      FS = file(fs, "w");
      # ................................................................      
      
      
      # ................................................................
      # . >> PREAMBLE:
      # . Generate a text string containing the model summary :
      # ................................................................
      buf = "#PREAMBLE:\n";
      cat(buf, file = FS);
      
      txtSummary = BasicCoxDiag.generateCoxCvWithCovSummarySingle(cv);
      cat(txtSummary, file = FS);

      buf = "\n";
      cat(buf, file = FS);
      cat(buf, file = FS);       
      # ................................................................      

      

      # ....................................................................................
      # . List the genes used as covariates in the Cox model :
      # ....................................................................................
      NQMAX = 20;
      
      buf = paste("#TABLE A: genes used as covariates in the Cox model",
                  " (up to the first NQMAX = ", NQMAX, " listed):\n", sep = "");;
      cat(buf, file = FS);

      if (flagQlist == 'yes') {
        buf = paste("#Note: a subset of genes was selected from the input data matrix",
                    " through an indepdendently provided list.\n", sep = "");
        cat(buf, file = FS);
      }

      buf = paste("#-----------------------------------------------------------------------------------\n",
                   sep = "");            
      cat(buf, file = FS);
      # ..........................................................................
      # . Generate the gene list :
      # ..........................................................................      
      nq = length(aq);
      nqBuf = min(nq, NQMAX);     # List up to NQMAX genes.
      aqBuf = aq[1:nqBuf];
      buf = paste(aq, collapse = '\n');
      buf = paste("#QUAL\n", buf, "\n", sep = "");

      if (nq > NQMAX) {
        ntemp = nq - NQMAX;
        buf = paste(buf, "#(plus ", ntemp, " more . . . )\n", sep = "");
      }
      
      cat(buf, file = FS);      
      # ..........................................................................      
      buf = paste("#-----------------------------------------------------------------------------------\n",
                   sep = "");            
      cat(buf, file = FS);                  
      # ....................................................................................            

      

      
      # ....................................................................................
      # . Additional arrays for confidence intervals :
      # ....................................................................................
      alTrainLo = cv$alTrainMedian - cv$alTrainSigmaMad;
      alTrainHi = cv$alTrainMedian + cv$alTrainSigmaMad;

      aR2TrainLo = cv$aR2TrainMedian - cv$aR2TrainSigmaMad;
      aR2TrainHi = cv$aR2TrainMedian + cv$aR2TrainSigmaMad;

      acvPLLo = cv$acvPLMedian - cv$acvPLSigmaMad;                    
      acvPLHi = cv$acvPLMedian + cv$acvPLSigmaMad;

      alRatioTestLo = cv$alRatioTestMedian - cv$alRatioTestSigmaMad;
      alRatioTestHi = cv$alRatioTestMedian + cv$alRatioTestSigmaMad;

      aR2TestLo = cv$aR2TestMedian - cv$aR2TestSigmaMad;
      aR2TestHi = cv$aR2TestMedian + cv$aR2TestSigmaMad;
      
      aMrmsLo = cv$aMrmsMedian - cv$aMrmsSigmaMad;
      aMrmsHi = cv$aMrmsMedian + cv$aMrmsSigmaMad;            
      # ......................................................................................

     
      # ......................................................................................
      # . Write cross-validation statistics here :
      # ......................................................................................
      buf = paste("\n\n", sep = "");
      cat(buf, file = FS);      
     
      buf = "#TABLE 1: cross-validation statistics for the specified tuning parameters:\n";
      cat(buf, file = FS);

      buf = paste("#-----------------------------------------------------------------------------------\n",
                   sep = "");            
      cat(buf, file = FS);      
      # ..........................................................................
      # . Write header :
      # ..........................................................................
      buf = paste("#Parameter\tValue\tDescription\n", sep = "");
      cat(buf, file = FS);
      # ..........................................................................
      # . Write body :
      # ..........................................................................      
      j = 1;
      # ..........................................................................
      # . Tuning parameters :
      # ..........................................................................      
      buf = paste("p\t", cv$p,
                  "\tNumber of genes used in model\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRC\t", hRC,
                  "\tExternal threshold for defining sensitives\n", sep = "");
      cat(buf, file = FS);      
      # ..........................................................................
      # . Predictive variables on internal threshold :
      # ..........................................................................
      buf = paste("hRCMin", "\t", sprintf("%10.5e", cv$ahRC[j]),
                  "\tInternal threshold: DloghR <= hRCMin achieves minimum P-value\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("pRMin", "\t", sprintf("%10.5e", cv$apRMin[j]),
                  "\tInternal threshold: Minimum P-value for split DloghR <= hRCMin\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRMin", "\t", sprintf("%10.5e", cv$ahRMin[j]),
                  "\tInternal threshold: Hazard-ratio obtained for DloghR <= hRCMin\n", sep = "");
      cat(buf, file = FS);
     
      buf = paste("nMin", "\t", sprintf("%10.5e", cv$aicMin[j]),
                  "\tInternal threshold: Number of sensitive patients obtained for DloghR <= hRCMin\n", sep = "");
      cat(buf, file = FS);      
      # ..........................................................................
      # . Log-likelihood, training set :
      # ..........................................................................            
      buf = paste("LTrainLo\t", sprintf("%10.5e", alTrainLo[j]),
                  "\tLog-likelihood, training set\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("LTrainMedian\t", sprintf("%10.5e", cv$alTrainMedian[j]),
                  "\tLog-likelihood, training set\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("LTrainHi\t", sprintf("%10.5e", alTrainHi[j]),
                  "\tLog-likelihood, training set\n", sep = "");
      cat(buf, file = FS);      

      buf = paste("LTrainQ25\t", sprintf("%10.5e", cv$alTrainQ25[j]),
                  "\tLog-likelihood, training set\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("LTrainQ75\t", sprintf("%10.5e", cv$alTrainQ75[j]),
                  "\tLog-likelihood, training set\n", sep = "");
      cat(buf, file = FS);
      # ..........................................................................
      # . R2, training set :
      # ..........................................................................      
      buf = paste("R2TrainLo\t", sprintf("%10.5e", aR2TrainLo[j]),
                  "\tR2, training set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("R2TrainMedian\t", sprintf("%10.5e", cv$aR2TrainMedian[j]),
                  "\tR2, training set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("R2TrainHi\t", sprintf("%10.5e", aR2TrainHi[j]),
                  "\tR2, training set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("R2TrainQ25\t", sprintf("%10.5e", cv$aR2TrainQ25[j]),
                  "\tR2, training set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("R2TrainQ75\t", sprintf("%10.5e", cv$aR2TrainQ75[j]),
                  "\tR2, training set\n", sep = "");
      cat(buf, file = FS);
      # ..........................................................................
      # . Cross-validated log-likelihood :
      # ..........................................................................            
      buf = paste("cvPLLo\t", sprintf("%10.5e", acvPLLo[j]),
                  "\tCross-validated log-likelihood\n", sep = "");
      cat(buf, file = FS);

      buf = paste("cvPLMedian\t", sprintf("%10.5e", cv$acvPLMedian[j]),
                  "\tCross-validated log-likelihood\n", sep = "");
      cat(buf, file = FS);

      buf = paste("cvPLHi\t", sprintf("%10.5e", acvPLHi[j]),
                  "\tCross-validated log-likelihood\n", sep = "");
      cat(buf, file = FS);

      buf = paste("cvPLQ25\t", sprintf("%10.5e", cv$acvPLQ25[j]),
                  "\tCross-validated log-likelihood\n", sep = "");
      cat(buf, file = FS);

      buf = paste("cvPLQ75\t", sprintf("%10.5e", cv$acvPLQ75[j]),
                  "\tCross-validated log-likelihood\n", sep = "");
      cat(buf, file = FS);

      buf = paste("cvPL\t", sprintf("%10.5e", cv$acvPL[j]),
                  "\tTotal cross-validated log-likelihood\n", sep = "");
      cat(buf, file = FS);      
      # ..........................................................................
      # . Log-likelihood ratio on test set :
      # ..........................................................................
      buf = paste("LRatioTestLo\t", sprintf("%10.5e", alRatioTestLo[j]),
                  "\tLog-likelihood ratio on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("LRatioTestMedian\t", sprintf("%10.5e", cv$alRatioTestMedian[j]),
                  "\tLog-likelihood ratio on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("LRatioTestHi\t", sprintf("%10.5e", alRatioTestHi[j]),
                  "\tLog-likelihood ratio on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("LRatioTestQ25\t", sprintf("%10.5e", cv$alRatioTestQ25[j]),
                  "\tLog-likelihood ratio on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("LRatioTestQ75\t", sprintf("%10.5e", cv$alRatioTestQ75[j]),
                  "\tLog-likelihood ratio on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("pRatioTestQ25\t", sprintf("%10.5e", cv$apRatioTestQ25[j]),
                  "\tLog-likelihood ratio on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("pRatioTestMedian\t", sprintf("%10.5e", cv$apRatioTestMedian[j]),
                  "\tLog-likelihood ratio on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("pRatioTestQ75\t", sprintf("%10.5e", cv$apRatioTestQ75[j]),
                  "\tLog-likelihood ratio on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("pRatioTestCombine\t", sprintf("%10.5e", cv$apRatioTestCombine[j]),
                  "\tLog-likelihood ratio on test set\n", sep = "");
      cat(buf, file = FS);
      # ..........................................................................
      # . R2 on test set :
      # ..........................................................................
      buf = paste("R2TestLo\t", sprintf("%10.5e", aR2TestLo[j]),
                  "\tR2 on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("R2TestMedian\t", sprintf("%10.5e", cv$aR2TestMedian[j]),
                  "\tR2 on test set\n", sep = "")
      cat(buf, file = FS);

      buf = paste("R2TestHi\t",  sprintf("%10.5e", aR2TestHi[j]),
                  "\tR2 on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("R2TestQ25\t", sprintf("%10.5e", cv$aR2TestQ25[j]),
                  "\tR2 on test set\n", sep = "");
      cat(buf, file = FS);

      buf = paste("R2TestQ75\t", sprintf("%10.5e", cv$aR2TestQ75[j]),
                  "\tR2 on test set\n", sep = "");
      cat(buf, file = FS);
      # ..........................................................................
      # . Martingale residuals :
      # ..........................................................................
      buf = paste("MrmsLo\t", sprintf("%10.5e", aMrmsLo[j]),
                  "\tMartingale residuals\n", sep = "");
      cat(buf, file = FS);

      buf = paste("MrmsMedian\t", sprintf("%10.5e", cv$aMrmsMedian[j]),
                  "\tMartingale residuals\n", sep = "");
      cat(buf, file = FS);

      buf = paste("MrmsHi\t", sprintf("%10.5e", aMrmsHi[j]),
                 "\tMartingale residuals\n", sep = "");
      cat(buf, file = FS);

      buf = paste("MrmsQ25\t", sprintf("%10.5e", cv$aMrmsQ25[j]),
                  "\tMartingale residuals\n", sep = "");
      cat(buf, file = FS);

      buf = paste("MrmsQ75\t", sprintf("%10.5e", cv$aMrmsQ75[j]),
                 "\tMartingale residuals\n", sep = "");
      cat(buf, file = FS);

      buf = paste("#-----------------------------------------------------------------------------------\n",
                   sep = "");      
      cat(buf, file = FS);       
      # ............................................................................................



      # ..........................................................................
      # . Find the sensitive samples, and compute Cox statistics for Z=1 to Z=0
      # . comparisons.
      # . This is done for wo values of the differential hazard-ratio threshold,
      # . the internal threshold, for which the P-value is minimized, and the
      # . external threshold, which is user-provided.
      # ..........................................................................
      cSens = SuperPcCv.computeCoxSensitivesOnBinary(cv, hRC);
      # ......................................................................................
      # . Write statistics on sensitive subsets here :
      # ......................................................................................
      buf = paste("\n\n", sep = "");
      cat(buf, file = FS);      
      
      buf = "#TABLE 2: statistics for sensitive subsets:\n";
      cat(buf, file = FS);

      buf = paste("#-----------------------------------------------------------------------------------\n",
                   sep = "");
      cat(buf, file = FS);      
      # ..........................................................................
      # . Write header :
      # ..........................................................................
      buf = paste("#Parameter\tValue\tDescription\n", sep = "");
      cat(buf, file = FS);
      # ..........................................................................
      # . >> Predictive variables on internal threshold :
      # ..........................................................................
      buf = paste("hRCMin", "\t", sprintf("%10.5e", cSens$hRCMin),
                  "\tInternal threshold: DloghR <= hRCMin achieves minimum P-value (same as in Table 1)\n",
                  sep = "");
      cat(buf, file = FS);

      buf = paste("nSensitiveMin", "\t", sprintf("%10.5e", cSens$nSensitiveMin),
                  "\tInternal threshold: Number of sensitive patients obtained for DloghR <= hRCMin",
                  " (same as in Table 1)\n",
                  sep = "");
      cat(buf, file = FS);            
      
      buf = paste("pRMin", "\t", sprintf("%10.5e", cSens$pRMin),
                  "\tInternal threshold: Minimum P-value for split DloghR <= hRCMin (same as in Table 1)\n",
                  sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRMin", "\t", sprintf("%10.5e", cSens$hRMin),
                  "\tInternal threshold: Hazard-ratio obtained for DloghR <= hRCMin  (same as in Table 1)\n",
                  sep = "");
      cat(buf, file = FS);

      buf = paste("hRMinLo", "\t", sprintf("%10.5e", cSens$hRMinLo),
                  "\tInternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRMinHi", "\t", sprintf("%10.5e", cSens$hRMinHi),
                  "\tInternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");            
      cat(buf, file = FS);      
      # ..........................................................................
      # . >> Predictive variables on external threshold :
      # ..........................................................................
      buf = paste("hRC\t", hRC,
                  "\tExternal threshold for defining sensitives\n", sep = "");
      cat(buf, file = FS);

      buf = paste("nSensitive", "\t", sprintf("%10.5e", cSens$nSensitive),
                  "\tExternal threshold: Number of sensitive patients obtained for DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);      
      
      buf = paste("pR", "\t", sprintf("%10.5e", cSens$pR),
                  "\tExternal threshold: Minimum P-value for split DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hR", "\t", sprintf("%10.5e", cSens$hR),
                  "\tExternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRLo", "\t", sprintf("%10.5e", cSens$hRLo),
                  "\tExternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRHi", "\t", sprintf("%10.5e", cSens$hRHi),
                  "\tExternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");            
      cat(buf, file = FS);
      # ............................................................................................
      # . Close table here :
      # ............................................................................................
      buf = paste("#-----------------------------------------------------------------------------------\n",
                   sep = "");                  
      cat(buf, file = FS);       
      # ............................................................................................      





      # ..........................................................................
      # . Generate a comprehensive ``ROC'' table:
      # . DloghR, hR, log(hR), pR, -log10(pR), sensitivity, number of sensitives.
      # . hR, . . ., -log10(pR) refer to Cox model statistics with {Z=1/Z=0}
      # . covariates for the subset defined by DloghR <= DloghR0, where DloghR0
      # . is the current value of DloghR in the table.
      # .
      # . Retrieve the salient variables :
      # ..........................................................................
      aDloghRSortBuf = cv$aDloghRSortBIG[ , 1];      # DloghR: predicted differential log-hazard threshold.
      aSBuf = (1:cv$n) / cv$n;                       # Sensitivity.
      anBuf = 1:cv$n;                                # Absolute number of sensitives.
      ahRSortBuf = cv$ahRSortBIG[ , 1];              # hR: resulting hR  between Z=1 and Z=0.
      aloghRSortBuf = log(cv$ahRSortBIG[ , 1]);      # log(hR): resulting loghR between Z=1 and Z=0.
      apRSortBuf = cv$apRSortBIG[ , 1];              # pR : P-value between Z=1 and Z=0.
      amlog10pRSortBuf = Stat.getMlog10(apRSortBuf); # -log10(P) transformation of P-value.
      # ..........................................................................
      # . Write here :
      # ..........................................................................      
      buf = paste("\n\n", sep = "");
      cat(buf, file = FS);      

      buf = "#TABLE 3: ROC table:\n";
      cat(buf, file = FS);

      buf = paste("#The variables hR, . . ., -log10(pR) refer to Cox model statistics with {Z=1/Z=0}\n",
                  "#covariates for the subset defined by DloghR <= DloghR0, where DloghR0\n",
                  "#is the current value of DloghR in the table.\n",
                  "DloghR = loghR(Z=1) - loghR(Z=0)\n",
                  "S = sensitivity\n",
                  "nc = number of sensitives\n",
                  sep = "");
      cat(buf, file = FS);
      
      buf = paste("#-----------------------------------------------------------------------------------\n\n",
                   sep = "");
      cat(buf, file = FS);      
      # ..........................................................................
      # . Write header :
      # ..........................................................................
      buf = paste("#DloghR\tS\tnc\thR\tlog(hR)\tpR\tmlog10(pR)\n", sep = "");
      cat(buf, file = FS);
      # ..........................................................................
      # . Write body :
      # ..........................................................................
      for (i in 1:cv$n) {
        buf = paste(sprintf("%10.5e", aDloghRSortBuf[i]), "\t",
                    sprintf("%10.5e", aSBuf[i]), "\t",
                    anBuf[i], "\t",
                    sprintf("%10.5e", ahRSortBuf[i]), "\t",
                    sprintf("%10.5e", aloghRSortBuf[i]), "\t",
                    sprintf("%10.5e", apRSortBuf[i]), "\t",
                    sprintf("%10.5e", amlog10pRSortBuf[i]),
                    "\n",
                    sep = "");
        cat(buf, file = FS);
      }
      # ............................................................................................
      # . Close table here :
      # ............................................................................................
      buf = paste("\n#-----------------------------------------------------------------------------------\n",
                   sep = "");                  
      cat(buf, file = FS);       
      # ............................................................................................      

      
      
      # .............................
      # . Close file here :
      # .............................      
      close(FS);
      # .............................      
     

      # ...........................................................................      
      cat(" ..........  Wrote Cox cross-validation results : ",
          fs, "\n", sep = "");
      # ...........................................................................
      
      
      # ...........
      return (0);
      # ...........

}

# =========================================================================================================================
# . End of BasicCoxDiag.writeCoxCvWithCovSingle.
# =========================================================================================================================





# =========================================================================================================================
# . BasicCoxDiag.generateCoxCvWithCovSummarySingle : generates a text string containing a summary of results 
# . ---------------------------------------------   from the supervised principal components cross-validation,
# .                                                 for the case with external covariate. This version is
# .                                                 for cross-validation on a single level of tuning parameters.
# .   Syntax:
# .        txt = BasicCoxDiag.generateCoxCvWithCovSummarySingle(cv);
# .
# .   In:
# .         cv = result of super pc cross-validation, as returned by function
# .              BasicCoxCv.crossValidateCoxWithCov().
# .
# .   Out:
# .        txt = contains listing of input parameters, feature selection results,
# .              svd results, and global and detailed results for the Cox propotional
# .              hazard model.
# .
# =========================================================================================================================

BasicCoxDiag.generateCoxCvWithCovSummarySingle <- function(cv)
{

      # .....................................................................................
      if (class(cv) != "basic.cox.cov.cv") {
        msg = "ERROR: from BasicCoxDiag.generateCoxCvWithCovSummarySingle: ";
        msg = paste("The input cv is not of class basic.cox.cov.cv");
        stop(msg);
      }
      # .....................................................................................      

  
      # ...........................................................................................
      buf = paste("#Cross-validation of Cox regression model :\n", sep = "");
      # ............................................................................................




      # ......................................................................................
      # . Parameters used in the computation :
      # ......................................................................................
      buf = paste(buf, "#General Parameters:\n", sep = "");      
      buf = paste(buf, "#Number of samples in the input training set: n = " , cv$n, "\n", sep = "");
      buf = paste(buf, "#Number of genes in the input training set: p = " , cv$p, "\n", sep = "");
      buf = paste(buf, "#Method for splitting the data: methodSplit = ", cv$methodSplit, "\n", sep = "");

      if (cv$methodSplit == 'vfold') {
        buf = paste(buf, "#Fraction put into test set: ft = ", cv$ft, "\n", sep = "");
        buf = paste(buf, "#Number of resamplings: ncv = ", cv$ncv, "\n", sep = "");
        buf = paste(buf, "#Random number generator seed: rngSeed = ", cv$rngSeed, "\n", sep = "");
      }

      buf = paste(buf, "#Cross-validation train-test breakdown (approximate):\n", sep = "");
      buf = paste(buf, "#n(total)\tntrain\tntest\n", sep = "");
      buf = paste(buf, cv$n, "\t", cv$ntrain, "\t", cv$ntest, "\n", sep = "");             
      buf = paste(buf, "\n", sep = "");      
      buf = paste(buf, "#Number of tuning parameter levels: nScan = ", cv$nScan, "\n", sep = "");      
      buf = paste(buf, "#Actual number of cross-validation splits: ncvHere = ", cv$ncvHere, "\n", sep = "");
      # ......................................................................................

      

      # ................................................................................................................
      # . Extract optimized feature selection parameter :
      # . At the given feature selection level.
      # . 
      # . >> 1. Significance for *prognostic* estimates on collected test sets, with the
      # . z = 0 and z = 1 treatment arms considered separately.
      # .................................................................................................................
      buf = paste(buf, "\n", sep = "");
      buf = paste(buf, "# 1. PROGNOSTIC ESTIMATES :\n", sep = "");
      # ..................................................................................................................
      # . z = 0 treatment arm:
      # ..................................................................................................................
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");      
      jmin0 = which.min(cv$apR0);
      pR0Min = cv$apR0[jmin0];        # Most significant prognostic estimate for z = 0 arm.
      hR0Min = cv$ahR0[jmin0];        # Corresponding hazard ratio for z = 0 arm.
      
      buf = paste(buf, "#Z = 0 arm (lower and upper tertiles):\n", sep = "");
      buf = paste(buf, "pR0Min = ", sprintf("%8.3e", pR0Min), "\n", sep = "");
      buf = paste(buf, "hR0Min = ", sprintf("%8.3e", hR0Min), "\n", sep = "");
      # .................................................................................................................
      # . z = 1 treatment arm:
      # .................................................................................................................
      jmin1 = which.min(cv$apR1);
      pR1Min = cv$apR1[jmin1];        # Most significant prognostic estimate for z = 1 arm.
      hR1Min = cv$ahR1[jmin1];        # Corresponding hazard ratio for z = 1 arm.

      buf = paste(buf, "#Z = 1 arm (lower and upper tertiles):\n", sep = "");      
      buf = paste(buf, "pR1Min = ", sprintf("%8.3e", pR1Min), "\n", sep = "");
      buf = paste(buf, "hR1Min = ", sprintf("%8.3e", hR1Min), "\n", sep = "");
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      buf = paste(buf, "#The P-values and hazard ratios are computed from lower and upper tertile\n", sep = "");
      buf = paste(buf, "#of aloghR.\n", sep = "");
      buf = paste(buf, "\n", sep = "");      
      
      buf = paste(buf, "#[by prognostic estimates, we mean that in the z = 0 and z = 1 treatment arms considered\n", sep = "");
      buf = paste(buf, "#separately, we predict hazard ratios on the basis of gene expression alone and.\n", sep = "");
      buf = paste(buf, "#ask how well they correlate with the observed data.]\n", sep = "");
      buf = paste(buf, "\n", sep = "");
      # ................................................................................................................
      # . >> 2. Significance for *predictive* estimate on collected test sets, with the
      # . two treatment arms considered together.
      # ................................................................................................................
      buf = paste(buf, "\n", sep = "");      
      buf = paste(buf, "# 2. PREDICTIVE ESTIMATES :\n", sep = "");
      # ...............................................................................................
      # . Basic optimizations here :
      # ...............................................................................................      
      jmin = which.min(cv$apRMin);    # Feature selection level that maximizes significance.
      pRMin = cv$apRMin[jmin];        # Minimum P-value at optimal thresholding between z = 1 and z = 0 sub-populations.  
      hRMin = cv$ahRMin[jmin];        # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.           
      hRCMin = cv$ahRC[jmin];         # Optimal cut: subset at predicted lambda(z = 1) / lambda(z = 0) <= hRC
                                      # to minimize the P-value.
      nMin = cv$aicMin[jmin];         # Number of samples actually used in the comparison.
      SMin = nMin / cv$n;             # Fraction sensitive.

      hCI = Cox.generatehRConfidenceInterval(hRMin, pRMin);   # Generate lower and upper CI bounds.
      hRMinLo = hCI$hRLo;
      hRMinHi = hCI$hRHi;      
      # ...............................................................................................
      # . Now display :
      # ...............................................................................................
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      buf = paste(buf, "# A. Baseline: all-patients Z = 1 to Z = 0 analysis:                  \n", sep = "");
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      buf = paste(buf, "n = ", cv$n, "\n", sep = "");                  
      buf = paste(buf, "pRAll = ", sprintf("%8.3e", cv$pRAll), "\n", sep = "");
      buf = paste(buf, "hRAllLo = ", sprintf("%8.3e", cv$hRAllLo), "\n", sep = "");
      buf = paste(buf, "hRAll = ", sprintf("%8.3e", cv$hRAll), "\n", sep = "");
      buf = paste(buf, "hRAllHi = ", sprintf("%8.3e", cv$hRAllHi), "\n", sep = "");      
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      buf = paste(buf, "# B. Optimization results using cross-validated differential log-hazard-ratios: \n", sep = "");
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");      
      buf = paste(buf, "hRCMin = ", sprintf("%8.3e", hRCMin), "\n", sep = "");
      buf = paste(buf, "nMin = ", nMin, "\n", sep = "");
      buf = paste(buf, "n = ", cv$n, "\n", sep = "");
      buf = paste(buf, "SMin = ", sprintf("%8.3e", SMin), "\n", sep = "");      
      buf = paste(buf, "pRMin = ", sprintf("%8.3e", pRMin), "\n", sep = "");
      buf = paste(buf, "hRMinLo = ", sprintf("%8.3e", hRMinLo), "\n", sep = "");      
      buf = paste(buf, "hRMin = ", sprintf("%8.3e", hRMin), "\n", sep = "");
      buf = paste(buf, "hRMinHi = ", sprintf("%8.3e", hRMinHi), "\n", sep = "");
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      buf = paste(buf, "# C. Overall model: regression of survival times against DloghR :     \n", sep = "");
      buf = paste(buf, "# log(hR(model)) = betaZ * Z + beta * DloghR + gamma * Z * DloghR   \n", sep = "");
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      buf = paste(buf, "pModel = ", sprintf("%8.3e", cv$cModel$pR), "\n", sep = "");
      buf = paste(buf, "Coefficient\tvalue\tse\tP-value\n", sep = "");        
      buf = paste(buf, "betaZ",
                       "\t", sprintf("%8.3e", cv$cModel$betaZ),
                       "\t", sprintf("%8.3e", cv$cModel$seBetaZ),
                       "\t", sprintf("%8.3e", cv$cModel$pBetaZ),        
                       "\n", sep = "");
      buf = paste(buf, "beta",
                       "\t", sprintf("%8.3e", cv$cModel$abeta[1]),
                       "\t", sprintf("%8.3e", cv$cModel$aseBeta[1]),                                     
                       "\t", sprintf("%8.3e", cv$cModel$apBeta[1]),
                       "\n", sep = "");
      buf = paste(buf, "gamma",
                       "\t", sprintf("%8.3e", cv$cModel$agamma[1]),
                       "\t", sprintf("%8.3e", cv$cModel$aseGamma[1]),        
                       "\t", sprintf("%8.3e", cv$cModel$apGamma[1]),
                       "\n", sep = "");                
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      # ......................................................................................
      # . Same as above, but with elaborate explanations :
      # ......................................................................................
      buf = paste(buf, "\n", sep = "");
      buf = paste(buf, "#[By predictive estimates, we mean that we use the Cox regression model to predict\n", sep = "");
      buf = paste(buf, "#in the collected test sets those patients most likely to respond with longer\n", sep = "");
      buf = paste(buf, "#survival times to the Z = 1 treatment arm than to the Z = 0 treatment arm.\n", sep = "");
      buf = paste(buf, "#The criterion for sensitivity is that the relative predicted hazard ratio,\n", sep = "");
      buf = paste(buf, "#hR(z = 1) / hR(z = 0) <= hRC, where the threshold hRC is an adjustable parameter.\n", sep = "");
      buf = paste(buf, "#For samples predicted to be sensitive, we then compare actual survival times in the two\n", sep = "");
      buf = paste(buf, "#treatment arms. We report here the value of feature selection, and hRC, to minimize P-value\n", sep = "");
      buf = paste(buf, "#for this comparison.\n", sep = "");            

      buf = paste(buf, "#\n", sep = "");      

      buf = paste(buf, "#Selecting for sensitive patients with predicted differential\n", sep = "");
      buf = paste(buf, "#hazard ratio lambda(z = 1) / lambda(z = 0) <= hRC yields the most\n", sep = "");
      buf = paste(buf, "#significant split between actual z = 0 and z =1 treatment arms\n", sep = "");
      buf = paste(buf, "#for the value of hRC given below:\n", sep = "");      
      
      buf = paste(buf, "#Optimal upper threshold on differential log-hazard-ratio for selecting sensitive patients:\n", sep = "");
      buf = paste(buf, "hRC = ", sprintf("%8.3e", hRCMin), "\n", sep = "");
      buf = paste(buf, "#Number of sensitive patients selected under that threshold:\n", sep = "");
      buf = paste(buf, "nMin = ", nMin, " (out of ", cv$n, ")\n", sep = "");      
      buf = paste(buf, "#P-value for difference in survival in sensitive patients, between z = 1 and z = 0 populations:\n", sep = "");
      buf = paste(buf, "pRMin = ", sprintf("%8.3e", pRMin), "\n", sep = "");
      buf = paste(buf, "#Corresponding hazard-ratio between z = 1 and z = 0 populations:\n", sep = "");
      buf = paste(buf, "hRMin = ", sprintf("%8.3e", hRMin), "]\n", sep = "");      
      # ......................................................................................



      # ......................................................................................
      # . Additional calculations to quantify ROCs based on hR(S) and hR(R) profiles :
      # ......................................................................................
      if (cv$flagComputeRES) {
        buf = paste(buf, "\n", sep = "");
        buf = paste(buf, "#Additional calculations to quantify ROCs based",
                         " on hR(S) and hR(R) profiles :\n", sep = "");
        # ......................................................................................
        # . Compute areas under and between curves :
        # ......................................................................................      
        aucSEN =  Cox.computehRROCArea(cv$ahRSortBIG[ , 1]);     # Area under sensitives ROC.
        aucRES =  Cox.computehRROCArea(cv$ahRSortRESBIG[, 1]);   # Area under resistants ROC.
        abc = aucRES - aucSEN;                                   # Area between curves.
        # ......................................................................................
        # . Compute hR)S) / hR(R) ratio :
        # ......................................................................................
        aqRatio = cv$ahRSortBIG[ , 1] / cv$ahRSortRESBIG[ , 1];    # hR(S) / hR(R).
        ncMin = cv$aicMinBIG[1];                                   # Number of patients selected by hR <= hRC filter.
        qRatioMin = aqRatio[ncMin];                                # hR(S) / hR(R) at that threshold.
        # ......................................................................................
        # . Generate objective function and find optimum :
        # ......................................................................................
        op = Cox.objectivePhi(cv$ahRSortBIG[ , 1], cv$ahRSortRESBIG[ , 1]);

        iminOPT = op$imin;                      # Index for which optimum occurs.
        hRCMinOPT = exp(cv$aDloghRSortBIG[ , 1][iminOPT]);   # Differential hazard ratio at threshold.              
        SminOPT = op$qmin;                      # Fraction sensitive at optimum.
        hRSensMinOPT = op$hRSensMin;            # Hazard ratio for sensitive group at optimum.
        hRResMinOPT = op$hRResMin;              # Hazard ratio for resistant group at optimum.
        # ......................................................................................
        # . Print the results here :
        # . >> Area calculations :
        # ......................................................................................
        buf = paste(buf, "#RESULTS FOR AREA CALCULATIONS :\n", sep = "");        
        buf = paste(buf, "Area under sensitive ROC: aucSEN = ", sprintf("%8.3e", aucSEN), "\n", sep = "");
        buf = paste(buf, "Area under resistant ROC: aucRES = ", sprintf("%8.3e", aucRES), "\n", sep = "");
        buf = paste(buf, "Area between curves: ABC = aucRES - aucSEN = ", sprintf("%8.3e", abc), "\n", sep = "");
        buf = paste(buf, "hR(S) / hR(R) at given threshold: qRatio = ", sprintf("%8.3e", qRatioMin), "\n", sep = "");
        # ......................................................................................
        # . >> All hazard ratios at the given threshold :
        # ......................................................................................
        buf = paste(buf, "#\n", sep = "");        
        buf = paste(buf, "#ALL HAZARD RATIOS AT GIVEN THRESHOLD:\n", sep = "");                
        buf = paste(buf, "hR(S) at given threshold: hR(S) = ",
                         sprintf("%8.3e", cv$ahRSortBIG[ , 1][ncMin]), "\n", sep = "");
        buf = paste(buf, "pR(S) at given threshold: pR(S) = ",
                         sprintf("%8.3e", cv$apRSortBIG[ , 1][ncMin]), "\n", sep = "");
        buf = paste(buf, "hR(R) at given threshold: hR(R) = ",
                         sprintf("%8.3e", cv$ahRSortRESBIG[ , 1][ncMin]), "\n", sep = "");
        buf = paste(buf, "pR(R) at given threshold: pR(R) = ",
                         sprintf("%8.3e", cv$apRSortRESBIG[ , 1][ncMin]), "\n", sep = "");
        # ......................................................................................
        # . >> Optimization of objective function :
        # ......................................................................................
        buf = paste(buf, "#\n", sep = "");                              
        buf = paste(buf, "#OPTIMIZATION OF OBJECTIVE FUNCTION:\n", sep = "");                        
        buf = paste(buf, "Index for which optimum occurs : iminOPT = ", iminOPT, "\n", sep = "");
        buf = paste(buf, "Differential hazard ratio at threshold : hRCMinOPT = ", sprintf("%8.3e", hRCMinOPT), "\n", sep = "");
        buf = paste(buf, "Fraction sensitive at optimum : SminOPT = ", sprintf("%8.3e", SminOPT), "\n", sep = "");
        buf = paste(buf, "Hazard ratio for sensitive group at optimum: hRSensMinOPT = ", sprintf("%8.3e", hRSensMinOPT), "\n", sep = "");
        buf = paste(buf, "Hazard ratio for resistant group at optimum: hRResMinOPT = ",  sprintf("%8.3e", hRResMinOPT),  "\n", sep = "");
        # ......................................................................................        
      }
      # ......................................................................................      
      
      # .............
      return (buf);
      # .............

}

# =========================================================================================================================
# . End of BasicCoxDiag.generateCoxCvWithCovSummarySingle.
# =========================================================================================================================






# ========================================================================================================
# . BasicCoxDiag.generateCoxWithCovPSM : generates the patient selection matrix (PSM).
# . ----------------------------------   Input is for model predictions for
# .                                      the case with external covariate. This version is
# .                                      for a single level of tuning parameters.
# .   Syntax:
# .        psm = BasicCoxDiag.generateCoxWithCovPSM(cv);
# .
# .   In:
# .         cv = result of super pc cross-validation, as returned by function
# .              BasicCoxCv.crossValidateCoxWithCov().
# .
# .   Out:
# .        psm = list with members as indicated in package at end of function.
# .
# ========================================================================================================

BasicCoxDiag.generateCoxWithCovPSM <- function(cv)
{

      # .....................................................................................
      if (class(cv) != "basic.cox.cov.cv") {
        msg = "ERROR: from BasicCoxDiag.generateCoxWithCovPSM: ";
        msg = paste("The input cv is not of class basic.cox.cov.cv");
        stop(msg);
      }
      # .....................................................................................



      # ....................................................................................
      # . First check that there are some resistant patients, else no comparison
      # . is possible :
      # ....................................................................................        
      indexSortBuf = cv$indexSortBIG[ , 1];
      ncMin = cv$aicMinBIG[1];      # Number of patients selected by hR <= hRC filter.
      
      nTemp = length(indexSortBuf);                           # Total number of patients.
      ncMin1 = ncMin + 1;

      if (ncMin1 > nTemp) {
        cat("WARNING: from BasicCoxDiag.generateCoxWithCovPSM:\n");
        cat("No resistant patients were found. I cannot generate the\n");
        cat("patient selection matrix.\n");

        psm = list(status = 'no_resistant');
      }
      # .....................................................................................

      
      # .....................................................................................
      # . Subset the data matrix to the relevant categories.
      # .
      # . Generate Cox analyses and estimate median survival times for 
      # . the different ``slices''.
      # .....................................................................................      
      hRCMin = cv$ahRCBIG[1];          # Upper bound for selecting patients predited to be sensitive.
      ncMin = cv$aicMinBIG[1];         # Number of patients selected by hR <= hRC filter.
      pRMin = cv$apRMin[1];            # P-value for Z = 1 to Z = 1 comparisons, at best hRC.
      hRMin = cv$ahRMin[1];            # hazard ratio for Z = 1 to Z = 1 comparisons, at best hRC.
      # .....................................................................................
      # . Gather S+R sets for each treatment arm separately :
      # .....................................................................................        
      indexSortBuf = cv$indexSortBIG[ , 1];
      n = length(indexSortBuf);                                  # Total number of patients.
      ncMin1 = ncMin + 1;
      # .....................................................................................
      # . Get all the clinical data into data frame format :
      # .....................................................................................
      dfA = data.frame(at = cv$atBIG, as = cv$asBIG, az = cv$azBIG);  
      # .....................................................................................
      # . Add the response state to the data frame.
      # . The response state is coded here in column `ar' as :
      # .
      # .      S = sensitive = 1
      # .      R = resistant = 0
      # ......................................................................................
      dfS = dfA[indexSortBuf[1:ncMin], ];
      dfR = dfA[indexSortBuf[ncMin1:n], ];
      ar = c(rep(1, times = nrow(dfS)), rep(0, times = nrow(dfR)));  # Response state

      dfB = rbind(dfS, dfR);                 
      dfB = data.frame(dfB, ar = ar);        # Column ar = response.
      # ......................................................................................
      # . Subset to four cases :
      # ......................................................................................      
      dfB0 = dfB[dfB$az == 0, ];             # All Z = 0 patients, S and R.
      dfB1 = dfB[dfB$az == 1, ];             # All Z = 1 patients, S and R.

      dfB_R = dfB[dfB$ar == 0, ];            # All R patients, Z = 0 and Z = 1.
      dfB_S = dfB[dfB$ar == 1, ];            # All S patients, Z = 0 and Z = 1.

      nB0 = nrow(dfB0);                      # Number of Z = 0 patients.
      nB1 = nrow(dfB1);                      # Number of Z = 0 patients.

      nB_R = nrow(dfB_R);                    # Number of R patients.
      nB_S = nrow(dfB_S);                    # Number of S patients.
      # ......................................................................................
      # . Add more detailed counts :
      # ......................................................................................
      nB0_R = sum(dfB0$ar == 0);             # Number of R patients in Z = 0 treatment arm.
      nB0_S = sum(dfB0$ar == 1);             # Number of S patients in Z = 0 treatment arm.
      nB1_R = sum(dfB1$ar == 0);             # Number of R patients in Z = 1 treatment arm.
      nB1_S = sum(dfB1$ar == 1);             # Number of S patients in Z = 1 treatment arm.
      # ......................................................................................
      # . Compute p-values and hazard ratios for binary comparisons on Z OR response
      # . status for all four cases :
      # ......................................................................................
      csB_All = Cox.computeBinaryCox(dfB$at, dfB$as, dfB$az);       # Z = 1 vs Z = 0 for R+S = ALL
      
      csB0 = Cox.computeBinaryCox(dfB0$at, dfB0$as, dfB0$ar);       # S vs R for Z = 0.
      csB1 = Cox.computeBinaryCox(dfB1$at, dfB1$as, dfB1$ar);       # S vs R for Z = 1.
      
      csB_R = Cox.computeBinaryCox(dfB_R$at, dfB_R$as, dfB_R$az);   # Z = 1 vs Z = 0 for R.
      csB_S = Cox.computeBinaryCox(dfB_S$at, dfB_S$as, dfB_S$az);   # Z = 1 vs Z = 0 for R.            
      # .....................................................................................
      # . 3. Generate a table of median survival times in a 2 * 2 table format,
      # . {treatment arm * response category} for easy reference.
      # .
      # . First generate median survival times for {treatment arm * response category} table :
      # .....................................................................................
      dfB0_R = dfB[(dfB$az == 0) & (dfB$ar == 0), ];             # Z = 0, R patients.
      dfB0_S = dfB[(dfB$az == 0) & (dfB$ar == 1), ];             # Z = 0, S patients.          
      dfB1_R = dfB[(dfB$az == 1) & (dfB$ar == 0), ];             # Z = 1, R patients.
      dfB1_S = dfB[(dfB$az == 1) & (dfB$ar == 1), ];             # Z = 1, S patients.

      ct0_All = Cox.computeTimes(dfB0$at, dfB0$as);              # Z = 0, R+S =ALL patients.
      ct1_All = Cox.computeTimes(dfB1$at, dfB1$as);              # Z = 1, R+S =ALL patients.      

      ctR_All = Cox.computeTimes(dfB_R$at, dfB_R$as);            # R group, Z = 0 + 1 patients.
      ctS_All = Cox.computeTimes(dfB_S$at, dfB_S$as);            # S group, Z = 0 + 1 patients.

      ct_All = Cox.computeTimes(dfB$at, dfB$as);                 # ALL patients.
      
      ct0_R = Cox.computeTimes(dfB0_R$at, dfB0_R$as);            # Z = 0, R patients.
      ct0_S = Cox.computeTimes(dfB0_S$at, dfB0_S$as);            # Z = 0, S patients.
      ct1_R = Cox.computeTimes(dfB1_R$at, dfB1_R$as);            # Z = 1, R patients.
      ct1_S = Cox.computeTimes(dfB1_S$at, dfB1_S$as);            # Z = 1, S patients.
          
      TMED = data.frame(R = c(ct0_R$tMed, ct1_R$tMed, ctR_All$tMed),
                        S = c(ct0_S$tMed, ct1_S$tMed, ctS_All$tMed),
                        ALL = c(ct0_All$tMed, ct1_All$tMed, ct_All$tMed));

      rownames(TMED) = c('0','1', 'ALL');      
      # .....................................................................................


      
      
      # .....................................................................................
      # . Package all in a data frame.
      # . The ``data package'' looks like :
      # .
      # .                  Prognostic effects -->
      # .                 sensitivity
      # .                  R         S       ALL      n     hR    pR       subscript in list
      # .  p             ------------------------
      # .  r    arm  0   | xx        xx      xx |    xx    xx    xx    -> 0
      # .  e         1   | xx        xx      xx |    xx    xx    xx    -> 1
      # .  i             ------------------------
      # .  d         n     xx        xx      xx
      # .  c        hR     xx        xx      xx
      # .  |        pR     xx        xx      xx
      # .  |                |         |
      # .  v                v         v
      # .                  _R        _S    subscript in list
      # .
      # .....................................................................................
      psm = list(status = 'ok',        # Indicates PSM was constructed.
        
                 TMED = TMED,          # Median survival times, {arm * response} matrix.
                 n = n,                # Total number of patients.

                 pR_All = csB_All$pR,  # compare Z = 1 vs Z =0,
                 hR_All = csB_All$hR,  # for ALL patients.
        
                 n0 = nB0,             # Z = 0 arm,     
                 pR0 = csB0$pR,        # compare S vs R.
                 hR0 = csB0$hR,

                 n1 = nB1,             # Z = 1 arm,     
                 pR1 = csB1$pR,        # compare S vs R.
                 hR1 = csB1$hR,

                 n_R = nB_R,           # R patients,            
                 pR_R = csB_R$pR,      # compare Z = 1 vs Z = 0.
                 hR_R = csB_R$hR,

                 n_S = nB_S,           # S patients,            
                 pR_S = csB_S$pR,      # compare Z = 1 vs Z = 0.
                 hR_S = csB_S$hR,

                 n0_R = nB0_R,        # Number of R patients in Z = 0 treatment arm.
                 n0_S = nB0_S,        # Number of S patients in Z = 0 treatment arm.
                 n1_R = nB1_R,        # Number of R patients in Z = 1 treatment arm.
                 n1_S = nB1_S         # Number of S patients in Z = 1 treatment arm.
                 );
      # .....................................................................................      


      # ..............
      return (psm);
      # ..............

}

# ========================================================================================================
# . End of BasicCoxDiag.generateCoxWithCovPSM.
# ========================================================================================================





# ========================================================================================================
# . BasicCoxDiag.formatCoxWithCovPSM : formats the patient selection matrix (PSM) into text.
# . --------------------------------   Input is for model predictions for
# .                                    the case with external covariate. This version is
# .                                    for a single level of tuning parameters.
# .   Syntax:
# .        txt = BasicCoxDiag.formatCoxWithCovPSM(cv, fmtType);
# .
# .   In:
# .         cv = result of super pc cross-validation, as returned by function
# .              BasicCoxCv.crossValidateCoxWithCov().
# .
# .    fmtType = format for printing. Valid options : 'f', 's' :
# .                     'f' = prints floating "%7.3f" representation for hazard ratios and median survival times.
# .                     's' = prints scientific "%8.3e" representation for hazard ratios and median survival times.
# .
# .   Out:
# .        txt = text representation of the PSM.
# .
# .......................................................................................................
# . * The layout of the ``data package'' looks like :
# .
# .
# .
# .                  Prognostic effects -->
# .                 sensitivity
# .                  R         S       ALL      n     hR    pR       subscript in list
# .  p             ------------------------
# .  r    arm  0   | xx        xx      xx |    xx    xx    xx    -> 0
# .  e         1   | xx        xx      xx |    xx    xx    xx    -> 1
# .  i             ------------------------
# .  d         n     xx        xx      xx
# .  c        hR     xx        xx      xx
# .  |        pR     xx        xx      xx
# .  |                |         |
# .  v                v         v
# .                  _R        _S    subscript in list
# .
# .
# ========================================================================================================

BasicCoxDiag.formatCoxWithCovPSM <- function(cv, fmtType)
{

      # .....................................................................................
      if (class(cv) != "basic.cox.cov.cv") {
        msg = "ERROR: from BasicCoxDiag.formatCoxWithCovPSM: ";
        msg = paste("The input cv is not of class basic.cox.cov.cv");
        stop(msg);
      }
      # .....................................................................................

      

      # .....................................................................................
      stopifnot((fmtType == 'f') || (fmtType == 's'));

      if (fmtType == 's') {
        fmt = "%8.3e";
      } else if (fmtType == 'f') {
        fmt = "%7.3f";
      }
      # .....................................................................................



      # .....................................................................................
      # . Generate the PSM :
      # .....................................................................................
      psm = BasicCoxDiag.generateCoxWithCovPSM(cv);

      if (psm$status != 'ok') {
        txt = "No resistant patients found.\n";
        return (txt);
      }
      # .....................................................................................

      

      # ....................................................................................................
      # . Build the text strings :
      # ....................................................................................................
      buf = list();        # Buffer.
      
      buf[[1]] = c("", "", "", "prognostic effects");
      buf[[2]] = c("", "", "", "sensitivity");
      buf[[3]] = c("", "", "Tmed", "R", "S", "n", "hR", "pR", "All(R+S)");
      buf[[4]] = c("", "", "0",
                                sprintf(fmt, psm$TMED[1,1]),
                                sprintf(fmt, psm$TMED[1,2]),
                                psm$n0,
                                sprintf(fmt, psm$hR0),
                                sprintf("%8.3e", psm$pR0),
                                sprintf(fmt, psm$TMED[1,3]));
      buf[[5]] = c("predictive effects", "arm", "1",
                                sprintf(fmt, psm$TMED[2,1]),
                                sprintf(fmt, psm$TMED[2,2]),
                                psm$n1,
                                sprintf(fmt, psm$hR1),
                                sprintf("%8.3e", psm$pR1),
                                sprintf(fmt, psm$TMED[2,3]));
      buf[[6]] = c("", "", "n", psm$n_R, psm$n_S, "", "", "", psm$n);
      buf[[7]] = c("", "", "hR", sprintf(fmt, psm$hR_R),
                                 sprintf(fmt,psm$hR_S),
                                 "", "", "",
                                 sprintf(fmt,psm$hR_All));
      buf[[8]] = c("", "", "pR", sprintf("%8.3e", psm$pR_R),
                                 sprintf("%8.3e", psm$pR_S),
                                 "", "", "",           
                                 sprintf("%8.3e", psm$pR_All));     

      buf[[9]] = c("", "", "ALL(0+1)", sprintf(fmt, psm$TMED[3,1]),
                                       sprintf(fmt, psm$TMED[3,2]),
                                       "", "", "",           
                                       sprintf(fmt, psm$TMED[3,3]));     
      
      nbuf = length(buf);
      bufT = sapply(1:nbuf, function(i){paste(buf[[i]], collapse = '\t');})

      txt = paste(bufT, collapse ='\n', sep = '');
      txt = paste(txt, "\n\n");
      # ....................................................................................................
      # . Put a preamble in front :
      # ....................................................................................................
      txtPreamble = paste("\n",
                          "#PATIENT SELECTION MATRIX : MEDIAN TIMES AND HAZARD RATIOS\n",
                          "#Comparisons along rows --> prognoses\n",
                          "#Comparisons along columns --> predictions\n",
                          "\n\n", sep = '');

      txt = paste(txtPreamble, txt, sep = '');
      # .....................................................................................................



      # .....................................................................................................
      # . Add a table with only the subset counts :
      # .....................................................................................................
      buf = list();        # Buffer.
      
      buf[[1]] = c("", "", "COUNTS", "R", "S", "All(R+S)");
      buf[[2]] = c("", "", "0", psm$n0_R, psm$n0_S, psm$n0);
      buf[[3]] = c("", "", "1", psm$n1_R, psm$n1_S, psm$n1);
      buf[[4]] = c("", "", "ALL(0+1)", psm$n_R, psm$n_S, psm$n);

      nbuf = length(buf);
      bufT = sapply(1:nbuf, function(i){paste(buf[[i]], collapse = '\t');})

      txtCounts = paste(bufT, collapse ='\n', sep = '');
      txtCounts = paste(txtCounts, "\n\n");
      # ....................................................................................................
      # . Put a preamble in front :
      # ....................................................................................................
      txtPreamble = paste("\n",
                          "#PATIENT SELECTION MATRIX : COUNTS\n",
                          "\n\n", sep = '');

      txtCounts = paste(txtPreamble, txtCounts, sep = '');
      # .....................................................................................................

      

      # ..................................................
      # . Final text :
      # ..................................................
      txt = paste(txt, txtCounts, sep = "");
      # ..................................................

      

      # ................
      return (txt);
      # ................      
  
}

# ========================================================================================================
# . End of BasicCoxDiag.formatCoxWithCovPSM.
# ========================================================================================================





# =================================================================================================
# . BasicCoxDiag.writeCoxSummaryWithCov : writes to file a summary of results from the basic
# . -----------------------------------   Cox calculation,
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .         BasicCoxDiag.writeCoxSummaryWithCov(bc, dsTrain, dsTest, fs);
# .
# .   In:
# .         bc = result of Cox model computation, returned
# .              by function BasicCox.computeCoxWithCov().
# .    dsTrain = as returned by BasicCox.computeSignificanceOnCov() on training set.
# .     dsTest = as returned by BasicCox.computeSignificanceOnCov() on test set (if any),
# .              else NULL.
# .         fs = name of output file.
# .
# =================================================================================================

BasicCoxDiag.writeCoxSummaryWithCov <- function(bc, dsTrain, dsTest, fs)
{

      # ...........................................................
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCoxDiag.writeCoxSummaryWithCov: ";
        msg = paste("The input bc is not of class basic.cox.cov");
        stop(msg);
      }
      # ...........................................................

      
      # ......................................................................
      # . Generate a text string containing the model summary :
      # ......................................................................
      txtSummary = BasicCoxDiag.generateCoxSummaryWithCov(bc, dsTrain, dsTest);
      # ......................................................................

      
      # ...........................................................
      # . Write to file :
      # ...........................................................      
      FS = file(fs, "w");
      cat(txtSummary, file = FS);
      close(FS);
      # ...........................................................

      
      # ..............................................................................      
      cat(" ..........  Wrote statistical summary : ", fs, "\n", sep = "");
      # ..............................................................................

      
      # ...................
      return (txtSummary);
      # ...................
      
}

# =================================================================================================
# . End of BasicCoxDiag.writeCoxSummaryWithCov.
# =================================================================================================      





# =================================================================================================
# . BasicCoxDiag.generateCoxSummaryWithCov : generates a text string containing a summary of results 
# . -------------------------------------   from the basic Cox model computation.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .        txt = BasicCoxDiag.generateCoxSummaryWithCov(bc, dsTrain, dsTest);
# .
# .   In:
# .        bc = result of basic Cox model computation, returned
# .              by function BasicCox.computeCoxWithCov().
# .    dsTrain = as returned by BasicCox.computeSignificanceOnCov() on training set.
# .     dsTest = as returned by BasicCox.computeSignificanceOnCov() on test set (if any),
# .              else NULL.
# .
# .
# .   Out:
# .        txt = contains listing of input parameters, feature selection results,
# .              svd results, and global and detailed results for the Cox propotional
# .              hazard model.
# .
# =================================================================================================

BasicCoxDiag.generateCoxSummaryWithCov <- function(bc, dsTrain, dsTest)
{

      # .....................................................................................
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCoxDiag.generateCoxSummaryWithCov: ";
        msg = paste("The input bc is not of class basic.cox.cov");
        stop(msg);
      }
      # .....................................................................................      

  
      # ...........................................................................................
      buf = "# ................................................................\n";
      buf = paste(buf,
                  "# . Summary for Cox proportional hazard model.                    \n", sep = "");
      buf = paste(buf,
                  "# ................................................................\n", sep = "");      
      # ............................................................................................




      # ......................................................................................
      # . Parameters used in the computation, and results of the feature selection :
      # ......................................................................................
      buf = paste(buf, "#General Parameters:\n", sep = "");      
      buf = paste(buf, "#Number of samples in data matrix: n = " , bc$n, "\n", sep = "");
      buf = paste(buf, "#Number of genes in data matrix: m = " , bc$m, "\n", sep = "");
      # ......................................................................................

      
      
      # ......................................................................................
      # . Details of the results for the Cox proportional hazard model:
      # ......................................................................................
      m21 = 2 * bc$m + 1;
      
      buf = paste(buf, "#\n", sep = "");      
      buf = paste(buf, "#Cox Proportional Hazard Model Results:", "\n", sep = "");
      buf = paste(buf, "#Proportional hazard model:\n", sep = "");
      buf = paste(buf, "#lambda(t) = lambda0(t) * exp(beta . y + betaZ . z + z . gamma . y)\n", sep = "");      
      buf = paste(buf, "#where y is the gee expression value\n", sep = "");
      buf = paste(buf, "#and Z is an external covariate, and where\n", sep = "");
      buf = paste(buf, "#beta = m-vector of Cox coeff. for direct terms (m = ", bc$m, "),\n", sep = "");
      buf = paste(buf, "#betaZ = Cox coefficients for direct effect of external covariate,\n", sep = "");
      buf = paste(buf, "#and gamma = m-vector of Cox coeff. for interaction terms (m = ", bc$m, ").\n", sep = "");
      buf = paste(buf, "#Total number of degrees of freedom: df = 2 * m + 1 = ", m21, ".\n", sep = ""); 
      buf = paste(buf, "#\n", sep = "");      

      buf = paste(buf, "#Global properties:\n", sep = "");

      lFinal = bc$coxK$loglik[2];         # This is l(beta).
      lFinal = sprintf("%8.3e", lFinal);

      buf = paste(buf, "#Final loglikelihood: l(beta) = ", lFinal, "\n", sep = "");
      
      qRtemp = sprintf("%8.3e", bc$qR);   # Loglikelihood ratio.
      pRtemp = sprintf("%8.3e", bc$pR);   # Corresponding p-value.

      buf = paste(buf, "#Loglikelihood ratio statistic (df = K): qR = 2 * (l(beta) - l(0))\n", sep = "");
      buf = paste(buf, "#qR = ", qRtemp, "\n", sep = "");      
      buf = paste(buf, "#P-value pR for loglikelihood ratio statistic (against chi2):\n", sep = "");
      buf = paste(buf, "#pR = ", pRtemp, "\n", sep = "");            

      buf = paste(buf, "#Detailed properties:\n", sep = "");
      
      coxKsum = summary(bc$coxK);         # Summary.
      coxKcoef = coxKsum$coef;             # Contains the K coefficients and P-values.
      # ...............................................................................
      # . Tabulate Cox coefficients.
      # . The direct term for the external covariate :
      # ...............................................................................
      buf = paste(buf, "#\n", sep = "");      
      buf = paste(buf, "#Cox coefficient for EXTERNAL covariate:", "\n", sep = "");
      buf = paste(buf, "betaZ\tse(betaZ)\texp(betaZ)\tPZ\n", sep = "");

      expBetaZ = exp(bc$betaZ);
      
      buf = paste(buf, bc$betaZ, "\t", bc$seBetaZ, "\t", expBetaZ,          
                       "\t", bc$pBetaZ, "\n", sep = "");      
      # ...............................................................................
      # . Direct and interaction terms :
      # ...............................................................................      
      abeta = bc$abeta;               # The K coefficients.
      aexpBeta = exp(abeta);           # exp(beta) the K coefficients.            
      aseBeta = bc$aseBeta;           # Standard errors for the K coefficients.
      apBeta = bc$apBeta;             # The corresponding K P-values.

      agamma = bc$agamma;               # The K coefficients.
      aexpGamma = exp(agamma);           # exp(gamma) the K coefficients.            
      aseGamma = bc$aseGamma;           # Standard errors for the K coefficients.
      apGamma = bc$apGamma;             # The corresponding K P-values.
      
      buf = paste(buf, "#\n", sep = "");      
      buf = paste(buf, "#Cox coefficients for DIRECT (beta) and INTERACTION (gamma) terms:", "\n", sep = "");
      buf = paste(buf, "Gene\tbeta\tse(beta)\texp(beta)\tPbeta\tgamma\tse(gamma)\texp(gamma)\tPgamma\n", sep = "");

      for (l in 1:bc$m) {
        buf = paste(buf, bc$ac[l],
                    "\t", abeta[l],
                    "\t", aseBeta[l],
                    "\t", aexpBeta[l],          
                    "\t", apBeta[l],
                    "\t", agamma[l],
                    "\t", aseGamma[l],
                    "\t", aexpGamma[l],          
                    "\t", apGamma[l],
                    "\n", sep = "");
      }

      buf = paste(buf, "\n", sep = "");      # Bare line.
      # ......................................................................................



      # ......................................................................................
      # . Sensitivity analysis for the training set :
      # ......................................................................................
      buf = paste(buf, "#Sensitivity analysis for the training set:\n", sep = "");
      # ...............................................................
      # . All training set samples :
      # ...............................................................      
      buf = paste(buf, "#For all training set samples:\n", sep = "");

      nHere = dsTrain$nAll;
      pR = sprintf("%8.3e", dsTrain$csAll$pR);
      hRLo = sprintf("%8.3e", dsTrain$csAll$hRLo);
      hR = sprintf("%8.3e", dsTrain$csAll$hR);
      hRHi = sprintf("%8.3e", dsTrain$csAll$hRHi);

      buf = paste(buf, "#n = ", nHere, "\n", sep = "");
      buf = paste(buf, "#pR = ", pR, "\n", sep = "");
      buf = paste(buf, "#hR = ", hR, " [", hRLo, ", ", hRHi, "]", "\n", sep = "");
      # ...................................................................................
      # . All sensitive patients :
      # ....................................................................................
      buf = paste(buf, "#For sensitive patients (hRC = ", dsTrain$hRC, ")\n", sep = "");

      nHere = dsTrain$nSens;

      if (nHere > 0) {
        pR = sprintf("%8.3e", dsTrain$csSens$pR);
        hRLo = sprintf("%8.3e", dsTrain$csSens$hRLo);
        hR = sprintf("%8.3e", dsTrain$csSens$hR);
        hRHi = sprintf("%8.3e", dsTrain$csSens$hRHi);

        buf = paste(buf, "#n = ", nHere, "\n", sep = "");
        buf = paste(buf, "#pR = ", pR, "\n", sep = "");
        buf = paste(buf, "#hR = ", hR, " [", hRLo, ", ", hRHi, "]", "\n", sep = "");
      } else {
        buf = paste(buf, "#n = ", nHere, "\n", sep = "");        
      }

      buf = paste(buf, "\n", sep = "");      # Bare line.      
      # ......................................................................................      


      
      # ......................................................................................
      # . Sensitivity analysis for the test set :
      # ......................................................................................
      if (!is.null(dsTest)) {
        buf = paste(buf, "#Sensitivity analysis for the test set:\n", sep = "");
        # ...............................................................
        # . All testing set samples :
        # ...............................................................      
        buf = paste(buf, "#For all test set samples:\n");

        nHere = dsTest$nAll;
        pR = sprintf("%8.3e", dsTest$csAll$pR);
        hRLo = sprintf("%8.3e", dsTest$csAll$hRLo);
        hR = sprintf("%8.3e", dsTest$csAll$hR);
        hRHi = sprintf("%8.3e", dsTest$csAll$hRHi);

        buf = paste(buf, "#n = ", nHere, "\n", sep = "");
        buf = paste(buf, "#pR = ", pR, "\n", sep = "");
        buf = paste(buf, "#hR = ", hR, " [", hRLo, ", ", hRHi, "]", "\n", sep = "");
        # ...................................................................................
        # . All sensitive patients :
        # ....................................................................................
        buf = paste(buf, "#For sensitive patients in test set (hRC = ", dsTest$hRC, ")\n", sep = "");

        nHere = dsTest$nSens;
        
        if (nHere > 0) {
          pR = sprintf("%8.3e", dsTest$csSens$pR);
          hRLo = sprintf("%8.3e", dsTest$csSens$hRLo);
          hR = sprintf("%8.3e", dsTest$csSens$hR);
          hRHi = sprintf("%8.3e", dsTest$csSens$hRHi);

          buf = paste(buf, "#n = ", nHere, "\n", sep = "");
          buf = paste(buf, "#pR = ", pR, "\n", sep = "");
          buf = paste(buf, "#hR = ", hR, " [", hRLo, ", ", hRHi, "]", "\n", sep = "");
        } else {
          buf = paste(buf, "#n = ", nHere, "\n", sep = "");        
        }
        # ....................................................................................
      }
      # ......................................................................................      

      

      # .............
      return (buf);
      # .............

}

# =================================================================================================
# . End of BasicCoxDiag.generateCoxSummaryWithCov.
# =================================================================================================





# =================================================================================================
# . BasicCoxDiag.writeCoxDataMatrixWithCov : for each sample in the input data matrix, this writes
# . ---------------------------------------   a record containing i) the K principal components (i.e. the
# .                                           projections of the p-gene profile against each of the K 
# .                                           principal component vectors), and ii) the corresponding
# .                                           log hazard and hazard ratios.
# .
# . Note that samples need *not* be the same as in the training set.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .        BasicCoxDiag.writeCoxDataMatrixWithCov(bc, dfX, dfE, az, fo);
# .
# .   In:
# .        bc = result of basic Cox model computation, returned
# .              by function BasicCox.computeCoxWithCov().
# .
# .       dfX = input data frame. It must have the same number and identity of genes as the dataframe
# .             used in BasicCox.computeCoxWithCoxWithCov().
# .             Samples need not be the same as in the training set (so that in particular the 
# .             number of rows need not be the same as in the training set).
# .
# .       dfE = experimental design data frame. It must have the same number of rows as dfX.
# .             Samples need not ne the same as in the training set.
# .
# .        az = input vector of covariate values. It must have the same number of rows as dfX.
# .             Samples need not ne the same as in the training set.
# .
# .       hRC = cutoff on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .        fo = name of output file.
# .
# =================================================================================================

BasicCoxDiag.writeCoxDataMatrixWithCov <- function(bc, dfX, dfE, az, hRC, fo)
{

      # ...........................................................
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCoxDiag.writeCoxDataMatrixWithCov: ";
        msg = paste("The input bc is not of class basic.cox.cov");
        stop(msg);
      }
      # ...........................................................

      
      
      # ................................................................
      # . Consistency check for input objects :
      # ................................................................
      n = nrow(dfX);
      p = ncol(dfX);
      # ................................................................
      # . Check on genes :
      # ................................................................     
      if (p != bc$m) {
        msg = "ERROR: from BasicCoxDiag.writeCoxDataMatrixWithCov: ";
        msg = paste(msg, " Input data frame has p = ", p,
                         " genes, not same as bc$m = ", bc$m, sep = "");
        stop(msg);
      }

      buf = (colnames(dfX) == bc$ac);    # Gene names must be the same.
      nbuf = length(which(buf == FALSE));

      if (nbuf > 0) {
        msg = "ERROR: from BasicCoxDiag.writeCoxDataMatrixWithCov: ";
        msg = paste(msg, " Gene names in input data frame not the same as in bc.", sep = "");
        msg = paste(msg, " Number different = ", nbuf, sep = "");
        stop(msg);
      }
      # ................................................................
      # . Check on number of samples :
      # ................................................................     
      ne = nrow(dfE);

      if (ne != n) {
        cat("ERROR: from BasicCoxDiag.writeCoxDataMatrixWithCov:\n");
        cat("Input experimental design has ne = ", ne, " rows ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }

      nz = length(az);

      if (nz != n) {
        cat("ERROR: from BasicCoxDiag.writeCoxDataMatrixWithCov:\n");
        cat("Input external covariate array az has nz = ", nz, " elements. ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }

      stopifnot(hRC >= 0.0);
      # ................................................................
      

      
      
      # ...................................................................................
      # . Compute the principal components and the log-hazard ratios, using the training
      # . set-derived column means and principal component vectors.
      # . This call returns :
      # .          sl$Y = n * K matrix of principal components.
      # .     sl$aloghR = n matrix of log-hazard-ratios.
      # ...................................................................................      
      sl = BasicCox.computeCoxLogHazardWithCovAndPred(bc, dfX, az, hRC);      
      # ...................................................................................
      


      # ...................................................................................
      # . Build the output data frame :
      # ...................................................................................      
      ar = rownames(dfX);                                     # The row names.

      dfOut = cbind(ar,
                    az,
                    as.data.frame(sl$Y[ , 1:bc$m]),
                    as.data.frame(sl$aloghR),
                    as.data.frame(sl$ahR),
                    as.data.frame(sl$atMed) );

      if (sl$flagPred) {
        dfOut = cbind(dfOut, sl$azMin);
      }

      if (sl$flagBin) {
        dfOut = cbind(dfOut, sl$aDloghRz, sl$aflagSensitiveZ);
      }      
      # ..................................................................................
      # . Assign the column names :
      # ..................................................................................      
      Ynames = paste("x_xm", 1:bc$m, sep = "");
      loghRnames = colnames(sl$aloghR);
      hRnames = colnames(sl$ahR);
      tMednames = colnames(sl$atMed);

      abuf = c('#QUAL', "zActual", Ynames, loghRnames, hRnames, tMednames);

      if (sl$flagPred) {
        abuf = c(abuf, "zMin");
      }

      if (sl$flagBin) {
        abuf = c(abuf, "DloghRz1_minus_0", "flagSensitiveZ");
      }      
      
      colnames(dfOut) = abuf;
      # ..................................................................................
      # . Add the input experimental design :
      # .................................................................................. 
      dfOut = cbind(dfOut, dfE);                               # Dataframe.
      # ...................................................................................

      
      
      # .............................................
      # . Write to file :
      # .............................................
      DataFrame.writeFlat(dfIn = dfOut, fo = fo);
      # .............................................


      # ...........................................................................      
      cat(" ..........  Wrote Cox pc data matrix : ", fo, "\n", sep = "");
      # ...........................................................................

      
      # ..........
      return (0);
      # ..........
      
}

# =================================================================================================
# . End of BasicCoxDiag.writeCoxDataMatrixWithCov.
# =================================================================================================      





# =================================================================================================
# . BasicCoxDiag.writeGeneOffsets : write the genes actually used in a basic Cox calculation, and
# . -----------------------------   the corresponding offsets that were subtracted from the raw
# .                                 data matrix.
# . Syntax :
# . 
# .            BasicCoxDiag.writeGeneOffsets(bc, fqOut);
# .
# . In:
# .      bc = object returned from a call to: BasicCox.computeCoxWithCov().
# .
# .      fqOut = output file.
# .
# =================================================================================================

BasicCoxDiag.writeGeneOffsets <- function(bc, fqOut)
{

  
      # ...........................................................
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCoxDiag.writeGeneOffsets: ";
        msg = paste("The input bc is not of class basic.cox.cov");
        stop(msg);
      }
      # ...........................................................

      

      # .....................................................................................
      dfOut = data.frame('ac' = bc$ac, 'axm' = bc$axm);
      colnames(dfOut) = c('#QUAL', 'xmOffset');
      
      DataFrame.writeFlat(dfIn = dfOut, fo = fqOut);

      cat(" ..........  Wrote genes used and offset data to file: ", fqOut, "\n", sep = '');
      # .....................................................................................


      
      # ............
      return (0);
      # ............

}   

# =================================================================================================
# . End of BasicCoxDiag.writeGeneOffsets.
# =================================================================================================


# =================================================================================================
# . BasicCoxDiag.plotCoxWithCov : displays the results of an analysis using the Cox propotional
# . ---------------------------   hazard model on survival data, in the form of a series of plots.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .       sp = BasicCoxDiag.plotCoxWithCov(at, as, az, dfX, spc, hRC,
# .                                        flagWrite, dirName, stemName);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .           bc = result of basic Cox model computation, returned
# .                 by function BasicCox.computeCoxWithCov().
# .
# .       hRC = cutoff on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .
# .     flagWrite = no/yes : flag indicating whether plots should be written to file in jpeg
# .                 format instead of being displayed.
# .                 If value is 'yes', each plot will be written to a file in the directory
# .                 indicated by 'dirName', with a name given by 'stemName' followed by
# .                 a random string and the .jpg extension.
# .                 If value is 'no', the user is prompted to interactively provide carriage
# .                 returns to march through the display.
# .
# .       dirName = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .      stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .   Out:
# .
# .           - If flagWrite = 'no', displays a series of plots. The use enter carriage returns
# .           to advance from one plot to the next.
# .           Object sp returned is NULL.
# .
# .           - If flagWrite = 'yes', generates a series of plot files, as indicated above.
# .           Object sp returned is a list with members:
# .
# .                  nplot = number of plot files generated.
# .                  afile = array of file names.
# .                  aplot = array of plot names.
# .
# =================================================================================================

BasicCoxDiag.plotCoxWithCov <- function(at, as, az, dfX, bc, hRC,
                                        flagWrite = 'no',
                                        dirName = NULL, stemName = NULL)
{

      # .............................................................
      cat(" ..........  Entry in BasicCoxDiag.plotCoxWithCov.\n");
      # .............................................................

      
      # .............................................................
      stopifnot((flagWrite == 'no') || (flagWrite == 'yes'));
      # .............................................................
      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCov: ";
        msg = paste("The input bc is not of class basic.cox.cov\n");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.
      
      if (nt != n) {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCov: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      
      if (bc$m != p) {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCov: ";        
        msg = paste("The input data matrix does not have the same number of ");
        msg = paste("genes as in the supervised pc. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("Bc has m = " , bc$m, " genes.");
        stop(msg);
      }

     if (bc$n != n) {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCov: ";        
        msg = paste("The input data matrix does not have the same number of ");       
        msg = paste("samples as in the supervised pc. ");
        msg = paste("Input has n = " , n, " samples. ");
        msg = paste("Bc has n = " , bc$n, " samples.");        
        stop(msg);
      }

      stopifnot(hRC >= 0.0);      
      # ...............................................................................................

      
      # ...................................................................................
      if (bc$flagCenter == 'yes') {
        dfXSel = scale(dfX, center = TRUE, scale = FALSE);  # Center each gene separately.
      } else {
        dfXSel = dfX;                                       # No centering.
      }

      #xxx dfXSel = dfXc[ , spc$indexSel];              # NOT RELEVANT. Subsetted to the selected genes.
      agene = colnames(dfXSel);                         # Selected gene names, in feature selection order.
      asample = rownames(dfXSel);                       # Sample names.

      nsel = nrow(dfXSel);                              # Number of samples.
      msel = ncol(dfXSel);                              # Number of subsetted genes.            
      # ...................................................................................

      
      # .......................................................
      # . Reset some defaults, in case they got changed :
      # .......................................................      
      par(ask = FALSE);
      par(mfrow = c(1,1));      
      # .......................................................


      # .......................................................................................
      if (flagWrite == 'no') {
        cat("\n");
        cat(" ..........  Enter carriage returns as indicated to generate plots one-by-one.\n");
      } else if (flagWrite == 'yes') {
        cat(" ..........  Generating plot files in directory = ", dirName, "\n", sep = "");
      }
      # .......................................................................................


      # ...........................................................
      # . Initialize plot arrays :
      # ...........................................................
      afile = c();
      aplot = c();

      if (flagWrite == 'no') {
        dirName = "foo";        # Dummy value.
        stemName = "dum";       # Dummy value.
      }
      # ...........................................................

      
      
      # .......................................................................................
      if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................
      

      
      # ..........................................................................................................
      # . HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS
      # .
      # . Generate heat maps below, provided the data matrices are not too large.
      # .
      # . First, plot of the entire data matrix, before any feature selection :
      # ..........................................................................................................
      if (p > BasicCoxDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the entire data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here p = ", p, " while the maximum is given by BasicCoxDiag.MSELMAX = ", BasicCoxDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat map for entire data matrix and continue execution.\n");
      }

      if (p <= BasicCoxDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the p * n data matrix before any feature selection.
        # . No clustering or sorting of any kind.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Training set data matrix";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ABuf = t(dfX);                  # Make this genes * samples.

        if (nrow(ABuf) == 1) {
          ABuf = rbind(ABuf, ABuf);     # Kludge for heat map display when there is only 1 gene.
        }

        if (flagWrite == 'yes') {
  	  #xxxxx      jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ABuf, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................      
      }
      # ..........................................................................................................

      
      # ..........................................................................................................
      # . Next, plot of the data matrix after feature selection :
      # ..........................................................................................................
      if (msel > BasicCoxDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the feature-selected data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here msel = ", msel, " while the maximum is given by BasicCoxDiag.MSELMAX = ", BasicCoxDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat maps of feature-selected data matrix and continue execution.\n");
      }

      if (msel <= BasicCoxDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the m * n data matrix after feature selection.
        # . Samples not sorted. Genes in order of feature selection, but otherwise not clustered.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste(bc$m, " selected genes. Samples not sorted. Genes not clustered.", sep = "");      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ASel = as.matrix(t(dfXSel));   # m * n = genes * samples format.

        if (nrow(ASel) == 1) {
          ASel = rbind(ASel, ASel);     # Kludge for heat map display when there is only 1 gene.
        }
        
        if (flagWrite == 'yes') {
          #xxx jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ASel,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................


        # .......................................................................................
        # . Preamble for sorting samples :
        # . if the values of the external covariate are all integers, use as part of the sort key.
        # .......................................................................................            
        azNR = unique(az);                        # Nonredundant list of values for external covariate.

        flagSortOnZ = FALSE;                      # Will indicate if we have sorted on covariate Z as well.
        nnonInt = sum(Math.isInt(azNR) == FALSE);
      
        if (nnonInt == 0) {
          Tmax = max(at);
          atForSort = at + az * Tmax;
          flagSortOnZ = TRUE;
        } else {
          atForSort = at;
          flagSortOnZ = FALSE;
        }
        # .......................................................................................                    


      
        # .......................................................................................      
        # . Sort samples so that the shortest survival times are on the left.
        # . If distinct values of covariate Z are integer, first sort on Z
        # . before sorting on survival times.
        # .......................................................................................
        sBuf = sort(atForSort, decreasing = FALSE, index.return = TRUE);
        indexSort = sBuf[["ix"]];      # Sort index.

        ASort = ASel[ , indexSort];    # Sorted on columns.
        azSort = az[indexSort];        # Values of Z in same order as sorted samples.
        # .......................................................................................
        # . Samples sorted, genes not clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        if (!flagSortOnZ) {
          pname = paste(bc$m, " selected genes. Samples sorted ",
                        " with increasing survival times left-to-right.",
                        " Genes not clustered.", sep = "");
          caption = paste(bc$m, " sel. genes. Samples sorted increas. surv. times LtR. Genes not clustered.",
                          sep = "");
        } else {
          pname = paste(bc$m, " selected genes. Samples sorted first on Z, then",
                               " with increasing survival times left-to-right.",
                               " Genes not clustered.", sep = "");
          caption = paste(bc$m, " sel. genes. Samples sort. on Z, then on increas. surv. times LtR. Genes not clust.",
                          sep = "");
        }
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        if (nrow(ASort) == 1) {
          ASort = rbind(ASort, ASort);     # Kludge for heat map display when there is only 1 gene.
        }
        
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................


      
      
        # .......................................................................................
        # . Samples sorted, genes clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        if (!flagSortOnZ) {
          pname = paste(bc$m, " selected genes. Samples sorted ",
                        " with increasing survival times left-to-right.",
                        " Genes clust.", sep = "");
          caption = paste(bc$m, " sel. genes. Samples sorted increas. surv. times LtR. Genes clust.",
                          sep = "");
        } else {
          pname = paste(bc$m, " selected genes. Samples sorted first on Z, then",
                               " with increasing survival times left-to-right.",
                               " Genes clust.", sep = "");
          caption = paste(bc$m, " sel. genes. Samples sort. on Z, then on increas. surv. times LtR. Genes clust.",
                          sep = "");
        }
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
	  #xxxx     jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
            
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'yes',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................



        # .......................................................................................      
        # . Generate a bar that indicates values of Z in final sorting order for the heat
        # . map columns.
        # .......................................................................................
        if (flagSortOnZ) {
          azSort = az[indexSort];               # Values of Z in same order as sorted samples.
          azSort = matrix(azSort, nrow = 1);    # Make into matrix, for bar.
          azSort = rbind(azSort, azSort);       # It needs at least two rows for the heat map.
          # .......................................................................................
          # . Generate file name :      
          # .......................................................................................
          fname = File.generateRandomName(dirName, stemName, ext = "jpg");

          pname = paste("Indicator bar for Z values in sorting order ",
                        " of the preceding heat map columns.", sep = "");

          afile = c(afile, fname);
          aplot = c(aplot, pname);
          # .......................................................................................
          # . Plot here :
          # .......................................................................................
          if (flagWrite == 'yes') {
	    #xxxxxx         jpeg(fname);              # Turn on plot device.
	    jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
          }
            
          SuperPcDiag.plotGeneDataMatrix(ax = azSort, caption = pname);
          # .....................................................................................
          # . Close device or prompt user for next plot :      
          # .......................................................................................
          if (flagWrite == 'yes') {
            dev.off();
          } else if (flagWrite == 'no') {
            buf = readline(">>Enter a carriage return to continue: ");    # Pause.
          }
          # .......................................................................................        
        }
        # ..........................................................................................
      }
      # ......................................................................................................
      # . END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS
      # ......................................................................................................



      
      # .......................................................................................
      # . Survival times and covariate values under the sort key :
      # .
      # . Generate file name :
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      # .......................................................................................
      # . Select captions based on clustering scheme :
      # .......................................................................................      
      pname = paste("Survival times and covariate values with samples sorted", sep = ""); 
      afile = c(afile, fname);
      aplot = c(aplot, pname);                        
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }

      atSort = at[indexSort];       # Sorted survival times.
      azSort = az[indexSort];       # Sorted covariate values.
      acSort = asample[indexSort];  # Corresponding sample names.
      
      par(mfrow = c(2,1));

      plot(atSort, xaxt = 'n', xlab = 'sorted samples', pch = 19);
      axis(side = 1, at = 1:length(acSort), labels = acSort);
      
      plot(azSort, xaxt = 'n', xlab = 'sorted samples', pch = 19);
      axis(side = 1, at = 1:length(acSort), labels = acSort);      

      par(mfrow = c(1, 1));      
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }                  
      # .......................................................................................


     

      
      # ...................................................................................
      # . Compute the log-hazard ratios, using the training set-derived column means:
      # . This call returns :
      # .          sl$Y = n * K matrix of principal components.
      # .     sl$aloghR = n matrix of log-hazard-ratios.
      # ...................................................................................
      sl = BasicCox.computeCoxLogHazardWithCovAndPred(bc, dfX, az, hRC);      
      # ...................................................................................


      

      # .......................................................................................
      # . Plot the hazard ratios estimated based on actual covariate values, against the samples :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = 'Estimated hazard ratios';
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
            
      ylim = c(0.0, max(sl$ahR));

      if (sl$flagPred) {
        ahRBuf = sl$ahR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
      } else {
        ahRBuf = sl$ahR;
      }
      
      plot(ahRBuf, xlab = 'Index (sample)', ylab = 'Hazard ratio',
           main = 'Estimated hazard ratios', ylim = ylim,
           xaxt = 'n', pch = 19);

      axis(side = 1, at = 1:length(asample), labels = asample);
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................



      # .......................................................................................
      # . Generate scatter plots of survival times against centered gene expression values
      # . for up to the first four genes :
      # .......................................................................................
      azNR = unique(az);                  # Nonredundant list of values for external covariate.
      nzNR = length(azNR);                # Number of nonredundant values.

      if (nzNR > BasicCox.NZMAX) {
        captionSub = 'Samples for all values of z';
        YBuf = sl$Y;
        
        if (bc$m == 1) {
          YBuf = as.matrix(sl$Y);
        }        
        
        pInfo = BasicCoxDiag.plotSurvivalTimesVsGE(bc, at, YBuf,
                                                   captionSub,
                                                   afile, aplot,
                                                   flagWrite, dirName, stemName);
        afile = pInfo$afile;
        aplot = pInfo$aplot;
      } else  {
        for (z in azNR) {
          indexBuf = which(az == z);
          atBuf = at[indexBuf];
          YBuf = sl$Y[indexBuf, ];

          if (bc$m == 1) {
            YBuf = as.matrix(YBuf);               # m == 1 is a special case.
          }
          
          captionSub = paste("Samples with Z = ", z, sep = "");
          pInfo = BasicCoxDiag.plotSurvivalTimesVsGE(bc, atBuf, YBuf,
                                                     captionSub,
                                                     afile, aplot,
                                                     flagWrite, dirName, stemName);          
        }
      }
      # .......................................................................................

      
      
     
      # .......................................................................................
      # . Scatter plot of survival times against estimated log-hazard-ratio :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Survival time versus log hazard ratio";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      if (sl$flagPred) {
        aloghRBuf = sl$aloghR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
      } else {
        aloghRBuf = sl$aloghR;
      }
      
      xlab = "log hazard ratio (estimated)";
      ylab = "Survival time";
      plot(aloghRBuf, at, type = 'p', xlab = xlab, ylab = ylab, main = pname, pch = 19);
      abline(v = 0.0);
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................




      
      # ....................................................................................
      # . Plot survival times versus predicted DloghR = loghR(Z=1) - loghR(Z=0) :
      # .......................................................................................
      msg = Cox.checkBinary(az);                     # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg == 'ok') {
        # ....................................................................................
        # . Generate file name:
        # ....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Survival times vs predicted DloghR";
        afile = c(afile, fname);
        aplot = c(aplot, pname);      
        # ....................................................................................
        # . Plot here :
        # ....................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Compute DloghR :
        # .....................................................................................
        aDloghR = sl$aDloghRz;               # This is DloghR = loghR(Z = 1) - loghR(Z = 0).

        acol = ifelse(az == 1, 'blue', 'red');
        # .....................................................................................
        # . For the feature selection level that maximizes significance :
        # . Plot survival times againsts DloghR.
        # .....................................................................................
        ymin = 0.0;
        ymax = 1.1 * max(at);

        xmax = max(aDloghR);
        xmin = min(aDloghR);
        
        caption = paste('Surv. time versus predicted DloghR: ');

        temp1 = paste('m = ', bc$m,
                        ', hRC = ', sprintf("%8.3e", hRC) , sep = "");

        caption = paste(caption, temp1, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aDloghR, at, ylim = c(ymin, ymax),
             type = 'p', xlab = 'predicted DloghR = loghR(Z = 1) - loghR(Z =0)',
             ylab = 'survival time', main = caption, col = acol, pch = 19);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);

        abline(v = 0);                           # Abcissa.
        temp1 = log(hRC);
        abline(v = temp1, lty = 'dashed');       # Boundary for determining sensitive patients.
        # ......................................................................................
        # . Add the legend here:
        # ......................................................................................
        xtemp1 = xmax - 0.2 * (xmax - xmin);
        ytemp1 = ymax;
        
        legendText = c("Z = 0", "Z = 1");
        colVector = c('red', 'blue');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = xtemp1, y = ytemp1,
               legend = legendText, col = colVector, pch = pchVector, bty = 'n');
        # ......................................................................................
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # ....................................................................................        
      }
      # .......................................................................................      



      

     
      # .......................................................................................
      # . Plot prediction of sample sensitivity vs sample index.
      # . These are the samples for which predicted DloghR <= log(hRC).
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Sensitivity status vs sample index";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ylim = c(0, 1);

        acol = ifelse(az == 0, 'red', 'blue');
        
        plot(sl$aflagSensitiveZ, xlab = 'Index (sample)', ylab = 'Sensitivity',
             main = 'Sensitivity prediction', ylim = ylim, col = acol,
             xaxt = 'n', pch = 19);

        axis(side = 1, at = 1:length(asample), labels = asample);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................




      # .......................................................................................
      # . Flag patients predicted sensitive, UN-sorted sample order; generate a heat
      # . map with bars. For two-armed studies only.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {      
        aflag = sl$aflagSensitiveZ;                 # The {0, 1} flags, not sorted. 1 = sensitive, 0 = not sensitive.
        aflag = ifelse(aflag == 1, 0.65, aflag);        

        aflag = matrix(aflag, nrow = 1);            # Make into matrix.
        aflag = rbind(aflag, aflag);                # It needs at least two rows for the heat map.
        # .......................................................................................      
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        pname = paste("Flag sensitive patients, hRC = ", hRC,
                      ", original sample order, red = sensitive", sep = ""); 
        afile = c(afile, fname);
        aplot = c(aplot, pname);                        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx    jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        SuperPcDiag.plotGeneDataMatrix(ax = aflag, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .....................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .....................................................................................
      }
      # .......................................................................................

            

      


      # .......................................................................................
      # . Flag patients predicted sensitive, SORTED sample order; generate a heat
      # . map with bars.
      # . For two-armed studies only.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {      
        aflagSort = sl$aflagSensitiveZ[indexSort];       # The {0, 1} flags, sorted. 1 = sensitive, 0 = not sensitive.
        aflagSort = ifelse(aflagSort == 1, 0.65, aflagSort);
        
        acSort = asample[indexSort];                     # Corresponding sample names.

        aflagSort = matrix(aflagSort, nrow = 1);         # Make into matrix, for bar.
        aflagSort = rbind(aflagSort, aflagSort);         # It needs at least two rows for the heat map.
        # .......................................................................................      
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        pname = paste("Flag sensitive patients, hRC = ", hRC,
                      ", sorted sample order, red = sensitive", sep = ""); 
        afile = c(afile, fname);
        aplot = c(aplot, pname);                        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        SuperPcDiag.plotGeneDataMatrix(ax = aflagSort, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .....................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .....................................................................................
      }
      # .......................................................................................

      

     
      # .......................................................................................
      # . Scatter plot of estimated log-hazard-ratios against the first principal
      # . component (for two-arm studies only):
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Log hazard ratio versus y1, hRC = ", hRC, sep = "");
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Get the data and segregate into Z = 0 and Z = 1 arms :
        # .......................................................................................        
        if (sl$flagPred) {
          aloghRBuf = sl$aloghR[ , 1];      # The first column contains the estimated hazard ratios for the actual Z value.
        } else {
          aloghRBuf = sl$aloghR;
        }

        ayPC1 = sl$Y[ , 1];                 # Gene expression (possibly mean-centered) for gene 1.

        ayPC1_0 = ayPC1[az == 0];
        ayPC1_1 = ayPC1[az == 1];

        aflagSensitiveZ_0 = sl$aflagSensitiveZ[az == 0];
        aflagSensitiveZ_1 = sl$aflagSensitiveZ[az == 1];        

        aloghRBuf_0 = aloghRBuf[az == 0];
        aloghRBuf_1 = aloghRBuf[az == 1];

        xmin = min(ayPC1);
        xmax = max(ayPC1);        
        
        ymin = min(aloghRBuf);
        ymax = max(aloghRBuf);
        # .......................................................................................
        # . The actual plot gets done here :
        # .......................................................................................      
        xlab = "y_mean_center_1";
        ylab = "loghR(estimated on actual Z)";

        apch_0 = ifelse(aflagSensitiveZ_0 == 0, 1, 19);           # pch = 1, open circles; pch = 19, filled circles.
        apch_1 = ifelse(aflagSensitiveZ_1 == 0, 1, 19);           # pch = 1, open circles; pch = 19, filled circles.        

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);
        plot(ayPC1_0, aloghRBuf_0, type = 'p',
             xlab = xlab, ylab = ylab, main = pname,
             xlim = c(xmin, xmax), ylim = c(ymin, ymax), col = 'red',
             pch = apch_0);
        par(cex.main = cex.main.OLD);
        
        lines(ayPC1_1, aloghRBuf_1, type = 'p', col = 'blue', pch = apch_1);

        abline(v = 0.0);
        abline(h = 0.0);
        # .......................................................................................
        # . Draw segments :
        # .......................................................................................
        i0min = which.min(ayPC1_0);
        i0max = which.max(ayPC1_0);        
        segments(ayPC1_0[i0min], aloghRBuf_0[i0min], ayPC1_0[i0max], aloghRBuf_0[i0max], col = 'red');

        i1min = which.min(ayPC1_1);
        i1max = which.max(ayPC1_1);        
        segments(ayPC1_1[i1min], aloghRBuf_1[i1min], ayPC1_1[i1max], aloghRBuf_1[i1max], col = 'blue');

        xtemp1 = xmax - 0.2 * (xmax - xmin);
        ytemp1 = ymax;
        
        legendText = c("Z = 0", "Z = 1");
        colVector = c('red', 'blue');
        ltyVector = c('solid', 'solid');
        legend(x = xtemp1, y = ytemp1, legend = legendText, col = colVector, lty = ltyVector, bty = 'n');

        xtemp1 = xmax - 0.2 * (xmax - xmin);
        ytemp1 = ymax - 0.075 * (ymax - ymin);
        
        legendText = c("not sensitive", "sensitive");
        colVector = c('blue', 'blue');
        pchVector = c(1, 19);
        legend(x = xtemp1, y = ytemp1, legend = legendText, col = colVector, pch = pchVector, bty = 'n');
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................





      # .......................................................................................
      # . Survival curves for Z = 0 and Z = 1 arms with ALL samples
      # . (for two-arm studies only):
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Survival curves for all patients", sep = "");
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Subset to sensitive samples only :
        # .......................................................................................
        legend_0 = "Z = 0";
        legend_1 = "Z = 1";
        caption = pname;
        
        SuperPcDiag.plotSurvivalOnBinary(at, as, az, legend_0, legend_1, caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      


      # .......................................................................................
      # . Survival curves for Z = 0 and Z = 1 arms of the sensitive samples, only :
      # . component (for two-arm studies only):
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Plot the survival curves only if a sensitive subpopulation has been identified :
        # .......................................................................................
        nsens = sum(sl$aflagSensitiveZ == 1);          # Number of samples predicted sensitive.
        
        if (nsens > 0) {
          # .......................................................................................
          # . Generate file name :      
          # .......................................................................................
          fname = File.generateRandomName(dirName, stemName, ext = "jpg");
          pname = paste("Survival curves for sensitive patients only", sep = "");
          afile = c(afile, fname);
          aplot = c(aplot, pname);
          # .......................................................................................
          # . Turn on plot device :
          # .......................................................................................
          if (flagWrite == 'yes') {
            jpeg(fname);              # Turn on plot device.
          }
          # .......................................................................................
          # . Subset to sensitive samples only :
          # .......................................................................................
          atSens = at[sl$aflagSensitiveZ == 1];
          asSens = as[sl$aflagSensitiveZ == 1];
          azSens = az[sl$aflagSensitiveZ == 1];                

          legend_0 = "Z = 0";
          legend_1 = "Z = 1";
          caption = pname;
        
          SuperPcDiag.plotSurvivalOnBinary(atSens, asSens, azSens, legend_0, legend_1, caption);
          # .....................................................................................
          # . Close device or prompt user for next plot :      
          # .......................................................................................
          if (flagWrite == 'yes') {
            dev.off();
          } else if (flagWrite == 'no') {
            buf = readline(">>Enter a carriage return to continue: ");    # Pause.
          }
          # .......................................................................................
        }
        # .......................................................................................        
      }
      # .......................................................................................
      



 

      # .......................................................................................
      # . Plot samples in gene space, if m > 1 :
      # .......................................................................................
      if (bc$m > 1) {
        # .....................................................................................
        # . Generate file name :
        # .....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Samples in gene space";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Generate a color array if the values are just 0 and 1 :
        # .......................................................................................
        acol = rep("black", times = length(az));        
        azNR = sort(unique(az));             # Nonredundant list of values for external covariate.
        flagColBinary = FALSE;

        pnameBuf = pname;

        if ((azNR[1] == 0) && (azNR[2] == 1)) {
          indexBuf = which(az == 1);
          acol[indexBuf] = rep("blue", times = length(indexBuf));    # Z = 1 values.
          acol[-indexBuf] = rep("red", times = length(indexBuf));    # Z = 0 values.
          flagColBinary = TRUE;
          pnameBuf = paste(pname, " red Z = 0, blue Z = 1", sep = "");
        }
        # .......................................................................................
        # . Proceed with the plot :
        # .......................................................................................        
        xlab = "y_mean_center_1";
        ylab = "y_mean_center_2";
        
        plot(sl$Y[ , 1], sl$Y[ , 2], xlab = xlab, ylab = ylab, main = pnameBuf, col = acol, pch = 19);
        abline(h = 0.0);
        abline(v = 0.0);        
        # ........................................................................................
        # . Assuming z = 0 or 1 only, generate the boundary at which h0 = h1 exactly :
        # ........................................................................................        
        if (bc$agamma[2] != 0.0) {
          bBuf = - bc$agamma[1] / bc$agamma[2];                        # Slope.
          aBuf = - bc$betaZ / bc$agamma[2];                            # y2-intercept.
          abline(a = aBuf, b = bBuf, lty = 'dashed', col = 'blue');      # Defines separation plane.
        } else if (bc$agamma[1] != 0.0) {
          vBuf = - bc$betaZ / bc$agamma[1];                            # y1-intercept.
          abline(v = vBuf, lty = 'dashed', col = 'blue');                # Defines separation plane.          
        }
        # ........................................................................................        
      }
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................



      
      
      # .......................................................................................
      # . Plot survival curves :  global comparison. This gets plotted only for non-binary
      # . external covariate.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg != 'ok') {
        # .......................................................................................
        # . Generate file name :            
        # .......................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Survival curves";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1,1));
        # .......................................................................................                
        # . >> ALL samples :
        # .......................................................................................        
        caption ="All samples";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at, as, aloghRBuf, caption);        
        # .......................................................................................
        par(mfrow = c(1,1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }        
      # .......................................................................................



      
      
      # .......................................................................................
      # . Plot survival curves : for two-arm studies only, separately investigate
      # . survival curves split on median predicted log-hazard-ratio.
      # .       cs1 = Cox.computeCoxOnSplitLoghR(at1, as1, aloghR_buf1);      
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Get the log-hazard-ratios :
        # .......................................................................................              
        if (sl$flagPred) {
          aloghRBuf = sl$aloghR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
        } else {
          aloghRBuf = sl$aloghR;
        }
        # .......................................................................................      
        # . Generate file name :            
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Survival plots for separate arms of binary study";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Start plots here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(2,2));
        # .......................................................................................
        # . Define the subsets and plot for each :
        # . >> Z = 0:
        # .......................................................................................        
        at0 = at[az == 0];
        as0 = as[az == 0];
        aloghR0 = aloghRBuf[az == 0];

        caption ="Z = 0 arm";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at0, as0, aloghR0, caption);
        # .......................................................................................                
        # . >> Z = 1 :
        # .......................................................................................        
        at1 = at[az == 1];
        as1 = as[az == 1];
        aloghR1 = aloghRBuf[az == 1];        
        caption ="Z = 1 arm";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at1, as1, aloghR1, caption);
        # .......................................................................................                
        # . >> ALL samples (repeated here for reference) :
        # .......................................................................................        
        caption ="All samples";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at, as, aloghRBuf, caption);        
        # .......................................................................................
        # . End the plots here:
        # .......................................................................................
        par(mfrow = c(1,1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................            


      

      
      # .......................................................................................
      # . Plot baseline hazard :
      # .
      # . Generate file name :            
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Baseline hazard";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      par(mfrow = c(2,2));
      
      if (flagWrite == 'yes') {
        par(mfrow = c(2,2));      # Otherwise written jpeg might look scrunched.
      }
      # .......................................................................................
      # . J. Theilhaber: 5-2-2010: access precomputed baseline hazard results.
      # .......................................................................................
      bh = BasicCox.getBaselineHazard(bc);   # Baseline hazard information.
      
      atSort = bh$atSort;                    # Time points (in sorted order).
      aSBase = bh$aSBase;                    # Baseline survival function.
      tBaseMed = bh$tBaseMed;                # Median survival time under baseline.
      aLambdaBase = bh$aLambdaBase;          # Cumulative baseline hazard function.
      aMSort = bh$aMSort;                    # Martingale residuals.
      # .......................................................................................
      # . Plot the baseline survival function :
      # .......................................................................................      
      caption = paste("Baseline survival, tMed = ", sprintf("%8.3e", tBaseMed), sep = "");      
      ylab = expression("exp(-" * Lambda * "0 (t))")
      tMax = max(at);
      plot(atSort, aSBase,
           type = 'l', xlab = "Survival time",
           ylab = ylab,
           main = caption, xlim = c(0, tMax), ylim = c(0,1));
      # .......................................................................................
      # . Plot the baseline cumulative hazard function :
      # .......................................................................................      
      caption = paste("Baseline cum. hazard", sep = "");      
      ylab = expression(Lambda * "0 (t)")
      tMax = max(at);
      plot(atSort, aLambdaBase,
           type = 'l', xlab = "Survival time",
           ylab = ylab,
           main = caption, xlim = c(0, tMax), ylim = c(0,max(aLambdaBase)));      
      # .......................................................................................
      # . Plot the Martingale residuals :
      # .......................................................................................
      caption = 'Martingale residuals';
      ylab = "M";
      tMax = max(at);
      plot(atSort, aMSort,
           type = 'p', xlab = "Survival time",
           ylab = ylab,
           main = caption, xlim = c(0, tMax));
      abline(h = 0, lty = 'dashed');
      lines(lowess(atSort, aMSort));             # Smoothing for detecting trends.
      # .......................................................................................
      par(mfrow = c(1,1));
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................



      


      # .......................................................................................
      # . Plot the gene expression profiles for m <= 4 :
      # .
      # . Generate file name :            
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Gene expression profiles";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      if (bc$m == 1) {
        par(mfrow = c(1,1));
      } else if (bc$m == 2) {
        par(mfrow = c(1,2));
      } else {
        par(mfrow = c(2,2));        
      }

      if (flagWrite == 'yes') {
        par(mfrow = c(2,2));      # Otherwise written jpeg might look scrunched.
      }
      
      mBuf = min(bc$m, 4);
      
      for (l in 1:mBuf) {
        caption = paste("Gene expression profile ", l, sep = "");
        xlab = paste("gene index (m = ", bc$m, ")", sep = "");
        ylab = paste("y_mean_center", l, sep = "");

        plot(sl$Y[ , l], xlab = xlab, ylab = ylab, main = caption, xaxt = 'n', pch = 19);
        abline(h = 0.0);
        axis(side = 1, at = 1:length(agene), labels = agene);         # Add gene labels.
      }

      par(mfrow = c(1,1));
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................


      
      # .......................................................................................
      # . Final tally :
      # .......................................................................................      
      nplot = length(afile);
      
      if (flagWrite == 'yes') {
        cat(" ..........  ", nplot, " jpeg plot files were generated.\n", sep = "");
      }
      # .......................................................................................

      
      
      # ....................................................................
      # . Package file names and plot names into list.
      # . Note that these are generated (with dummy names in that case)
      # . even if flagWrite = 'no'.
      # .
      # .   nplot = total number of plots in array.
      # .   afile = array of file names.
      # .   aplot = array of corresponding plot names.
      # ....................................................................
      sp = list(nplot = nplot, afile = afile, aplot = aplot);

      class(sp) = 'basic.cox.diag.plot';
      # ....................................................................
      
     
      # ...........
      return (sp);
      # ...........

}

# =================================================================================================
# . End of BasicCoxDiag.plotCoxWithCov.
# =================================================================================================






# =================================================================================================
# . BasicCoxDiag.plotCoxWithCovOnTest : displays the results of an analysis using the Cox propotional
# . ---------------------------------   hazard model on survival data, in the form of a series of plots.
# .
# . This is restricted version of BasicCoxDiag.plotCoxWithCov(), specific for displaying test
# . set results.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .       sp = BasicCoxDiag.plotCoxWithCovOnTest(at, as, az, dfX, bc, hRC,
# .                                              flagWrite, dirName, stemName);
# .
# .   In:
# .            at = n : vector of test set survival times (n = number of samples).
# .
# .            as = n : vector of test set censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for test set external covariate.
# .
# .           dfX = input test set data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .           bc = result of basic Cox model computation, returned
# .                 by function BasicCox.computeCoxWithCov().
# .
# .       hRC = cutoff on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .
# .     flagWrite = no/yes : flag indicating whether plots should be written to file in jpeg
# .                 format instead of being displayed.
# .                 If value is 'yes', each plot will be written to a file in the directory
# .                 indicated by 'dirName', with a name given by 'stemName' followed by
# .                 a random string and the .jpg extension.
# .                 If value is 'no', the user is prompted to interactively provide carriage
# .                 returns to march through the display.
# .
# .       dirName = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .      stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .   Out:
# .
# .           - If flagWrite = 'no', displays a series of plots. The use enter carriage returns
# .           to advance from one plot to the next.
# .           Object sp returned is NULL.
# .
# .           - If flagWrite = 'yes', generates a series of plot files, as indicated above.
# .           Object sp returned is a list with members:
# .
# .                  nplot = number of plot files generated.
# .                  afile = array of file names.
# .                  aplot = array of plot names.
# .
# =================================================================================================

BasicCoxDiag.plotCoxWithCovOnTest <- function(at, as, az, dfX, bc, hRC,
                                              flagWrite = 'no',
                                              dirName = NULL, stemName = NULL)
{

      # .............................................................
      cat(" ..........  Entry in BasicCoxDiag.plotCoxWithCovOnTest.\n");
      # .............................................................

      
      # .............................................................
      stopifnot((flagWrite == 'no') || (flagWrite == 'yes'));
      # .............................................................
      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCovOnTest: ";
        msg = paste("The input bc is not of class basic.cox.cov\n");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.
      
      if (nt != n) {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCovOnTest: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCovOnTest: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCovOnTest: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      
      if (bc$m != p) {
        msg = "ERROR: from BasicCoxDiag.plotCoxWithCovOnTest: ";        
        msg = paste("The input data matrix does not have the same number of ");
        msg = paste("genes as in the supervised pc. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("Bc has m = " , bc$m, " genes.");
        stop(msg);
      }

      stopifnot(hRC >= 0.0);      
      # ...............................................................................................

      
      # ...................................................................................
      if (bc$flagCenter == 'yes') {
        dfXSel = sweep(dfX, 2, bc$axm);                     # Center each column separately on the means of the training set.
      } else {
        dfXSel = dfX;                                       # No centering.
      }

      agene = colnames(dfXSel);                         # Selected gene names, in feature selection order.
      asample = rownames(dfXSel);                       # Sample names.

      nsel = nrow(dfXSel);                              # Number of samples.
      msel = ncol(dfXSel);                              # Number of subsetted genes.            
      # ...................................................................................

      
      # .......................................................
      # . Reset some defaults, in case they got changed :
      # .......................................................      
      par(ask = FALSE);
      par(mfrow = c(1,1));      
      # .......................................................


      # .......................................................................................
      if (flagWrite == 'no') {
        cat("\n");
        cat(" ..........  Enter carriage returns as indicated to generate plots one-by-one.\n");
      } else if (flagWrite == 'yes') {
        cat(" ..........  Generating plot files in directory = ", dirName, "\n", sep = "");
      }
      # .......................................................................................


      # ...........................................................
      # . Initialize plot arrays :
      # ...........................................................
      afile = c();
      aplot = c();

      if (flagWrite == 'no') {
        dirName = "foo";        # Dummy value.
        stemName = "dum";       # Dummy value.
      }
      # ...........................................................

      
      
      # .......................................................................................
      if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................
      

      
      # ..........................................................................................................
      # . HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS
      # .
      # . Generate heat maps below, provided the data matrices are not too large.
      # .
      # . First, plot of the entire data matrix, before any feature selection :
      # ..........................................................................................................
      if (p > BasicCoxDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the entire data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here p = ", p, " while the maximum is given by BasicCoxDiag.MSELMAX = ", BasicCoxDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat map for entire data matrix and continue execution.\n");
      }

      if (p <= BasicCoxDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the p * n data matrix before any feature selection.
        # . No clustering or sorting of any kind.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test set data matrix";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ABuf = t(dfX);                  # Make this genes * samples.

        if (nrow(ABuf) == 1) {
          ABuf = rbind(ABuf, ABuf);     # Kludge for heat map display when there is only 1 gene.
        }

        if (flagWrite == 'yes') {
	  #xxxxxx   jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ABuf, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................      
      }
      # ..........................................................................................................

      
      # ..........................................................................................................
      # . Next, plot of the data matrix after feature selection :
      # ..........................................................................................................
      if (msel > BasicCoxDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the feature-selected data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here msel = ", msel, " while the maximum is given by BasicCoxDiag.MSELMAX = ", BasicCoxDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat maps of feature-selected data matrix and continue execution.\n");
      }

      if (msel <= BasicCoxDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the m * n data matrix after feature selection.
        # . Samples not sorted. Genes in order of feature selection, but otherwise not clustered.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Test: ", bc$m, " selected genes. Samples not sorted. Genes not clustered.", sep = "");      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ASel = as.matrix(t(dfXSel));   # m * n = genes * samples format.

        if (nrow(ASel) == 1) {
          ASel = rbind(ASel, ASel);     # Kludge for heat map display when there is only 1 gene.
        }
        
        if (flagWrite == 'yes') {
          #xxxxx     jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ASel,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................


        # .......................................................................................
        # . Preamble for sorting samples :
        # . if the values of the external covariate are all integers, use as part of the sort key.
        # .......................................................................................            
        azNR = unique(az);                        # Nonredundant list of values for external covariate.

        flagSortOnZ = FALSE;                      # Will indicate if we have sorted on covariate Z as well.
        nnonInt = sum(Math.isInt(azNR) == FALSE);
      
        if (nnonInt == 0) {
          Tmax = max(at);
          atForSort = at + az * Tmax;
          flagSortOnZ = TRUE;
        } else {
          atForSort = at;
          flagSortOnZ = FALSE;
        }
        # .......................................................................................                    


      
        # .......................................................................................      
        # . Sort samples so that the shortest survival times are on the left.
        # . If distinct values of covariate Z are integer, first sort on Z
        # . before sorting on survival times.
        # .......................................................................................
        sBuf = sort(atForSort, decreasing = FALSE, index.return = TRUE);
        indexSort = sBuf[["ix"]];      # Sort index.

        ASort = ASel[ , indexSort];    # Sorted on columns.
        azSort = az[indexSort];        # Values of Z in same order as sorted samples.
        # .......................................................................................
        # . Samples sorted, genes not clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        if (!flagSortOnZ) {
          pname = paste("Test: ", bc$m, " selected genes. Samples sorted ",
                        " with increasing survival times left-to-right.",
                        " Genes not clustered.", sep = "");
          caption = paste(bc$m, " sel. genes. Samples sorted increas. surv. times LtR. Genes not clustered.",
                          sep = "");
        } else {
          pname = paste(bc$m, " selected genes. Samples sorted first on Z, then",
                               " with increasing survival times left-to-right.",
                               " Genes not clustered.", sep = "");
          caption = paste(bc$m, " sel. genes. Samples sort. on Z, then on increas. surv. times LtR. Genes not clust.",
                          sep = "");
        }
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
	  #xxxxx        jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        if (nrow(ASort) == 1) {
          ASort = rbind(ASort, ASort);     # Kludge for heat map display when there is only 1 gene.
        }
        
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................


      
      
        # .......................................................................................
        # . Samples sorted, genes clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        if (!flagSortOnZ) {
          pname = paste("Test: ", bc$m, " selected genes. Samples sorted ",
                        " with increasing survival times left-to-right.",
                        " Genes clust.", sep = "");
          caption = paste(bc$m, " sel. genes. Samples sorted increas. surv. times LtR. Genes clust.",
                          sep = "");
        } else {
          pname = paste(bc$m, " selected genes. Samples sorted first on Z, then",
                               " with increasing survival times left-to-right.",
                               " Genes clust.", sep = "");
          caption = paste(bc$m, " sel. genes. Samples sort. on Z, then on increas. surv. times LtR. Genes clust.",
                          sep = "");
        }
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
            
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'yes',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................



        # .......................................................................................      
        # . Generate a bar that indicates values of Z in final sorting order for the heat
        # . map columns.
        # .......................................................................................
        if (flagSortOnZ) {
          azSort = az[indexSort];               # Values of Z in same order as sorted samples.
          azSort = matrix(azSort, nrow = 1);    # Make into matrix, for bar.
          azSort = rbind(azSort, azSort);       # It needs at least two rows for the heat map.
          # .......................................................................................
          # . Generate file name :      
          # .......................................................................................
          fname = File.generateRandomName(dirName, stemName, ext = "jpg");

          pname = paste("Indicator bar for Z values in sorting order ",
                        " of the preceding heat map columns.", sep = "");

          afile = c(afile, fname);
          aplot = c(aplot, pname);
          # .......................................................................................
          # . Plot here :
          # .......................................................................................
          if (flagWrite == 'yes') {
  	    #xxxxx          jpeg(fname);              # Turn on plot device.
            jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
          }
            
          SuperPcDiag.plotGeneDataMatrix(ax = azSort, caption = pname);
          # .....................................................................................
          # . Close device or prompt user for next plot :      
          # .......................................................................................
          if (flagWrite == 'yes') {
            dev.off();
          } else if (flagWrite == 'no') {
            buf = readline(">>Enter a carriage return to continue: ");    # Pause.
          }
          # .......................................................................................        
        }
        # ..........................................................................................
      }
      # ......................................................................................................
      # . END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS
      # ......................................................................................................



      
      # .......................................................................................
      # . Survival times and covariate values under the sort key :
      # .
      # . Generate file name :
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      # .......................................................................................
      # . Select captions based on clustering scheme :
      # .......................................................................................      
      pname = paste("Test: survival times and covariate values with samples sorted", sep = ""); 
      afile = c(afile, fname);
      aplot = c(aplot, pname);                        
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }

      atSort = at[indexSort];       # Sorted survival times.
      azSort = az[indexSort];       # Sorted covariate values.
      acSort = asample[indexSort];  # Corresponding sample names.
      
      par(mfrow = c(2,1));

      plot(atSort, xaxt = 'n', xlab = 'sorted samples');
      axis(side = 1, at = 1:length(acSort), labels = acSort);
      
      plot(azSort, xaxt = 'n', xlab = 'sorted samples');
      axis(side = 1, at = 1:length(acSort), labels = acSort);      

      par(mfrow = c(1, 1));      
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }                  
      # .......................................................................................


     

      
      # ...................................................................................
      # . Compute the log-hazard ratios, using the training set-derived column means:
      # . This call returns :
      # .          sl$Y = n * K matrix of principal components.
      # .     sl$aloghR = n matrix of log-hazard-ratios.
      # ...................................................................................
      sl = BasicCox.computeCoxLogHazardWithCovAndPred(bc, dfX, az, hRC);      
      # ...................................................................................


      

      # .......................................................................................
      # . Plot the hazard ratios estimated based on actual covariate values, against the samples :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = 'Test: estimated hazard ratios';
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
            
      ylim = c(0.0, max(sl$ahR));

      if (sl$flagPred) {
        ahRBuf = sl$ahR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
      } else {
        ahRBuf = sl$ahR;
      }
      
      plot(ahRBuf, xlab = 'Index (sample)', ylab = 'Hazard ratio',
           main = 'Estimated hazard ratios', ylim = ylim,
           xaxt = 'n', pch = 19);

      axis(side = 1, at = 1:length(asample), labels = asample);
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................



      # .......................................................................................
      # . Generate scatter plots of survival times against centered gene expression values
      # . for up to the first four genes :
      # .......................................................................................
      azNR = unique(az);                  # Nonredundant list of values for external covariate.
      nzNR = length(azNR);                # Number of nonredundant values.

      if (nzNR > BasicCox.NZMAX) {
        captionSub = 'Test: samples for all values of z';
        YBuf = sl$Y;
        
        if (bc$m == 1) {
          YBuf = as.matrix(sl$Y);
        }        
        
        pInfo = BasicCoxDiag.plotSurvivalTimesVsGE(bc, at, YBuf,
                                                   captionSub,
                                                   afile, aplot,
                                                   flagWrite, dirName, stemName);
        afile = pInfo$afile;
        aplot = pInfo$aplot;
      } else  {
        for (z in azNR) {
          indexBuf = which(az == z);
          atBuf = at[indexBuf];
          YBuf = sl$Y[indexBuf, ];

          if (bc$m == 1) {
            YBuf = as.matrix(YBuf);               # m == 1 is a special case.
          }
          
          captionSub = paste("Test: samples with Z = ", z, sep = "");
          pInfo = BasicCoxDiag.plotSurvivalTimesVsGE(bc, atBuf, YBuf,
                                                     captionSub,
                                                     afile, aplot,
                                                     flagWrite, dirName, stemName);          
        }
      }
      # .......................................................................................

      
      
     
      # .......................................................................................
      # . Scatter plot of survival times against estimated log-hazard-ratio :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Test: survival time versus log hazard ratio";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      if (sl$flagPred) {
        aloghRBuf = sl$aloghR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
      } else {
        aloghRBuf = sl$aloghR;
      }
      
      xlab = "log hazard ratio (estimated)";
      ylab = "Survival time";
      plot(aloghRBuf, at, type = 'p', xlab = xlab, ylab = ylab, main = pname, pch = 19);
      abline(v = 0.0);
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................




      
      # ....................................................................................
      # . Plot survival times versus predicted DloghR = loghR(Z=1) - loghR(Z=0) :
      # .......................................................................................
      msg = Cox.checkBinary(az);                     # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg == 'ok') {
        # ....................................................................................
        # . Generate file name:
        # ....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test: survival times vs predicted DloghR";
        afile = c(afile, fname);
        aplot = c(aplot, pname);      
        # ....................................................................................
        # . Plot here :
        # ....................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Compute DloghR :
        # .....................................................................................
        aDloghR = sl$aDloghRz;               # This is DloghR = loghR(Z = 1) - loghR(Z = 0).

        acol = ifelse(az == 1, 'blue', 'red');
        # .....................................................................................
        # . For the feature selection level that maximizes significance :
        # . Plot survival times againsts DloghR.
        # .....................................................................................
        ymin = 0.0;
        ymax = 1.1 * max(at);

        xmax = max(aDloghR);
        xmin = min(aDloghR);
        
        caption = paste('Test: surv. time versus predicted DloghR: ');

        temp1 = paste('m = ', bc$m,
                        ', hRC = ', sprintf("%8.3e", hRC) , sep = "");

        caption = paste(caption, temp1, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aDloghR, at, ylim = c(ymin, ymax),
             type = 'p', xlab = 'predicted DloghR = loghR(Z = 1) - loghR(Z =0)',
             ylab = 'survival time', main = caption, col = acol, pch = 19);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);

        abline(v = 0);                           # Abcissa.
        temp1 = log(hRC);
        abline(v = temp1, lty = 'dashed');       # Boundary for determining sensitive patients.
        # ......................................................................................
        # . Add the legend here:
        # ......................................................................................
        xtemp1 = xmax - 0.2 * (xmax - xmin);
        ytemp1 = ymax;
        
        legendText = c("Z = 0", "Z = 1");
        colVector = c('red', 'blue');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = xtemp1, y = ytemp1,
               legend = legendText, col = colVector, pch = pchVector, bty = 'n');
        # ......................................................................................
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # ....................................................................................        
      }
      # .......................................................................................      



      

     
      # .......................................................................................
      # . Plot prediction of sample sensitivity vs sample index.
      # . These are the samples for which predicted DloghR <= log(hRC).
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test: sensitivity status vs sample index";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ylim = c(0, 1);

        acol = ifelse(az == 0, 'red', 'blue');
        
        plot(sl$aflagSensitiveZ, xlab = 'Index (sample)', ylab = 'Sensitivity',
             main = 'Test: sensitivity prediction', ylim = ylim, col = acol,
             xaxt = 'n');

        axis(side = 1, at = 1:length(asample), labels = asample);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................




      # .......................................................................................
      # . Flag patients predicted sensitive, UN-sorted sample order; generate a heat
      # . map with bars. For two-armed studies only.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {      
        aflag = sl$aflagSensitiveZ;                 # The {0, 1} flags, not sorted. 1 = sensitive, 0 = not sensitive.
        aflag = ifelse(aflag == 1, 0.65, aflag);        

        aflag = matrix(aflag, nrow = 1);            # Make into matrix.
        aflag = rbind(aflag, aflag);                # It needs at least two rows for the heat map.
        # .......................................................................................      
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        pname = paste("Test: flag sensitive patients, hRC = ", hRC,
                      ", original sample order, red = sensitive", sep = ""); 
        afile = c(afile, fname);
        aplot = c(aplot, pname);                        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
	  #xxxxx          jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        SuperPcDiag.plotGeneDataMatrix(ax = aflag, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .....................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .....................................................................................
      }
      # .......................................................................................

            

      


      # .......................................................................................
      # . Flag patients predicted sensitive, SORTED sample order; generate a heat
      # . map with bars.
      # . For two-armed studies only.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {      
        aflagSort = sl$aflagSensitiveZ[indexSort];       # The {0, 1} flags, sorted. 1 = sensitive, 0 = not sensitive.
        aflagSort = ifelse(aflagSort == 1, 0.65, aflagSort);
        
        acSort = asample[indexSort];                     # Corresponding sample names.

        aflagSort = matrix(aflagSort, nrow = 1);         # Make into matrix, for bar.
        aflagSort = rbind(aflagSort, aflagSort);         # It needs at least two rows for the heat map.
        # .......................................................................................      
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        pname = paste("Test: flag sensitive patients, hRC = ", hRC,
                      ", sorted sample order, red = sensitive", sep = ""); 
        afile = c(afile, fname);
        aplot = c(aplot, pname);                        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxxxx     jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        SuperPcDiag.plotGeneDataMatrix(ax = aflagSort, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .....................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .....................................................................................
      }
      # .......................................................................................

      

     
      # .......................................................................................
      # . Scatter plot of estimated log-hazard-ratios against the first principal
      # . component (for two-arm studies only):
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Test: log hazard ratio versus y1, hRC = ", hRC, sep = "");
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Get the data and segregate into Z = 0 and Z = 1 arms :
        # .......................................................................................        
        if (sl$flagPred) {
          aloghRBuf = sl$aloghR[ , 1];      # The first column contains the estimated hazard ratios for the actual Z value.
        } else {
          aloghRBuf = sl$aloghR;
        }

        ayPC1 = sl$Y[ , 1];                 # Gene expression (possibly mean-centered) for gene 1.

        ayPC1_0 = ayPC1[az == 0];
        ayPC1_1 = ayPC1[az == 1];

        aflagSensitiveZ_0 = sl$aflagSensitiveZ[az == 0];
        aflagSensitiveZ_1 = sl$aflagSensitiveZ[az == 1];        

        aloghRBuf_0 = aloghRBuf[az == 0];
        aloghRBuf_1 = aloghRBuf[az == 1];

        xmin = min(ayPC1);
        xmax = max(ayPC1);        
        
        ymin = min(aloghRBuf);
        ymax = max(aloghRBuf);
        # .......................................................................................
        # . The actual plot gets done here :
        # .......................................................................................      
        xlab = "y_mean_center_1";
        ylab = "loghR(estimated on actual Z)";

        apch_0 = ifelse(aflagSensitiveZ_0 == 0, 1, 19);           # pch = 1, open circles; pch = 19, filled circles.
        apch_1 = ifelse(aflagSensitiveZ_1 == 0, 1, 19);           # pch = 1, open circles; pch = 19, filled circles.        

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);
        plot(ayPC1_0, aloghRBuf_0, type = 'p',
             xlab = xlab, ylab = ylab, main = pname,
             xlim = c(xmin, xmax), ylim = c(ymin, ymax), col = 'red',
             pch = apch_0);
        par(cex.main = cex.main.OLD);
        
        lines(ayPC1_1, aloghRBuf_1, type = 'p', col = 'blue', pch = apch_1);

        abline(v = 0.0);
        abline(h = 0.0);
        # .......................................................................................
        # . Draw segments :
        # .......................................................................................
        i0min = which.min(ayPC1_0);
        i0max = which.max(ayPC1_0);        
        segments(ayPC1_0[i0min], aloghRBuf_0[i0min], ayPC1_0[i0max], aloghRBuf_0[i0max], col = 'red');

        i1min = which.min(ayPC1_1);
        i1max = which.max(ayPC1_1);        
        segments(ayPC1_1[i1min], aloghRBuf_1[i1min], ayPC1_1[i1max], aloghRBuf_1[i1max], col = 'blue');

        xtemp1 = xmax - 0.2 * (xmax - xmin);
        ytemp1 = ymax;
        
        legendText = c("Z = 0", "Z = 1");
        colVector = c('red', 'blue');
        ltyVector = c('solid', 'solid');
        legend(x = xtemp1, y = ytemp1, legend = legendText, col = colVector, lty = ltyVector, bty = 'n');

        xtemp1 = xmax - 0.2 * (xmax - xmin);
        ytemp1 = ymax - 0.075 * (ymax - ymin);
        
        legendText = c("not sensitive", "sensitive");
        colVector = c('blue', 'blue');
        pchVector = c(1, 19);
        legend(x = xtemp1, y = ytemp1, legend = legendText, col = colVector, pch = pchVector, bty = 'n');
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................





      # .......................................................................................
      # . Survival curves for Z = 0 and Z = 1 arms with ALL samples
      # . (for two-arm studies only):
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Test: survival curves for all patients", sep = "");
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Subset to sensitive samples only :
        # .......................................................................................
        legend_0 = "Z = 0";
        legend_1 = "Z = 1";
        caption = pname;
        
        SuperPcDiag.plotSurvivalOnBinary(at, as, az, legend_0, legend_1, caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      


      # .......................................................................................
      # . Survival curves for Z = 0 and Z = 1 arms of the sensitive samples, only :
      # . component (for two-arm studies only):
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Plot the survival curves only if a sensitive subpopulation has been identified :
        # .......................................................................................
        nsens = sum(sl$aflagSensitiveZ == 1);          # Number of samples predicted sensitive.
        
        if (nsens > 0) {
          # .......................................................................................
          # . Generate file name :      
          # .......................................................................................
          fname = File.generateRandomName(dirName, stemName, ext = "jpg");
          pname = paste("Test: survival curves for sensitive patients only", sep = "");
          afile = c(afile, fname);
          aplot = c(aplot, pname);
          # .......................................................................................
          # . Turn on plot device :
          # .......................................................................................
          if (flagWrite == 'yes') {
            jpeg(fname);              # Turn on plot device.
          }
          # .......................................................................................
          # . Subset to sensitive samples only :
          # .......................................................................................
          atSens = at[sl$aflagSensitiveZ == 1];
          asSens = as[sl$aflagSensitiveZ == 1];
          azSens = az[sl$aflagSensitiveZ == 1];                

          legend_0 = "Z = 0";
          legend_1 = "Z = 1";
          caption = pname;
        
          SuperPcDiag.plotSurvivalOnBinary(atSens, asSens, azSens, legend_0, legend_1, caption);
          # .....................................................................................
          # . Close device or prompt user for next plot :      
          # .......................................................................................
          if (flagWrite == 'yes') {
            dev.off();
          } else if (flagWrite == 'no') {
            buf = readline(">>Enter a carriage return to continue: ");    # Pause.
          }
          # .......................................................................................
        }
        # .......................................................................................        
      }
      # .......................................................................................
      



 

      # .......................................................................................
      # . Plot samples in gene space, if m > 1 :
      # .......................................................................................
      if (bc$m > 1) {
        # .....................................................................................
        # . Generate file name :
        # .....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test: samples in gene space";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Generate a color array if the values are just 0 and 1 :
        # .......................................................................................
        acol = rep("black", times = length(az));        
        azNR = sort(unique(az));             # Nonredundant list of values for external covariate.
        flagColBinary = FALSE;

        pnameBuf = pname;

        if ((azNR[1] == 0) && (azNR[2] == 1)) {
          indexBuf = which(az == 1);
          acol[indexBuf] = rep("blue", times = length(indexBuf));    # Z = 1 values.
          acol[-indexBuf] = rep("red", times = length(indexBuf));    # Z = 0 values.
          flagColBinary = TRUE;
          pnameBuf = paste(pname, " red Z = 0, blue Z = 1", sep = "");
        }
        # .......................................................................................
        # . Proceed with the plot :
        # .......................................................................................        
        xlab = "y_mean_center_1";
        ylab = "y_mean_center_2";
        
        plot(sl$Y[ , 1], sl$Y[ , 2], xlab = xlab, ylab = ylab, main = pnameBuf, col = acol);
        abline(h = 0.0);
        abline(v = 0.0);        
        # ........................................................................................
        # . Assuming z = 0 or 1 only, generate the boundary at which h0 = h1 exactly :
        # ........................................................................................        
        if (bc$agamma[2] != 0.0) {
          bBuf = - bc$agamma[1] / bc$agamma[2];                        # Slope.
          aBuf = - bc$betaZ / bc$agamma[2];                            # y2-intercept.
          abline(a = aBuf, b = bBuf, lty = 'dashed', col = 'blue');      # Defines separation plane.
        } else if (bc$agamma[1] != 0.0) {
          vBuf = - bc$betaZ / bc$agamma[1];                            # y1-intercept.
          abline(v = vBuf, lty = 'dashed', col = 'blue');                # Defines separation plane.          
        }
        # ........................................................................................        
      }
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................



      
      
      # .......................................................................................
      # . Plot survival curves :  global comparison. This gets plotted only for non-binary
      # . external covariate.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg != 'ok') {
        # .......................................................................................
        # . Generate file name :            
        # .......................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test: survival curves";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1,1));
        # .......................................................................................                
        # . >> ALL samples :
        # .......................................................................................        
        caption ="All samples";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at, as, aloghRBuf, caption);        
        # .......................................................................................
        par(mfrow = c(1,1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }        
      # .......................................................................................



      
      
      # .......................................................................................
      # . Plot survival curves : for two-arm studies only, separately investigate
      # . survival curves split on median predicted log-hazard-ratio.
      # .       cs1 = Cox.computeCoxOnSplitLoghR(at1, as1, aloghR_buf1);      
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Get the log-hazard-ratios :
        # .......................................................................................              
        if (sl$flagPred) {
          aloghRBuf = sl$aloghR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
        } else {
          aloghRBuf = sl$aloghR;
        }
        # .......................................................................................      
        # . Generate file name :            
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test: survival plots for separate arms of binary study";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Start plots here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(2,2));
        # .......................................................................................
        # . Define the subsets and plot for each :
        # . >> Z = 0:
        # .......................................................................................        
        at0 = at[az == 0];
        as0 = as[az == 0];
        aloghR0 = aloghRBuf[az == 0];

        caption ="Z = 0 arm";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at0, as0, aloghR0, caption);
        # .......................................................................................                
        # . >> Z = 1 :
        # .......................................................................................        
        at1 = at[az == 1];
        as1 = as[az == 1];
        aloghR1 = aloghRBuf[az == 1];        
        caption ="Z = 1 arm";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at1, as1, aloghR1, caption);
        # .......................................................................................                
        # . >> ALL samples (repeated here for reference) :
        # .......................................................................................        
        caption ="All samples";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at, as, aloghRBuf, caption);        
        # .......................................................................................
        # . End the plots here:
        # .......................................................................................
        par(mfrow = c(1,1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................            


      

      
#      # .......................................................................................
#      # . Plot baseline hazard :
#      # .
#      # . Generate file name :            
#      # .......................................................................................
#      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
#      pname = "Baseline hazard";
#      afile = c(afile, fname);
#      aplot = c(aplot, pname);
#      # .......................................................................................
#      # . Plot here :
#      # .......................................................................................
#      if (flagWrite == 'yes') {
#        jpeg(fname);              # Turn on plot device.
#      }
      
#      par(mfrow = c(2,2));
      
#      if (flagWrite == 'yes') {
#        par(mfrow = c(2,2));      # Otherwise written jpeg might look scrunched.
#      }
#      # .......................................................................................
#      # . J. Theilhaber: 5-2-2010: access precomputed baseline hazard results.
#      # .......................................................................................
#      bh = BasicCox.getBaselineHazard(bc);   # Baseline hazard information.
      
#      atSort = bh$atSort;                    # Time points (in sorted order).
#      aSBase = bh$aSBase;                    # Baseline survival function.
#      tBaseMed = bh$tBaseMed;                # Median survival time under baseline.
#      aLambdaBase = bh$aLambdaBase;          # Cumulative baseline hazard function.
#      aMSort = bh$aMSort;                    # Martingale residuals.
#      # .......................................................................................
#      # . Plot the baseline survival function :
#      # .......................................................................................      
#      caption = paste("Baseline survival, tMed = ", sprintf("%8.3e", tBaseMed), sep = "");      
#      ylab = expression("exp(-" * Lambda * "0 (t))")
#      tMax = max(at);
#      plot(atSort, aSBase,
#           type = 'l', xlab = "Survival time",
#           ylab = ylab,
#           main = caption, xlim = c(0, tMax), ylim = c(0,1));
#      # .......................................................................................
#      # . Plot the baseline cumulative hazard function :
#      # .......................................................................................      
#      caption = paste("Baseline cum. hazard", sep = "");      
#      ylab = expression(Lambda * "0 (t)")
#      tMax = max(at);
#      plot(atSort, aLambdaBase,
#           type = 'l', xlab = "Survival time",
#           ylab = ylab,
#           main = caption, xlim = c(0, tMax), ylim = c(0,max(aLambdaBase)));      
#      # .......................................................................................
#      # . Plot the Martingale residuals :
#      # .......................................................................................
#      caption = 'Martingale residuals';
#      ylab = "M";
#      tMax = max(at);
#      plot(atSort, aMSort,
#           type = 'p', xlab = "Survival time",
#           ylab = ylab,
#           main = caption, xlim = c(0, tMax));
#      abline(h = 0, lty = 'dashed');
#      lines(lowess(atSort, aMSort));             # Smoothing for detecting trends.
#      # .......................................................................................
#      par(mfrow = c(1,1));
#      # .....................................................................................
#      # . Close device or prompt user for next plot :      
#      # .......................................................................................
#      if (flagWrite == 'yes') {
#        dev.off();
#      } else if (flagWrite == 'no') {      
#        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
#      }
#      # .......................................................................................



      


      # .......................................................................................
      # . Plot the gene expression profiles for m <= 4 :
      # .
      # . Generate file name :            
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Test: gene expression profiles";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      if (bc$m == 1) {
        par(mfrow = c(1,1));
      } else if (bc$m == 2) {
        par(mfrow = c(1,2));
      } else {
        par(mfrow = c(2,2));        
      }

      if (flagWrite == 'yes') {
        par(mfrow = c(2,2));      # Otherwise written jpeg might look scrunched.
      }
      
      mBuf = min(bc$m, 4);
      
      for (l in 1:mBuf) {
        caption = paste("Gene expression profile ", l, sep = "");
        xlab = paste("gene index (m = ", bc$m, ")", sep = "");
        ylab = paste("y_mean_center", l, sep = "");

        plot(sl$Y[ , l], xlab = xlab, ylab = ylab, main = caption, xaxt = 'n');
        abline(h = 0.0);
        axis(side = 1, at = 1:length(agene), labels = agene);         # Add gene labels.
      }

      par(mfrow = c(1,1));
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................


      
      # .......................................................................................
      # . Final tally :
      # .......................................................................................      
      nplot = length(afile);
      
      if (flagWrite == 'yes') {
        cat(" ..........  ", nplot, " jpeg plot files were generated.\n", sep = "");
      }
      # .......................................................................................

      
      
      # ....................................................................
      # . Package file names and plot names into list.
      # . Note that these are generated (with dummy names in that case)
      # . even if flagWrite = 'no'.
      # .
      # .   nplot = total number of plots in array.
      # .   afile = array of file names.
      # .   aplot = array of corresponding plot names.
      # ....................................................................
      sp = list(nplot = nplot, afile = afile, aplot = aplot);

      class(sp) = 'basic.cox.diag.plot';
      # ....................................................................
      
     
      # ...........
      return (sp);
      # ...........

}

# =================================================================================================
# . End of BasicCoxDiag.plotCoxWithCovOnTest.
# =================================================================================================










# =================================================================================================
# . BasicCoxDiag.plotSurvivalTimesVsGE : a utility function, for plotting survival times against
# . ----------------------------------   gene expression values. To be called from e.g. from :
# .                                     BasicCoxDiag.plotCoxWithCov().
# .
# .   Syntax:
# .
# .        pInfo = BasicCoxDiag.plotSurvivalTimesVsGE(bc, at, Y, captionSub,
# .                                                   afile, aplot,
# .                                                   flagWrite, dirName, stemName);
# .
# .   In:
# .
# .       spc = result from BasicCox.computeCoxWithCov().
# .
# .        at = n : vector of survival times.
# .
# .         Y = n * m : matrix of (possibly mean-centered) gene expression values.
# .
# .  captionSub = title at bottom of page, captions all plots in the page.
# .
# .     afile = array of file names being accumulated in BasicCoxDiag.plotCoxWithCov().
# .
# .     aplot = array of file captions being accumulated in BasicCoxDiag.plotCoxWithCov().
# .
# .     flagWrite = no/yes : flag indicating whether plots should be written to file in jpeg
# .                 format instead of being displayed.
# .                 If value is 'yes', each plot will be written to a file in the directory
# .                 indicated by 'dirName', with a name given by 'stemName' followed by
# .                 a random string and the .jpg extension.
# .                 If value is 'no', the user is prompted to interactively provide carriage
# .                 returns to march through the display.
# .
# .       dirName = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .      stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .
# .     Checks are made to verify that: nrow(Y) = length(at); ncol(Y) = spc$K .
# .
# .   Out:
# .
# .       pInfo = list with members :
# .               afile
# .               aplot
# .
# =================================================================================================

BasicCoxDiag.plotSurvivalTimesVsGE <- function(bc, at, Y, captionSub,
                                               afile, aplot, flagWrite, dirName, stemName)
{

      # ...........................................................
      if (class(bc) != "basic.cox.cov") {
        msg = "ERROR: from BasicCoxDiag.plotSurvivalTimesVsGE ";
        msg = paste("The input bc is not of class basic.cox.cov");
        stop(msg);
      }
      # ...........................................................


      # .............................................................
      stopifnot((flagWrite == 'no') || (flagWrite == 'yes'));
      # .............................................................


      # ......................................................................................
      # . Check consistency of input variables :
      # ......................................................................................      
      if (nrow(Y) != length(at)) {
        cat("ERROR: from BasicCoxDiag.plotSurvivalTimesVsGE\n");
        cat("length(at) = ", length(at), " not same as nrow(Y) = ", nrow(Y), "\n", sep = "");
        stop();
      }

      if (ncol(Y) != bc$m) {
        cat("ERROR: from BasicCoxDiag.plotSurvivalTimesVsGE\n");
        cat("bc$m = ", bc$m, " not same as ncol(Y) = ", ncol(Y), "\n", sep = "");
        stop();
      }      
      # ......................................................................................              



      
      # .......................................................................................
      # . Generate scatter plots of survival times against principal component values
      # . for up to the first four pcs.
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = 'Survival times against principal components';
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      if (bc$m == 1) {
        par(mfrow = c(1,1));
      } else if (bc$m == 2) {
        par(mfrow = c(1,2));
      } else {
        par(mfrow = c(2,2));        
      }

      if (flagWrite == 'yes') {
        par(mfrow = c(2,2));         # Otherwise written jpeg might look scrunched.
      }

      lmax = min(bc$m, 4);          # Display against up to 4 principal components.
      
      for (l in 1:lmax) {
        betaBuf =  sprintf("%8.3e", bc$abeta[l]);
        pBetaBuf =  sprintf("%8.3e", bc$apBeta[l]);
        gammaBuf =  sprintf("%8.3e", bc$agamma[l]);
        pGammaBuf =  sprintf("%8.3e", bc$apGamma[l]);        
        
        caption = paste("beta = ", betaBuf, ", pBeta = ", pBetaBuf,
                        "gamma = ", gammaBuf, ", pGamma = ", pGammaBuf, sep = "");
        xlab = paste("y_mean_center", l);
        ylab = "Survival time";

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);
        plot(Y[ , l], at, type = 'p', xlab = xlab, ylab = ylab, main = caption);
        abline(v = 0.0);
        par(cex.main = cex.main.OLD);        
      }
    
      par(mfrow = c(1,1));
      # ......................................................................................
      # . Add an over plot (sub) title :
      # ......................................................................................
      par(cex.main = 1.2);         
      title(sub = captionSub);
      par(cex.main = cex.main.OLD);   
      # ......................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................


      # ...........................................
      pInfo = list(afile = afile, aplot = aplot);
      # ...........................................
      
}

# =================================================================================================
# . End of BasicCoxDiag.plotSurvivalTimesVsGE.
# =================================================================================================





# =================================================================================================
# . BasicCoxDiag.writeCoxWithCovBootstrap :  writes to file statistical summary from bootstrap
# . -------------------------------------    resampling.
# .
# .
# . Syntax:
# .
# .     BasicCoxDiag.writeCoxWithCovBootstrap(bs, fs, flagAppend);
# .
# . In :
# .     bs = bootstrap object returned by SuperPcBoot.computeCoxWithCovSignificanceOnSplit(),
# .          resampling of data contained in COXPH or COXCV file.
# .
# .     fs = output file name.
# .
# .     flagAppend = yes/no. If no, create new file, if yes, append to existing file.
# .
# ==================================================================================================

BasicCoxDiag.writeCoxWithCovBootstrap <- function(bs, fs, flagAppend)
{

      # ...........................................................
      if (class(bs) != "spc.cox.cov.boot") {
        msg = "ERROR: from BasicCoxDiag.writeCoxWithCovBootstrap: ";
        msg = paste("The input bs is not of class spc.cox.cov.boot.");
        stop(msg);
      }
      # ...........................................................

      
      # .....................................................................
      cat(" ..........  Entry in BasicCoxDiag.writeCoxWithCovBootstrap.\n");
      # .....................................................................



      # ...............................................................................
      if ((flagAppend != 'yes') && (flagAppend != 'no')) {
        cat("ERROR: from BasicCoxDiag.writeCoxWithCovBootstrap:\n");
        cat("flagAppend = ", flagAppend, " is not valid. Valid: yes, no.\n", sep = "");
        stop(msg);
      }
      # ...............................................................................



      # ...............................................................................
      if (flagAppend == 'no') {
        FS = file(fs, "w");
      } else if (flagAppend == 'yes') {
        FS = file(fs, "a");
      }
      # ...............................................................................




      # ..................................................................................................
      # . Print text here.
      # . Preamble first:
      # ..................................................................................................
      resamplingType = toupper(bs$resamplingType);
      
      cat("#", resamplingType, " RESAMPLING FOR PREDICTIVE ESTIMATES:\n", sep = "", file = FS);
      cat("#nboot = ", bs$nboot, "\n", sep = "", file = FS);
      cat("#rngSeed = ", bs$rngSeed, "\n", sep = "", file = FS);
      cat("#flaghRC = ", bs$flaghRC, "\n", sep = "", file = FS);
      cat("#resamplingType = ", bs$resamplingType, "\n", sep = "", file = FS);      

      if (bs$flaghRC == 'external') {
        cat("#hRCExt = ", bs$hRCExt, " (fixed)\n", sep = "", file = FS);
      }

      cat("\n", file = FS);

      cat("DEFINITION : qRatio = hR(S) / hR(all)\n", sep = "", file = FS);
      cat("\n", file = FS);      
      # ...................................................................................................
      # . Body of text.
      # ...................................................................................................
      cat("#Variable\tvalue\tDescription\n", file = FS);

      cat("hRAll_base\t", sprintf("%8.3e", bs$hRAll_base),
                          "\thR for all patients, actual value\n", sep = "", file = FS);
      cat("hRC_base\t", sprintf("%8.3e", bs$hRC_base),
                          "\thRC, actual value\n", sep = "", file = FS);
      cat("hRMin_base\t", sprintf("%8.3e", bs$hRMin_base),
                          "\thRMin, actual value\n", sep = "", file = FS);
      cat("pRMin_base\t", sprintf("%8.3e", bs$pRMin_base),
                          "\tpRMin, actual value\n", sep = "", file = FS);
      cat("SMin_base\t", sprintf("%8.3e", bs$SMin_base),
                          "\tSMin, actual value\n", sep = "", file = FS);
      cat("qRatio_base\t", sprintf("%8.3e", bs$qRatio_base),
                          "\tRatio hRMin/hRAll, actual value\n", sep = "", file = FS);
      cat("\n", file = FS);
      
      cat("hRAllLo\t", sprintf("%8.3e", bs$hRAllLo), "\tAll patients, 0.025 quantile\n", sep = "", file = FS);
      cat("hRAll\t", sprintf("%8.3e", bs$hRAll), "\tAll patients, median\n", sep = "", file = FS);
      cat("hRAllHi\t", sprintf("%8.3e", bs$hRAllHi), "\tAll patients, 0.975 quantile\n", sep = "", file = FS);
      cat("\n", file = FS);
      
      cat("hRCLo\t", sprintf("%8.3e", bs$hRCLo), "\tThreshold, 0.025 quantile\n", sep = "", file = FS);
      cat("hRC\t", sprintf("%8.3e", bs$hRC), "\tThreshold, median\n", sep = "", file = FS);
      cat("hRCHi\t", sprintf("%8.3e", bs$hRCHi), "\tThreshold, 0.975 quantile\n", sep = "", file = FS);            
      cat("\n", file = FS);
      
      cat("hRMinLo\t", sprintf("%8.3e", bs$hRMinLo), "\thR for sensitive patients, 0.025 quantile\n", sep = "", file = FS);
      cat("hRMin\t", sprintf("%8.3e", bs$hRMin), "\thR for sensitive patients, median\n", sep = "", file = FS);
      cat("hRMinHi\t", sprintf("%8.3e", bs$hRMinHi), "\thR for sensitive patients, 0.975 quantile\n", sep = "", file = FS);
      cat("\n", file = FS);
      
      cat("pRMinLo\t", sprintf("%8.3e", bs$pRMinLo), "\tpR for sensitive patients, 0.025 quantile\n", sep = "", file = FS);
      cat("pRMin\t", sprintf("%8.3e", bs$pRMin), "\tpR for sensitive patients, median\n", sep = "", file = FS);
      cat("pRMinHi\t", sprintf("%8.3e", bs$pRMinHi), "\tpR for sensitive patients, 0.975 quantile\n", sep = "", file = FS);      
      cat("\n", file = FS);
      
      cat("SMinLo\t", sprintf("%8.3e", bs$SMinLo), "\tFraction sensitive patients, 0.025 quantile\n", sep = "", file = FS);
      cat("SMin\t", sprintf("%8.3e", bs$SMin), "\tFraction sensitive patients, median\n", sep = "", file = FS);
      cat("SMinHi\t", sprintf("%8.3e", bs$SMinHi), "\tFraction sensitive patients, 0.975 quantile\n", sep = "", file = FS);      
      cat("\n", file = FS);
      
      cat("qRatioLo\t", sprintf("%8.3e", bs$qRatioLo), "\tRatio hRMin/hRAll, 0.025 quantile\n", sep = "", file = FS);
      cat("qRatio\t", sprintf("%8.3e", bs$qRatio), "\tRatio hRMin/hRAll, median\n", sep = "", file = FS);
      cat("qRatioHi\t", sprintf("%8.3e", bs$qRatioHi), "\tRatio hRMin/hRAll, 0.975 quantile\n", sep = "", file = FS);

      if (bs$resamplingType == 'bootstrap') {
        cat("\n", file = FS);
        cat("npge1\t", bs$npge1, "\tcount of Prob(hRMin/hRAll >= 1), out of nboot\n", sep = "", file = FS);      
        cat("pge1_qRatioLo\t", sprintf("%8.3e", bs$pge1_qRatioLo), "\tProb(hRMin/hRAll >= 1), 0.025 quantile\n",
            sep = "", file = FS);
        cat("pge1_qRatio\t", sprintf("%8.3e", bs$pge1_qRatio), "\tProb(hRMin/hRAll >= 1), median est.\n",
            sep = "", file = FS);
        cat("pge1_qRatioHi\t", sprintf("%8.3e", bs$pge1_qRatioHi), "\tProb(hRMin/hRAll >= 1), 0.975 quantile\n",
            sep = "", file = FS);
      }

      if (bs$resamplingType == 'permutation') {      
        cat("\n", file = FS);
        cat("npval\t", bs$npval, "\tcount of Prob(hRMin/hRAll < (hRMin/hRAll)_base), out of nboot\n",
            sep = "", file = FS);      
        cat("pval_qRatioLo\t", sprintf("%8.3e", bs$pval_qRatioLo), "\tProb(hRMin/hRAll  < (hRMin/hRAll)_base), 0.025 quantile\n",
            sep = "", file = FS);
        cat("pval_qRatio\t", sprintf("%8.3e", bs$pval_qRatio), "\tProb(hRMin/hRAll  < (hRMin/hRAll)_base), median est.\n", sep = "", file = FS);
        cat("pval_qRatioHi\t", sprintf("%8.3e", bs$pval_qRatioHi), "\tProb(hRMin/hRAll  < (hRMin/hRAll)_base), 0.975 quantile\n",
            sep = "", file = FS);
        cat("qRatio_base\t", sprintf("%8.3e", bs$qRatio_base),
            "\tRatio hRMin/hRAll, actual value\n", sep = "", file = FS);
        cat("log(qRatio_base)\t", sprintf("%8.3e", log(bs$qRatio_base)),
            "\tlog(Ratio hRMin/hRAll), actual value\n", sep = "", file = FS);
      }
      # ...................................................................................................



      # ...........
      close (FS);
      # ...........
  
}

# =================================================================================================
# . End of BasicCoxDiag.writeCoxWithCovBootstrap.
# =================================================================================================





# =================================================================================================
# . BasicCoxDiag.writeCoxWithCovPermProg :  writes to file statistical summary from permutation
# . ------------------------------------    resampling of prognostic estimates. This takes as
# .                                         input an object returned by:
# .
# .                                         SuperPcBoot.permuteOnProgIndexALLCov().
# .
# .                                         this function generating results for all patients,
# .                                         Z = 0 patients and Z = 1 patients separately.
# .
# .
# . Syntax:
# .
# .     BasicCoxDiag.writeCoxWithCovPermProg(pgALL, fs, flagAppend);
# .
# . In :
# . 
# .   pgAL = object containing results for permutation resampling of prognostic estimates.
# .          This is the data type returned by the function :
# .
# .                SuperPcBoot.permuteOnProgIndexALLCov()
# .
# .     fs = output file name.
# .
# .     flagAppend = yes/no. If no, create new file, if yes, append to existing file.
# .
# ..................................................................................................
# .
# . * Example :
# .
# .       pgALL = SuperPcBoot.permuteOnProgIndexALLCov(at = at,
# .                                                    as = as,
# .                                                    az = az,
# .                                                    aloghR = aloghR,
# .                                                    nperm = inparam$npermProg,
# .                                                    rngSeed = inparam$rngSeedProg);
# .
# .        BasicCoxDiag.writeCoxWithCovPermProg(pgALL, inparam$fs, flagAppend = 'yes');
# .
# ==================================================================================================

BasicCoxDiag.writeCoxWithCovPermProg <- function(pgALL, fs, flagAppend)
{

      # .............................................................
      if (class(pgALL) != "spc.cox.perm.ALL") {
        cat("ERROR: from BasicCoxDiag.writeCoxWithCovPermProg:\n");
        cat("The input pgALL is not of class spc.cox.perm.ALL\n");
        cat("(this is the data type returned by: SuperPcBoot.permuteOnProgIndexALLCov())\n");
        stop(msg);
      }
      # ..............................................................

      
      # .....................................................................
      cat(" ..........  Entry in BasicCoxDiag.writeCoxWithCovPermProg.\n");
      # .....................................................................



      # ...............................................................................
      if ((flagAppend != 'yes') && (flagAppend != 'no')) {
        cat("ERROR: from BasicCoxDiag.writeCoxWithCovPermProg:\n");
        cat("flagAppend = ", flagAppend, " is not valid. Valid: yes, no.\n", sep = "");
        stop(msg);
      }
      # ...............................................................................



      # ...............................................................................
      if (flagAppend == 'no') {
        FS = file(fs, "w");
      } else if (flagAppend == 'yes') {
        FS = file(fs, "a");
      }
      # ...............................................................................




      # ..................................................................................................
      # . Print text here.
      # . Preamble and header first:
      # ..................................................................................................
      cat("#PERMUTATION RESAMPLING FOR PROGNOSTIC ESTIMATES:\n", sep = "", file = FS);
      cat("#nperm = ", pgALL$nperm, "\n", sep = "", file = FS);
      cat("#rngSeed = ", pgALL$rngSeed, "\n", sep = "", file = FS);

      cat("\n", file = FS);
      cat("#Case\tVariable\tvalue\tDescription\n", file = FS);      
      # ...................................................................................................
      # . Body of text.
      # . >>All patients :
      # ...................................................................................................
      txt =  BasicCoxDiag.formatResultsPermProg(pg = pgALL$pgAll,
                                                commonCaption = "ALL patients",
                                                flagHeader = 'no');
      cat(txt, file = FS);
      cat("\n", file = FS);
      # ...................................................................................................      
      # . >>Z = 0 patients :
      # ...................................................................................................
      txt =  BasicCoxDiag.formatResultsPermProg(pg = pgALL$pg0,
                                                commonCaption = "Z = 0 patients",
                                                flagHeader = 'no');
      cat(txt, file = FS);
      cat("\n", file = FS);
      # ...................................................................................................      
      # . >>Z = 1 patients :
      # ...................................................................................................
      txt =  BasicCoxDiag.formatResultsPermProg(pg = pgALL$pg1,
                                                commonCaption = "Z = 1 patients",
                                                flagHeader = 'no');
      cat(txt, file = FS);
      cat("\n", file = FS);
      # ...................................................................................................


      # ...................................................................................................
      if (flagAppend == 'no') {
        cat(" ..........  Wrote prognostic information to file: ", fs, "\n", sep = '');
      } else {
        cat(" ..........  Appended prognostic information to file: ", fs, "\n", sep = '');        
      }
      # ...................................................................................................      



      # ...........
      close (FS);
      # ...........
  
}

# =================================================================================================
# . End of BasicCoxDiag.writeCoxWithCovPermProg.
# =================================================================================================






# =================================================================================================
# . BasicCoxDiag.formatResultsPermProg :  formats results from permutation
# . ----------------------------------    resampling of prognostic estimates. This takes as
# .                                       input an object returned by:
# .
# .                                         SuperPcBoot.permuteOnProgIndex().
# .
# .
# . Syntax:
# .
# .     txtSummary =  BasicCoxDiag.formatResultsPermProg(pg, commonCaption, flagHeader);
# .
# . In :
# . 
# .     pg = object containing results for permutation resampling of prognostic estimates.
# .          This is the data type returned by the function :
# .
# .                SuperPcBoot.permuteOnProgIndex()
# .
# .     commonCaption = common caption for the first field in each record to be generated.
# .
# .     flagHeader = yes/no. If yes, prefix output with a header.
# .
# . Out:
# .
# .     txtSummary = formated text.
# .
# ==================================================================================================

BasicCoxDiag.formatResultsPermProg <- function(pg, commonCaption, flagHeader)
{

      # ...............................................................................
      if (class(pg) != "spc.cox.perm") {
        cat("ERROR: from BasicCoxDiag.formatResultsPermProg:\n");
        cat("The input pgALL is not of class spc.cox.perm\n");
        cat("(this is the data type returned by: SuperPcBoot.permuteOnProgIndex())\n");
        stop(msg);
      }
      # ................................................................................



      # ...............................................................................
      if ((flagHeader != 'yes') && (flagHeader != 'no')) {
        cat("ERROR: from BasicCoxDiag.writeCoxWithCovPermProg:\n");
        cat("flagHeader = ", flagHeader, " is not valid. Valid: yes, no.\n", sep = "");
        stop();
      }
      # ...............................................................................


      
      # .....................................
      txt = "";          # Initialize.
      # .....................................




      # ..................................................................................................
      # . Generate text here.
      # .
      # . Preamble and header first if specified :
      # ..................................................................................................
      if (flagHeader == 'yes') {
        txt = paste(txt, "#PERMUTATION RESAMPLING FOR PROGNOSTIC ESTIMATE:\n", sep = '');
        txt = paste(txt, "#n = ", pg$n, "\n", sep = "");        
        txt = paste(txt, "#rngSeed = ", pg$rngSeed, "\n", sep = "");
        txt = paste(txt, "\n", sep = "");

        txt = paste(txt, "#Case\tvariable\tvalue\tdescription\n", sep = "");
      }
      # ...................................................................................................
      # . Body of text here :
      # ...................................................................................................
      txt = paste(txt, commonCaption, "\t",
                  "n\t",
                  pg$n,
                  "\tNumber of patients\n",
                  sep = "");
      
      txt = paste(txt, commonCaption, "\t",
                  "nperm\t",
                  pg$nperm,
                  "\tNumber of permutations\n",
                  sep = "");
      
      txt = paste(txt, commonCaption, "\t",
                  "npval\t",
                  pg$npval,
                  "\tNumber of times loglik* > loglik_base\n",
                  sep = "");

      txt = paste(txt, commonCaption, "\t",
                  "pval_loglikLo\t",
                  sprintf("%8.3e", pg$pval_loglikLo),
                  "\t0.025 lower bound on P-value\n",
                  sep = "");

      txt = paste(txt, commonCaption, "\t",
                  "pval_loglik\t",
                  sprintf("%8.3e", pg$pval_loglik),
                  "\tMedian estimate for P-value\n",
                  sep = "");

      txt = paste(txt, commonCaption, "\t",
                  "pval_loglikHi\t",
                  sprintf("%8.3e", pg$pval_loglikHi),
                  "\t0.975 upper bound on P-value\n",
                  sep = "");

      txt = paste(txt, commonCaption, "\t",
                  "pval_tertile\t",
                  sprintf("%8.3e", pg$pval_tertile),
                  "\tPoor man\'s p-value, based on upper vs lower tertile comparison.\n",
                  sep = "");

      txt = paste(txt, commonCaption, "\t",
                  "hR_tertile\t",
                  sprintf("%8.3e", pg$hR_tertile),
                  "\tPoor man\'s hazard ratio, based on upper vs lower tertile comparison.\n",
                  sep = "");
      
      txt = paste(txt, commonCaption, "\t",
                  "beta_calib\t",
                  sprintf("%8.3e", pg$beta_calib),
                  "\tBeta for recalibrated univariate Cox model on loghR\n",
                  sep = "");
      
      txt = paste(txt, commonCaption, "\t",
                  "seBeta_calib\t",
                  sprintf("%8.3e", pg$seBeta_calib),
                  "\tse(beta) for recalibrated univariate Cox model on loghR\n",
                  sep = "");
      
      txt = paste(txt, commonCaption, "\t",
                  "pval_calib\t",
                  sprintf("%8.3e",pg$pval_calib),
                  "\tP-value for recalibrated univariate Cox model on loghR\n",
                  sep = "");      
      # ...................................................................................................



      # .............
      return (txt);
      # .............
  
}

# =================================================================================================
# . End of BasicCoxDiag.formatResultsPermProg.
# =================================================================================================
      




# ====================================================================================================
# . BasicCoxDiag.addResponseGroup : for a data frame read from a COXPH file, adds a column indicating 
# . -----------------------------   sensitive/resistant category in accordance with the given threshold.
# .                                 
# .
# . Syntax:
# .
# .     dfXRes =  BasicCoxDiag.addResponseGroup(dfX, hRCExt);
# .
# . In:
# .     dfX = input data frame. Must have columns loghR_z0, loghR_z1.
# .
# . Out:
# .     dfXRes = output data frame, given by input data frame augmented by a 
# .              column denoted by name "responseGroup_hRCExtxxx" where xxx = character
# .              representation of hRCExt, and with sensitivity category coded as:
# .
# .                            R = 0
# .                            S = 1
# .
# ====================================================================================================

BasicCoxDiag.addResponseGroup <- function(dfX, hRCExt)
{

       # ...........................................................................
       stopifnot(hRCExt > 0.0);

       if (is.null(dfX$loghR_z0)) {
         cat("ERROR: from BasicCoxDiag.BasicCoxDiag.addResponseGroup:\n");
         cat("Input data frame dfX does not have a column = loghR_z0.\n");
         cat("Perhaps not read from a COXPH file?\n");
         stop();
       }

       if (is.null(dfX$loghR_z1)) {
         cat("ERROR: from BasicCoxDiag.BasicCoxDiag.addResponseGroup:\n");
         cat("Input data frame dfX does not have a column = loghR_z1.\n");
         cat("Perhaps not read from a COXPH file?\n");
         stop();
       }

       ac = colnames(dfX);

       if (ac[1] != 'X.QUAL') {
         cat("ERROR: from BasicCoxDiag.BasicCoxDiag.addResponseGroup:\n");
         cat("First column name for dfX is not: X.QUAL\n");
         cat("Perhaps not read from a COXPH file?\n");
         stop();
       }
       # ...........................................................................



       # ...........................................................................
       # . Generate the sensitive/resistant assignments :
       # ...........................................................................
       loghRCExt = log(hRCExt);
       
       aDloghR = dfX$loghR_z1 - dfX$loghR_z0;
       ar = ifelse(aDloghR <= loghRCExt, 1, 0);     # category : S = 1, R = 0.

       dfXRes = data.frame(dfX, responseGroup = ar);
       # ............................................................................
       # . Adjust column names :
       # .
       # . QUAL column name, response group:
       # ............................................................................       
       ac = colnames(dfXRes);

       ac[1] = "#QUAL";  
         
       temp1 = paste("responseGroup_hRCExt", sprintf("%5.5f", hRCExt), sep = "");
       temp2 = sub("\\.", "_", temp1);

       nc = length(ac);
       ac[nc] = temp2;

       colnames(dfXRes) = ac;        # Final assignment.
       # ............................................................................


       # ................
       return (dfXRes);
       # ................

}

# ====================================================================================================
# . End of BasicCoxDiag.addResponseGroup.
# ====================================================================================================








# ==========================================================================================================================
# . BasicCoxDiag.writeCoxWithCovBootFULL :  writes to file statistical summary from bootstrap.
# . ------------------------------------    This is a somewhat different version of    
# .                                         BasicCoxDiag.writeCoxWithCovBootstrap()
# .
# .   BasicCoxDiag.writeCoxWithCovBootstrap() : uses output from resampling of DloghR values,
# .                                             without rebuilding models on the training set.
# .
# .   BasicCoxDiag.writeCoxWithCovBootFULL()  : uses the output from a full resampling of the
# .                                             training set itself.
# .
# . Syntax:
# .
# .       BasicCoxDiag.writeCoxWithCovBootFULL(rs, fs);
# .
# . In :
# .
# .     rs = resampling summary object returned by :
# .          rs = SuperPcBoot.extractResampledCoxWithCovStats(cvBoot);
# .          where cvBoot is generated by
# .          cvBoot = GlmnetCv.crossValidateCoxWithCovBoot();
# .
# .     fs = output file name.
# .
# .
# ==========================================================================================================================

BasicCoxDiag.writeCoxWithCovBootFULL <- function(rs, fs)
{

      # ...............................................................................
      if (class(rs) != "cox.cov.boot.extract") {
        cat("ERROR: from BasicCoxDiag.writeCoxWithCovBootFULL:\n");
        cat("The input rs is not of class cox.cov.boot.extract\n");
        cat("as returned by function SuperPcBoot.extractResampledCoxWithCovStats().\n");
        stop(msg);
      }
      # ................................................................................


      
      # .....................................................................
      cat(" ..........  Entry in BasicCoxDiag.writeCoxWithCovBootFULL.\n");
      # .....................................................................



      # ....................
      FS = file(fs, "w");
      # ....................



      # ..................................................................................................
      # . >> PREAMBLE :
      # ..................................................................................................
      cat("#-------------------------------------------------------------------------------------------------------------\n",  sep = "", file = FS);      
      cat("#Resampling type :", rs$bootType, "\n", sep = "", file = FS);

      if (rs$bootType == 'fullBoot') {
        cat("#Full bootstrap: resample training set with replacement.\n", sep = "", file = FS);
      } else if (rs$bootType == 'splitOnly') {
        cat("#Resample splits only : resample only on cross-validation folds, not on input training set.\n", sep = "", file = FS);
      } else if (rs$bootType == 'permutation') {
        cat("#Permutation : permute gene expression relative to (t, s, z).\n", sep = "", file = FS);
      }
      
      cat("#nboot = ", rs$nboot, "\n", sep = "", file = FS);
      cat("#rngSeed = ", rs$rngSeed, "\n", sep = "", file = FS);
      cat("#hRC = ", rs$hRC, "\n", sep = "", file = FS);
      cat("#Estimates below include:\n", file = FS);
      cat("# i)Bayes estimation of probabilities based on raw numeric counts\n", sep = "", file = FS);
      cat("# ii) Analytic estimates of probabilities based on Gaussian approximations for the distributions.\n", sep = "", file = FS);
      cat("#-------------------------------------------------------------------------------------------------------------\n",  sep = "", file = FS);            

      cat("\n", file = FS);
      # ...................................................................................................


      
      
      # ...................................................................................................
      # . >> BODY :
      # ...................................................................................................
      cat("#------------------------------------------------------------------------------------------\n",  sep = "", file = FS);
      cat("#VARIABLE\tVALUE\tDESCRIPTION\n", file = FS);
      cat("# ...........................................................................................\n", file = FS);
      cat("# . Values for the actual, non-resampled data set :                                          \n", file = FS);
      cat("# ...........................................................................................\n", file = FS);

      cat("hRC_obs\t", sprintf("%8.3e", rs$hRC_obs),                 "\thRC.\n", sep = "", file = FS);      
      cat("hR_all_obs\t", sprintf("%8.3e", rs$hR_all_obs),           "\thR(all).\n", sep = "", file = FS);
      cat("hR_S_obs\t", sprintf("%8.3e", rs$hR_S_obs),               "\thR(S).\n", sep = "", file = FS);
      cat("hR_R_obs\t", sprintf("%8.3e", rs$hR_R_obs),               "\thR(R).\n", sep = "", file = FS);
      cat("ratio_hR_S_to_R_obs\t",
                        sprintf("%8.3e", rs$ratio_hR_S_to_R_obs),    "\thR(S) / hR(R).\n", sep = "", file = FS);
      cat("abc_obs\t", sprintf("%8.3e", rs$abc_obs),                 "\tabc = AUC(R) - AUC(S).\n", sep = "", file = FS);
      cat("nS_obs\t", rs$nS_obs,                                     "\tNumber of sensitives.\n", sep = "", file = FS);
      cat("nR_obs\t", rs$nR_obs,                                     "\tNumber of resistants.\n", sep = "", file = FS);            

      cat("# ............................................................................................\n", file = FS);
      cat("# . Normality tests :                                                           \n", file = FS);
      cat("# ............................................................................................\n", file = FS);
      cat("pval_NORMAL_Logratio_hR_S_to_R\t", sprintf("%8.3e", rs$pval_NORMAL_Logratio_hR_S_to_R),
                                                                   "\tNormality test on hR(S)/hR(R) distribution.\n", sep = "", file = FS);
      cat("pval_NORMAL_abc\t", sprintf("%8.3e", rs$pval_NORMAL_abc),
                                                                   "\tNormality test ob abc distribution.\n", sep = "", file = FS);
      cat("# ............................................................................................\n", file = FS);
      cat("# . Summary statistics : hRC.                                                                 \n", file = FS);
      cat("# ............................................................................................\n", file = FS);
      cat("hRCLo\t", sprintf("%8.3e",  rs$hRCLo),         "\t2.5% bound on threshold.\n", sep = "", file = FS);
      cat("hRCMed\t", sprintf("%8.3e", rs$hRCMed),        "\tMedian threshold.\n", sep = "", file = FS);
      cat("hRCHi\t", sprintf("%8.3e",  rs$hRCHi),         "\t97.5% bound on threshold (Bayes).\n", sep = "", file = FS);
      cat("\n", file = FS);      
      cat("# ............................................................................................\n", file = FS);
      cat("# . Summary statistics : hR(all).                                                             \n", file = FS);
      cat("# ............................................................................................\n", file = FS);
      cat("hR_allLo\t", sprintf("%8.3e",  rs$hR_allLo),   "\t2.5% bound on hazard ratios for all samples,\n", sep = "", file = FS);
      cat("hR_all\t", sprintf("%8.3e",    rs$hR_all),     "\tMedian hhR(all).\n", sep = "", file = FS);
      cat("hR_allHi\t", sprintf("%8.3e",  rs$hR_allHi),   "\t97.5% bound on hR(all) (Bayes).\n", sep = "", file = FS);
      cat("\n", file = FS);
      cat("# ............................................................................................\n", file = FS);
      cat("# . Summary statistics : hR(S).                                                               \n", file = FS);
      cat("# ............................................................................................\n", file = FS);
      cat("hR_SLo\t", sprintf("%8.3e",    rs$hR_SLo),                   "\tHazard ratios for sensitive samples,\n", sep = "", file = FS);
      cat("hR_S\t", sprintf("%8.3e",      rs$hR_S),                     "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
      cat("hR_SHi\t", sprintf("%8.3e",    rs$hR_SHi), "\t\n", sep = "", file = FS);
      cat("\n", file = FS);

      if ((rs$bootType == 'fullBoot') || (rs$bootType == 'splitOnly')) {
        cat("nconf_hR_S\t", rs$nconf_hR_S,                                "\tcount(hR(S)* < hR(all)*),\n", sep = "", file = FS);        
        cat("pconf_hR_SLo\t", sprintf("%8.3e",         rs$pconf_hR_SLo),  "\tProb(hR(S) < hR(all)*),\n", sep = "", file = FS);
        cat("pconf_hR_S\t", sprintf("%8.3e",           rs$pconf_hR_S),    "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
        cat("pconf_hR_SHi\t", sprintf("%8.3e",         rs$pconf_hR_SHi),  "\t\n", sep = "", file = FS);
        cat("pconf_hR_S_ANALYTIC\t", sprintf("%8.3e",  rs$pconf_hR_S_ANALYTIC),  "\tAnalytic model estimate (Gaussian approx).\n", sep = "", file = FS);
      }

      if (rs$bootType == 'permutation') {
        cat("npval_hR_S\t",  rs$npval_hR_S,                               "\tcount(hR(S)* < hR(S)_obs),\n", sep = "", file = FS);        
        cat("pval_hR_SLo\t", sprintf("%8.3e",          rs$pval_hR_SLo),   "\tProb(hR(S)* < hR(S)_obs),\n", sep = "", file = FS);
        cat("pval_hR_S\t", sprintf("%8.3e",            rs$pval_hR_S),     "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
        cat("pval_hR_SHi\t", sprintf("%8.3e",          rs$pval_hR_SHi),   "\t\n", sep = "", file = FS);
        cat("pval_hR_S_ANALYTIC\t", sprintf("%8.3e",   rs$pval_hR_S_ANALYTIC),   "\tAnalytic model estimate (Gaussian approx).\n", sep = "", file = FS);
      }      
      cat("# ............................................................................................\n", file = FS);
      cat("# . Summary statistics : hR(R).                                                               \n", file = FS);
      cat("# ............................................................................................\n", file = FS);      
      cat("hR_RLo\t", sprintf("%8.3e",    rs$hR_RLo),                "\tHazard ratios for resistant samples,\n", sep = "", file = FS);
      cat("hR_R\t", sprintf("%8.3e",      rs$hR_R),                  "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
      cat("hR_RHi\t", sprintf("%8.3e",    rs$hR_RHi), "\t\n", sep = "", file = FS);
      cat("# ............................................................................................\n", file = FS);
      cat("# . Summary statistics : hR(S) / hR(R).                                                       \n", file = FS);
      cat("# ............................................................................................\n", file = FS);
      cat("ratio_hR_S_to_RLo\t", sprintf("%8.3e",    rs$ratio_hR_S_to_RLo),  "\thR(S) / hR(R) statistics,\n", sep = "", file = FS);
      cat("ratio_hR_S_to_R\t", sprintf("%8.3e",      rs$ratio_hR_S_to_R),   "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
      cat("ratio_hR_S_to_RHi\t", sprintf("%8.3e",    rs$ratio_hR_S_to_RHi),  "\t\n", sep = "", file = FS);
      cat("\n", file = FS);

      if ((rs$bootType == 'fullBoot') || (rs$bootType == 'splitOnly')) {
        cat("nconf_ratio_hR_S_to_R\t", rs$nconf_ratio_hR_S_to_R,                                "\tcount(ratio < 1),\n", sep = "", file = FS);        
        cat("pconf_ratio_hR_S_to_RLo\t", sprintf("%8.3e",         rs$pconf_ratio_hR_S_to_RLo),  "\tProb(ratio < 1),\n", sep = "", file = FS);
        cat("pconf_ratio_hR_S_to_R\t", sprintf("%8.3e",           rs$pconf_ratio_hR_S_to_R),    "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
        cat("pconf_ratio_hR_S_to_RHi\t", sprintf("%8.3e",         rs$pconf_ratio_hR_S_to_RHi),  "\t\n", sep = "", file = FS);
        cat("pconf_ratio_hR_S_to_R_ANALYTIC\t", sprintf("%8.3e",  rs$pconf_ratio_hR_S_to_R_ANALYTIC),  "\tAnalytic model estimate (Gaussian approx).\n", sep = "", file = FS);
      }

      if (rs$bootType == 'permutation') {
        cat("npval_ratio_hR_S_to_R\t",  rs$npval_ratio_hR_S_to_R,                               "\tcount(ratio* < ratio_obs),\n", sep = "", file = FS);        
        cat("pval_ratio_hR_S_to_RLo\t", sprintf("%8.3e",          rs$pval_ratio_hR_S_to_RLo),   "\tProb(ratio* < ratio_obs),\n", sep = "", file = FS);
        cat("pval_ratio_hR_S_to_R\t", sprintf("%8.3e",            rs$pval_ratio_hR_S_to_R),     "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
        cat("pval_ratio_hR_S_to_RHi\t", sprintf("%8.3e",          rs$pval_ratio_hR_S_to_RHi),   "\t\n", sep = "", file = FS);
        cat("pval_ratio_hR_S_to_R_ANALYTIC\t", sprintf("%8.3e",   rs$pval_ratio_hR_S_to_R_ANALYTIC),   "\tAnalytic model estimate (Gaussian approx).\n", sep = "", file = FS);
      }
      cat("# ............................................................................................\n", file = FS);
      cat("# . Summary statistics : area between curves.                                                 \n", file = FS);
      cat("# ............................................................................................\n", file = FS);
      cat("abcLo\t", sprintf("%8.3e",    rs$abcLo),     "\tArea between curves statistics,\n", sep = "", file = FS);
      cat("abc\t", sprintf("%8.3e",      rs$abc),       "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
      cat("abcHi\t", sprintf("%8.3e",    rs$abcHi),     "\t\n", sep = "", file = FS);                  
      cat("\n", file = FS);

      if ((rs$bootType == 'fullBoot') || (rs$bootType == 'splitOnly')) {
        cat("nconf_abc\t", rs$nconf_abc,                                         "\tcount(abc > 0).\n", sep = "", file = FS);        
        cat("pconf_abcLo\t", sprintf("%8.3e",           rs$pconf_abcLo),         "\tProb(abc > 0).\n", sep = "", file = FS);
        cat("pconf_abc\t", sprintf("%8.3e",             rs$pconf_abc),           "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
        cat("pconf_abcHi\t", sprintf("%8.3e",           rs$pconf_abcHi),         "\t\n", sep = "", file = FS);
        cat("pconf_abc_ANALYTIC\t", sprintf("%8.3e",    rs$pconf_abc_ANALYTIC),  "\tAnalytic model estimate (Gaussian approx).\n", sep = "", file = FS);
      }

      if (rs$bootType == 'permutation') {
        cat("npval_abc\t", rs$npval_abc,                                         "\tcount(abc* > abc_obs),\n", sep = "", file = FS);
        cat("pval_abcLo\t", sprintf("%8.3e",            rs$pval_abcLo),          "\tProb(abc* > abc_obs),\n", sep = "", file = FS);
        cat("pval_abc\t", sprintf("%8.3e",              rs$pval_abc),            "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
        cat("pval_abcHi\t", sprintf("%8.3e",            rs$pval_abcHi),          "\t\n", sep = "", file = FS);
        cat("pval_abc_ANALYTIC\t", sprintf("%8.3e",   rs$pval_abc_ANALYTIC), "\tAnalytic model estimate (Gaussian approx).\n", sep = "", file = FS);
      }

      cat("# ............................................................................................\n", file = FS);
      cat("# . Summary statistics : number of sensitives and resistants.                                 \n", file = FS);
      cat("# ............................................................................................\n", file = FS);

      cat("nSLo\t", sprintf("%8.3e",    rs$nSLo),     "\tNumber of sensitives,\n", sep = "", file = FS);
      cat("nS\t", sprintf("%8.3e",      rs$nS),       "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
      cat("nSHi\t", sprintf("%8.3e",    rs$nSHi),     "\t\n", sep = "", file = FS);                  
      cat("\n", file = FS);

      cat("nRLo\t", sprintf("%8.3e",    rs$nRLo),     "\tNumber of resistants,\n", sep = "", file = FS);
      cat("nR\t", sprintf("%8.3e",      rs$nR),       "\twith 95% confidence interval (Bayes).\n", sep = "", file = FS);
      cat("nRHi\t", sprintf("%8.3e",    rs$nRHi),     "\t\n", sep = "", file = FS);                  
      cat("\n", file = FS);

      cat("# ............................................................................................\n", file = FS);
      # ...................................................................................................

      
      # .......................................................................................
      cat(" ..........  Wrote resampling summary statistics to file : ", fs, "\n", sep = "");
      # .......................................................................................



      # ...........
      close (FS);
      # ...........


      # .............
      return (0);
      # .............      
  
}

# ==========================================================================================================================
# . End of BasicCoxDiag.writeCoxWithCovBootFULL.
# ==========================================================================================================================






# ==========================================================================================================================
# . BasicCoxDiag.writeCoxWithCovBootSERIES :  writes to file resample-by-resample bootstarp results.
# . --------------------------------------    
# .                                           Note that :      
# .
# .   BasicCoxDiag.writeCoxWithCovBootstrap() : uses output from resampling of DloghR values,
# .                                             without rebuilding models on the training set.
# .
# .   BasicCoxDiag.writeCoxWithCovBootSERIES()  : uses the output from a full resampling of the
# .                                             training set itself.
# .
# . Syntax:
# .
# .       BasicCoxDiag.writeCoxWithCovBootSERIES(rs, fo);
# .
# . In :
# .
# .     rs = resampling summary object returned by :
# .          rs = SuperPcBoot.extractResampledCoxWithCovStats(cvBoot);
# .          where cvBoot is generated by
# .          cvBoot = GlmnetCv.crossValidateCoxWithCovBoot();
# .
# .     fo = output file name.
# .
# .
# ==========================================================================================================================

BasicCoxDiag.writeCoxWithCovBootSERIES <- function(rs, fo)
{

      # ...............................................................................
      if (class(rs) != "cox.cov.boot.extract") {
        cat("ERROR: from BasicCoxDiag.writeCoxWithCovBootSERIES:\n");
        cat("The input rs is not of class cox.cov.boot.extract\n");
        cat("as returned by function SuperPcBoot.extractResampledCoxWithCovStats().\n");
        stop(msg);
      }
      # ................................................................................


      
      # .....................................................................
      cat(" ..........  Entry in BasicCoxDiag.writeCoxWithCovBootSERIES.\n");
      # .....................................................................



      # ....................
      FO = file(fo, "w");
      # ....................

      
      # ...................................................................................................
      # . Write text here :
      # ...................................................................................................      
      cat("#QUAL", "\t",
           "hRC", "\t",          
           "hR_all", "\t",
           "hR_S", "\t",
           "hR_R", "\t",
           "ratio_hR_S_to_R", "\t",
           "abc", "\t",
           "nS", "\t",
           "nR", "\t",
           "n", "\t",
           "fS", "\t",
           "fR",
           "\n", sep = "", file = FO);      

      for (l in 1:rs$nboot) {
        fS = rs$anS[l] / rs$n;         # Fraction sensitive.
        fR = rs$anR[l] / rs$n;         # Fraction resistant.
        
        cat(l, "\t",
            sprintf("%8.3e", rs$ahRC[l]), "\t",            
            sprintf("%8.3e", rs$ahR_all[l]), "\t",
            sprintf("%8.3e", rs$ahR_S[l]), "\t",
            sprintf("%8.3e", rs$ahR_R[l]), "\t",
            sprintf("%8.3e", rs$aratio_hR_S_to_R[l]), "\t",
            sprintf("%8.3e", rs$aAbc[l]), "\t",
            rs$anS[l], "\t",
            rs$anR[l], "\t",
            rs$n, "\t",
            sprintf("%8.3e", fS), "\t",
            sprintf("%8.3e", fR),            
            "\n", sep = "", file = FO);
      }
      # ...................................................................................................            

      
      # ...........
      close (FO);
      # ...........


      # .......................................................................................
      cat(" ..........  Wrote resampling series data to file : ", fo, "\n", sep = "");
      # .......................................................................................
      

      # .............
      return (0);
      # .............      
  
}

# ==========================================================================================================================
# . End of BasicCoxDiag.writeCoxWithCovBootSERIES.
# ==========================================================================================================================








# ===============================================================================================================
# . BasicCoxDiag.plotCoxWithCovOnSubtypes : generates a sequence of KM plots, given a series of intrinsic
# . -------------------------------------   subtype assignments (or other categorical divisions), alongside time, 
# .                                         censoring status and treatment arm. Each KM plot contains two curves, 
# .                                         one for the Z = 0 and the other for the Z = 1 treatment arm.
# .
# .   Syntax:
# .
# .       dfR = BasicCoxDiag.plotCoxWithCovOnSubtypes(at, as, az, ac, captionStem = '');
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : binary vector for treatment arm (Z = 0, 1).
# .
# .            ac = n : character vector, gives subtype membership.
# .
# .   captionStem = stem for captions.
# .
# =================================================================================================================

BasicCoxDiag.plotCoxWithCovOnSubtypes <- function(at, as, az, ac, captionStem = '')
{

      # ......................................................................
      cat(" ..........  Entry in BasicCoxDiag.plotCoxWithCovOnSubtypes.\n");
      # ......................................................................


      # ......................................................................
      # . Check on lengths :
      # ......................................................................      
      n = length(at);
      ac = as.character(ac);

      stopifnot(length(as) == n);
      stopifnot(length(az) == n);
      stopifnot(length(ac) == n);
      # ......................................................................


      # ......................................................................
      # . Get distinct subtypes :
      # ......................................................................          
      acU = sort(unique(ac));
      K = length(acU);

      cat(" ..........  I found ", K, " distinct subtypes.\n", sep = "");
      # ......................................................................      

      

      # ...............................................................................................................      
      buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
      if (buf == 'q') {
        stop();
      }
      # ...............................................................................................................      


      
      # ...............................................................................................................
      # . >> 1. Plot systematically subtype-by-subtype :
      # . Kludge to determine number of rows and columns in plot page :
      # ...............................................................................................................
      nbuf = sqrt(K);
      nrPlot = max(floor(nbuf), 1);
      ncPlot = ceiling(nbuf);

      ntemp = nrPlot * ncPlot;

      if (ntemp < K) {
        nrPlot = nrPlot + 1;
      }

      par(mfrow = c(nrPlot, ncPlot));
      # ...............................................................................................................
      # . Plots here :
      # ...............................................................................................................
      for (k in 1:K) {
        classSubtype = acU[k];
        mask = (ac == classSubtype);

        atBuf  = at[mask];
        asBuf = as[mask];
        azBuf = az[mask];
        acBuf = ac[mask];
        # ....................................................................................................
        # . Compute the hR and pR for this subtype :
        # ....................................................................................................
        cs = Cox.computeBinaryCox(at = atBuf, as = asBuf, abin = azBuf);

        if (k == 1) {
          dfR = matrix(unlist(cs), nrow = 1);
          colnames(dfR) = names(cs);
        } else {
          dfR = rbind(dfR, cs);
        }

        rownames(dfR)[k] = classSubtype;
	# ....................................................................................................
	# . Plot for this subtype :
	# ....................................................................................................
        if (nchar(captionStem) > 0) {
          temp = paste(captionStem, " : ", sep = "");
        }
        caption = paste(temp, "subtype = ", classSubtype, " ", sep = "");
        
        SuperPcDiag.plotSurvivalOnBinary(at = atBuf, as = asBuf, abin = azBuf,,
                                         legend_0 = 'Z = 0', legend_1 = "Z = 1", 
                                         caption = caption);
        # ....................................................................................................
      }
      par(mfrow = c(1, 1));
      # ...............................................................................................................


      
      # ...............................................................................................................      
      buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
      if (buf == 'q') {
        stop();
      }
      # ...............................................................................................................            


      # ...............................................................................................................
      # . >> 2. Barplot summaries of hRs and P-values :
      # ...............................................................................................................
      csAll = Cox.computeBinaryCox(at = at, as = as, abin = az);
      hRAll = csAll$hR;

      ymin = 0.0;
      ymax = min(1.5, max(as.numeric(dfR[ , "hRHi"])));


      if (nchar(captionStem) > 0) {
        temp = paste(captionStem, " : ", sep = "");
      }
      caption = paste(temp, " subtype dependence, K = ", K, sep = "");
      
      buf = Stat.barplotWithErrorBarsAndTopLabels(ay = as.numeric(dfR[ , "hR"]),
                                                  flagErrbar = TRUE,
                                                  aylo = as.numeric(dfR[ , "hRLo"]),
                                                  ayhi = as.numeric(dfR[ , "hRHi"]),
                                                  alabBot = rownames(dfR),
                                                  alabTop = as.numeric(dfR[ , "n"]),
                                                  ylab = "hR : Z = 1 / Z = 0",
                                                  caption = caption,
                                                  flagLogScale = FALSE,
                                                  flagYlim = TRUE,
                                                  ylimIn = c(ymin, ymax));

      abline(h = hRAll, lty = 'dashed');
      abline(h = 1.0, col = 'gray');
      # ...............................................................................................................
      

      # ...............
      return (dfR);
      # ...............

}

# ===============================================================================================================
# . End of BasicCoxDiag.plotCoxWithCovOnSubtypes.
# ===============================================================================================================

