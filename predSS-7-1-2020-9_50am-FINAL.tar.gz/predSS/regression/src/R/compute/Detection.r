# ======================================================================================
# . Detection.r : simple-minded models for detecttion sensitivity.
# . --------   12-19-2007
# ======================================================================================

# ======================================================================================
# . Detection.fOverlap : estimation of overlap in two successive detection exercises.
# . ------------------
# .
# . Syntax :
# .
# .      fOverlap = Detection.fOverlap(beta, alpha, xc);
# .
# . In:
# .      beta = parameter for assumed exponential distribution of u = log(R).
# .     alpha = coefficient of variation in mesurement of u.
# .        xc = cutoff in x for detection (is detected if x >= xc).
# .
# . Out:
# .
# . Estimate of :
# .
# .                          N_int
# .            fOverlap =  ----------
# .                          N_found
# .
# . where N_int is the number of genes overlapping in two lists, and N_found the average
# . of the number of genes found in each of the two lists.
# .
# ======================================================================================

Detection.fOverlap <- function(beta, alpha, xc)
{

    # .....................................................................
    lambda = 2.0 * alpha * beta;
    lambda2 = lambda^2;

    fac1 = exp(- 0.5 * lambda * xc);
    fac2 = exp( 0.5 * lambda);

    facL = exp(- lambda);
    
    tempTop = (2.0 - (2.0 + 2.0 * lambda + lambda2) * facL) / lambda2;
    tempBot = (1.0 - (1.0 + lambda) * facL) / lambda;

    top = fac1 + fac2 * tempTop;
    bot = fac1 + fac2 * tempBot;

    fOverlap = top / bot;
    # .....................................................................  


    # .................
    return (fOverlap);
    # .................
  
}

# ======================================================================================
# . End of Detection.fOverlap.
# ======================================================================================
