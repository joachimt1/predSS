# =================================================================================================
# . GlmnetDiag.r : diagnostc functions for regression models using the glmnet functions.
# . ------------   
# .
# =================================================================================================


GlmnetDiag.MSELMAX = 1000;      # Maximum number of genes to be displayed in a heat map.


# =================================================================================================
# . GlmnetDiag.writeCoxSummaryWithCov : writes to file a summary of results from feature-selection
# . ---------------------------------   + coxnet calculation.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .        GlmnetDiag.writeCoxSummaryWithCov(gl, dsTrain, dsTest, fs);
# .
# .   In:
# .        gl = result of supervised principal components computation, returned
# .              by function Glmnet.computeCoxWithCov().
# .    dsTrain = as returned by Glmnet.computeSignificanceOnCov() on training set.
# .     dsTest = as returned by Glmnet.computeSignificanceOnCov() on test set (if any),
# .              else NULL.
# .         fs = name of output file.
# .
# =================================================================================================

GlmnetDiag.writeCoxSummaryWithCov <- function(gl, dsTrain, dsTest, fs)
{

      # ...........................................................
      if (class(gl) != "glmnet.cox.cov") {
        msg = "ERROR: from GlmnetDiag.writeCoxSummaryWithCov: ";
        msg = paste("The input gl is not of class glmnet.cox.cov");
        stop(msg);
      }
      # ...........................................................


      
      # .......................................................................
      # . Write to file :
      # .......................................................................
      FS = file(fs, "w");
      # .......................................................................
      # . Write the model summary :
      # .......................................................................
      txtSummary = GlmnetDiag.generateCoxSummaryWithCov(gl, dsTrain, dsTest);
      
      cat(txtSummary, file = FS);
      # ...............................................................................
      # . The direct term for the external covariate :
      # ...............................................................................
      cat("#\n", sep = "", file = FS);      
      cat("#Cox coefficient for EXTERNAL covariate:", "\n", sep = "", file = FS);
      cat("betaZ\tse(betaZ)\texp(betaZ)\tPZ\n", sep = "", file = FS);

      expBetaZ = exp(gl$betaZ);
      
      cat(gl$betaZ, "\t", gl$seBetaZ, "\t", expBetaZ, "\t", gl$pBetaZ, "\n", sep = "", file = FS);      
      # ...............................................................................
      # . Gene-by-gene Cox coefficients, direct and interaction terms :
      # ...............................................................................      
      abeta = gl$abeta;               # The m coefficients.
      aexpBeta = exp(abeta);          # exp(beta) the m coefficients.            
      aseBeta = gl$aseBeta;           # Standard errors for the m coefficients.
      apBeta = gl$apBeta;             # The corresponding m P-values.

      agamma = gl$agamma;             # The m coefficients.
      aexpGamma = exp(agamma);        # exp(gamma) the m coefficients.            
      aseGamma = gl$aseGamma;         # Standard errors for the m coefficients.
      apGamma = gl$apGamma;           # The corresponding m P-values.
      
      cat("#\n", sep = "", file = FS);      
      cat("#Cox coefficients for DIRECT (beta) and INTERACTION (gamma) terms:", "\n",
           sep = "", file = FS);
      cat("#m = ", gl$m, " genes selected.\n", sep = "", file = FS);      
      cat("#QUAL\tbeta\tse(beta)\texp(beta)\tPbeta\tgamma\tse(gamma)\texp(gamma)\tPgamma\n",
          sep = "", file = FS);

      for (l in 1:gl$m) {
        geneName = gl$ac[gl$indexSelACT[l]];
        cat(geneName,
            "\t", abeta[l],
            "\t", aseBeta[l],
            "\t", aexpBeta[l],          
            "\t", apBeta[l],
            "\t", agamma[l],
            "\t", aseGamma[l],
            "\t", aexpGamma[l],          
            "\t", apGamma[l],
            "\n", sep = "", file = FS);
      }

      buf = cat("\n", sep = "");      # Bare line.
      # ......................................................................................


      # ...........      
      close(FS);
      # ...........

      
      # ..............................................................................      
      cat(" ..........  Wrote statistical summary : ", fs, "\n", sep = "");
      # ..............................................................................

      
      # ...........
      return (0);
      # ...........
      
}

# =================================================================================================
# . End of GlmnetDiag.writeCoxSummaryWithCov.
# =================================================================================================      





# =================================================================================================
# . GlmnetDiag.generateCoxSummaryWithCov : generates a text string containing a summary of results 
# . -------------------------------------   from the supervised principal components calculation.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .        txt = GlmnetDiag.generateCoxSummaryWithCov(gl, dsTrain, dsTest);
# .
# .   In:
# .        gl = result of supervised principal components computation, returned
# .              by function Glmnet.computeCoxWithCov().
# .    dsTrain = as returned by Glmnet.computeSignificanceOnCov() on training set.
# .     dsTest = as returned by Glmnet.computeSignificanceOnCov() on test set (if any),
# .              else NULL.
# .
# .
# .   Out:
# .        txt = contains listing of input parameters, feature selection results,
# .              svd results, and global and detailed results for the Cox propotional
# .              hazard model.
# .
# =================================================================================================

GlmnetDiag.generateCoxSummaryWithCov <- function(gl, dsTrain, dsTest)
{

      # .....................................................................................
      if (class(gl) != "glmnet.cox.cov") {
        msg = "ERROR: from GlmnetDiag.generateCoxSummaryWithCov: ";
        msg = paste("The input gl is not of class glmnet.cox.cov");
        stop(msg);
      }
      # .....................................................................................      

  
      # ...........................................................................................
      buf = "# ................................................................\n";
      buf = paste(buf,
                  "# . Summary for Cox proportional hazard model.                    \n", sep = "");
      buf = paste(buf,
                  "# ................................................................\n", sep = "");      
      # ............................................................................................




      # ......................................................................................
      # . Parameters used in the computation, and results of the feature selection :
      # ......................................................................................
      buf = paste(buf, "#General Parameters:\n", sep = "");      
      buf = paste(buf, "#Number of samples in data matrix: n = " , gl$n, "\n", sep = "");
      buf = paste(buf, "#Number of genes in data matrix: p = " , gl$p, "\n", sep = "");
      buf = paste(buf, "#Outer feature selection method: methodFs = mtop\n", sep = "");

      buf = paste(buf, "#mtop = " , gl$mtop, "\n", sep = "");        

      buf = paste(buf, "#Type of P-value used in feature selection: typePval = " ,
                  gl$typePval, "\n", sep = "");      
      buf = paste(buf, "#Number of genes passed by combined feature selection and glmnet: m = " , gl$m, "\n", sep = "");
      # ......................................................................................


      
      # ......................................................................................
      # . Details of the results for the Cox proportional hazard model:
      # ......................................................................................
      m21 = 2 * gl$m + 1;
      
      buf = paste(buf, "#\n", sep = "");      
      buf = paste(buf, "#Cox Proportional Hazard Model Results:", "\n", sep = "");
      buf = paste(buf, "#Proportional hazard model:\n", sep = "");
      buf = paste(buf, "#lambda(t) = lambda0(t) * exp(beta . x + betaZ . z + z . gamma . x)\n", sep = "");      
      buf = paste(buf, "#where x is the gene expression vector\n", sep = "");
      buf = paste(buf, "#and Z is an external covariate, and where\n", sep = "");
      buf = paste(buf, "#beta = m-vector of Cox coeff. for direct terms (m = ", gl$m, "),\n", sep = "");
      buf = paste(buf, "#betaZ = Cox coefficients for direct effect of external covariate,\n", sep = "");
      buf = paste(buf, "#and gamma = m-vector of Cox coeff. for interaction terms (m = ", gl$m, ").\n", sep = "");
      buf = paste(buf, "#Total number of degrees of freedom: df = 2 * m + 1 = ", m21, ".\n", sep = ""); 
      buf = paste(buf, "#\n", sep = "");      

      buf = paste(buf, "#Global properties:\n", sep = "");
     
      qRtemp = sprintf("%8.3e", gl$qR);   # Loglikelihood ratio.
      pRtemp = sprintf("%8.3e", gl$pR);   # Corresponding p-value.

      buf = paste(buf, "#Loglikelihood ratio statistic (df = 2 * m + 1): qR = 2 * (l(beta) - l(0))\n", sep = "");
      buf = paste(buf, "#qR = ", qRtemp, "\n", sep = "");      
      buf = paste(buf, "#P-value pR for loglikelihood ratio statistic (against chi2):\n", sep = "");
      buf = paste(buf, "#pR = ", pRtemp, "\n", sep = "");            
      # ......................................................................................



      # ......................................................................................
      # . Sensitivity analysis for the training set :
      # ......................................................................................
      buf = paste(buf, "#Sensitivity analysis for the training set:\n", sep = "");
      # ...............................................................
      # . All training set samples :
      # ...............................................................      
      buf = paste(buf, "#For all training set samples:\n", sep = "");

      nHere = dsTrain$nAll;
      pR = sprintf("%8.3e", dsTrain$csAll$pR);
      hRLo = sprintf("%8.3e", dsTrain$csAll$hRLo);
      hR = sprintf("%8.3e", dsTrain$csAll$hR);
      hRHi = sprintf("%8.3e", dsTrain$csAll$hRHi);

      buf = paste(buf, "#n = ", nHere, "\n", sep = "");
      buf = paste(buf, "#pR = ", pR, "\n", sep = "");
      buf = paste(buf, "#hR = ", hR, " [", hRLo, ", ", hRHi, "]0.95", "\n", sep = "");
      # ...................................................................................
      # . All sensitive patients :
      # ....................................................................................
      buf = paste(buf, "#For sensitive patients (hRC = ", dsTrain$hRC, ")\n", sep = "");

      nHere = dsTrain$nSens;

      if (nHere > 0) {
        pR = sprintf("%8.3e", dsTrain$csSens$pR);
        hRLo = sprintf("%8.3e", dsTrain$csSens$hRLo);
        hR = sprintf("%8.3e", dsTrain$csSens$hR);
        hRHi = sprintf("%8.3e", dsTrain$csSens$hRHi);

        buf = paste(buf, "#n = ", nHere, "\n", sep = "");
        buf = paste(buf, "#pR = ", pR, "\n", sep = "");
        buf = paste(buf, "#hR = ", hR, " [", hRLo, ", ", hRHi, "]0.95", "\n", sep = "");
      } else {
        buf = paste(buf, "#n = ", nHere, "\n", sep = "");        
      }

      buf = paste(buf, "\n", sep = "");      # Bare line.      
      # ......................................................................................      


      
      # ......................................................................................
      # . Sensitivity analysis for the test set :
      # ......................................................................................
      if (!is.null(dsTest)) {
        buf = paste(buf, "#Sensitivity analysis for the test set:\n", sep = "");
        # ...............................................................
        # . All testing set samples :
        # ...............................................................      
        buf = paste(buf, "#For all test set samples:\n");

        nHere = dsTest$nAll;
        pR = sprintf("%8.3e", dsTest$csAll$pR);
        hRLo = sprintf("%8.3e", dsTest$csAll$hRLo);
        hR = sprintf("%8.3e", dsTest$csAll$hR);
        hRHi = sprintf("%8.3e", dsTest$csAll$hRHi);

        buf = paste(buf, "#n = ", nHere, "\n", sep = "");
        buf = paste(buf, "#pR = ", pR, "\n", sep = "");
        buf = paste(buf, "#hR = ", hR, " [", hRLo, ", ", hRHi, "]0.95", "\n", sep = "");
        # ...................................................................................
        # . All sensitive patients :
        # ....................................................................................
        buf = paste(buf, "#For sensitive patients in test set (hRC = ", dsTest$hRC, ")\n", sep = "");

        nHere = dsTest$nSens;
        
        if (nHere > 0) {
          pR = sprintf("%8.3e", dsTest$csSens$pR);
          hRLo = sprintf("%8.3e", dsTest$csSens$hRLo);
          hR = sprintf("%8.3e", dsTest$csSens$hR);
          hRHi = sprintf("%8.3e", dsTest$csSens$hRHi);

          buf = paste(buf, "#n = ", nHere, "\n", sep = "");
          buf = paste(buf, "#pR = ", pR, "\n", sep = "");
          buf = paste(buf, "#hR = ", hR, " [", hRLo, ", ", hRHi, "]0.95", "\n", sep = "");
        } else {
          buf = paste(buf, "#n = ", nHere, "\n", sep = "");        
        }
        # ....................................................................................
      }
      # ......................................................................................      


    
      # .............
      return (buf);
      # .............

}

# =================================================================================================
# . End of GlmnetDiag.generateCoxSummaryWithCov.
# =================================================================================================







# =================================================================================================
# . GlmnetDiag.writeCoxDataWithCov : for each sample in the input data matrix, this writes
# . ------------------------------   log hazard and hazard ratios.
# .                                          
# .
# . Note that samples need *not* be the same as in the training set.
# .
# .   Syntax:
# .           GlmnetDiag.writeCoxDataWithCov(gl, dfX, dfE, az, fo);
# .
# .   In:
# .        gl = result of supervised principal components computation, returned
# .              by function Glmnet.computeCoxWithCov().
# .
# .       dfX = input data frame. It must have the same number and identity of genes as the dataframe
# .             used in SuperPc.computeCoxWithCoxWithCov().
# .             Samples need not be the same as in the training set (so that in particular the 
# .             number of rows need not be the same as in the training set).
# .
# .       dfE = experimental design data frame. It must have the same number of rows as dfX.
# .             Samples need not ne the same as in the training set.
# .
# .        az = input vector of covariate values. It must have the same number of rows as dfX.
# .             Samples need not ne the same as in the training set.
# .
# .       hRC = cutoff on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .        fo = name of output file.
# .
# =================================================================================================

GlmnetDiag.writeCoxDataWithCov <- function(gl, dfX, dfE, az, hRC, fo)
{

      # ...........................................................
      if (class(gl) != "glmnet.cox.cov") {
        msg = "ERROR: from GlmnetDiag.writeCoxDataWithCov: ";
        msg = paste("The input gl is not of class glmnet.cox.cov");
        stop(msg);
      }
      # ...........................................................

      
      # .............................................................................
      #xxx cat(" ..........  Entry in GlmnetDiag.writeCoxDataWithCov.\n");
      # .............................................................................

      
      # ................................................................
      # . Consistency check for input objects :
      # ................................................................
      n = nrow(dfX);
      p = ncol(dfX);
      # ................................................................
      # . Check on genes :
      # ................................................................     
      if (p != gl$p) {
        msg = "ERROR: from GlmnetDiag.writeCoxDataWithCov: ";
        msg = paste(msg, " Input data frame has p = ", p,
                         " genes, not same as gl$p = ", gl$p, sep = "");
        stop(msg);
      }

      buf = (colnames(dfX) == gl$ac);    # Gene names must be the same.
      nbuf = length(which(buf == FALSE));

      if (nbuf > 0) {
        msg = "ERROR: from GlmnetDiag.writeCoxDataWithCov: ";
        msg = paste(msg, " Gene names in input data frame not the same as in gl.", sep = "");
        msg = paste(msg, " Number different = ", nbuf, sep = "");
        stop(msg);
      }
      # ................................................................
      # . Check on number of samples :
      # ................................................................     
      ne = nrow(dfE);

      if (ne != n) {
        cat("ERROR: from GlmnetDiag.writeCoxDataWithCov:\n");
        cat("Input experimental design has ne = ", ne, " rows ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }

      nz = length(az);

      if (nz != n) {
        cat("ERROR: from GlmnetDiag.writeCoxDataWithCov:\n");
        cat("Input external covariate array az has nz = ", nz, " elements. ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }

      stopifnot(hRC >= 0.0);
      # ................................................................
      

      
      
      # ...................................................................................
      # . Compute the log-hazard ratios. This call returns :
      # .          sl$Y = n * K matrix of principal components.
      # .     sl$aloghR = n matrix of log-hazard-ratios.
      # ...................................................................................      
      sl = Glmnet.computeCoxLogHazardWithCovAndPred(gl, dfX, az, hRC);
      # ...................................................................................
      


      # ...................................................................................
      # . Build the output data frame :
      # ...................................................................................      
      ar = rownames(dfX);                                     # The row names.

      dfOut = cbind(ar,
                    az,
                    as.data.frame(sl$aloghR),
                    as.data.frame(sl$ahR),
                    as.data.frame(sl$atMed) );

      if (sl$flagPred) {
        dfOut = cbind(dfOut, sl$azMin);
      }

      if (sl$flagBin) {
        dfOut = cbind(dfOut, sl$aDloghRz, sl$aflagSensitiveZ);
      }      
      # ..................................................................................
      # . Assign the column names :
      # ..................................................................................      
      loghRnames = colnames(sl$aloghR);
      hRnames = colnames(sl$ahR);
      tMednames = colnames(sl$atMed);

      abuf = c('#QUAL', "zActual", loghRnames, hRnames, tMednames);

      if (sl$flagPred) {
        abuf = c(abuf, "zMin");
      }

      if (sl$flagBin) {
        abuf = c(abuf, "DloghRz1_minus_0", "flagSensitiveZ");
      }      
      
      colnames(dfOut) = abuf;
      # ..................................................................................
      # . Add the input experimental design :
      # .................................................................................. 
      dfOut = cbind(dfOut, dfE);                               # Dataframe.
      # ...................................................................................

      
      
      # .............................................
      # . Write to file :
      # .............................................
      DataFrame.writeFlat(dfIn = dfOut, fo = fo);
      # .............................................


      # ...........................................................................      
      cat(" ..........  Wrote Cox data : ", fo, "\n", sep = "");
      # ...........................................................................

      
      # ..........
      return (0);
      # ..........
      
}

# =================================================================================================
# . End of GlmnetDiag.writeCoxDataWithCov.
# =================================================================================================      





# =================================================================================================
# . GlmnetDiag.plotCoxWithCov : displays the results of an analysis using the Cox propotional
# . --------------------------   hazard model on survival data, in the form of a series of plots.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .       sp = GlmnetDiag.plotCoxWithCov(at, as, az, dfX, gl, hRC,
# .                                       flagWrite, dirName, stemName);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .           gl = result of Cox regression, returned by function Glmnet.computeCoxWithCov().
# .
# .       hRC = cutoff on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .
# .     flagWrite = no/yes : flag indicating whether plots should be written to file in jpeg
# .                 format instead of being displayed.
# .                 If value is 'yes', each plot will be written to a file in the directory
# .                 indicated by 'dirName', with a name given by 'stemName' followed by
# .                 a random string and the .jpg extension.
# .                 If value is 'no', the user is prompted to interactively provide carriage
# .                 returns to march through the display.
# .
# .       dirName = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .      stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .   Out:
# .
# .           - If flagWrite = 'no', displays a series of plots. The use enter carriage returns
# .           to advance from one plot to the next.
# .           Object sp returned is NULL.
# .
# .           - If flagWrite = 'yes', generates a series of plot files, as indicated above.
# .           Object sp returned is a list with members:
# .
# .                  nplot = number of plot files generated.
# .                  afile = array of file names.
# .                  aplot = array of plot names.
# .
# =================================================================================================

GlmnetDiag.plotCoxWithCov <- function(at, as, az, dfX, gl, hRC,
                                      flagWrite = 'no',
                                      dirName = NULL, stemName = NULL)
{

      # .............................................................
      cat(" ..........  Entry in GlmnetDiag.plotCoxWithCov.\n");
      # .............................................................

      
      # .............................................................
      stopifnot((flagWrite == 'no') || (flagWrite == 'yes'));
      # .............................................................
      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      if (class(gl) != "glmnet.cox.cov") {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCov: ";
        msg = paste("The input gl is not of class glmnet.cox.cov\n");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.
      
      if (nt != n) {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCov: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCov: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCov: ";        
        msg = paste("The input data matrix does not have the same number of ");
        msg = paste("genes as in the supervised pc. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("gl has p = " , gl$p, " genes.");
        stop(msg);
      }

     if (gl$n != n) {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCov: ";        
        msg = paste("The input data matrix does not have the same number of ");       
        msg = paste("samples as in the supervised pc. ");
        msg = paste("Input has n = " , n, " samples. ");
        msg = paste("gl has n = " , gl$n, " samples.");        
        stop(msg);
      }

      stopifnot(hRC >= 0.0);      
      # ...............................................................................................


      
      # ...................................................................................
      dfXc = sweep(dfX, 2, gl$axm);                # Center each column separately. 
      dfXSel = dfXc[ , gl$indexSelACT];            # nIn * m data matrix subsetted to the selected genes.

      if (nrow(dfXc) == 1) {
        dfXSel = matrix(dfXSel, nrow = 1);           # Special case for nrow = 1, to preserve matrix geometry.
      }

      if (length(gl$indexSelACT) == 1) {
        dfXSel = as.matrix(dfXSel, nrow = nrow(dfXc));
        colnames(dfXSel) = colnames(dfXc)[gl$indexSelACT];
      }

      agene = colnames(dfXSel);                         # Selected gene names, in feature selection order.
      asample = rownames(dfXSel);                       # Sample names.

      nsel = nrow(dfXSel);                              # Number of samples.
      msel = ncol(dfXSel);                              # Number of subsetted genes.            
      # ...................................................................................

      
      # .......................................................
      # . Reset some defaults, in case they got changed :
      # .......................................................      
      par(ask = FALSE);
      par(mfrow = c(1,1));      
      # .......................................................


      # .......................................................................................
      if (flagWrite == 'no') {
        cat("\n");
        cat(" ..........  Enter carriage returns as indicated to generate plots one-by-one.\n");
      } else if (flagWrite == 'yes') {
        cat(" ..........  Generating plot files in directory = ", dirName, "\n", sep = "");
      }
      # .......................................................................................


      # ...........................................................
      # . Initialize plot arrays :
      # ...........................................................
      afile = c();
      aplot = c();

      if (flagWrite == 'no') {
        dirName = "foo";        # Dummy value.
        stemName = "dum";       # Dummy value.
      }
      # ...........................................................

      
      
      # .......................................................................................
      if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................
      

      
      # ..........................................................................................................
      # . HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS
      # .
      # . Generate heat maps below, provided the data matrices are not too large.
      # .
      # . First, plot of the entire data matrix, before any feature selection :
      # ..........................................................................................................
      if (p > SuperPcDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the entire data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here p = ", p, " while the maximum is given by SuperPcDiag.MSELMAX = ", SuperPcDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat map for entire data matrix and continue execution.\n");
      }

      if (p <= SuperPcDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the p * n data matrix before any feature selection.
        # . No clustering or sorting of any kind.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Training set data matrix";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ABuf = t(dfX);              # Make this genes * samples.

        if (flagWrite == 'yes') {
	  #xxxx        jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
        
        if (nrow(ABuf) == 1) {
          ABuf = rbind(ABuf, ABuf);     # Trick to get to a single gene to display in the heat map.
        }         
        
        SuperPcDiag.plotGeneDataMatrix(ax = ABuf, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................      
      }
      # ..........................................................................................................

      
      # ..........................................................................................................
      # . Next, plot of the data matrix after feature selection :
      # ..........................................................................................................
      if (msel > SuperPcDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the feature-selected data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here msel = ", msel, " while the maximum is given by SuperPcDiag.MSELMAX = ", SuperPcDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat maps of feature-selected data matrix and continue execution.\n");
      }

      if (msel <= SuperPcDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the m * n data matrix after feature selection.
        # . Samples not sorted. Genes in order of feature selection, but otherwise not clustered.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste(gl$m, " selected genes. Samples not sorted. Genes not clustered.", sep = "");      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ASel = as.matrix(t(dfXSel));   # m * n = genes * samples format.

        if (flagWrite == 'yes') {
	  #xxxx        jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        if (nrow(ASel) == 1) {
          ASel = rbind(ASel, ASel);     # Trick to get to a single gene to display in the heat map.
        }         

        SuperPcDiag.plotGeneDataMatrix(ax = ASel,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................


        # .......................................................................................
        # . Preamble for sorting samples :
        # . if the values of the external covariate are all integers, use as part of the sort key.
        # .......................................................................................            
        azNR = unique(az);                        # Nonredundant list of values for external covariate.

        flagSortOnZ = FALSE;                      # Will indicate if we have sorted on covariate Z as well.
        nnonInt = sum(Math.isInt(azNR) == FALSE);
      
        if (nnonInt == 0) {
          Tmax = max(at);
          atForSort = at + az * Tmax;
          flagSortOnZ = TRUE;
        } else {
          atForSort = at;
          flagSortOnZ = FALSE;
        }
        # .......................................................................................                    


      
        # .......................................................................................      
        # . Sort samples so that the shortest survival times are on the left.
        # . If distinct values of covariate Z are integer, first sort on Z
        # . before sorting on survival times.
        # .......................................................................................
        sBuf = sort(atForSort, decreasing = FALSE, index.return = TRUE);
        indexSort = sBuf[["ix"]];      # Sort index.

        ASort = ASel[ , indexSort];    # Sorted on columns.
        azSort = az[indexSort];        # Values of Z in same order as sorted samples.
        # .......................................................................................
        # . Samples sorted, genes not clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        if (!flagSortOnZ) {
          pname = paste(gl$m, " selected genes. Samples sorted ",
                        " with increasing survival times left-to-right.",
                        " Genes not clustered.", sep = "");
          caption = paste(gl$m, " sel. genes. Samples sorted increas. surv. times LtR. Genes not clustered.",
                          sep = "");
        } else {
          pname = paste(gl$m, " selected genes. Samples sorted first on Z, then",
                               " with increasing survival times left-to-right.",
                               " Genes not clustered.", sep = "");
          caption = paste(gl$m, " sel. genes. Samples sort. on Z, then on increas. surv. times LtR. Genes not clust.",
                          sep = "");
        }
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxx jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        if (nrow(ASort) == 1) {
          ASort = rbind(ASort, ASort);     # Trick to get to a single gene to display in the heat map.
        }         
        
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................


      
      
        # .......................................................................................
        # . Samples sorted, genes clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        if (!flagSortOnZ) {
          pname = paste(gl$m, " selected genes. Samples sorted ",
                        " with increasing survival times left-to-right.",
                        " Genes clust.", sep = "");
          caption = paste(gl$m, " sel. genes. Samples sorted increas. surv. times LtR. Genes clust.",
                          sep = "");
        } else {
          pname = paste(gl$m, " selected genes. Samples sorted first on Z, then",
                               " with increasing survival times left-to-right.",
                               " Genes clust.", sep = "");
          caption = paste(gl$m, " sel. genes. Samples sort. on Z, then on increas. surv. times LtR. Genes clust.",
                          sep = "");
        }
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxxx          jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        if (nrow(ASort) == 1) {
          ASort = rbind(ASort, ASort);     # Trick to get to a single gene to display in the heat map.
        }         
        
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'yes',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................



        # .......................................................................................      
        # . Generate a bar that indicates values of Z in final sorting order for the heat
        # . map columns.
        # .......................................................................................
        if (flagSortOnZ) {
          azSort = az[indexSort];               # Values of Z in same order as sorted samples.
          azSort = matrix(azSort, nrow = 1);    # Make into matrix, for bar.
          azSort = rbind(azSort, azSort);       # It needs at least two rows for the heat map.
          # .......................................................................................
          # . Generate file name :      
          # .......................................................................................
          fname = File.generateRandomName(dirName, stemName, ext = "jpg");

          pname = paste("Indicator bar for Z values in sorting order ",
                        " of the preceding heat map columns.", sep = "");

          afile = c(afile, fname);
          aplot = c(aplot, pname);
          # .......................................................................................
          # . Plot here :
          # .......................................................................................
          if (flagWrite == 'yes') {
            #xxxxxx        jpeg(fname);              # Turn on plot device.
            jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
          }
            
          SuperPcDiag.plotGeneDataMatrix(ax = azSort, caption = pname);
          # .....................................................................................
          # . Close device or prompt user for next plot :      
          # .......................................................................................
          if (flagWrite == 'yes') {
            dev.off();
          } else if (flagWrite == 'no') {
            buf = readline(">>Enter a carriage return to continue: ");    # Pause.
          }
          # .......................................................................................        
        }
        # ..........................................................................................
      }
      # ......................................................................................................
      # . END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS
      # ......................................................................................................



      
      # .......................................................................................
      # . Survival times and covariate values under the sort key :
      # .
      # . Generate file name :
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      # .......................................................................................
      # . Select captions based on clustering scheme :
      # .......................................................................................      
      pname = paste("Survival times and covariate values with samples sorted", sep = ""); 
      afile = c(afile, fname);
      aplot = c(aplot, pname);                        
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }

      atSort = at[indexSort];       # Sorted survival times.
      azSort = az[indexSort];       # Sorted covariate values.
      acSort = asample[indexSort];  # Corresponding sample names.
      
      par(mfrow = c(2,1));

      plot(atSort, xaxt = 'n', xlab = 'sorted samples');
      axis(side = 1, at = 1:length(acSort), labels = acSort);
      
      plot(azSort, xaxt = 'n', xlab = 'sorted samples');
      axis(side = 1, at = 1:length(acSort), labels = acSort);      

      par(mfrow = c(1, 1));      
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }                  
      # .......................................................................................


     

      
      # ...................................................................................
      # . Compute the log-hazard ratios, using the trining set model :
      # .          sl$Y = n * m matrix of expression values.
      # .     sl$aloghR = n matrix of log-hazard-ratios.
      # ...................................................................................
      sl = Glmnet.computeCoxLogHazardWithCovAndPred(gl, dfX, az, hRC);      
      # ...................................................................................


      

      # .......................................................................................
      # . Plot the hazard ratios estimated based on actual covariate values, against the samples :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = 'Estimated hazard ratios';
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
            
      ylim = c(0.0, max(sl$ahR));

      if (sl$flagPred) {
        ahRBuf = sl$ahR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
      } else {
        ahRBuf = sl$ahR;
      }
      
      plot(ahRBuf, xlab = 'Index (sample)', ylab = 'Hazard ratio',
           main = 'Estimated hazard ratios', ylim = ylim,
           xaxt = 'n');

      axis(side = 1, at = 1:length(asample), labels = asample);
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................


      

      # .......................................................................................
      # . Regularization paths for Coxnet model :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Coxnet regularization paths";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }

      caption = paste(pname," (actual lambda = ", gl$lambda, ")", sep = "");
      plot(gl$fitB, xvar = 'lambda', main = caption);

      if (gl$lambda > 0.0) {
        temp1 = log(gl$lambda);
        abline(v = temp1, lty = 'dashed');
      }
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................

      



      # .......................................................................................
      # . Number of active genes as a function of lambda :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Number of active genes as a function of lambda";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }

      amACT = Glmnet.findNumberActiveGenes(gl);
      caption = pname;
      
      plot(log(gl$alambdaOut), amACT, main = caption, pch = 19,
           xlab = 'Log Lambda', ylab = 'Number of active genes');

      lines(log(gl$alambdaOut), amACT, type = 'l');

      if (gl$lambda > 0.0) {
        temp1 = log(gl$lambda);
        abline(v = temp1, lty = 'dashed');
      }
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................




      
      
     
      # .......................................................................................
      # . Scatter plot of survival times against estimated log-hazard-ratio :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Survival time versus log hazard ratio";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      if (sl$flagPred) {
        aloghRBuf = sl$aloghR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
      } else {
        aloghRBuf = sl$aloghR;
      }
      
      xlab = "log hazard ratio (estimated)";
      ylab = "Survival time";
      plot(aloghRBuf, at, type = 'p', xlab = xlab, ylab = ylab, main = pname);
      abline(v = 0.0);
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................




      
      # ....................................................................................
      # . Plot survival times versus predicted DloghR = loghR(Z=1) - loghR(Z=0) :
      # .......................................................................................
      msg = Cox.checkBinary(az);                     # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg == 'ok') {
        # ....................................................................................
        # . Generate file name:
        # ....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Survival times vs predicted DloghR";
        afile = c(afile, fname);
        aplot = c(aplot, pname);      
        # ....................................................................................
        # . Plot here :
        # ....................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Compute DloghR :
        # .....................................................................................
        aDloghR = sl$aDloghRz;               # This is DloghR = loghR(Z = 1) - loghR(Z = 0).

        acol = ifelse(az == 1, 'blue', 'red');
        # .....................................................................................
        # . For the feature selection level that maximizes significance :
        # . Plot survival times againsts DloghR.
        # .....................................................................................
        ymin = 0.0;
        ymax = 1.1 * max(at);

        xmax = max(aDloghR);
        xmin = min(aDloghR);
        
        caption = paste('Surv. time versus predicted DloghR: ');

        temp1 = paste('mtop = ', gl$mtop,
                        ', hRC = ', sprintf("%8.3e", hRC) , sep = "");

        caption = paste(caption, temp1, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aDloghR, at, ylim = c(ymin, ymax),
             type = 'p', xlab = 'predicted DloghR = loghR(Z = 1) - loghR(Z =0)',
             ylab = 'survival time', main = caption, col = acol, pch = 19);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);

        abline(v = 0);                           # Abcissa.
        temp1 = log(hRC);
        abline(v = temp1, lty = 'dashed');       # Boundary for determining sensitive patients.
        # ......................................................................................
        # . Add the legend here:
        # ......................................................................................
        xtemp1 = xmax - 0.2 * (xmax - xmin);
        ytemp1 = ymax;
        
        legendText = c("Z = 0", "Z = 1");
        colVector = c('red', 'blue');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = xtemp1, y = ytemp1,
               legend = legendText, col = colVector, pch = pchVector, bty = 'n');
        # ......................................................................................
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # ....................................................................................        
      }
      # .......................................................................................      



      

     
      # .......................................................................................
      # . Plot prediction of sample sensitivity vs sample index.
      # . These are the samples for which predicted DloghR <= log(hRC).
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Sensitivity status vs sample index";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ylim = c(0, 1);

        acol = ifelse(az == 0, 'red', 'blue');
        
        plot(sl$aflagSensitiveZ, xlab = 'Index (sample)', ylab = 'Sensitivity',
             main = 'Sensitivity prediction', ylim = ylim, col = acol,
             xaxt = 'n', pch = 19);

        axis(side = 1, at = 1:length(asample), labels = asample);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................




      # .......................................................................................
      # . Flag patients predicted sensitive, UN-sorted sample order; generate a heat
      # . map with bars. For two-armed studies only.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {      
        aflag = sl$aflagSensitiveZ;                 # The {0, 1} flags, not sorted. 1 = sensitive, 0 = not sensitive.
        aflag = ifelse(aflag == 1, 0.65, aflag);        

        aflag = matrix(aflag, nrow = 1);            # Make into matrix.
        aflag = rbind(aflag, aflag);                # It needs at least two rows for the heat map.
        # .......................................................................................      
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        pname = paste("Flag sensitive patients, hRC = ", hRC,
                      ", original sample order, red = sensitive", sep = ""); 
        afile = c(afile, fname);
        aplot = c(aplot, pname);                        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxxxxxxxxxxxxxx        jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        SuperPcDiag.plotGeneDataMatrix(ax = aflag, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .....................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .....................................................................................
      }
      # .......................................................................................

            

      


      # .......................................................................................
      # . Flag patients predicted sensitive, SORTED sample order; generate a heat
      # . map with bars.
      # . For two-armed studies only.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {      
        aflagSort = sl$aflagSensitiveZ[indexSort];       # The {0, 1} flags, sorted. 1 = sensitive, 0 = not sensitive.
        aflagSort = ifelse(aflagSort == 1, 0.65, aflagSort);
        
        acSort = asample[indexSort];                     # Corresponding sample names.

        aflagSort = matrix(aflagSort, nrow = 1);         # Make into matrix, for bar.
        aflagSort = rbind(aflagSort, aflagSort);         # It needs at least two rows for the heat map.
        # .......................................................................................      
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        pname = paste("Flag sensitive patients, hRC = ", hRC,
                      ", sorted sample order, red = sensitive", sep = ""); 
        afile = c(afile, fname);
        aplot = c(aplot, pname);                        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx          jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        SuperPcDiag.plotGeneDataMatrix(ax = aflagSort, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .....................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .....................................................................................
      }
      # .......................................................................................

      

     

      # .......................................................................................
      # . Survival curves for Z = 0 and Z = 1 arms :
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Survival curves", sep = "");
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Set number of plots :
        # .......................................................................................
        par(mfrow = c(2, 2));
        # .......................................................................................
        # . 1. All samples :
        # .......................................................................................
        legend_0 = "Z = 0";
        legend_1 = "Z = 1";
        caption = pname;
        
        SuperPcDiag.plotSurvivalOnBinary(at, as, az, legend_0, legend_1, caption);
        # .......................................................................................
        # . 2. Subset to sensitive samples only :
        # .......................................................................................
        nBuf = sum(sl$aflagSensitiveZ == 1);          # Number of samples predicted sensitive.

        if (nBuf > 0) {
          atBuf = at[sl$aflagSensitiveZ == 1];
          asBuf = as[sl$aflagSensitiveZ == 1];
          azBuf = az[sl$aflagSensitiveZ == 1];                

          legend_0 = "Z = 0";
          legend_1 = "Z = 1";
          caption = paste(pname, ": sensitive group", sep = "");
        
          SuperPcDiag.plotSurvivalOnBinary(atBuf, asBuf, azBuf, legend_0, legend_1, caption);
        }
        # .......................................................................................
        # . 3. Subset to resistant samples only :
        # .......................................................................................
        nBuf = sum(sl$aflagSensitiveZ == 0);          # Number of samples predicted resistant.

        if (nBuf > 0) {        
          atBuf = at[sl$aflagSensitiveZ == 0];
          asBuf = as[sl$aflagSensitiveZ == 0];
          azBuf = az[sl$aflagSensitiveZ == 0];                

          legend_0 = "Z = 0";
          legend_1 = "Z = 1";
          caption = paste(pname, ": resistant group", sep = "");
        
          SuperPcDiag.plotSurvivalOnBinary(atBuf, asBuf, azBuf, legend_0, legend_1, caption);
        }
        # .......................................................................................
        # . 4. Plot 4 survival curves in one graph :
        # .......................................................................................
        alZ = c('0', '1');
        alR = c('R', 'S');
        caption = paste(pname, ": sensitive and resistant", sep = "");
        
        SuperPcDiag.plotSurvivalOnTwoBinaries(at, as, az, sl$aflagSensitiveZ, alZ, alR, caption = caption);        
        # .......................................................................................
        # . Reset number of plots :
        # .......................................................................................
        par(mfrow = c(1, 1));        
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      
    



      # ................................................................................................
      # . Survival curves for Z = 0 and Z = 1 arms X {S, R} status :
      # . (for two-arm studies only):
      # ................................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Survival curves for sensitive and resistant patients", sep = "");
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # .   Plot 4 survival curves in one graph :
        # .......................................................................................
        alZ = c('0', '1');
        alR = c('R', 'S');
        caption = "sensitive and resistant";
        SuperPcDiag.plotSurvivalOnTwoBinaries(at, as, az, sl$aflagSensitiveZ, alZ, alR, caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................        
      }
      # .....................................................................................................


      
      
      
      # .......................................................................................
      # . Gene loadings.
      # .
      # . Generate file name :            
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Gene loadings";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      par(mfrow = c(2, 2));
      # .......................................................................................
      # . Singular values density :
      # .......................................................................................      
      #xxxx plot(density(spc$sv$d, bw = 0.1), main = "Singular values density");
      # .......................................................................................
      # . Gene loadings, direct terms, unsorted :
      # .......................................................................................      
      xlab = paste("gene index (m = ", gl$m, ")", sep = "");
      ylab = expression(beta);
      plot(1:gl$m, gl$abeta,
           xlab = xlab, ylab = ylab, main = "Gene loadings, direct terms -- not sorted",
           xaxt = 'n');
      abline(h = 0.0);

      axis(side = 1, at = 1:length(agene), labels = agene);         
      # .......................................................................................
      # . Gene loadings, direct terms, sorted :
      # .......................................................................................      
      sBuf = sort(gl$abeta, index.return = TRUE);
      avbuf = sBuf[["x"]];             # The sorted data.
      indexBuf = sBuf[["ix"]];         # The sorting index.
      ageneBuf = agene[indexBuf];
      
      xlab = paste("gene index (m = ", gl$m, ")", sep = "");
      ylab = expression(beta * V);
      plot(1:gl$m, avbuf,
           xlab = xlab, ylab = ylab, main = "Gene loadings, direct terms -- sorted",
           xaxt = 'n');
      abline(h = 0.0);
      
      axis(side = 1, at = 1:length(ageneBuf), labels = ageneBuf);
      # .......................................................................................
      # . Gene loadings, interaction terms, unsorted :
      # .......................................................................................      
      xlab = paste("gene index (m = ", gl$m, ")", sep = "");
      ylab = expression(gamma);
      plot(1:gl$m, gl$agamma,
           xlab = xlab, ylab = ylab, main = "Gene loadings, interaction terms -- not sorted",
           xaxt = 'n');
      abline(h = 0.0);

      axis(side = 1, at = 1:length(agene), labels = agene);               
      # .......................................................................................
      # . Gene loadings, interaction terms, sorted :
      # .......................................................................................      
      sBuf = sort(gl$agamma, index.return = TRUE);
      avbuf = sBuf[["x"]];             # The sorted data.
      indexBuf = sBuf[["ix"]];         # The sorting index.
      ageneBuf = agene[indexBuf];
      
      xlab = paste("gene index (m = ", gl$m, ")", sep = "");
      ylab = expression(gamma);
      plot(1:gl$m, avbuf,
           xlab = xlab, ylab = ylab, main = "Gene loadings, interaction terms -- sorted",
           xaxt = 'n');
      abline(h = 0.0);
      
      axis(side = 1, at = 1:length(ageneBuf), labels = ageneBuf);       
      # .......................................................................................
      par(mfrow = c(1, 1));
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");
      }
      # .......................................................................................
     

      
      
      
      # .......................................................................................
      # . Plot survival curves :  global comparison. This gets plotted only for non-binary
      # . external covariate.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg != 'ok') {
        # .......................................................................................
        # . Generate file name :            
        # .......................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Survival curves";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1,1));
        # ....................................................................................... 
        # . >> ALL samples :
        # .......................................................................................        
        caption ="All samples";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at, as, aloghRBuf, caption);        
        # .......................................................................................
        par(mfrow = c(1,1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }        
      # .......................................................................................



      
      
      # .......................................................................................
      # . Plot survival curves : for two-arm studies only, separately investigate
      # . survival curves splitr on median predicted log-hazard-ratio.
      # .       cs1 = Cox.computeCoxOnSplitLoghR(at1, as1, aloghR_buf1);      
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Get the log-hazard-ratios :
        # .......................................................................................              
        if (sl$flagPred) {
          aloghRBuf = sl$aloghR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
        } else {
          aloghRBuf = sl$aloghR;
        }
        # .......................................................................................      
        # . Generate file name :            
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Survival plots for separate arms of binary study";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Start plots here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(2,2));
        # .......................................................................................
        # . Define the subsets and plot for each :
        # . >> Z = 0:
        # .......................................................................................        
        at0 = at[az == 0];
        as0 = as[az == 0];
        aloghR0 = aloghRBuf[az == 0];

        caption ="Z = 0 arm";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at0, as0, aloghR0, caption);
        # .......................................................................................
        # . >> Z = 1 :
        # .......................................................................................        
        at1 = at[az == 1];
        as1 = as[az == 1];
        aloghR1 = aloghRBuf[az == 1];        
        caption ="Z = 1 arm";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at1, as1, aloghR1, caption);
        # .......................................................................................
        # . >> ALL samples (repeated here for reference) :
        # .......................................................................................        
        caption ="All samples";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at, as, aloghRBuf, caption);        
        # .......................................................................................
        # . End the plots here:
        # .......................................................................................
        par(mfrow = c(1,1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................            


      

      
      # .......................................................................................
      # . Plot baseline hazard :
      # .
      # . Generate file name :            
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Baseline hazard";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      par(mfrow = c(2,2));
      
      if (flagWrite == 'yes') {
        par(mfrow = c(2,2));      # Otherwise written jpeg might look scrunched.
      }
      # .......................................................................................
      # . J. Theilhaber: 5-2-2010: access precomputed baseline hazard results.
      # .......................................................................................
      bh = SuperPc.getBaselineHazard(gl);   # Baseline hazard information.
      
      atSort = bh$atSort;                    # Time points (in sorted order).
      aSBase = bh$aSBase;                    # Baseline survival function.
      tBaseMed = bh$tBaseMed;                # Median survival time under baseline.
      aLambdaBase = bh$aLambdaBase;          # Cumulative baseline hazard function.
      aMSort = bh$aMSort;                    # Martingale residuals.
      # .......................................................................................
      # . Plot the baseline survival function :
      # .......................................................................................      
      caption = paste("Baseline survival, tMed = ", sprintf("%8.3e", tBaseMed), sep = "");      
      ylab = expression("exp(-" * Lambda * "0 (t))")
      tMax = max(at);
      plot(atSort, aSBase,
           type = 'l', xlab = "Survival time",
           ylab = ylab,
           main = caption, xlim = c(0, tMax), ylim = c(0,1));
      # .......................................................................................
      # . Plot the baseline cumulative hazard function :
      # .......................................................................................      
      caption = paste("Baseline cum. hazard", sep = "");      
      ylab = expression(Lambda * "0 (t)")
      tMax = max(at);
      plot(atSort, aLambdaBase,
           type = 'l', xlab = "Survival time",
           ylab = ylab,
           main = caption, xlim = c(0, tMax), ylim = c(0,max(aLambdaBase)));      
      # .......................................................................................
      # . Plot the Martingale residuals :
      # .......................................................................................
      caption = 'Martingale residuals';
      ylab = "M";
      tMax = max(at);
      plot(atSort, aMSort,
           type = 'p', xlab = "Survival time",
           ylab = ylab,
           main = caption, xlim = c(0, tMax));
      abline(h = 0, lty = 'dashed');
      lines(lowess(atSort, aMSort));             # Smoothing for detecting trends.
      # .......................................................................................
      par(mfrow = c(1,1));
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................



     
      # .......................................................................................
      # . Final tally :
      # .......................................................................................      
      nplot = length(afile);
      
      if (flagWrite == 'yes') {
        cat(" ..........  ", nplot, " jpeg plot files were generated.\n", sep = "");
      }
      # .......................................................................................

      
      
      # ....................................................................
      # . Package file names and plot names into list.
      # . Note that these are generated (with dummy names in that case)
      # . even if flagWrite = 'no'.
      # .
      # .   nplot = total number of plots in array.
      # .   afile = array of file names.
      # .   aplot = array of corresponding plot names.
      # ....................................................................
      sp = list(nplot = nplot, afile = afile, aplot = aplot);

      class(sp) = 'glmnet.diag.plot';
      # ....................................................................
      
     
      # ...........
      return (sp);
      # ...........

}

# =================================================================================================
# . End of GlmnetDiag.plotCoxWithCov.
# =================================================================================================









# =================================================================================================
# . GlmnetDiag.plotCoxWithCovOnTest : displays the results of an analysis using the Cox propotional
# . --------------------------------   hazard model on survival data, in the form of a series of plots.
# .
# .
# . This is restricted version of GlmnetDiag.plotCoxWithCov(), specific for displaying test
# . set results.
# .
# . This version allows for an additional external covariate.
# .
# .   Syntax:
# .
# .       sp = GlmnetDiag.plotCoxWithCovOnTest(at, as, az, dfX, gl, hRC,
# .                                             flagWrite, dirName, stemName);
# .
# .   In:
# .            at = n : vector of test set survival times (n = number of samples).
# .
# .            as = n : vector of test set censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for test set external covariate.
# .
# .           dfX = input test set data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .           gl = result of Cox regression, returned by function Glmnet.computeCoxWithCov().
# .
# .       hRC = cutoff on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .
# .     flagWrite = no/yes : flag indicating whether plots should be written to file in jpeg
# .                 format instead of being displayed.
# .                 If value is 'yes', each plot will be written to a file in the directory
# .                 indicated by 'dirName', with a name given by 'stemName' followed by
# .                 a random string and the .jpg extension.
# .                 If value is 'no', the user is prompted to interactively provide carriage
# .                 returns to march through the display.
# .
# .       dirName = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .      stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .   Out:
# .
# .           - If flagWrite = 'no', displays a series of plots. The use enter carriage returns
# .           to advance from one plot to the next.
# .           Object sp returned is NULL.
# .
# .           - If flagWrite = 'yes', generates a series of plot files, as indicated above.
# .           Object sp returned is a list with members:
# .
# .                  nplot = number of plot files generated.
# .                  afile = array of file names.
# .                  aplot = array of plot names.
# .
# =================================================================================================

GlmnetDiag.plotCoxWithCovOnTest <- function(at, as, az, dfX, gl, hRC,
                                            flagWrite = 'no',
                                            dirName = NULL, stemName = NULL)
{

      # .............................................................
      cat(" ..........  Entry in GlmnetDiag.plotCoxWithCovOnTest.\n");
      # .............................................................

      
      # .............................................................
      stopifnot((flagWrite == 'no') || (flagWrite == 'yes'));
      # .............................................................
      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      if (class(gl) != "glmnet.cox.cov") {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCovOnTest: ";
        msg = paste("The input gl is not of class glmnet.cox.cov\n");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.
      
      if (nt != n) {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCovOnTest: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCovOnTest: ";
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCovOnTest: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.plotCoxWithCovOnTest: ";        
        msg = paste("The input data matrix does not have the same number of ");
        msg = paste("genes as in the supervised pc. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("Gl has p = " , gl$p, " genes.");
        stop(msg);
      }

      stopifnot(hRC >= 0.0);      
      # ...............................................................................................

      
      # ...................................................................................
      dfXc = sweep(dfX, 2, gl$axm);                    # Center each column separately on the means of the training set.
      
      dfXSel = dfXc[ , gl$indexSelACT];                   # Subsetted to the selected genes.
      agene = colnames(dfXSel);                         # Selected gene names, in feature selection order.
      asample = rownames(dfXSel);                       # Sample names.

      nsel = nrow(dfXSel);                              # Number of samples.
      msel = ncol(dfXSel);                              # Number of subsetted genes.            
      # ...................................................................................

      
      # .......................................................
      # . Reset some defaults, in case they got changed :
      # .......................................................      
      par(ask = FALSE);
      par(mfrow = c(1,1));      
      # .......................................................


      # .......................................................................................
      if (flagWrite == 'no') {
        cat("\n");
        cat(" ..........  Enter carriage returns as indicated to generate plots one-by-one.\n");
      } else if (flagWrite == 'yes') {
        cat(" ..........  Generating plot files in directory = ", dirName, "\n", sep = "");
      }
      # .......................................................................................


      # ...........................................................
      # . Initialize plot arrays :
      # ...........................................................
      afile = c();
      aplot = c();

      if (flagWrite == 'no') {
        dirName = "foo";        # Dummy value.
        stemName = "dum";       # Dummy value.
      }
      # ...........................................................

      
      
      # .......................................................................................
      if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................
      

      
      # ..........................................................................................................
      # . HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS
      # .
      # . Generate heat maps below, provided the data matrices are not too large.
      # .
      # . First, plot of the entire data matrix, before any feature selection :
      # ..........................................................................................................
      if (p > SuperPcDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the entire data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here p = ", p, " while the maximum is given by SuperPcDiag.MSELMAX = ", SuperPcDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat map for entire data matrix and continue execution.\n");
      }

      if (p <= SuperPcDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the p * n data matrix before any feature selection.
        # . No clustering or sorting of any kind.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test set data matrix";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ABuf = t(dfX);              # Make this genes * samples.

        if (flagWrite == 'yes') {
          #xxxx          jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ABuf, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................      
      }
      # ..........................................................................................................

      
      # ..........................................................................................................
      # . Next, plot of the data matrix after feature selection :
      # ..........................................................................................................
      if (msel > SuperPcDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the feature-selected data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here msel = ", msel, " while the maximum is given by SuperPcDiag.MSELMAX = ", SuperPcDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat maps of feature-selected data matrix and continue execution.\n");
      }

      if (msel <= SuperPcDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the m * n data matrix after feature selection.
        # . Samples not sorted. Genes in order of feature selection, but otherwise not clustered.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Test set:", gl$m, " selected genes. Samples not sorted. Genes not clustered.", sep = "");      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ASel = as.matrix(t(dfXSel));   # m * n = genes * samples format.

        if (flagWrite == 'yes') {
          #xxxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ASel,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................


        # .......................................................................................
        # . Preamble for sorting samples :
        # . if the values of the external covariate are all integers, use as part of the sort key.
        # .......................................................................................            
        azNR = unique(az);                        # Nonredundant list of values for external covariate.

        flagSortOnZ = FALSE;                      # Will indicate if we have sorted on covariate Z as well.
        nnonInt = sum(Math.isInt(azNR) == FALSE);
      
        if (nnonInt == 0) {
          Tmax = max(at);
          atForSort = at + az * Tmax;
          flagSortOnZ = TRUE;
        } else {
          atForSort = at;
          flagSortOnZ = FALSE;
        }
        # .......................................................................................                    


      
        # .......................................................................................      
        # . Sort samples so that the shortest survival times are on the left.
        # . If distinct values of covariate Z are integer, first sort on Z
        # . before sorting on survival times.
        # .......................................................................................
        sBuf = sort(atForSort, decreasing = FALSE, index.return = TRUE);
        indexSort = sBuf[["ix"]];      # Sort index.

        ASort = ASel[ , indexSort];    # Sorted on columns.
        azSort = az[indexSort];        # Values of Z in same order as sorted samples.
        # .......................................................................................
        # . Samples sorted, genes not clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        if (!flagSortOnZ) {
          pname = paste("Test set: ", gl$m, " selected genes. Samples sorted ",
                        " with increasing survival times left-to-right.",
                        " Genes not clustered.", sep = "");
          caption = paste(gl$m, " sel. genes. Samples sorted increas. surv. times LtR. Genes not clustered.",
                          sep = "");
        } else {
          pname = paste(gl$m, " selected genes. Samples sorted first on Z, then",
                               " with increasing survival times left-to-right.",
                               " Genes not clustered.", sep = "");
          caption = paste(gl$m, " sel. genes. Samples sort. on Z, then on increas. surv. times LtR. Genes not clust.",
                          sep = "");
        }
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx   jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
            
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................


      
      
        # .......................................................................................
        # . Samples sorted, genes clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        if (!flagSortOnZ) {
          pname = paste("Test set: ", gl$m, " selected genes. Samples sorted ",
                        " with increasing survival times left-to-right.",
                        " Genes clust.", sep = "");
          caption = paste(gl$m, " sel. genes. Samples sorted increas. surv. times LtR. Genes clust.",
                          sep = "");
        } else {
          pname = paste(gl$m, " selected genes. Samples sorted first on Z, then",
                               " with increasing survival times left-to-right.",
                               " Genes clust.", sep = "");
          caption = paste(gl$m, " sel. genes. Samples sort. on Z, then on increas. surv. times LtR. Genes clust.",
                          sep = "");
        }
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }
            
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'yes',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................



        # .......................................................................................      
        # . Generate a bar that indicates values of Z in final sorting order for the heat
        # . map columns.
        # .......................................................................................
        if (flagSortOnZ) {
          azSort = az[indexSort];               # Values of Z in same order as sorted samples.
          azSort = matrix(azSort, nrow = 1);    # Make into matrix, for bar.
          azSort = rbind(azSort, azSort);       # It needs at least two rows for the heat map.
          # .......................................................................................
          # . Generate file name :      
          # .......................................................................................
          fname = File.generateRandomName(dirName, stemName, ext = "jpg");

          pname = paste("Test set : indicator bar for Z values in sorting order ",
                        " of the preceding heat map columns.", sep = "");

          afile = c(afile, fname);
          aplot = c(aplot, pname);
          # .......................................................................................
          # . Plot here :
          # .......................................................................................
          if (flagWrite == 'yes') {
            #xxxx jpeg(fname);              # Turn on plot device.
            jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
          }
            
          SuperPcDiag.plotGeneDataMatrix(ax = azSort, caption = pname);
          # .....................................................................................
          # . Close device or prompt user for next plot :      
          # .......................................................................................
          if (flagWrite == 'yes') {
            dev.off();
          } else if (flagWrite == 'no') {
            buf = readline(">>Enter a carriage return to continue: ");    # Pause.
          }
          # .......................................................................................        
        }
        # ..........................................................................................
      }
      # ......................................................................................................
      # . END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS
      # ......................................................................................................



      
      # .......................................................................................
      # . Survival times and covariate values under the sort key :
      # .
      # . Generate file name :
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      # .......................................................................................
      # . Select captions based on clustering scheme :
      # .......................................................................................      
      pname = paste("Test set survival times and covariate values with samples sorted", sep = ""); 
      afile = c(afile, fname);
      aplot = c(aplot, pname);                        
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }

      atSort = at[indexSort];       # Sorted survival times.
      azSort = az[indexSort];       # Sorted covariate values.
      acSort = asample[indexSort];  # Corresponding sample names.
      
      par(mfrow = c(2,1));

      plot(atSort, xaxt = 'n', xlab = 'sorted samples');
      axis(side = 1, at = 1:length(acSort), labels = acSort);
      
      plot(azSort, xaxt = 'n', xlab = 'sorted samples');
      axis(side = 1, at = 1:length(acSort), labels = acSort);      

      par(mfrow = c(1, 1));      
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }                  
      # .......................................................................................


     

      # ...................................................................................
      # . Compute the log-hazard ratios, using the trining set model :
      # .          sl$Y = n * m matrix of expression values.
      # .     sl$aloghR = n matrix of log-hazard-ratios.
      # ...................................................................................      
      sl = Glmnet.computeCoxLogHazardWithCovAndPred(gl, dfX, az, hRC);            
      # ...................................................................................


      

      # .......................................................................................
      # . Plot the hazard ratios estimated based on actual covariate values, against the samples :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = 'Test set estimated hazard ratios';
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
            
      ylim = c(0.0, max(sl$ahR));

      if (sl$flagPred) {
        ahRBuf = sl$ahR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
      } else {
        ahRBuf = sl$ahR;
      }
      
      plot(ahRBuf, xlab = 'Index (sample)', ylab = 'Hazard ratio',
           main = 'Test set estimated hazard ratios', ylim = ylim,
           xaxt = 'n');

      axis(side = 1, at = 1:length(asample), labels = asample);
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................


      
      
     
      # .......................................................................................
      # . Scatter plot of survival times against estimated log-hazard-ratio :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Test set survival time versus log hazard ratio";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      if (sl$flagPred) {
        aloghRBuf = sl$aloghR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
      } else {
        aloghRBuf = sl$aloghR;
      }
      
      xlab = "log hazard ratio (estimated)";
      ylab = "Survival time";
      plot(aloghRBuf, at, type = 'p', xlab = xlab, ylab = ylab, main = pname);
      abline(v = 0.0);
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................




      
      # ....................................................................................
      # . Plot survival times versus predicted DloghR = loghR(Z=1) - loghR(Z=0) :
      # .......................................................................................
      msg = Cox.checkBinary(az);                     # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg == 'ok') {
        # ....................................................................................
        # . Generate file name:
        # ....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test set survival times vs predicted DloghR";
        afile = c(afile, fname);
        aplot = c(aplot, pname);      
        # ....................................................................................
        # . Plot here :
        # ....................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Compute DloghR :
        # .....................................................................................
        aDloghR = sl$aDloghRz;               # This is DloghR = loghR(Z = 1) - loghR(Z = 0).

        acol = ifelse(az == 1, 'blue', 'red');
        # .....................................................................................
        # . For the feature selection level that maximizes significance :
        # . Plot survival times againsts DloghR.
        # .....................................................................................
        ymin = 0.0;
        ymax = 1.1 * max(at);

        xmax = max(aDloghR);
        xmin = min(aDloghR);
        
        caption = paste('Surv. time versus predicted DloghR: ');

        temp1 = paste('mtop = ', gl$mtop,
                        ', hRC = ', sprintf("%8.3e", hRC) , sep = "");

        caption = paste(caption, temp1, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aDloghR, at, ylim = c(ymin, ymax),
             type = 'p', xlab = 'predicted DloghR = loghR(Z = 1) - loghR(Z =0)',
             ylab = 'survival time', main = caption, col = acol, pch = 19);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);

        abline(v = 0);                           # Abcissa.
        temp1 = log(hRC);
        abline(v = temp1, lty = 'dashed');       # Boundary for determining sensitive patients.
        # ......................................................................................
        # . Add the legend here:
        # ......................................................................................
        xtemp1 = xmax - 0.2 * (xmax - xmin);
        ytemp1 = ymax;
        
        legendText = c("Z = 0", "Z = 1");
        colVector = c('red', 'blue');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = xtemp1, y = ytemp1,
               legend = legendText, col = colVector, pch = pchVector, bty = 'n');
        # ......................................................................................
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # ....................................................................................        
      }
      # .......................................................................................      



      

     
      # .......................................................................................
      # . Plot prediction of sample sensitivity vs sample index.
      # . These are the samples for which predicted DloghR <= log(hRC).
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test set sensitivity status vs sample index";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ylim = c(0, 1);

        acol = ifelse(az == 0, 'red', 'blue');
        
        plot(sl$aflagSensitiveZ, xlab = 'Index (sample)', ylab = 'Sensitivity',
             main = 'Test set sensitivity prediction', ylim = ylim, col = acol,
             xaxt = 'n', pch = 19);

        axis(side = 1, at = 1:length(asample), labels = asample);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................




      # .......................................................................................
      # . Flag patients predicted sensitive, UN-sorted sample order; generate a heat
      # . map with bars. For two-armed studies only.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {      
        aflag = sl$aflagSensitiveZ;                 # The {0, 1} flags, not sorted. 1 = sensitive, 0 = not sensitive.
        aflag = ifelse(aflag == 1, 0.65, aflag);        

        aflag = matrix(aflag, nrow = 1);            # Make into matrix.
        aflag = rbind(aflag, aflag);                # It needs at least two rows for the heat map.
        # .......................................................................................      
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        pname = paste("Test set: flag sensitive patients, hRC = ", hRC,
                      ", original sample order, red = sensitive", sep = ""); 
        afile = c(afile, fname);
        aplot = c(aplot, pname);                        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        SuperPcDiag.plotGeneDataMatrix(ax = aflag, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .....................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .....................................................................................
      }
      # .......................................................................................

            

      


      # .......................................................................................
      # . Flag patients predicted sensitive, SORTED sample order; generate a heat
      # . map with bars.
      # . For two-armed studies only.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {      
        aflagSort = sl$aflagSensitiveZ[indexSort];       # The {0, 1} flags, sorted. 1 = sensitive, 0 = not sensitive.
        aflagSort = ifelse(aflagSort == 1, 0.65, aflagSort);
        
        acSort = asample[indexSort];                     # Corresponding sample names.

        aflagSort = matrix(aflagSort, nrow = 1);         # Make into matrix, for bar.
        aflagSort = rbind(aflagSort, aflagSort);         # It needs at least two rows for the heat map.
        # .......................................................................................      
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        pname = paste("Test set: flag sensitive patients, hRC = ", hRC,
                      ", sorted sample order, red = sensitive", sep = ""); 
        afile = c(afile, fname);
        aplot = c(aplot, pname);                        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx          jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.	
        }

        SuperPcDiag.plotGeneDataMatrix(ax = aflagSort, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .....................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .....................................................................................
      }
      # .......................................................................................

      



#      # .......................................................................................
#      # . Survival curves for Z = 0 and Z = 1 arms with ALL samples
#      # . (for two-arm studies only):
#      # .......................................................................................
#      msg = Cox.checkBinary(az);

#      if (msg == 'ok') {
#        # .......................................................................................
#        # . Generate file name :      
#        # .......................................................................................
#        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
#        pname = paste("Test set : survival curves for all patients", sep = "");
#        afile = c(afile, fname);
#        aplot = c(aplot, pname);
#        # .......................................................................................
#        # . Turn on plot device :
#        # .......................................................................................
#        if (flagWrite == 'yes') {
#          jpeg(fname);              # Turn on plot device.
#        }
#        # .......................................................................................
#        # . Subset to sensitive samples only :
#        # .......................................................................................
#        legend_0 = "Z = 0";
#        legend_1 = "Z = 1";
#        caption = pname;
        
#        SuperPcDiag.plotSurvivalOnBinary(at, as, az, legend_0, legend_1, caption);
#        # .....................................................................................
#        # . Close device or prompt user for next plot :      
#        # .......................................................................................
#        if (flagWrite == 'yes') {
#          dev.off();
#        } else if (flagWrite == 'no') {
#          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
#        }
#        # .......................................................................................
#      }
#      # .......................................................................................


      


#      # .......................................................................................
#      # . Survival curves for Z = 0 and Z = 1 arms of the sensitive samples, only :
#      # . component (for two-arm studies only):
#      # .......................................................................................
#      msg = Cox.checkBinary(az);

#      if (msg == 'ok') {
#        # .......................................................................................
#        # . Plot the survival curves only if a sensitive subpopulation has been identified :
#        # .......................................................................................
#        nsens = sum(sl$aflagSensitiveZ == 1);          # Number of samples predicted sensitive.
        
#        if (nsens > 0) {
#          # .......................................................................................
#          # . Generate file name :      
#          # .......................................................................................
#          fname = File.generateRandomName(dirName, stemName, ext = "jpg");
#          pname = paste("Test set : survival curves for sensitive patients only", sep = "");
#          afile = c(afile, fname);
#          aplot = c(aplot, pname);
#          # .......................................................................................
#          # . Turn on plot device :
#          # .......................................................................................
#          if (flagWrite == 'yes') {
#            jpeg(fname);              # Turn on plot device.
#          }
#          # .......................................................................................
#          # . Subset to sensitive samples only :
#          # .......................................................................................
#          atSens = at[sl$aflagSensitiveZ == 1];
#          asSens = as[sl$aflagSensitiveZ == 1];
#          azSens = az[sl$aflagSensitiveZ == 1];                

#          legend_0 = "Z = 0";
#          legend_1 = "Z = 1";
#          caption = pname;
        
#          SuperPcDiag.plotSurvivalOnBinary(atSens, asSens, azSens, legend_0, legend_1, caption);
#          # .....................................................................................
#          # . Close device or prompt user for next plot :      
#          # .......................................................................................
#          if (flagWrite == 'yes') {
#            dev.off();
#          } else if (flagWrite == 'no') {
#            buf = readline(">>Enter a carriage return to continue: ");    # Pause.
#          }
#          # .......................................................................................
#        }
#        # .......................................................................................        
#      }
#      # .......................................................................................
      


     

      # .......................................................................................
      # . Survival curves for Z = 0 and Z = 1 arms :
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Test set survival curves", sep = "");
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # . Set number of plots :
        # .......................................................................................
        par(mfrow = c(2, 2));
        # .......................................................................................
        # . 1. All samples :
        # .......................................................................................
        legend_0 = "Z = 0";
        legend_1 = "Z = 1";
        caption = pname;
        
        SuperPcDiag.plotSurvivalOnBinary(at, as, az, legend_0, legend_1, caption);
        # .......................................................................................
        # . 2. Subset to sensitive samples only :
        # .......................................................................................
        nBuf = sum(sl$aflagSensitiveZ == 1);          # Number of samples predicted sensitive.

        if (nBuf > 0) {
          atBuf = at[sl$aflagSensitiveZ == 1];
          asBuf = as[sl$aflagSensitiveZ == 1];
          azBuf = az[sl$aflagSensitiveZ == 1];                

          legend_0 = "Z = 0";
          legend_1 = "Z = 1";
          caption = paste(pname, ": sensitive group", sep = "");
        
          SuperPcDiag.plotSurvivalOnBinary(atBuf, asBuf, azBuf, legend_0, legend_1, caption);
        }
        # .......................................................................................
        # . 3. Subset to resistant samples only :
        # .......................................................................................
        nBuf = sum(sl$aflagSensitiveZ == 0);          # Number of samples predicted resistant.

        if (nBuf > 0) {        
          atBuf = at[sl$aflagSensitiveZ == 0];
          asBuf = as[sl$aflagSensitiveZ == 0];
          azBuf = az[sl$aflagSensitiveZ == 0];                

          legend_0 = "Z = 0";
          legend_1 = "Z = 1";
          caption = paste(pname, ": resistant group", sep = "");
        
          SuperPcDiag.plotSurvivalOnBinary(atBuf, asBuf, azBuf, legend_0, legend_1, caption);
        }
        # .......................................................................................
        # . 4. Plot 4 survival curves in one graph :
        # .......................................................................................
        alZ = c('0', '1');
        alR = c('R', 'S');
        caption = paste(pname, ": sensitive and resistant", sep = "");
        
        SuperPcDiag.plotSurvivalOnTwoBinaries(at, as, az, sl$aflagSensitiveZ, alZ, alR, caption = caption);        
        # .......................................................................................
        # . Reset number of plots :
        # .......................................................................................
        par(mfrow = c(1, 1));        
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      
    



      # ................................................................................................
      # . Survival curves for Z = 0 and Z = 1 arms X {S, R} status :
      # . (for two-arm studies only):
      # ................................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Test set survival curves for sensitive and resistant patients", sep = "");
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Turn on plot device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
        # .......................................................................................
        # .   Plot 4 survival curves in one graph :
        # .......................................................................................
        alZ = c('0', '1');
        alR = c('R', 'S');
        caption = "Test set sensitive and resistant";
        SuperPcDiag.plotSurvivalOnTwoBinaries(at, as, az, sl$aflagSensitiveZ, alZ, alR, caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................        
      }
      # .....................................................................................................
      



      
      
      # .......................................................................................
      # . Plot survival curves :  global comparison. This gets plotted only for non-binary
      # . external covariate.
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg != 'ok') {
        # .......................................................................................
        # . Generate file name :            
        # .......................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Survival curves";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1,1));
        # .......................................................................................                
        # . >> ALL samples :
        # .......................................................................................        
        caption ="All test set samples";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at, as, aloghRBuf, caption);        
        # .......................................................................................
        par(mfrow = c(1,1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }        
      # .......................................................................................



      
      
      # .......................................................................................
      # . Plot survival curves : for two-arm studies only, separately investigate
      # . survival curves splitr on median predicted log-hazard-ratio.
      # .       cs1 = Cox.computeCoxOnSplitLoghR(at1, as1, aloghR_buf1);      
      # .......................................................................................
      msg = Cox.checkBinary(az);

      if (msg == 'ok') {
        # .......................................................................................
        # . Get the log-hazard-ratios :
        # .......................................................................................              
        if (sl$flagPred) {
          aloghRBuf = sl$aloghR[ , 1];    # The first column contains the estimated hazard ratios for the actual Z value.
        } else {
          aloghRBuf = sl$aloghR;
        }
        # .......................................................................................      
        # . Generate file name :            
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test set survival plots for separate arms of binary study";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Start plots here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(2,2));
        # .......................................................................................
        # . Define the subsets and plot for each :
        # . >> Z = 0:
        # .......................................................................................        
        at0 = at[az == 0];
        as0 = as[az == 0];
        aloghR0 = aloghRBuf[az == 0];

        caption ="Z = 0 arm";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at0, as0, aloghR0, caption);
        # .......................................................................................                
        # . >> Z = 1 :
        # .......................................................................................        
        at1 = at[az == 1];
        as1 = as[az == 1];
        aloghR1 = aloghRBuf[az == 1];        
        caption ="Z = 1 arm";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at1, as1, aloghR1, caption);
        # .......................................................................................                
        # . >> ALL samples (repeated here for reference) :
        # .......................................................................................        
        caption ="All samples";
        SuperPcDiag.plotSurvivalOnSplitLoghR(at, as, aloghRBuf, caption);        
        # .......................................................................................
        # . End the plots here:
        # .......................................................................................
        par(mfrow = c(1,1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................            


      
      
      # .......................................................................................
      # . Final tally :
      # .......................................................................................      
      nplot = length(afile);
     
      if (flagWrite == 'yes') {
        cat(" ..........  ", nplot, " jpeg plot files were generated.\n", sep = "");
      }
      # .......................................................................................

      
      
      # ....................................................................
      # . Package file names and plot names into list.
      # . Note that these are generated (with dummy names in that case)
      # . even if flagWrite = 'no'.
      # .
      # .   nplot = total number of plots in array.
      # .   afile = array of file names.
      # .   aplot = array of corresponding plot names.
      # ....................................................................
      sp = list(nplot = nplot, afile = afile, aplot = aplot);

      class(sp) = 'glmnet.diag.plot';
      # ....................................................................
      
     
      # ...........
      return (sp);
      # ...........

}

# =================================================================================================
# . End of GlmnetDiag.plotCoxWithCovOnTest.
# =================================================================================================






# =========================================================================================================================
# . GlmnetDiag.writeCoxCvWithCov : writes Cox cross-validation results to the specified file.
# . -----------------------------
# .                          
# .   Syntax:
# .           GlmnetDiag.writeCoxCvWithCov(cv, fs);
# .
# .   In:
# .        cv = result of a cross-validation calculation, returned by call to
# .             GlmnetCv.crossValidateCoxWithCov().
# .        fs = output file name.
# .
# =========================================================================================================================

GlmnetDiag.writeCoxCvWithCov <- function(cv, fs)
{

      # ...........................................................
      if (class(cv) != "glmnet.cox.cov.cv") {
        msg = "ERROR: from GlmnetDiag.writeCoxCvWithCov: ";
        msg = paste("The input cv is not of class glmnet.cox.cov.cv.");
        stop(msg);
      }
      # ...........................................................

      
      # ................................................................
      cat(" ..........  Entry in GlmnetDiag.writeCoxCvWithCov.\n");
      # ................................................................


      # ................................................................
      # . Open output file :
      # ................................................................
      FS = file(fs, "w");
      # ................................................................      
      
      
      # ................................................................
      # . >> PREAMBLE:
      # . Generate a text string containing the model summary :
      # ................................................................
      buf = "#PREAMBLE:\n";
      cat(buf, file = FS);
      
      txtSummary = GlmnetDiag.generateCoxCvWithCovSummary(cv);
      cat(txtSummary, file = FS);

      buf = "\n";
      cat(buf, file = FS);
      cat(buf, file = FS);       
      # ................................................................      

      
      # ................................................................
      # . Define the array and label for the x axis :
      # ................................................................
      aScan = cv$alambda;
      xlab = 'lambda';
      nScan = length(aScan);
      # ................................................................
      

     
      # ..........................................................................
      # . Write to file here :
      # ..........................................................................
      buf = "#TABLE 1: cross-validation statistics as a function of scanned parameter:\n";
      cat(buf, file = FS);

      buf = paste("#---------------------------------------------------------------------\n", sep = "");
      cat(buf, file = FS);      
      # ..........................................................................
      # . Write header :
      # ..........................................................................            
      buf = paste("#", xlab, sep = "");

      buf = paste(buf, "\tpRMin", sep = "");
      buf = paste(buf, "\thRMin", sep = "");      
      buf = paste(buf, "\thRC", sep = "");
      buf = paste(buf, "\tnMin", sep = "");      

      buf = paste(buf, "\n", sep = "");
      cat(buf, file = FS);            
      # ..........................................................................
      # . Write body :
      # ..........................................................................      
      for (j in 1:nScan) {
        buf = paste(aScan[j], sep = "");

        buf = paste(buf, "\t", sprintf("%10.5e", cv$apRMin[j]), sep = "");
        buf = paste(buf, "\t", sprintf("%10.5e", cv$ahRMin[j]), sep = "");        
        buf = paste(buf, "\t", sprintf("%10.5e", cv$ahRC[j]), sep = "");
        buf = paste(buf, "\t", sprintf("%10.5e", cv$aicMin[j]), sep = "");                       
        
        buf = paste(buf, "\n", sep = "");
        cat(buf, file = FS);            
      }

      buf = paste("#---------------------------------------------------------------------\n", sep = "");
      cat(buf, file = FS);       
      # ..........................................................................      

      
      # .........
      close(FS);
      # .........      
     

      # ...........................................................................      
      cat(" ..........  Wrote Cox cross-validation results : ", fs, "\n", sep = "");
      # ...........................................................................
      
      
      # ...........
      return (0);
      # ...........

}

# =========================================================================================================================
# . End of GlmnetDiag.writeCoxCvWithCov.
# =========================================================================================================================






# =========================================================================================================================
# . GlmnetDiag.generateCoxCvWithCovSummary : generates a text string containing a summary of results 
# . ---------------------------------------   from the supervised principal components cross-validation,
# .                                           for the case with external covariate.
# .   Syntax:
# .        txt = GlmnetDiag.generateCoxCvWithCovSummary(cv);
# .
# .   In:
# .         cv = result of cross-validation, as returned by function
# .              GlmnetCv.crossValidateCoxWithCov().
# .
# .   Out:
# .        txt = contains listing of input parameters, feature selection results,
# .              svd results, and global and detailed results for the Cox propotional
# .              hazard model.
# .
# =========================================================================================================================

GlmnetDiag.generateCoxCvWithCovSummary <- function(cv)
{

      # .....................................................................................
      if (class(cv) != "glmnet.cox.cov.cv") {
        msg = "ERROR: from GlmnetDiag.generateCoxCvWithCovSummary: ";
        msg = paste("The input cv is not of class glmnet.cox.cov.cv");
        stop(msg);
      }
      # .....................................................................................      

  
      # ...........................................................................................
      buf = paste("#Cross-validation of Coxnet regression model :\n", sep = "");
      # ............................................................................................




      # ......................................................................................
      # . Parameters used in the computation, and results of the feature selection :
      # ......................................................................................
      buf = paste(buf, "#General Parameters:\n", sep = "");      
      buf = paste(buf, "#Number of samples in the input training set: n = " , cv$n, "\n", sep = "");
      buf = paste(buf, "#Number of genes in the input training set: p = " , cv$p, "\n", sep = "");

      if (cv$flagFs == 'yes') {
        buf = paste(buf, "#First-pass feature selection method: methodFs = mtop\n", sep = "");  
        buf = paste(buf, "#Type of P-value used in feature selection: typePval = ", cv$typePval, "\n", sep = "");
        buf = paste(buf, "#Number of genes retained in first pass: mtop = ", cv$mtop, "\n", sep = "");
      } else {
        buf = paste(buf, "#First-pass feature selection method: NONE used.\n", sep = "");          
      }
      
      buf = paste(buf, "#Method for splitting the data: methodSplit = ", cv$methodSplit, "\n", sep = "");

      if (cv$methodSplit == 'vfoldStrict') {
        buf = paste(buf, "#Fraction put into test set: ft = ", cv$ft, "\n", sep = "");
        buf = paste(buf, "#Random number generator seed: rngSeed = ", cv$rngSeed, "\n", sep = "");
      }

      buf = paste(buf, "#Number of lambda values: nlambda = ", cv$nlambda, "\n", sep = "");
      
      buf = paste(buf, "#Cross-validation train-test breakdown (approximate):\n", sep = "");
      buf = paste(buf, "#n(total)\tntrain\tntest\n", sep = "");
      buf = paste(buf, cv$n, "\t", cv$ntrain, "\t", cv$ntest, "\n", sep = "");             
      buf = paste(buf, "\n", sep = "");      
      buf = paste(buf, "#Parameter scanned: lambda\n", sep = "");
      buf = paste(buf, "#Number of tuning parameter levels: nScan = ", cv$nScan, "\n", sep = "");      
      buf = paste(buf, "#Actual number of cross-validation splits: ncvHere = ", cv$ncvHere, "\n", sep = "");
      # ......................................................................................

      

      # ................................................................................................................
      # . Extract optimized feature selection parameter :
      # . At the given feature selection level.
      # . 
      # . >> 1. Significance for *prognostic* estimates on collected test sets, with the
      # . z = 0 and z = 1 treatment arms considered separately.
      # .................................................................................................................
      buf = paste(buf, "\n", sep = "");
      buf = paste(buf, "# 1. PROGNOSTIC ESTIMATES ON COLLECTED TEST SETS:\n", sep = "");
      # ..................................................................................................................
      # . z = 0 treatment arm:
      # ..................................................................................................................
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");      
      jmin0 = which.min(cv$apR0);
      pR0Min = cv$apR0[jmin0];        # Most significant prognostic estimate for z = 0 arm.
      hR0Min = cv$ahR0[jmin0];        # Corresponding hazard ratio for z = 0 arm.
      
      lambdaMin0 = cv$alambda[jmin0];
      buf = paste(buf, "#Z = 0 arm: lambdaMin0 = ", lambdaMin0, "\n", sep = "");
      buf = paste(buf, "pR0Min = ", sprintf("%8.3e", pR0Min), "\n", sep = "");
      buf = paste(buf, "hR0Min = ", sprintf("%8.3e", hR0Min), "\n", sep = "");
      # .................................................................................................................
      # . z = 1 treatment arm:
      # .................................................................................................................
      jmin1 = which.min(cv$apR1);
      pR1Min = cv$apR1[jmin1];        # Most significant prognostic estimate for z = 1 arm.
      hR1Min = cv$ahR1[jmin1];        # Corresponding hazard ratio for z = 1 arm.
      
      lambdaMin1 = cv$alambda[jmin1];
      
      buf = paste(buf, "\n", sep = "");
      buf = paste(buf, "#Z = 1 arm: lambdaMin0 = ", lambdaMin1, "\n", sep = "");


      buf = paste(buf, "pR1Min = ", sprintf("%8.3e", pR1Min), "\n", sep = "");
      buf = paste(buf, "hR1Min = ", sprintf("%8.3e", hR1Min), "\n", sep = "");
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      buf = paste(buf, "#By prognostic estimates, we mean that in the z = 0 and z = 1 treatment arms considered\n", sep = "");
      buf = paste(buf, "#separately, we predict hazard ratios on the basis of gene expression alone and.\n", sep = "");
      buf = paste(buf, "#ask how well they correlate with the observed data:\n", sep = "");
      buf = paste(buf, "\n", sep = "");      
      # ................................................................................................................
      # . >> 2. Significance for *predictive* estimate on collected test sets, with the
      # . two treatment arms considered together.
      # ................................................................................................................
      buf = paste(buf, "\n", sep = "");      
      buf = paste(buf, "# 2. PREDICTIVE ESTIMATES ON COLLECTED TEST SETS:\n", sep = "");
      # ...............................................................................................
      # . Basic optimizations here :
      # ...............................................................................................      
      jmin = which.min(cv$apRMin);    # Feature selection level that maximizes significance.
      pRMin = cv$apRMin[jmin];        # Minimum P-value at optimal thresholding between z = 1 and z = 0 sub-populations.  
      hRMin = cv$ahRMin[jmin];        # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.           
      hRCMin = cv$ahRC[jmin];         # Optimal cut: subset at predicted lambda(z = 1) / lambda(z = 0) <= hRC
                                      # to minimize the P-value.
      nMin = cv$aicMin[jmin];         # Number of samples actually used in the comparison.
      
      lambdaMin = cv$alambda[jmin];
      # ...............................................................................................
      # . Now display :
      # ...............................................................................................      
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");      

      buf = paste(buf, "lambdaMin = ", lambdaMin, "\n", sep = "");

      buf = paste(buf, "hRCMin = ", sprintf("%8.3e", hRCMin), "\n", sep = "");
      buf = paste(buf, "nMin = ", nMin, "\n", sep = "");
      buf = paste(buf, "n = ", cv$n, "\n", sep = "");            
      buf = paste(buf, "pRMin = ", sprintf("%8.3e", pRMin), "\n", sep = "");
      buf = paste(buf, "hRMin = ", sprintf("%8.3e", hRMin), "\n", sep = "");
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      # ......................................................................................
      # . Same as above, but with elaborate explanations :
      # ......................................................................................      
      buf = paste(buf, "#By predictive estimates, we mean that we use the Cox regression model to predict\n", sep = "");
      buf = paste(buf, "#in the collected test sets those patients most likely to respond with longer\n", sep = "");
      buf = paste(buf, "#survival times to the Z = 1 treatment arm than to the Z = 0 treatment arm.\n", sep = "");
      buf = paste(buf, "#The criterion for sensitivity is that the relative predicted hazard ratio,\n", sep = "");
      buf = paste(buf, "#hR(z = 1) / hR(z = 0) <= hRC, where the threshold hRC is an adjustable parameter.\n", sep = "");
      buf = paste(buf, "#For samples predicted to be sensitive, we then compare actual survival times in the two\n", sep = "");
      buf = paste(buf, "#treatment arms. We report here the value of feature selection, and hRC, to minimize P-value\n", sep = "");
      buf = paste(buf, "#for this comparison.\n", sep = "");            

      buf = paste(buf, "#\n", sep = "");      
   

      buf = paste(buf, "#Coxnet model:", sep = "");
      
      buf = paste(buf, " lambda = lambdaMin = ", lambdaMin, " for maximum significance.\n", sep = "");

      buf = paste(buf, "#Selecting for sensitive patients with predicted differential\n", sep = "");
      buf = paste(buf, "#hazard ratio lambda(z = 1) / lambda(z = 0) <= hRC yields the most\n", sep = "");
      buf = paste(buf, "#significant split between actual z = 0 and z =1 treatment arms\n", sep = "");
      buf = paste(buf, "#for the value of hRC given below:\n", sep = "");      
      
      buf = paste(buf, "#Optimal upper threshold on differential log-hazard-ratio for selecting sensitive patients:\n", sep = "");
      buf = paste(buf, "hRC = ", sprintf("%8.3e", hRCMin), "\n", sep = "");
      buf = paste(buf, "#Number of sensitive patients selected under that threshold:\n", sep = "");
      buf = paste(buf, "nMin = ", nMin, " (out of ", cv$n, ")\n", sep = "");      
      buf = paste(buf, "#P-value for difference in survival in sensitive patients, between z = 1 and z = 0 populations:\n", sep = "");
      buf = paste(buf, "pRMin = ", sprintf("%8.3e", pRMin), "\n", sep = "");
      buf = paste(buf, "#Corresponding hazard-ratio between z = 1 and z = 0 populations:\n", sep = "");
      buf = paste(buf, "hRMin = ", sprintf("%8.3e", hRMin), "\n", sep = "");      
      # ......................................................................................            

      
      # .............
      return (buf);
      # .............

}

# =========================================================================================================================
# . End of GlmnetDiag.generateCoxCvWithCovSummary.
# =========================================================================================================================






# =================================================================================================
# . GlmnetDiag.plotCoxCvWithCov : plots training and cross-validated log-likelihoods against the model
# . ----------------------------   parameter scanned in the cross-validation of the Cox model with
# .                                external covariate.
# .   Syntax:
# .
# .       sp = GlmnetDiag.plotCoxCvWithCov(cv, flagWrite, dirName, stemName);
# .
# .   In:
# .        cv = result of a cross-validation calculation, returned by function
# .             GlmnetCv.crossValidateCoxWithCov().
# .
# .     flagWrite = no/yes : flag indicating whether plots should be written to file in jpeg
# .                 format instead of being displayed.
# .                 If value is 'yes', each plot will be written to a file in the directory
# .                 indicated by 'dirName', with a name given by 'stemName' followed by
# .                 a random string and the .jpg extension.
# .                 If value is 'no', the user is prompted to interactively provide carriage
# .                 returns to march through the display.
# .
# .       dirName = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .      stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .   Out:
# .       Produces plots of the training and cross-validated log-likelihoods against the model
# .       parameter scanned in the cross-validation.
# .
# .           - If flagWrite = 'no', displays a series of plots. The use enter carriage returns
# .           to advance from one plot to the next.
# .           Object sp returned is NULL.
# .
# .           - If flagWrite = 'yes', generates a series of plot files, as indicated above.
# .           Object sp returned is a list with members:
# .
# .                  nplot = number of plot files generated.
# .                  afile = array of file names.
# .                  aplot = array of plot names.
# .
# .
# =================================================================================================

GlmnetDiag.plotCoxCvWithCov <- function(cv,
                                        flagWrite = 'no',
                                        dirName = NULL, stemName = NULL)
{

      # ...........................................................
      if (class(cv) != "glmnet.cox.cov.cv") {
        msg = "ERROR: from GlmnetDiag.plotCoxCvWithCov: ";
        msg = paste("The input cv is not of class glmnet.cox.cv.");
        stop(msg);
      }
      # ...........................................................

      
      # ................................................................
      cat(" ..........  Entry in GlmnetDiag.plotCoxCvWithCov.\n");
      # ................................................................

      
      # .............................................................
      stopifnot((flagWrite == 'no') || (flagWrite == 'yes'));
      # .............................................................
      

      # .......................................................................................
      if (flagWrite == 'no') {
        cat("\n");
        cat(" ..........  Enter carriage returns as indicated to generate plots one-by-one.\n");
      } else if (flagWrite == 'yes') {
        cat(" ..........  Generating plot files in directory = ", dirName, "\n", sep = "");
      }
      # .......................................................................................


      # ...........................................................
      # . Initialize plot arrays :
      # ...........................................................
      afile = c();
      aplot = c();

      if (flagWrite == 'no') {
        dirName = "foo";        # Dummy value.
        stemName = "dum";       # Dummy value.
      }
      # ...........................................................


      # .......................................................................................
      if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................
      
     
      
      # ................................................................
      # . Define the array for the x axis :
      # ................................................................
      aScan = cv$alambda;
      xlab = 'lambda';
      # ................................................................
      

      
      
      
      # ....................................................................................
      # . >>PROGNOSTIC ESTIMATES :
      # . Plot the P-values for median log-hazard-ratio splits on the Z = 0 and Z = 1
      # . treatment arms separately.
      # .......................................................................................
      msg = Cox.checkBinary(cv$azBIG);   # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg == 'ok') {
        # ....................................................................................
        # . Generate file name:
        # ....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "prognostic estimates on collected test sets";        
        afile = c(afile, fname);
        aplot = c(aplot, pname);      
        # ....................................................................................
        # . Plots here :
        # ....................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(2, 2));
        # .....................................................................................
        # . P-values for splits of the Z = 0 arm of the collected test sets :
        # .....................................................................................
        amlog10pR0 = Stat.getMlog10(cv$apR0);

        ymin = 0.0;
        ymax = 1.1 * max(amlog10pR0);

        caption = paste('P-values for splits of Z = 0 arm');

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aScan, amlog10pR0, ylim = c(ymin, ymax),
             type = 'l', xlab = xlab, ylab = '-log10(pR0)', main = caption);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);
        # .....................................................................................
        # . Hazard ratios for splits of the Z = 0 arm of the collected test sets :        
        # .....................................................................................
        ymin = 0.0;
        ymax = 1.1 * max(cv$ahR0);

        caption = paste('Hazard-ratios for splits of Z = 0 arm');            

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aScan, cv$ahR0, ylim = c(ymin, ymax),
             type = 'l', xlab = xlab, ylab = 'hR0', main = caption);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . P-values for splits of the Z = 1 arm of the collected test sets :
        # .....................................................................................
        amlog10pR1 = Stat.getMlog10(cv$apR1);

        ymin = 0.0;
        ymax = 1.1 * max(amlog10pR1);

        caption = paste('P-values for splits of Z = 1 arm');

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aScan, amlog10pR1, ylim = c(ymin, ymax),
             type = 'l', xlab = xlab, ylab = '-log10(pR1)', main = caption);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);
        # .....................................................................................
        # . Hazard ratios for splits of the Z = 1 arm of the collected test sets :        
        # .....................................................................................
        ymin = 0.0;
        ymax = 1.1 * max(cv$ahR1);

        caption = paste('Hazard-ratios for splits of Z = 1 arm');            

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aScan, cv$ahR1, ylim = c(ymin, ymax),
             type = 'l', xlab = xlab, ylab = 'hR1', main = caption);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);      
        # ......................................................................................
        par(mfrow = c(1, 1));
        # ......................................................................................
        # . Add an over plot (sub) title :
        # ......................................................................................
        captionSub = "Prognostic estimates : separate on Z = 1 and Z = 0 arms";
        cex.main.OLD = par("cex.main");        
        par(cex.main = 1.0);         
        title(sub = captionSub);
        par(cex.main = cex.main.OLD);         
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # ....................................................................................        
      }
      # .......................................................................................      
      


      
      # ....................................................................................
      # . >>PREDICTIVE ESTIMATES, Part 1:
      # . Plot the P-value for the optimal hR <= hRC on the samples predicted
      # . to be sensitive in the collected test sets.
      # .......................................................................................
      msg = Cox.checkBinary(cv$azBIG);   # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg == 'ok') {
        # ....................................................................................
        # . Generate file name:
        # ....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Predictive estimates on collected test sets: behavior of pMin";
        afile = c(afile, fname);
        aplot = c(aplot, pname);      
        # ....................................................................................
        # . Plots here :
        # ....................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(2, 2));
        # .....................................................................................
        # . Minimum P-values from comparison of Z = 1 to Z = 0 treatment arms for samples 
        # . predicted sensitive in the collected test sets :
        # .....................................................................................
        amlog10pRMin = Stat.getMlog10(cv$apRMin);

        indexMin = which.min(cv$apRMin);
        zMin = aScan[indexMin];               # Feature selection level which yields the most significant Z = 1 to Z = 0 comparison.

        ymin = 0.0;
        ymax = 1.1 * max(amlog10pRMin);

        caption = paste('Minimum P-values for hR <= hRC');

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aScan, amlog10pRMin, ylim = c(ymin, ymax),
             type = 'l', xlab = xlab, ylab = '-log10(Pmin)', main = caption);
        abline(h = 0.0);
        abline(v = zMin, lty = 'dashed');        
        par(cex.main = cex.main.OLD);
        # .....................................................................................
        # . Hazard ratios corresponding to minimum P-values above, in Cox comparison
        # . of Z = 1 to Z = 0 treatment arms for collected test samples:
        # .....................................................................................
        abuf = log(cv$ahRMin);                        # Log-hazard-ratio.
        ymin = min(0.0, abuf);
        ymax = max(0.0, abuf);        
        #xxx ymin = 0.0;
        #xxx ymax = 1.1 * max(cv$ahRMin);

        caption = paste('Log-hazard-ratio for Z = 1 vs Z = 0, for hR <= hRC samples');            

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        #xxx plot(aScan, cv$ahRMin, ylim = c(ymin, ymax),
        #xxx type = 'l', xlab = xlab, ylab = 'hRMin', main = caption);
        plot(aScan, abuf, type = 'l', xlab = xlab, ylim = c(ymin, ymax),
             ylab = 'log(hRMin) = betaMLE', main = caption);        
        abline(h = 0.0);
        abline(v = zMin, lty = 'dashed');        
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Hazard-ratio thresholds from comparison of Z = 1 to Z = 0 treatment arms for samples 
        # . predicted sensitive in the collected test sets, for which P = Pmin :
        # .....................................................................................
        abuf = log(cv$ahRCBIG);                       # Log-hazard-ratio.
        ymin = min(0.0, abuf);
        ymax = max(0.0, abuf);
        #xxx ymax = 1.1 * max(cv$ahRCBIG);

        caption = paste('Threshold log(hRC) for which P = Pmin');            

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        #xxx plot(aScan, cv$ahRCBIG, ylim = c(ymin, ymax),
        #xxx      type = 'l', xlab = xlab, ylab = 'hRC', main = caption);
        plot(aScan, abuf, type = 'l', xlab = xlab, ylim = c(ymin, ymax),
             ylab = 'log(hRC)', main = caption);
        abline(h = 0.0);
        abline(v = zMin, lty = 'dashed');        
        par(cex.main = cex.main.OLD);
        # .....................................................................................
        # . Number of samples predicted sensitive for hR <= hRC :
        # .....................................................................................
        ymin = 0.0;
        ymax = 1.1 * max(cv$aicMinBIG);

        caption = paste('Number samples for hR <= hRC (n = ', cv$n, ')', sep = "");            

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aScan, cv$aicMinBIG, ylim = c(ymin, ymax),
             type = 'l', xlab = xlab, ylab = 'ncMin', main = caption);
        abline(h = 0.0);
        abline(v = zMin, lty = 'dashed');        
        par(cex.main = cex.main.OLD);      
        # ......................................................................................
        par(mfrow = c(1, 1));
        # ......................................................................................
        # . Add an over plot (sub) title :
        # ......................................................................................
        captionSub = "Predictive estimates : comparison of Z = 1 to Z = 0 arms";
        cex.main.OLD = par("cex.main");        
        par(cex.main = 1.0);         
        title(sub = captionSub);
        par(cex.main = cex.main.OLD);         
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # ....................................................................................        
      }
      # .......................................................................................      
      


      
      
      # ....................................................................................
      # . >>PREDICTIVE ESTIMATES Part 2 :
      # . Find the feature selection level that minimizes P-value.
      # . Plot Z = 1 to Z = 0 comparison P-value as a function of hRC :
      # .......................................................................................
      msg = Cox.checkBinary(cv$azBIG);   # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg == 'ok') {
        # ....................................................................................
        # . Generate file name:
        # ....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Predictive estimates on collected test sets: optimal feature selection level";
        afile = c(afile, fname);
        aplot = c(aplot, pname);      
        # ....................................................................................
        # . Plots here :
        # ....................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(2, 2));
        # .....................................................................................
        # . Determine the optimal feature selection level : this is the one that minimizes
        # . the P-value for Z = 1 to Z = 1 comparisons.
        # .....................................................................................
        jmin = which.min(cv$apRMin);     # Index of feature selection level which maximizes significance.

        hRC = cv$ahRCBIG[jmin];          # Upper bound for selecting patients predited to be sensitive.
        ncMin = cv$aicMinBIG[jmin];      # Number of patients selected by hR <= hRC filter.
        pRMin = cv$apRMin[jmin];         # P-value for Z = 1 to Z = 1 comparisons, at best hRC.
        hRMin = cv$ahRMin[jmin];         # hazard ratio for Z = 1 to Z = 1 comparisons, at best hRC.
        # .....................................................................................
        # . For the feature selection level that maximizes significance :
        # . 1. Plot apRSort against fraction declared sensitive.
        # .....................................................................................
        apRSortBuf = cv$apRSortBIG[ , jmin];
        amlog10pRSort = Stat.getMlog10(apRSortBuf);   # -log10(P) transformation.
        afBuf = (1:cv$n) / cv$n;                      # Fraction declared sensitive.
        anBuf = 1:cv$n;                               # Absolute number of sensitives.
        fracMin = ncMin / cv$n;                       # Fraction sensitive at optimum.

        ymin = 0.0;
        ymax = 1.1 * max(amlog10pRSort);

        caption = paste('P-value for Z=1 to Z=0 versus nc. ncMin = ', ncMin, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(anBuf, amlog10pRSort, ylim = c(ymin, ymax),
             type = 'l', xlab = 'nc: number sensitive',
             ylab = '-log10(P)', main = caption);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);

        #xxx abline(v = fracMin, lty = 'dashed');
        abline(v = ncMin, lty = 'dashed');
        # .....................................................................................
        # . 2. Plot apRSort against differential log-hazard-ratio :
        # .....................................................................................
        aDloghRSortBuf = cv$aDloghRSortBIG[ , jmin];

        ymin = 0.0;
        ymax = 1.1 * max(amlog10pRSort);

        caption = paste('P-value for Z=1 to Z=0 versus DloghR');        

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aDloghRSortBuf, amlog10pRSort, ylim = c(ymin, ymax),
             type = 'l', xlab = 'DloghR = loghR(Z=1)-loghR(Z=0)',
             ylab = '-log10(P)', main = caption);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);

        temp1 = log(hRC);
        abline(v = temp1, lty = 'dashed');       # Boundary for determining sensitive patients.        
        # .....................................................................................
        # . 3. For the optimal feature selection level and the corresponding optimal threshold
        # . hRC for selection of the sensitive subset, generate survival curves comparing
        # . true Z = 1 and Z = 0 subgroups.
        # .
        # . First select subset :
        # .....................................................................................
        indexSortBuf = cv$indexSortBIG[ , jmin];

        atSortBuf = cv$atBIG[indexSortBuf[1:ncMin]]
        asSortBuf = cv$asBIG[indexSortBuf[1:ncMin]]
        azSortBuf = cv$azBIG[indexSortBuf[1:ncMin]]                

        fitBuf = survfit(Surv(atSortBuf, asSortBuf) ~ azSortBuf);

        dBuf = survdiff(Surv(atSortBuf, asSortBuf) ~ azSortBuf);     # Logrank test.
        pRBuf = pchisq(dBuf$chisq, df = 1, lower.tail = FALSE);      # Reality check. Should be same as pRMin.
        # .......................................................................................
        # . Now generate the plot :
        # .......................................................................................        
        caption = paste("True Z=1/Z=0 for optimum: pRMin =" , sprintf("%8.3e", pRMin),
                         " hR <= hRC = ", sprintf("%8.3e", hRC), sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.6);      
        plot(fitBuf,
             conf.int = FALSE,
             xlab = 'Survival time', ylab = 'Survival probability', 
             main = caption,
             col = c('red', 'blue'));

        temp1 = 0.4 * max(atSortBuf);
      
        legendText = c("Z = 0", "Z = 1");
        colVector = c('red', 'blue');
        ltyVector = c('solid', 'solid');
        legend(x = temp1, y = 1.0, legend = legendText, col = colVector, lty = ltyVector, bty = 'n');
        par(cex.main = cex.main.OLD);
        # ......................................................................................
        par(mfrow = c(1, 1));
        # ......................................................................................
        # . Add an over plot (sub) title :
        # ......................................................................................
        captionSub = "Comparison of Z = 1 to Z = 0 arms for ";

        captionSub = paste(captionSub, ' lambda = ', sprintf("%8.3e", aScan[jmin]), sep = "");
      
        cex.main.OLD = par("cex.main");        
        par(cex.main = 1.0);         
        title(sub = captionSub);
        par(cex.main = cex.main.OLD);         
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # ....................................................................................        
      }
      # .......................................................................................      

      


      
      # ....................................................................................
      # . >>PREDICTIVE ESTIMATES Part 3 :
      # . Find the feature selection level that minimizes P-value.
      # . Plot survival times versus predicted DloghR = loghR(Z=1) - loghR(Z=0) :
      # .......................................................................................
      msg = Cox.checkBinary(cv$azBIG);   # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg == 'ok') {
        # ....................................................................................
        # . Generate file name:
        # ....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Survival times vs predicted DloghR: optimal feature selection level";
        afile = c(afile, fname);
        aplot = c(aplot, pname);      
        # ....................................................................................
        # . Plot here :
        # ....................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Determine the optimal feature selection level.
        # . Retrieve DloghR for that level.
        # .....................................................................................
        jmin = which.min(cv$apRMin);     # Index of feature selection level which maximizes significance.
        hRC = cv$ahRCBIG[jmin];          # Upper bound for selecting patients predited to be sensitive.
        
        indexSortBuf = cv$indexSortBIG[ , jmin];
        aDloghRBuf = rep(0.0, times = length(indexSortBuf));      # Initialize with dummy values.

        aDloghRBuf[indexSortBuf] = cv$aDloghRSortBIG[ , jmin];    # In original order.
        atBuf = cv$atBIG;
        asBuf = cv$asBIG;
        azBuf = cv$azBIG;

        acol = ifelse(azBuf == 1, 'blue', 'red');
        # .....................................................................................
        # . For the feature selection level that maximizes significance :
        # . Plot survival times againsts DloghR.
        # .....................................................................................
        ymin = 0.0;
        ymax = 1.1 * max(atBuf);

        xmax = max(aDloghRBuf);
        xmin = min(aDloghRBuf);
        
        caption = paste('Surv. time versus predicted DloghR: ');

        temp1 = paste('lambda = ', sprintf("%8.3e", aScan[jmin]),
                        ', hRC = ', sprintf("%8.3e", hRC) , sep = "");
        caption = paste(caption, temp1, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.8);            
        plot(aDloghRBuf, atBuf, ylim = c(ymin, ymax),
             type = 'p', xlab = 'predicted DloghR = loghR(Z = 1) - loghR(Z =0)',
             ylab = 'survival time', main = caption, col = acol, pch = 19);
        abline(h = 0.0);
        par(cex.main = cex.main.OLD);

        abline(v = 0);                           # Abcissa.
        temp1 = log(hRC);
        abline(v = temp1, lty = 'dashed');       # Boundary for determining sensitive patients.
        # ......................................................................................
        # . Add the legend here:
        # ......................................................................................
        xtemp1 = xmax - 0.2 * (xmax - xmin);
        ytemp1 = ymax;
        
        legendText = c("Z = 0", "Z = 1");
        colVector = c('red', 'blue');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = xtemp1, y = ytemp1,
               legend = legendText, col = colVector, pch = pchVector, bty = 'n');
        # ......................................................................................
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # ....................................................................................        
      }
      # .......................................................................................      

      
      


      # .......................................................................................
      # . Regularization paths for Coxnet model :
      # .
      # . Generate file name :      
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Coxnet regularization paths";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Turn on plot devices :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      # .......................................................................................
      # . Plot here :
      # .......................................................................................      
      lambdaMin = aScan[jmin];
      lambdaMinBuf = sprintf("%8.3e", lambdaMin);

      cex.main.OLD = par("cex.main");
      par(cex.main = 0.8);
      
      caption = paste(pname," (lambdaMin = ", lambdaMinBuf, ")", sep = "");
      plot(cv$fitB, xvar = 'lambda', main = caption);

      if (lambdaMin > 0.0) {
        temp1 = log(lambdaMin);
        abline(v = temp1, lty = 'dashed');
      }

      par(cex.main = cex.main.OLD);      
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................
      
      


      
      # ....................................................................................
      # . >>Text summary for optimal parameters :
      # ....................................................................................
      msg = Cox.checkBinary(cv$azBIG);   # Applies only to two-arm studies, coded as Z = 0, 1.

      if (msg == 'ok') {
        # ....................................................................................              
        # . Generate file name:
        # ....................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Text summary for optimal parameters";
        afile = c(afile, fname);
        aplot = c(aplot, pname);      
        # ....................................................................................
        # . Plots here :
        # ....................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }
      
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Write text into a plot, summarizing optimal parameters. This is put here
        # . in the graphical output for easy reference.
        # .....................................................................................
        xBuf = c(0,1);
        yBuf = c(0,1);        
        plot(xBuf, yBuf, type = 'n', xaxt = 'n', yaxt = 'n', xlab = '', ylab = '');   # Generate the box : no axis labels or tick marks.
        txtSummary = GlmnetDiag.generateCoxCvWithCovSummary(cv);
        txtSummary = gsub("\t", "  ", txtSummary);
        
        text(0.05, 0.0, txtSummary, cex = 0.6, col = 'black', adj = c(0,0))        
        # ......................................................................................
        par(mfrow = c(1, 1));
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # ....................................................................................        
      }
      # .......................................................................................      
      


    
      
      
      # .......................................................................................
      # . Final tally :
      # .......................................................................................      
      nplot = length(afile);
      
      if (flagWrite == 'yes') {
        cat(" ..........  ", nplot, " jpeg plot files were generated.\n", sep = "");
      }
      # .......................................................................................

      
      
      # ....................................................................
      # . Package file names and plot names into list.
      # . Note that these are generated (with dummy names in that case)
      # . even if flagWrite = 'no'.
      # .
      # .   nplot = total number of plots in array.
      # .   afile = array of file names.
      # .   aplot = array of corresponding plot names.
      # ....................................................................
      sp = list(nplot = nplot, afile = afile, aplot = aplot);

      class(sp) = 'glmnet.diag.plot';
      # ....................................................................
      
     
      # ...........
      return (sp);
      # ...........

}

# =================================================================================================
# . End of GlmnetDiag.plotCoxCvWithCov.
# =================================================================================================






# =========================================================================================================================
# . GlmnetDiag.writeCoxCvWithCovSingle : writes Cox cross-validation results to the specified file. This version is
# . -----------------------------------   for cross-validation on a single level of tuning parameters.
# .                          
# .   Syntax:
# .           GlmnetDiag.writeCoxCvWithCovSingle(cv, hRC, fs);
# .
# .   In:
# .        cv = result of a cross-validation calculation, returned by call to
# .             GlmnetCv.crossValidateCoxWithCov().
# .
# .       hRC = external threshold on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .       fs = output file name.
# .
# =========================================================================================================================

GlmnetDiag.writeCoxCvWithCovSingle <- function(cv, hRC, fs)
{

      # ...........................................................
      if (class(cv) != "glmnet.cox.cov.cv") {
        msg = "ERROR: from GlmnetDiag.writeCoxCvWithCovSingle: ";
        msg = paste("The input cv is not of class glmnet.cox.cov.cv.");
        stop(msg);
      }
      # ...........................................................

      
      # ................................................................
      cat(" ..........  Entry in GlmnetDiag.writeCoxCvWithCovSingle.\n");
      # ................................................................


      # ................................................................
      # . Some simple failsafes here :
      # ................................................................      
      if (cv$cvType != 'single'){
        cat("ERROR: from GlmnetDiag.writeCoxCvWithCovSingle:\n");
        cat("cross-validation type in input cv is not single.\n");
        stop();
      }

      if (cv$nScan != 1){
        cat("ERROR: from GlmnetDiag.writeCoxCvWithCovSingle:\n");
        cat("Inconsistency: cross-validation type is single, but nScan = ",
            nScan, " != 1.\n", sep = "");
        stop();
      }

      stopifnot(hRC >= 0.0);
      # ................................................................      


      # ................................................................
      # . Open output file :
      # ................................................................
      FS = file(fs, "w");
      # ................................................................      
      
      
      # ................................................................
      # . >> PREAMBLE:
      # . Generate a text string containing the model summary :
      # ................................................................
      buf = "#PREAMBLE:\n";
      cat(buf, file = FS);
      
      txtSummary = GlmnetDiag.generateCoxCvWithCovSummarySingle(cv);
      cat(txtSummary, file = FS);

      buf = "\n";
      cat(buf, file = FS);
      cat(buf, file = FS);       
      # ................................................................      

      
      # ................................................................
      # . Define the array and label for the x axis :
      # ................................................................
      xlab = 'lambda';      
      nScan = cv$nScan;
      # ................................................................
      




      # ..........................................................................
      # . Find the sensitive samples, and compute Cox statistics for Z=1 to Z=0
      # . comparisons.
      # . This is done for wo values of the differential hazard-ratio threshold,
      # . the internal threshold, for which the P-value is minimized, and the
      # . external threshold, which is user-provided.
      # ..........................................................................
      cSens = SuperPcCv.computeCoxSensitivesOnBinary(cv, hRC);
      # ......................................................................................
      # . Write statistics on sensitive subsets here :
      # ......................................................................................
      buf = paste("\n\n", sep = "");
      cat(buf, file = FS);      
      
      buf = "#TABLE 1: statistics for sensitive subsets:\n";
      cat(buf, file = FS);

      buf = paste("#-----------------------------------------------------------------------------------\n",
                   sep = "");
      cat(buf, file = FS);      
      # ..........................................................................
      # . Write header :
      # ..........................................................................
      buf = paste("#Parameter\tValue\tDescription\n", sep = "");
      cat(buf, file = FS);
      # ..........................................................................
      # . >> Predictive variables on internal threshold :
      # ..........................................................................
      buf = paste("hRCMin", "\t", sprintf("%10.5e", cSens$hRCMin),
                  "\tInternal threshold: DloghR <= hRCMin achieves minimum P-value (same as in Table 1)\n",
                  sep = "");
      cat(buf, file = FS);

      buf = paste("nSensitiveMin", "\t", sprintf("%10.5e", cSens$nSensitiveMin),
                  "\tInternal threshold: Number of sensitive patients obtained for DloghR <= hRCMin",
                  " (same as in Table 1)\n",
                  sep = "");
      cat(buf, file = FS);            
      
      buf = paste("pRMin", "\t", sprintf("%10.5e", cSens$pRMin),
                  "\tInternal threshold: Minimum P-value for split DloghR <= hRCMin (same as in Table 1)\n",
                  sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRMin", "\t", sprintf("%10.5e", cSens$hRMin),
                  "\tInternal threshold: Hazard-ratio obtained for DloghR <= hRCMin  (same as in Table 1)\n",
                  sep = "");
      cat(buf, file = FS);

      buf = paste("hRMinLo", "\t", sprintf("%10.5e", cSens$hRMinLo),
                  "\tInternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRMinHi", "\t", sprintf("%10.5e", cSens$hRMinHi),
                  "\tInternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");            
      cat(buf, file = FS);      
      # ..........................................................................
      # . >> Predictive variables on external threshold :
      # ..........................................................................
      buf = paste("hRC\t", hRC,
                  "\tExternal threshold for defining sensitives\n", sep = "");
      cat(buf, file = FS);

      buf = paste("nSensitive", "\t", sprintf("%10.5e", cSens$nSensitive),
                  "\tExternal threshold: Number of sensitive patients obtained for DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);      
      
      buf = paste("pR", "\t", sprintf("%10.5e", cSens$pR),
                  "\tExternal threshold: Minimum P-value for split DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hR", "\t", sprintf("%10.5e", cSens$hR),
                  "\tExternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRLo", "\t", sprintf("%10.5e", cSens$hRLo),
                  "\tExternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");
      cat(buf, file = FS);
      
      buf = paste("hRHi", "\t", sprintf("%10.5e", cSens$hRHi),
                  "\tExternal threshold: Hazard-ratio obtained for DloghR <= hRC\n", sep = "");            
      cat(buf, file = FS);
      # ............................................................................................
      # . Close table here :
      # ............................................................................................
      buf = paste("#-----------------------------------------------------------------------------------\n",
                   sep = "");                  
      cat(buf, file = FS);       
      # ............................................................................................      





      # ..........................................................................
      # . Generate a comprehensive ``ROC'' table:
      # . DloghR, hR, log(hR), pR, -log10(pR), sensitivity, number of sensitives.
      # . hR, . . ., -log10(pR) refer to Cox model statistics with {Z=1/Z=0}
      # . covariates for the subset defined by DloghR <= DloghR0, where DloghR0
      # . is the current value of DloghR in the table.
      # .
      # . Retrieve the salient variables :
      # ..........................................................................
      aDloghRSortBuf = cv$aDloghRSortBIG[ , 1];      # DloghR: predicted differential log-hazard threshold.
      aSBuf = (1:cv$n) / cv$n;                       # Sensitivity.
      anBuf = 1:cv$n;                                # Absolute number of sensitives.
      ahRSortBuf = cv$ahRSortBIG[ , 1];              # hR: resulting hR  between Z=1 and Z=0.
      aloghRSortBuf = log(cv$ahRSortBIG[ , 1]);      # log(hR): resulting loghR between Z=1 and Z=0.
      apRSortBuf = cv$apRSortBIG[ , 1];              # pR : P-value between Z=1 and Z=0.
      amlog10pRSortBuf = Stat.getMlog10(apRSortBuf); # -log10(P) transformation of P-value.
      # ..........................................................................
      # . Write here :
      # ..........................................................................      
      buf = paste("\n\n", sep = "");
      cat(buf, file = FS);      

      buf = "#TABLE 2: ROC table:\n";
      cat(buf, file = FS);

      buf = paste("#The variables hR, . . ., -log10(pR) refer to Cox model statistics with {Z=1/Z=0}\n",
                  "#covariates for the subset defined by DloghR <= DloghR0, where DloghR0\n",
                  "#is the current value of DloghR in the table.\n",
                  "DloghR = loghR(Z=1) - loghR(Z=0)\n",
                  "S = sensitivity\n",
                  "nc = number of sensitives\n",
                  sep = "");
      cat(buf, file = FS);
      
      buf = paste("#-----------------------------------------------------------------------------------\n\n",
                   sep = "");
      cat(buf, file = FS);      
      # ..........................................................................
      # . Write header :
      # ..........................................................................
      buf = paste("#DloghR\tS\tnc\thR\tlog(hR)\tpR\tmlog10(pR)\n", sep = "");
      cat(buf, file = FS);
      # ..........................................................................
      # . Write body :
      # ..........................................................................
      for (i in 1:cv$n) {
        buf = paste(sprintf("%10.5e", aDloghRSortBuf[i]), "\t",
                    sprintf("%10.5e", aSBuf[i]), "\t",
                    anBuf[i], "\t",
                    sprintf("%10.5e", ahRSortBuf[i]), "\t",
                    sprintf("%10.5e", aloghRSortBuf[i]), "\t",
                    sprintf("%10.5e", apRSortBuf[i]), "\t",
                    sprintf("%10.5e", amlog10pRSortBuf[i]),
                    "\n",
                    sep = "");
        cat(buf, file = FS);
      }
      # ............................................................................................
      # . Close table here :
      # ............................................................................................
      buf = paste("\n#-----------------------------------------------------------------------------------\n",
                   sep = "");                  
      cat(buf, file = FS);       
      # ............................................................................................



      # ............................................................................................
      # . Write tables of first-pass feature-selected and of active genes here :
      # ............................................................................................
      sumBuf = rowSums(cv$agFsMat);
      dfFsMat = data.frame(SUM = sumBuf, as.data.frame(cv$agFsMat));
      dfFsMat = dfFsMat[order(sumBuf, decreasing = TRUE), ];
      

      sumBuf = rowSums(cv$agACTMat);
      dfACTMat = data.frame(SUM = sumBuf, as.data.frame(cv$agACTMat));
      dfACTMat = dfACTMat[order(sumBuf, decreasing = TRUE), ];
      # ............................................................................................
      # . Title and body for first-pass feature-selection table :
      # ............................................................................................
      buf = paste("\n#-----------------------------------------------------------------------------------\n", sep = "");
      buf = paste("#FIRST-PASS FEATURE SELECTION TABLE: genes * folds                                   \n", sep = "");
      cat(buf, file = FS);

      dfBuf = data.frame(aq = rownames(dfFsMat), dfFsMat);    # Integrate row names as first column.
      ac = colnames(dfBuf);
      ac[1] = "#QUAL";
      colnames(dfBuf) = ac;

      DataFrame.writeFlat(dfIn = dfBuf, fo = FS, append = TRUE);      
      #xxxx write.table(x = dfFsMat, file = FS, append = TRUE, sep = "\t");
      # ............................................................................................
      # . Title and body for active genes table :
      # ............................................................................................
      buf = paste("\n\n#\n", sep = "");
      buf = paste("\n#-----------------------------------------------------------------------------------\n", sep = "");
      buf = paste("#ACTIVE GENES TABLE: genes * folds                                   \n", sep = "");
      cat(buf, file = FS);

      dfBuf = data.frame(aq = rownames(dfACTMat), dfACTMat);    # Integrate row names as first column.
      ac = colnames(dfBuf);
      ac[1] = "#QUAL";
      colnames(dfBuf) = ac;

      DataFrame.writeFlat(dfIn = dfBuf, fo = FS, append = TRUE);            
      #xxx write.table(x = dfACTMat, file = FS, append = TRUE, sep = "\t");            
      # ............................................................................................            

      
      
      # .............................
      # . Close file here :
      # .............................      
      close(FS);
      # .............................      
     

      # ...........................................................................      
      cat(" ..........  Wrote Cox cross-validation results : ",
          fs, "\n", sep = "");
      # ...........................................................................
      
      
      # ...........
      return (0);
      # ...........

}

# =========================================================================================================================
# . End of GlmnetDiag.writeCoxCvWithCovSingle.
# =========================================================================================================================




# =========================================================================================================================
# . GlmnetDiag.generateCoxCvWithCovSummarySingle : generates a text string containing a summary of results 
# . ---------------------------------------------   from the supervised principal components cross-validation,
# .                                                 for the case with external covariate. This version is
# .                                                 for cross-validation on a single level of tuning parameters.
# .   Syntax:
# .        txt = GlmnetDiag.generateCoxCvWithCovSummarySingle(cv);
# .
# .   In:
# .         cv = result of super pc cross-validation, as returned by function
# .              GlmnetCv.crossValidateCoxWithCov().
# .
# .   Out:
# .        txt = contains listing of input parameters, feature selection results,
# .              svd results, and global and detailed results for the Cox propotional
# .              hazard model.
# .
# =========================================================================================================================

GlmnetDiag.generateCoxCvWithCovSummarySingle <- function(cv)
{

      # .....................................................................................
      if (class(cv) != "glmnet.cox.cov.cv") {
        msg = "ERROR: from GlmnetDiag.generateCoxCvWithCovSummarySingle: ";
        msg = paste("The input cv is not of class glmnet.cox.cov.cv");
        stop(msg);
      }
      # .....................................................................................      

  
      # ...........................................................................................
      buf = paste("#Cross-validation of Cox regression model :\n", sep = "");
      # ............................................................................................




      # ......................................................................................
      # . Parameters used in the computation, and results of the feature selection :
      # ......................................................................................
      buf = paste(buf, "#General Parameters:\n", sep = "");      
      buf = paste(buf, "#Number of samples in the input training set: n = " , cv$n, "\n", sep = "");
      buf = paste(buf, "#Number of genes in the input training set: p = " , cv$p, "\n", sep = "");
      buf = paste(buf, "#Feature selection method: methodFs = mtop\n", sep = "");       # Frozen,
      buf = paste(buf, "#Method for splitting the data: methodSplit = ", cv$methodSplit, "\n", sep = "");
      buf = paste(buf, "#Type of P-value used in feature selection: typePval = ", cv$typePval, "\n", sep = "");      

      buf = paste(buf, "#Fraction put into test set: ft = ", cv$ft, "\n", sep = "");
      buf = paste(buf, "#Random number generator seed: rngSeed = ", cv$rngSeed, "\n", sep = "");

      buf = paste(buf, "#Cross-validation train-test breakdown (approximate):\n", sep = "");
      buf = paste(buf, "#n(total)\tntrain\tntest\n", sep = "");
      buf = paste(buf, cv$n, "\t", cv$ntrain, "\t", cv$ntest, "\n", sep = "");             
      buf = paste(buf, "\n", sep = "");      
      buf = paste(buf, "#Parameter scanned: lambda\n", sep = "");
      buf = paste(buf, "#Number of tuning parameter levels: nScan = ", cv$nScan, "\n", sep = "");      
      buf = paste(buf, "#Actual number of cross-validation splits: ncvHere = ", cv$ncvHere, "\n", sep = "");
      # ......................................................................................

      

      # ................................................................................................................
      # . Extract optimized feature selection parameter :
      # . At the given feature selection level.
      # . 
      # . >> 1. Significance for *prognostic* estimates on collected test sets, with the
      # . z = 0 and z = 1 treatment arms considered separately.
      # .................................................................................................................
      buf = paste(buf, "\n", sep = "");
      buf = paste(buf, "# 1. PROGNOSTIC ESTIMATES ON COLLECTED TEST SETS:\n", sep = "");
      # ..................................................................................................................
      # . z = 0 treatment arm:
      # ..................................................................................................................
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");      
      jmin0 = which.min(cv$apR0);
      pR0Min = cv$apR0[jmin0];        # Most significant prognostic estimate for z = 0 arm.
      hR0Min = cv$ahR0[jmin0];        # Corresponding hazard ratio for z = 0 arm.

      lambdaMin0 = cv$alambda[jmin0];      
      buf = paste(buf, "#Z = 0 arm: lambdaMin0 = ", sprintf("%8.3e", lambdaMin0), "\n", sep = "");
      
      buf = paste(buf, "pR0Min = ", sprintf("%8.3e", pR0Min), "\n", sep = "");
      buf = paste(buf, "hR0Min = ", sprintf("%8.3e", hR0Min), "\n", sep = "");
      # .................................................................................................................
      # . z = 1 treatment arm:
      # .................................................................................................................
      jmin1 = which.min(cv$apR1);
      pR1Min = cv$apR1[jmin1];        # Most significant prognostic estimate for z = 1 arm.
      hR1Min = cv$ahR1[jmin1];        # Corresponding hazard ratio for z = 1 arm.

      lambdaMin1 = cv$alambda[jmin1];      
      buf = paste(buf, "#Z = 1 arm: lambdaMin1 = ", sprintf("%8.3e", lambdaMin1), "\n", sep = "");

      buf = paste(buf, "pR1Min = ", sprintf("%8.3e", pR1Min), "\n", sep = "");
      buf = paste(buf, "hR1Min = ", sprintf("%8.3e", hR1Min), "\n", sep = "");
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      buf = paste(buf, "#By prognostic estimates, we mean that in the z = 0 and z = 1 treatment arms considered\n", sep = "");
      buf = paste(buf, "#separately, we predict hazard ratios on the basis of gene expression alone and.\n", sep = "");
      buf = paste(buf, "#ask how well they correlate with the observed data:\n", sep = "");
      buf = paste(buf, "\n", sep = "");      
      # ................................................................................................................
      # . >> 2. Significance for *predictive* estimate on collected test sets, with the
      # . two treatment arms considered together.
      # ................................................................................................................
      buf = paste(buf, "\n", sep = "");      
      buf = paste(buf, "# 2. PREDICTIVE ESTIMATES ON COLLECTED TEST SETS:\n", sep = "");
      # ...............................................................................................
      # . Basic optimizations here :
      # ...............................................................................................      
      jmin = which.min(cv$apRMin);    # Feature selection level that maximizes significance.
      pRMin = cv$apRMin[jmin];        # Minimum P-value at optimal thresholding between z = 1 and z = 0 sub-populations.  
      hRMin = cv$ahRMin[jmin];        # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.           
      hRCMin = cv$ahRC[jmin];         # Optimal cut: subset at predicted lambda(z = 1) / lambda(z = 0) <= hRC
                                      # to minimize the P-value.
      nMin = cv$aicMin[jmin];         # Number of samples actually used in the comparison.
      
      lambdaMin = cv$alambda[jmin];
      # ...............................................................................................
      # . Now display :
      # ...............................................................................................      
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");      

      buf = paste(buf, "lambdaMin = ", sprintf("%8.3e", lambdaMin), "\n", sep = "");

      buf = paste(buf, "hRCMin = ", sprintf("%8.3e", hRCMin), "\n", sep = "");
      buf = paste(buf, "nMin = ", nMin, "\n", sep = "");
      buf = paste(buf, "n = ", cv$n, "\n", sep = "");            
      buf = paste(buf, "pRMin = ", sprintf("%8.3e", pRMin), "\n", sep = "");
      buf = paste(buf, "hRMin = ", sprintf("%8.3e", hRMin), "\n", sep = "");
      buf = paste(buf, "#---------------------------------------------------------------------\n", sep = "");
      # ......................................................................................
      # . Same as above, but with elaborate explanations :
      # ......................................................................................      
      buf = paste(buf, "#By predictive estimates, we mean that we use the Cox regression model to predict\n", sep = "");
      buf = paste(buf, "#in the collected test sets those patients most likely to respond with longer\n", sep = "");
      buf = paste(buf, "#survival times to the Z = 1 treatment arm than to the Z = 0 treatment arm.\n", sep = "");
      buf = paste(buf, "#The criterion for sensitivity is that the relative predicted hazard ratio,\n", sep = "");
      buf = paste(buf, "#hR(z = 1) / hR(z = 0) <= hRC, where the threshold hRC is an adjustable parameter.\n", sep = "");
      buf = paste(buf, "#For samples predicted to be sensitive, we then compare actual survival times in the two\n", sep = "");
      buf = paste(buf, "#treatment arms. We report here the value of feature selection, and hRC, to minimize P-value\n", sep = "");
      buf = paste(buf, "#for this comparison.\n", sep = "");            

      buf = paste(buf, "#\n", sep = "");      
   

      buf = paste(buf, "#Feature selection:", sep = "");

      buf = paste(buf, "lambda = lambdaMin = ", sprintf("%8.3e", lambdaMin),
                  " for maximum significance.\n", sep = "");

      buf = paste(buf, "#Selecting for sensitive patients with predicted differential\n", sep = "");
      buf = paste(buf, "#hazard ratio lambda(z = 1) / lambda(z = 0) <= hRC yields the most\n", sep = "");
      buf = paste(buf, "#significant split between actual z = 0 and z =1 treatment arms\n", sep = "");
      buf = paste(buf, "#for the value of hRC given below:\n", sep = "");      
      
      buf = paste(buf, "#Optimal upper threshold on differential log-hazard-ratio for selecting sensitive patients:\n", sep = "");
      buf = paste(buf, "hRC = ", sprintf("%8.3e", hRCMin), "\n", sep = "");
      buf = paste(buf, "#Number of sensitive patients selected under that threshold:\n", sep = "");
      buf = paste(buf, "nMin = ", nMin, " (out of ", cv$n, ")\n", sep = "");      
      buf = paste(buf, "#P-value for difference in survival in sensitive patients, between z = 1 and z = 0 populations:\n", sep = "");
      buf = paste(buf, "pRMin = ", sprintf("%8.3e", pRMin), "\n", sep = "");
      buf = paste(buf, "#Corresponding hazard-ratio between z = 1 and z = 0 populations:\n", sep = "");
      buf = paste(buf, "hRMin = ", sprintf("%8.3e", hRMin), "\n", sep = "");      
      # ......................................................................................            

      
      # .............
      return (buf);
      # .............

}

# =========================================================================================================================
# . End of GlmnetDiag.generateCoxCvWithCovSummarySingle.
# =========================================================================================================================









# =================================================================================================
# . GlmnetDiag.writeRegressSummary : writes to file a summary of results from the supervised
# . -------------------------------   principal components calculation using regression models.
# .
# .   Syntax:
# .
# .        txt = GlmnetDiag.writeRegressSummary(ay, dfX, gl, fs);
# .
# .   In:
# .         ay = n : vector of output variable values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .            gl = result of glmnet computation, returned
# .                 by function Glmnet.computeRegress().
# .
# .            fs = name of output file.
# .
# =================================================================================================

GlmnetDiag.writeRegressSummary <- function(ay, dfX, gl, fs)
{

      # .........................................................................  
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from GlmnetDiag.writeRegressSummary: ";
        msg = paste("The input gl is not of class glmnet.regress.");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.

      ny = length(ay);   # Number of samples in output variable vector.      

      if (ny != n) {
        msg = "ERROR: from GlmnetDiag.writeRegressSummary: ";        
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.writeRegressSummary: ";        
        msg = paste("The input data matrix does not have the same number of ");
        msg = paste("genes as in the glmnet model. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("Glmnet model has p = " , gl$p, " genes.");
        stop(msg);
      }

     if (gl$n != n) {
        msg = "ERROR: from GlmnetDiag.writeRegressSummary: ";               
        msg = paste("The input data matrix does not have the same number of ");       
        msg = paste("samples as in the glmnet model. ");
        msg = paste("Input has n = " , n, " samples. ");
        msg = paste("Glmnet model has n = " , gl$n, " samples.");        
        stop(msg);
      }      
      # .........................................................................
      

      
      # ...........................................................
      # . Generate a text string containing the model summary :
      # ...........................................................
      txtSummary = GlmnetDiag.generateRegressSummary(ay = ay,
                                                     dfX = dfX,
                                                     gl = gl);
      # ...........................................................      

      
      # ...........................................................
      # . Write to file :
      # ...........................................................      
      FS = file(fs, "w");
      cat(txtSummary, file = FS);
      # ...........................................................



      
      # ..........................................................................
      # . Add fold assignments here, if cross-validation was specified :
      # ..........................................................................
      if (gl$flagCv == 'yes') {
        buf = "\n";
        cat(buf, file = FS);

        cat("####################################################################################\n", file = FS);
        buf = paste("# FOLD ASSIGNMENTS FOR CROSS-VALIDATION: number of folds used = ", gl$ncv, sep = "", "\n");
        cat(buf, file = FS);
        cat("####################################################################################\n", file = FS);        
        # ..........................................................................
        # . Get the fold assignments :
        # ..........................................................................      
        aindex = 1:gl$n;              # Simple numbering of entries.
        ar = gl$arowName;             # The corresponding sample names.
        afold = gl$afold;             # The fold assignments for the cross-validation.

        dfBuf = data.frame("index" = aindex, "rowName" = ar, "foldIndex" = afold);
        # ..........................................................................
        # . Write to file :
        # ..........................................................................
        write.table(x = dfBuf, file = FS, sep = "\t", quote = FALSE, row.names = FALSE);
        # ..........................................................................           
        buf = "\n";
        cat(buf, file = FS);
      }        
      # ..........................................................................      

      
      # ..............
      close(FS);
      # ..............      

      
      # ..............................................................................      
      cat(" ..........  Wrote statistical summary : ", fs, "\n", sep = "");
      # ..............................................................................

      
      # ...................
      return (txtSummary);
      # ...................
      
}

# =================================================================================================
# . End of GlmnetDiag.writeRegressSummary.
# =================================================================================================      





# =================================================================================================
# . GlmnetDiag.generateRegressSummary : generates a text string containing a summary of results 
# . ---------------------------------   from the glmnet regression model.
# .                                     
# .   Syntax:
# .
# .        txt = GlmnetDiag.generateRegressSummary(ay, dfX, gl);
# .
# .   In:
# .         ay = n : vector of output variable values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .        gl = result of glmnet computation, returned
# .              by function Glmnet.computeRegress().
# .
# .   Out:
# .        txt = contains listing of input parameters, feature selection results,
# .              svd results, and global and detailed results for the Cox propotional
# .              hazard model.
# .
# =================================================================================================

GlmnetDiag.generateRegressSummary <- function(ay, dfX, gl)
{

      # .....................................................................................
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from GlmnetDiag.generateRegressSummary: ";
        msg = paste("The input gl is not of class glmnet.regress.");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.

      ny = length(ay);   # Number of samples in output variable vector.      

      if (ny != n) {
        msg = "ERROR: from GlmnetDiag.generateRegressSummary: ";        
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.generateRegressSummary: ";        
        msg = paste("The input data matrix does not have the same number of ");
        msg = paste("genes as in the supervised pc. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("Gl has p = " , gl$p, " genes.");
        stop(msg);
      }

     if (gl$n != n) {
        msg = "ERROR: from GlmnetDiag.generateRegressSummary: ";               
        msg = paste("The input data matrix does not have the same number of ");       
        msg = paste("samples as in the supervised pc. ");
        msg = paste("Input has n = " , n, " samples. ");
        msg = paste("Gl has n = " , gl$n, " samples.");        
        stop(msg);
      }
      # .....................................................................................      


      
      # ...................................................................................
      # . Compute the principal components and the predicted output values, using 
      # . the training set-derived means and principal component vectors.
      # . This call returns :
      # .        sl$axi = n : vector of prognostic indices xi = beta0 + beta . x
      # .     sl$ayPred = n : vector of predicted output values.
      # .    sl$aPyPred = n : vector of estimated P(y = 1|x) valyes.
      # ...................................................................................      
      sl = Glmnet.computeRegressOutputVariable(gl, dfX);
      # ...................................................................................

      

      
      # ...........................................................................................
      buf = "# ................................................................\n";
      buf = paste(buf, "# . SUMMARY FOR REGRESSION MODEL COMPUTATION           \n", sep = "");
      buf = paste(buf, "# ................................................................\n", sep = "");
      buf = paste(buf, "\n", sep = "");      
      # ............................................................................................




      # ......................................................................................
      # . Parameters used in the computation, and results of the feature selection :
      # ......................................................................................
      buf = paste(buf, "#GENERAL PARAMETERS:\n", sep = "");      
      buf = paste(buf, "#Number of samples in data matrix: n = " , gl$n, "\n", sep = "");
      buf = paste(buf, "#Number of genes in data matrix: p = " , gl$p, "\n", sep = "");
      buf = paste(buf, "#Regression model used: modelType = " , gl$modelType, sep = "");
      
      if (gl$modelType == 'lm') {
        buf = paste(buf, " (multivariate glmnet linear regression)\n", sep = "");
      }

      if (gl$modelType == 'logistic') {
        buf = paste(buf, " (multivariate glmnet logistic regression)\n", sep = "");
      }
      
      buf = paste(buf, "#glmnet parameters:\n", sep = "");

      buf = paste(buf, "#alpha = " , gl$alpha, " (alpha = 1 --> all-lasso)\n", sep = "");        
      buf = paste(buf, "#lambda = " , gl$lambda, "\n", sep = "");                

      buf = paste(buf, "#Number of genes passed by feature selection: m = " , gl$m, "\n", sep = "");

      buf = paste(buf, "\n", sep = "");
      buf = paste(buf, "\n", sep = "");      
      # ......................................................................................

      
      
      
      # ......................................................................................
      # . Details of the results for the regression model:
      # ......................................................................................
      buf = paste(buf, "\n", sep = "");      
      buf = paste(buf, "#REGRESSION MODEL DESCRIPTION :", "\n", sep = "");
      # ......................................................................................
      # . >> LINEAR REGRESSION model :
      # ......................................................................................      
      if (gl$modelType == 'lm') {
        buf = paste(buf, "#Regression model: y = ym + beta * Xc\n", sep = "");
        buf = paste(buf, "#where y is the output variable, ym = sample mean of y,\n");
        buf = paste(buf, "#and Xc is gene-centered data matrix.\n", sep = "");
        buf = paste(buf, "#Note that centering all data is just a way of implicitly\n", sep = "");
        buf = paste(buf, "#computing the intercept term.\n", sep = "");        
      }
      # ......................................................................................
      # . >> LOGISTIC REGRESSION model :
      # ......................................................................................      
      if (gl$modelType == 'logistic') {
        buf = paste(buf, "#Logistic regression model: logit(P(y = 1|x)) = beta0 + betaT * Xc\n", sep = "");
        buf = paste(buf, "#where y is the output variable, beta0 = interecept term,\n", sep = "");
        buf = paste(buf, "#and Xc is gene-centered data matrix.\n", sep = "");
      }
      # ......................................................................................      
      buf = paste(buf, "\n", sep = "");            
      # ......................................................................................



      

      # ...................................................................................
      # . >>For LINEAR REGRESSION:
      # .   Compute error statistics :
      # ...................................................................................            
      if (gl$modelType == 'lm') {
        lr = Stat.basicLinearRegression(sl$ayPred, ay);

        sigmaBuf = sprintf("%8.3e", lr$sigma);
        R2Buf = sprintf("%8.3e", lr$R2);
        eps2Buf = sprintf("%8.3e", lr$eps2);
        pvalBuf = sprintf("%8.3e", lr$pval);
        beta0Buf = sprintf("%8.3e", lr$beta0);
        beta1Buf = sprintf("%8.3e", lr$beta1);                        
        ymBuf = sprintf("%8.3e", gl$ym);        

        buf = paste(buf, "#REGRESSION MODEL FIT: look at y ~ yPredicted:\n", sep = "");

        buf = paste(buf, "#P-value = ", pvalBuf, "\n", sep = "");                
        buf = paste(buf, "#Intercept: beta0 = ", beta0Buf, "\n", sep = "");
        buf = paste(buf, "#Slope: beta1 = ", beta1Buf, "\n", sep = "");                
        
        buf = paste(buf, "#Estimated std. dev. of the random error in y:\n", sep = "");
        buf = paste(buf, "#sigma = ", sigmaBuf, "\n", sep = "");      
        buf = paste(buf, "#Relative error squared eps2 (training error)\n", sep = "");
        buf = paste(buf, "#and fraction of variance R2 explained by the model:\n", sep = "");
        buf = paste(buf, "#R2 = 1 - eps2\n", sep = "");      
        buf = paste(buf, "#eps2 = |y - X . beta|^2 / |y - ym|^2\n", sep = "");

        buf = paste(buf, "#R2 = ", R2Buf, "\n", sep = "");      
        buf = paste(buf, "#eps2 = ", eps2Buf, "\n", sep = "");

        
        buf = paste(buf, "#Mean value of y (intercept term in the regression model):\n", sep = "");
        buf = paste(buf, "#ym = ", ymBuf, "\n", sep = "");
        # ......................................................................................
        buf = paste(buf, "\n", sep = "");
        # ......................................................................................        
      }
      # ......................................................................................





      # ...................................................................................
      # . >>For LOGISTICS REGRESSION:
      # .   Compute ROC, error statistics and confusion matrix :
      # ...................................................................................      
      if (gl$modelType == 'logistic') {
        #xxxx roc = Stat.basicROC(sl$aPyPred, ay,
        roc = Stat.basicROC(sl$axi, ay,                      # J. Theilhaber.
                            flagPval = TRUE,
                            flagConfInterval = TRUE,
                            flagNormalModel = TRUE,
                            prob = 0.95);

        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);
        cm = Stat.generateBinaryConfusionMatrix(ay, sl$ayPred);
        # .................................................................
        # . Header :
        # .................................................................        
        temp1 = "#Statistics for discrimination of 1 versus 0 class.\n";
        buf = paste(buf, temp1, sep = "");
        # .................................................................
        # . AUC stats :
        # .................................................................
        temp1 = "#Area under curve (AUC) for ROC, with 95% CI :\n";
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("auc = ", sprintf("%8.3f", aucStats$A), "\n",
                      "aucLo95 = ", sprintf("%8.3f", aucStats$ALo), "\n",
                      "aucHi95 = ", sprintf("%8.3f", aucStats$AHi), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        # .................................................................
        # . P-value from Wilcox test :
        # .................................................................
        temp1 = "#P-value for significance of discrimination :\n";
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("pval (Wilcox) = ", sprintf("%8.3e", roc$pval), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        # .................................................................
        # . Error rate :
        # .................................................................
        temp1 = "#Error rate and S/FP rates under MAP class assignments :\n";
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("errCount = ", sprintf("%8.3e", cm$errCount), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("errMAP = ", sprintf("%8.3e", cm$errRate), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("errMAPLo95 = ", sprintf("%8.3e", cm$errRateLo95), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("errMAPHi95 = ", sprintf("%8.3e", cm$errRateHi95), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");                
        # .................................................................
        # . S/FP rates under MAP class assignments :
        # .................................................................
        temp1 = paste("S_MAP = ", sprintf("%8.3e", roc$aS[roc$jMAP]),
                      " (sensitivity in detecting class = 1 under MAP assignments)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("FP_MAP = ", sprintf("%8.3e", roc$aFP[roc$jMAP]),
                      " (FP rate in detecting class = 1 under MAP assignments)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");                
        # .................................................................
        # . Confusion matrix :
        # .................................................................
        temp1 = "#Confusion matrix :\n";
        buf = paste(buf, temp1, sep = "");

        temp1 = DataFrame.generateTextNum(cm$Mmarg, "%5.0f");   # Confusion matrix with margins.
        buf = paste(buf, temp1, "\n", sep = "");        
        # .................................................................
        buf = paste(buf, "\n", sep = "");
        # .................................................................        
      }
      # ...................................................................................



      # ...................................................................................
      # . Cross-validation resuls :
      # ...................................................................................
      if (gl$flagCv == 'yes') {
        buf = paste(buf, "\n", sep = "");
        buf = paste(buf, "#CROSS-VALIDATION RESULTS :\n", sep = "");
        buf = paste(buf, "#Number of folds used : nfolds = ", gl$nfolds, "\n", sep = "");
        buf = paste(buf, "#Measure used : ", gl$cv.fitG$name, "\n", sep = "");

        lambda.min = gl$cv.fitG$lambda.min;
        lambda.1se = gl$cv.fitG$lambda.1se;
        lambda.min.Buf = sprintf("%8.3e", gl$cv.fitG$lambda.min);
        lambda.1se.Buf = sprintf("%8.3e", gl$cv.fitG$lambda.1se);

        index.min = which(gl$cv.fitG$lambda == gl$cv.fitG$lambda.min);
        index.1se = which(gl$cv.fitG$lambda == gl$cv.fitG$lambda.1se);        

        cvm.min = gl$cv.fitG$cvm[index.min];
        cvlo.min = gl$cv.fitG$cvlo[index.min];
        cvup.min = gl$cv.fitG$cvup[index.min];

        cvm.1se = gl$cv.fitG$cvm[index.1se];
        cvlo.1se = gl$cv.fitG$cvlo[index.1se];
        cvup.1se = gl$cv.fitG$cvup[index.1se];        
        
        buf = paste(buf, "#lambda.min = ", lambda.min.Buf, "\n", sep = "");
        buf = paste(buf, "#lambda.1se = ", lambda.1se.Buf, "\n", sep = "");
        
        buf = paste(buf, "#Cross-validated errors:\n", sep = "");
        buf = paste(buf, "#cvm.min - sd = ", sprintf("%8.3e", cvlo.min), "\n", sep = "");                
        buf = paste(buf, "#cvm.min = ", sprintf("%8.3e", cvm.min), "\n", sep = "");
        buf = paste(buf, "#cvm.min + sd = ", sprintf("%8.3e", cvup.min), "\n", sep = "");

        buf = paste(buf, "\n", sep = "");        
        buf = paste(buf, "#cvm.1se - sd = ", sprintf("%8.3e", cvlo.1se), "\n", sep = "");                
        buf = paste(buf, "#cvm.1se = ", sprintf("%8.3e", cvm.1se), "\n", sep = "");
        buf = paste(buf, "#cvm.1se + sd = ", sprintf("%8.3e", cvup.1se), "\n", sep = "");                
        
        buf = paste(buf, "\n", sep = "");        
      }
      # ...................................................................................      
      



      # ......................................................................................................
      # . >> REGRESSION COEFFICIENTS FOR THE SELECTED GENES :
      # ......................................................................................................
      m = gl$m;                                # Number of selected genes.
      acSel = gl$ac[gl$indexSel];              # Selected gene names.      
      abetaSel = gl$abeta[gl$indexSel];        # Regression coefficients for the selected genes.
      beta0 = gl$beta0;                        # Intercept term.
      
      buf = paste(buf, "#\n", sep = "");
      buf = paste(buf, "####################################################################################\n", sep = "");
      buf = paste(buf, "# REGRESSION COEFFICIENTS :\n");
      buf = paste(buf, "####################################################################################\n", sep = "");      
      buf = paste(buf, "#Number of genes selected: m = ", m, " out of a total of  p = ", p, "\n", sep = "");      
      buf = paste(buf, "#Regression coefficients for the selected genes:", "\n", sep = "");
      buf = paste(buf, "#(calculated on mean-centered (column-centered) gene expression data matrix X)\n", sep = "");

      ymBuf = sprintf("%8.3e", gl$ym);
      buf = paste(buf, "#Intercept term :  ym = ", ymBuf, "\n", sep = "");              

      buf = paste(buf, "-------------------------------------------------------------\n", sep = "");      
      buf = paste(buf, "GENE\tbeta\n", sep = "");

      for (j in 1:m) {
        buf = paste(buf, acSel[j], "\t", abetaSel[j], "\n", sep = "");
      }
      
      buf = paste(buf, "-------------------------------------------------------------\n", sep = "");      
      buf = paste(buf, "\n", sep = "");      # Bare line.
      # ......................................................................................

      
      
      # .............
      return (buf);
      # .............

}

# =================================================================================================
# . End of GlmnetDiag.generateRegressSummary.
# =================================================================================================








# =================================================================================================
# . GlmnetDiag.writeRegressSummaryOnTest : writes to file a summary of results for prediction
# . -------------------------------------   on test samples.
# .
# .   Syntax:
# .
# .        txt = GlmnetDiag.writeRegressSummaryOnTest(ay, dfX, gl, fs, append);
# .
# .   In:
# .         ay = n : vector of output variable values (n = number of samples).
# .
# .        dfX = input data frame for the predictor variables.
# .              This is of dimension n * p, where p = number of genes;
# .              each row corresponds to a samples, and each column to a gene.
# .
# .       gl = result of glmnet computation, returned
# .              by function Glmnet.computeRegress().
# .
# .         fs = name of output file.
# .
# .     append = if TRUE, append to existing false, if FALSE create a new file.
# .
# =================================================================================================

GlmnetDiag.writeRegressSummaryOnTest <- function(ay, dfX, gl, fs, append)
{

      # .........................................................................  
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from GlmnetDiag.writeRegressSummaryOnTest: ";
        msg = paste("The input gl is not of class glmnet.regress.");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.

      ny = length(ay);   # Number of samples in output variable vector.      

      if (ny != n) {
        msg = "ERROR: from GlmnetDiag.writeRegressSummaryOnTest: ";        
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.writeRegressSummaryOnTest: ";        
        msg = paste("The input data matrix does not have the same number of ");
        msg = paste("genes as in the glmnet model. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("gl has p = " , gl$p, " genes.");
        stop(msg);
      }
      # .........................................................................
      

      
      # .................................................................
      # . Generate a text string containing the model summary :
      # .................................................................
      txtSummary = GlmnetDiag.generateRegressSummaryOnTest(ay = ay,
                                                           dfX = dfX,
                                                           gl = gl);
      # .................................................................

      
      # ...........................................................
      # . Write to file :
      # ...........................................................
      if (!append) {
        FS = file(fs, "w");
      } else {
        FS = file(fs, "a");
      }

      cat(txtSummary, file = FS);
      close(FS);
      # ...........................................................

      
      # ..............................................................................      
      cat(" ..........  Wrote statistical summary : ", fs, "\n", sep = "");
      # ..............................................................................

      
      # ...................
      return (txtSummary);
      # ...................
      
}

# =================================================================================================
# . End of GlmnetDiag.writeRegressSummaryOnTest.
# =================================================================================================      







# =================================================================================================
# . GlmnetDiag.generateRegressSummaryOnTest : generates a text string containing a summary of results 
# . ----------------------------------------   for the supervised principal components model
# .                                            applied to an arbitrary test set (regerssion models).
# .   Syntax:
# .
# .        txt = GlmnetDiag.generateRegressSummaryOnTest(ay, dfX, gl);
# .
# .   In:
# .         ay = n : vector of output variable values foe the test samples (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables of the test samples.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene. The number of genes in dfX must be equal to those in gl (see below),
# .                 the model returned by glmnet.
# .
# .        spc = result of glmnet computation, returned
# .              by function Glmnet.computeRegress().
# .
# .   Out:
# .
# .        txt = results on prediction for the test samples using the specified input model.
# .
# =================================================================================================

GlmnetDiag.generateRegressSummaryOnTest <- function(ay, dfX, gl)
{

      # .....................................................................................
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from GlmnetDiag.generateRegressSummaryOnTest: ";
        msg = paste("The input gl is not of class glmnet.regress.");
        stop(msg);
      }

      n = nrow(dfX);     # Number of test samples.
      p = ncol(dfX);     # Number of genes.

      ny = length(ay);   # Number of test samples in output variable vector.      

      if (ny != n) {
        msg = "ERROR: from GlmnetDiag.generateRegressSummaryOnTest: ";        
        msg = paste("The output variable vector for the test samples has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, " test samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.generateRegressSummaryOnTest: ";        
        msg = paste("The input test data matrix does not have the same number of ");
        msg = paste("genes as in the glmnet model.");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("gl has p = " , gl$p, " genes.");
        stop(msg);
      }
      # .....................................................................................      


      
      # ...................................................................................
      # . Compute the principal components and the predicted output values, using 
      # . the training set-derived means and principal component vectors.
      # . This call returns :
      # .        sl$axi = n : vector of prognostic indices xi = beta0 + beta . x
      # .     sl$ayPred = n : vector of predicted output values.
      # .    sl$aPyPred = n : vector of estimated P(y = 1|x) valyes.
      # ...................................................................................      
      sl = Glmnet.computeRegressOutputVariable(gl, dfX);
      # ...................................................................................


      
      
      # ...................................................................................
      # . >>For LOGISTICS REGRESSION:
      # .   Compute ROC, error statistics and confusion matrix :
      # ...................................................................................      
      if (gl$modelType == 'logistic') {
        #xxx roc = Stat.basicROC(sl$aPyPred, ay,
        roc = Stat.basicROC(sl$axi, ay,                      # J. Theilhaber.
                            flagPval = TRUE,
                            flagConfInterval = TRUE,
                            flagNormalModel = TRUE,
                            prob = 0.95);

        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);
        cm = Stat.generateBinaryConfusionMatrix(ay, sl$ayPred);   
      }
      # ...................................................................................      
      

      
      # ...........................................................................................
      buf = "# ................................................................\n";
      buf = paste(buf, "# . SUMMARY FOR TEST SAMPLE MODEL COMPUTATION:                    \n", sep = "");
      buf = paste(buf, "# ................................................................\n", sep = "");
      buf = paste(buf, "\n", sep = "");            
      # ............................................................................................




      # ......................................................................................
      # . Parameters used in the computation, and results of the feature selection :
      # ......................................................................................
      buf = paste(buf, "#GENERAL PARAMETERS:\n", sep = "");      
      buf = paste(buf, "#Number of samples in test data matrix: n = " , nrow(dfX), "\n", sep = "");
      buf = paste(buf, "#Number of genes in test data matrix: p = " , ncol(dfX), "\n", sep = "");

      # ......................................................................................

      

      # ......................................................................................
      # . >> LINEAR REGRESSION model :
      # ......................................................................................      
      if (gl$modelType == 'lm') {
        lr = Stat.basicLinearRegression(sl$ayPred, ay)

        sigmaTemp = sprintf("%8.3e", lr$sigma);
        R2Temp = sprintf("%8.3e", lr$R2);
        eps2Temp = sprintf("%8.3e", lr$eps2);
        pvalTemp = sprintf("%8.3e", lr$pval);
        beta0Temp = sprintf("%8.3e", lr$beta0);
        beta1Temp = sprintf("%8.3e", lr$beta1);                

        buf = paste(buf, "#\n", sep = "");
        buf = paste(buf, "#Linear regression model: predicting test set instances :\n", sep = "");
        buf = paste(buf, "#Compute a univariate linear regression model, ypred ~ y :\n", sep = "");                       
        buf = paste(buf, "#sigma = ", sigmaTemp, "\n", sep = "");      
        buf = paste(buf, "#R2 = ", R2Temp, "\n", sep = "");      
        buf = paste(buf, "#eps2 = ", eps2Temp, "\n", sep = "");
        buf = paste(buf, "#pval = ", pvalTemp, "\n", sep = "");
        buf = paste(buf, "#beta0 = ", beta0Temp, "\n", sep = "");
        buf = paste(buf, "#beta1 = ", beta1Temp, "\n", sep = "");                
      }
      # ......................................................................................


      

      # ...................................................................................
      # . >>For LOGISTICS REGRESSION:
      # .   Compute ROC, error statistics and confusion matrix :
      # ...................................................................................      
      if (gl$modelType == 'logistic') {
        #xxxx roc = Stat.basicROC(sl$aPyPred, ay,
        roc = Stat.basicROC(sl$axi, ay,                            # J. Theilhaber.
                            flagPval = TRUE,
                            flagConfInterval = TRUE,
                            flagNormalModel = TRUE,
                            prob = 0.95);

        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);
        cm = Stat.generateBinaryConfusionMatrix(ay, sl$ayPred);
        # .................................................................
        # . Header :
        # .................................................................        
        temp1 = "#Statistics for discrimination of 1 versus 0 class.\n";
        buf = paste(buf, temp1, sep = "");
        # .................................................................
        # . AUC stats :
        # .................................................................
        temp1 = "#Area under curve (AUC) for ROC, with 95% CI :\n";
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("auc = ", sprintf("%8.3f", aucStats$A), "\n",
                      "aucLo95 = ", sprintf("%8.3f", aucStats$ALo), "\n",
                      "aucHi95 = ", sprintf("%8.3f", aucStats$AHi), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        # .................................................................
        # . P-value from Wilcox test :
        # .................................................................
        temp1 = "#P-value for significance of discrimination :\n";
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("pval (Wilcox) = ", sprintf("%8.3e", roc$pval), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        # .................................................................
        # . Error rate :
        # .................................................................
        temp1 = "#Error rate and S/FP rates under MAP class assignments :\n";
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("errCount = ", sprintf("%8.3e", cm$errCount), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("errMAP = ", sprintf("%8.3e", cm$errRate), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("errMAPLo95 = ", sprintf("%8.3e", cm$errRateLo95), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("errMAPHi95 = ", sprintf("%8.3e", cm$errRateHi95), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");                
        # .................................................................
        # . S/FP rates under MAP class assignments :
        # .................................................................
        temp1 = paste("S_MAP = ", sprintf("%8.3e", roc$aS[roc$jMAP]),
                      " (sensitivity in detecting class = 1 under MAP assignments)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("FP_MAP = ", sprintf("%8.3e", roc$aFP[roc$jMAP]),
                      " (FP rate in detecting class = 1 under MAP assignments)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");                
        # .................................................................
        # . Confusion matrix :
        # .................................................................
        temp1 = "#Confusion matrix :\n";
        buf = paste(buf, temp1, sep = "");

        temp1 = DataFrame.generateTextNum(cm$Mmarg, "%5.0f");   # Confusion matrix with margins.
        buf = paste(buf, temp1, "\n", sep = "");        
        # .................................................................        
      }
      # ...................................................................................      
      

      
      # .............
      return (buf);
      # .............

}

# =================================================================================================
# . End of GlmnetDiag.generateRegressSummaryOnTest.
# =================================================================================================









# =================================================================================================
# . GlmnetDiag.writeRegressDataMatrix : for each sample in the input data matrix, this writes 
# . ----------------------------------  a record containing the corresponding                 
# .                                     prediction for the output variable y, with the input  
# .                                     experimental design columns joined.                   
# .
# .   Syntax:
# .
# .           GlmnetDiag.writeRegressDataMatrix(gl, ay, dfX, dfE, fo);
# .
# .   In:
# .
# .        gl = result of supervised principal components computation, returned
# .              by function Glmnet.computeRegress().
# .
# .        ay = array of response values. Its length must be equal to the number of rows in dfX.
# .
# .       dfX = input data frame. It must have the same number and identity of genes as the dataframe
# .             used in Glmnet.computeRegress(), but can refer to the same or different samples.
# .
# .       dfE = experimental design data frame. It must have the same number of rows as dfX.
# .
# .        fo = name of output file.
# .
# =================================================================================================

GlmnetDiag.writeRegressDataMatrix <- function(gl, ay, dfX, dfE, fo)
{

      # ...........................................................
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from GlmnetDiag.writeRegressDataMatrix: ";
        msg = paste("The input gl is not of class glmnet.regress.");
        stop(msg);
      }
      # ...........................................................

      
      
      # ................................................................
      # . Consistency check for input objects :
      # ................................................................
      n = nrow(dfX);
      p = ncol(dfX);
      # ................................................................
      # . Check on genes :
      # ................................................................     
      if (p != gl$p) {
        msg = "ERROR: from GlmnetDiag.writeRegressDataMatrix: ";
        msg = paste(msg, " Input data frame has p = ", p,
                         " genes, not same as gl$p = ", gl$p, sep = "");
        stop(msg);
      }

      buf = (colnames(dfX) == gl$ac);    # Gene names must be the same.
      nbuf = length(which(buf == FALSE));

      if (nbuf > 0) {
        msg = "ERROR: from GlmnetDiag.writeRegressDataMatrix: ";
        msg = paste(msg, " Gene names in input data frame not the same as in gl.", sep = "");
        msg = paste(msg, " Number different = ", nbuf, sep = "");
        stop(msg);
      }
      # ................................................................
      # . Check on number of samples :
      # ................................................................     
      ne = nrow(dfE);

      if (ne != n) {
        cat("ERROR: from GlmnetDiag.writeRegressDataMatrix:\n");
        cat("Input experimental design has ne = ", ne, " rows ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }

      ny = length(ay);

      if (ny != n) {
        cat("ERROR: from GlmnetDiag.writeRegressDataMatrix:\n");
        cat("Input ay has ny = ", ny, " elements ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }
      # ................................................................
      

      # ..............................................................
      # . Generate the output data frame :
      # ..............................................................
      dfOut = GlmnetDiag.generateRegressDataMatrix(gl, ay, dfX, dfE);
      # ..............................................................

      
      # .............................................
      # . Write to file :
      # .............................................
      DataFrame.writeFlat(dfIn = dfOut, fo = fo);
      # .............................................


      # ...........................................................................      
      cat(" ..........  Wrote regression model data matrix : ", fo, "\n", sep = "");
      # ...........................................................................

      
      # ..........
      return (0);
      # ..........
      
}

# =================================================================================================
# . End of GlmnetDiag.writeRegressDataMatrix.
# =================================================================================================      





# =================================================================================================
# . GlmnetDiag.generateRegressDataMatrix : for each sample in the input data matrix, this generates
# . --------------------------------------   a record containing the corresponding                 
# .                                          prediction for the output variable y, with the input  
# .                                          experimental design columns joined.                   
# .                                        
# .   Syntax:
# .
# .           dfOut = GlmnetDiag.generateRegressDataMatrix(gl, ay, dfX, dfE);
# .
# .   In:
# .
# .        gl = result of supervised principal components computation, returned
# .              by function SuperPc.computeCox().
# .
# .        ay = array of response values. Its length must be equal to the number of rows in dfX.
# .
# .       dfX = input data frame. It must have the same number and identity of genes as the dataframe
# .             used in SuperPc.computeRegress(), but can refer to the same or different samples.
# .
# .       dfE = experimental design data frame. It must have the same number of rows as dfX.
# .
# .   Out:
# .     dfOut = data frame with as many rows as there are samples in dfX, and with the same
# .             row names, and with columns :
# .
# .                yPC1, yPC2, . . . , yPCK, yPred, sigmaY, columns(dfE)
# .
# .             where yPC1, . . ., yPCK are the values of the first K principal components,
# .             yPred the predicted value of the output variable for the corresponding sample,
# .             sigmaY the estimate of the standard error for that sample, and columns(dfE)
# .             refers to all the columns of the input experimental design in dfE.
# .
# =================================================================================================

GlmnetDiag.generateRegressDataMatrix <- function(gl, ay, dfX, dfE, fo)
{

      # ...........................................................
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from GlmnetDiag.generateRegressDataMatrix: ";
        msg = paste("The input gl is not of class glmnet.regress.");
        stop(msg);
      }
      # ...........................................................

      
      # .........................................................................
      #xxx cat(" ..........  Entry in GlmnetDiag.generateRegressDataMatrix.\n");
      # .........................................................................


      # .........................................................................
      stopifnot((gl$modelType == 'lm') || (gl$modelType == 'logistic'));
      # .........................................................................      


      # ................................................................
      # . Consistency check for input objects :
      # ................................................................
      n = nrow(dfX);
      p = ncol(dfX);
      # ................................................................
      # . Check on genes :
      # ................................................................     
      if (p != gl$p) {
        msg = "ERROR: from GlmnetDiag.generateRegressDataMatrix: ";
        msg = paste(msg, " Input data frame has p = ", p,
                         " genes, not same as gl$p = ", gl$p, sep = "");
        stop(msg);
      }

      buf = (colnames(dfX) == gl$ac);    # Gene names must be the same.
      nbuf = length(which(buf == FALSE));

      if (nbuf > 0) {
        msg = "ERROR: from GlmnetDiag.generateRegressDataMatrix: ";
        msg = paste(msg, " Gene names in input data frame not the same as in gl.", sep = "");
        msg = paste(msg, " Number different = ", nbuf, sep = "");
        stop(msg);
      }
      # ................................................................
      # . Check on number of samples :
      # ................................................................     
      ne = nrow(dfE);

      if (ne != n) {
        cat("ERROR: from GlmnetDiag.generateRegressDataMatrix:\n");
        cat("Input experimental design has ne = ", ne, " rows ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }

      ny = length(ay);

      if (ny != n) {
        cat("ERROR: from GlmnetDiag.generateRegressDataMatrix:\n");
        cat("Input ay has ny = ", ny, " elements ",
            "not same as input data frame with n = ", n, " rows.\n", sep = "");
        stop();
      }      
      # ................................................................
      

      
      
      # ...................................................................................
      # . Compute the predicted output values, using the training set-derived column means :
      # . This call returns :
      # .
      # .         axi = nIn-length vector of prognostic indices:  xi = beta0 + beta * x
      # .      ayPred = nIn-length vector of predicted output variable values.
      # .     aPyPred = nIn-length vector of estimated P(y = 1|x) values
      # .               (non-zero for logistic regression; set to dummy all-zero
      # .               values for linear regression).
      # ...................................................................................      
      sl = Glmnet.computeRegressOutputVariable(gl, dfX);
      # ...................................................................................


      # ...................................................................................
      # . Get estimate of sd of noise term :
      # . Note that this is needed only for linear regression.
      # ...................................................................................
      if (gl$modelType == 'lm') {
        lr = Stat.basicLinearRegression(sl$ayPred, ay);        
        asigma = rep(lr$sigma, times = n);                      # Constant error term.
      }
      # ...................................................................................      
      


      # ...................................................................................
      # . Build the output data frame :
      # ...................................................................................      
      ar = rownames(dfX);                                       # The row names array.
      flagDONE = FALSE;                                         # Failsafe.
      
      if (gl$modelType == 'lm') {
        dfOut = cbind(ar, sl$ayPred, asigma);                   # Concat. row names array and num. data.
        colnames(dfOut) = c('#QUAL', 'yPred', 'sigmaY');
        flagDONE = TRUE;                
      }

      if (gl$modelType == 'logistic') {
        dfOut = cbind(ar, sl$aPyPred, sl$ayPred);   # Concat. row names array and num. data.
        colnames(dfOut) = c('#QUAL', 'P(y=1)_Pred', 'yPred');
        flagDONE = TRUE;                        
      }

      stopifnot(flagDONE);                                       # Failsafe.

      dfOut = cbind(dfOut, dfE);                                 # Add the experimental design.
      # ...................................................................................

      
      # ...............
      return (dfOut);
      # ...............
      
}

# =================================================================================================
# . End of GlmnetDiag.generateRegressDataMatrix.
# =================================================================================================      






# =================================================================================================
# . GlmnetDiag.plotRegress : displays the results of an analysis using regression models
# . -----------------------   in the form of a series of plots.
# .
# .   Syntax:
# .
# .       sp = GlmnetDiag.plotRegress(ay, dfX, gl, flagWrite, dirName, stemName);
# .
# .   In:
# .            ay = n : vector of output variable values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .            gl = result of glmnet computation, returned
# .                 by function Glmnet.computeRegress().
# .
# .     flagWrite = no/yes : flag indicating whether plots should be written to file in jpeg
# .                 format instead of being displayed.
# .                 If value is 'yes', each plot will be written to a file in the directory
# .                 indicated by 'dirName', with a name given by 'stemName' followed by
# .                 a random string and the .jpg extension.
# .                 If value is 'no', the user is prompted to interactively provide carriage
# .                 returns to march through the display.
# .
# .       dirName = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .      stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .   Out:
# .
# .           - If flagWrite = 'no', displays a series of plots. The use enter carriage returns
# .           to advance from one plot to the next.
# .           Object sp returned is NULL.
# .
# .           - If flagWrite = 'yes', generates a series of plot files, as indicated above.
# .           Object sp returned is a list with members:
# .
# .                  nplot = number of plot files generated.
# .                  afile = array of file names.
# .                  aplot = array of plot names.
# .
# =================================================================================================

GlmnetDiag.plotRegress <- function(ay, dfX, gl,
                                   flagWrite = 'no',
                                   dirName = NULL, stemName = NULL)
{

      # .............................................................
      cat(" ..........  Entry in GlmnetDiag.plotRegress.\n");
      # .............................................................

      
      # .............................................................
      stopifnot((flagWrite == 'no') || (flagWrite == 'yes'));
      # .............................................................
      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from GlmnetDiag.plotRegress: ";
        msg = paste("The input gl is not of class glmnet.regress.\n");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.

      ny = length(ay);   # Number of samples in output variable vector.      

      if (ny != n) {
        msg = "ERROR: from GlmnetDiag.plotRegress: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.plotRegress: ";        
        msg = paste("The input data matrix does not have the same number of ");
        msg = paste("genes as in the glmnet computation. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("Gl has p = " , gl$p, " genes.");
        stop(msg);
      }

     if (gl$n != n) {
        msg = "ERROR: from GlmnetDiag.plotRegress: ";        
        msg = paste("The input data matrix does not have the same number of ");       
        msg = paste("samples as in the glmnet computation. ");
        msg = paste("Input has n = " , n, " samples. ");
        msg = paste("Gl has n = " , gl$n, " samples.");        
        stop(msg);
      }
      # ...............................................................................................

      
      # ...................................................................................
      dfXc = scale(dfX, center = TRUE, scale = FALSE);  # Center each gene separately.
      dfXSel = dfXc[ , gl$indexSel];                   # Subsetted to the selected genes.

      if (length(gl$indexSel) == 1) {
        dfXSel = data.frame(dfXSel);
        colnames(dfXSel) = colnames(dfXc)[gl$indexSel];
        rownames(dfXSel) = rownames(dfXc);
      }
      
      agene = colnames(dfXSel);                         # Selected gene names, in feature selection order.
      asample = rownames(dfXSel);                       # Sample names.

      nsel = nrow(dfXSel);                              # Number of samples.
      msel = ncol(dfXSel);                              # Number of subsetted genes.            
      # ...................................................................................

      
      # .......................................................
      # . Reset some defaults, in case they got changed :
      # .......................................................      
      par(ask = FALSE);
      par(mfrow = c(1,1));      
      # .......................................................


      # .......................................................................................
      if (flagWrite == 'no') {
        cat("\n");
        cat(" ..........  Enter carriage returns as indicated to generate plots one-by-one.\n");
      } else if (flagWrite == 'yes') {
        cat(" ..........  Generating plot files in directory = ", dirName, "\n", sep = "");
      }
      # .......................................................................................


      # ...........................................................
      # . Initialize plot arrays :
      # ...........................................................
      afile = c();
      aplot = c();

      if (flagWrite == 'no') {
        dirName = "foo";        # Dummy value.
        stemName = "dum";       # Dummy value.
      }
      # ...........................................................

      
      
      # .......................................................................................
      if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................
      


      
      # .......................................................................................
      # . Plot the regularization paths :
      # .
      # . Generate file name :
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      # .......................................................................................
      # . Select captions based on clustering scheme :
      # .......................................................................................      
      pname = paste("Regularization paths", sep = ""); 
      afile = c(afile, fname);
      aplot = c(aplot, pname);                        
      # .......................................................................................
      # . Initilialize device :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname, width = 720, height = 720);              # Turn on plot device.
      }
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      alphaBuf = sprintf("%8.3e", gl$alpha);      
      lambdaBuf = sprintf("%8.3e", gl$lambda);

      cex.main.OLD = par("cex.main");
      par(cex.main = 0.7);
      
      caption = paste(pname," (alpha = ", alphaBuf, ", lambda = ", lambdaBuf, ")", sep = "");
      plot(gl$fitG, xvar = 'lambda', main = caption);
      # .......................................................................................
      # . Mark actual value used :
      # .......................................................................................
      lambdaTemp = gl$lambda;
      
      if (gl$lambda < min(gl$fitG$lambda)) {
        lambdaTemp = min(gl$fitG$lambda);
      } else if (gl$lambda > max(gl$fitG$lambda)) {
        lambdaTemp = max(gl$fitG$lambda);
      }
      
      temp1 = log(lambdaTemp);
      abline(v = temp1, lty = 'dashed');
      # .......................................................................................
      par(cex.main = cex.main.OLD);      
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }                  
      # .......................................................................................




      # .......................................................................................
      # . Plot the cross-validation results :
      # .
      # . Generate file name :
      # .......................................................................................
      if (gl$flagCv == 'yes') {
        # .......................................................................................        
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        # .......................................................................................
        # . Select captions based on clustering scheme :
        # .......................................................................................      
        pname = paste("Cross-validation results", sep = ""); 
        afile = c(afile, fname);
        aplot = c(aplot, pname);                        
        # .......................................................................................
        # . Initilialize device :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname, width = 720, height = 820);              # Turn on plot device.
        }
        # .......................................................................................
        # . Retrieve some additional information :
        # .......................................................................................
        lambda.min = gl$cv.fitG$lambda.min;
        lambda.1se = gl$cv.fitG$lambda.1se;
        lambda.min.Buf = sprintf("%8.3e", gl$cv.fitG$lambda.min);
        lambda.1se.Buf = sprintf("%8.3e", gl$cv.fitG$lambda.1se);
        
        nameBuf = gl$cv.fitG$name;             # Type of measure used.
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        alphaBuf = sprintf("%8.3e", gl$alpha);      
        lambdaBuf = sprintf("%8.3e", gl$lambda);

        cex.main.OLD = par("cex.main");
        mai.OLD = par("mai");               # Margin size in inches : c(bottom, left, top, right)
        buf = mai.OLD;
        buf[3] = 2.0;                       # Change the top margin.

        par(mai = buf);
        par(cex.main = 0.7);
      
        caption = paste(pname," measure = ", nameBuf,
                              " (alpha = ", alphaBuf, ", lambda = ", lambdaBuf, ")",
                              "\nlambda.min = ", lambda.min.Buf, ", lambda.1se = ", lambda.1se.Buf, ")",          
                              sep = "");
        
        plot(gl$cv.fitG, main = caption);
        # .......................................................................................
        # . Mark actual value used :
        # .......................................................................................
        lambdaTemp = gl$lambda;
      
        if (gl$lambda < min(gl$fitG$lambda)) {
          lambdaTemp = min(gl$fitG$lambda);
        } else if (gl$lambda > max(gl$fitG$lambda)) {
          lambdaTemp = max(gl$fitG$lambda);
        }
      
        temp1 = log(lambdaTemp);
        abline(v = temp1, lty = 'dashed', col = 'red');
        # .......................................................................................
        par(mai = mai.OLD);        
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      
      
      
      # ..........................................................................................................
      # . HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS
      # .
      # . Generate heat maps below, provided the data matrices are not too large.
      # .
      # . First, plot of the entire data matrix, before any feature selection :
      # ..........................................................................................................
      if (p > SuperPcDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the entire data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here p = ", p, " while the maximum is given by SuperPcDiag.MSELMAX = ", SuperPcDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat map for entire data matrix and continue execution.\n");
      }

      if (p <= SuperPcDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the p * n data matrix before any feature selection.
        # . No clustering or sorting of any kind.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Training set data matrix";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ABuf = t(dfX);              # Make this genes * samples.

        if (flagWrite == 'yes') {
          #xxx jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.                    
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ABuf, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................      
      }
      # ..........................................................................................................

      
      # ..........................................................................................................
      # . Next, plot of the data matrix after feature selection :
      # ..........................................................................................................
      if (msel > SuperPcDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the feature-selected data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here msel = ", msel, " while the maximum is given by SuperPcDiag.MSELMAX = ", SuperPcDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat maps of feature-selected data matrix and continue execution.\n");
      }

      if (msel <= SuperPcDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the m * n data matrix after feature selection.
        # . Samples not sorted. Genes in order of feature selection, but otherwise not clustered.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste(gl$m, " selected genes. Samples not sorted. Genes not clustered.", sep = "");      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ASel = as.matrix(t(dfXSel));   # m * n = genes * samples format.

        if (flagWrite == 'yes') {
          #xxxx    jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.                    
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ASel,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................      
        # . Sort samples so that the shortest survival times are on the left.
        # .......................................................................................
        sBuf = sort(ay, decreasing = FALSE, index.return = TRUE);
        indexSort = sBuf[["ix"]];      # Sort index.

        ASort = ASel[ , indexSort];    # Sorted on columns.
        # .......................................................................................
        # . Samples sorted, genes not clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste(gl$m, " selected genes. Samples sorted ",
                      " with increasing output variable left-to-right.",
                      " Genes not clustered.", sep = "");
        caption = paste(gl$m, " sel. genes. Samples sorted increas. output var. LtR. Genes not clustered.", sep = "");      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.                    
        }
            
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
        # . Samples sorted, genes clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste(gl$m, " selected genes. Samples sorted with",
                      " increasing output variable left-to-right. Genes clustered.", sep = "");
        caption = paste(gl$m, " sel. genes. Samples sorted incr. output var. LtR. Genes clustered.", sep = "");
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.                              
        }
            
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'yes',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # ......................................................................................................
      # . END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS
      # ......................................................................................................



      # .......................................................................................
      # . Generate the sort key for plotting with the smallest output variable values
      # . on the left.
      # .......................................................................................
      sBuf = sort(ay, decreasing = FALSE, index.return = TRUE);
      indexSort = sBuf[["ix"]];      # Sort index.
      # .......................................................................................



      
      # .......................................................................................
      # . Output values under the sort key :
      # . Plot the values of the output variable, with samples sorted so that the
      # . smallest values are on the left.  This generates a plot with the same
      # . sample order as in the last two heat maps above, which can then be used a a
      # . reference.      
      # .
      # . Generate file name :
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      # .......................................................................................
      # . Select captions based on clustering scheme :
      # .......................................................................................      
      pname = paste("Output variable with samples sorted", sep = ""); 
      afile = c(afile, fname);
      aplot = c(aplot, pname);                        
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }

      aySort = ay[indexSort];       # Sorted output variables.
      acSort = asample[indexSort];  # Corresponding sample names.

      par(mfrow = c(2, 1));
      caption = "Sorted output variable";
      plot(aySort, xaxt = 'n', xlab = 'samples (sorted)', pch = 19, main = caption);
      axis(side = 1, at = 1:length(acSort), labels = acSort);
      par(mfrow = c(1, 1));
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }                  
      # .......................................................................................

      

      
      # ...................................................................................
      # . Compute the predicted output values, using 
      # . the training set-derived means and glmnet model :
      # . This call returns :
      # .        sl$axi = n : vector of prognostic indices xi = beta0 + beta . x
      # .     sl$ayPred = n : vector of predicted output values.
      # .    sl$aPyPred = n : vector of estimated P(y = 1|x) valyes.
      # ...................................................................................      
      sl = Glmnet.computeRegressOutputVariable(gl, dfX);
      # ...................................................................................
      # . Get the model error terms :
      # ...................................................................................
      if (gl$modelType == 'lm') {      
        eR = Stat.basicLinearRegression(sl$ayPred, ay);    # Observed versus predicted y.
      }

      if (gl$modelType == 'logistic') {
        #xxx roc = Stat.basicROC(sl$aPyPred, ay,
        roc = Stat.basicROC(sl$axi, ay,                    # J. Theilhaber.
                           flagPval = TRUE,
                           flagConfInterval = TRUE,
                           flagNormalModel = TRUE,
                           prob = 0.95);
        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);        
      }
      # ...................................................................................
      


      # .......................................................................................
      # . >>For LINEAR REGRESSION :
      # .   Plot the predicted output variable against the OBSERVED values.
      # .......................................................................................
      if (gl$modelType == 'lm') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Predicted versus training values for output variable';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        R2Temp = sprintf("%8.3e", eR$R2);
        eps2Temp = sprintf("%8.3e", eR$eps2);
        pvalTemp = sprintf("%8.3e", eR$pval);      
      
        caption = paste("Predicted vs training Y: P = ", pvalTemp, ", R2 = ", R2Temp, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        plot(ay, sl$ayPred, xlab = 'y input values (training set)', ylab = 'y predicted values',
             main = caption, pch = 19);
        abline(h = 0);
        abline(v = 0);
        # ...........................................................................
        # . Add regression line and 1 s.e. confidence interval :
        # ...........................................................................
        if (eR$beta1 != 0) {
          beta0Prime = - eR$beta0 / eR$beta1;      # Transform because basic regression
          beta1Prime = 1.0 / eR$beta1;             # was done for y versus y_predicted.
          sigmaPrime = eR$sigma / abs(eR$beta1);

          abline(a = beta0Prime, b = beta1Prime, lty = 'dashed');
          a_lo = beta0Prime - sigmaPrime;
          a_hi = beta0Prime + sigmaPrime;
          abline(a = a_lo, b = beta1Prime, lty = 'dashed');
          abline(a = a_hi, b = beta1Prime, lty = 'dashed');
        }
        # ...........................................................................                
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................




      # .......................................................................................
      # . >>For LINEAR REGRESSION :
      # .   Plot the OBSERVED values against the predicted output.
      # . This is the SAME plot as above, but with reversed axes.
      # .......................................................................................
      if (gl$modelType == 'lm') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Training set values versus predicted values for output variable';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        R2Temp = sprintf("%8.3e", eR$R2);
        eps2Temp = sprintf("%8.3e", eR$eps2);
        pvalTemp = sprintf("%8.3e", eR$pval);      
      
        caption = paste("Training vs predicted Y: model P = ", pvalTemp, ", R2 = ", R2Temp, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        plot(sl$ayPred, ay, xlab = 'y predicted values', ylab = 'y input values (training set)', 
             main = caption, pch = 19);
        abline(h = 0);
        abline(v = 0);
        # ...........................................................................
        # . Add regression line and 1 s.e. confidence interval :
        # ...........................................................................        
        abline(a = eR$beta0, eR$beta1, lty = 'dashed');
        a_lo = eR$beta0 - eR$sigma;
        a_hi = eR$beta0 + eR$sigma;
        abline(a = a_lo, eR$beta1, lty = 'dashed');
        abline(a = a_hi, eR$beta1, lty = 'dashed');
        # ...........................................................................         
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      

      # .......................................................................................
      # . >>For LINEAR REGRESSION :      
      # . Plot residuals versus training set values for output variable.
      # .......................................................................................
      if (gl$modelType == 'lm') {      
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Residuals versus input values of y';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        caption = paste("Residuals vs input values of y", sep = "");

        plot(ay, eR$ares, xlab = 'y input values (training set)', ylab = 'residuals (yPred - y)',
             main = caption, pch = 19);
        abline(h = 0.0);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................
      
      


      

      # .......................................................................................
      # . >>for LINEAR REGRESSION :            
      # . Generate a normal QQ plot for the model residuals :
      # .......................................................................................
      if (gl$modelType == 'lm') {            
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Normal QQ plot for model residuals';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        caption = paste("Normal QQ plot for model residuals", sep = "");

        Stat.qqNormCI(eR$ares, caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................
      


      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   Plot the actual output values against estimated P(y = 1|x).
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Training values for output variable versus estimated P(y = 1|x)';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);             # Area under curve.
        pvalTemp = sprintf("%8.3e", roc$pval);         # P-value for detection of y = 1 versus y = 0.
        errMAPTemp = sprintf("%8.3e", roc$errMAP);     # Error rate under MAP classification.
      
        caption = paste("actual Y versus P(y=1|x): AUC = ", ATemp,
                        ", P-value = ", pvalTemp,
                        ", errMAP = ", errMAPTemp,
                        sep = "");        

        ayJitter = ay + 0.1 * (runif(length(ay)) - 0.5);   # Add vertical jitter of plus-minus 0.05.
        
        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        plot(sl$aPyPred, ayJitter, xlab = 'estimated P(y=1|x)', ylab = 'y input values (training set)',
             main = caption, pch = 19);
        abline(h = 0);
        abline(h = 1, lty = 'dashed');        
        abline(v = 0);
        abline(v = 0.5, lty = 'dashed');        
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................

      

      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   Plot the actual output values against estimated the prognostic index,
      # .   xi = beta0 + beta * x.
      # .   This is almost identical to the previous plot, but with prognostic
      # .   index = logit(P(y=1|x)) replacing P(y=1|x) estimated values.
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Training values for output variable versus xi = beta0 + beta . x';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);             # Area under curve.
        pvalTemp = sprintf("%8.3e", roc$pval);         # P-value for detection of y = 1 versus y = 0.
        errMAPTemp = sprintf("%8.3e", roc$errMAP);     # Error rate under MAP classification.
      
        caption = paste("actual Y versus PI xi = beta0 + beta . x: AUC = ", ATemp,
                        ", P-value = ", pvalTemp,
                        ", errMAP = ", errMAPTemp,
                        sep = "");        

        ayJitter = ay + 0.1 * (runif(length(ay)) - 0.5);   # Add vertical jitter of plus-minus 0.05.
        
        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        plot(sl$axi, ayJitter, xlab = 'prognostic index', ylab = 'y input values (training set)',
             main = caption, pch = 19);
        abline(h = 0);
        abline(h = 1, lty = 'dashed');
        abline(v = 0);
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      

      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   Plot the model fit : graph P(y=1|x) versus prognostic index xi = beta0 + beta . x,
      # .   and add rug plots of data points and binned estimates of P(y=1|x).
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Fit for logistic model';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);                    # AUC for detection of 1 versus 0.
        caption = paste("Fit for logistic model; n = ", gl$n, "; AUC = ",
                        ATemp, sep = "");

        ncut = floor(gl$n / 10);
        if (ncut < 2) {
          ncut = 2;
        } else if (ncut > 10) {
          ncut = 10;
        }
        
        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);        
        Logistic.plotFitOnArrays(sl$axi, ay, 
                                 xlab = 'prognostic index', 
                                 ylab = 'estimated P(y=1|x)',
                                 caption = caption,
                                 ncut = 10);
        par(cex.main = cex.main.OLD);        
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................



      

      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   1. Plot the empirical ROC and approximations from various models :
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'ROCs based on estimated P(y = 1|x), with binormal approximation';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Generate ROCs and compute stats on AUC :
        # .......................................................................................
#        roc = Stat.basicROC(sl$aPyPred, ay,
#                            flagPval = TRUE,
#                            flagConfInterval = TRUE,
#                            flagNormalModel = TRUE,
#                            prob = 0.95);

#        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);           # Area under curve.
        pvalTemp = sprintf("%8.3e", roc$pval);       # Wilcoxon P-value for detection of y = 1 versus y = 0.
        errMAPTemp = sprintf("%8.3e", roc$errMAP);   # Error rate under MAP classification.
        errMinTemp = sprintf("%8.3e", roc$errMin);   # Minimum error rate.
      
        caption = paste("ROC: AUC = ", ATemp,
                        ", P-value = ", pvalTemp,
                        ", errMAP = ", errMAPTemp,
                        ", errMin = ", errMinTemp,
                        sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        # ........................................................................
        # . Plot empirical ROC :
        # ........................................................................        
        plot(roc$aFP, roc$aS,
             xlim = c(0, 1),
             ylim = c(0, 1),
             xlab = 'FP',
             ylab = 'S',
             main = caption,
             type = 'l',
             lwd = 2,
             pch = 19);

        points(roc$aFP[roc$jMAP], roc$aS[roc$jMAP], pch = 19);
        points(roc$aFP[roc$jMin], roc$aS[roc$jMin], pch = 19, col = 'red');        
        # ........................................................................
        # . Add analytic null distribution plus-minus 1 sd, and binormal
        # . model approximation :
        # ........................................................................        
        lines(roc$aFPnull, roc$aSnull, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullLo, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullHi, type = 'l', col = 'blue');        

        lines(roc$aFPnormal, roc$aSnormal, lty = 'dashed');
        # ........................................................................
        # . Add legend :
        # ........................................................................
        legendText = c("empirical", "binormal", "null, CI 95%");
        colVector = c('black', 'black', 'blue');
        ltyVector = c('solid', 'dashed', 'solid');
        lwdVector = c(2, 1, 1);        
        legend(x = 0.6, y = 0.3,
               legend = legendText, 
               col = colVector, lty = ltyVector, lwd = lwdVector, bty = 'n');
        
        legendText = c("MAP", "Min");
        colVector = c('black', 'red');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = 0.6, y = 0.12,
               legend = legendText,
               col = colVector, pch = pchVector, bty = 'n');
        
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................




      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   2. Plot the empirical ROC and approximations from various models :
      # .   This is almost identical to the previous plot, but here we do not
      # .   display the binormal model approximation, but add the confidence interval
      # .   for the emprical ROC.
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'ROCs based on estimated P(y = 1|x), with empirical confidence interval';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Generate ROCs and compute stats on AUC :
        # .......................................................................................
        #xxx roc = Stat.basicROC(sl$aPyPred, ay,
        roc = Stat.basicROC(sl$axi, ay,                       # J. Theilhaber.
                            flagPval = TRUE,
                            flagConfInterval = TRUE,
                            flagNormalModel = TRUE,
                            prob = 0.95);

        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);           # Area under curve.
        pvalTemp = sprintf("%8.3e", roc$pval);       # Wilcoxon P-value for detection of y = 1 versus y = 0.
        errMAPTemp = sprintf("%8.3e", roc$errMAP);   # Error rate under MAP classification.
        errMinTemp = sprintf("%8.3e", roc$errMin);   # Minimum error rate.
      
        caption = paste("ROC: AUC = ", ATemp,
                        ", P-value = ", pvalTemp,
                        ", errMAP = ", errMAPTemp,
                        ", errMin = ", errMinTemp,
                        sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        # ........................................................................
        # . Plot empirical ROC :
        # ........................................................................        
        plot(roc$aFP, roc$aS,
             xlim = c(0, 1),
             ylim = c(0, 1),
             xlab = 'FP',
             ylab = 'S',
             main = caption,
             type = 'l',
             lwd = 2,
             pch = 19);

        points(roc$aFP[roc$jMAP], roc$aS[roc$jMAP], pch = 19);
        points(roc$aFP[roc$jMin], roc$aS[roc$jMin], pch = 19, col = 'red');        
        # ........................................................................
        # . Add analytic null distribution plus-minus 1 sd, and confidence
        # . interval for the empirical ROC :
        # ........................................................................        
        lines(roc$aFPnull, roc$aSnull, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullLo, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullHi, type = 'l', col = 'blue');        

        lines(roc$aFP, roc$aSLo, lty = 'dashed');
        lines(roc$aFP, roc$aSHi, lty = 'dashed');        
        # ........................................................................
        # . Add legend :
        # ........................................................................
        legendText = c("empirical", "emp. CI, 95%", "null, CI 95%");
        colVector = c('black', 'black', 'blue');
        ltyVector = c('solid', 'dashed', 'solid');
        lwdVector = c(2, 1, 1);        
        legend(x = 0.6, y = 0.3,
               legend = legendText, 
               col = colVector, lty = ltyVector, lwd = lwdVector, bty = 'n');
        
        legendText = c("MAP", "Min");
        colVector = c('black', 'red');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = 0.6, y = 0.12,
               legend = legendText,
               col = colVector, pch = pchVector, bty = 'n');
        
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................



      
      # .......................................................................................
      # . Regression coefficients (gene loadings):
      # .
      # . Generate file name :            
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      pname = "Regression coefficients (gene loadings)";
      afile = c(afile, fname);
      aplot = c(aplot, pname);
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }
      
      par(mfrow = c(2, 2));
      # .......................................................................................
      # . Generate selected genes subsets :
      # .......................................................................................
      ageneSel = gl$ac[gl$indexSel];
      abetaSel = gl$abeta[gl$index];
      # .......................................................................................
      # . Gene loadings, unsorted :
      # .......................................................................................
      xlab = paste("gene index (m = ", gl$m, ")", sep = "");
      ylab = expression(beta);
      plot(1:gl$m, abetaSel,
           xlab = xlab, ylab = ylab, main = "Regression coefficients -- not sorted",
           xaxt = 'n', pch = 19);
      abline(h = 0.0);

      axis(side = 1, at = 1:length(ageneSel), labels = ageneSel);         
      # .......................................................................................
      # . Gene loadings, sorted :
      # .......................................................................................      
      sBuf = sort(abetaSel, index.return = TRUE);
      abetaBuf = sBuf[["x"]];             # The sorted data.
      indexBuf = sBuf[["ix"]];            # The sorting index.
      ageneBuf = ageneSel[indexBuf];
      
      xlab = paste("gene index (m = ", gl$m, ")", sep = "");
      ylab = expression(beta * V);
      plot(1:gl$m, abetaBuf,
           xlab = xlab, ylab = ylab, main = "Regression coefficients -- sorted",
           xaxt = 'n', pch = 19);
      abline(h = 0.0);
      
      axis(side = 1, at = 1:length(ageneBuf), labels = ageneBuf);       
      # .......................................................................................
      par(mfrow = c(1, 1));
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {
        buf = readline(">>Enter a carriage return to continue: ");
      }
      # .......................................................................................
     


      
      # .......................................................................................
      # . Final tally :
      # .......................................................................................      
      nplot = length(afile);
      
      if (flagWrite == 'yes') {
        cat(" ..........  ", nplot, " jpeg plot files were generated.\n", sep = "");
      }
      # .......................................................................................

      
      
      # ....................................................................
      # . Package file names and plot names into list.
      # . Note that these are generated (with dummy names in that case)
      # . even if flagWrite = 'no'.
      # .
      # .   nplot = total number of plots in array.
      # .   afile = array of file names.
      # .   aplot = array of corresponding plot names.
      # ....................................................................
      sp = list(nplot = nplot, afile = afile, aplot = aplot);

      class(sp) = 'super.pc.diag.plot';
      # ....................................................................
      
     
      # ...........
      return (sp);
      # ...........

}

# =================================================================================================
# . End of GlmnetDiag.plotRegress.
# =================================================================================================







# =================================================================================================
# . GlmnetDiag.plotRegressTest : displays the results of an analysis using regression models
# . ---------------------------   in the form of a series of plots. Used for test data.
# .
# .   Syntax:
# .
# .       sp = GlmnetDiag.plotRegressTest(ay, dfX, gl, flagWrite, dirName, stemName);
# .
# .   In:
# .            ay = n : vector of output variable values for test samples (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables for test samples.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .            gl = result of glmnet computation, returned by function Glmnet.computeRegress().
# .
# .     flagWrite = no/yes : flag indicating whether plots should be written to file in jpeg
# .                 format instead of being displayed.
# .                 If value is 'yes', each plot will be written to a file in the directory
# .                 indicated by 'dirName', with a name given by 'stemName' followed by
# .                 a random string and the .jpg extension.
# .                 If value is 'no', the user is prompted to interactively provide carriage
# .                 returns to march through the display.
# .
# .       dirName = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .      stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .   Out:
# .
# .           - If flagWrite = 'no', displays a series of plots. The use enter carriage returns
# .           to advance from one plot to the next.
# .           Object sp returned is NULL.
# .
# .           - If flagWrite = 'yes', generates a series of plot files, as indicated above.
# .           Object sp returned is a list with members:
# .
# .                  nplot = number of plot files generated.
# .                  afile = array of file names.
# .                  aplot = array of plot names.
# .
# =================================================================================================

GlmnetDiag.plotRegressTest <- function(ay, dfX, gl,
                                        flagWrite = 'no',
                                        dirName = NULL, stemName = NULL)
{

      # .............................................................
      cat(" ..........  Entry in GlmnetDiag.plotRegressTest.\n");
      # .............................................................

      
      # .............................................................
      stopifnot((flagWrite == 'no') || (flagWrite == 'yes'));
      # .............................................................
      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from GlmnetDiag.plotRegressTest: ";
        msg = paste("The input gl is not of class glmnet.regress.\n");
        stop(msg);
      }

      n = nrow(dfX);     # Number of samples.
      p = ncol(dfX);     # Number of genes.

      ny = length(ay);   # Number of samples in output variable vector.      

      if (ny != n) {
        msg = "ERROR: from GlmnetDiag.plotRegressTest: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");      
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.plotRegressTest: ";        
        msg = paste("The input data matrix does not have the same number of ");
        msg = paste("genes as in the glmnet model. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("gl has p = " , gl$p, " genes.");
        stop(msg);
      }
      # ...............................................................................................

      
      # ...................................................................................
      dfXc = sweep(dfX, 2, gl$axm);                    # Center each column separately.      
      dfXSel = dfXc[ , gl$indexSel];                   # nIn * m data matrix subsetted to the selected genes.

      if (nrow(dfXc) == 1) {
        dfXSel = matrix(dfXSel, nrow = 1);              # Special case for nrow = 1, to preserve matrix geometry.
      }

      if (length(gl$indexSel) == 1) {
        dfXSel = data.frame(dfXSel);
        colnames(dfXSel) = colnames(dfXc)[gl$indexSel];
        rownames(dfXSel) = rownames(dfXc);
      }
      
      agene = colnames(dfXSel);                         # Selected gene names, in feature selection order.
      asample = rownames(dfXSel);                       # Sample names.
      
      nsel = nrow(dfXSel);                              # Number of samples.
      msel = ncol(dfXSel);                              # Number of subsetted genes.            
      # ...................................................................................

      
      # .......................................................
      # . Reset some defaults, in case they got changed :
      # .......................................................      
      par(ask = FALSE);
      par(mfrow = c(1,1));      
      # .......................................................


      # .......................................................................................
      if (flagWrite == 'no') {
        cat("\n");
        cat(" ..........  Enter carriage returns as indicated to generate plots one-by-one.\n");
      } else if (flagWrite == 'yes') {
        cat(" ..........  Generating plot files in directory = ", dirName, "\n", sep = "");
      }
      # .......................................................................................


      # ...........................................................
      # . Initialize plot arrays :
      # ...........................................................
      afile = c();
      aplot = c();

      if (flagWrite == 'no') {
        dirName = "foo";        # Dummy value.
        stemName = "dum";       # Dummy value.
      }
      # ...........................................................

      
      
      # .......................................................................................
      if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................
      

      
      # ..........................................................................................................
      # . HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS
      # .
      # . Generate heat maps below, provided the data matrices are not too large.
      # .
      # . First, plot of the entire data matrix, before any feature selection :
      # ..........................................................................................................
      if (p > SuperPcDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the entire data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here p = ", p, " while the maximum is given by SuperPcDiag.MSELMAX = ", SuperPcDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat map for entire data matrix and continue execution.\n");
      }

      if (p <= SuperPcDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the p * n data matrix before any feature selection.
        # . No clustering or sorting of any kind.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = "Test set data matrix";
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ABuf = t(dfX);              # Make this genes * samples.

        if (flagWrite == 'yes') {
          #xxx jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.                    
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ABuf, caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................      
      }
      # ..........................................................................................................

      
      # ..........................................................................................................
      # . Next, plot of the data matrix after feature selection :
      # ..........................................................................................................
      if (msel > SuperPcDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the feature-selected data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here msel = ", msel, " while the maximum is given by SuperPcDiag.MSELMAX = ", SuperPcDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat maps of feature-selected data matrix and continue execution.\n");
      }

      if (msel <= SuperPcDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the m * n data matrix after feature selection.
        # . Samples not sorted. Genes in order of feature selection, but otherwise not clustered.
        # .
        # . Generate file name :
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Test set: ", gl$m, " selected genes. Test samples not sorted. Genes not clustered.", sep = "");      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        ASel = as.matrix(t(dfXSel));   # m * n = genes * samples format.

        if (flagWrite == 'yes') {
          #xxxx    jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.                    
        }
      
        SuperPcDiag.plotGeneDataMatrix(ax = ASel,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = pname);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................      
        # . Sort samples so that the shortest survival times are on the left.
        # .......................................................................................
        sBuf = sort(ay, decreasing = FALSE, index.return = TRUE);
        indexSort = sBuf[["ix"]];      # Sort index.

        ASort = ASel[ , indexSort];    # Sorted on columns.
        # .......................................................................................
        # . Samples sorted, genes not clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Test set: ", gl$m, " selected genes. Test samples sorted ",
                      " with increasing output variable left-to-right.",
                      " Genes not clustered.", sep = "");
        caption = paste(gl$m, " sel. genes. Samples sorted increas. output var. LtR. Genes not clustered.", sep = "");      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.                    
        }
            
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'no',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
        # . Samples sorted, genes clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Test set: ", gl$m, " selected genes. Test samples sorted with",
                      " increasing output variable left-to-right. Genes clustered.", sep = "");
        caption = paste(gl$m, " sel. genes. Samples sorted incr. output var. LtR. Genes clustered.", sep = "");
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.                              
        }
            
        SuperPcDiag.plotGeneDataMatrix(ax = ASort,
                                       flagClusterx = 'yes',
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # ......................................................................................................
      # . END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS
      # ......................................................................................................



      # .......................................................................................
      # . Generate the sort key for plotting with the smallest output variable values
      # . on the left.
      # .......................................................................................
      sBuf = sort(ay, decreasing = FALSE, index.return = TRUE);
      indexSort = sBuf[["ix"]];      # Sort index.
      # .......................................................................................



      
      # .......................................................................................
      # . Output values under the sort key :
      # . Plot the values of the output variable, with samples sorted so that the
      # . smallest values are on the left.  This generates a plot with the same
      # . sample order as in the last two heat maps above, which can then be used a a
      # . reference.      
      # .
      # . Generate file name :
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      # .......................................................................................
      # . Select captions based on clustering scheme :
      # .......................................................................................      
      pname = paste("Output variable for test set with samples sorted", sep = ""); 
      afile = c(afile, fname);
      aplot = c(aplot, pname);                        
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }

      aySort = ay[indexSort];       # Sorted output variables.
      acSort = asample[indexSort];  # Corresponding sample names.

      par(mfrow = c(2, 1));
      caption = "Sorted output variable for test set";
      plot(aySort, xaxt = 'n', xlab = 'samples (sorted)', pch = 19, main = caption);
      axis(side = 1, at = 1:length(acSort), labels = acSort);
      par(mfrow = c(1, 1));
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }                  
      # .......................................................................................

      

      
      # ...................................................................................
      # . Compute the predicted output values, using 
      # . the training set-derived means and glmnet model :
      # . This call returns :
      # .        sl$axi = n : vector of prognostic indices xi = beta0 + beta . x
      # .     sl$ayPred = n : vector of predicted output values.
      # .    sl$aPyPred = n : vector of estimated P(y = 1|x) valyes.
      # ...................................................................................      
      sl = Glmnet.computeRegressOutputVariable(gl, dfX);      
      # ...................................................................................
      # . Get the model error terms :
      # ...................................................................................
      if (gl$modelType == 'lm') {            
        eR = Stat.basicLinearRegression(sl$ayPred, ay);    # Observed versus predicted y.
      }
      
      if (gl$modelType == 'logistic') {      
        #xxx roc = Stat.basicROC(sl$aPyPred, ay,
        roc = Stat.basicROC(sl$axi, ay,                    # J. Theilhaber.
                            flagPval = TRUE,
                            flagConfInterval = TRUE,
                            flagNormalModel = TRUE,
                            prob = 0.95);
      }
      # ...................................................................................
      


      # .......................................................................................
      # . >>For LINEAR REGRESSION :
      # .   Plot the predicted output variable against the actual values.
      # .......................................................................................
      if (gl$modelType == 'lm') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Predicted versus test set values for output variable';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        R2Temp = sprintf("%8.3e", eR$R2);
        eps2Temp = sprintf("%8.3e", eR$eps2);
        pvalTemp = sprintf("%8.3e", eR$pval);      
      
        caption = paste("Predicted vs test set Y: P = ", pvalTemp, ", R2 = ", R2Temp, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        plot(ay, sl$ayPred, xlab = 'y input values (test set)', ylab = 'y predicted values',
             main = caption, pch = 19);
        abline(h = 0);
        abline(v = 0);
        # ...........................................................................
        # . Add regression line and 1 s.e. confidence interval :
        # ...........................................................................
        if (eR$beta1 != 0) {
          beta0Prime = - eR$beta0 / eR$beta1;      # Transform because basic regression
          beta1Prime = 1.0 / eR$beta1;             # was done for y versus y_predicted.
          sigmaPrime = eR$sigma / abs(eR$beta1);

          abline(a = beta0Prime, b = beta1Prime, lty = 'dashed');
          a_lo = beta0Prime - sigmaPrime;
          a_hi = beta0Prime + sigmaPrime;
          abline(a = a_lo, b = beta1Prime, lty = 'dashed');
          abline(a = a_hi, b = beta1Prime, lty = 'dashed');
        }
        # ...........................................................................                        
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................




      # .......................................................................................
      # . >>For LINEAR REGRESSION :
      # .   Plot the actual values against the predicted output.
      # . This is the SAME plot as above, but with reversed axes.
      # .......................................................................................
      if (gl$modelType == 'lm') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Test set values versus predicted values for output variable';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        R2Temp = sprintf("%8.3e", eR$R2);
        eps2Temp = sprintf("%8.3e", eR$eps2);
        pvalTemp = sprintf("%8.3e", eR$pval);      
      
        caption = paste("Test vs predicted Y: model P = ", pvalTemp, ", R2 = ", R2Temp, sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        plot(sl$ayPred, ay, xlab = 'y predicted values', ylab = 'y input values (test set)', 
             main = caption, pch = 19);
        abline(h = 0);
        abline(v = 0);
        # ...........................................................................
        # . Add regression line and 1 s.e. confidence interval :
        # ...........................................................................        
        abline(a = eR$beta0, eR$beta1, lty = 'dashed');
        a_lo = eR$beta0 - eR$sigma;
        a_hi = eR$beta0 + eR$sigma;
        abline(a = a_lo, eR$beta1, lty = 'dashed');
        abline(a = a_hi, eR$beta1, lty = 'dashed');
        # ...........................................................................                
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      

      # .......................................................................................
      # . >>For LINEAR REGRESSION :      
      # . Plot residuals versus training set values for output variable.
      # .......................................................................................
      if (gl$modelType == 'lm') {      
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Test set residuals versus input values of y';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        caption = paste("Test set residuals vs input values of y", sep = "");

        plot(ay, eR$ares, xlab = 'y input values (test set)', ylab = 'residuals (yPred - y)',
             main = caption, pch = 19);
        abline(h = 0.0);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................
      
      


      

      # .......................................................................................
      # . >>for LINEAR REGRESSION :            
      # . Generate a normal QQ plot for the model residuals :
      # .......................................................................................
      if (gl$modelType == 'lm') {            
        # .......................................................................................
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Normal QQ plot for model residuals for test set';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        caption = paste("Normal QQ plot for model residuals for test set", sep = "");

        Stat.qqNormCI(eR$ares, caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................
      


      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   Plot the actual output values against estimated P(y = 1|x).
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Test set values for output variable versus estimated P(y = 1|x)';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);             # Area under curve.
        pvalTemp = sprintf("%8.3e", roc$pval);       # P-value for detection of y = 1 versus y = 0.
        errMAPTemp = sprintf("%8.3e", roc$errMAP);  # Error rate under MAP classification.
      
        caption = paste("actual Y versus P(y=1|x): AUC = ", ATemp,
                        ", P-value = ", pvalTemp,
                        ", errMAP = ", errMAPTemp,
                        sep = "");        

        ayJitter = ay + 0.1 * (runif(length(ay)) - 0.5);   # Add vertical jitter of plus-minus 0.05.
        
        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        plot(sl$aPyPred, ayJitter, xlab = 'estimated P(y=1|x)', ylab = 'y input values (training set)',
             main = caption, pch = 19);
        abline(h = 0);
        abline(h = 1, lty = 'dashed');        
        abline(v = 0);
        abline(v = 0.5, lty = 'dashed');        
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................

      

      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   Plot the actual output values against estimated the prognostic index,
      # .   xi = beta0 + beta * x.
      # .   This is almost identical to the previous plot, but with prognostic
      # .   index = logit(P(y=1|x)) replacing P(y=1|x) estimated values.
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Test set values for output variable versus xi = beta0 + beta . x';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);             # Area under curve.
        pvalTemp = sprintf("%8.3e", roc$pval);         # P-value for detection of y = 1 versus y = 0.
        errMAPTemp = sprintf("%8.3e", roc$errMAP);     # Error rate under MAP classification.
      
        caption = paste("Test set actual Y versus PI xi = beta0 + beta . x: AUC = ", ATemp,
                        ", P-value = ", pvalTemp,
                        ", errMAP = ", errMAPTemp,
                        sep = "");        

        ayJitter = ay + 0.1 * (runif(length(ay)) - 0.5);   # Add vertical jitter of plus-minus 0.05.
        
        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        plot(sl$axi, ayJitter, xlab = 'prognostic index', ylab = 'y input values (training set)',
             main = caption, pch = 19);
        abline(h = 0);
        abline(h = 1, lty = 'dashed');
        abline(v = 0);
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      

      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   Plot the model fit : graph P(y=1|x) versus prognostic index xi = beta0 + beta . x,
      # .   and add rug plots of data points and binned estimates of P(y=1|x).
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Fit on test set for logistic model';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);                    # AUC for detection of 1 versus 0.
        caption = paste("Test set fit for logistic model: AUC = ",
                        ATemp, sep = "");

        ncut = floor(gl$n / 10);
        if (ncut < 2) {
          ncut = 2;
        } else if (ncut > 10) {
          ncut = 10;
        }
        
        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);        
        Logistic.plotFitOnArrays(sl$axi, ay, 
                                 xlab = 'prognostic index', 
                                 ylab = 'estimated P(y=1|x)',
                                 caption = caption,
                                 ncut = 10);
        par(cex.main = cex.main.OLD);        
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................



      

      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   1. Plot the empirical ROC and approximations from various models :
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Test set ROCs based on estimated P(y = 1|x), with binormal approximation';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Generate ROCs and compute stats on AUC :
        # .......................................................................................
        #xxx roc = Stat.basicROC(sl$aPyPred, ay,
        roc = Stat.basicROC(sl$axi, ay,                        # J. Theilhaber.
                            flagPval = TRUE,
                            flagConfInterval = TRUE,
                            flagNormalModel = TRUE,
                            prob = 0.95);

        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);           # Area under curve.
        pvalTemp = sprintf("%8.3e", roc$pval);       # Wilcoxon P-value for detection of y = 1 versus y = 0.
        errMAPTemp = sprintf("%8.3e", roc$errMAP);   # Error rate under MAP classification.
        errMinTemp = sprintf("%8.3e", roc$errMin);   # Minimum error rate.
      
        caption = paste("ROC: AUC = ", ATemp,
                        ", P-value = ", pvalTemp,
                        ", errMAP = ", errMAPTemp,
                        ", errMin = ", errMinTemp,
                        sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        # ........................................................................
        # . Plot empirical ROC :
        # ........................................................................        
        plot(roc$aFP, roc$aS,
             xlim = c(0, 1),
             ylim = c(0, 1),
             xlab = 'FP',
             ylab = 'S',
             main = caption,
             type = 'l',
             lwd = 2,
             pch = 19);

        points(roc$aFP[roc$jMAP], roc$aS[roc$jMAP], pch = 19);
        points(roc$aFP[roc$jMin], roc$aS[roc$jMin], pch = 19, col = 'red');        
        # ........................................................................
        # . Add analytic null distribution plus-minus 1 sd, and binormal
        # . model approximation :
        # ........................................................................        
        lines(roc$aFPnull, roc$aSnull, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullLo, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullHi, type = 'l', col = 'blue');        

        lines(roc$aFPnormal, roc$aSnormal, lty = 'dashed');
        # ........................................................................
        # . Add legend :
        # ........................................................................
        legendText = c("empirical", "binormal", "null, CI 95%");
        colVector = c('black', 'black', 'blue');
        ltyVector = c('solid', 'dashed', 'solid');
        lwdVector = c(2, 1, 1);        
        legend(x = 0.6, y = 0.3,
               legend = legendText, 
               col = colVector, lty = ltyVector, lwd = lwdVector, bty = 'n');
        
        legendText = c("MAP", "Min");
        colVector = c('black', 'red');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = 0.6, y = 0.12,
               legend = legendText,
               col = colVector, pch = pchVector, bty = 'n');
        
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................




      # .......................................................................................
      # . >>For LOGISTIC REGRESSION :
      # .   2. Plot the empirical ROC and approximations from various models :
      # .   This is almost identical to the previous plot, but here we do not
      # .   display the binormal model approximation, but add the confidence interval
      # .   for the emprical ROC.
      # .......................................................................................
      if (gl$modelType == 'logistic') {
        # .......................................................................................        
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = 'Test set ROCs based on estimated P(y = 1|x), with empirical confidence interval';
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Generate ROCs and compute stats on AUC :
        # .......................................................................................
        #xxx roc = Stat.basicROC(sl$aPyPred, ay,
        roc = Stat.basicROC(sl$axi, ay,                      # J. Theilhaber.
                            flagPval = TRUE,
                            flagConfInterval = TRUE,
                            flagNormalModel = TRUE,
                            prob = 0.95);

        aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);        
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          jpeg(fname);              # Turn on plot device.
        }

        ATemp = sprintf("%8.3e", roc$auc);           # Area under curve.
        pvalTemp = sprintf("%8.3e", roc$pval);       # Wilcoxon P-value for detection of y = 1 versus y = 0.
        errMAPTemp = sprintf("%8.3e", roc$errMAP);   # Error rate under MAP classification.
        errMinTemp = sprintf("%8.3e", roc$errMin);   # Minimum error rate.
      
        caption = paste("ROC: AUC = ", ATemp,
                        ", P-value = ", pvalTemp,
                        ", errMAP = ", errMAPTemp,
                        ", errMin = ", errMinTemp,
                        sep = "");

        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        # ........................................................................
        # . Plot empirical ROC :
        # ........................................................................        
        plot(roc$aFP, roc$aS,
             xlim = c(0, 1),
             ylim = c(0, 1),
             xlab = 'FP',
             ylab = 'S',
             main = caption,
             type = 'l',
             lwd = 2,
             pch = 19);

        points(roc$aFP[roc$jMAP], roc$aS[roc$jMAP], pch = 19);
        points(roc$aFP[roc$jMin], roc$aS[roc$jMin], pch = 19, col = 'red');        
        # ........................................................................
        # . Add analytic null distribution plus-minus 1 sd, and confidence
        # . interval for the empirical ROC :
        # ........................................................................        
        lines(roc$aFPnull, roc$aSnull, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullLo, type = 'l', col = 'blue');
        lines(roc$aFPnull, roc$aSnullHi, type = 'l', col = 'blue');        

        lines(roc$aFP, roc$aSLo, lty = 'dashed');
        lines(roc$aFP, roc$aSHi, lty = 'dashed');        
        # ........................................................................
        # . Add legend :
        # ........................................................................
        legendText = c("empirical", "emp. CI, 95%", "null, CI 95%");
        colVector = c('black', 'black', 'blue');
        ltyVector = c('solid', 'dashed', 'solid');
        lwdVector = c(2, 1, 1);        
        legend(x = 0.6, y = 0.3,
               legend = legendText, 
               col = colVector, lty = ltyVector, lwd = lwdVector, bty = 'n');
        
        legendText = c("MAP", "Min");
        colVector = c('black', 'red');
        ltyVector = c('solid', 'solid');
        pchVector = c(19, 19);        
        legend(x = 0.6, y = 0.12,
               legend = legendText,
               col = colVector, pch = pchVector, bty = 'n');
        
        par(cex.main = cex.main.OLD);      
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {      
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # .......................................................................................


      
      # .......................................................................................
      # . Final tally :
      # .......................................................................................      
      nplot = length(afile);
      
      if (flagWrite == 'yes') {
        cat(" ..........  ", nplot, " jpeg plot files were generated.\n", sep = "");
      }
      # .......................................................................................

      
      
      # ....................................................................
      # . Package file names and plot names into list.
      # . Note that these are generated (with dummy names in that case)
      # . even if flagWrite = 'no'.
      # .
      # .   nplot = total number of plots in array.
      # .   afile = array of file names.
      # .   aplot = array of corresponding plot names.
      # ....................................................................
      sp = list(nplot = nplot, afile = afile, aplot = aplot);

      class(sp) = 'super.pc.diag.plot';
      # ....................................................................
      
     
      # ...........
      return (sp);
      # ...........

}

# =================================================================================================
# . End of GlmnetDiag.plotRegressTest.
# =================================================================================================






# =================================================================================================
# . GlmnetDiag.plotRegressTrainAndTest : displays the results of an analysis using regression models
# . -----------------------------------   in the form of a series of plots : this contrasts
# .                                       train and test data, when appropriate.
# .   Syntax:
# .
# .       sp = GlmnetDiag.plotRegressTrainAndTest(ayTrain, dfXTrain,
# .                                                ayTest, dfXTest,
# .                                                gl, flagWrite, dirName, stemName);
# .
# .   In:
# .
# .         ayTrain = vector of output variable values for training set,
# .                   with say ntrain samples.
# .
# .        dfXTrain = input data frame for the predictor variables for test samples.
# .                   This is of dimension ntrain * p, where p = number of genes;
# .                   each row corresponds to a samples, and each column to a
# .                   gene.
# .
# .          ayTest = vector of output variable values for test set,
# .                   with say ntest samples.
# .
# .          dfXTest= input data frame for the predictor variables for test samples.
# .                   This is of dimension ntest * p, where p = number of genes;
# .                   each row corresponds to a samples, and each column to a
# .                   gene.
# .
# .            gl = result of glmnet computation, returned
# .                 by function Glmnet.computeRegress().
# .
# .     flagWrite = no/yes : flag indicating whether plots should be written to file in jpeg
# .                 format instead of being displayed.
# .                 If value is 'yes', each plot will be written to a file in the directory
# .                 indicated by 'dirName', with a name given by 'stemName' followed by
# .                 a random string and the .jpg extension.
# .                 If value is 'no', the user is prompted to interactively provide carriage
# .                 returns to march through the display.
# .
# .       dirName = directory in which to write the plot files, under option flagWrite = 'yes'.
# .
# .      stemName = stem name for all plot files, under option flagWrite = 'yes'.
# .
# .   Out:
# .
# .           - If flagWrite = 'no', displays a series of plots. The use enter carriage returns
# .           to advance from one plot to the next.
# .           Object sp returned is NULL.
# .
# .           - If flagWrite = 'yes', generates a series of plot files, as indicated above.
# .           Object sp returned is a list with members:
# .
# .                  nplot = number of plot files generated.
# .                  afile = array of file names.
# .                  aplot = array of plot names.
# .
# =================================================================================================

GlmnetDiag.plotRegressTrainAndTest <- function(ayTrain, dfXTrain,
                                               ayTest, dfXTest,
                                               gl,
                                               flagWrite = 'no',
                                               dirName = NULL, stemName = NULL)
{

      # .......................................................................
      cat(" ..........  Entry in GlmnetDiag.plotRegressTrainAndTest.\n");
      # .......................................................................

      
      # .............................................................
      stopifnot((flagWrite == 'no') || (flagWrite == 'yes'));
      # .............................................................
      
      
      # ......................................................................................      
      # . Determine the numbers of samples and genes.
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      if (class(gl) != "glmnet.regress") {
        msg = "ERROR: from GlmnetDiag.plotRegressTrainAndTest: ";
        msg = paste("The input gl is not of class glmnet.regress.\n");
        stop(msg);
      }
      # ......................................................................................
      # . Check on consistency of the training set data :
      # ......................................................................................        
      ntrain = nrow(dfXTrain);     # Number of training set samples.
      p = ncol(dfXTrain);          # Number of genes.

      ny = length(ayTrain);   # Number of samples in output variable vector.      

      if (ny != ntrain) {
        msg = "ERROR: from GlmnetDiag.plotRegressTrainAndTest: ";
        msg = paste("The training set vector ayTrain has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the ntrain = ", ntrain, "samples in the training set data matrix dfXTrain.", sep = "");      
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.plotRegressTrainAndTest: ";        
        msg = paste("The input training set data matrix does not have the same number of ");
        msg = paste("genes as in the glmnet model. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("gl has p = " , gl$p, " genes.");
        stop(msg);
      }
      # ......................................................................................
      # . Check on consistency of the test set data :
      # ......................................................................................        
      ntest = nrow(dfXTest);      # Number of test set samples.
      p = ncol(dfXTest);          # Number of genes.

      ny = length(ayTest);        # Number of samples in output variable vector.      

      if (ny != ntest) {
        msg = "ERROR: from GlmnetDiag.plotRegressTrainAndTest: ";
        msg = paste("The test set vector ayTest has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the ntest = ", ntest, "samples in the testing set data matrix dfXTest.", sep = "");      
        stop(msg);
      }
      
      if (gl$p != p) {
        msg = "ERROR: from GlmnetDiag.plotRegressTrainAndTest: ";        
        msg = paste("The input testing set data matrix does not have the same number of ");
        msg = paste("genes as in the glmnet model. ");
        msg = paste("Input has p = " , p, " genes. ");
        msg = paste("gl has p = " , gl$p, " genes.");
        stop(msg);
      }
      # ...............................................................................................

      

      
      # ...............................................................................................
      # . Processing the input data matrices :
      # .
      # . Center both training and test sets on the training set means :
      # . >> Training set :
      # ...............................................................................................
      dfXTrainc = sweep(dfXTrain, 2, gl$axm);                    # Center each column separately.      
      dfXTrainSel = dfXTrainc[ , gl$indexSel];                   # nIn * m data matrix subsetted to the selected genes.

      if (nrow(dfXTrainc) == 1) {
        dfXTrainSel = matrix(dfXTrainSel, nrow = 1);              # Special case for nrow = 1, to preserve matrix geometry.
      }

      if (length(gl$indexSel) == 1) {
        dfXTrainSel = data.frame(dfXTrainSel);
        colnames(dfXTrainSel) = colnames(dfXTrainc)[gl$indexSel];
        rownames(dfXTrainSel) = rownames(dfXTrainc);
      }
      
      agene = colnames(dfXTrainSel);                              # Selected gene names, in feature selection order.
      atrainSample = rownames(dfXTrainSel);                       # Sample names.
      
      ntrainSel = nrow(dfXTrainSel);                              # Number of samples.
      mtrainSel = ncol(dfXTrainSel);                              # Number of subsetted genes.
      # ...................................................................................      
      # . >> Test set :
      # ...................................................................................      
      dfXTestc = sweep(dfXTest, 2, gl$axm);                      # Center each column separately.      
      dfXTestSel = dfXTestc[ , gl$indexSel];                     # nIn * m data matrix subsetted to the selected genes.

      if (nrow(dfXTestc) == 1) {
        dfXTestSel = matrix(dfXTestSel, nrow = 1);                # Special case for nrow = 1, to preserve matrix geometry.
      }

      if (length(gl$indexSel) == 1) {
        dfXTestSel = data.frame(dfXTestSel);
        colnames(dfXTestSel) = colnames(dfXTestc)[gl$indexSel];
        rownames(dfXTestSel) = rownames(dfXTestc);
      }
      
      agene = colnames(dfXTestSel);                               # Selected gene names, in feature selection order.
      atestSample = rownames(dfXTestSel);                         # Sample names.
      
      ntestSel = nrow(dfXTestSel);                                # Number of samples.
      mtestSel = ncol(dfXTestSel);                                # Number of subsetted genes.                  
      # ...............................................................................................
      # . Generate the keys for plotting with output variable increasing left-to-right
      # . separately in training set and test set :
      # ...............................................................................................
      sBuf = sort(ayTrain, decreasing = FALSE, index.return = TRUE);
      indexTrainSort = sBuf[["ix"]];                                  # Sort index for training set.

      sBuf = sort(ayTest, decreasing = FALSE, index.return = TRUE);
      indexTestSort = sBuf[["ix"]];                                   # Sort index for test set.
      # ................................................................................................
      # . Format the data into matrices and sort on output variable increasing left-to-right :
      # . >> Training set :
      # ................................................................................................     
      ATrainSel = as.matrix(t(dfXTrainSel));               # m * n = genes * samples format, training set.
      ATrainSort = ATrainSel[ , indexTrainSort];           # Sorted on columns now.

      ayTrainSort = ayTrain[indexTrainSort];               # Sorted output variables.
      acTrainSort = atrainSample[indexTrainSort];          # Corresponding sample names.
      # ................................................................................................                 
      # . >> Test set :
      # ................................................................................................           
      ATestSel = as.matrix(t(dfXTestSel));                 # m * n = genes * samples format, test set.
      ATestSort = ATestSel[ , indexTestSort];              # Sorted on columns now.

      ayTestSort = ayTest[indexTestSort];                  # Sorted output variables.
      acTestSort = atestSample[indexTestSort];             # Corresponding sample names.
      # .................................................................................................
      # . Generate a row clustering sort key, based on just the training set :
      # .................................................................................................
      dbuf = dist(ATrainSort); 
      hbuf = hclust(dbuf);
      rowIndex = hbuf$order;
      # .................................................................................................
      # . Combine and sort rows in both data matrices :
      # .................................................................................................
      Ball = cbind(ATrainSort, ATestSort);
      Ball = Ball[rowIndex, ];

      aySort = c(ayTrainSort, ayTestSort);       # Concatenated outptu variables.
      acSort = c(acTrainSort, acTestSort);       # All the column names.
      # .................................................................................................     




      
      # .......................................................
      # . Reset some defaults, in case they got changed :
      # .......................................................      
      par(ask = FALSE);
      par(mfrow = c(1,1));      
      # .......................................................


      # .......................................................................................
      if (flagWrite == 'no') {
        cat("\n");
        cat(" ..........  Enter carriage returns as indicated to generate plots one-by-one.\n");
      } else if (flagWrite == 'yes') {
        cat(" ..........  Generating plot files in directory = ", dirName, "\n", sep = "");
      }
      # .......................................................................................


      # ...........................................................
      # . Initialize plot arrays :
      # ...........................................................
      afile = c();
      aplot = c();

      if (flagWrite == 'no') {
        dirName = "foo";        # Dummy value.
        stemName = "dum";       # Dummy value.
      }
      # ...........................................................

      
      
      # .......................................................................................
      if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }
      # .......................................................................................
      

      
      # ..........................................................................................................
      # . HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS       HEAT MAPS
      # .
      # ..........................................................................................................
      # ..........................................................................................................
      # . Plot of the data matrix after feature selection, sorting of samples on value of output variable.
      # . The gene * samples array is pre-clustered on rows based on the training set alone.
      # ..........................................................................................................
      if (mtrainSel > SuperPcDiag.MSELMAX) {
        cat(">>Warning: the number of genes in the feature-selected data matrix exceeds the maximum allowed for display of heat maps.\n");
        cat(">>Here msel = ", mtrainSel, " while the maximum is given by SuperPcDiag.MSELMAX = ", SuperPcDiag.MSELMAX, "\n", sep = "");
        cat(">>Skip heat maps of feature-selected data matrix and continue execution.\n");
      }

      if (mtrainSel <= SuperPcDiag.MSELMAX) {      
        # .......................................................................................
        # . Heat map of the m * n data matrix after feature selection.
        # . Samples sorted, genes clustered :
        # .
        # . Generate file name :      
        # .......................................................................................
        fname = File.generateRandomName(dirName, stemName, ext = "jpg");
        pname = paste("Training and test sets: ", gl$m, " selected genes. Sets separately sorted with",
                      " increasing output variable left-to-right. Genes clustered.", sep = "");
        caption = paste("Train+test: ", gl$m, " genes. Samples sorted incr. output var. LtR. Genes clustered.", sep = "");
      
        afile = c(afile, fname);
        aplot = c(aplot, pname);
        # .......................................................................................
        # . Plot here :
        # .......................................................................................
        if (flagWrite == 'yes') {
          #xxx  jpeg(fname);              # Turn on plot device.
          jpeg(fname, width = 960, height = 960);              # Turn on plot device.                              
        }
            
        SuperPcDiag.plotGeneDataMatrix(ax = Ball,
                                       flagClusterx = 'no',    # Already ordered according to clustering scheme.
                                       flagClustery = 'no',
                                       caption = caption);
        # .....................................................................................
        # . Close device or prompt user for next plot :      
        # .......................................................................................
        if (flagWrite == 'yes') {
          dev.off();
        } else if (flagWrite == 'no') {
          buf = readline(">>Enter a carriage return to continue: ");    # Pause.
        }
        # .......................................................................................
      }
      # ......................................................................................................
      # . END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS       END OF HEAT MAPS
      # ......................................................................................................



      
      # .......................................................................................
      # . Output values under the sort key :
      # . Plot the values of the output variable, with samples sorted so that the
      # . smallest values are on the left, separately for training and test sets.
      # . This generates a plot with the same sample order as the heat maps above,
      # . which can then be used a reference.      
      # .
      # . Generate file name :
      # .......................................................................................
      fname = File.generateRandomName(dirName, stemName, ext = "jpg");
      # .......................................................................................
      # . Select captions based on clustering scheme :
      # .......................................................................................      
      pname = paste("Output variable for training and test set with samples sorted", sep = ""); 
      afile = c(afile, fname);
      aplot = c(aplot, pname);                        
      # .......................................................................................
      # . Plot here :
      # .......................................................................................
      if (flagWrite == 'yes') {
        jpeg(fname);              # Turn on plot device.
      }

      par(mfrow = c(2, 1));
      caption = "Sorted output variable for training and test sets";
      plot(aySort, xaxt = 'n', xlab = 'samples (sorted)', pch = 19, main = caption);
      axis(side = 1, at = 1:length(acSort), labels = acSort);
      par(mfrow = c(1, 1));
      # .....................................................................................
      # . Close device or prompt user for next plot :      
      # .......................................................................................
      if (flagWrite == 'yes') {
        dev.off();
      } else if (flagWrite == 'no') {      
        buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      }                  
      # .......................................................................................

      

      
      # .......................................................................................
      # . Final tally :
      # .......................................................................................      
      nplot = length(afile);
      
      if (flagWrite == 'yes') {
        cat(" ..........  ", nplot, " jpeg plot files were generated.\n", sep = "");
      }
      # .......................................................................................

      
      
      
      # ....................................................................
      # . Package file names and plot names into list.
      # . Note that these are generated (with dummy names in that case)
      # . even if flagWrite = 'no'.
      # .
      # .   nplot = total number of plots in array.
      # .   afile = array of file names.
      # .   aplot = array of corresponding plot names.
      # ....................................................................
      sp = list(nplot = nplot, afile = afile, aplot = aplot);

      class(sp) = 'super.pc.diag.plot';
      # ....................................................................
      
     
      # ...........
      return (sp);
      # ...........

}

# =================================================================================================
# . End of GlmnetDiag.plotRegressTrainAndTest.
# =================================================================================================




