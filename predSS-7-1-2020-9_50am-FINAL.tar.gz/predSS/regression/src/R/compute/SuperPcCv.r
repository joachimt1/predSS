# =================================================================================================
# . SuperPcCv.r : functions for cross-validating supervised principal components.
# . -----------   
# .
# =================================================================================================

library(survival);


# =================================================================================================
# . SuperPcCv.crossValidateSingle : for one level of gene selection, does cross-validation on the
# . -----------------------------   indicated training set.
# .
# .
# .   Syntax:
# .
# .        cv = SuperPcCv.crossValidateSingle(ay, dfX, methodFs, theta, mtop, ft, nr);
# .
# .   In:
# .            ay = outcome vector, of length n, where n is the number
# .                 of samples.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes.
# .                 Thus successive rows correspond to successive
# .                 samples, and each column corresponds to a different
# .                 gene.
# .
# .      methodFs = method of feature selection. Allowed values:
# .                  - 'theta' : use the threshold parameter theta for selecting
# .                    genes.
# .                  - 'mtop' :use the cutoff parameter mtop for selecting genes.
# .
# .         theta = threshold in absolute value of the regression coefficients
# .                 for retaining genes in the SVD calculation.
# .
# .          mtop = alternative feature-selection parameter : select the top mtop
# .                 genes, ranked in decreasing order of absolute value of the
# .                 correlation coefficient.
# .
# .            ft = fraction of all training samples to be removed for the
# .                 on-the-fly generated test set; 0 < ft < 1.
# .
# .            nr = number of independent resamplings.
# .
# =================================================================================================

SuperPcCv.crossValidateSingle  <- function(ay, dfX, methodFs, theta, mtop, ft, nr)
{

  # ..................................................................................
  n = nrow(dfX);             # Total number of samples.
  nTest = floor(n * ft);     # Number to be placed into on-the-fly test set.
  # ..................................................................................  

  
  # .........................................................................
  amSel = rep(0.0, times = nr);     # Number of features selected by filter.
  aerrAbs = rep(0.0, times = nr);   # Dummy assignments, to allocate for 
  aerrRel = rep(0.0, times = nr);   # the corresponding arrays.
  aQ = rep(0.0, times = nr);    
  # .........................................................................


  # ..................................................................................  
  for (i in 1:nr) {
    if ((i == 1) || (i%%10 == 0)) {
      cat(">>Processing single: i = " , i, " out of ", nr, "\n");   # Temporary diagnostic.
    }
    # ...................................................................
    # . Generate training and test sets :
    # ...................................................................    
    indexTest = sample(x = 1:n, size = nTest);

    dfXTrain = dfX[-indexTest, ];  # The training set data matrix.
    ayTrain = ay[-indexTest];      # The training set outcome variables.
    
    dfXTest = dfX[indexTest, ];    # The test set data matrix.
    ayTest = ay[indexTest];        # The test set outcome variables.
    # ...................................................................
    # . Build the model on the training data :
    # ...................................................................        
    spc = SuperPc.computeLmOnTraining(ay = ayTrain,
                                      dfX = dfXTrain,
                                      methodFs = methodFs,
                                      theta = theta,
                                      mtop = mtop);
    # ...................................................................
    # . Test predictions on the test set :
    # ...................................................................        
    spt = SuperPc.computeLmOnTest(spc = spc,
                                  ayTest = ayTest,
                                  dfX = dfXTest);
    #xxxxx >>>  SuperPc.displayTest(spt);         # Temporary diagnostic.
    # ...................................................................
    # . Save the results :
    # ...................................................................
    amSel[i] = spc$m;          # Number of features sel. at this level of theta.    
    aerrAbs[i] = spt$errAbs;
    aerrRel[i] = spt$errRel;
    aQ[i] = spt$Q;
    # ...................................................................    
  }
  # ...................................................................................


  # ........................................
  # . Generate summary statistics :
  # ........................................
  mSelMean = mean(amSel);
  mSelSigma = sd(amSel);
  
  errAbsMean = mean(aerrAbs);
  errAbsSigma = sd(aerrAbs);

  errRelMean = mean(aerrRel);
  errRelSigma = sd(aerrRel);    

  QMean = mean(aQ);
  QSigma = sd(aQ);
  # ........................................


  # ........................................
  # . Package the results :
  # ........................................
  cv = list(mSelMean = mSelMean,
            mSelSigma = mSelSigma,
            errAbsMean = errAbsMean,
            errAbsSigma = errAbsSigma,
            errRelMean = errRelMean,
            errRelSigma = errRelSigma,
            QMean = QMean,
            QSigma = QSigma);
  # ........................................

}

# =================================================================================================
# . End of SuperPc.crossValidateSingle.
# =================================================================================================


    
# =================================================================================================
# . SuperPcCv.crossValidateLoop : does cross-validation for the indicated values of theta.
# . ---------------------------   
# .
# .
# .   Syntax:
# .
# .           cvl = SuperPc.crossValidateLoop(ay, dfX, methodFs,
# .                                           mtopLo, mtopHi, mtopInc, ft, nr);
# .
# .   In:
# .            ay = outcome vector, of length n, where n is the number
# .                 of samples.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes.
# .                 Thus successive rows correspond to successive
# .                 samples, and each column corresponds to a different
# .                 gene.
# .
# .        mtopLo = lower bound on mtop for cross-validation run.
# .        mtopHi = upper bound on mtop for cross-validation run. 
# .       mtopInc = increment on mtop for cross-validation run. 
# .        
# .
# .            ft = fraction of all training samples to be removed for the
# .                 on-the-fly generated test set; 0 < ft < 1.
# .
# .            nr = number of independent resamplings.
# .
# =================================================================================================

SuperPcCv.crossValidateLoop  <- function(ay, dfX, methodFs,
                                       mtopLo, mtopHi, mtopInc,                                       
                                       ft, nr)
{


  # ...........................................................
  cat(" ..........  Entry in SuperPcCv.crossValidateLoop.\n");
  # ...........................................................

  
  # ..............................
  stopifnot(mtopLo >= 1);
  stopifnot(mtopHi >= 1);
  stopifnot(mtopLo <= mtopHi);
  stopifnot(mtopInc >= 1);        
  # ...............................

  
  # ..................................................................................
  amtop = seq(from = mtopLo, to = mtopHi, by = mtopInc);
  nmtop = length(amtop);

  if (amtop[nmtop] != mtopHi) {
    amtop = c(amtop, mtopHi);    # Insures both low and high values are inclued.
    nmtop = length(amtop);
  }
  # ..................................................................................  

  
  # ..................................................................................

  k = 1;                         # Initialize step counter.
  as = list();                   # Will contain succession of results.

  for (mtop in amtop) {
    cat(">>Processing: mtop = ", mtop, "; step = ", k, " out of ", nmtop, "\n");
    # ........................................................................
    # . Do cross-validation :
    # ........................................................................
    methodFs = 'mtop';
    cv = SuperPcCv.crossValidateSingle(ay = ay,
                                     dfX = dfX,
                                     methodFs = methodFs,
                                     theta = 0.0,
                                     mtop = mtop,
                                     ft = ft,
                                     nr = nr);
    as[[k]] = cv;                 # Store cross-validation results.
    # ........................................................................
    # . Summary report for this step :
    # ........................................................................
    cat(">>Result: mSelMean = ", cv$mSelMean,
        "; errAbsMean = ", cv$errAbsMean,
        "; errRelMean = ", cv$errRelMean,
        "; QMean = ", cv$QMean, "\n");
    # ........................................................................
    k = k + 1;
    # ........................................................................    
  }  
  # ..................................................................................


  # .............................................
  # . Package results :
  # .............................................
  cvl = list(amtop = amtop,
             as = as);             

  class(cvl) = "cvl";
  # .............................................


  # .............
  return (cvl);
  # .............

}

# =================================================================================================
# . End of SuperPcCv.crossValidateLoop.
# =================================================================================================
  




# ======================================================================================
# . SuperPcCv.getCVLarrays : packages arrays for all the error terms generated
# . --------------------   in a cross-validation loop.
# .
# . Syntax:
# .
# .       a = SuperPcCv.getCVLarrays(cvl);
# .
# . In:
# .       cvl = object returned by SuperPcCv.crossValidateLoop.
# .
# . Out:
# .       a = list, with members :
# .
# .              mtop = number of feature selection levels used.
# .              amtop = array of mtop values.
# .              aerrAbsMean = array of mean of absolute error.
# .              aerrAbsSigma = array of s.d. of absolute error.
# .              aerrRelMean = array of mean of relative error.
# .              aerrRelSigma = array of s.d. of relative error.
# .              aQMean = array of mean of log-likelihood statistic.
# .              aQSigma = array of s.d. of log-likelihood statistic.
# .
# ======================================================================================

SuperPcCv.getCVLarrays <- function(cvl)
{

	# .........................................................................................
	if (class(cvl) != "cvl") {
	   msg = paste("ERROR: from SuperPcCv.getCVarrays : input variable cvl is not of class cvl.\n");
	   stop(msg);
	}
	# .........................................................................................


        
       	# ...............................................................................
        # . Gather values into arrays :
       	# ...............................................................................        
        amtop = cvl$amtop;        # Values of mtop used in cross-validation loop.
        nmtop = length(amtop);    # Number of levels.
        as = cvl$as;              # Series of error reports.

        aerrAbsMean = rep(0, times = nmtop);  # Allocate.
        aerrAbsSigma = rep(0, times = nmtop); 
        aerrRelMean = rep(0, times = nmtop);  
        aerrRelSigma = rep(0, times = nmtop); 
        aQMean = rep(0, times = nmtop); 
        aQSigma = rep(0, times = nmtop); 
        
        for (k in 1:nmtop) {
          aerrAbsMean[k] =  as[[k]]$errAbsMean;
          aerrAbsSigma[k] = as[[k]]$errAbsSigma;
          aerrRelMean[k] = as[[k]]$errRelMean;
          aerrRelSigma[k] = as[[k]]$errRelSigma;
          aQMean[k] = as[[k]]$QMean;
          aQSigma[k] = as[[k]]$QSigma;
        }
       	# ...............................................................................        


      	# ......................................................
        # . Package results :
      	# ......................................................
        a = list(nmtop = nmtop,
                 amtop = amtop,
                 aerrAbsMean =  aerrAbsMean,
                 aerrAbsSigma = aerrAbsSigma,
                 aerrRelMean = aerrRelMean,
                 aerrRelSigma = aerrRelSigma,
                 aQMean = aQMean,
                 aQSigma = aQSigma);
      	# ......................................................        

                
     	# ..........
        return (a);
        # .............

}

# ======================================================================================
# . End of SuperPcCv.getCVLarrays.
# ======================================================================================




# =================================================================================================
# . SuperPcCv.crossValidateCox : cross-validation of the Cox proportional hazard model over 
# . --------------------------   multiple splits of the data into training and test sets,
# .                              with exploration of a range of model parameters.
# .                              
# .
# .   Syntax:
# .
# .            cv =  SuperPcCv.crossValidateCox(at, as, dfX,
# .                                             methodSplit,
# .                                             af, ft, ncv,
# .                                             scoreType,
# .                                             mtop, K,
# .                                             parameterScan,
# .                                             amtop, aK,
# .                                             flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid). Note that only ONE split is ever
# .                               generated.
# .
# .                   - 'vfold' : use parameter ft (below) to do a vfold
# .                               split of the data matrix. Generate ncv
# .                               independent splits of the data matrix.
# .                               The sampling is done here with
# .                               replacement, so that the ncv successive test sets
# .                               generated on-the-fly are not necessarily disjoint.
# .
# .             - 'vfoldStrict' : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .                               
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, for methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfold' or 'vfoldSplit'. Allowed: 0 < ft < 1.
# .
# .           ncv = number of independent splits generated, under method 'vfold'.
# .
# .
# .    >> Score type:
# .
# .     scoreType = type of score to be used for computing P-values.
# .                 Allowed values : 
# .                  - 'loglik' : use score = 2 * (l(beta*) - l(0)).
# .                  - 'u0'     : use score = U(0)^2 / J(0).
# .
# .
# .     >> Fixed-values parameters:
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values). Used only if
# .                 parameterScan = 'K'.
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .                 Used only if parameterScan = 'mtop'.
# .
# .
# .   parameterScan = which parameter to scan in doing the cross-validation on this split of
# .                the data. Allowed values:
# .
# .                   - 'mtop' : do the cross-validation for the values of mtop
# .                              in the input array amtop.
# .                              The input values of the fixed-value parameters mtop
# .                              and p0 are ignored.
# .                              All calculations are done at the fixed value of K.
# .
# .                   - 'K' :    do the cross-validation for the values of K
# .                              in the input array aK.
# .                              The input value of the fixed-value parameter K
# .                              is ignored.
# .                              All calculations are done at the fixed values of
# .                              mtop or p0 (whichever applies under selected
# .                              methodFs).
# .
# .     >> Arrays of parameters for cross-validation:
# .
# .         amtop = array of values of mtop. Keep the mtop genes
# .                 with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .            aK = array of number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .   flagVerbose = if TRUE, prints progress on computation in the innner cross-validation loop.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .       parameterScan = parameter that was scanned (mtop or K).
# .               nscan = number of discrete parameter values used.
# .               amtop = array of the nscan mtop values (for parameterScan = mtop).
# .                  aK = array of nscan K values (for parameterScan = K).
# .               alAll = log-likelihoods for entire data set.
# .             alTrain = log-likelihoods for just training set.
# .
# =================================================================================================

SuperPcCv.crossValidateCox  <- function(at, as, dfX,
                                        methodSplit,
                                        af, ft, ncv, rngSeed,
                                        scoreType,
                                        mtop, K,
                                        parameterScan,
                                        amtop, aK,
                                        flagVerbose)
{

      # ...........................................................................
      cat(" ..........  Entry in SuperPcCv.crossValidateCox.\n");
      # ...........................................................................


      
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (nt != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCox: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCox: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (nf != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCox: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from SuperPcCv.crossValidateCox: ";        
        msg = paste("The number of samples in the data matrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((methodSplit == 'given')
                || (methodSplit == 'vfold')
                || (methodSplit == 'vfoldStrict'));
      
      stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));

      if (parameterScan == 'mtop') {
        stopifnot(K >= 1);
        stopifnot(length(amtop) > 0);        
      } else if (parameterScan == 'K') {
        stopifnot(mtop >= 1);
        stopifnot(length(aK) > 0);        
      }

      if (methodSplit == 'vfold') {
        stopifnot(ncv >= 1);      
        stopifnot((ft > 0.0) && (ft < 1.0));
      }

      stopifnot(rngSeed > 0);
      stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));       
      # ...................................................................................


      # .........................................
      # . Initialize random number generator :
      # .........................................      
      set.seed(rngSeed);                  
      # .........................................
      

      # ....................................................................................................
      cat(" ..........  Begin outer cross-validation loop, parameter scanned = ", parameterScan, "\n", sep = "");
      # ....................................................................................................



      # ....................................................................................................
      # . >>CROSS-VALIDATION :
      # . Generate ncv independent splits of the data, and compute log-likelihoods for the designated
      # . range of the chosen parameter.
      # .
      # . >>PREAMBLE :
      # ....................................................................................................
      if (methodSplit == 'given') {
        ncvHere = 1;                        # We are using only the designated split in the data.
        aIndexSplit = NULL;                 # Will not be needed.        
      } else if (methodSplit == 'vfold') {
        ncvHere = ncv;                      # Generate all ncv independent samplings.
        aIndexSplit = NULL;                 # Will not be needed.                
      } else if (methodSplit == 'vfoldStrict') {
        cSplit = Stat.generateSplitsForVfold(n = n, ft = ft, flagRandom = TRUE);  # Generate truly disjoint groups.
        ncvHere = cSplit$ncv;
        aIndexSplit = cSplit$aIndexSplit;
      }
      # ....................................................................................................
      # . Begin cross-validation below :
      # ....................................................................................................
      cat(" ..........  Total number of steps: ncvHere = ", ncv, "\n", sep = "");
      cat(" ..........  Start loop.\n", sep = "");            
      # ....................................................................................................
      # . >> MAIN LOOP :
      # ....................................................................................................
      t1 = proc.time()[3];              # Starting time.
      
      for (icv in 1:ncvHere) {
        cat("Start step = ", icv, " out of ", ncvHere, "\n", sep = "");
        
        ta = proc.time()[3];
        cvS =  SuperPcCv.crossValidateCoxSingleSplit(at = at,
                                                     as = as,
                                                     dfX = dfX,
                                                     methodSplit = methodSplit,
                                                     af = af,
                                                     ft = ft,
                                                     scoreType = scoreType,
                                                     mtop = mtop,
                                                     K = K,
                                                     parameterScan = parameterScan,
                                                     amtop = amtop,
                                                     aK = aK,
                                                     icv = icv,
                                                     aIndexSplit = aIndexSplit,
                                                     flagVerbose = flagVerbose);
        tb = proc.time()[3] - ta;
        cat("Processed step = ", icv, " out of ", ncvHere, ", time = ", tb, " s.\n", sep = "");
        # .....................................................................................
        # . Package intermediate results :
        # .....................................................................................
        if (icv == 1) {
          dlTrain = as.data.frame(matrix(cvS$alTrain, nrow = 1));
          dR2Train = as.data.frame(matrix(cvS$aR2Train, nrow = 1));          
          dcvPL = as.data.frame(matrix(cvS$acvPL, nrow = 1));
          dlRatioTest = as.data.frame(matrix(cvS$alRatioTest, nrow = 1));
          dpRatioTest = as.data.frame(matrix(cvS$apRatioTest, nrow = 1));
          dR2Test = as.data.frame(matrix(cvS$aR2Test, nrow = 1));           
          dMrms = as.data.frame(matrix(cvS$aMrms, nrow = 1));

          aloghRBIG = cvS$aloghRBIG;
          indexTestBIG = cvS$indexTest;
        } else {
          dlTrain = rbind(dlTrain, cvS$alTrain);
          dR2Train= rbind(dR2Train, cvS$aR2Train);          
          dcvPL = rbind(dcvPL, cvS$acvPL);
          dlRatioTest = rbind(dlRatioTest, cvS$alRatioTest);
          dpRatioTest = rbind(dpRatioTest, cvS$apRatioTest);
          dR2Test= rbind(dR2Test, cvS$aR2Test);                    
          dMrms = rbind(dMrms, cvS$aMrms);

          aloghRBIG = rbind(aloghRBIG, cvS$aloghRBIG);     # Stack rows.
          indexTestBIG = c(indexTestBIG, cvS$indexTest);   # Add to end.
        }

        ntrain = cvS$ntrain;      # These will be about the same 
        ntest = cvS$ntest;        # for each resampling.
        # .....................................................................................   
      }

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / ncvHere;                               # Time per split.

      cat(" ..........  Outer cross-validation loop done. Total time = ", t2, " s.", sep = "");
      cat(" Time = ", tau, " s per step.\n");      
      # ....................................................................................................      




      # ....................................................................................................
      # . Generate summary stats.
      # .
      # . Log-likelihood for training set alone :
      # .................................................................................................... 
      alTrainQ25 = apply(dlTrain, 2, quantile, probs = 0.25);   # First quartile log-likelihood for training set.
      alTrainMedian = apply(dlTrain, 2, median);                # Median log-likelihood for training set.
      alTrainQ75 = apply(dlTrain, 2, quantile, probs = 0.75);   # Third quartile log-likelihood for training set.
      alTrainSigmaMad = apply(dlTrain, 2, mad);                 # MAD std. deviation of log-likeli for train. set.
      # ....................................................................................................
      # . R2 for training set :
      # .................................................................................................... 
      aR2TrainQ25 = apply(dR2Train, 2, quantile, probs = 0.25);   # First quartile R2 for training set.
      aR2TrainMedian = apply(dR2Train, 2, median);                # Median R2 for training set.
      aR2TrainQ75 = apply(dR2Train, 2, quantile, probs = 0.75);   # Third quartile R2 for training set.
      aR2TrainSigmaMad = apply(dR2Train, 2, mad);                 # MAD std. deviation of R2 for train. set.           
      # ....................................................................................................      
      # . Cross-validated log-likelihood :
      # ....................................................................................................
      acvPLQ25 = apply(dcvPL, 2, quantile, probs = 0.25);       # First quartile cvPL for training set.
      acvPLMedian = apply(dcvPL, 2, median);                    # Median cvPL for training set.
      acvPLQ75 = apply(dcvPL, 2, quantile, probs = 0.75);       # Third quartile cvPL for training set.
      acvPLSigmaMad = apply(dcvPL, 2, mad);                     # MAD std. deviation of cvPL for training set.
      # ....................................................................................................      
      # . Log-likelihood for test set using training set derived parameters :
      # ....................................................................................................
      alRatioTestQ25 = apply(dlRatioTest, 2, quantile, probs = 0.25);  # First quartile lRatioTest.
      alRatioTestMedian = apply(dlRatioTest, 2, median);               # Median lRatioTest.
      alRatioTestQ75 = apply(dlRatioTest, 2, quantile, probs = 0.75);  # Third quartile lRatioTest.
      alRatioTestSigmaMad = apply(dlRatioTest, 2, mad);                # MAD std. deviation of lRatioTest.

      apRatioTestQ25 = apply(dpRatioTest, 2, quantile, probs = 0.25);  # First quartile lRatioTest.
      apRatioTestMedian = apply(dpRatioTest, 2, median);               # Median lRatioTest.
      apRatioTestQ75 = apply(dpRatioTest, 2, quantile, probs = 0.75);  # Third quartile lRatioTest.
      
      apRatioTestCombine = apply(dpRatioTest, 2, Stat.combinePvalMean);   # Combined P-values for log-likeli.
      # ....................................................................................................
      # . R2 for test set :
      # .................................................................................................... 
      aR2TestQ25 = apply(dR2Test, 2, quantile, probs = 0.25);   # First quartile R2 for test set.
      aR2TestMedian = apply(dR2Test, 2, median);                # Median R2 for test set.
      aR2TestQ75 = apply(dR2Test, 2, quantile, probs = 0.75);   # Third quartile R2 for test set.
      aR2TestSigmaMad = apply(dR2Test, 2, mad);                 # MAD std. deviation of R2 for train. set.      
      # ....................................................................................................      
      # . Martingale residuals for the test set, using the training ste derived parameters :
      # ....................................................................................................      
      aMrmsQ25 = apply(dMrms, 2, quantile, probs = 0.25);  # First quartile for r.m.s. of Martingale res.
      aMrmsMedian = apply(dMrms, 2, median);               # Median Mrms.
      aMrmsQ75 = apply(dMrms, 2, quantile, probs = 0.75);  # Third quartile Mrms.
      aMrmsSigmaMad = apply(dMrms, 2, mad);                # MAD std. deviation Mrms.
      # ....................................................................................................


      
      # ....................................................................................................
      # . Generate single vectors of P-values and hazard ratios for the series of test sets generated 
      # . for all the feature selection levels :
      # ....................................................................................................
      atBIG = at[indexTestBIG];     # Survival times in order of generation by each split.
      asBIG = as[indexTestBIG];     # Censoring statuses in order of generation by each split.

      nScan = ncol(aloghRBIG);
      bBIG = sapply(1:nScan, function(j){buf = SuperPc.computeCoxSignificanceOnSplitLoghR(atBIG, asBIG, aloghRBIG[ , j]);});
      apRSigTest = as.numeric(bBIG["pR", ]);      # Get the P-values from the significance tests.
      ahRSigTest = as.numeric(bBIG["hR", ]);      # Get the hazard-ratios from the significance tests.      
      # ....................................................................................................      


      

      # .......................................................................
      # . Package results :
      # .......................................................................
      cv = list(parameterScan = parameterScan,
                methodSplit = methodSplit,
                ft = ft,
                ncv = ncv,
                ncvHere = ncvHere,
                rngSeed = rngSeed,
                K = K,
                mtop = mtop,
                nScan = cvS$nScan,
                amtop = amtop,
                aK = aK,
                ncv = ncvHere,
                n = n,
                ntrain = ntrain,
                ntest = ntest,
                p = p,

                alTrainQ25 = alTrainQ25,
                alTrainMedian = alTrainMedian,
                alTrainQ75 = alTrainQ75,
                alTrainSigmaMad = alTrainSigmaMad,

                aR2TrainQ25 = aR2TrainQ25,
                aR2TrainMedian = aR2TrainMedian,
                aR2TrainQ75 = aR2TrainQ75,
                aR2TrainSigmaMad = aR2TrainSigmaMad,
        
                acvPLQ25 = acvPLQ25,
                acvPLMedian = acvPLMedian,
                acvPLQ75 = acvPLQ75,
                acvPLSigmaMad = acvPLSigmaMad,

                alRatioTestQ25 = alRatioTestQ25,
                alRatioTestMedian = alRatioTestMedian,
                alRatioTestQ75 = alRatioTestQ75,
                alRatioTestSigmaMad = alRatioTestSigmaMad,

                apRatioTestQ25 = apRatioTestQ25,
                apRatioTestMedian = apRatioTestMedian,
                apRatioTestQ75 = apRatioTestQ75,
                apRatioTestCombine = apRatioTestCombine,

                aR2TestQ25 = aR2TestQ25,
                aR2TestMedian = aR2TestMedian,
                aR2TestQ75 = aR2TestQ75,
                aR2TestSigmaMad = aR2TestSigmaMad,

                aMrmsQ25 = aMrmsQ25,
                aMrmsMedian = aMrmsMedian,
                aMrmsQ75 = aMrmsQ75,
                aMrmsSigmaMad = aMrmsSigmaMad,

                apRSigTest = apRSigTest,         # nScan vector.
                ahRSigTest = ahRSigTest,         # nScan vector.

                atBIG = atBIG,                   # n vector.
                asBIG = asBIG,                   # n vector.
                aloghRBIG = aloghRBIG);          # n * nScan matrix.

      class(cv) = 'spc.cox.cv';
      # .......................................................................

      

      # ...........................................................
      cat(" ..........  Exit SuperPcCv.crossValidateCox.\n");
      # ...........................................................

      
      
      # .............
      return (cv);
      # .............

}

# ========================================================================================================
# . End of  SuperPcCv.crossValidateCox.
# ========================================================================================================      






# =================================================================================================
# . SuperPcCv.crossValidateCoxSingleSplit : generates a split of the data into training and test 
# . -------------------------------------   sets, and then computes log-likelihood-ratios for the 
# .                                         test set for a range of the supervised principal
# .                                         components parameters.
# .
# .   Syntax:
# .
# .      cv =  SuperPcCv.crossValidateCoxSingleSplit(at, as, dfX,
# .                                                  methodSplit,
# .                                                  af, ft,
# .                                                  scoreType,
# .                                                  mtop, K,
# .                                                  parameterScan,
# .                                                  amtop, aK,
# .                                                  icv, aIndexSplit,
# .                                                  flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid).
# .
# .                   - 'vfold' : use parameter ft (below) to do a vfold
# .                               split of the data matrix.
# .
# .
# .            - 'vfoldStrict'  : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, under methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, under
# .                 methodSplit = 'vfold'. Allowed: 0 < ft < 1.
# .
# .    >> Score type:
# .
# .     scoreType = type of score to be used for computing P-values.
# .                 Allowed values : 
# .                  - 'loglik' : use score = 2 * (l(beta*) - l(0)).
# .                  - 'u0'     : use score = U(0)^2 / J(0).
# .
# .
# .     >> Fixed-values parameters:
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values). Used only if
# .                 parameterScan = 'K'.
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .                 Used only if parameterScan = 'mtop'.
# .
# .
# .   parameterScan = which parameter to scan in doing the cross-validation on this split of
# .                the data. Allowed values:
# .
# .                   - 'mtop' : do the cross-validation for the values of mtop
# .                              in the input array amtop.
# .                              The input values of the fixed-value parameters mtop
# .                              and p0 are ignored.
# .                              All calculations are done at the fixed value of K.
# .
# .                   - 'K' :    do the cross-validation for the values of K
# .                              in the input array aK.
# .                              The input value of the fixed-value parameter K
# .                              is ignored.
# .                              All calculations are done at the fixed values of
# .                              mtop or p0 (whichever applies under selected
# .                              methodFs).
# .
# .     >> Arrays of parameters for cross-validation:
# .
# .         amtop = array of values of mtop. Keep the mtop genes
# .                 with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .            aK = array of number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .     >> Split counter and groups :
# .
# .           icv = defines the group to be removed under split method 'vfoldStrict'.
# .                 This parameter is ignored otherwise.
# .   aIndexSplit = list of disjoint arrays, defining the groups to be removed for that round
# .                 of cross validation. Used under split method 'vfoldStrict', ignored
# .                 otherwise.
# .
# .     >> General :
# .
# .   flagVerbose = if TRUE, prints progress on computation.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .       parameterScan = parameter that was scanned (mtop or K).
# .               nscan = number of discrete parameter values used.
# .               amtop = array of the nscan mtop values (for parameterScan = mtop).
# .                  aK = array of nscan K values (for parameterScan = K).
# .               alAll = log-likelihoods for entire data set.
# .             alTrain = log-likelihoods for just training set.
# .               acvPL = cross-validated partial likelihood.
# .         alRatioTest = log-likelihood ratio for test set, using training set model parameters.
# .         apRatioTest = P-values for log-likelihood-ratio for test set on train. set.      
# .               aMrms = r.m.s. values of Martingale residuals for the test set, evaluated
# .                       using the training set model parameters.
# .
# =================================================================================================

SuperPcCv.crossValidateCoxSingleSplit  <- function(at, as, dfX,
                                                   methodSplit,
                                                   af, ft,
                                                   scoreType,
                                                   mtop, K,
                                                   parameterScan,
                                                   amtop, aK,
                                                   icv,
                                                   aIndexSplit,
                                                   flagVerbose)
{

      # ...........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPcCv.crossValidateCoxSingleSplit.\n");
      }
      # ...........................................................................

      
  
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (nt != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxSingleSplit: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxSingleSplit: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (nf != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxSingleSplit: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxSingleSplit: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................        
      stopifnot((methodSplit == 'given')
                || (methodSplit == 'vfold')
                || (methodSplit == 'vfoldStrict'));
      stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));

      if (parameterScan == 'mtop') {
        stopifnot(K >= 1);
        stopifnot(length(amtop) > 0);        
      } else if (parameterScan == 'K') {
        stopifnot(mtop >= 1);
        stopifnot(length(aK) > 0);        
      }

      if (methodSplit == 'vfold') {
        stopifnot((ft > 0.0) && (ft < 1.0));
      }

      if (methodSplit == 'vfoldStrict') {
        ncvBuf = length(aIndexSplit);

        if (icv > ncvBuf) {
          cat("ERROR: from SuperPcCv.crossValidateCoxSingleSplit:\n");
          cat("icv = ", icv, " is greater than the number of groups to be cross-validated, ncv = ", ncvBuf, "\n", sep = "");
          stop();
        }
      }

      stopifnot((scoreType == 'loglik') || (scoreType == 'u0'));      
      # ...................................................................................

      

      # ...................................................................................
      # . Generate the indices for splitting the data into training and test set.
      # .
      # . >> methodSplit = given :
      # ...................................................................................
      if (methodSplit == 'given') {
        # ......................................................................
        # . Check all given entries are 'train', 'test' or 'NONE' :
        # ......................................................................
        indexInvalid = which((af != 'train') & (af != 'test') & (af != 'NONE'));

        if (length(indexInvalid) > 0) {
          msg = "ERROR: from SuperPcCv.crossValidateCoxSingleSplit: ";        
          msg = paste("The train/test assignment vector contains some values which are neither ", sep = "");
          msg = paste("train, test or NONE. First detected invalid value = ", af[indexInvalid[1]], sep = "");
          stop(msg);
        }
        # ......................................................................
        # . Find the indices for the training and test subsets :
        # ......................................................................
        indexTrain = which(af == 'train');
        indexTest = which(af == 'test');

        ntrain = length(indexTrain);
        ntest = length(indexTest);        
        
        if (ntrain < 2) {
          msg = "ERROR: from SuperPcCv.crossValidateCoxSingleSplit: ";
          msg = paste("Less than 2 training set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntrain = ", ntrain, sep = "");          
          stop(msg);
        }

        if (ntest < 2) {
          msg = "ERROR: from SuperPcCv.crossValidateCoxSingleSplit: ";
          msg = paste("Less than 2 test set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntest = ", ntest, sep = "");          
          stop(msg);
        }        
        # ......................................................................        
      }
      # ...................................................................................      
      # . >> methodSplit = vfold :
      # .    The training set and the test set must each have at least 2 elements.
      # .    Note that we require above that n >= 4, so that this is always possible.
      # ...................................................................................
      if (methodSplit == 'vfold') {
        # ......................................................................                
        ntest = floor(n * ft);
        if (ntest < 2) {
          ntest = 2;               # At least 2 elements in the test set.
        }

        n1 = n - 1;
        if (ntest >= n1) {
          ntest = n - 2;           # At least 2 elements in the training set.
        }
            
        indexTest = sample(x = 1:n, size = ntest);
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }
      # ...................................................................................      
      # . >> methodSplit = vfoldStrict :
      # . Under this option the groups were predefined before the function call,
      # . by function Stat.generateSplitsForVfold(). We just retrieve the indices.
      # ...................................................................................
      if (methodSplit == 'vfoldStrict') {
        # ......................................................................                
        indexTest = aIndexSplit[[icv]];
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }      
      # ...................................................................................      



      # ...................................................................................
      # . Generate the training and test subsets :
      # ...................................................................................
      atTrain = at[indexTrain];       # Survival times.
      asTrain = as[indexTrain];       # Censoring statuses (1 = not censored, 0 = censored).
      dfXTrain = dfX[indexTrain, ];   # Data matrix of gene expression values.

      atTest = at[indexTest];         # Survival times.
      asTest = as[indexTest];         # Censoring statuses (1 = not censored, 0 = censored).
      dfXTest = dfX[indexTest, ];     # Data matrix of gene expression values.        
      # ...................................................................................


      
      # ...................................................................................
      # . Adjust for special cases :
      # ...................................................................................
      if (length(indexTest) == 1) {
        dfXTest = matrix(dfXTest, nrow = 1);
      }
      # ...................................................................................      

      
      
      # ....................................................................................................
      # . Column-center the training data then generate univariate Cox scores for
      # . each gene separately.
      # ....................................................................................................
      axm = colMeans(dfXTrain);                                # Save the p column means.
      dfXc = scale(dfXTrain, center = TRUE, scale = FALSE);    # Center each gene separately.

      cat(" ..........  Compute univariate Cox scores.\n");
      cat(" ..........  Generate scores using scoreType = ", scoreType, "\n", sep = "");      

      if (scoreType == 'loglik') {      
        #xxxx coxS = Cox.computeOnDataFrameSimple(atTrain, asTrain, dfXc, flagVerbose = TRUE);                     # log-likelihood score.
        coxS = Cox.computeOnDataFrameSimpleBeta(atTrain, asTrain, dfXc, flagVerbose = TRUE);                       # log-likelihood score.      
      } else if (scoreType == 'u0') {
        #xxx coxS = Cox.computeOnDataFrameNoTiesParallel(atTrain, asTrain, dfXc, flagVerbose = flagVerbose);  # u0 score.
        coxS = Cox.computeOnDataFrameNoTiesCHUNKED(atTrain, asTrain, dfXc, flagVerbose = flagVerbose);        # Wrapper for the above.
      } else {
        cat("ERROR: from SuperPc.computeCox: scoreType = ", scoreType, " is not valid.\n");              # Failsafe.
        cat("Please check program logic.\n");
        stop();
      }
      # .....................................................................................................


      # ..............................................................................
      cat(" ..........  Begin inner cross-validation loop, scanning parameter = ",
            parameterScan, "\n", sep = "");
      # ..............................................................................

      
      # .........................................................................
      methodFs = 'mtop'; # Hardwired, as only feature selection method used here.
      p0 = 1.0;          # Dummy value, as is ignored in feature selection.
      # .........................................................................
      
      
      # .................................................................................................
      # . CROSS-VALIDATION
      # . >> PREAMBLE :
      # . Assign the array for the parameter to be scanned.
      # .................................................................................................
      if (parameterScan == 'mtop') {
        aScan = amtop;                        # Array of parameters to be scanned.
      } else if (parameterScan == 'K') {
        aScan = aK;                           # Array of parameters to be scanned.
      }
      # .................................................................................................
      # . For parameterScan = 'K', we need to do the feature selection at the indicated mtop level
      # . only once.
      # .................................................................................................      
      if (parameterScan == 'K') {
        selFFixed = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtop, coxS);
      }
      # .................................................................................................
      # . >> MAIN LOOP :
      # .................................................................................................
      alAll = c();             # Log-likelihoods for entire data set.
      alTrain = c();           # Log-likelihoods for just training set.
      aR2Train = c();          # R2 on training set.      
      acvPL = c();             # Cross-validated log-likelihoods.
      alRatioTest = c();       # Log-likelihood-ratio for test set on training set parameters.
      apRatioTest = c();       # P-values for log-likelihood-ratio for test set on train. set.
      aR2Test = c();           # R2 on test set.      
      aMrms = c();             # r.m.s. of Martingale res. for test set on train. set parameters.

      nScan = length(aScan);   # Number of levels to be explored.
      il = 0;                  # Level counter.
        
      cat("Progress: ", sep = "");     # Progress indicator.
      t1 = proc.time()[3];              # Starting time.
       
      for (z in aScan) {
        # .......................................................................................
        # . Set the parameters :
        # .......................................................................................        
        if (parameterScan == 'mtop') {
          mtopHere = z;             # The parameter being scanned is mtop.
          KHere = K;                # K is fixed.
        } else if (parameterScan == 'K') {
          mtopHere = mtop;          # mtop is fixed.
          KHere = z;                # The parameter being scanned is K.
        }
        # .......................................................................................
        # . Perform the feature selection with the indicated method and parameters :
        # .......................................................................................
        if (parameterScan == 'mtop') {
          selF = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtopHere, coxS);
        } else if (parameterScan == 'K') {
          selF = selFFixed;                    # This was precomputed at the specified value of mtop.
        }
        # .......................................................................................
        # . Do the svd and generate Cox proportional hazard model :
        # .......................................................................................      
        cSel = SuperPc.computeCoxOnSelectedFeatures(atTrain, asTrain, selF$dfXSel, KHere);
        # .......................................................................................
        # . Compute the baseline hazard functions (here using an approximation that assumes
        # . no ties) :
        # .......................................................................................
        bh = SuperPc.computeBaselineHazardNoTies(atTrain, asTrain, cSel, selF$dfXSel);              
        # .......................................................................................
        # . Package all the results into a single spc.cox object :
        # .......................................................................................
        spcTrain = SuperPc.packageSpcCox(methodFs = methodFs,
                                         mtop = mtopHere,
                                         p0 = p0,
                                         n = n, p = p,
                                         axm = axm, indexSel = selF$indexSel, m = selF$m,
                                         pvalMin = selF$pvalMin, pvalMax = selF$pvalMax,
                                         K = KHere,
                                         abeta = cSel$abeta,
                                         aseBeta = cSel$aseBeta,
                                         ap = cSel$ap,
                                         qR = cSel$qR, pR = cSel$pR,
                                         avSel = cSel$avSel,
                                         av = NULL,                  # Not required for log-likelihood.
                                         avSelTot = cSel$avSelTot,
                                         avTot = NULL,               # Not required for log-likelihood.
                                         sv = cSel$sv, coxK = cSel$coxK,
                                         bh = bh);
        # .......................................................................................
        # . i. Estimate the log partial likelihood for *all* samples, using the coefficients 
        # .    derived only from the training set.
        # .......................................................................................
        llBuf = SuperPc.computeCoxLogLikelihood(spcTrain,
                                                atIn = at,
                                                asIn = as,
                                                dfXIn = dfX);
        lOutAll = llBuf$lOut;
        # .......................................................................................
        # . ii. Estimate the log partial likelihood for only *training set* samples, using the 
        # .     coefficients derived only from the training set.
        # .......................................................................................        
        llBuf = SuperPc.computeCoxLogLikelihood(spcTrain,
                                                atIn = atTrain,
                                                asIn = asTrain,
                                                dfXIn = dfXTrain);
        lOutTrain = llBuf$lOut;
        lRatioTrain = llBuf$lRatio;                       # Log-likelkihood ratio on training set.
        R2Train = 1.0 - exp(- lRatioTrain / ntrain);      # R2 for training set.        
        # .......................................................................................
        # . Compute the cross-validated log partial likelihood (CVPL) :
        # .......................................................................................        
        cvPL = lOutAll - lOutTrain;
        # .......................................................................................
        # . Compute a log likelihood ratio for the test set on its own, but using the
        # . model derived from the training set :
        # .......................................................................................
        llBuf = SuperPc.computeCoxLogLikelihood(spcTrain,
                                                atIn = atTest,
                                                asIn = asTest,
                                                dfXIn = dfXTest);
        lRatioTest = llBuf$lRatio;
        lTemp = max(lRatioTest, 0.0);                               # As lRatioTest need not always be non-negative.
        pRatioTest = pchisq(lTemp, df = KHere, lower.tail = FALSE); # p-value from likelihood ratio.

        R2Test = 1.0 - exp(- lTemp / ntest);                        # R2 for test set, with lTemp floored at 0.       
        # .......................................................................................
        # . Compute the Martingale residuals for the test set, on the basis of the parameters
        # . estimated from the training set :
        # .......................................................................................
        slTest = SuperPc.computeCoxPcAndLogHazard(spcTrain,
                                                  dfXIn = dfXTest);
        ahRTest = slTest$ahR;                     # Test set values of exp(beta * Y).
        
        mr = SuperPc.computeMartingaleResiduals(spcTrain = spcTrain,
                                                atIn = atTest,
                                                asIn = asTest,
                                                ahRIn = ahRTest);
        Mrms = mr$Mrms;
        # .......................................................................................
        # . Generate the columns of the matrix of log-hazard-ratios
        # . [samples * feature-selection levels] for the test samples, for this given split.
        # . The final matrix will have dimensions ntest * nScan.
        # .......................................................................................
        if (il == 0) {
          aloghRBIG = matrix(slTest$aloghR, nrow = length(slTest$aloghR));    # The first column.
        } else {
          aloghRBIG = cbind(aloghRBIG, slTest$aloghR);                        # Subsequent columns.
        }
        # .......................................................................................
        # . Update arrays :
        # .......................................................................................
        alAll = c(alAll, lOutAll);  
        alTrain = c(alTrain, lOutTrain);             # Log-likelihood on training set only.
        aR2Train = c(aR2Train, R2Train);             # R2 for training set.
        acvPL = c(acvPL, cvPL);                      # Cross-validated log-likelihood.
        alRatioTest = c(alRatioTest, lRatioTest);    # Log-likelihood ratio for test set.
        apRatioTest = c(apRatioTest, pRatioTest);    # p-value for test set fitted by training set coefficients.
        aR2Test = c(aR2Test, R2Test);                # R2 for test set fitted by training set coefficients.       
        aMrms = c(aMrms, Mrms);                      # Martingale residuals for the test set.

        cat(".", sep = "");                          # Progress indicator.

        il = il + 1;
        if (il%%20 == 0) {
          cat(" : processed ", il, " levels out of ", nScan, ".\n", sep = "");
          cat("          ", sep = "");            # Spacer for next row of dots indicating progress.
        }
        # .......................................................................................          
      }
      # .......................................................................................
      # . Summarize times :
      # .......................................................................................        
      cat("\n", sep = "");

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / nScan;                                 # Time per parameter value.

      if (flagVerbose) {
        cat(" ..........  Inner cross-validation loop done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per ", parameterScan, " value.\n");
      }
      # .............................................................................................

      

      # ...............................................
      # . Package results :
      # ...............................................
      cv = list(parameterScan = parameterScan,
                methodSplit = methodSplit,
                scoreType = scoreType,
                mtop = mtop,
                K = K,        
                nScan = nScan,
                amtop = amtop,
                aK = aK,
                n = n,
                ntrain = ntrain,
                ntest = ntest,
                alAll = alAll,
                alTrain = alTrain,
                aR2Train = aR2Train,        
                acvPL = acvPL,
                alRatioTest = alRatioTest,
                apRatioTest = apRatioTest,
                aR2Test = aR2Test,        
                aMrms = aMrms,
                indexTest = indexTest,
                aloghRBIG = aloghRBIG);

      class(cv) = 'spc.cox.cv.single';
      # ...............................................


      # .............
      return (cv);
      # .............
      
}

# =================================================================================================
# . End of SuperPcCv.crossValidateCoxSingleSplit.
# =================================================================================================





# =================================================================================================
# . SuperPcCv.crossValidateCoxWithCov : cross-validation of the Cox proportional hazard model over 
# . ---------------------------------   multiple splits of the data into training and test sets,
# .                                     with exploration of a range of model parameters.
# .                                     This version is with an external covariate.
# .                              
# .
# .   Syntax:
# .
# .            cv =  SuperPcCv.crossValidateCoxWithCov(at, as, az, dfX,
# .                                                    methodSplit,
# .                                                    af, ft, ncv,
# .                                                    rngSeed, flagRngSeed,
# .                                                    mtop, K,
# .                                                    parameterScan,
# .                                                    amtop, aK,
# .                                                    typePval,
# .                                                    flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid). Note that only ONE split is ever
# .                               generated.
# .
# .                   - 'vfold' : use parameter ft (below) to do a vfold
# .                               split of the data matrix. Generate ncv
# .                               independent splits of the data matrix.
# .
# .             - 'vfoldStrict' : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, for methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfold' or 'vfoldStrict'. Allowed: 0 < ft < 1.
# .
# .           ncv = number of independent splots generated, under method 'vfold'.
# .
# .       rngSeed = initial random number seed. Must be integer > 0.
# .
# .   flagRngSeed = if TRUE, set initial random number seed to value rngSeed.
# .                 If FALSE, do not (re)set value.
# .
# .     >> Fixed-values parameters:
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values). Used only if
# .                 parameterScan = 'K'.
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .                 Used only if parameterScan = 'mtop'.
# .
# .
# .   parameterScan = which parameter to scan in doing the cross-validation on this split of
# .                the data. Allowed values:
# .
# .                   - 'mtop' : do the cross-validation for the values of mtop
# .                              in the input array amtop.
# .                              The input values of the fixed-value parameters mtop
# .                              and p0 are ignored.
# .                              All calculations are done at the fixed value of K.
# .
# .                   - 'K' :    do the cross-validation for the values of K
# .                              in the input array aK.
# .                              The input value of the fixed-value parameter K
# .                              is ignored.
# .                              All calculations are done at the fixed values of
# .                              mtop or p0 (whichever applies under selected
# .                              methodFs).
# .
# .     >> Arrays of parameters for cross-validation:
# .
# .         amtop = array of values of mtop. Keep the mtop genes
# .                 with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .            aK = array of number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .     >> Type of P-value used for the feature selection:
# .
# .      typePval = type of the P-value that is to be used for the feature selection.
# .                 Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .   flagVerbose = if TRUE, prints progress on computation in the innner cross-validation loop.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .       parameterScan = parameter that was scanned (mtop or K).
# .               nscan = number of discrete parameter values used.
# .               amtop = array of the nscan mtop values (for parameterScan = mtop).
# .                  aK = array of nscan K values (for parameterScan = K).
# .               alAll = log-likelihoods for entire data set.
# .             alTrain = log-likelihoods for just training set.
# .
# .................................................................................................
# .  ADDITIONAL DETAILS :
# .
# .  * Note that the gene-by-gene score type here is always implicitely 'loglik', so that there is no
# .    explicit parameter for 'scoreType'. This is because I have not implemented an alternative
# .    'u0' type of score (schematically, one for which score = U(0)^2 / J(0)) for the case
# .    with an external covariate. Such a score is however available for the case without an
# .    external covariate, where it does provide a modest (~ 2-fold) speedup in evaluation
# .    of the gene-by-gene scores.
# .
# =================================================================================================

SuperPcCv.crossValidateCoxWithCov  <- function(at, as, az, dfX,
                                               methodSplit,
                                               af, ft, ncv,
                                               rngSeed, flagRngSeed,
                                               mtop, K,
                                               parameterScan,
                                               amtop, aK,
                                               typePval,
                                               flagVerbose)
{

      # ...........................................................................
      cat(" ..........  Entry in SuperPcCv.crossValidateCoxWithCov.\n");
      # ...........................................................................


      
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.            
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (nt != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCov: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCov: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCov: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      
      if (nf != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCov: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCov: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
#      stopifnot((methodSplit == 'given')
#                || (methodSplit == 'vfold')
#                || (methodSplit == 'vfoldStrict'));

      stopifnot((methodSplit == 'given')
                || (methodSplit == 'vfoldStrict'));     # methodSplit = vfold is obsolete.
      
      stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));

      if (parameterScan == 'mtop') {
        stopifnot(K >= 1);
        stopifnot(length(amtop) > 0);        
      } else if (parameterScan == 'K') {
        stopifnot(mtop >= 1);
        stopifnot(length(aK) > 0);        
      }

      if (methodSplit == 'vfold') {
        stopifnot(ncv >= 1);      
        stopifnot((ft > 0.0) && (ft < 1.0));
      }

      stopifnot(rngSeed > 0);
      stopifnot(flagRngSeed || !flagRngSeed);

      allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
      if (is.null(allowedTypePval[[typePval]])) {
        cat("ERROR: from SuperPcCv.crossValidateCoxWithCov:\n");
        cat("typePval = ", typePval, " is not valid.\n", sep = "");
        cat("Valid: model, X, Z, ZX.\n", sep = "");
        stop();
      }
      # ...................................................................................


      
      # .......................................................................................
      # . Check on the external covariate :
      # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
      # . Note that this applies only to the cross-validation program, and not to the
      # . feature selection or model building cases.
      # .......................................................................................    
      msgBin = Cox.checkBinary(az);

      if (msgBin != 'ok') {
        cat("ERROR: from SuperPcCv.crossValidateCoxWithCov:\n");
        cat("External covariate values must all be {0, 1}\n");
        cat(msgBin);
        cat("\n");
        stop();
      }
    # .......................................................................................



      
      # .........................................
      # . Initialize random number generator :
      # .........................................
      if (flagRngSeed) {
        set.seed(rngSeed);
      }
      # .........................................
      

      # ....................................................................................................
      cat(" ..........  Begin outer cross-validation loop, parameter scanned = ", parameterScan, "\n", sep = "");
      # ....................................................................................................



      # ....................................................................................................
      # . >>CROSS-VALIDATION :
      # . Generate ncv independent splits of the data, and compute log-likelihoods for the designated
      # . range of the chosen parameter.
      # .
      # . >>PREAMBLE :
      # ....................................................................................................
      if (methodSplit == 'given') {
        ncvHere = 1;                        # We are using only the designated split in the data.
        aIndexSplit = NULL;                 # Will not be needed.        
      } else if (methodSplit == 'vfold') {
        ncvHere = ncv;                      # Generate all ncv independent samplings.
        aIndexSplit = NULL;                 # Will not be needed.                
      } else if (methodSplit == 'vfoldStrict') {
        cSplit = Stat.generateSplitsForVfold(n = n, ft = ft, flagRandom = TRUE);  # Generate truly disjoint groups.
        ncvHere = cSplit$ncv;
        aIndexSplit = cSplit$aIndexSplit;
        afold = cSplit$afold;               # Maps: sample --> fold.        
      }

      agFs = list();         # Fold-by-fold list of genes selected by first-pass feature selection.      
      # ....................................................................................................
      # . Begin cross-validation below :
      # ....................................................................................................      
      cat(" ..........  Total number of steps: ncvHere = ", ncvHere, "\n", sep = "");
      cat(" ..........  Start loop.\n", sep = "");            
      # ....................................................................................................
      # . >> MAIN LOOP :
      # ....................................................................................................
      t1 = proc.time()[3];              # Starting time.
      
      for (icv in 1:ncvHere) {
        cat("Start step = ", icv, " out of ", ncvHere, "\n", sep = "");
        
        ta = proc.time()[3];
        cvS =  SuperPcCv.crossValidateCoxWithCovSingleSplit(at = at,
                                                            as = as,
                                                            az = az,          
                                                            dfX = dfX,
                                                            methodSplit = methodSplit,
                                                            af = af,
                                                            ft = ft,
                                                            mtop = mtop,
                                                            K = K,
                                                            parameterScan = parameterScan,
                                                            amtop = amtop,
                                                            aK = aK,
                                                            icv = icv,
                                                            aIndexSplit = aIndexSplit,
                                                            typePval = typePval,
                                                            flagVerbose = flagVerbose);
        tb = proc.time()[3] - ta;
        cat("Processed step = ", icv, " out of ", ncvHere, ", time = ", tb, " s.\n", sep = "");
        # .....................................................................................
        # . Package intermediate results :
        # .....................................................................................
        if (icv == 1) {
          dlTrain = as.data.frame(matrix(cvS$alTrain, nrow = 1));
          dR2Train = as.data.frame(matrix(cvS$aR2Train, nrow = 1));          
          dcvPL = as.data.frame(matrix(cvS$acvPL, nrow = 1));
          dlRatioTest = as.data.frame(matrix(cvS$alRatioTest, nrow = 1));
          dpRatioTest = as.data.frame(matrix(cvS$apRatioTest, nrow = 1));
          dR2Test = as.data.frame(matrix(cvS$aR2Test, nrow = 1));                    
          dMrms = as.data.frame(matrix(cvS$aMrms, nrow = 1));

          aloghRBIG = cvS$aloghRBIG;
          aloghRBIG0 = cvS$aloghRBIG0;
          aloghRBIG1 = cvS$aloghRBIG1;          
          indexTestBIG = cvS$indexTest;          
        } else {
          dlTrain = rbind(dlTrain, cvS$alTrain);
          dR2Train= rbind(dR2Train, cvS$aR2Train);
          dcvPL = rbind(dcvPL, cvS$acvPL);
          dlRatioTest = rbind(dlRatioTest, cvS$alRatioTest);
          dpRatioTest = rbind(dpRatioTest, cvS$apRatioTest);
          dR2Test= rbind(dR2Test, cvS$aR2Test);          
          dMrms = rbind(dMrms, cvS$aMrms);

          aloghRBIG = rbind(aloghRBIG, cvS$aloghRBIG);     # Stack rows.
          aloghRBIG0 = rbind(aloghRBIG0, cvS$aloghRBIG0);  # Stack rows.
          aloghRBIG1 = rbind(aloghRBIG1, cvS$aloghRBIG1);  # Stack rows.
          indexTestBIG = c(indexTestBIG, cvS$indexTest);   # Add to end.          
        }

        ntrain = cvS$ntrain;      # These will be the same 
        ntest = cvS$ntest;        # for each resampling.
        # ................................................................................................
        # . Save gene lists for this fold :
        # . These are the feature-selected genes for the very last feature selection level used.
        # . This list makes sense only in the context of a SINGLE feature selection level being explored.
        # ................................................................................................
        agFs[[icv]] = cvS$agFs;        
        # .....................................................................................   
      }
      # ..................................................................................
      # . Now that all the collected test-sets log-hazard-ratios have been assembled,
      # . restore the original order of sample indices.
      # ..................................................................................      
      aloghRBIG[indexTestBIG, ] = aloghRBIG;        
      aloghRBIG0[indexTestBIG, ] = aloghRBIG0;     
      aloghRBIG1[indexTestBIG, ] = aloghRBIG1;

      aDloghRBIG = aloghRBIG1 - aloghRBIG0;          # Predicted differential log-hazard.
      # ..................................................................................
      # . The outer cross-validation loop is done :
      # ..................................................................................            
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / ncvHere;                               # Time per split.

      cat(" ..........  Outer cross-validation loop done. Total time = ", t2, " s.", sep = "");
      cat(" Time = ", tau, " s per step.\n");      
      # ....................................................................................................      




      # ....................................................................................................
      # . Consolidate selected gene lists into fold-membership matrices.
      # ....................................................................................................      
      agFsUnion = sort(unique(unlist(agFs)));
      agFsMat = matrix(0, nrow = length(agFsUnion), ncol = ncvHere);

      for (icv in 1:ncvHere) {      
        buf = ifelse(agFsUnion %in% agFs[[icv]], 1, 0);
        agFsMat[ , icv] = buf;
      }

      rownames(agFsMat) = agFsUnion;
      colnames(agFsMat) = paste("fold_", 1:ncvHere, sep = "");
      # ....................................................................................................
      


      # ....................................................................................................
      # . Generate summary stats.
      # .
      # . Log-likelihood for training set alone :
      # .................................................................................................... 
      alTrainQ25 = apply(dlTrain, 2, quantile, probs = 0.25);   # First quartile log-likelihood for training set.
      alTrainMedian = apply(dlTrain, 2, median);                # Median log-likelihood for training set.
      alTrainQ75 = apply(dlTrain, 2, quantile, probs = 0.75);   # Third quartile log-likelihood for training set.
      alTrainSigmaMad = apply(dlTrain, 2, mad);                 # MAD std. deviation of log-likeli for train. set.
      # ....................................................................................................
      # . R2 for training set :
      # .................................................................................................... 
      aR2TrainQ25 = apply(dR2Train, 2, quantile, probs = 0.25);   # First quartile R2 for training set.
      aR2TrainMedian = apply(dR2Train, 2, median);                # Median R2 for training set.
      aR2TrainQ75 = apply(dR2Train, 2, quantile, probs = 0.75);   # Third quartile R2 for training set.
      aR2TrainSigmaMad = apply(dR2Train, 2, mad);                 # MAD std. deviation of R2 for train. set.     
      # ....................................................................................................      
      # . Cross-validated log-likelihood :
      # ....................................................................................................
      acvPLQ25 = apply(dcvPL, 2, quantile, probs = 0.25);       # First quartile cvPL for training set.
      acvPLMedian = apply(dcvPL, 2, median);                    # Median cvPL for training set.
      acvPLQ75 = apply(dcvPL, 2, quantile, probs = 0.75);       # Third quartile cvPL for training set.
      acvPLSigmaMad = apply(dcvPL, 2, mad);                     # MAD std. deviation of cvPL for training set.
      # ....................................................................................................      
      # . Log-likelihood for test set using training set derived parameters :
      # ....................................................................................................
      alRatioTestQ25 = apply(dlRatioTest, 2, quantile, probs = 0.25);  # First quartile lRatioTest.
      alRatioTestMedian = apply(dlRatioTest, 2, median);               # Median lRatioTest.
      alRatioTestQ75 = apply(dlRatioTest, 2, quantile, probs = 0.75);  # Third quartile lRatioTest.
      alRatioTestSigmaMad = apply(dlRatioTest, 2, mad);                # MAD std. deviation of lRatioTest.

      apRatioTestQ25 = apply(dpRatioTest, 2, quantile, probs = 0.25);  # First quartile lRatioTest.
      apRatioTestMedian = apply(dpRatioTest, 2, median);               # Median lRatioTest.
      apRatioTestQ75 = apply(dpRatioTest, 2, quantile, probs = 0.75);  # Third quartile lRatioTest.
      
      apRatioTestCombine = apply(dpRatioTest, 2, Stat.combinePvalMean);   # Combined P-values for log-likeli.
      # ....................................................................................................
      # . R2 for test set :
      # .................................................................................................... 
      aR2TestQ25 = apply(dR2Test, 2, quantile, probs = 0.25);   # First quartile R2 for test set.
      aR2TestMedian = apply(dR2Test, 2, median);                # Median R2 for test set.
      aR2TestQ75 = apply(dR2Test, 2, quantile, probs = 0.75);   # Third quartile R2 for test set.
      aR2TestSigmaMad = apply(dR2Test, 2, mad);                 # MAD std. deviation of R2 for train. set.
      # ....................................................................................................      
      # . Martingale residuals for the test set, using the training ste derived parameters :
      # ....................................................................................................      
      aMrmsQ25 = apply(dMrms, 2, quantile, probs = 0.25);  # First quartile for r.m.s. of Martingale res.
      aMrmsMedian = apply(dMrms, 2, median);               # Median Mrms.
      aMrmsQ75 = apply(dMrms, 2, quantile, probs = 0.75);  # Third quartile Mrms.
      aMrmsSigmaMad = apply(dMrms, 2, mad);                # MAD std. deviation Mrms.
      # ....................................................................................................


      # ....................................................................................................
      # . Generate single vectors of P-values and hazard ratios for the series of test sets generated 
      # . for all the feature selection levels :
      # ....................................................................................................
      nScan = ncol(aloghRBIG);      # Total number of feature selection levels.

      cat(" ..........  Compute significance of differences in survival times\n");
      cat("             for collected test samples predicted to be sensitive.\n");
      cat("             nScan = ", nScan, " feature selection levels will be tested.\n");            
      # .......................................................................................
      # . Generate nScan vectors and (n * nScan) arrays storing test results for each
      # . feature selection level:
      # .......................................................................................
      apR0 = c();
      ahR0 = c();
      apR1 = c();
      ahR1 = c();            

      cat(">>Progress: ");             # Dots will follow.
      
      for (j in 1:nScan) {
        cCov = SuperPc.computeCoxWithCovSignificanceOnSplit(at, as, az,
                                                            aloghRBIG[ , j],
                                                            aloghRBIG0[ , j],
                                                            aloghRBIG1[ , j],
                                                            flagComputeRES = TRUE);            
        apR0[j] = cCov$cs0$pR;
        ahR0[j] = cCov$cs0$hR;

        apR1[j] = cCov$cs1$pR;
        ahR1[j] = cCov$cs1$hR;                
        
        if (j == 1) {
          aDloghRSortBIG = as.data.frame(matrix(cCov$aDloghRSort, nrow = n));
          indexSortBIG = as.data.frame(matrix(cCov$indexSort, nrow = n));
          
          apRSortBIG = as.data.frame(matrix(cCov$apRSort, nrow = n));           # Sensitives P-values.     
          ahRSortBIG = as.data.frame(matrix(cCov$ahRSort, nrow = n));           # Sensitives hazard ratios.
          
          apRSortRESBIG = as.data.frame(matrix(cCov$apRSortRES, nrow = n));     # Resistants P-values.
          ahRSortRESBIG = as.data.frame(matrix(cCov$ahRSortRES, nrow = n));     # Resistants hazard ratios.
          
          aicMinBIG = c(cCov$icMin);
          apRMin = c(cCov$pRMin);
          ahRMin = c(cCov$hRMin);          
          ahRCBIG = c(cCov$hRC);          
        } else {
          aDloghRSortBIG = cbind(aDloghRSortBIG, cCov$aDloghRSort);
          indexSortBIG = cbind(indexSortBIG, cCov$indexSort);
          
          apRSortBIG = cbind(apRSortBIG, cCov$apRSort);                         # Sensitives P-values.     
          ahRSortBIG = cbind(ahRSortBIG, cCov$ahRSort);                         # Sensitives hazard ratios.

          apRSortRESBIG = cbind(apRSortRESBIG, cCov$apRSortRES);                # Resistants P-values.     
          ahRSortRESBIG = cbind(ahRSortRESBIG, cCov$ahRSortRES);                # Resistants hazard ratios.          
          
          aicMinBIG = c(aicMinBIG, cCov$icMin);
          apRMin = c(apRMin, cCov$pRMin);       # Minimum P-value at optimal thresholding between z = 1 and z = 0 sub-populations.  
          ahRMin = c(ahRMin, cCov$hRMin);       # The corresponding hazard-ratio between z = 1 and z = 0 sub-populations.
          ahRCBIG = c(ahRCBIG, cCov$hRC);       # Optimal cut: subset at predicted
                                                # lambda(z = 1) / lambda(z = 0) <= hRC to minimize the P-value.
        }

        cat(".", sep = "");     # Progress indicator.
      }

      cat("\n");                # We are done.
      # ....................................................................................................


      
      # ....................................................................................................
      # . For quantities arising from the Z=1 to Z=0 comparisons, generate arrays in the
      # . original (unsorted) order 
      # ....................................................................................................
      apRUnSortBIG = apRSortBIG;       # Dummy assign, just to get allocation.
      ahRUnSortBIG = ahRSortBIG;       # Dummy assign, just to get allocation.
      arankBIG = indexSortBIG;         # Dummy assign, just to get allocation.
      
      apRUnSortRESBIG = apRSortRESBIG; # Dummy assign, just to get allocation.
      ahRUnSortRESBIG = ahRSortRESBIG; # Dummy assign, just to get allocation.

      nScan = ncol(indexSortBIG);        # Number of tuning parameter levels = number of columns.

      for (j in 1:nScan) {
        apRUnSortBIG[indexSortBIG[ , j], j] = apRSortBIG[ ,j];
        ahRUnSortBIG[indexSortBIG[ , j], j] = ahRSortBIG[ ,j];

        apRUnSortRESBIG[indexSortBIG[ , j], j] = apRSortRESBIG[ ,j];
        ahRUnSortRESBIG[indexSortBIG[ , j], j] = ahRSortRESBIG[ ,j];        
        
        abuf = 1:n;
        arankBIG[indexSortBIG[ , j], j] = abuf;  # For each sample in original order, its rank in terms of DloghR.
      }
      # ....................................................................................................      
      

      

      # ........................................................................................
      # . Package results :
      # ........................................................................................
      cv = list(parameterScan = parameterScan,
                methodSplit = methodSplit,
                ft = ft,
                ncvHere = ncvHere,             # Actual number of splits.
                rngSeed = rngSeed,
                afold = afold,                 # For method vfoldStrict: maps sample --> fold.        
                K = K,
                mtop = mtop,
                nScan = cvS$nScan,
                amtop = amtop,
                aK = aK,
                typePval = typePval,
                ncv = ncvHere,
                n = n,
                ntrain = ntrain,
                ntest = ntest,
                p = p,
        
                alTrainQ25 = alTrainQ25,
                alTrainMedian = alTrainMedian,
                alTrainQ75 = alTrainQ75,
                alTrainSigmaMad = alTrainSigmaMad,

                aR2TrainQ25 = aR2TrainQ25,
                aR2TrainMedian = aR2TrainMedian,
                aR2TrainQ75 = aR2TrainQ75,
                aR2TrainSigmaMad = aR2TrainSigmaMad,
        
                acvPLQ25 = acvPLQ25,
                acvPLMedian = acvPLMedian,
                acvPLQ75 = acvPLQ75,
                acvPLSigmaMad = acvPLSigmaMad,
        
                alRatioTestQ25 = alRatioTestQ25,
                alRatioTestMedian = alRatioTestMedian,
                alRatioTestQ75 = alRatioTestQ75,
                alRatioTestSigmaMad = alRatioTestSigmaMad,

                apRatioTestQ25 = apRatioTestQ25,
                apRatioTestMedian = apRatioTestMedian,
                apRatioTestQ75 = apRatioTestQ75,
                apRatioTestCombine = apRatioTestCombine,

                aR2TestQ25 = aR2TestQ25,
                aR2TestMedian = aR2TestMedian,
                aR2TestQ75 = aR2TestQ75,
                aR2TestSigmaMad = aR2TestSigmaMad,
        
                aMrmsQ25 = aMrmsQ25,
                aMrmsMedian = aMrmsMedian,
                aMrmsQ75 = aMrmsQ75,
                aMrmsSigmaMad = aMrmsSigmaMad,
                # ................................................................................
                # . >> Prognostic tests :
                # ................................................................................
                apR0 = apR0,                      # nScan : P-values for PROGNOSTIC tests on Z=0 arm only.
                ahR0 = ahR0,                      # nScan : corresponding hR for PROGNOSTIC tests on Z=0 arm only.
        
                apR1 = apR1,                      # nScan : P-values for PROGNOSTIC tests on Z=1 arm only.
                ahR1 = ahR1,                      # nScan : corresponding hR for PROGNOSTIC tests on Z=1 arm only.
                # ................................................................................
                # . >> Time, censoring status and external covariate :
                # ................................................................................
                atBIG = at,                       # n : vector of survival times actually used.
                asBIG = as,                       # n : vector of censoring statuses actually used.
                azBIG = az,                       # n : vector of covariate values actually used.
                # ................................................................................
                # . >> UNSORTED arrays below :
                # ................................................................................
                aloghRBIG = aloghRBIG,            # n * nScan : each column contains predicted loghR for collected test sets, for actual values of Z.
                aloghRBIG0 = aloghRBIG0,          # n * nScan : each column contains predicted loghR for collected test sets, for Z = 0.
                aloghRBIG1 = aloghRBIG1,          # n * nScan : each column contains predicted loghR for collected test sets, for Z = 1.
                aDloghRBIG = aDloghRBIG,          # n * nScan : each column contains loghR(Z=1) - loghR(Z=0).

                apRUnSortBIG = apRUnSortBIG,      # n * nScan : each col. contains Z=1 to Z=0 P-value for threshold at this DloghR.
                ahRUnSortBIG = ahRUnSortBIG,      # n * nScan :  each col. contains Z=1 to Z=0 hR for threshold at this DloghR.
                arankBIG = arankBIG,              # n * nScan : in each col., for each sample in original order, its rank in terms of DloghR.
                # ................................................................................
                # . >> SORTED arrays below :
                # ................................................................................
                aDloghRSortBIG = aDloghRSortBIG,  # n * nScan : each column contains DloghR = loghR(Z=1) - loghR(Z=0), sorted in increasing order.
                indexSortBIG = indexSortBIG,      # n * nScan : each column contains the sort index: aDloghRSort =  aDloghR[indexSort].
                apRSortBIG = apRSortBIG,          # n * nScan : each column contains P-values for Z=1 to Z=0 comparisons, in sort order.
                ahRSortBIG = ahRSortBIG,          # n * nScan : each column contains hR's for Z=1 to Z=0 comparisons, in sort order.

                flagComputeRES = TRUE,            # Indicates whether computation of pR and hR profile has been done for the *resistant* subset.
                apRSortRESBIG = apRSortRESBIG,    # n * nScan : each column contains P-values for Z=1 to Z=0 comparisons, in sort order, for RESISTANT subset.
                ahRSortRESBIG = ahRSortRESBIG,    # n * nScan : each column contains hR's for Z=1 to Z=0 comparisons, in sort order, for RESISTANT subset.
                # ................................................................................
                # . Quantities obtained for maximum P-values :
                # ................................................................................        
                ahRCBIG = ahRCBIG,                # nScan : optimal hR = hRC, for selecting patients predicted to be sensitive by hR <= hRC filter.        
                aicMinBIG = aicMinBIG,            # nScan : number of patients selected by hR <= hRC filter.
                apRMin = apRMin,                  # nScan : P-value for Z = 1 to Z = 1 comparisons, at best hRC.
                ahRMin = ahRMin,                  # nScan : vector.
                # ................................................................................
                # . Membership matrices for selected genes * fold :
                # ................................................................................
                agFsMat = agFsMat                 # First-pass feature selected genes.        
                # ................................................................................        
        );          

      class(cv) = 'spc.cox.cov.cv';
      # ........................................................................................      

      

      # ...........................................................
      cat(" ..........  Exit SuperPcCv.crossValidateCoxWithCov.\n");
      # ...........................................................

      
      
      # .............
      return (cv);
      # .............

}

# ========================================================================================================
# . End of  SuperPcCv.crossValidateCoxWithCov.
# ========================================================================================================      






# =================================================================================================
# . SuperPcCv.crossValidateCoxWithCovSingleSplit : generates a split of the data into training and test 
# . --------------------------------------------   sets, and then computes log-likelihood-ratios for the 
# .                                                test set for a range of the supervised principal
# .                                                components parameters.
# .
# .   Syntax:
# .
# .      cv =  SuperPcCv.crossValidateCoxWithCovSingleSplit(at, as, az, dfX,
# .                                                         methodSplit,
# .                                                         af, ft,
# .                                                         mtop, K,
# .                                                         parameterScan,
# .                                                         amtop, aK,
# .                                                         icv, aIndexSplit,
# .                                                         typePval,
# .                                                         flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid).
# .
# .                   - 'vfold' : use parameter ft (below) to do a vfold
# .                               split of the data matrix.
# .
# .            - 'vfoldStrict'  : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, under methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, under
# .                 methodSplit = 'vfold'. Allowed: 0 < ft < 1.
# .
# .
# .     >> Fixed-values parameters:
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values). Used only if
# .                 parameterScan = 'K'.
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .                 Used only if parameterScan = 'mtop'.
# .
# .
# .   parameterScan = which parameter to scan in doing the cross-validation on this split of
# .                the data. Allowed values:
# .
# .                   - 'mtop' : do the cross-validation for the values of mtop
# .                              in the input array amtop.
# .                              The input values of the fixed-value parameters mtop
# .                              and p0 are ignored.
# .                              All calculations are done at the fixed value of K.
# .
# .                   - 'K' :    do the cross-validation for the values of K
# .                              in the input array aK.
# .                              The input value of the fixed-value parameter K
# .                              is ignored.
# .                              All calculations are done at the fixed values of
# .                              mtop or p0 (whichever applies under selected
# .                              methodFs).
# .
# .     >> Arrays of parameters for cross-validation:
# .
# .         amtop = array of values of mtop. Keep the mtop genes
# .                 with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .            aK = array of number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .     >> Split counter and groups :
# .
# .           icv = defines the group to be removed under split method 'vfoldStrict'.
# .                 This parameter is ignored otherwise.
# .   aIndexSplit = list of disjoint arrays, defining the groups to be removed for that round
# .                 of cross validation. Used under split method 'vfoldStrict', ignored
# .                 otherwise.
# .
# .     >> Type of P-value used for the feature selection:
# .
# .      typePval = type of the P-value that is to be used for the feature selection.
# .                 Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .     >> General :
# .
# .   flagVerbose = if TRUE, prints progress on computation.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .       parameterScan = parameter that was scanned (mtop or K).
# .               nscan = number of discrete parameter values used.
# .               amtop = array of the nscan mtop values (for parameterScan = mtop).
# .                  aK = array of nscan K values (for parameterScan = K).
# .               alAll = log-likelihoods for entire data set.
# .             alTrain = log-likelihoods for just training set.
# .            aR2Train = R2 for just training set.
# .               acvPL = cross-validated partial likelihood.
# .         alRatioTest = log-likelihood ratio for test set, using training set model parameters.
# .         apRatioTest = P-values for log-likelihood-ratio for test set on train. set.
# .             aR2Test = R2 for just test set.
# .               aMrms = r.m.s. values of Martingale residuals for the test set, evaluated
# .                       using the training set model parameters.
# .
# =================================================================================================

SuperPcCv.crossValidateCoxWithCovSingleSplit  <- function(at, as, az, dfX,
                                                          methodSplit,
                                                          af, ft,
                                                          mtop, K,
                                                          parameterScan,
                                                          amtop, aK,
                                                          icv,
                                                          aIndexSplit,
                                                          typePval,
                                                          flagVerbose)
{

      # ...........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPcCv.crossValidateCoxWithCovSingleSplit.\n");
      }
      # ...........................................................................

      
  
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.                  
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (nt != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovSingleSplit: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovSingleSplit: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }
      
      if (nz != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovSingleSplit: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      
      if (nf != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovSingleSplit: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovSingleSplit: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................        
      stopifnot((methodSplit == 'given')
                || (methodSplit == 'vfold')
                || (methodSplit == 'vfoldStrict'));
      stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));

      if (parameterScan == 'mtop') {
        stopifnot(K >= 1);
        stopifnot(length(amtop) > 0);        
      } else if (parameterScan == 'K') {
        stopifnot(mtop >= 1);
        stopifnot(length(aK) > 0);        
      }

      allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
      if (is.null(allowedTypePval[[typePval]])) {
        cat("ERROR: from SuperPcCv.crossValidateCoxWithCov:\n");
        cat("typePval = ", typePval, " is not valid.\n", sep = "");
        cat("Valid: model, X, Z, ZX.\n", sep = "");
        stop();
      }      

      if (methodSplit == 'vfold') {
        stopifnot((ft > 0.0) && (ft < 1.0));
      }

      if (methodSplit == 'vfoldStrict') {
        ncvBuf = length(aIndexSplit);

        if (icv > ncvBuf) {
          cat("ERROR: from SuperPcCv.crossValidateCoxWithCovSingleSplit:\n");
          cat("icv = ", icv, " is greater than the number of groups to be cross-validated, ncv = ", ncvBuf, "\n", sep = "");
          stop();
        }
      }
      # ...................................................................................

      

      # ...................................................................................
      # . Generate the indices for splitting the data into training and test set.
      # .
      # . >> methodSplit = given :
      # ...................................................................................
      if (methodSplit == 'given') {
        # ......................................................................
        # . Check all given entries are 'train', 'test' or 'NONE' :
        # ......................................................................
        indexInvalid = which((af != 'train') & (af != 'test') & (af != 'NONE'));

        if (length(indexInvalid) > 0) {
          msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovSingleSplit: ";        
          msg = paste("The train/test assignment vector contains some values which are neither ", sep = "");
          msg = paste("train, test or NONE. First detected invalid value = ", af[indexInvalid[1]], sep = "");
          stop(msg);
        }
        # ......................................................................
        # . Find the indices for the training and test subsets :
        # ......................................................................
        indexTrain = which(af == 'train');
        indexTest = which(af == 'test');

        ntrain = length(indexTrain);
        ntest = length(indexTest);        
        
        if (ntrain < 2) {
          msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovSingleSplit: ";
          msg = paste("Less than 2 training set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntrain = ", ntrain, sep = "");          
          stop(msg);
        }

        if (ntest < 2) {
          msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovSingleSplit: ";
          msg = paste("Less than 2 test set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntest = ", ntest, sep = "");          
          stop(msg);
        }        
        # ......................................................................        
      }
      # ...................................................................................      
      # . >> methodSplit = vfold :
      # .    The training set and the test set must each have at least 2 elements.
      # .    Note that we require above that n >= 4, so that this is always possible.
      # ...................................................................................
      if (methodSplit == 'vfold') {
        # ......................................................................                
        ntest = floor(n * ft);
        if (ntest < 2) {
          ntest = 2;               # At least 2 elements in the test set.
        }

        n1 = n - 1;
        if (ntest >= n1) {
          ntest = n - 2;           # At least 2 elements in the training set.
        }
            
        indexTest = sample(x = 1:n, size = ntest);
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }
      # ...................................................................................      
      # . >> methodSplit = vfoldStrict :
      # . Under this option the groups were predefined before the function call,
      # . by function Stat.generateSplitsForVfold(). We just retrieve the indices.
      # ...................................................................................
      if (methodSplit == 'vfoldStrict') {
        # ......................................................................                
        indexTest = aIndexSplit[[icv]];
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }      
      # ...................................................................................      



      # ...................................................................................
      # . Generate the training and test subsets :
      # ...................................................................................
      atTrain = at[indexTrain];       # Survival times.
      asTrain = as[indexTrain];       # Censoring statuses (1 = not censored, 0 = censored).
      azTrain = az[indexTrain];       # External covariate.
      dfXTrain = dfX[indexTrain, ];   # Data matrix of gene expression values.

      atTest = at[indexTest];         # Survival times.
      asTest = as[indexTest];         # Censoring statuses (1 = not censored, 0 = censored).
      azTest = az[indexTest];         # External covariate.      
      dfXTest = dfX[indexTest, ];     # Data matrix of gene expression values.        
      # ...................................................................................


      # ...................................................................................
      # . Adjust for special cases :
      # ...................................................................................
      if (length(indexTest) == 1) {
        dfXTest = matrix(dfXTest, nrow = 1);
      }
      # ...................................................................................      

     
      
      # ....................................................................................................
      # . Column-center the training data then generate univariate Cox scores for
      # . each gene separately.
      # ....................................................................................................
      axm = colMeans(dfXTrain);                                # Save the p column means.
      dfXc = scale(dfXTrain, center = TRUE, scale = FALSE);    # Center each gene separately.

      cat(" ..........  Compute univariate Cox scores.\n");

      coxS = Cox.computeOnDataFrameSimpleBetaWithCov(atTrain,
                                                     asTrain,
                                                     azTrain,
                                                     dfXc,
                                                     flagVerbose = TRUE);  # log-likelihood score.
      
      #xxx coxS = Cox.computeOnDataFrameNoTiesParallel(atTrain, asTrain, dfXc, flagVerbose = flagVerbose);
      # .....................................................................................................


      # ..............................................................................
      cat(" ..........  Begin inner cross-validation loop, scanning parameter = ",
            parameterScan, "\n", sep = "");
      # ..............................................................................

      
      # .........................................................................
      methodFs = 'mtop'; # Hardwired, as only feature selection method used here.
      p0 = 1.0;          # Dummy value, as is ignored in feature selection.
      # .........................................................................
      
      
      # .................................................................................................
      # . CROSS-VALIDATION
      # . >> PREAMBLE :
      # . Assign the array for the parameter to be scanned.
      # .................................................................................................
      if (parameterScan == 'mtop') {
        aScan = amtop;                        # Array of parameters to be scanned.
      } else if (parameterScan == 'K') {
        aScan = aK;                           # Array of parameters to be scanned.
      }
      # .................................................................................................
      # . For parameterScan = 'K', we need to do the feature selection at the indicated mtop level
      # . only once.
      # .................................................................................................      
      if (parameterScan == 'K') {
        selFFixed = SuperPc.selectFeaturesCoxWithCov(dfXc, methodFs, p0, mtop, coxS, typePval);
      }
      # .................................................................................................
      # . >> MAIN LOOP :
      # .................................................................................................
      alAll = c();             # Log-likelihoods for entire data set.
      alTrain = c();           # Log-likelihoods for just training set.
      aR2Train = c();          # R2 on training set.
      acvPL = c();             # Cross-validated log-likelihoods.
      alRatioTest = c();       # Log-likelihood-ratio for test set on training set parameters.
      apRatioTest = c();       # P-values for log-likelihood-ratio for test set on train. set.
      aR2Test = c();           # R2 on test set.
      aMrms = c();             # r.m.s. of Martingale res. for test set on train. set parameters.

      nScan = length(aScan);   # Number of levels to be explored.
      il = 0;                  # Level counter.
        
      cat("Progress: ", sep = "");     # Progress indicator.
      t1 = proc.time()[3];              # Starting time.
       
      for (z in aScan) {
        # .......................................................................................
        # . Set the parameters :
        # .......................................................................................        
        if (parameterScan == 'mtop') {
          mtopHere = z;             # The parameter being scanned is mtop.
          KHere = K;                # K is fixed.
        } else if (parameterScan == 'K') {
          mtopHere = mtop;          # mtop is fixed.
          KHere = z;                # The parameter being scanned is K.
        }
        # .......................................................................................
        # . Perform the feature selection with the indicated method and parameters :
        # .......................................................................................
        if (parameterScan == 'mtop') {
          selF = SuperPc.selectFeaturesCoxWithCov(dfXc, methodFs, p0, mtopHere, coxS, typePval);
        } else if (parameterScan == 'K') {
          selF = selFFixed;                    # This was precomputed at the specified value of mtop.
        }
        # .......................................................................................
        # . Get the genes that were selected by the computation :
        # .......................................................................................
        agFs = colnames(selF$dfXSel);          # Genes selected by the feature selection.
        # .......................................................................................
        # . Do the svd and generate Cox proportional hazard model :
        # .......................................................................................      
        cSel = SuperPc.computeCoxOnSelectedFeaturesWithCov(atTrain, asTrain, azTrain, selF$dfXSel, KHere);
        # .......................................................................................
        # . Compute the baseline hazard functions (here using an approximation that assumes
        # . no ties) :
        # .......................................................................................
        bh = SuperPc.computeBaselineHazardNoTiesWithCov(atTrain, asTrain, azTrain, cSel, selF$dfXSel);        
        # .......................................................................................
        # . Package all the results into a single spc.cox object :
        # .......................................................................................
        spcTrain = SuperPc.packageSpcCoxWithCov(methodFs = methodFs,
                                                mtop = mtopHere,
                                                p0 = p0,
                                                n = n, p = p,
                                                axm = axm,
                                                indexSel = selF$indexSel,
                                                agFs = agFs,
                                                m = selF$m,
                                                pvalMin = selF$pvalMin, pvalMax = selF$pvalMax,
                                                K = KHere,
                                                abeta = cSel$abeta,        
                                                aseBeta = cSel$aseBeta,    
                                                apBeta= cSel$apBeta,       
                                                betaZ = cSel$betaZ,        
                                                seBetaZ = cSel$seBetaZ,    
                                                pBetaZ = cSel$pBetaZ,      
                                                agamma = cSel$agamma,      
                                                aseGamma = cSel$aseGamma,  
                                                apGamma = cSel$apGamma,    
                                                qR = cSel$qR, pR = cSel$pR,
                                                avSel = cSel$avSel,
                                                av = NULL,                  # Not required for log-likelihood.
                                                avSelTot = cSel$avSelTot,
                                                avTot = NULL,               # Not required for log-likelihood.
                                                sv = cSel$sv, coxK = cSel$coxK,
                                                bh = bh);        
        # .......................................................................................
        # . i. Estimate the log partial likelihood for *all* samples, using the coefficients 
        # .    derived only from the training set.
        # .......................................................................................
        llBuf = SuperPc.computeCoxLogLikelihoodWithCov(spcTrain,
                                                       atIn = at,
                                                       asIn = as,
                                                       azIn = az,          
                                                       dfXIn = dfX);
        lOutAll = llBuf$lOut;
        # .......................................................................................
        # . ii. Estimate the log partial likelihood for only *training set* samples, using the 
        # .     coefficients derived only from the training set.
        # .......................................................................................
        llBuf = SuperPc.computeCoxLogLikelihoodWithCov(spcTrain,
                                                       atIn = atTrain,
                                                       asIn = asTrain,
                                                       azIn = azTrain,          
                                                       dfXIn = dfXTrain);
        lOutTrain = llBuf$lOut;
        lRatioTrain = llBuf$lRatio;                       # Log-likelkihood ratio on training set.
        R2Train = 1.0 - exp(- lRatioTrain / ntrain);      # R2 for training set.
        # .......................................................................................
        # . Compute the cross-validated log partial likelihood (CVPL) :
        # .......................................................................................        
        cvPL = lOutAll - lOutTrain;
        # .......................................................................................
        # . Compute a log likelihood ratio for the test set on its own, using the
        # . model derived from the training set :
        # .......................................................................................
        llBuf = SuperPc.computeCoxLogLikelihoodWithCov(spcTrain,
                                                       atIn = atTest,
                                                       asIn = asTest,
                                                       azIn = azTest,
                                                       dfXIn = dfXTest);
        lRatioTest = llBuf$lRatio;
        lTemp = max(lRatioTest, 0.0);                                # As lRatioTest need not always be non-negative.
        K21 = 2 * KHere + 1;                                         # Degrees of freedom.
        pRatioTest = pchisq(lTemp, df = K21, lower.tail = FALSE);    # p-value from likelihood ratio.

        R2Test = 1.0 - exp(- lTemp / ntest);                         # R2 for test set, with lTemp floored at 0.
        # .......................................................................................
        # . Compute the Martingale residuals for the test set, on the basis of the parameters
        # . estimated from the training set :
        # .......................................................................................
        slTest = SuperPc.computeCoxPcAndLogHazardWithCov(spcTrain,
                                                         dfXIn = dfXTest,
                                                         azIn = azTest);
        ahRTest = slTest$ahR;                                        # Test set values of exp(beta * Y).
        
        mr = SuperPc.computeMartingaleResiduals(spcTrain = spcTrain,
                                                atIn = atTest,
                                                asIn = asTest,
                                                ahRIn = ahRTest);
        Mrms = mr$Mrms;
        # .......................................................................................
        # . >> FOR TWO-ARMED STUDIES :
        # . Additional predictions, predicated on all z = 0, or all z = 1, for the same
        # . gene expression data.
        # . Note that this is relevant only for two-armed studies, coded as z = 0 or 1.
        # .......................................................................................
        azIn0 = rep(0, times = length(azTest));  # All z = 0.
        azIn1 = rep(1, times = length(azTest));  # All z = 1.

        slTest0 = SuperPc.computeCoxPcAndLogHazardWithCov(spcTrain,
                                                          dfXIn = dfXTest,
                                                          azIn = azIn0);        

        slTest1 = SuperPc.computeCoxPcAndLogHazardWithCov(spcTrain,
                                                          dfXIn = dfXTest,
                                                          azIn = azIn1);                
        # .......................................................................................
        # . Generate the columns of the matrix of log-hazard-ratios
        # . [samples * feature-selection levels] for the test samples, for this given split.
        # . The final matrix will have dimensions ntest * nScan.
        # .......................................................................................
        if (il == 0) {
          aloghRBIG = matrix(slTest$aloghR, nrow = length(slTest$aloghR));       # The first column.
          aloghRBIG0 = matrix(slTest0$aloghR, nrow = length(slTest0$aloghR));    # The first column.
          aloghRBIG1 = matrix(slTest1$aloghR, nrow = length(slTest1$aloghR));    # The first column.
        } else {
          aloghRBIG = cbind(aloghRBIG, slTest$aloghR);                           # Subsequent columns.
          aloghRBIG0 = cbind(aloghRBIG0, slTest0$aloghR)                         # Subsequent columns.
          aloghRBIG1 = cbind(aloghRBIG1, slTest1$aloghR)                         # Subsequent columns.          
        }        
        # .......................................................................................
        # . Update arrays :
        # .......................................................................................
        alAll = c(alAll, lOutAll);
        alTrain = c(alTrain, lOutTrain);             # Log-likelihood on training set only.
        aR2Train = c(aR2Train, R2Train);             # R2 for training set.
        acvPL = c(acvPL, cvPL);                      # Cross-validated log-likelihood.
        alRatioTest = c(alRatioTest, lRatioTest);    # Log-likelihood ratio for test set.
        apRatioTest = c(apRatioTest, pRatioTest);    # p-value for test set fitted by training set coefficients.
        aR2Test = c(aR2Test, R2Test);                # R2 for test set fitted by training set coefficients.
        aMrms = c(aMrms, Mrms);                      # Martingale residuals for the test set.

        cat(".", sep = "");                          # Progress indicator.

        il = il + 1;
        if (il%%20 == 0) {
          cat(" : processed ", il, " levels out of ", nScan, ".\n", sep = "");
          cat("          ", sep = "");            # Spacer for next row of dots indicating progress.
        }
        # .......................................................................................          
      }
      # .......................................................................................
      # . Summarize times :
      # .......................................................................................        
      cat("\n", sep = "");

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / nScan;                                 # Time per parameter value.

      if (flagVerbose) {
        cat(" ..........  Inner cross-validation loop done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per ", parameterScan, " value.\n");
      }
      # .............................................................................................

      

      # .............................................................................................
      # . Package results :
      # .............................................................................................
      cv = list(parameterScan = parameterScan,
                methodSplit = methodSplit,
                mtop = mtop,
                K = K,        
                nScan = nScan,
                amtop = amtop,
                aK = aK,
                typePval = typePval,
                n = n,
                ntrain = ntrain,
                ntest = ntest,
                alAll = alAll,
                alTrain = alTrain,
                aR2Train = aR2Train,
                acvPL = acvPL,
                alRatioTest = alRatioTest,
                apRatioTest = apRatioTest,
                aR2Test = aR2Test,
                aMrms = aMrms,
                indexTest = indexTest,
                aloghRBIG = aloghRBIG,
                aloghRBIG0 = aloghRBIG0,
                aloghRBIG1 = aloghRBIG1,
                agFs = spcTrain$agFs        # Genes selected by feature selection on last feature selection level explored.
               );                

      class(cv) = 'spc.cox.cv.single';
      # .............................................................................................      



      # .............
      return (cv);
      # .............
      
}

# =================================================================================================
# . End of SuperPcCv.crossValidateCoxWithCovSingleSplit.
# =================================================================================================









# =====================================================================================================================
# . SuperPcCv.crossValidateCoxWithCovBoot : bootstrap of cross-validation of the Cox proportional hazard model over 
# . ------------------------------------    multiple splits of the data into training and test sets.
# .                                         This version is with an external covariate.
# .                                     
# .                              
# .
# .   Syntax:
# .
# .           cv =  SuperPcCv.crossValidateCoxWithCovBoot(at, as, az, dfX,
# .                                                       ft,
# .                                                       rngSeed,
# .                                                       bootType,
# .                                                       nboot,
# .                                                       mtop, K, typePval,
# .                                                       flaghRCOpt, hRC,
# .                                                       flagVerbose)
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfoldStrict'. Allowed: 0 < ft < 1.
# .
# .       rngSeed = initial random number seed. Must be integer > 0.
# .
# .     >> Bootstrap parameters :
# .
# .       bootType = type of resampling to be done in the outer loop.
# .                  Two types are valid : fullBoot, splitOnly       
# .                
# .                           fullBoot : do full bootstrap resampling. Resample 
# .                                      with replacement the training set      
# .                                      members, then do the indicated cross-  
# .                                      validation. Note that with this option 
# .                                      splits necessarily are different for   
# .                                      resampling.                            
# .     
# .                           splitOnly : only the splits deining the folds are 
# .                                       randomly changed for each outer loop  
# .                                       sampling. The overall training set    
# .                                       itself is unchanged.
# .
# .                         permutation : permute the gene expression profiles
# .                                       with respect to the survival data
# .                                       and external covariate (i.e. (t, s, z)
# .                                       are kept in synch with each other, and 
# .                                       x randomly permuted).
# .     
# .          nboot = number of bootstrap resamplings to be applied.
# .
# .     >> Cox-model parameters :
# .
# .          mtop = for each split keep the mtop genes with most 
# .                 significant Cox scores (i.e. those with the mtop smallest P-values).
# .
# .             K = number of principal components.
# .
# .      typePval = type of the P-value that is to be used for the 
# .                 feature selection. Allowed options:
# . 
# .                    'model' = P-value for overall model fitness (log-likelihood-ratio).
# .                        'X' = P-value for gene effects.
# .                        'Z' = P-value for treatment effects.
# .                       'ZX' = P-value for interaction effects.
# .
# .     >> Decision boundary :
# .
# .        flaghRCOpt = flag defining where the hRC threshold value used comes from.
# .                     Allowed values :
# .
# .                     -   'no' : use input value hRC given below.
# .                     -  'yes' : use value which maximizes significance of separation of treatment
# .                                arms for sensitives.
# .
# .               hRC = decision threshold. Used if fflaghRCOpt = 'no', ignored if flaghRCOpt = 'yes'.
# .
# .                      Note that DloghR <= log(hRC) defines sensitive samples, DloghR >= log(hRC)
# .                      defines resistant samples.
# .
# .
# .   flagVerbose = if TRUE, prints progress on computation in the innner cross-validation loop.
# .
# .
# .   Out:
# .    cv = list, with members defined in packaging at end of function body.
# .
# =====================================================================================================================

SuperPcCv.crossValidateCoxWithCovBoot  <- function(at, as, az, dfX,
                                                   ft, rngSeed, 
                                                   bootType, nboot,
                                                   mtop, K, typePval,
                                                   flaghRCOpt,
                                                   hRC,
                                                   flagVerbose)
{

      # ...........................................................................
      cat(" ..........  Entry in SuperPcCv.crossValidateCoxWithCovBoot.\n");
      # ...........................................................................


      
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      nt = length(at);   # Number of samples in survival time vector.
      ns = length(as);   # Number of samples in censoring status vector.
      nz = length(az);   # Number of samples in external covariate vector.            

      if (nt != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovBoot: ";
        msg = paste("The survival time vector at has nt = ", nt, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovBoot: ";        
        msg = paste("The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovBoot: ";                
        msg = paste("The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n,
                    "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      
      if (n < 4) {
        msg = "ERROR: from SuperPcCv.crossValidateCoxWithCovBoot: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((bootType == 'fullBoot')
                || (bootType == 'splitOnly')
                || (bootType == 'permutation'));
      
      stopifnot(mtop > 0);
      stopifnot(mtop <= p);

      allowedTypePval = list(model = 1, X = 1, Z = 1, ZX = 1);
      
      if (is.null(allowedTypePval[[typePval]])) {
        cat("ERROR: from SuperPcCv.crossValidateCoxWithCovBoot:\n");
        cat("typePval = ", typePval, " is not valid.\n", sep = "");
        cat("Valid: model, X, Z, ZX.\n", sep = "");
        stop();
      }        

      stopifnot(rngSeed > 0);
      stopifnot(nboot > 0);      

      stopifnot((flaghRCOpt == 'yes') || (flaghRCOpt == 'no'));      
      stopifnot(hRC > 0);      
      # ...................................................................................


      
      # .......................................................................................
      # . Check on the external covariate :
      # . >>CURRENT restriction to binary (0, 1) values for the external covariate:
      # . Note that this applies only to the cross-validation program, and not to the
      # . feature selection or model building cases.
      # .......................................................................................    
      msgBin = Cox.checkBinary(az);

      if (msgBin != 'ok') {
        cat("ERROR: from SuperPcCv.crossValidateCoxWithCovBoot:\n");
        cat("External covariate values must all be {0, 1}\n");
        cat(msgBin);
        cat("\n");
        stop();
      }
      # .......................................................................................



      # ...............................................................................
      # . Set fixed defaults to be used inside the bootstrap loop :
      # ...............................................................................
      cvType = 'single';
      methodSplit = 'vfoldStrict';
      af = rep('NONE', times = length(at));           # Dummy.

      set.seed(rngSeed);  # Actually (re)set in the calculation on the non-resampled data.      
      # ...............................................................................
        


      # ......................................................................................................
      # . Do a one-time cross-validation on the non-resampled data :
      # ......................................................................................................            
      cat(" ..........  Do one-time cross-validation on the actual (non-resampled) data set.\n", sep = "");

      cv = SuperPcCv.crossValidateCoxWithCov(at = at,
                                             as = as,
                                             az = az,          
                                             dfX = dfX,
                                             methodSplit = 'vfoldStrict',          # Frozen to 'vfoldStrict'.
                                             af = af,                              # Not used, as methodSplit = 'vfoldStrict'.
                                             ft = ft,
                                             rngSeed = rngSeed,                    # Not used in call, as flagRngSeed = FALSE.
                                             flagRngSeed = TRUE,                   # Initializes the random number seed.
                                             mtop = mtop,
                                             K = K,
                                             parameterScan = 'mtop',
                                             amtop = c(mtop),
                                             aK = c(K),
                                             typePval = typePval,          
                                             flagVerbose = TRUE);
      # ......................................................................................................
      # . Gather statistics for this resampling step :
      # ......................................................................................................
      sumCObs = SuperPc.summarizeCoxWithCovOnSplit(cv$aDloghRSortBIG[ , 1],
                                                   cv$ahRSortBIG[ , 1],
                                                   cv$apRSortBIG[ , 1],                                               
                                                   cv$ahRSortRESBIG[ , 1],
                                                   cv$apRSortRESBIG[ , 1],
                                                   hRCIn = hRC,
                                                   flaghRCOpt = flaghRCOpt);        
      # .......................................................................................................

      


      
        
      # ..................................................................................................................
      # . MAIN RESAMPLING LOOP :
      # ..................................................................................................................
      index0 = 1:n;                # Fixed index for resampling.
      asumC = list();              # This will contain the results from the resampling runs.
      
      cat(" ..........  Begin the resampling loop.\n", sep = "");
      cat(" ..........  Resampling type : ", bootType, "\n", sep = "");
      
      t1 = proc.time()[3];              # Starting time.
      
      for (l in 1:nboot) {
        cat(">>##############################################################\n");
        cat(">>Bootstrap resampling step ", l, " out of ", nboot, "\n", sep = "");
        cat(">>##############################################################\n");        
        # ......................................................................................
        # . >>FULL BOOTSTRAP: resample with replacement. All features remain together.
        # . We are simulating a new data set from the same distribution as the input data set.
        # ......................................................................................
        if (bootType == 'fullBoot') {
          indexBuf = sample(index0, replace = TRUE);   # Sampling with replacement.
          
          atBuf = at[indexBuf];
          asBuf = as[indexBuf];
          azBuf = az[indexBuf];

          dfXBuf = dfX[indexBuf, ];

        }
        # ......................................................................................        
        # . >>RESAMPLE SPLITS ONLY : we are gauging only the effects of generating variable
        # . fold selections in the internal cross-validation. The training set remains
        # . untouched.
        # ......................................................................................
        if (bootType == 'splitOnly') {
          atBuf = at;
          asBuf = as;
          azBuf = az;

          dfXBuf = dfX;
        }
        # ......................................................................................
        # . >>PERMUTATION:  shuffle gene expression profiles
        # . but keep survival and external co-variate in-place.
        # . We are simulating a data set under the null hypothesis of no association between
        # . survival and gene-expression.
        # ......................................................................................
        if (bootType == 'permutation') {
          indexBuf = sample(index0);                    # Permutation.
          
          atBuf = at;                                   # These stay in place.
          asBuf = as;                                   # These stay in place.
          azBuf = az;                                   # These stay in place.

          dfXBuf = dfX[indexBuf, ];                     # Shuffle gene expression profiles.
        }        
        # ......................................................................................
        # . The innner cross-validation is done here :
        # ......................................................................................                
        cv = SuperPcCv.crossValidateCoxWithCov(at = atBuf,
                                               as = asBuf,
                                               az = azBuf,          
                                               dfX = dfXBuf,
                                               methodSplit = 'vfoldStrict',          # Frozen to 'vfoldStrict'.
                                               af = af,                              # Not used, as methodSplit = 'vfoldStrict'.
                                               ft = ft,
                                               rngSeed = rngSeed,                    # Not used in call, as flagRngSeed = FALSE.
                                               flagRngSeed = FALSE,                  # Frozen to FALSE.
                                               mtop = mtop,
                                               K = K,
                                               parameterScan = 'mtop',
                                               amtop = c(mtop),
                                               aK = c(K),          
                                               typePval = typePval,          
                                               flagVerbose = TRUE);
        # ......................................................................................
        # . Gather statistics for this resampling step :
        # ......................................................................................
        sumC = SuperPc.summarizeCoxWithCovOnSplit(cv$aDloghRSortBIG[ , 1],
                                                  cv$ahRSortBIG[ , 1],
                                                  cv$apRSortBIG[ , 1],                                               
                                                  cv$ahRSortRESBIG[ , 1],
                                                  cv$apRSortRESBIG[ , 1],
                                                  hRCIn = hRC,
                                                  flaghRCOpt = flaghRCOpt);                  

        asumC[[l]] = sumC;
        # ......................................................................................        
      }

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / nboot;                                 # Time per resampling.

      cat(" ..........  Bootstrap loop done. Total time = ", t2, " s.", sep = "");
      cat(" Time = ", tau, " s per resampling.\n");            
      # ..................................................................................................................


      

      # ........................................................................................
      # . Package results :
      # ........................................................................................
      cvBoot = list(n = n,                       # Number of samples.
                    bootType = bootType,         # Type of resampling done.
                    nboot = nboot,               # Number of resamplings.
                    rngSeed = rngSeed,           # Random number seed.
                    hRC = hRC,                   # Hazard ratio threshold for S and R calls.
                    sumCObs = sumCObs,           # Statistical summary for actual training set.
                    asumC = asumC);              # List contains series of summaries generated by resamplings.
            
      class(cvBoot) = 'glmnet.cox.cov.cv.boot';
      # ........................................................................................      

      

      # ................................................................
      cat(" ..........  Exit SuperPcCv.crossValidateCoxWithCovBoot.\n");
      # ................................................................

      
      
      # ...............
      return (cvBoot);
      # ...............

}

# =====================================================================================================================
# . End of  SuperPcCv.crossValidateCoxWithCovBoot.
# =====================================================================================================================






# =================================================================================================
# . SuperPcCv.generatePermutedCoxWithCov : runs the cross-validation function 
# . ------------------------------------   SuperPcCv.crossValidateCoxWithCov() on permuted samples
# .                                        of the data matrix, and builds baseline statistics for
# .                                        evaluating the significance of the actual cross-validated
# .                                        metrics.
# .
# .   Syntax:
# .
# .            cv =  SuperPcCv.generatePermutedCoxWithCov(at, as, az, dfX,
# .                                                       methodSplit,
# .                                                       af, ft, ncv,
# .                                                       mtop, K,
# .                                                       parameterScan,
# .                                                       amtop, aK,
# .                                                       nperm);
# .
# .   The input parameters {at, as, . . . , aK} are the same as in function
# .   SuperPcCv.crossValidateCoxWithCov(). The additional parameter nperm specifies the
# .   number of permutations to be generated.
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector for external covariate.
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid). Note that only ONE split is ever
# .                               generated.
# .
# .                   - 'vfold' : use parameter ft (below) to do a vfold
# .                               split of the data matrix. Generate ncv
# .                               independent splits of the data matrix.
# .
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, for methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfold'. Allowed: 0 < ft < 1.
# .
# .           ncv = number of independent splots generated, under method 'vfold'.
# .
# .     >> Fixed-values parameters:
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values). Used only if
# .                 parameterScan = 'K'.
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .                 Used only if parameterScan = 'mtop'.
# .
# .
# .   parameterScan = which parameter to scan in doing the cross-validation on this split of
# .                the data. Allowed values:
# .
# .                   - 'mtop' : do the cross-validation for the values of mtop
# .                              in the input array amtop.
# .                              The input values of the fixed-value parameters mtop
# .                              and p0 are ignored.
# .                              All calculations are done at the fixed value of K.
# .
# .                   - 'K' :    do the cross-validation for the values of K
# .                              in the input array aK.
# .                              The input value of the fixed-value parameter K
# .                              is ignored.
# .                              All calculations are done at the fixed values of
# .                              mtop or p0 (whichever applies under selected
# .                              methodFs).
# .
# .     >> Arrays of parameters for cross-validation:
# .
# .         amtop = array of values of mtop. Keep the mtop genes
# .                 with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .            aK = array of number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .     >> Number of permutations :
# .
# .         nperm = number of random sample permutations. Each permutation is applied to
# .                 the gene expression data matrix, while the companion input arrays
# .                 for survival time and covariate, at, as, and az ar not tranformed.
# .
# .   Out:
# .    cvRand = list, with members :
# .
# .
# =================================================================================================

SuperPcCv.generatePermutedCoxWithCov  <- function(at, as, az, dfX,
                                                  methodSplit,
                                                  af, ft, ncv, rngSeed,
                                                  mtop, K,
                                                  parameterScan,
                                                  amtop, aK,
                                                  nperm)
{

      # ......................................................................
      cat(" ..........  Entry in SuperPcCv.generatePermutedCoxWithCov.\n");
      # ......................................................................


      # ........................
      stopifnot(nperm > 0);
      # ........................


      # ......................................................................................
      cat(" ..........  Generate random permutations of data matrix.\n");
      cat(" ..........  Cross-validation with split method = ", methodSplit, "\n", sep = "");
      cat(" ..........  Parameter scanned = ", parameterScan, "\n", sep = "");
      # ......................................................................................



      # ................................................................................................
      # . The main loop is here :
      # ................................................................................................
      n = nrow(dfX);                               # Number of samples to be permuted.
      
      for (iperm in 1:nperm) {
        cat(">>******************************************************************\n", sep = "");        
        cat(">>Generate permutation ", iperm, " out of ", nperm, "\n", sep = "");
        
        indexPerm = sample(x = 1:n, size = n);     # Random permutation.
        dfXPerm = dfX[indexPerm, ];                # Permute the rows of the gene expression data matrix.

        cvBuf = SuperPcCv.crossValidateCoxWithCov(at = at,
                                                  as = as,
                                                  az = az,
                                                  dfX = dfXPerm,
                                                  methodSplit = methodSplit,
                                                  af = af,
                                                  ft = ft,
                                                  ncv = ncv,
                                                  rngSeed = rngSeed,
                                                  flagRngSeed = FALSE,          
                                                  mtop = mtop,
                                                  K = K,
                                                  parameterScan = parameterScan,
                                                  amtop = amtop,
                                                  aK = aK,
                                                  flagVerbose = TRUE);
        # .....................................................................................
        # . Package intermediate results :
        # .....................................................................................
        if (iperm == 1) {
          dlRatioTestMedian = as.data.frame(matrix(cvBuf$alRatioTestMedian, nrow = 1));
          dR2TestMedian = as.data.frame(matrix(cvBuf$aR2TestMedian, nrow = 1));                    
        } else {
          dlRatioTestMedian = rbind(dlRatioTestMedian, cvBuf$alRatioTestMedian);
          dR2TestMedian = rbind(dR2TestMedian, cvBuf$aR2TestMedian);          
        }
        # .....................................................................................
      }

      cat(">>******************************************************************\n", sep = "");               
      # ...........................................................................................



      # ...........................................................
      # . Package results :
      # ...........................................................
      cvRand = list(parameterScan = parameterScan,
                    methodSplit = methodSplit,
                    ft = ft,
                    ncv = ncv,
                    rngSeed = rngSeed,
                    K = K,
                    mtop = mtop,
                    nScan = cvBuf$nScan,
                    amtop = amtop,
                    aK = aK,
                    n = n,
                    ntrain = cvBuf$ntrain,
                    ntest = cvBuf$ntest,
                    p = cvBuf$p,
                    dlRatioTestMedian = dlRatioTestMedian,
                    dR2TestMedian = dR2TestMedian);

      class(cvRand) = 'spc.cox.cv.rand';
      # ...........................................................

      

      # .................................................................
      cat(" ..........  Exit SuperPcCv.generatePermutedCoxWithCov.\n");
      # .................................................................

      
      
      # .............
      return (cvRand);
      # .............
      
}

# =================================================================================================
# . End fo SuperPcCv.generatePermutedCoxWithCov.
# =================================================================================================





# =================================================================================================
# . SuperPcCv.crossValidateRegress : cross-validation of the regression model over 
# . ------------------------------   multiple splits of the data into training and test sets,
# .                                  with exploration of a range of model parameters.
# .                              
# .
# .   Syntax:
# .
# .            cv =  SuperPcCv.crossValidateRegress(ay, dfX,
# .                                                 modelType,
# .                                                 methodSplit,
# .                                                 af, ft, ncv, rngSeed,
# .                                                 mtop, K,
# .                                                 parameterScan,
# .                                                 amtop, aK,
# .                                                 flagVerbose)
# .
# .   In:
# .            ay = n : vector of output values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     modelType = type of regression model to be used :
# .                 Allowed values : 
# .                  - 'lm' : linear model.
# .                  - 'logistic' : logistic distribution. 
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid). Note that only ONE split is ever
# .                               generated.
# .
# .                   - 'vfold' : use parameter ft (below) to do a vfold
# .                               split of the data matrix. Generate ncv
# .                               independent splits of the data matrix.
# .
# .             - 'vfoldStrict' : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, for methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, for
# .                 methodSplit = 'vfold'. Allowed: 0 < ft < 1.
# .
# .           ncv = number of independent splots generated, under method 'vfold'.
# .
# .     >> Fixed-values parameters:
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values). Used only if
# .                 parameterScan = 'K'.
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .                 Used only if parameterScan = 'mtop'.
# .
# .
# .   parameterScan = which parameter to scan in doing the cross-validation on this split of
# .                the data. Allowed values:
# .
# .                   - 'mtop' : do the cross-validation for the values of mtop
# .                              in the input array amtop.
# .                              The input values of the fixed-value parameters mtop
# .                              and p0 are ignored.
# .                              All calculations are done at the fixed value of K.
# .
# .                   - 'K' :    do the cross-validation for the values of K
# .                              in the input array aK.
# .                              The input value of the fixed-value parameter K
# .                              is ignored.
# .                              All calculations are done at the fixed values of
# .                              mtop or p0 (whichever applies under selected
# .                              methodFs).
# .
# .     >> Arrays of parameters for cross-validation:
# .
# .         amtop = array of values of mtop. Keep the mtop genes
# .                 with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .            aK = array of number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .   flagVerbose = if TRUE, prints progress on computation in the innner cross-validation loop.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .           modelType = type of regression model.
# .       parameterScan = parameter that was scanned (mtop or K).
# .               nscan = number of discrete parameter values used.
# .               amtop = array of the nscan mtop values (for parameterScan = mtop).
# .                  aK = array of nscan K values (for parameterScan = K).
# .
# .            aRrmsQ25 = First quartile for r.m.s. of residuals of test set on training set.
# .         aRrmsMedian = Median Rrms.
# .            aRrmsQ75 =  Third quartile Rrms.
# .       aRrmsSigmaMad =  MAD std. deviation Rrms.
# .
# .            aepsR2Q25 = First quartile epsR2.
# .         aepsR2Median = Median epsR2.
# .           aepsR2Q75  = Third quartile epsR2.
# .      aepsR2SigmaMad  = MAD std. deviation epsR2.
# .
# .         amlog10pRQ25 = First quartile mlog10pR.
# .      amlog10pRMedian = Median mlog10pR.
# .         amlog10pRQ75 = Third quartile mlog10pR.
# .    amlog10pRSigmaMad = MAD std. deviation mlog10pR.
# .
# =================================================================================================

SuperPcCv.crossValidateRegress  <- function(ay, dfX,
                                            modelType,
                                            methodSplit,
                                            af, ft, ncv, rngSeed,
                                            mtop, K,
                                            parameterScan,
                                            amtop, aK,
                                            flagVerbose)
{

      # ...........................................................................
      cat(" ..........  Entry in SuperPcCv.crossValidateRegress.\n");
      # ...........................................................................


      
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);                   # Number of samples in data matrix.
      p = ncol(dfX);
      arowName = rownames(dfX);        # Array of row names.
      
      ny = length(ay);   # Number of samples in output variable vector.
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (ny != n) {
        msg = "ERROR: from SuperPcCv.crossValidateRegress: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      

      if (nf != n) {
        msg = "ERROR: from SuperPcCv.crossValidateRegress: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from SuperPcCv.crossValidateRegress: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((modelType == 'lm') || (modelType == 'logistic'));
      stopifnot((methodSplit == 'given')
                || (methodSplit == 'vfoldStrict'));      # methodSplit is obsolete.
      
      stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));

      if (parameterScan == 'mtop') {
        stopifnot(K >= 1);
        stopifnot(length(amtop) > 0);        
      } else if (parameterScan == 'K') {
        stopifnot(mtop >= 1);
        stopifnot(length(aK) > 0);        
      }

      if (methodSplit == 'vfoldStrict') {
        #xxx stopifnot(ncv >= 1);      
        stopifnot((ft > 0.0) && (ft < 1.0));
      }

      stopifnot(rngSeed > 0);
      # ...................................................................................


      # .........................................
      # . Initialize random number generator :
      # .........................................      
      set.seed(rngSeed);                  
      # .........................................
      

      # ....................................................................................................
      cat(" ..........  Begin outer cross-validation loop, parameter scanned = ", parameterScan, "\n", sep = "");
      # ....................................................................................................



      # ....................................................................................................
      # . >>CROSS-VALIDATION :
      # . Generate ncv independent splits of the data, and compute log-likelihoods for the designated
      # . range of the chosen parameter.
      # .
      # . >>PREAMBLE :
      # ....................................................................................................
      if (methodSplit == 'given') {
        ncvHere = 1;                        # We are using only the designated split in the data.
        aIndexSplit = NULL;                 # Will not be needed.        
      } else if (methodSplit == 'vfold') {
        ncvHere = ncv;                      # Generate all ncv independent samplings.
        aIndexSplit = NULL;                 # Will not be needed.                
      } else if (methodSplit == 'vfoldStrict') {
        cSplit = Stat.generateSplitsForVfold(n = n, ft = ft, flagRandom = TRUE);  # Generate truly disjoint groups.
        ncvHere = cSplit$ncv;
        aIndexSplit = cSplit$aIndexSplit;
      }      
      # ....................................................................................................
      # . Begin cross-validation below :
      # ....................................................................................................      
      cat(" ..........  Total number of steps: ncvHere = ", ncvHere, "\n", sep = "");
      cat(" ..........  Start loop.\n", sep = "");            
      # ....................................................................................................
      # . >> MAIN LOOP :
      # ....................................................................................................
      t1 = proc.time()[3];              # Starting time.
      
      for (icv in 1:ncvHere) {
        cat("Start step = ", icv, " out of ", ncvHere, "\n", sep = "");
        
        ta = proc.time()[3];
        cvS =  SuperPcCv.crossValidateRegressSingleSplit(ay = ay,
                                                         dfX = dfX,
                                                         modelType = modelType,
                                                         methodSplit = methodSplit,
                                                         af = af,
                                                         ft = ft,
                                                         mtop = mtop,
                                                         K = K,
                                                         parameterScan = parameterScan,
                                                         amtop = amtop,
                                                         aK = aK,
                                                         icv = icv,
                                                         aIndexSplit = aIndexSplit,          
                                                         flagVerbose = flagVerbose);
        tb = proc.time()[3] - ta;
        cat("Processed step = ", icv, " out of ", ncvHere, ", time = ", tb, " s.\n", sep = "");
        # .....................................................................................
        # . Package intermediate results :
        # .....................................................................................
        if (icv == 1) {
          dRrms = as.data.frame(matrix(cvS$aRrms, nrow = 1));
          depsR2 = as.data.frame(matrix(cvS$aepsR2, nrow = 1));
          dpR = as.data.frame(matrix(cvS$apR, nrow = 1));

          axiBIG = cvS$axiBIG;
          ayPredBIG = cvS$ayPredBIG;
          aPyPredBIG = cvS$aPyPredBIG;          
          indexTestBIG = cvS$indexTest;          
        } else {
          dRrms = rbind(dRrms, cvS$aRrms);
          depsR2 = rbind(depsR2, cvS$aepsR2);
          dpR = rbind(dpR, cvS$apR);

          axiBIG = rbind(axiBIG, cvS$axiBIG);                # Stack rows.          
          ayPredBIG = rbind(ayPredBIG, cvS$ayPredBIG);       # Stack rows.
          aPyPredBIG = rbind(aPyPredBIG, cvS$aPyPredBIG);    # Stack rows.          
          indexTestBIG = c(indexTestBIG, cvS$indexTest);     # Add to end.                    
        }

        ntrain = cvS$ntrain;      # These will be the same 
        ntest = cvS$ntest;        # for each resampling.
        # .....................................................................................   
      }
      # ..................................................................................
      # . Now that all the collected test-sets log-hazard-ratios have been assembled,
      # . restore the original order of sample indices.
      # .
      # . Note that for methodSplit = 'given', not all samples will have been recycled 
      # . as on-the-fly test samples, and matrix ayPredBIG will have rows that are
      # . all-NAs.
      # ..................................................................................
      arHOLD = rownames(ayPredBIG);                  # Hold the test sample names here.

      axiBuf = matrix(NA, nrow = n, ncol = ncol(axiBIG));
      axiBuf[indexTestBIG, ] = axiBIG;               # Assign numerical values.
      axiBIG = axiBuf;
      
      ayBuf = matrix(NA, nrow = n, ncol = ncol(ayPredBIG));
      ayBuf[indexTestBIG, ] = ayPredBIG;             # Assign numerical values.
      ayPredBIG = ayBuf;

      aPyBuf = matrix(NA, nrow = n, ncol = ncol(aPyPredBIG));
      aPyBuf[indexTestBIG, ] = aPyPredBIG;           # Assign numerical values.
      aPyPredBIG = aPyBuf;

      arBuf = rep(NA, times = n);
      arBuf[indexTestBIG] = arHOLD;                  # Unpermute the row names.

      rownames(axiBIG) = arBuf;                      # Assign the unpermuted row names.      
      rownames(ayPredBIG) = arBuf;                   # Assign the unpermuted row names.
      rownames(aPyPredBIG) = arBuf;                  # Assign the unpermuted row names.      
      # ..................................................................................
      # . The outer cross-validation loop is done :
      # ..................................................................................
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / ncvHere;                               # Time per split.

      cat(" ..........  Outer cross-validation loop done. Total time = ", t2, " s.", sep = "");
      cat(" Time = ", tau, " s per step.\n");      
      # ....................................................................................................      




      # ....................................................................................................
      # . Generate summary stats.
      # . >>r.m.s residuals:
      # . Note that all these statistics on individual test sets are somewhat obsolete, and are
      # . meaningful only for the linear regression model (modelType = 'lm').
      # . For logistic regression, all values are dummy values.
      # . See below for the 'true' statistics generated on the collected cross-validated predictions.
      # ....................................................................................................
      aRrmsQ25 = apply(dRrms, 2, quantile, probs = 0.25);  # First quartile for r.m.s. of res.
      aRrmsMedian = apply(dRrms, 2, median);               # Median Rrms.
      aRrmsQ75 = apply(dRrms, 2, quantile, probs = 0.75);  # Third quartile Rrms.
      aRrmsSigmaMad = apply(dRrms, 2, mad);                # MAD std. deviation Rrms.
      # ....................................................................................................
      # . >>relative error squared:
      # ....................................................................................................
      aepsR2Q25 = apply(depsR2, 2, quantile, probs = 0.25);  # First quartile epsR2.
      aepsR2Median = apply(depsR2, 2, median);               # Median epsR2.
      aepsR2Q75 = apply(depsR2, 2, quantile, probs = 0.75);  # Third quartile epsR2.
      aepsR2SigmaMad = apply(depsR2, 2, mad);                # MAD std. deviation epsR2.
      # ....................................................................................................
      # . >>model P-values :
      # . First transform P-values into xi = -log10(P), the compute quantiles :
      # ....................................................................................................
      if (nrow(dpR) > 1) {
        dmlog10pR = apply(dpR, 2, Stat.getMlog10);
      } else {
        pBuf = dpR[1, ];
        dmlog10pR = ifelse(pBuf > 0.0, - log(pBuf, base = 10.0), 20.0);   # 20 is a standin for - log10(0).
        dmlog10pR = as.data.frame(dmlog10pR);                             # Convert to data frame.
      }

      amlog10pRQ25 = apply(dmlog10pR, 2, quantile, probs = 0.25);  # First quartile mlog10pR.
      amlog10pRMedian = apply(dmlog10pR, 2, median);               # Median mlog10pR.
      amlog10pRQ75 = apply(dmlog10pR, 2, quantile, probs = 0.75);  # Third quartile mlog10pR.
      amlog10pRSigmaMad = apply(dmlog10pR, 2, mad);                # MAD std. deviation mlog10pR.
      # ....................................................................................................



      # ....................................................................................................
      # . Generate single vectors of P-values and hazard ratios for the series of test sets generated 
      # . for all the feature selection levels :
      # ....................................................................................................
      nScan = ncol(ayPredBIG);        # Total number of feature selection levels.

      cat(" ..........  Compute significance of prediction on collected test \n");
      cat("             sets relative to actual output values.               \n");
      cat("             nScan = ", nScan, " feature selection levels will be tested.\n");            
      # .......................................................................................
      # . Generate nScan vectors and (n * nScan) arrays storing test results for each
      # . feature selection level:
      # .......................................................................................
      apPred = c();                    # P-values for significance of the predictions.
      aR2Pred = c();                   # R2-values for prediction models.
      aAlphaPred = c();                # y-intercepts for regression lines.
      aBetaPred = c();                 # Slopes for regression lines.
      aSigmaPred = c();                # Estimated standard dev in prediction noise.

      aaucPred = c();                  # AUC for logistic regression.
      aaucPredLo95 = c();              # Lower bound on CI for AUC for logistic regression.
      aaucPredHi95 = c();              # Upper bound on CI for AUC for logistic regression.
      
      aerrMAP = c();                   # MAP error logistic regression.                      
      aerrMAPLo95 = c();               # Lower bound on CI for MAP error logistic regression.
      aerrMAPHi95 = c();               # Upper bound on CI for MAP error logistic regression.

      cat(">>Progress: ");             # Dots will follow.
      
      for (j in 1:nScan) {
        # .....................................................................................
        # . For each set of predictions generated at the given feature selection level,
        # . compute statistical measures of accuracy in prediction of observed values.
        # . Generate a P-value and associated values (coefficients, AUCs, etc).
        # .
        # . >> LINEAR REGRESSION MODEL :
        # . For each set of predictions generated at the given feature selection level,
        # . generate a linear regression of the observed values on the predicted values. 
        # . This results in a P-value and intercept and slope coefficients.
        # .....................................................................................
        if (modelType == 'lm') {
          ayPred = ayPredBIG[, j];       # The vector of predictions for the j-th feature selection level.

          fl = lm(ay ~ ayPred, na.action = 'na.omit');     # Regress observed on predicted. Omit NAs.
          fls = summary(fl);
        
          fscore = fls$fstatistic[1];    # F-statistic.
          alpha = fl$coefficients[1];    # y-intercept of regression line.      
          beta = fl$coefficients[2];     # Slope of regression line.
          R2 = fls$r.squared;            # R2 value.
          sigma = fls$sigma;             # Estimate of standard dev. of noise.

          numNA = length(which(is.na(ayPred)));                              # Number of NAs.
          n2 = length(ayPred) - 2 - numNA;                                   # df = n - 2.
          pval = pf(fscore, df1 = 1, df2 = n2, lower.tail = FALSE);          # Corresponding p-value.
          # ................................................................
          # . Assigned statistical metrics :
          # ................................................................                    
          apPred[j] = pval;              # P-values for significance of the predictions.
          aR2Pred[j] = R2;               # R2-values for prediction models.
          aAlphaPred[j] = alpha;         # y-intercepts for regression lines.
          aBetaPred[j] = beta;           # Slopes for regression lines.
          aSigmaPred[j] = sigma;         # Standard deviation of noise.
          # ................................................................
          # . Dummy values :
          # ................................................................
          aaucPred[j] = 0.5;             # Dummy value.
          aaucPredLo95[j] = 0.5;         # Dummy value.
          aaucPredHi95[j] = 0.5;         # Dummy value.
          aerrMAP[j] = 1.0;              # Dummy value.
          aerrMAPLo95[j] = 1.0;          # Dummy value.
          aerrMAPHi95[j] = 1.0;          # Dummy value.                    
          # ................................................................           
          cat(".", sep = "");            # Progress indicator.
        }
        # .....................................................................................                
        # . >> LOGISTIC REGRESSION MODEL :
        # . For each set of predictions generated at the given feature selection level,
        # . compute the AUC for detection of class 1 versus class 0, and the associated
        # . P-value (from the Wilcoxon test). Also compute a linear regression model
        # . of the observed output values on the cross-validated prognostic indices (PIs).
        # . This results in a P-value (not used here) and intercept and slope coefficients.
        # .....................................................................................        
        if (modelType == 'logistic') {
          axi = axiBIG[, j];               # Vector of cv'ed PIs for the j-th feature selection level.          
          aPyPred = aPyPredBIG[, j];       # Vector of est. P(y=1|x) for the j-th feature selection level.
          # ..............................................................
          # . For methodSplit = 'given', not all samples were re-cycled as
          # . test values. Therefore filter out NAs before doing roc calculations.
          # ..............................................................
          indexNoNA = which(!is.na(aPyPred));   # Index of calculated values.

          if (length(indexNoNA) > 0) {
            aPyPredBuf = aPyPred[indexNoNA];    # Filter down to calculated values.
            ayBuf = ay[indexNoNA];
            axiBuf = axi[indexNoNA];            
          } else {
            aPyPredBuf = aPyPred;               # Or keep all.
            ayBuf = ay;
            axiBuf = axi;            
          }
          # ..............................................................
          # . ROC and error statistics computation :
          # ..............................................................          
          #xxxx  roc = Stat.basicROC(aPyPredBuf, ayBuf,
          roc = Stat.basicROC(axiBuf, ayBuf,            
                              flagPval = TRUE,
                              flagConfInterval = FALSE,    # Not needed here.
                              flagNormalModel = FALSE,     # Not needed here.
                              prob = 0.95);
          
          aucStats = Stat.aucROCTest(roc$auc, roc$n0, roc$n1, prob = 0.95);
          # ................................................................
          # . Generate a logistic model on the CV prognostic index :
          # ................................................................
          fl = glm(ay ~ axi, family = binomial("logit"), na.action = 'na.omit');   # Omit NAs.
          fls = summary(fl);
          acoef = fls$coefficients;     # Coefficients array.
          alpha = acoef[1, 1];          # Intercept.
          beta = acoef[2, 1];           # Slope for x-dependency.
          pbeta = acoef[2, 4];          # P-value for x-dependency.
          # ................................................................
          # . Assigned statistical metrics :
          # ................................................................                    
          apPred[j] = roc$pval;          # P-values for significance of the predictions.

          aaucPred[j] = roc$auc;         # AUC.
          aaucPredLo95[j] = aucStats$ALo;# Lower bound on CI for AUC.
          aaucPredHi95[j] = aucStats$AHi;# Upper bound on CI for AUC.
          
          aerrMAP[j] = roc$errMAP;       # MAP error logistic regression.                      
          aerrMAPLo95[j] = roc$errMAPLo; # Lower bound on CI for MAP error logistic regression. 
          aerrMAPHi95[j] = roc$errMAPHi; # Upper bound on CI for MAP error logistic regression. 
          
          aAlphaPred[j] = alpha;         # y-intercepts for logit model of Y on xi.
          aBetaPred[j] = beta;           # slope for logit model of Y on xi.       
          # ................................................................
          # . Dummy values :
          # ................................................................          
          aR2Pred[j] = 1.0;              # Dummy value.
          aSigmaPred[j] = 0.0;           # Dummy value.
          # ................................................................ 
          cat(".", sep = "");            # Progress indicator.
        }
        # .....................................................................................        
      }
      cat("\n");                # We are done.
      # ....................................................................................................
      # . Determine the feature selection level which minimizes the P-value. In cases of a tie, always
      # . choose the simplest model (smallest value of j):
      # ....................................................................................................
      pvalMin = min(apPred);                      # Smallest P-value.
      jmin = min(which(apPred == pvalMin));       # This resolves ties, if any, in favor of the simplest model.
     
      if (parameterScan == 'mtop') {
        mtopMin = amtop[jmin];
        KMin = 0;                           # Dummy.
      } else if (parameterScan == 'K') {
        mtopMin = 0;                        # Dummy.
        KMin = aK[jmin];
      }

      ayPredMin = ayPredBIG[, jmin];                 # Vector of CVed predictions at the best tuning parameters.
      aPyPredMin = aPyPredBIG[, jmin];               # Vector of CVed est. P(y=1|x) at best tuning parameters.
      axiMin = axiBIG[, jmin];                       # Vector of PIs at best tuning parameters.           
      alphaPredMin = aAlphaPred[jmin];               # Corresponding intercept.
      betaPredMin = aBetaPred[jmin];                 # Corresponding slope.
      nPredMin = length(which(!is.na(ayPredMin)));   # Num.samples for which CVed values act. generated (non-NAs).
      # ....................................................................................................




      # ....................................................................................................
      # . FAILSAFE CHECK (this should be completely redundant) : check that the non-NA names for the
      # . cross-validated predictions are the same as those of the input data matrix!
      # ....................................................................................................
      abuf1 = arowName;
      abuf2 = names(ayPredMin);

      indexNA = which(is.na(ayPredMin));
      
      if (length(indexNA) > 0) {
        abuf1 = abuf1[-indexNA];   # Remove NAs.
        abuf2 = abuf2[-indexNA];   # Remove NAs.
      }

      errCount = sum(abuf2 != abuf1);       # Find discirdant entries.

      if (errCount > 0) {
        cat("ERROR: from SuperPcCv.crossValidateRegress:\n");
        cat("Logical error: row names in ayPredMin not same as row names in input data matrix dfX.\n");
        cat("Check assignment of ayPred in SuperPcCv.crossValidateRegressSingleSplit().\n");
        stop();
      }
      # ....................................................................................................



      # ....................................................................................................
      # . To pass fold-assignments :
      # ....................................................................................................
      if (methodSplit == 'vfoldStrict') {
        afold = cSplit$afold;
      } else if (methodSplit == 'given') {
        afold = af;
      } else {
        afold = rep(0, times = n);        
      }
      # ....................................................................................................      


     

      # ...............................................
      # . Package results :
      # ...............................................
      cv = list(modelType = modelType,
                ay = ay,
                parameterScan = parameterScan,
                methodSplit = methodSplit,
                ft = ft,
                ncv = ncv,
                rngSeed = rngSeed,
                afold = afold,
                K = K,
                mtop = mtop,
                nScan = cvS$nScan,
                amtop = amtop,
                aK = aK,
                ncv = ncvHere,
                n = n,
                arowName = arowName,
                ntrain = ntrain,
                ntest = ntest,
                p = p,
                aRrmsQ25 = aRrmsQ25,
                aRrmsMedian = aRrmsMedian,
                aRrmsQ75 = aRrmsQ75,
                aRrmsSigmaMad = aRrmsSigmaMad,
                aepsR2Q25 = aepsR2Q25,
                aepsR2Median = aepsR2Median,
                aepsR2Q75 = aepsR2Q75,
                aepsR2SigmaMad = aepsR2SigmaMad,
                amlog10pRQ25 = amlog10pRQ25,
                amlog10pRMedian = amlog10pRMedian,
                amlog10pRQ75 = amlog10pRQ75,
                amlog10pRSigmaMad = amlog10pRSigmaMad,
                apPred = apPred,
                aR2Pred = aR2Pred,
                aAlphaPred = aAlphaPred,
                aBetaPred = aBetaPred,
                aSigmaPred = aSigmaPred,        
                aaucPred = aaucPred,
                aaucPredLo95 = aaucPredLo95,
                aaucPredHi95 = aaucPredHi95,              
                aerrMAP = aerrMAP,
                aerrMAPLo95 = aerrMAPLo95,
                aerrMAPHi95 = aerrMAPHi95,        
                jmin = jmin,
                mtopMin = mtopMin,
                KMin = KMin,
                ayPredMin = ayPredMin,
                aPyPredMin = aPyPredMin,
                axiMin = axiMin,        
                alphaPredMin = alphaPredMin,
                betaPredMin = betaPredMin,
                nPredMin = nPredMin
              );
        
      
      class(cv) = 'spc.regress.cv';
      # ...............................................

      

      # ...........................................................
      cat(" ..........  Exit SuperPcCv.crossValidateRegress.\n");
      # ...........................................................

      
      
      # .............
      return (cv);
      # .............

}

# ========================================================================================================
# . End of  SuperPcCv.crossValidateRegress.
# ========================================================================================================      






# =================================================================================================
# . SuperPcCv.crossValidateRegressSingleSplit : generates a split of the data into training and test 
# . -----------------------------------------   sets, and then computes log-likelihood-ratios for the 
# .                                             test set for a range of the supervised principal
# .                                             components parameters.
# .
# .   Syntax:
# .
# .      cv =  SuperPcCv.crossValidateRegressSingleSplit(ay, dfX,
# .                                                      modelType,
# .                                                      methodSplit,
# .                                                      af, ft,
# .                                                      mtop, K,
# .                                                      parameterScan,
# .                                                      amtop, aK,
# .                                                      icv, aindexSplit,
# .                                                      flagVerbose)
# .
# .   In:
# .            ay = n : vector of output values (n = number of samples).
# .
# .           dfX = input data frame for the predictor variables.
# .                 This is of dimension n * p, where p = number of genes;
# .                 each row corresponds to a samples, and each column to a
# .                 gene.
# .
# .     modelType = type of regression model to be used :
# .                 Allowed values : 
# .                  - 'lm' : linear model.
# .                  - 'logistic' : logistic distribution. 
# .
# .   methodSplit = how to split the data matrix into training and test sets.
# .                 Allowed values:
# .
# .                   - 'given' : use array af (below) for assignments.
# .                               Entries = 'train' are assigned to the training set,
# .                               entries = 'test' are assigned to the test set,
# .                               entries = 'NONE' are ignored (other entries
# .                               are not valid).
# .
# .                   - 'vfold' : use parameter ft (below) to do a vfold
# .                               split of the data matrix.
# .
# .            - 'vfoldStrict'  : strict version of vfold. In applying the splits,
# .                               generate about 1/ft disjoint test sets, each with about
# .                               n_test = ft * n members (exact values are adjusted to whole
# .                               numbers). The value of n_test is floored to 1, so that for
# .                               ft << 1, this is the same as leave-one-out cross-validation.
# .
# .
# .            af = array of values flagging samples as being assigned to training
# .                 or test sets, or to be ignored, under methodSplit = 'given'.
# .                 Allowed values: 'train', 'test', or 'NONE'.
# .
# .            ft = fraction of all samples to be put into the test set, under
# .                 methodSplit = 'vfold'. Allowed: 0 < ft < 1.
# .
# .
# .     >> Fixed-values parameters:
# .
# .          mtop = keep the mtop genes with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values). Used only if
# .                 parameterScan = 'K'.
# .
# .             K = number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .                 Used only if parameterScan = 'mtop'.
# .
# .
# .   parameterScan = which parameter to scan in doing the cross-validation on this split of
# .                the data. Allowed values:
# .
# .                   - 'mtop' : do the cross-validation for the values of mtop
# .                              in the input array amtop.
# .                              The input values of the fixed-value parameters mtop
# .                              and p0 are ignored.
# .                              All calculations are done at the fixed value of K.
# .
# .                   - 'K' :    do the cross-validation for the values of K
# .                              in the input array aK.
# .                              The input value of the fixed-value parameter K
# .                              is ignored.
# .                              All calculations are done at the fixed values of
# .                              mtop or p0 (whichever applies under selected
# .                              methodFs).
# .
# .     >> Arrays of parameters for cross-validation:
# .
# .         amtop = array of values of mtop. Keep the mtop genes
# .                 with most significant Cox scores (i.e.
# .                 those with the mtop smallest P-values).
# .
# .            aK = array of number of principal components to be used as covariates
# .                 in the Cox proportional hazard model for the survival data.
# .
# .
# .     >> Split counter and groups :
# .
# .           icv = defines the group to be removed under split method 'vfoldStrict'.
# .                 This parameter is ignored otherwise.
# .   aIndexSplit = list of disjoint arrays, defining the groups to be removed for that round
# .                 of cross validation. Used under split method 'vfoldStrict', ignored
# .                 otherwise.
# .
# .
# .     >> General :
# .
# .   flagVerbose = if TRUE, prints progress on computation.
# .
# .
# .   Out:
# .    cv = list, with members :
# .
# .       parameterScan = parameter that was scanned (mtop or K).
# .               nscan = number of discrete parameter values used.
# .               amtop = array of the nscan mtop values (for parameterScan = mtop).
# .                  aK = array of nscan K values (for parameterScan = K).
# .               aRrms = array of r.m.s. values of residuals for the test set, evaluated
# .                       using the training set model parameters.
# .              aepsR2 = array of relative error terms (residual variance / original variance).
# .                 apR = array of model P-values.
# .
# =================================================================================================

SuperPcCv.crossValidateRegressSingleSplit  <- function(ay, dfX,
                                                       modelType,
                                                       methodSplit,
                                                       af, ft,
                                                       mtop, K,
                                                       parameterScan,
                                                       amtop, aK,
                                                       icv,
                                                       aIndexSplit,
                                                       flagVerbose)
{

      # ...........................................................................
      if (flagVerbose) {
        cat(" ..........  Entry in SuperPcCv.crossValidateRegressSingleSplit.\n");
      }
      # ...........................................................................

      
  
      # ......................................................................................      
      # . Determine the numbers of samples.
      # . Catch inconsistencies in specification of input arrays.
      # ......................................................................................
      n = nrow(dfX);     # Number of samples in data matrix.
      p = ncol(dfX);
      
      ny = length(ay);   # Number of samples in output variable vector.
      nf = length(af);   # Number of samples in train/test assignment vector.

      if (ny != n) {
        msg = "ERROR: from SuperPcCv.crossValidateRegressSingleSplit: ";        
        msg = paste("The output variable vector at has ny = ", ny, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      

      if (nf != n) {
        msg = "ERROR: from SuperPcCv.crossValidateRegressSingleSplit: ";        
        msg = paste("The train/test assignment vector as has nf = ", nf, "samples. ", sep = "");
        msg = paste("This is not the same as the n = ", n, "samples in the data matrix dfX.", sep = "");
        stop(msg);
      }

      if (n < 4) {
        msg = "ERROR: from SuperPcCv.crossValidateRegressSingleSplit: ";        
        msg = paste("The number of samples in the dat amatrix is n = ", n, sep = "");
        msg = paste("n >= 4 is required, as train and test set must each have at least 2 members.",
                    sep = "");
        stop(msg);
      }
      # ......................................................................................
   

      # ...................................................................................
      # . Check on the validity of some of the other input parameters :
      # ...................................................................................
      stopifnot((modelType == 'lm') || (modelType == 'logistic'));       
      stopifnot((methodSplit == 'given')
                || (methodSplit == 'vfold')
                || (methodSplit == 'vfoldStrict'));
      stopifnot((parameterScan == 'mtop') || (parameterScan == 'K'));

      if (parameterScan == 'mtop') {
        stopifnot(K >= 1);
        stopifnot(length(amtop) > 0);        
      } else if (parameterScan == 'K') {
        stopifnot(mtop >= 1);
        stopifnot(length(aK) > 0);        
      }

      if (methodSplit == 'vfold') {
        stopifnot((ft > 0.0) && (ft < 1.0));
      }


      if (methodSplit == 'vfoldStrict') {
        ncvBuf = length(aIndexSplit);

        if (icv > ncvBuf) {
          cat("ERROR: from SuperPcCv.crossValidateRegressSingleSplit:\n");
          cat("icv = ", icv, " is greater than the number of groups to be cross-validated, ncv = ", ncvBuf, "\n", sep = "");
          stop();
        }
      }      
      # ...................................................................................

      

      # ...................................................................................
      # . Generate the indices for splitting the data into training and test set.
      # .
      # . >> methodSplit = given :
      # ...................................................................................
      if (methodSplit == 'given') {
        # ......................................................................
        # . Check all given entries are 'train', 'test' or 'NONE' :
        # ......................................................................
        indexInvalid = which((af != 'train') & (af != 'test') & (af != 'NONE'));

        if (length(indexInvalid) > 0) {
          msg = "ERROR: from SuperPcCv.crossValidateRegressSingleSplit: ";        
          msg = paste("The train/test assignment vector contains some values which are neither ", sep = "");
          msg = paste("train, test or NONE. First detected invalid value = ", af[indexInvalid[1]], sep = "");
          stop(msg);
        }
        # ......................................................................
        # . Find the indices for the training and test subsets :
        # ......................................................................
        indexTrain = which(af == 'train');
        indexTest = which(af == 'test');

        ntrain = length(indexTrain);
        ntest = length(indexTest);        
        
        if (ntrain < 2) {
          msg = "ERROR: from SuperPcCv.crossValidateRegressSingleSplit: ";
          msg = paste("Less than 2 training set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntrain = ", ntrain, sep = "");          
          stop(msg);
        }

        if (ntest < 2) {
          msg = "ERROR: from SuperPcCv.crossValidateRegressSingleSplit: ";
          msg = paste("Less than 2 test set instances are specified in assignment vector af.", sep = "");
          msg = paste("ntest = ", ntest, sep = "");          
          stop(msg);
        }        
        # ......................................................................        
      }
      # ...................................................................................      
      # . >> methodSplit = vfold :
      # .    The training set and the test set must each have at least 2 elements.
      # .    Note that we require above that n >= 4, so that this is always possible.
      # ...................................................................................
      if (methodSplit == 'vfold') {
        # ......................................................................                
        ntest = floor(n * ft);
        if (ntest < 2) {
          ntest = 2;               # At least 2 elements in the test set.
        }

        n1 = n - 1;
        if (ntest >= n1) {
          ntest = n - 2;           # At least 2 elements in the training set.
        }
            
        indexTest = sample(x = 1:n, size = ntest);
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }
      # ...................................................................................      
      # . >> methodSplit = vfoldStrict :
      # . Under this option the groups were predefined before the function call,
      # . by function Stat.generateSplitsForVfold(). We just retrieve the indices.
      # ...................................................................................
      if (methodSplit == 'vfoldStrict') {
        # ......................................................................                
        indexTest = aIndexSplit[[icv]];
        buf = 1:n;
        indexTrain = buf[-indexTest];   # Complement of indexTest.

        ntrain = length(indexTrain);    # Final assignments.
        ntest = length(indexTest);        
        # ......................................................................         
      }            
      # ...................................................................................      



      # ...................................................................................
      # . Generate the training and test subsets :
      # ...................................................................................
      ayTrain = ay[indexTrain];       # Output variable values.
      dfXTrain = dfX[indexTrain, ];   # Data matrix of gene expression values.

      ayTest = ay[indexTest];         # Output variable values.
      dfXTest = dfX[indexTest, ];     # Data matrix of gene expression values.        
      # ...................................................................................

      
      # ...................................................................................
      # . Adjust for special cases :
      # ...................................................................................
      if (length(indexTest) == 1) {
        dfXTest = matrix(dfXTest, nrow = 1);
      }
      # ...................................................................................      

      
      
      # ..............................................................................................................
      # . Column-center the training data then generate univariate regression scores for
      # . each gene separately.
      # ..............................................................................................................
      axm = colMeans(dfXTrain);                                # Save the p column means.
      ym = mean(ayTrain);                                      # The single mean for the outcome data.
      
      dfXc = scale(dfXTrain, center = TRUE, scale = FALSE);    # Center each gene separately.
      ayc = ayTrain - ym;                                      # Center the outcome vector.
      
      cat(" ..........  Generating univariate scores using modelType = ", modelType, "\n", sep = "");

      if (modelType == 'lm') {      
        regS = Regress.computeLmUni(ayc, dfXc, flagVerbose = flagVerbose);             # Univariate linear model.
      } else if (modelType == 'logistic') {      
        #xxx  regS = Regress.computeLogisticUni(ayTrain, dfXc, flagVerbose = flagVerbose);   # Univariate logistic model.
        regS = Regress.computeLogisticUniMASKED(ayTrain, dfXc, flagVerbose = flagVerbose);   # Univariate logistic model. J. Theilhaber.
      } else {
        cat("ERROR: from SuperPcCv.: modelType = ", modelType, " is not valid.\n");    # Failsafe.
        cat("Please check program logic.\n");
        stop();
      }
      # ...............................................................................................................


      # ..............................................................................
      cat(" ..........  Begin inner cross-validation loop, scanning parameter = ",
            parameterScan, "\n", sep = "");
      # ..............................................................................

      
      # .........................................................................
      methodFs = 'mtop'; # Hardwired, as only feature selection method used here.
      p0 = 1.0;          # Dummy value, as is ignored in feature selection.
      # .........................................................................
      
      
      # .................................................................................................
      # . CROSS-VALIDATION
      # . >> PREAMBLE :
      # . Assign the array for the parameter to be scanned.
      # .................................................................................................
      if (parameterScan == 'mtop') {
        aScan = amtop;                        # Array of parameters to be scanned.
      } else if (parameterScan == 'K') {
        aScan = aK;                           # Array of parameters to be scanned.
      }
      # .................................................................................................
      # . For parameterScan = 'K', we need to do the feature selection at the indicated mtop level
      # . only once.
      # .................................................................................................      
      if (parameterScan == 'K') {
        selFFixed = SuperPc.selectFeaturesRegress(dfXc, methodFs, p0, mtop, regS);      
        #xxx selFFixed = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtop, coxS);
      }
      # .................................................................................................
      # . >> MAIN LOOP :
      # .................................................................................................
      aRrms = c();             # r.m.s. of residuals of test set on training set parameters.
      aepsR2 = c();            # relative error of test set on training set parameters.
      apR = c();               # model P-values.

      nScan = length(aScan);   # Number of levels to be explored.
      il = 0;                  # Level counter.
        
      cat("Progress: ", sep = "");     # Progress indicator.
      t1 = proc.time()[3];              # Starting time.
       
      for (z in aScan) {
        # .......................................................................................
        # . Set the parameters :
        # .......................................................................................        
        if (parameterScan == 'mtop') {
          mtopHere = z;             # The parameter being scanned is mtop.
          KHere = K;                # K is fixed.
        } else if (parameterScan == 'K') {
          mtopHere = mtop;          # mtop is fixed.
          KHere = z;                # The parameter being scanned is K.
        }
        # .......................................................................................
        # . Perform the feature selection with the indicated method and parameters :
        # .......................................................................................
        if (parameterScan == 'mtop') {
          selF = SuperPc.selectFeaturesRegress(dfXc, methodFs, p0, mtopHere, regS);      
          #xxx selF = SuperPc.selectFeaturesCox(dfXc, methodFs, p0, mtopHere, coxS);
        } else if (parameterScan == 'K') {
          selF = selFFixed;                    # This was precomputed at the specified value of mtop.
        }
        # .......................................................................................
        # . Do the svd and generate multivariate regression model :
        # . - for linear regression, use centered output variable.
        # . - for logistic regression, use raw binary {0, 1} output variable.        
        # .......................................................................................
        if (modelType == 'lm') {      
          cSel = SuperPc.computeRegressOnSelectedFeatures(ayc, selF$dfXSel, modelType, KHere);
        } else if (modelType == 'logistic') {
          cSel = SuperPc.computeRegressOnSelectedFeatures(ayTrain, selF$dfXSel, modelType, KHere);        
        }
        # .......................................................................................
        # . Package all the results into a single spc.regress object :
        # .......................................................................................
        spcTrain = SuperPc.packageSpcRegress(msg = 'ok',
                                             ay = ayTrain,
                                             modelType = modelType,
                                             methodFs = methodFs,
                                             mtop = mtopHere,
                                             p0 = p0,
                                             n = n,
                                             p = p,
                                             ac = NULL,                # Not required for cross-validation.
                                             ym = ym,
                                             axm = axm,
                                             indexSel = selF$indexSel,
                                             m = selF$m,
                                             pvalMin = selF$pvalMin,
                                             pvalMax = selF$pvalMax,
                                             K = KHere,
                                             abeta = cSel$abeta,
                                             aseBeta = cSel$aseBeta,
                                             ap = cSel$ap,
                                             beta0 = cSel$beta0,          # Intercept coefficient.
                                             seBeta0 = cSel$seBeta0,      # Standard error for intercept.
                                             pBeta0 = cSel$pBeta0,        # P-value for intercept non-zero.
                                             qR = cSel$qR,
                                             df1 = cSel$df1,
                                             df2 = cSel$df2,
                                             pR = cSel$pR,
                                             avSel = cSel$avSel,
                                             av = NULL,                  # Not required for cross-validation.
                                             avSelTot = cSel$avSelTot,
                                             avTot = NULL,               # Not required for cross-validation.
                                             sv = cSel$sv,
                                             regK = cSel$regK);
        # ...............................................................................
        # . Compute the model predictions on the test set :
        # . This call returns :
        # .          sl$Y = ntest * K :  matrix of principal components.
        # .        sl$axi = ntest : vector of prognostic indices xi = beta0 + beta . x
        # .     sl$ayPred = ntest : vector of predicted output values.
        # .    sl$aPyPred = ntest : vector of estimated P(y = 1|x) values 
        # .                         (dummy values = 0 for modelType = 'lm').
        # ...............................................................................
        sTest = SuperPc.computeRegressPcAndOutputVariable(spcTrain, dfXIn = dfXTest);
        # .......................................................................................
        # . Generate the columns of the matrix for the computed values, for each of the
        # . variables axi, ayPred and aPyPred. This creates a matrix of dimensions
        # . [samples * feature-selection levels] for the test samples, for this given split.
        # . The final matrix will have dimensions ntest * nScan.
        # .......................................................................................
        if (il == 0) {
          axiBIG = matrix(sTest$axi, nrow = length(sTest$axi));                 # The first column.
          rownames(axiBIG) = rownames(sTest$axi);
          
          ayPredBIG = matrix(sTest$ayPred, nrow = length(sTest$ayPred));        # The first column.
          rownames(ayPredBIG) = rownames(sTest$ayPred);

          aPyPredBIG = matrix(sTest$aPyPred, nrow = length(sTest$aPyPred));     # The first column.
          rownames(aPyPredBIG) = rownames(sTest$aPyPred);          
        } else {
          axiBIG = cbind(axiBIG, sTest$axi);                                    # Subsequent columns.          
          ayPredBIG = cbind(ayPredBIG, sTest$ayPred);                           # Subsequent columns.
          aPyPredBIG = cbind(aPyPredBIG, sTest$aPyPred);                        # Subsequent columns.          
        }                
        # .......................................................................................
        # . Compute the residuals for the test set, using the model derived from
        # . the training set.
        # . Note that we are doing this for only the linear regression model, and that
        # . this is a holdover from an earlier measure of corss-validation.
        # .......................................................................................
        if (modelType == 'lm') {
          resTest = SuperPc.computeRegressResiduals(spcTrain,
                                                    ayIn = ayTest,
                                                    dfXIn = dfXTest);
          Rrms = resTest$Rrms;
          epsR2 = resTest$epsR2;
          pR = cSel$pR;                  # Model P-value, retrieved here as well.
        } else if (modelType == 'logistic') {
          Rrms = 1.0;                    # Dummy values.
          epsR2 = 1.0;
          pR = 1.0;
        }
        # .......................................................................................
        # . Update arrays :
        # .......................................................................................
        aRrms = c(aRrms, Rrms);
        aepsR2 = c(aepsR2, epsR2);
        apR = c(apR, pR);        

        cat(".", sep = "");         # Progress indicator.

        il = il + 1;
        if (il%%20 == 0) {
          cat(" : processed ", il, " levels out of ", nScan, ".\n", sep = "");
          cat("          ", sep = "");                                          # Spacer for next row of dots indicating progress.
        }
        # .......................................................................................          
      }
      # .......................................................................................
      # . Summarize times :
      # .......................................................................................        
      cat("\n", sep = "");

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / nScan;                                 # Time per parameter value.

      if (flagVerbose) {
        cat(" ..........  Inner cross-validation loop done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per ", parameterScan, " value.\n");
      }
      # .............................................................................................

      

      # ...............................................
      # . Package results :
      # ...............................................
      cv = list(parameterScan = parameterScan,
                methodSplit = methodSplit,
                mtop = mtop,
                K = K,        
                nScan = nScan,
                amtop = amtop,
                aK = aK,
                n = n,
                ntrain = ntrain,
                ntest = ntest,
                aRrms = aRrms,
                aepsR2 = aepsR2,
                apR = apR,
                indexTest = indexTest,
                axiBIG = axiBIG,
                ayPredBIG = ayPredBIG,
                aPyPredBIG = aPyPredBIG);

      class(cv) = 'spc.regress.cv.single';
      # ...............................................


      # .............
      return (cv);
      # .............
      
}

# =================================================================================================
# . End of SuperPcCv.crossValidateRegressSingleSplit.
# =================================================================================================




## =================================================================================================
## . SuperPcCv.generateSplitsForVfold : generates splits for the ``strict'' version of vfold.
## . --------------------------------
## .
## . Syntax :
## .
## .       cs = SuperPcCv.generateSplitsForVfold(n, ft, flagRandom);
## .
## . In:
## .              n = total number of samples.
## .
## .             ft = fraction to be removed from the total to generate each test.
## .                  0 < ft < 1.
## .
## .     flagRandom = TRUE/FALSE. If TRUE, randomize index order before generating the groups.
## .                  If FALSE, the groups are generated in order of appearance of the indices.
## .
## . Out:
## .        cs = list with members :
## .
## .                ncv = number of groups generated.
## .              ntest = number of members in each group (last one may be truncated).
## .        aIndexSplit = list of ncv arrays, each array containing the indices of the group
## .                      to be extracted for a round of the cross-validation.
## .
## =================================================================================================

#SuperPcCv.generateSplitsForVfold <- function(n, ft, flagRandom = FALSE)
#{

#      # ..................................
#      stopifnot(ft > 0.0, ft < 1.0);
#      stopifnot(n > 1);
#      # ..................................
     

      
#      # .............................................................
#      # . Determine the value of ntest :
#      # .............................................................      
#      ntest = ceiling(ft * n);         # Tentative number in each test set.

#      if (ntest < 1) {
#        ntest = 1                 # Smallest test set has 1 element.
#      };

#      n2 = ceiling(n / 2);
      
#      if (ntest > n2) {
#        ntest = n2;               # At least two approximately equal groups.
#      }
#      # .............................................................


      
#      # .................................................................................................
#      # . Now generate the actual groups :
#      # .................................................................................................
#      bufIndex = 1:n;
#      bufIndexChoose = bufIndex;

#      if (ntest == 1) {
#        mask = 1:n;                      # Each group will contain just one index.
#      } else {
#        bufB = bufIndex%%ntest;          # 0's mark transitions between groups.
#        bufB = c(0, bufB[1:(n-1)]);      # Pad with one leading 0.
#        bufC = ifelse(bufB == 0, 1, 0);  # Now 1's mark transitioons between groups, all others are 0.
#        mask = cumsum(bufC);             # The cum. sum generates the fold labels {1 1 1 2 2 2 3 3 3 . . .}
#      }
        
#      if (flagRandom) {
#        bufIndexChoose = sample(bufIndexChoose);         # Randomize before assigning to folds.
#      }

#      aIndexSplit = split(bufIndexChoose, mask);     # Maps: fold --> bag of samples.
#      ncv = length(aIndexSplit);

#      afold = c();
#      afold[bufIndexChoose] = mask;                  # Maps: sample --> fold of which it is a member.
#      # ..................................................................................................



#      # ........................................................................
#      # . Package the results :
#      # ........................................................................
#      cs = list(ncv = ncv,
#                ntest = ntest,      
#                aIndexSplit = aIndexSplit,    # List, maps: fold --> bag of samples.
#                afold = afold);               # Array, maps: sample --> fold of which it is a member.
#      # .........................................................................


#      # ...........
#      return (cs);
#      # ...........
      
#}  

## =================================================================================================
## . End of SuperPcCv.generateSplitsForVfold.
## =================================================================================================





# =================================================================================================
# . SuperPcCv.computeCoxSensitivesOnBinary : 
# . --------------------------------------
# .
# . This applies to cross-validation of two-treatment arm studies (i.e. with a binary
# . external covariate {0, 1}, denoting the treatment arm) :
# .
# .   * Using the cross-validated log-hazards, this predicts sensitive/nonSensitive status
# .     for all of the samples.
# .
# .   * Two values of the threshold, are used :
# .       hRCMin :the threshold for which the minimum P-value between treatment arms obtains.
# .       hRC: an externally supplied threshold.
# .   * For each of the sensitive subsets thus defined, this then computes the P-values and
# .     log-hazard ratios between Z = 1 and Z = 0 treatment arms, based on a Cox model.
# .
# .................................................................................................
# .   Syntax:
# .
# .       cSens = SuperPcCv.computeCoxSensitivesOnBinary(cv, hRC);
# .
# .   In:
# .        cv = result of cross-validation for a *single* feature selection level, returned
# .             by function SuperPcCv.crossValidateCoxWithCov();
# .
# .
# .       hRC = external threshold on differential predicted log-hazard-ratios for defining the sensitive
# .             subset of patient samples. This is used only for binary external covariate
# .             (Z in {0, 1}), ignored otherwise. hRC must be >= 0.
# .
# .   Out:
# .        cSens = list, with members defined at end of this method.
# .
# =================================================================================================

SuperPcCv.computeCoxSensitivesOnBinary <- function(cv, hRC)
{

      # ...........................................................
      if ((class(cv) != "spc.cox.cov.cv")
          && (class(cv) != "basic.cox.cov.cv")
          && (class(cv) != "glmnet.cox.cov.cv")
          ) {
        msg = "ERROR: from SuperPcCv.computeCoxSensitivesOnBinary: ";
        msg = paste("The input cv is not of class spc.cox.cov.cv, basic.cox.cov.cv, glmnet.cox.cov.cv");
        stop(msg);
      }
      # ...........................................................


      # ...........................................................
      at = cv$atBIG;
      as = cv$asBIG;
      az = cv$azBIG;
      # ...........................................................      


      
      # .......................................................................................
      # . Check on the external covariate (failsafe) :
      # .......................................................................................    
      msgBin = Cox.checkBinary(az);

      if (msgBin != 'ok') {
        cat("ERROR: from SuperPcCv.computeCoxSensitivesOnBinary:\n");        
        cat("External covariate values must all be {0, 1}\n");
        cat(msgBin);
        cat("\n");
        stop();
      }

      stopifnot(hRC >= 0.0);
      # .......................................................................................


      
      # ......................................................................
      # . Failsafe: this applies to only a single level of tuning
      # . parameters.
      # ......................................................................
      if (cv$nScan != 1) {
        cat("ERROR: from SuperPcCv.computeCoxSensitivesOnBinary:\n");
        cat("In cv input object, nScan = ", cv$nScan, " != 1.\n", sep = "");
        cat("This method applies to only a single level of tuning parameters.\n");
        stop();
      }
      # ......................................................................

      

      # ...................................................................................
      # . Find the sensitive samples :
      # ...................................................................................      
      aloghRactual = cv$aloghRBIG[ , 1];       # The log-hazard ratios predicted for the actual Z.
      aloghR0 = cv$aloghRBIG0[ , 1];           # The log-hazard ratios predicted for the Z = 0 arm.
      aloghR1 = cv$aloghRBIG1[ , 1];           # The log-hazard ratios predicted for the Z = 1 arm.
      aDloghR = cv$aDloghRBIG[ , 1];           # The cross-validated differential log-hazard ratio.

      hRCMin = cv$ahRCBIG[1];
      loghRCMin = log(max(cv$ahRCBIG[1], 1.0e-12));     # Internal threshold for defining sensitives.
      loghRC = log(max(hRC, 1.0e-12));                  # External threshold for defining sensitives.
      
      aflagSensitiveMin = ifelse(aDloghR <= loghRCMin, 1, 0);
      aflagSensitive = ifelse(aDloghR <= loghRC, 1, 0);

      nSensitiveMin = sum(aflagSensitiveMin);     # Number of sensitives on internal threshold.
      nSensitive = sum(aflagSensitive);           # Number of sensitives on external threshold.      
      # ...................................................................................


      # ...........................................................................................
      # . Cox analyses for the sensitive groups.
      # .
      # . >> 1. Internal threshold :
      # ............................................................................................
      pRMin = 1.0;            # Defaults, if there are no instances under the threshold.
      loghRMin = 0.0;         # (this cannot be the case for the internal threshold,
      loghRMinLo = 0.0;       # but I'm keeping this structure for consistency with the
      loghRMinHi = 0.0;       # external threshold case).
      hRMin = 1.0;
      hRMinLo = 1.0;
      hRMinHi = 1.0;
      
      if (nSensitiveMin > 0) {
        loghRCMin = log(max(cv$ahRCBIG[1], 1.0e-12));     # Internal threshold for defining sensitives.
      
        atBuf = at[aDloghR < loghRCMin];
        asBuf = as[aDloghR < loghRCMin];
        azBuf = az[aDloghR < loghRCMin];           

        coxBuf = coxph(Surv(atBuf, asBuf) ~ azBuf);           # Cox model on binary {0,1} variable.

        qR = 2.0 * (coxBuf$loglik[2] - coxBuf$loglik[1]);     # Likelihood ratio statistic.
        pRMin = pchisq(qR, df = 1, lower.tail = FALSE);       # >> P-value from likelihood ratio.
      
        coxBufsum = summary(coxBuf);
        coxBufcoef = coxBufsum$coef;                       # Contains the coefficient and P-value.
      
        beta = coxBufcoef[ , 1];                           # The Cox coefficient.
        seBeta = coxBufcoef[ , 3];                         # Standard error for the coefficient.
        pBeta = coxBufcoef[ , 5];                          # The corresponding P-value.

        if (is.nan(seBeta)) {
          seBeta = Cox.MAX_SEBETA;
        }

        if (seBeta > Cox.MAX_SEBETA) {
          seBeta = Cox.MAX_SEBETA;                         # Controls for cases where beta -> -infinity.
        }
        # .......................................................................................
        # . Compute the hazard ratio between treated (+1) and untreated (0) groups,
        # . and its confidence limits for +/- one std. dev. in the log-hazard-ratio.
        # .......................................................................................
        loghRMin = beta;
        loghRMinLo = beta - seBeta;
        loghRMinHi = beta + seBeta;

        hRMin = exp(loghRMin);                                  # Hazard ratio of treated to untreated group.
        hRMinLo = exp(loghRMinLo);
        hRMinHi = exp(loghRMinHi);
        # .......................................................................................
      }
      # ............................................................................................
      # . >> 2. External threshold :
      # ............................................................................................
      pR = 1.0;                # Defaults, if there are no instances under the threshold.
      loghR = 0.0;             # (this cannot be the case for the internal threshold,
      loghRLo = 0.0;           # but I'm keeping this structure for consistency with the
      loghRHi = 0.0;           # external threshold case).
      hR = 1.0;
      hRLo = 1.0;
      hRHi = 1.0;
      
      if (nSensitive > 0) {
        loghRC = log(max(hRC, 1.0e-12));               # External threshold for defining sensitives.            
      
        atBuf = at[aDloghR < loghRC];
        asBuf = as[aDloghR < loghRC];
        azBuf = az[aDloghR < loghRC] ;           

        coxBuf = coxph(Surv(atBuf, asBuf) ~ azBuf);    # Cox model on binary {0,1} variable.

        qR = 2.0 * (coxBuf$loglik[2] - coxBuf$loglik[1]);     # Likelihood ratio statistic.
        pR = pchisq(qR, df = 1, lower.tail = FALSE);       # >> P-value from likelihood ratio.
      
        coxBufsum = summary(coxBuf);
        coxBufcoef = coxBufsum$coef;                       # Contains the coefficient and P-value.
      
        beta = coxBufcoef[ , 1];                           # The Cox coefficient.
        seBeta = coxBufcoef[ , 3];                         # Standard error for the coefficient.
        pBeta = coxBufcoef[ , 5];                          # The corresponding P-value.

        if (is.nan(seBeta)) {
          seBeta = Cox.MAX_SEBETA;
        }

        if (seBeta > Cox.MAX_SEBETA) {
          seBeta = Cox.MAX_SEBETA;                         # Controls for cases where beta -> -infinity.
        }
        # .......................................................................................
        # . Compute the hazard ratio between treated (+1) and untreated (0) groups,
        # . and its confidence limits for +/- one std. dev. in the log-hazard-ratio.
        # .......................................................................................
        loghR = beta;
        loghRLo = beta - seBeta;
        loghRHi = beta + seBeta;

        hR = exp(loghR);                                  # Hazard ratio of treated to untreated group.
        hRLo = exp(loghRLo);
        hRHi = exp(loghRHi);
        # .......................................................................................
      }        
      # ...................................................................................



      # ..................................................................................................
      # . Package the results :
      # ..................................................................................................
      cSens = list(aloghRactual = aloghRactual, # The log-hazard ratios predicted for the actual Z.
                   aloghR0 = aloghR0,           # The log-hazard ratios predicted for the Z = 0 arm.
                   aloghR1 = aloghR1,           # The log-hazard ratios predicted for the Z = 1 arm.
                   aDloghR = aDloghR,           # The cross-validated differential log-hazard ratio.

                   hRCMin = hRCMin,             # Internal threshold for differential log-hazard-ratio.
      
                   aflagSensitiveMin = aflagSensitiveMin,  # Flags sensitives on internal threshold.
                   aflagSensitive = aflagSensitive,        # Flags sensitives on external threshold.

                   nSensitiveMin = nSensitiveMin,     # Number of sensitives on internal threshold.
                   nSensitive = nSensitive,           # Number of sensitives on external threshold.      

                   pRMin = pRMin,              # Internal threshold: P-value for Z=1 versus Z=0.  
                   loghRMin = loghRMin,        # Internal threshold: loghR for Z=1 versus Z=0.    
                   loghRMinLo = loghRMinLo,    # Internal threshold: loghR lower bound (-se).     
                   loghRMinHi = loghRMinHi,    # Internal threshold: loghR upper bound (+se).     
                   hRMin = hRMin,              # Internal threshold: hR for Z=1 versus Z=0.       
                   hRMinLo = hRMinLo,          # Internal threshold: hR lower bound.              
                   hRMinHi = hRMinHi,          # Internal threshold: hR upper bound.
        
                   pR = pR,                    # External threshold: P-value for Z=1 versus Z=0.  
                   loghR = loghR,              # External threshold: loghR for Z=1 versus Z=0.    
                   loghRLo = loghRLo,          # External threshold: loghR lower bound (-se).     
                   loghRHi = loghRHi,          # External threshold: loghR upper bound (+se).     
                   hR = hR,                    # External threshold: hR for Z=1 versus Z=0.       
                   hRLo = hRLo,                # External threshold: hR lower bound.              
                   hRHi = hRHi);               # Internal threshold: hR upper bound.              
      # ..................................................................................................      


      # ................
      return (cSens);
      # ................

}

# =================================================================================================
# . End of SuperPcCv.computeCoxSensitivesOnBinary.
# =================================================================================================





# =================================================================================================
# . SuperPcCv.computeCoxROCOnBinary : 
# . -------------------------------
# .
# . This applies to cross-validation of two-treatment arm studies (i.e. with a binary
# . external covariate {0, 1}, denoting the treatment arm) :
# .
# .   * Using the cross-validated log-hazards, this retrives the predicted differential 
# .     log-hazard-ratio DloghR, the P-values and hazard-ratios between Z=1 and Z=0,
# .     the rank of each sample in accordance with DloghR in increasing order,
# .     computes the log of the hazard-ratios and -log10 of the P-values,
# .     and finally also computes the sensitivity and actual number of samples
# .     for selections based on DloghR <= hRC.
# .
# .     ROC plots can then be obtained by plotting e.g. hR vs DloghR.
# .
# .................................................................................................
# .   Syntax:
# .
# .       cRoc = SuperPcCv.computeCoxROCOnBinary(cv);
# .
# .   In:
# .        cv = result of cross-validation for a *single* feature selection level, returned
# .             by function SuperPcCv.crossValidateCoxWithCov();
# .
# .   Out:
# .        cRoc = data frame, with columns defined at end of this method.
# .
# =================================================================================================

SuperPcCv.computeCoxROCOnBinary <- function(cv, hRC)
{

      # ...........................................................
      if ((class(cv) != "spc.cox.cov.cv")
          && (class(cv) != "basic.cox.cov.cv")
          && (class(cv) != "glmnet.cox.cov.cv")          
          ) {
        msg = "ERROR: from SuperPcCv.computeCoxROCOnBinary: ";
        msg = paste("The input cv is not of class spc.cox.cov.cv, basic.cox.cov.cv, glmnet.cox.cov.cv");
        stop(msg);
      }
      # ...........................................................


      
      # .......................................................................................
      # . Check on the external covariate (failsafe) :
      # .......................................................................................    
      msgBin = Cox.checkBinary(cv$azBIG);

      if (msgBin != 'ok') {
        cat("ERROR: from SuperPcCv.computeCoxROCOnBinary:\n");        
        cat("External covariate values must all be {0, 1}\n");
        cat(msgBin);
        cat("\n");
        stop();
      }
      # .......................................................................................


      
      # ......................................................................
      # . Failsafe: this applies to only a single level of tuning
      # . parameters.
      # ......................................................................
      if (cv$nScan != 1) {
        cat("ERROR: from SuperPcCv.computeCoxROCOnBinary:\n");
        cat("In cv input object, nScan = ", cv$nScan, " != 1.\n", sep = "");
        cat("This method applies to only a single level of tuning parameters.\n");
        stop();
      }
      # ......................................................................


      
      # ..................................................................................................
      # . Retrieve the relevant arrays :
      # ..................................................................................................      
      aDloghR = cv$aDloghRBIG[ , 1];                  # DloghR: predicted differential log-hazard threshold.
      ahRUnSort = cv$ahRUnSortBIG[ , 1];              # hR: resulting hR between Z=1 and Z=0.
      aloghRUnSort = log(cv$ahRUnSortBIG[ , 1]);      # log(hR): resulting loghR between Z=1 and Z=0.
      apRUnSort = cv$apRUnSortBIG[ , 1];              # pR : P-value between Z=1 and Z=0.
      amlog10pRUnSort = Stat.getMlog10(apRUnSort);    # -log10(P) transformation of P-value.
      arank = cv$arankBIG[ , 1];                      # For each sample in original order, its rank in terms of DloghR.
      
      aSSort = (1:cv$n) / cv$n;                       # Sensitivity, in DloghR-sorted order.
      anSort = 1:cv$n;                                # Absolute number of sensitive patients.

      aS = aSSort[arank];                             # Sensitivity in original order.
      an = anSort[arank];                             # Absolute number of sensitive patients, in original order.
      # ..................................................................................................



      # ..................................................................................................
      # . Package the results :
      # ..................................................................................................
      cRoc = data.frame(
                  arank = arank,                      # For each sample in original order, rank in terms of DloghR.
                  aDloghR = aDloghR,                  # DloghR: predicted differential log-hazard threshold.
                  ahRUnSort = ahRUnSort,              # hR: resulting hR between Z=1 and Z=0.
                  aloghRUnSort = aloghRUnSort,        # log(hR): resulting loghR between Z=1 and Z=0.
                  apRUnSort = apRUnSort,              # pR : P-value between Z=1 and Z=0.
                  amlog10pRUnSort = amlog10pRUnSort,  # -log10(P) transformation of P-value.
                  aS = aS,                            # Sensitivity in original order.
                  an = an);                           # Absolute number of sensitive patients, in original order.
      # ..................................................................................................

      
      # ................
      return (cRoc);
      # ................

}

# =================================================================================================
# . End of SuperPcCv.computeCoxROCOnBinary.
# =================================================================================================





# =================================================================================================
# . SuperPcCv.computeRegressLeftRightROC :
# . ------------------------------------
# .
# . For any linear regression model, regressing an output variable Y on multivariate data :
# . Let y = actual values, and yPred = predicted values (preferably through cross-validation).
# . 
# . For each value of yPred = yPred0, this computes the "left" and "right" statistics :
# .
# .     yL = mean of all y for which yPred <= yPred0 .
# .     sL = standard deviation of all y for which yPred <= yPred0 .
# .     yR = mean of all y for which yPred >= yPred0 .
# .     sR = standard deviation of all y for which yPred >= yPred0 .
# .
# .................................................................................................
# .   Syntax:
# .
# .     lrRoc = SuperPcCv.computeLeftRightROC(y, yPred);
# .
# .   In:
# .         y = actual values of output variable.
# .     yPred = predicted values of output variable (preferably through cross-validation).
# .             The length of yPred must be the same as that of y.
# .
# .   Out:
# .       lrRoc = list, with members {n, yPredSort, ySort, yR, sR, yL, sL}, where n = number of elements,
# .               {yPredSort, ySort} are the input arrays under the sort key for yPred in
# .               increasing left-to-right order, and {yR, sR, yL, sL} to arrays of length n
# .               containing the statistics.
# .
# =================================================================================================

SuperPcCv.computeRegressLeftRightROC <- function(y, yPred)
{

      # .....................................................................
      n = length(y);

      if (n == 0) {
        cat("ERROR: from SuperPcCv.computeRegressLeftRightROC:\n");
        cat("Input array y is of 0 length.\n");
        stop();
      }
      
      if (length(yPred) != n) {
        cat("ERROR: from SuperPcCv.computeRegressLeftRightROC:\n");
        cat("Input array yPred is not the same length as input array y.\n");
        stop();
      }
      # ......................................................................

      

      # ...........................................................
      # . Sort the samples so that yPred is in increasing
      # . order left-to-right :
      # ...........................................................
      indexSort = order(yPred);
      yPredSort = yPred[indexSort];
      ySort = y[indexSort];
      # ...........................................................


      
      # ...............................................................................
      # . Traverse the array, generating left and right statistics on the way :
      # ...............................................................................      
      lrBIG = sapply(1:n, function(j){buf = SuperPc.computeLeftRightStats(ySort, j);});
      
      yL = as.numeric(lrBIG["yL", ]);
      sL = as.numeric(lrBIG["sL", ]);         
      yR = as.numeric(lrBIG["yR", ]);
      sR = as.numeric(lrBIG["sR", ]);
      pvalLR = as.numeric(lrBIG["pvalLR", ]);         
      # ...............................................................................


     
      # .............................................................................
      # . Find point of maximum separation :
      # .............................................................................
      jmin = which.min(pvalLR);
      pvalMin = pvalLR[jmin];
      # .............................................................................      

      

      # ......................................................................
      # . Package the results :
      # ......................................................................
      lrROC = list(n = n,
                   yPredSort = yPredSort,   # Predicted values, sorted in increasing order left-to-right.
                   ySort = ySort,           # Actual values, on yPred sort key.
                   yL = yL,
                   sL = sL,
                   yR = yR,
                   sR = sR,
                   pvalLR = pvalLR,
                   jmin = jmin,             # Index for maximum separation.
                   pvalMin = pvalMin);      # P-value for maximum separation.
      # ......................................................................

      

      # ...............
      return (lrROC);
      # ...............

}

# =================================================================================================
# . End of SuperPcCv.computeRegressLeftRightROC.
# =================================================================================================






# =======================================================================================================================
# . SuperPcCv.computeCoxLeftRightROC :
# . ---------------------------------
# .
# . For a Cox model with no external covariate, regressing time and censoring data (at, as)
# . on multivariate data :
# . Let (at, as) = actual values, and xiPred = prognostic index = log-hazard-ratio (preferably through cross-validation).
# . 
# . For each value of xiPred = xiPred0, this computes the "left" and "right" statistics :
# .
# .     tL = median time to event (from KM estimator) for all samples for which xiPred <= xiPred0 .
# .     tR = median time to event (from KM estimator) fro all samples for which xiPred >= xiPred0 .
# .     sR = standard deviation of all y for which xiPred >= xiPred0 .
# .     hLR = hazard ratio for L reletaive to R populations for given split.
# .     pvalLR = corresponding P-value, based on the logrank test.
# .
# .........................................................................................................................
# .   Syntax:
# .
# .     lrRoc = SuperPcCv.computeLeftRightROC(at, as, xiPred);
# .
# .   In:
# .         at = actual values of times to event.
# .         as = actual companion censoring statuses. Length must be the same as at.
# .     xiPred = predicted values of output variable (preferably through cross-validation).
# .             The length of xiPred must be the same as that of at.
# .
# .   Out:
# .       lrRoc = list, with members {n, xiPredSort, atSort, asSort, tR, tL, hLR, pvalLR},
# .               where n = number of elements,
# .               {xiPredSort, atSort, asSort} are the input arrays under the sort key for xiPred in
# .               increasing left-to-right order, and {tR, tL, hLR, pvalLR} arrays of length n
# .               containing the statistics.
# .
# ==========================================================================================================================

SuperPcCv.computeCoxLeftRightROC <- function(at, as, xiPred)
{

      # .....................................................................
      n = length(at);

      if (n == 0) {
        cat("ERROR: from SuperPcCv.computeCoxLeftRightROC:\n");
        cat("Input array at is of 0 length.\n");
        stop();
      }

      if (length(as) != n) {
        cat("ERROR: from SuperPcCv.computeCoxLeftRightROC:\n");
        cat("Input array as is not the same length as input array at.\n");
        stop();
      }
      
      if (length(xiPred) != n) {
        cat("ERROR: from SuperPcCv.computeCoxLeftRightROC:\n");
        cat("Input array xiPred is not the same length as input array at.\n");
        stop();
      }
      # ......................................................................

      

      # ...........................................................
      # . Sort the samples so that xiPred is in increasing
      # . order left-to-right :
      # ...........................................................
      indexSort = order(xiPred);
      xiPredSort = xiPred[indexSort];
      atSort = at[indexSort];
      asSort = as[indexSort];
      # ...........................................................


      
      # ...............................................................................................
      # . Traverse the array, generating left and right statistics on the way :
      # ...............................................................................................
      lrBIG = sapply(1:n, function(j){buf = SuperPc.computeLeftRightCoxStats(atSort, asSort, j);});
      
      tL = as.numeric(lrBIG["tL", ]);
      tR = as.numeric(lrBIG["tR", ]);

      loghLR = as.numeric(lrBIG["loghLR", ]);
      hLR = exp(loghLR);
      pvalLR = as.numeric(lrBIG["pvalLR", ]);         
      # ................................................................................................


     
      # .............................................................................
      # . Find point of maximum separation :
      # .............................................................................
      jmin = which.min(pvalLR);
      pvalMin = pvalLR[jmin];
      # .............................................................................      

      

      # ....................................................................................................
      # . Package the results :
      # ....................................................................................................
      lrROC = list(n = n,
                   xiPredSort = xiPredSort,   # Predicted values, sorted in increasing order left-to-right.
                   atSort = atSort,           # Actual values, on xiPred sort key.
                   asSort = asSort,           # Actual values, on xiPred sort key.        
                   tL = tL,
                   tR = tR,
                   loghLR = loghLR,        
                   hLR = hLR,
                   pvalLR = pvalLR,
                   jmin = jmin,             # Index for maximum separation.
                   pvalMin = pvalMin);      # P-value for maximum separation.
      # .....................................................................................................

      

      # ...............
      return (lrROC);
      # ...............

}

# ==============================================================================================================
# . End of SuperPcCv.computeCoxLeftRightROC.
# ==============================================================================================================

