# =================================================================================================
# . Logistic.r : functions for logistic regression.
# . ----------  
# .              
# . start: 11-6-2011 
# =================================================================================================




# =================================================================================================
# . Logistic.plotFit : for a given logistic regression model, plots the fit.
# . ----------------
# .
# . Syntax:
# .
# .   Logistic.plotFit(modL,
# .                    flagAlt = FALSE,
# .                    axAlt = NULL,
# .                    xlab = 'prognostic index',
# .                    ylab = 'response',
# .                    caption = 'Logistic regression fit',
# .                    ncut = 5)
# .
# . In:
# .        modL = model generate by glm() on logistic regression model (see example below).
# .
# .        flagAlt = if true, plot the fit against the alternative array xalt (generally,
# .                  the raw predictor values).
# .
# .        axAlt = array with alternative values to be used on x axis.
# .
# .        xlab, ylab, caption = plot axis labels and caption.
# .
# .        ncut = number of bins in which to compute mean response data.
# .
# .................................................................................................
# . Example:
# .
# .    library(ElemStatLearn);
# .    heartModel = glm(chd ~ sbp + tobacco + ldl + famhist + obesity +  age, 
# .                     data = SAheart, family = binomial("logit")); 
# .    Logistic.plotFit(heartModel);
# .
# .................................................................................................
# . * This is taken from Michael Crawley's R book, p.
# .
# . See also Crawley's web site : 
# . http://www.bio.ic.ac.uk/research/crawley/statistics/
# =================================================================================================

Logistic.plotFit <- function(modL,
                             flagAlt = FALSE,
                             axAlt = NULL,
                             xlab = 'prognostic index',
                             ylab = 'response',
                             caption = 'Reg. fit', ncut = 5)
{


   # .........................................................
   stopifnot(ncut >= 1);

   stopifnot(modL$method == 'glm.fit');
   stopifnot(modL$family[1] == 'binomial');
   stopifnot(modL$family[2] == 'logit');

   if (flagAlt) {
     stopifnot(!is.null(axAlt));
   }
   # ......................................................... 

   
   
   # .............................................................................................
   # . Retrieve prognostic index and observed output values :
   # .............................................................................................
   axi = modL$linear.predictors;          # Prognostic index:  xi = beta0 + beta * x
   yname = all.vars(modL$formula)[1];     # This is the response variable name,
   #xxx ar = modL$data[[yname]];          # and this is the {0, 1} response variable.
   ar = modL$y;                           # and this is the {0, 1} response variable.

   if (flagAlt) {
     nxi = length(axi);
     nalt = length(axAlt);

     if (nalt != nxi) {
       cat("ERROR: from  Logistic.plotFit:\n");
       cat("Alternative x array xalt does not have the same number of elements as in the model.\n");
       stop();
     }
   }
   # .............................................................................................


   # .............................................................................................
   # . Retrieve model coeffcients :
   # .............................................................................................
   beta0 = modL$coefficients[1];
   beta1 = modL$coefficients[2];

   sumMod = summary(modL);
   pval = sumMod$coefficients[2, 4];
   
   if (beta1 > 0) {
     sign = " + ";
   } else {
     sign = " ";
   }
   
   captionExtra = paste(":   logit(P(y = 1))  =  ",
                        format(beta0, digits = 5),
                        sign ,
                        format(beta1, digits = 5), " * x",
                        ", p-value = ", sprintf("%8.3e", pval),
                        sep = "");
   
   caption = paste(caption, captionExtra, sep = "");
   # .............................................................................................      

   
   
   # .............................................................................................
   # . Call generic plit function :
   # .............................................................................................   
   Logistic.plotFitOnArrays(axi = axi,
                            ar = ar,
                            flagAlt = flagAlt,
                            axAlt = axAlt,
                            xlab = xlab,
                            ylab = ylab,
                            caption = caption,
                            ncut = ncut);
   # .............................................................................   

   
   # .................
   return (0);
   # .................   

}

# =================================================================================================
# . End of Logistic.plotFit.
# =================================================================================================





# =================================================================================================
# . Logistic.plotFitOnArrays : for a given logistic regression model, plots the fit.
# . ------------------------   This has identical output to Logistc.plotFit(), but
# .                            takes explicit arrays as arguments rather than the glm model
# .                            object itself.
# . Syntax:
# .
# .   Logistic.plotFitOnArrays(axi, ar,
# .                            xlab = 'prognostic index',
# .                            ylab = 'response',
# .                            caption = 'Logistic regression fit',
# .                            ncut = 5)
# .
# . In:
# .         axi = array of prognostic index values. Specifically :
# .                                T
# .               xi = beta0 + beta . x
# .
# .               where beta0 = intercept term, beta = vector of coefficients, x = covariate vector.
# .
# .          ar = array of actual response values, all in {0, 1}.
# .
# .     flagAlt = if true, plot the fit against the alternative array xalt (generally,
# .               the raw predictor values).
# .
# .       axAlt = array with alternative values to be used on x axis.
# .
# .
# .        xlab, ylab, caption = plot axis labels and caption.
# .        ncut = number of bins in which to compute mean response data.
# .
# .................................................................................................
# . Example:
# .
# .    library(ElemStatLearn);
# .    heartModel = glm(chd ~ sbp + tobacco + ldl + famhist + obesity +  age, 
# .                     data = SAheart, family = binomial("logit")); 
# .    Logistic.plotFitOnArrays(heartModel);
# .
# .................................................................................................
# . * This is taken from Michael Crawley's R book, p.
# .
# . See also Crawley's web site : 
# . http://www.bio.ic.ac.uk/research/crawley/statistics/
# =================================================================================================

Logistic.plotFitOnArrays <- function(axi,
                                     ar,
                                     flagAlt = FALSE,
                                     axAlt = NULL,
                                     xlab = 'prognostic index',
                                     ylab = 'response',
                                     caption = 'Reg. fit',
                                     ncut = 5)
{


   # ................................................................................................
   stopifnot(ncut >= 1);

   n = length(axi);
   nr = length(ar);

   if (nr != n) {
     cat("ERROR: from Logistic.plotFitOnArrays:\n");
     cat("Input arrays axi and ar have different lengths.\n");
     cat("length(axi) = ", n, sep = "");
     cat("length(ar) = ", nr, sep = "");
     cat("\n");     
     stop();
   }

   msg = Cox.checkBinary(ar);  

   if (msg != 'ok') {
     cat("ERROR: from Logistic.plotFitOnArrays:\n");
     cat(msg, "\n", sep = "");
     stop();
   }

   if (flagAlt) {
     stopifnot(!is.null(axAlt));
     nalt = length(axAlt);

     if (nalt != n) {
       cat("ERROR: from  Logistic.plotFitOnArrays:\n");
       cat("Alternative x array xalt does not have the same number of elements as in the model.\n");
       stop();
     }
   }   
   # ....................................................................................................

  


   # ........................................................................
   # . Plot of response versus prognostic index
   # ........................................................................
   ay = axi;                        # These are the terms:  beta0 + beta * x
   az = 1.0  / (1.0 + exp(-ay));    # These are the response predictions.

   cs = sort(ay, index = TRUE);

   ays = ay[cs$ix];   # Sorted in increasing order.
   azs = az[cs$ix];
   ars = ar[cs$ix];

   if (flagAlt) {
     ays = axAlt[cs$ix];     # Replace by alternative values (e.g. input preditors).
     ay = axAlt;
   }
   
   plot(ays, azs, type = 'l', xlab = xlab, ylab = ylab, main = caption, ylim = c(0, 1));

   rug(jitter(ays[ars == 0]), side = 1, col = 'blue');
   rug(jitter(ays[ars == 1]), side = 3, col = 'blue');
   # .............................................................................
   # . Add binned estimates of observed mean responses :
   # .............................................................................
   acut = cut(ay, ncut);                        # Divide into ncut groups.
   atop = tapply(ar, acut, sum);                # Number of responders, group-by-group.
   abot = table(acut);                          # Total number of subjects, group-by-group.

   aP = atop / abot;                            # Binned estimates of probabilities.
   aP = as.vector(aP);                          # Cast as a vector.

   aB = tapply(ay, acut, mean);                 # Means of the corresponding prognostic indices.
   aB = as.vector(aB);                          # Cast as a vector.
 
   asigmaP = sqrt(aP * (1.0 - aP) / abot);      # Estimated sd of probability estimates.
   asigmaP = as.vector(asigmaP);                # Cast as a vector.

   aPlo = aP - asigmaP;                         # 1-sigma confidence interval.
   aPhi = aP + asigmaP;                         

   points(aB, aP, pch = 16);
   for (i in 1:ncut) {lines(c(aB[i], aB[i]), c(aPlo[i], aPhi[i]));}   # Add error bars.
   # .............................................................................

 
   
   # .................
   return (0);
   # .................   

}

# =================================================================================================
# . End of Logistic.plotFitOnArrays.
# =================================================================================================





# =================================================================================================
# . Logistic.loglik : computes the log-likelihood for a univariate logistic regression model, given
# . ---------------   a set of covariate values, the corresponding binary output variables, and a given
# .                   regression coefficient vector.
# .
# . Syntax :
# .
# .           ll = Logistic.loglik(ax, ay, abeta);
# .
# . In :
# .            ax = vector of covariate values, length n.
# .            ay = vector of binary ouptut values, length n.
# .         abeta = vector of regression coefficients, of length 2 :
# .                 abeta = (beta0, beta1)
# .
# . Out :
# .            ll = log-likelihood.
# .
# .................................................................................................
# . * Details: the log-likelihood is computed according to :
# .
# .                   n                 T            n                     T
# .     l(beta) = -  Sum  (1 - y )  beta . x   -    Sum  log(1 + exp(- beta . x ))
# .                 i = 1       i           i      i = 1                       i
# .
# .
# =================================================================================================

Logistic.loglik <- function(ax, ay, abeta)
{

     # ......................................................................
     # . Check the input values :
     # ......................................................................  
     n = length(ax);

     if (length(ay) != n) {
       cat("ERROR: from Logistic.loglik:\n");
       cat("Input vector ay not same length as ax.\n");
       stop();
     }

     if (length(abeta) != 2) {
       cat("ERROR: from Logistic.loglik:\n");
       cat("Input regression coefficient vector abeta is not of length 2.\n");
       stop();
     }

      msg = Cox.checkBinary(ay);   # Check that all values are in {0, 1}.

      if (msg != 'ok') {
       cat("ERROR: from Logistic.loglik:\n");        
        cat("For array ay:\n", sep = "");
        cat(msgBin);
        stop();
      }           
     # ......................................................................

     

     # .............................................................................
     # .Compute the log-likelihood :
     # .............................................................................     
     beta0 = abeta[1];
     beta1 = abeta[2];

     af = beta0 + beta1 * ax;                                   # Exponents.
     abuf = ifelse(af > -20, log(1.0 + exp(-af)), - af);        # Check overflow.
     ll = - sum((1.0 - ay) * af) - sum(abuf);                   # Final sum.
     # ..............................................................................     


     # ............
     return (ll);
     # ............
     
}

# =================================================================================================
# . End of Logistic.loglik.
# =================================================================================================







# =================================================================================================================
# . Logistic.fitAndPlotOnSingle : for a given series of outcomes, and a given UNIVARIATE predictor,
# . ---------------------------    this i) computes a logistic model fit, ii) computes AUC and ROC  
# .                               curves, iii) plots scatter plot, logistic model fit and ROC
# .                               curves, iv) prints out confusion matrix and main statistics.
# .                            
# . Syntax:
# .
# .    fpl =  Logistic.fitAndPlotOnSingle(ay, as, ncut = 10, caption = '', flagPlot = TRUE);
# .                      
# .
# . In:
# .           ay = array of observed binary outcome variable.
# .           as = ONE-DIMENSIONAL array of predictor variable values.
# .         ncut = number of bins in which to compute mean response data
# .                displaying logistic model fit.
# .      caption = plot caption.
# .     flagPlot = if TRUE, generate plots and display results.
# .                if FALSE, do not show plots, just return results.
# .
# . Out :
# .
# .        fpl = list, containing:
# .                - model P-value
# .                - regression coefficients
# .                - AUC estimate (plus CI).
# .                - errMAP (plus CI).
# .
# ===================================================================================================================

Logistic.fitAndPlotOnSingle <- function(ay, 
                                        as,
                                        ncut = 10,
                                        caption = '',
                                        flagPlot = TRUE)
{

      # ........................................................................
      stopifnot(ncut >= 1);

      n = length(as);
      ny = length(ay);

      if (ny != n) {
        cat("ERROR: from Logistic.fitAndPlotOnSingle:\n");
        cat("Input arrays as and ay have different lengths.\n");
        cat("length(as) = ", n, sep = "");
        cat("length(ay) = ", ny, sep = "");
        cat("\n");     
        stop();
      }

      msg = Cox.checkBinary(ay);  

      if (msg != 'ok') {
        cat("ERROR: from Logistic.fitAndPlotOnSingle:\n");
        cat(msg, "\n", sep = "");
        stop();
      }
      # ........................................................................


  
      # ....................................................................................................
      # . Logistic regression fit :
      # ....................................................................................................      
      regK = glm(ay ~ as, family = binomial("logit"));       # Logistic regression model.
      # ................................................................................
      # . Compute likelihood ratio test statistic against null model with
      # . intercept term beta0 nonzero and beta = 0, and resulting P-value.
      # ................................................................................        
      regKsum = summary(regK);

      lFull = - 0.5 * regKsum$deviance;                         # Log-likelihood for this model.
      n1 = sum(ay);                                             # Number of instances with y = 1.
      n0 = n - n1;                                              # Number of instances with y = 0.
      beta0Star = log(n1 / (n - n1));                           # Optimal beta0, when beta = 0.        
      lNull = n0 * log(n0) + n1 * log(n1) - n * log(n);         # Log-likelihood with (beta0, beta = 0).

      K = 1;                                                    # Difference in degrees of freedom.
      qR = 2.0 * (lFull - lNull);                               # Likelihood ratio statistic. 
      pR = pchisq(qR, df = K, lower.tail = FALSE);              # p-value from likelihood ratio.
      # ....................................................................................................
      # . Prognostic index for each sample :
      # ....................................................................................................            
      beta0 = regK$coefficients[1]; 
      beta1 = regK$coefficients[2]; 
      axi = beta0 + beta1 * as;                              # Prognostic index.
      # ....................................................................................................
      # . Predicted outcome under MAP assignment :
      # ....................................................................................................            
      ayPred = rep(0, times = length(ay));
      ayPred[axi >= 0] = 1;

      cm = Stat.generateBinaryConfusionMatrix(ay, ayPred);     # Confusion matrix.

      if (!flagPlot) {      
        proc = Stat.plotROCnoPlot(axi, ay, prob = 0.95);       # ROC statistics, no plot.
      }
      # ....................................................................................................


      # ..................................................................................................................
      # . PLOTS   ---     PLOTS   ---     PLOTS   ---     PLOTS   ---     PLOTS   ---     PLOTS   ---     PLOTS   ---
      # .
      # . Display plots and output numerical results :
      # ..................................................................................................................
      if (flagPlot) {
        # .......................................................................................................
        cat(" ########################################################################################### \n");
        cat(" ..........  Start plots for " , caption, "\n", sep = "");
        # .......................................................................................................   

        
        # ....................................................................................................
        # . ROC plot :
        # ....................................................................................................
        buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
        if (buf == 'q') {return('q');}

        proc = Stat.plotROC(axi, ay, prob = 0.95);               # ROC statistics.        
        # ....................................................................................................
        # . Logistic regression fit :
        # ....................................................................................................
        buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
        if (buf == 'q') {return('q');}                                                       

        captionBuf  = paste("Prognostic index : ", caption, sep = "");
        Logistic.plotFitOnArrays(axi, ay, 
                                 xlab = " PI from score",
                                 ylab = 'estimated P(y=1|x)',
                                 caption = captionBuf,
                                 ncut = ncut);
        # ....................................................................................................      
        # . Make a plot of observed outcome versus prognostic index :
        # .
        # . Retrieve values from ROC calculation :
        # .......................................................................................
        ATemp = proc$roc$auc;              # Area under the curve for optimal model.
        pvalTemp = proc$roc$pval;          # P-value for detection of y = 1 versus y = 0.
        errMAPTemp = proc$roc$errMAP;      # Error rate under MAP classification (threshold Prob = 1/2);

        ATemp = sprintf("%8.3e", ATemp);      
        pvalTemp = sprintf("%8.3e", pvalTemp);  
        errMAPTemp = sprintf("%8.3e", errMAPTemp);        
        # .......................................................................................
        # . Generate the plot :
        # .......................................................................................
        buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
        if (buf == 'q') {return('q');}                                                       

        captionBuf = paste(caption, ": actual Y versus PI: AUC = ", ATemp,
                           ", P-value = ", pvalTemp,
                           ", errMAP = ", errMAPTemp,
                           sep = "");        

        ayJitter = ay + 0.1 * (runif(length(ay)) - 0.5);   # Add vertical jitter of plus-minus 0.05.
        
        cex.main.OLD = par("cex.main");
        par(cex.main = 0.7);
        plot(axi, ayJitter, xlab = 'prognostic index', ylab = 'y values',
             main = captionBuf, pch = 19);
        abline(h = 0);
        abline(h = 1, lty = 'dashed');
        abline(v = 0);
        par(cex.main = cex.main.OLD);
        # .......................................................................................      
      
        # ..............................................................................
        # . >> Print statistics :
        # ..............................................................................
        cat("---------------------------------------------------------------\n");
        print(regKsum);

        cat("Overall model P-value: pR = ", sprintf("%8.3e", pR), "\n");
        cat("---------------------------------------------------------------\n");
        # ..............................................................................      
        # . Header :
        # ..............................................................................
        buf = paste("#", caption, "\n", sep = "");
      
        temp1 = "#Statistics for discrimination of 1 versus 0 class.\n";
        buf = paste(buf, temp1, sep = "");
        # ..............................................................................
        # . Regression coefficients :
        # ..............................................................................
        temp1 = "#Regression coefficients : xi = beta0 + beta1 * s\n";
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("beta0 = ", sprintf("%8.3e", beta0), "\n",
                      "beta1 = ", sprintf("%8.3e", beta1), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        # ..............................................................................
        # . AUC stats :
        # ..............................................................................
        temp1 = "#Area under curve (AUC) for ROC, with 95% CI :\n";
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("auc = ", sprintf("%8.3f", proc$aucStats$A), "\n",
                      "aucLo95 = ", sprintf("%8.3f", proc$aucStats$ALo), "\n",
                      "aucHi95 = ", sprintf("%8.3f", proc$aucStats$AHi), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        # ..............................................................................
        # . P-value from Wilcox test :
        # ..............................................................................
        temp1 = "#P-value for significance of discrimination :\n";
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("pval (Wilcox) = ", sprintf("%8.3e", proc$roc$pval), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        # .............................................................................
        # . Error rate :
        # .............................................................................
        temp1 = "#Error rate and S/FP rates under MAP class assignments :\n";
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("errCount = ", sprintf("%8.3e", cm$errCount), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("errMAP = ", sprintf("%8.3e", cm$errRate), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("errMAPLo95 = ", sprintf("%8.3e", cm$errRateLo95), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("errMAPHi95 = ", sprintf("%8.3e", cm$errRateHi95), "\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");                
        # .............................................................................
        # . S/FP rates under MAP class assignments :
        # .............................................................................
        temp1 = paste("S_MAP = ", sprintf("%8.3e", proc$roc$SMAP),
                      " (sensitivity in detecting class = 1 under MAP assignments)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("FP_MAP = ", sprintf("%8.3e", proc$roc$FPMAP),
                      " (FP rate in detecting class = 1 under MAP assignments)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");                
        # .............................................................................
        # . Confusion matrix :
        # .............................................................................
        temp1 = "#Confusion matrix :\n";
        buf = paste(buf, temp1, sep = "");

        temp1 = DataFrame.generateTextNum(cm$Mmarg, "%5.0f");   # Confusion matrix with margins.
        buf = paste(buf, temp1, "\n", sep = "");        
        # .............................................................................
      
        # ...............................................................
        # . Print the text here :
        # ...............................................................      
        cat(buf);
        # ...............................................................

        # .......................................................................................................
        cat(" ########################################################################################### \n");
        # .......................................................................................................
      }
      # ..................................................................................................................
      # . END OF PLOTS   ---      END OF PLOTS   ---      END OF PLOTS   ---      END OF PLOTS   ---      END OF PLOTS
      # ..................................................................................................................        


      
      # .......................................................................................................
      # . Package results :
      # .......................................................................................................
      fpl = list(pR = pR,                         # Model p-value.
                 beta0 = beta0,                   # Logistic regression coefficient.
                 beta1 = beta1,                   # Logistic regression coefficient.
                 auc = proc$aucStats$A,           # AUC estimate.
                 aucLo95 = proc$aucStats$ALo,     # AUC estimate, lower limit to 95% CI.
                 aucHi95 = proc$aucStats$AHi,     # AUC estimate, upper limit to 95% CI.
                 errMAP = cm$errRate,             # MAP(P(y|x)) error rate.
                 errMAPLo95 = cm$errRateLo95,     # MAP(P(y|x)) error rate, lower limit to 95% CI.
                 errMAPHi95 = cm$errRateHI95 );   # MAP(P(y|x)) error rate, upper limit to 95% CI.
      # .......................................................................................................               
  


      # ............
      return (fpl);
      # ............
}

# =================================================================================================================
# . End of Logistic.fitAndPlotOnSingle.
# =================================================================================================================







# =================================================================================================================
# . Logistic.fitAndPlotOnMultiple : for a given series of outcomes, and a given MULTIVARIATE predictor,
# . -----------------------------   this i) computes a logistic model fit, ii) computes AUC and ROC  
# .                                 curves, iii) plots scatter plot, logistic model fit and ROC
# .                                 curves, iv) prints out confusion matrix and main statistics.
# .                            
# . Syntax:
# .
# .      Logistic.fitAndPlotOnMultiple(ay, ax, gamma = NULL, ncut = 10, caption = '');
# .                      
# .
# . In:
# .
# .                ay = array of observed binary outcome variable (n values).
# .
# .                ax = n * p data matrix of predictor variable values, where p = number of predictors.
# .
# .           flagInt = Valid: no, yes, yesNoDirect2.
# .                     If 'yes', include 1:2 interaction term. If 'no', do not compute interaction term.
# .                     If 'yesNodirect2', generates model : y ~ ax_1 _+ ax_1 : ax_2, ignoring the
# .                     direct effect of ax_1. Both 'yes; and 'yesNoDirect2' are valid only for
# .                     p = 2.
# .
# .              ncut = number of bins in which to compute mean response data
# .                     displaying logistic model fit.
# .
# .           caption = plot caption.
# .
# .             FPref = reference value for the False-positive rate, used for a point calculations of the
# .                     corresponding sensitivity and false-discovery rates. If NULL, the point calculations
# .                     are not done. Otherwise must be in range 0 < FPref < 1.
# .                     This feature is useful for comparing different models at a fixed false-positive rate.
# .
# .            FDRref = reference value for the False-discovery rate, used for a point calculations of the
# .                     corresponding sensitivity and false-positive rates. If NULL, the point calculations
# .                     are not done. Otherwise must be in range 0 < FDRref < 1.
# .                     This feature is useful for comparing different models at a fixed FDR.

# .
# ===================================================================================================================

Logistic.fitAndPlotOnMultiple <- function(ay, 
                                          ax,
                                          flagInt = 'no', 
                                          ncut = 10,
                                          caption = '',
                                          FPref = NULL,
                                          FDRref = NULL)
{

      # ........................................................................
      stopifnot(ncut >= 1);
      stopifnot((flagInt == 'yes') || (flagInt == 'yesNoDirect2') || (flagInt == 'no'));

      if (!is.null(FPref)) {
        stopifnot((FPref > 0.0) && (FPref < 1.0));
      }

      if (!is.null(FDRref)) {
        stopifnot((FDRref > 0.0) && (FDRref < 1.0));
      }      

      if (class(ax) != 'matrix') {
        cat("ERROR: from Logistic.fitAndPlotOnMultiple:\n");
        cat("Input ax is not of class matrix.\n");
        stop();
      }
      
      n = nrow(ax);         # Number of samples.
      K = ncol(ax);         # Number of covariates.


      if ((flagInt == 'yes') || (flagInt == 'yesNoDirect2')) {
        if (K != 2) {
          cat("ERROR: from Logistic.fitAndPlotOnMultiple:\n");
          cat("Number of covariates is K = ", K, " \n");
          cat("flagInt = yes or yesNoDirect2 currently valid only for K = 2 covariates.\n");
          stop();
        }          
      }
      
      ny = length(ay);

      if (ny != n) {
        cat("ERROR: from Logistic.fitAndPlotOnMultiple:\n");
        cat("Input arrays ax and ay have different number of samples.\n");
        cat("nrow(ax) = ", n, sep = "");
        cat("length(ay) = ", ny, sep = "");
        cat("\n");     
        stop();
      }

      msg = Cox.checkBinary(ay);  

      if (msg != 'ok') {
        cat("ERROR: from Logistic.fitAndPlotOnMultiple:\n");
        cat(msg, "\n", sep = "");
        stop();
      }
      # ........................................................................


  
      # ....................................................................................................
      # . Logistic regression fit :
      # . >> Regress on each predictor separately, no interaction :
      # ....................................................................................................
      if (flagInt == 'no') {
        regK = glm(ay ~ ax, family = binomial("logit"));
      }
      # ....................................................................................................      
      # . >> Regress with interaction terms :
      # ....................................................................................................
      if (flagInt == 'yes') {
        regK = glm(ay ~ ax + ax[ , 1]:ax[ , 2], family = binomial("logit"));
      }
      # ....................................................................................................      
      # . >> Regress with interaction terms but skip direct effects from variable 2.
      # ....................................................................................................
      if (flagInt == 'yesNoDirect2') {
        regK = glm(ay ~ ax[ , 1] + ax[ , 1]:ax[ , 2], family = binomial("logit"));
      }            
      # ....................................................................................................
      # . Results :
      # ....................................................................................................      
      regKsum = summary(regK);
      print(regKsum);
      # ................................................................................
      # . Compute likelihood ratio test statistic against null model with
      # . intercept term beta0 nonzero and beta = 0.
      # ................................................................................        
      lFull = - 0.5 * regKsum$deviance;              # Log-likelihood under full model.
      n1 = sum(ay);                                  # Number of instances with y = 1.
      n0 = n - n1;                                   # Number of instances with y = 0.
      beta0Star = log(n1 / (n - n1));                # Optimal beta0, when beta = 0.        
      lNull = n0 * log(n0) + n1 * log(n1) - n * log(n);     # Log-likelihood with (beta0, beta = 0).
      #xxx temp1 = Logistic.loglik(rep(0.0, times = n), ay, abeta = c(beta0Star, 0.0));  # Same.
        
      qR = 2.0 * (lFull - lNull);                    # Likelihood ratio statistic.

      if (flagInt == 'no') {
        Kmodel = K;
      } else if (flagInt == 'yes') {
        Kmodel = K + 1;
      } else if (flagInt == 'yesNoDirect2') {
        Kmodel = K;        
      }
        
      pR = pchisq(qR, df = Kmodel, lower.tail = FALSE);   # p-value from likelihood ratio.

      df1 = regKsum$df[1];                           # Not really useful for logistic model,
      df2 = regKsum$df[2];                           # but I'm keeping for consistency.
      # ................................................................................
      # . Retrieve individual coefficients : 
      # ................................................................................        
      regKcoef = regKsum$coefficients;
      K1 = K + 1;        
        
      abetaRaw = regKcoef[ , 1];           # The K + 1 coefficients (including intercept).
      beta0 = abetaRaw[1];                 # Intercept coefficient.        
      abeta = abetaRaw[2:K1];              # Exclude the y intercept coefficient.
        
      aseBetaRaw = regKcoef[ , 2];         # Standard errors for the K + 1 coefficients.
      seBeta0 = aseBetaRaw[1];             # Standard error for intercept.        
      aseBeta = aseBetaRaw[2:K1];          # Exclude the y intercept error.
        
      apRaw = regKcoef[ , 4];              # The corresponding K + 1 P-values against beta = 0.
      pBeta0 = apRaw[1];                   # P-value for intercept.        
      ap = apRaw[2:K1];                    # Exclude the y intercept P-value.
      # ....................................................................................................
      # . For the interaction term :
      # ....................................................................................................
      if (flagInt == 'yes') {
        K2 = K + 2;
        gamma = abetaRaw[K2];
        seGamma = aseBetaRaw[K2];
        pGamma = apRaw[K2];        
      } else {
        gamma = 0.0;
        seGamma = 0.0;
        pGamma = 1.0;
      }
      # ....................................................................................................
      # . Prognostic index for each sample :
      # ....................................................................................................            
      axi = beta0 + ax %*% abeta;                              # Prognostic index.

      if (flagInt == 'yes') {
        axi = axi + gamma * ax[ , 1] * ax[ , 2];               # Add the interaction term.
      }
      # ....................................................................................................
      # . Predicted outcome under MAP assignment :
      # ....................................................................................................            
      ayPred = rep(0, times = length(ay));
      ayPred[axi >= 0] = 1;

      cm = Stat.generateBinaryConfusionMatrix(ay, ayPred);   # Confusion matrix.
      # ....................................................................................................



      # ....................................................................................................
      # . Generate the ROC on the basis of the prognostic index for this model.
      # ....................................................................................................      
      roc = Stat.basicROC(ax = axi, ac = ay,
                          flagPval = TRUE,
                          flagConfInterval = TRUE,
                          flagNormalModel = TRUE,
                          prob = 0.95);
      # ....................................................................................................
      # . If specified, do point calculations :
      # ....................................................................................................            
      if (!is.null(FPref)) {
        iref = min(which(roc$aFP <= FPref));
        S_FPref = roc$aS[iref];
        FDR_FPref = roc$aFDR[iref];
      }

      if (!is.null(FDRref)) {
        indexRef = which(roc$aFDR <= FDRref);

        if (length(indexRef) > 0) {
          iref = min(indexRef);
          S_FDRref = roc$aS[iref];
          FP_FDRref = roc$aFP[iref];
        } else {
          S_FDRref = -1;        # Indicates cannot achieve this FDR value anywhere.
          FP_FDRref = -1;
        }
      }      
      # ....................................................................................................

      

      
      
      # .......................................................................................................
      cat(" ########################################################################################### \n");
      cat(" ..........  Start plots for " , caption, "\n", sep = "");
      # .......................................................................................................   

      

      # ....................................................................................................
      # . ROC plot, with binormal approximation :
      # ....................................................................................................
      buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
      if (buf == 'q') {return('q');}                                                                                                            

      proc = Stat.plotROC(axi, ay, prob = 0.95, flagCI = 'no');
      # ....................................................................................................
      # . ROC plot, with CI for empirical distribution :
      # ....................................................................................................
      buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
      if (buf == 'q') {return('q');}                                                                                                            

      proc = Stat.plotROC(axi, ay, prob = 0.95, flagCI = 'yes');            
      # ....................................................................................................
      # . Logistic regression fit :
      # ....................................................................................................
      buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
      if (buf == 'q') {return('q');}                                                       

      captionBuf  = paste("Prognostic index : ", caption, sep = "");
      Logistic.plotFitOnArrays(axi, ay, 
                               xlab = " PI from score",
                               ylab = 'estimated P(y=1|x)',
                               caption = captionBuf,
                               ncut = ncut);
      # ....................................................................................................      
      # Make a plot of observed outcome versus prognostic index :
      # .
      # . Retrieve values from ROC calculation :
      # .......................................................................................
      ATemp = proc$roc$auc;              # Area under the curve for optimal model.
      pvalTemp = proc$roc$pval;          # P-value for detection of y = 1 versus y = 0.
      errMAPTemp = proc$roc$errMAP;      # Error rate under MAP classification (threshold Prob = 1/2);

      ATemp = sprintf("%8.3e", ATemp);      
      pvalTemp = sprintf("%8.3e", pvalTemp);  
      errMAPTemp = sprintf("%8.3e", errMAPTemp);        
      # .......................................................................................
      # . Generate the plot :
      # .......................................................................................
      buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
      if (buf == 'q') {return('q');}                                                       

      captionBuf = paste(caption, ": actual Y versus PI: AUC = ", ATemp,
                         ", P-value = ", pvalTemp,
                         ", errMAP = ", errMAPTemp,
                         sep = "");        

      ayJitter = ay + 0.1 * (runif(length(ay)) - 0.5);   # Add vertical jitter of plus-minus 0.05.
        
      cex.main.OLD = par("cex.main");
      par(cex.main = 0.7);
      plot(axi, ayJitter, xlab = 'prognostic index', ylab = 'y values',
           main = captionBuf, pch = 19);
      abline(h = 0);
      abline(h = 1, lty = 'dashed');
      abline(v = 0);
      par(cex.main = cex.main.OLD);
      # .......................................................................................


      
      # ..............................................................................
      # . >> Print statistics :
      # ..............................................................................
      cat("---------------------------------------------------------------\n");
      print(regKsum);

      cat("Overall model P-value: pR = ", sprintf("%8.3e", pR), "\n");
      cat("---------------------------------------------------------------\n");      
      # . Header :
      # ..............................................................................
      buf = paste("#", caption, "\n", sep = "");
      
      temp1 = "#Statistics for discrimination of 1 versus 0 class.\n";
      buf = paste(buf, temp1, sep = "");
      # ..............................................................................
      # . Regression coefficients :
      # ..............................................................................
      if (flagInt == 'no') {
        temp1 = "#Regression coefficients : xi = beta0 + beta * x\n";
        buf = paste(buf, temp1, sep = "");
      } else {
        temp1 = "#Regression coefficients : xi = beta0 + beta * x + gamma * x[ , 1] * x[ , 2]\n";
        buf = paste(buf, temp1, sep = "");
      }
        
      temp1 = paste("beta0 = ", sprintf("%8.3f", beta0), "\n");
      buf = paste(buf, temp1, sep = "");

      for (k in 1:K) {
        temp1 = paste("beta[", k, "] = ", sprintf("%8.3f", abeta[k]), "\n", sep = "");
        buf = paste(buf, temp1, sep = "");
      }

      if (flagInt == 'yes') {
        temp1 = paste("gamma = ", sprintf("%8.3f", gamma), "\n");
        buf = paste(buf, temp1, sep = "");
      }
      # ..............................................................................
      # . AUC stats :
      # ..............................................................................
      temp1 = "#Area under curve (AUC) for ROC, with 95% CI :\n";
      buf = paste(buf, temp1, sep = "");
        
      temp1 = paste("auc = ", sprintf("%8.3f", proc$aucStats$A), "\n",
                    "aucLo95 = ", sprintf("%8.3f", proc$aucStats$ALo), "\n",
                    "aucHi95 = ", sprintf("%8.3f", proc$aucStats$AHi), "\n",
                    sep = "");
      buf = paste(buf, temp1, sep = "");
      # ..............................................................................
      # . P-value from Wilcox test :
      # ..............................................................................
      temp1 = "#P-value for significance of discrimination :\n";
      buf = paste(buf, temp1, sep = "");
        
      temp1 = paste("pval (Wilcox) = ", sprintf("%8.3e", proc$roc$pval), "\n",
                     sep = "");
      buf = paste(buf, temp1, sep = "");
      # .............................................................................
      # . Error rate :
      # .............................................................................
      temp1 = "#Error rate and S/FP rates under MAP class assignments :\n";
      buf = paste(buf, temp1, sep = "");

      temp1 = paste("errCount = ", sprintf("%8.3e", cm$errCount), "\n",
                      sep = "");
      buf = paste(buf, temp1, sep = "");
        
      temp1 = paste("errMAP = ", sprintf("%8.3e", cm$errRate), "\n",
                    sep = "");
      buf = paste(buf, temp1, sep = "");

      temp1 = paste("errMAPLo95 = ", sprintf("%8.3e", cm$errRateLo95), "\n",
                      sep = "");
      buf = paste(buf, temp1, sep = "");

      temp1 = paste("errMAPHi95 = ", sprintf("%8.3e", cm$errRateHi95), "\n",
                      sep = "");
      buf = paste(buf, temp1, sep = "");                
      # .............................................................................
      # . S/FP rates under MAP class assignments :
      # .............................................................................
      temp1 = paste("SMAP = ", sprintf("%8.3e", proc$roc$SMAP),
                      " (sensitivity in detecting class = 1 under MAP assignments)\n",
                      sep = "");
      buf = paste(buf, temp1, sep = "");

      temp1 = paste("FPMAP = ", sprintf("%8.3e", proc$roc$FPMAP),
                      " (FP rate in detecting class = 1 under MAP assignments)\n",
                      sep = "");
      buf = paste(buf, temp1, sep = "");

      temp1 = paste("FDRMAP = ", sprintf("%8.3e", proc$roc$FDRMAP),
                      " (FDR in detecting class = 1 under MAP assignments)\n",
                      sep = "");
      buf = paste(buf, temp1, sep = "");
      # .............................................................................
      # . Point calculation based on FP, if requested :
      # .............................................................................
      if (!is.null(FPref)) {
        temp1 = "#Point calculation on FP :\n";
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("FPref = ", sprintf("%8.3e", FPref),
                      " (reference FP for detecting class = 1 for point calculation)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("S_FPref = ", sprintf("%8.3e", S_FPref),
                      " (reference S from point calculation based on FP)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("FDR_FPref = ", sprintf("%8.3e", FDR_FPref),
                      " (reference FDR from point calculation based on FP)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");                
      }
      # .............................................................................
      # . Point calculation based on FDR, if requested :
      # .............................................................................
      if (!is.null(FDRref)) {
        temp1 = "#Point calculation on FDR :\n";
        buf = paste(buf, temp1, sep = "");
        
        temp1 = paste("FDRref = ", sprintf("%8.3e", FDRref),
                      " (reference FDR for detecting class = 1 for point calculation)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("S_FDRref = ", sprintf("%8.3e", S_FDRref),
                      " (reference S from point calculation based on FDR)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");

        temp1 = paste("FP_FDRref = ", sprintf("%8.3e", FP_FDRref),
                      " (reference FP from point calculation based on FDR)\n",
                      sep = "");
        buf = paste(buf, temp1, sep = "");                
      }            
      # .............................................................................
      # . Confusion matrix :
      # .............................................................................
      temp1 = "#Confusion matrix :\n";
      buf = paste(buf, temp1, sep = "");

      temp1 = DataFrame.generateTextNum(cm$Mmarg, "%5.0f");   # Confusion matrix with margins.
      buf = paste(buf, temp1, "\n", sep = "");        
      # .............................................................................



      
      # ...............................................................
      # . Print the text here :
      # ...............................................................      
      cat(buf);
      # ...............................................................


      # .......................................................................................................
      cat(" ########################################################################################### \n");
      # .......................................................................................................         
  


      # ............
      return (0);
      # ............
}

# =================================================================================================================
# . End of Logistic.fitAndPlotOnMultiple.
# =================================================================================================================



# =================================================================================================================
# . Logistic.exploreROCmodels : simple-minded exploration of consequences of a spectrum of models with varying
# . -------------------------   AUC, where the AUC characterizes the ROC for detection of class 1 events
# .                             against class 0 events.
# .
# . Syntax :
# .
# .        Logistic.exploreROCmodels(mu0Lo, mu0Hi, sigma0, mu1, sigma1, pi1, n, FDR0, beta = 0.5, np);
# .
# . In :
# .
# .         mu0Lo = lower bound for mean for predictor for class 0.
# .         mu0Hi = upper bound for mean for predictor for class 0.
# .        sigma0 = sd for predictor for class 0.
# .           mu1 = mean for predictor for class 1.
# .        sigma1 = sd for predictor for class 1.
# .           pi1 = a priori probability of class 1 (pi0 = 1 - pi1).
# .          FDR0 = point-value for FDR.
# .          beta = weight to be given to FALSE NEGATIVES in objective function for optimizing threshold.
# .                 0 <= beta <= 1. A value of beta = 1/2 means equal weight are given to false positives
# .                 and false-negatives.
# .
# .            np = number of AUC values to be generated.
# .
# .................................................................................................................
# . >> Details :
# .
# .      * Generate np equally spaced values of mu0 spanning the indicated range mu0Lo to mu0Hi.
# .
# .      * For each value of mu0, and the other parameters (sigma0, mu1, sigma1, pi1, n) fixed,
# .        compute :
# .
# .               i) AUC
# .              ii) the sensitivity S0 and fraction of total FT0 selected by fixing the FDR = FDR0.
# .             iii) the sensitivity Sopt, fraction of total FTopt and FDR FDRopt which obtain under
# .                  optimizing (minimizing) an objective function which accounts for both false positives
# .                  and false negatives.
# .
# .
# .   The objective function used is :
# .
# .        phi(x) = (1 - beta) . pi . Fp(x)  +  beta . pi1 . (1 - S(x))
# .                             0
# .
# .   with the optimal decision threshold given by :
# .
#.               x    = argmin phi(x)
# .               opt     x
# .
# =================================================================================================================

Logistic.exploreROCmodels <- function(mu0Lo, mu0Hi, sigma0, mu1, sigma1, pi1, FDR0, beta = 0.5, np)
{

       # ........................................................
       stopifnot(mu0Lo <= mu0Hi);
       stopifnot(pi1 > 0, pi1 < 1);
       stopifnot(FDR0 > 0, FDR0 < 1);
       # ........................................................



       # ...............................................................................................
       # . Generate the input array of mu0 values :
       # ...............................................................................................
       amu0 = seq(from = mu0Lo, to = mu0Hi, length.out = np);

       NDUM = 10000;                                 # Dummy value. The CI on AUC is not needed here.
       
       ad = sapply(amu0,
                   Stat.binormalModelROC,            # This is the function we are scanning with.
                   sigma0 = sigma0,
                   mu1 = mu1,
                   sigma1 = sigma1,
                   pi1 = pi1,
                   n = NDUM,
                   FDR0 = FDR0,
                   beta = beta);

       ad  = apply(ad, 1, unlist);
       dfROC = as.data.frame(ad);
       # ...............................................................................................

       
      
       # .......................................................................................................
       cat(" ########################################################################################### \n");
       cat(" ..........  Start plots.\n", sep = "");
       # .......................................................................................................   


       
       # ....................................................................................................
       # . Thresholds as a function of AUC :
       # ....................................................................................................
       buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
       if (buf == 'q') {return('q');}                                                                                                            

       xmin = min(0.5, min(dfROC$AUCtheo));
       ymin = min(c(dfROC$x0, dfROC$xOpt, dfROC$mu0, dfROC$mu1));
       ymax = max(c(dfROC$x0, dfROC$xOpt, dfROC$mu0, dfROC$mu1));
       
       caption = paste("Thresholds as a function of AUC");
       
       plot(dfROC$AUCtheo, dfROC$x0, type = 'l', lwd = 2,
            pch = 19, col = 'gray',
            xlim = c(xmin, 1.0),
            ylim = c(ymin, ymax),
            xlab = 'AUC', ylab = 'Biomarker value',
            main = caption);

       lines(dfROC$AUCtheo, dfROC$xOpt, type = 'l', lwd = 2);       

       lines(dfROC$AUCtheo, dfROC$mu0, type = 'l', lty = 'dashed', col = 'red');
       lines(dfROC$AUCtheo, dfROC$mu0 - dfROC$sigma0, type = 'l', col = 'red');
       lines(dfROC$AUCtheo, dfROC$mu0 + dfROC$sigma0, type = 'l', col = 'red');       
       
       lines(dfROC$AUCtheo, dfROC$mu1, type = 'l', lty = 'dashed', col = 'blue');
       lines(dfROC$AUCtheo, dfROC$mu1 - dfROC$sigma1, type = 'l', col = 'blue');
       lines(dfROC$AUCtheo, dfROC$mu1 + dfROC$sigma1, type = 'l', col = 'blue');              

       abline(v = 0.5, col = 'gray');              
       # ............................................................
       # . Add legend :
       # ............................................................
       legendText = c('x0', 'xOpt', 'mu0', 'mu1');
       colVector = c('gray', 'black', 'red', 'blue');
       ltyVector = c(1, 1, 2, 2);
       lwdVector = c(2, 2, 1, 1);
       pchVector = rep(19, times = 4);

       ytemp1 = ymin + 0.3 * (ymax - ymin);
       
       legend(x = xmin, y = ytemp1,
              legend = legendText, 
              col = colVector, 
              lty = ltyVector, 
              lwd = lwdVector,
              bty = 'n');
       # ...............................................................................................


       

       # ....................................................................................................
       # . Detection for fixed FDR :
       # ....................................................................................................
       buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
       if (buf == 'q') {return('q');}                                                                                                            

       xmin = min(0.5, min(dfROC$AUCtheo));

       caption = paste("Detection for fixed FDR, FDR0 = ", FDR0, sep = "");
       
       plot(dfROC$AUCtheo, dfROC$S0, type = 'l', pch = 19,
            ylim = c(0, 1.0), xlim = c(xmin, 1.0),
            xlab = 'AUC', ylab = 'Fraction',
            main = caption,
            col = 'blue');

       lines(dfROC$AUCtheo, dfROC$FT0, type = 'l');
       lines(dfROC$AUCtheo, dfROC$FP0, type = 'l', col = 'gray');       

       abline(h = FDR0, lty = 'dashed');
       abline(v = 0.5, col = 'gray');       
       # ............................................................
       # . Add legend :
       # ............................................................
       legendText = c('Sensitivity', 'Fraction of total', 'FDR', 'FP');
       colVector = c('blue', 'black', 'black', 'gray');
       ltyVector = c(1, 1, 2, 1);
       lwdVector = c(1, 1, 1, 1);
       pchVector = rep(19, times = 4);
       
       legend(x = xmin, y = 0.95,
              legend = legendText, 
              col = colVector, 
              lty = ltyVector, 
              lwd = lwdVector,
              bty = 'n');
       # ...............................................................................................




       # ....................................................................................................
       # . Detection at optimal threshold :
       # ....................................................................................................
       buf = readline(">>Enter a carriage return to continue, q to quit: ");    # Pause.
       if (buf == 'q') {return('q');}                                                                                                            

       xmin = min(0.5, min(dfROC$AUCtheo));

       caption = paste("Detection at optimal threshold, beta = ", beta, sep = "");
       
       plot(dfROC$AUCtheo, dfROC$FDROpt, type = 'l', lty = 'dashed',
            pch = 19,
            ylim = c(0, 1.0), xlim = c(xmin, 1.0),
            xlab = 'AUC', ylab = 'Fraction selected',
            main = caption);

       lines(dfROC$AUCtheo, dfROC$FTOpt, type = 'l');
       lines(dfROC$AUCtheo, dfROC$SOpt, type = 'l', col = 'blue');
       lines(1.005 * dfROC$AUCtheo, 1.01 * dfROC$FPOpt, type = 'l', col = 'gray');   # Multipliers to offset FP from S in some places.

       abline(v = 0.5, col = 'gray');              
       # ............................................................
       # . Add legend :
       # ............................................................
       legendText = c('Sensitivity', 'Fraction of total', 'FDR', 'FP');
       colVector = c('blue', 'black', 'black', 'gray');
       ltyVector = c(1, 1, 2, 1);
       lwdVector = c(1, 1, 1, 1);
       pchVector = rep(19, times = 4);

       legend(x = xmin, y = 0.95,
              legend = legendText, 
              col = colVector, 
              lty = ltyVector, 
              lwd = lwdVector,
              bty = 'n');
       # ...............................................................................................



   


       
       

       # .......................................................................................................
       cat(" ..........  All plots done.\n", sep = "");
       cat(" ########################################################################################### \n");
       # .......................................................................................................         
       

       # ............
       return (0);
       # ............

}

# =================================================================================================================
# . End of Logistic.exploreROCmodels.
# =================================================================================================================






# =================================================================================================================
# . Logistic.simulateTrainTestPower : for a one-dimensional predictor model with binary {0, 1} outcome, does a simulation by 
# . -------------------------------   generating many train/test data sets, and evaluating detection in each case.
# .                                   Accumulates statistics and generates estimates of POWER of detection for
# .                                   both signature discovery on training set, and validation on test set.
# .                                   This guides choice of minimum number of samples required in TRAINING and TEST
# .                                   sets to achieve given powers of detection at given confidence level.
# .
# . Syntax :
# .
# .   simLog = Logistic.simulateTrainTestPower(AUC1, probR = 0.5, nTrain, nTest, L, rngSeed, alpha);
# .
# . In :
# .           AUC1 = input AUC for binormal model generating the data.
# . 
# .          probR = probability of 'responder' in {0, 1} outcome data.
# .
# .         nTrain = number of samples in training set.
# .
# .          nTest = number of samples in test set.
# .
# .              L = number of independent realizations.
# .
# .        rngSeed = initial random number seed.
# .
# .          alpha = confidence level for detection (e.g. alpha = 0.05).
# .
# . Out:
# .     simLog = list, with members :
# .
# .              AUC1 = input value.
# .            nTrain = input value.
# .             nTest = input value.
# .
# .         betaTrain = power for detecting the signature in the training set at alpha level of detection.
# .   betaTestOnTrain = power for validating the signature in the test set at alpha level of detection,
# .                     conditional on having detected it in the training set.
# .
# =================================================================================================================

Logistic.simulateTrainTestPower <- function(AUC1, probR = 0.5, nTrain, nTest, L, rngSeed, alpha)
{

     # ............................................................
     cat(" ..........  Entry in Logistic.simulateTrainTestPower.\n");
     # ............................................................
     
  
     # ..............................................................................
     # . Check on values :
     # ..............................................................................  
     stopifnot(AUC1 > 0.0, AUC1 < 1.0);
     stopifnot(probR > 0.0, probR < 1.0);
     # ..............................................................................



     # ............................................
     # . Set the RNG seed for reproducibility.
     # ............................................     
     set.seed(rngSeed);
     # ............................................


     # ..........................................................................................................
     # . Main loop :
     # ..........................................................................................................
     cat(" ..........  Start simulation loop.\n");
     
     for (l in 1:L) {
       # .............................................................................
       # . Build some models using the binormal approximation :
       # . Given the analytic formula:
       # .    
       # .                     mu1  -  mu0
       # .    AUC = pnorm( -------------------   , lower.tail = TRUE);
       # .                       2        2  1/2
       # .                 (sigma  + sigma  )
       # .                       0        1
       # .
       # . let  : mu0 = 0, sigma0 = sigma1 = 1. Then :
       # .
       # .    mu1 = sqrt(2) . qnorm(AUC, lower.tail = TRUE);
       # .
       # ...............................................................................................
       mu1 = sqrt(2) * qnorm(AUC1, lower.tail = TRUE);     # This determines mu1.
       # ...............................................................................................
       # . Generate a realization of the model.
       # . Assume a priori given probability of a responder.
       # ...............................................................................................
       nTrain1 = rbinom(n = 1, size = nTrain, prob = probR);         # Sample number of responders according to binomial distribution.
       nTrain0 = nTrain - nTrain1;                                   # Corresponding number of non-responders.
       # ...............................................................................................
       # . Generate Gaussian distributions for each population :
       # ...............................................................................................
       asTrain0 = rnorm(n = nTrain0, mean = 0.0, sd = 1.0);
       asTrain1 = rnorm(n = nTrain1, mean = mu1, sd = 1.0);
       
       asTrain = c(asTrain0, asTrain1);
       ayTrain = c(rep(0, times = nTrain0), rep(1, times = nTrain1));
       # ...............................................................................................
       # . Do a logistic regression on the data and plot the results :
       # ...............................................................................................
       fplTrain = Logistic.fitAndPlotOnSingle(ay = ayTrain, as = asTrain, ncut = 10, caption = '', flagPlot = FALSE);
       # ...............................................................................................
       # . Now generate another sampling, but this one simulating the test set :
       # ...............................................................................................
       nTest1 = rbinom(n = 1, size = nTest, prob = probR);               # Sample number of responders according to binomial distribution.
       nTest0 = nTest - nTest1;                                             # Corresponding number of no-responders.
       # ...............................................................................................
       # . Generate Gaussian distributions for the test set population :
       # ...............................................................................................
       asTest0 = rnorm(n = nTest0, mean = 0.0, sd = 1.0);
       asTest1 = rnorm(n = nTest1, mean = mu1, sd = 1.0);
       asTest = c(asTest0, asTest1);
       ayTest = c(rep(0, times = nTest0), rep(1, times = nTest1));
       # ...............................................................................................
       # . Compute the prognostic indices for the test set, using the parameters estimated from the
           # . training set :
       # ...............................................................................................
       beta0 = fpl$beta0;
       beta1 = fpl$beta1;
       axiTest = beta0 + beta1 * asTest;
       ayTestPred = ifelse(axiTest >= 0, 1, 0);   # Predictions based on MAP threshold of 0.
       # ...............................................................................................
       # . Tally confusion matrix, estimate p-value :
       # ...............................................................................................
       cmTest = Stat.generateBinaryConfusionMatrix(ayTest, ayTestPred);       # Test set confusion matrix.
       fplTest = Logistic.fitAndPlotOnSingle(ay = ayTest, as = asTest, ncut = 10, caption = '', flagPlot = FALSE);       
       # ...............................................................................................
       # . Package the results for this realization :
       # ...............................................................................................
       dfBuf = data.frame("aucTrue" = AUC1,
                          "nTrain" = nTrain,
                          "nTest" = nTest,
                          "aucTrain" = fplTrain$auc,
                          "pvalTrain" = fplTrain$pR,
                          "errMAPTrain" = fpl$errMAP,
                          "aucTest" = fplTest$auc,
                          "errMAPTest" = cmTest$errRate,
                          "pvalTest" = cmTest$pval);
         
       if (l == 1) {
         dfX = dfBuf;
       } else {
         dfX = rbind(dfX, dfBuf);
       }
       # ...............................................................................................
       # . Progress :
       # ...............................................................................................
       if (l%%50 == 0) {
         cat("Processed ", l, " realizations out of ", L, " so far.\n", sep = "");
       }
       # ...............................................................................................              
     }

     cat(" ..........  Simulation loop done.\n");     
     # ..........................................................................................................



     # ..........................................................................................................
     # . Analyze the data matrix :
     # ..........................................................................................................
     maskTrain = (dfX$pvalTrain <= alpha);
     lTrainPassed = sum(maskTrain);                     # Number of training set realizations scoring significantly at this confidence level.
     betaTrain = lTrainPassed / L;                      # Power of detecting AUC = AUC1.
     dfY = dfX[maskTrain, ];                            # Subset to passed models.
     
     maskTest = (dfY$pvalTest <= alpha);            
     lTestPassed = sum(maskTest);                       # Number of test set realizations scoring significantly, conditional on training set passed.
     betaTestOnTrain = lTestPassed / lTrainPassed;      # Power of confirming AUC > 1/2 in test set, conditional on training set passed.
     # ..........................................................................................................


     # ..........................................................................................................
     # . Print results here :
     # ..........................................................................................................     
     cat("AUC1\tnTrain\tnTest\tbetaTrain\tbetaTestOnTrain\n");
     cat(AUC1, "\t", nTrain, "\t", nTest, "\t", sprintf("%8.3e", betaTrain), "\t", sprintf("%8.3e", betaTestOnTrain), "\n", sep = "");
     # ..........................................................................................................          

     
     # ..........................................................................................................
     # . Package the results here :
     # ..........................................................................................................
     simLog = list(AUC1 = AUC1,
                   nTrain = nTrain,
                   nTest = nTest,
                   betaTrain = betaTrain,
                   betaTestOnTrain = betaTestOnTrain);
     # ..........................................................................................................          
     


     # ...............
     return (simLog);
     # ...............
     
}

# =================================================================================================================
# . End of Logistic.simulateTrainTestPower.
# =================================================================================================================







# =================================================================================================================
# . Logistic.computeModelPvalue : computes the overall model P-value from a glm fit.
# . ---------------------------   
# .
# . Syntax :
# .
# .     pR = Logistic.computeModelPvalue(regK);
# .
# . In :
# .
# .    regK = object returned by function glm().
# .
# . Out:
# .
# .      pR = model P-value, computed using likelihood ratio test.
# .
# .................................................................................................................
# . * Example :
# .
# .          regK = glm(ay ~ ax + as.factor(ac) + ax:as.factor(ac), family = binomial("logit"));
# .          pval = Logistic.computeModelPvalue(regK);
# .
# =================================================================================================================

Logistic.computeModelPvalue <- function(regK)
{


      # ......................................................................................................
      # . Generate summary from model object :
      # ......................................................................................................        
      regKsum = summary(regK);
      # ......................................................................................................
      # . Detailed calculation using explicit outcome data & degrees of freedom for model :
      # . I'm leaving these in here for reference.
      # .
      # .  n = length(ay);                                                                                    
      # .  lFull = - 0.5 * regKsum$deviance;                     # Log-likelihood under full model.                  
      # .  n1 = sum(ay);                                         # Number of instances with r = 1.                   
      # .  n0 = n - n1;                                          # Number of instances with r = 0.                   
      # .  beta0Star = log(n1 / (n - n1));                       # Optimal beta0, when beta = 0.                     
      # .  lNull = n0 * log(n0) + n1 * log(n1) - n * log(n);     # Log-likelihood with (beta0, beta = 0).     
      # .                                                                                                     
      # .  qR = 2.0 * (lFull - lNull);                           # Likelihood ratio statistic.                       
      # .  Kmodel = 5;                                                                                        
      # ......................................................................................................      
      qR = regKsum$null.deviance - regKsum$deviance;        
      Kmodel = regKsum$df.null - regKsum$df.residual;
      pR = pchisq(qR, df = Kmodel, lower.tail = FALSE);   # p-value from likelihood ratio test.
      # ......................................................................................................


      # .............
      return (pR);
      # .............      

}

# =================================================================================================================
# . End of Logistic.computeModelPvalue.
# =================================================================================================================






# =================================================================================================================
# . Logistic.fitTrainTest : for given training and test sets, computes a mutivariate logistic model
# . ---------------------   (with only direct effects) on the training set, then evaluates performace (AUC, S, FDR)
# .                         on the test set.
# .                            
# . Syntax:
# .
# .             fl =  Logistic.fitTrainTest(ax1, ay1, ax2, ay2, p1C = 0.5);
# .                      
# .
# . In:
# .
# .                ax1 = {n1 * K} data matrix of co-variates, where K = number of 
# .                      features : training set.
# .
# .                ay1 = n1 array of corresponding binary outcomes : training set.
# .
# .                ax2 = {n2 * K} data matrix of co-variates, where K = number of 
# .                      features : test set.
# .
# .                ay2 = n2 array of corresponding binary outcomes : test set.
# .
# .                p1C = probability decision threshold. If P(y = 1|x) >= p1C,
# .                      then outcome is predicted to be 1, otherwise 0.
# .                      Valid: 0 < p1C < 1.
# .
# ===================================================================================================================

Logistic.fitTrainTest <- function(ax1,
                                  ay1,
                                  ax2,
                                  ay2,
                                  p1C = 0.5)
{

      # ......................................................................................
      # . Check on values and consistency :
      # ......................................................................................
      stopifnot(p1C > 0.0, p1C < 1.0);
      
      if (class(ax1) != 'matrix') {
        cat("ERROR: from Logistic.fitTrainTest:\n");
        cat("Input ax1 is not of class matrix.\n");
        stop();
      }

      if (class(ax2) != 'matrix') {
        cat("ERROR: from Logistic.fitTrainTest:\n");
        cat("Input ax1 is not of class matrix.\n");
        stop();
      }
      # ......................................................................................
      # . Training set :
      # ......................................................................................        
      n1 = nrow(ax1);         # Number of samples in training set.
      K1 = ncol(ax1);         # Number of covariates in training set.
      ny1 = length(ay1);

      if (ny1 != n1) {
        cat("ERROR: from Logistic.fitTrainTest:\n");
        cat("Input arrays ax1 and ay1 have different number of samples.\n");
        stop();
      }

      msg = Cox.checkBinary(ay1);  

      if (msg != 'ok') {
        cat("ERROR: from Logistic.fitTrainTest:\n");
        cat(msg, "\n", sep = "");
        stop();
      }
      # ......................................................................................
      # . Test set :
      # ......................................................................................        
      n2 = nrow(ax2);         # Number of samples in training set.
      K2 = ncol(ax2);         # Number of covariates in training set.
      ny2 = length(ay2);

      if (ny2 != n2) {
        cat("ERROR: from Logistic.fitTrainTest:\n");
        cat("Input arrays ax2 and ay2 have different number of samples.\n");
        stop();
      }

      msg = Cox.checkBinary(ay2);  

      if (msg != 'ok') {
        cat("ERROR: from Logistic.fitTrainTest:\n");
        cat(msg, "\n", sep = "");
        stop();
      }
      # ......................................................................................
      # . Training and test sets :
      # ......................................................................................
      if (K2 != K1) {
        cat("ERROR: from Logistic.fitTrainTest:\n");
        cat("Input arrays ax1 and ax2 have different number of covariates.\n");
        stop();
      }

      K = K1;                                               # Number of covariates.
      # ......................................................................................


  
      # ....................................................................................................
      # . Logistic regression fit using the training set :
      # ....................................................................................................
      regK = glm(ay1 ~ ax1, family = binomial("logit"));
      # ....................................................................................................
      # . Results :
      # ....................................................................................................      
      regKsum = summary(regK);
      #xxx print(regKsum);                                              # For debugging only.
      # ....................................................................................................
      # . Compute likelihood ratio test statistic against null model with
      # . intercept term beta0 nonzero and beta = 0.
      # ....................................................................................................
      lFull = - 0.5 * regKsum$deviance;                                 # Log-likelihood under full model.
      n1_1 = sum(ay1);                                                  # Number of instances with y = 1.
      n1_0 = n1 - n1_1;                                                 # Number of instances with y = 0.
      beta0Star = log(n1_1 / (n1 - n1_1));                              # Optimal beta0, when beta = 0.        
      lNull = n1_0 * log(n1_0) + n1_1 * log(n1_1) - n1 * log(n1);       # Log-likelihood with (beta0, beta = 0).
      #xxx temp1 = Logistic.loglik(rep(0.0, times = n), ay, abeta = c(beta0Star, 0.0));  # Same.
        
      qR = 2.0 * (lFull - lNull);                                       # Likelihood ratio statistic.
      Kmodel = K;
        
      pR = pchisq(qR, df = Kmodel, lower.tail = FALSE);                 # p-value from likelihood ratio.

      df1 = regKsum$df[1];                                              # Not really useful for logistic model,
      df2 = regKsum$df[2];                                              # but I'm keeping for consistency.
      # ....................................................................................................
      # . Retrieve individual coefficients : 
      # ....................................................................................................
      regKcoef = regKsum$coefficients;
      K1 = K + 1;        
        
      abetaRaw = regKcoef[ , 1];                     # The K + 1 coefficients (including intercept).
      beta0 = abetaRaw[1];                           # Intercept coefficient.        
      abeta = abetaRaw[2:K1];                        # Exclude the y intercept coefficient.
        
      aseBetaRaw = regKcoef[ , 2];                   # Standard errors for the K + 1 coefficients.
      seBeta0 = aseBetaRaw[1];                       # Standard error for intercept.        
      aseBeta = aseBetaRaw[2:K1];                    # Exclude the y intercept error.
        
      apRaw = regKcoef[ , 4];                        # The corresponding K + 1 P-values against beta = 0.
      pBeta0 = apRaw[1];                             # P-value for intercept.        
      ap = apRaw[2:K1];                              # Exclude the y intercept P-value.
      # ....................................................................................................


      
      # ....................................................................................................      
      # . Prognostic index for each sample in the test set.
      # ....................................................................................................            
      axi2 = beta0 + ax2 %*% abeta;                           # Prognostic indices for the test set.
      # ....................................................................................................            
      # . Test set predicted outcomes :
      # ....................................................................................................
      xiC = log(p1C / (1.0 - p1C));                           # logit() of the decision threshold p1C.
      ayPred = rep(0, times = length(ay2));
      ayPred[axi2 >= xiC] = 1;

      cm = Stat.generateBinaryConfusionMatrix(ay2, ayPred);   # Confusion matrix calculation.

      Mmarg = cm$Mmarg;                                       # {input * output} confusion matrix with margins.

      S_c = Mmarg[2, 2] / Mmarg[2, 3];                        # Sensitivity at the given threshold.

      if (Mmarg[3, 2] > 0) {
        FDR_c = Mmarg[1, 2] / Mmarg[3, 2];                    # FDR at the given threshold.
      } else {
        FDR_c = 0.0;                                          # Nothing detected, so zero FDR.   
      }

      Fsel_c = Mmarg[3, 2] / Mmarg[3, 3];                     # Fraction of total selected as positives (TP + FP).
      # ....................................................................................................
      # . Generate the ROC on the basis of the prognostic index for this model.
      # ....................................................................................................      
      roc = Stat.basicROC(ax = axi2, ac = ay2,
                          flagPval = TRUE,
                          flagConfInterval = TRUE,
                          flagNormalModel = TRUE,
                          prob = 0.95);

      auc = roc$auc;                                  # AUC.
      S_MAP = roc$SMAP;                               # S for MAP decision (p1C = 0.5).
      FDR_MAP = roc$FDRMAP;                           # FDR for MAP decision (p1C = 0.5).      
      # ....................................................................................................

      

      # ....................................................................................................
      # . ROC plot, with binormal approximation : for debugging only.
      # ....................................................................................................
      ## buf = readline(">>Enter a carriage return to continue, q to quit: ");
      ## if (buf == 'q') {return('q');}
      
      ## proc = Stat.plotROC(axi2, ay2, prob = 0.95, flagCI = 'no'); 
      # ....................................................................................................



      # .......................................................................................
      # . Package results :
      # .......................................................................................
      fl = list('auc'     = auc,                    # Area under the curve.
                'p1C'     = p1C,                    # Threshold used for determining S and FDR.
                'S_c'     = S_c,                    # Sensitivity at declared threshold p1C.
                'FDR_c'   = FDR_c,                  # FDR at declared threshold p1C.
                'Fsel_c'  = Fsel_c,                 # Fraction selected as positives at p1C (TP + FP).        
                'S_MAP'   = S_MAP,                  # Sensitivity at MAP threshold p1C = 0.5.
                'FDR_MAP' = FDR_MAP);               # FDR at MAP threshold p1C = 0.5.
      # .......................................................................................      
      

      # ............
      return (fl);
      # ............
}

# =================================================================================================================
# . End of Logistic.fitTrainTest.
# =================================================================================================================






# =================================================================================================================
# . Logistic.fitTrainTestLoop : resamples a larger data matrix into train/test subsets multiple times;
# . -------------------------   evaluates multivariate classifier performance.
# .                            
# . Syntax:
# .
# .           pr =  Logistic.fitTrainTestLoop(dfY,
# .                                           ay,
# .                                           ntrain,
# .                                           ntest,
# .                                           nresamp,
# .                                           rngSeed = 123456,
# .                                           p1C = 0.5,
# .                                           flagPlot = FALSE,
# .                                           captionStem = '');
# .                      
# .
# . In:
# .
# .                dfY = {n * K} data matrix of co-variates, where K = number of 
# .                      features.
# .
# .                ay = n array of corresponding binary outcomes.
# .
# .            ntrain = number of training set instances in each realization.
# .
# .             ntest = number of test set instances in each realization.
# .
# .           nresamp = number of resampling steps.
# .
# .           rngSeed = random number seed.
# .
# .               p1C = probability decision threshold. If P(y = 1|x) >= p1C,
# .                     then outcome is predicted to be 1, otherwise 0.
# .                     Valid: 0 < p1C < 1.
# .
# .          flagPlot = if TRUE, make plots after processing is done.
# .
# .       captionStem = stem for caption texts in plots. Ignored if flagPlot = FALSE.
# .
# ===================================================================================================================

Logistic.fitTrainTestLoop <- function(dfY,
                                      ay,
                                      ntrain,
                                      ntest,
                                      nresamp,
                                      rngSeed = 123456,
                                      p1C = 0.5,
                                      flagPlot = FALSE,
                                      captionStem = '')
{

      # ......................................................................................
      # . Check on values and consistency :
      # ......................................................................................
      stopifnot(p1C > 0.0, p1C < 1.0);
      # ......................................................................................
      # . Training set :
      # ......................................................................................        
      n = nrow(dfY);         # Number of samples.
      K = ncol(dfY);         # Number of covariates.
      ny = length(ay);

      if (ny != n) {
        cat("ERROR: from Logistic.fitTrainTestLoop:\n");
        cat("Input dfY and ay have different number of samples.\n");
        stop();
      }

      msg = Cox.checkBinary(ay);  

      if (msg != 'ok') {
        cat("ERROR: from Logistic.fitTrainTestLoop:\n");
        cat(msg, "\n", sep = "");
        stop();
      }

      stopifnot(ntrain < n);
      stopifnot(ntest < n);      
      stopifnot(ntrain + ntest <= n);            
      # ......................................................................................
      



      # ................................................................................................
      # . Resampling loop here :
      # ................................................................................................
      cat(" ..........  Begin resampling loop.\n");
      
      set.seed(rngSeed);
      index0 = 1:n;
      indexOut = c();                      # Tally training sets with all the same outcomes & which are excluded.
      flagInitialize = TRUE;
      
      for (i in 1:nresamp) {
        # ...............................................................................................
        # . Generate train and test sets :
        # ...............................................................................................        
        indexTrain = sample(index0, ntrain);

        indexBuf = setdiff(index0, indexTrain);    # Exclude the samples already taken for the training set.
        indexTest = sample(indexBuf, ntest);

        ax1 = as.matrix(dfY[indexTrain, ]);
        ay1 = ay[indexTrain];

        ax2 = as.matrix(dfY[indexTest, ]);
        ay2 = ay[indexTest];
        # ...............................................................................................
        # . Skip instances where all outcome values are identical or where there are to few instances
        # . of 0 or 1 to be processed :
        # ...............................................................................................
        flagSame = (min(ay1) == max(ay1)) || (min(ay2) == max(ay2));
        flagBuf1 = (min(table(ay1)) < 2);
        flagBuf2 = (min(table(ay2)) < 2);
        flagSame = flagSame | flagBuf1 | flagBuf2;

        if (flagSame) {
          indexOut = c(indexOut, i);
          next;
        }
        # ...............................................................................................
        # . Compute model :
        # ...............................................................................................
        fl =  Logistic.fitTrainTest(ax1, ay1, ax2, ay2, p1C = 0.5);
        # ...............................................................................................
        # . Gather stats to main results matrix :
        # ...............................................................................................
        afl = unlist(fl);
        
        if (flagInitialize) {
          matR = matrix(0.0, nrow = nresamp, ncol = length(afl));
          colnames(matR) = names(fl);
          flagInitialize = FALSE;          
        }

        matR[i, ] = afl;
        # ...............................................................................................
        # . Report progress :
        # ...............................................................................................
        if (i%%400 == 0) {
          cat("Processed ", i, " steps out of ", nresamp, "\n", sep = "");
        }
        # ...............................................................................................                
      }

      cat(" ..........  End of resampling loop.\n");
      # .................................................................................................


      
      # .................................................................................................
      # . Adjust for 'dud' training sets, which were skipped :
      # .................................................................................................      
      nout = length(indexOut);

      if (nout > 0) {
        cat(" ..........  Exclude ", nout, " dud training sets from final tally.\n", sep = "");
        matR = matR[-indexOut, ];
      }
      # .................................................................................................

      
      
      # .................................................................................................
      # . Generate summary stats :
      # .................................................................................................
      aS = matR[  , "S_c"];
      aFDR = matR[  , "FDR_c"];
      aFsel = matR[  , "Fsel_c"];
      
      Slo_95 = quantile(aS, probs = 0.025);
      Smed = quantile(aS, probs = 0.5);
      Shi_95 = quantile(aS, probs = 0.975);

      FDRlo_95 = quantile(aFDR, probs = 0.025);
      FDRmed = quantile(aFDR, probs = 0.5);
      FDRhi_95 = quantile(aFDR, probs = 0.975);

      Fsello_95 = quantile(aFsel, probs = 0.025);
      Fselmed = quantile(aFsel, probs = 0.5);
      Fselhi_95 = quantile(aFsel, probs = 0.975);      
      # .................................................................................................
      # . Find the intrinsic, 'over' dispersion in FDR, beyond the extrinsic dispertion due
      # . to binomial sampling :
      # .................................................................................................
      sigFDR.mad = mad(aFDR);
      varFDR.mad = sigFDR.mad^2;
      varFDR.bin = (1 / ntest) * FDRmed * (1.0 - FDRmed);

      temp1 = varFDR.mad - varFDR.bin;
      varfOver = sqrt(ntest / (ntest - 1)) * max(temp1, 0.0);
      sigfOver = sqrt(varfOver);
      # .................................................................................................                  
      



      # ...................................................................................................
      # . Plots here :
      # ...................................................................................................
      if (flagPlot) {
        # .................................................................................................
        # . Scatter plot of the predictors, if there are only two :
        # .................................................................................................
        if (ncol(dfY) == 2) {
          Util.readLine();

          gene1 = colnames(dfY)[1];
          gene2 = colnames(dfY)[2];

          acol = ifelse(ay == 1, 'blue', 'brown');          
          caption = paste(captionStem, " : predictors (n = ", n, ") - brown = 0, blue = 1.", sep = "");
          xlab = paste('log2(', gene1, ")", sep = "");
          ylab = paste('log2(', gene2, ")", sep = "");          

          plot(as.numeric(dfY[ , 1]),
               as.numeric(dfY[  , 2]),
               pch = 19,
               xlab = xlab,
               ylab = ylab,
               main = caption,
               col = acol);
        }
        # .................................................................................................
        # . Boxplots for auc, S, FDR :
        # .................................................................................................
        Util.readLine();
        
        caption = paste(captionStem, " : ntrain = ", ntrain,
                        ", ntest = ", ntest,
                        ", p1C = ", p1C,
                        ", nresamp = ", nresamp, sep = "");
        boxplot(matR[ , c("auc", "S_c", "FDR_c", "Fsel_c")],
                ylim = c(0, 1),
                main = caption);
        # .................................................................................................
        # . Scatter plot, S versus FDR :
        # .................................................................................................
        Util.readLine();
        
        caption = paste(captionStem, " : ntrain = ", ntrain,
                        ", ntest = ", ntest,
                        ", p1C = ", p1C,
                        ", nresamp = ", nresamp, sep = "");
        plot(aFDR, aS, pch = 19, xlab = 'FDR', ylab = 'S',
             xlim = c(0, 1), ylim = c(0, 1),
             main = caption);
        # .................................................................................................
        # . Scatter plot, Fsel versus FDR :
        # .................................................................................................
        Util.readLine();
        
        caption = paste(captionStem, " : ntrain = ", ntrain,
                        ", ntest = ", ntest,
                        ", p1C = ", p1C,
                        ", nresamp = ", nresamp, sep = "");
        plot(aFDR, aFsel, pch = 19, xlab = 'FDR', ylab = 'Fsel',
             xlim = c(0, 1), ylim = c(0, 1),
             main = caption);
        # .................................................................................................
        # . Distribution of FDR :
        # .................................................................................................
        Util.readLine();

        if (length(aFDR) <= 500) {
          nb = 20;
        } else {
          nb = 50;
        }

        FDR_095 = quantile(aFDR, probs = 0.95);
        
        caption = paste(captionStem, " : ntrain = ", ntrain,
                        ", ntest = ", ntest,
                        ", p1C = ", p1C,
                        ", nresamp = ", nresamp, " (95% level)", sep = "");        
        hist(aFDR, breaks = nb, xlab = 'FDR', main = caption);
        abline(v = FDR_095, lty = 'dashed');
        # .................................................................................................
        # . Distribution of FDR, with superimposed binomial distribution :
        # .................................................................................................
        Util.readLine();

        if (length(aFDR) <= 500) {
          nb = 20;
        } else {
          nb = 50;
        }
        # ...................................................................................................................
        # . How much of this is due to binomial sampling variance?
        # ...................................................................................................................
        caption = paste(captionStem, " : ntrain = ", ntrain,
                        ", ntest = ", ntest,
                        ", p1C = ", p1C,
                        ", nresamp = ", nresamp, sep = "");
        caption = paste(caption, "\n[overdisperion: sigfOver = ", sprintf("%6.3e", sigfOver), sep = "");
        
        barx = hist(afdr, 
                    breaks = nb,
                    xlab = 'FDR',
  		    main = caption);


        ap.bin = dbinom(0:ntest, ntest, FDRmed);
        af.bin = 0:ntest / ntest;

        par(new = TRUE);
        plot(af.bin , 
             ap.bin, 
 	     type = 'l',
             lwd = 2,
  	     col = 'red', 
	     xlim = c(0, max(barx$breaks)), 
	     xaxt = 'n', yaxt = 'n',
	     xlab = '', ylab = '');
        # ..............................................................................................
        # . Legend :
        # ..............................................................................................
        legendText = c('binomial distribution\n using median FDR');
        colVector = c('red');
        ltyVector = c(1);
        lwdVector = c(2);
        pchVector = c(19);
      
        legend(x = 0.7 * max(barx$breaks),
               y = max(ap.bin),
               cex = 1.0,
               legend = legendText, 
 	       lty = ltyVector,
               col = colVector,
               bty = 'n',
               title = '');
        # .................................................................................................                
      }
      # ...................................................................................................
      



      # .......................................................................................
      # . Package results :
      # .......................................................................................
      pr = list(n         = n,
                K         = K,
                ntrain    = ntrain,
                ntest     = ntest,
                p1C       = p1C,
                nresamp   = nresamp,
                matR      = matR,             # Matrix with all individual resampling results.
                Slo_95    = Slo_95,
                Smed      = Smed, 
                Shi_95    = Shi_95,
                FDRlo_95  = FDRlo_95,
                FDRmed    = FDRmed,
                FDRhi_95  = FDRhi_95,
                Fsello_95 = Fsello_95,
                Fselmed   = Fselmed, 
                Fselhi_95 = Fselhi_95);
      # .......................................................................................      
      

      # ............
      return (pr);
      # ............
}

# =================================================================================================================
# . End of Logistic.fitTrainTestLoop.
# =================================================================================================================








# =================================================================================================================
# . Logistic.fitTrainTestLoopDriver : implements a 'superloop' around the function Logistic.fitTrainTestLoop()
# . -------------------------------   to explore a range of ntrain or ntest values.
# .                            
# . Syntax:
# .
# .           cr =  Logistic.fitTrainTestLoopDriver(dfY,
# .                                                 ay,
# .                                                 flagMode,
# .                                                 ntrainIn,
# .                                                 ntestIn,
# .                                                 antrain,
# .                                                 antest,
# .                                                 nresamp,
# .                                                 rngSeed = 123456,
# .                                                 p1C = 0.5,
# .                                                 flagPlot = FALSE,
# .                                                 captionStem = '');
# .                      
# .
# . In:
# .
# .                dfY = {n * K} data matrix of co-variates, where n = samples and 
# .                      K = number of genes.
# .
# .                ay = n array of corresponding binary outcomes.
# .
# .          flagMode = 'scanTrain', 'scanTest'.
# .
# .          ntrainIn = number of training set instances in each realization.
# .                     Used if flagMode = 'scanTest', ignored otherwise.
# .
# .           ntestIn = number of test set instances in each realization.
# .                     Used if flagMode = 'scanTrain', ignored otherwise.
# .
# .           antrain = array of ntrain values to be used.
# .                     Used if flagMode = 'scanTrain', ignored otherwise.
# .
# .            antest = array of ntest values to be used.
# .                     Used if flagMode = 'scanTest', ignored otherwise.
# .
# .           nresamp = number of resampling steps.
# .
# .           rngSeed = random number seed.
# .
# .               p1C = probability decision threshold. If P(y = 1|x) >= p1C,
# .                     then outcome is predicted to be 1, otherwise 0.
# .                     Valid: 0 < p1C < 1.
# .
# .          flagPlot = if TRUE, make plots after processing is done.
# .
# .       captionStem = stem for caption texts in plots. Ignored if flagPlot = FALSE.
# .
# ===================================================================================================================

Logistic.fitTrainTestLoopDriver <- function(dfY,
                                            ay,
                                            flagMode,
                                            ntrainIn,
                                            ntestIn,
                                            antrain,
                                            antest,                                            
                                            nresamp,
                                            rngSeed = 123456,
                                            p1C = 0.5,
                                            flagPlot = FALSE,
                                            captionStem = '')
{

      # ............................................................................................
      # . Check on values and consistency :
      # ............................................................................................
      stopifnot(p1C > 0.0, p1C < 1.0);
      stopifnot((flagMode == 'scanTrain') || (flagMode == 'scanTest'));
      # ............................................................................................
      # . Training set :
      # ............................................................................................  
      n = nrow(dfY);         # Number of samples.
      K = ncol(dfY);         # Number of covariates.
      ny = length(ay);

      if (ny != n) {
        cat("ERROR: from Logistic.fitTrainTestLoopDriver:\n");
        cat("Input dfY and ay have different number of samples.\n");
        stop();
      }

      msg = Cox.checkBinary(ay);  

      if (msg != 'ok') {
        cat("ERROR: from Logistic.fitTrainTestLoopDriver:\n");
        cat(msg, "\n", sep = "");
        stop();
      }
      # ............................................................................................
      # . Check on sample sizes :
      # ............................................................................................
      if (flagMode == 'scanTrain') {
        anbuf = ntestIn + antrain;

        if (max(anbuf) > n) {
          cat("ERROR: from Logistic.fitTrainTestLoopDriver:\n");
          cat("Some value(s) in antrain are too large: ntestIn + ntrain > total number of samples.\n");
          stop();
        }
      }

      if (flagMode == 'scanTest') {
        anbuf = ntrainIn + antest;

        if (max(anbuf) > n) {
          cat("ERROR: from Logistic.fitTrainTestLoopDriver:\n");
          cat("Some value(s) in antest are too large: ntrianIn + ntest > total number of samples.\n");
          stop();
        }
      }      
      # ............................................................................................
      

      
      # ...............................................
      cat(" ..........  Begin scan loop.\n");
      # ...............................................      

      

      # ................................................................................................
      # . Resampling loop here :
      # .
      # . >> 1. scanTrain :
      # ................................................................................................
      if (flagMode == 'scanTrain') {
        i = 1;
        iall = length(antrain);
        ta = proc.time()[3];
        
        for (ntrain in antrain) {
          cat("#######################################################################################################\n");
          cat("Processing for ntrain = ", ntrain, " (step ", i, " out of ", iall, ").\n", sep = "");

          pr =  Logistic.fitTrainTestLoop(dfY = dfY, 
                                          ay = ay, 
                                          ntrain = ntrain,
                                          ntest = ntestIn,
                                          nresamp = nresamp,
                                          rngSeed = rngSeed, 
	   			          p1C = p1C,
				          flagPlot = FALSE,
				          captionStem = captionStem);

          indexBuf = grep("^ntrain|^S|^FDR|^Fsel", names(pr))
          prBuf = pr[indexBuf];
          prBuf1 = unlist(prBuf);
          names(prBuf1) = names(prBuf);
          prBuf2 = t(as.matrix(prBuf1))

          if (i == 1) {
            dfR = as.data.frame.matrix(prBuf2);
          } else {
            dfR = rbind(dfR, prBuf2);
          }

          i = i + 1;
          cat("#######################################################################################################\n\n");
        }

        tb = proc.time()[3] - ta;	# Time in seconds.
        t1 = tb / iall;                 # Time per level.        
      }
      # ................................................................................................
      # . >> 2. scanTest :
      # ................................................................................................
      if (flagMode == 'scanTest') {        
        i = 1;
        iall = length(antest);
        ta = proc.time()[3];
        
        for (ntest in antest) {
          cat("#######################################################################################################\n");
          cat("Processing for ntest = ", ntest, " (step ", i, " out of ", iall, ").\n", sep = "");

          pr =  Logistic.fitTrainTestLoop(dfY = dfY,
                                          ay = ay,
                                          ntrain = ntrainIn,
                                          ntest = ntest, 
                                          nresamp = nresamp,
                                          rngSeed = rngSeed,
   				          p1C = p1C,
				          flagPlot = FALSE,
				          captionStem = captionStem);

          indexBuf = grep("^ntest|^S|^FDR|^Fsel", names(pr))
          prBuf = pr[indexBuf];
          prBuf1 = unlist(prBuf);
          names(prBuf1) = names(prBuf);
          prBuf2 = t(as.matrix(prBuf1))

          if (i == 1) {
            dfR = as.data.frame.matrix(prBuf2);
          } else {
            dfR = rbind(dfR, prBuf2);
          }

          i = i + 1;
          cat("#######################################################################################################\n\n");
        }

        tb = proc.time()[3] - ta;	# Time in seconds.
        t1 = tb / iall;                 # Time per level.
      }
      # ................................................................................................      

      

      # ................................................................................
      cat(" ..........  End of scan loop.\n");
      cat("             Total time = ", tb, " s.\n", sep = "");
      cat("             Time per level = ", format(t1, digit = 3), " s.\n", sep = "");      
      # ................................................................................
      
      
        
      # ...................................................................................................
      # . Plots here :
      # ...................................................................................................
      if (flagPlot) {
        # .................................................................................................
        # . Plot dependencies of performance metrics :
        # .................................................................................................
        Util.readLine();
        # .................................................................................................
        # . Scan ntrain :
        # .................................................................................................
        if (flagMode == 'scanTrain') {        
          par(mfrow = c(2, 2));
          caption = "Sensitivity";
          plot(dfR$ntrain, dfR$Smed, type = 'l', ylim = c(0, 1), xlab = 'ntrain', ylab = 'Sensitivity (95% CI)', main = caption);
          lines(dfR$ntrain, dfR$Slo_95, lty = 'dashed');
          lines(dfR$ntrain, dfR$Shi_95, lty = 'dashed');

          caption = "False discovery rate";
          plot(dfR$ntrain, dfR$FDRmed, type = 'l', ylim = c(0, 1), xlab = 'ntrain', ylab = 'FDR (95% CI)', main = caption);
          lines(dfR$ntrain, dfR$FDRlo_95, lty = 'dashed');
          lines(dfR$ntrain, dfR$FDRhi_95, lty = 'dashed');

          caption = "Fraction selected (TP + FP)";
          plot(dfR$ntrain, dfR$Fselmed, type = 'l', ylim = c(0, 1), xlab = 'ntrain', ylab = 'Fsel (95% CI)', main = caption);
          lines(dfR$ntrain, dfR$Fsello_95, lty = 'dashed');
          lines(dfR$ntrain, dfR$Fselhi_95, lty = 'dashed');
          par(mfrow = c(1, 1));

          caption = paste("\n", captionStem, ": scan on ntrain : ntestIn = ", ntestIn,
                          ", p1C = ", p1C,
                          ", nresamp = ", nresamp, sep = "");
          title(main = caption, outer = TRUE, cex.main = 0.8);          
        }
        # .................................................................................................
        # . Scan ntest :
        # .................................................................................................
        if (flagMode == 'scanTest') {        
          par(mfrow = c(2, 2));
          caption = "Sensitivity";
          plot(dfR$ntest, dfR$Smed, type = 'l', ylim = c(0, 1), xlab = 'ntest', ylab = 'Sensitivity (95% CI)', main = caption);
          lines(dfR$ntest, dfR$Slo_95, lty = 'dashed');
          lines(dfR$ntest, dfR$Shi_95, lty = 'dashed');

          caption = "False discovery rate";
          plot(dfR$ntest, dfR$FDRmed, type = 'l', ylim = c(0, 1), xlab = 'ntest', ylab = 'FDR (95% CI)', main = caption);
          lines(dfR$ntest, dfR$FDRlo_95, lty = 'dashed');
          lines(dfR$ntest, dfR$FDRhi_95, lty = 'dashed');

          caption = "Fraction selected (TP + FP)";
          plot(dfR$ntest, dfR$Fselmed, type = 'l', ylim = c(0, 1), xlab = 'ntest', ylab = 'Fsel (95% CI)', main = caption);
          lines(dfR$ntest, dfR$Fsello_95, lty = 'dashed');
          lines(dfR$ntest, dfR$Fselhi_95, lty = 'dashed');
          par(mfrow = c(1, 1));

          caption = paste("\n", captionStem, ": scan on ntest : ntrainIn = ", ntrainIn,
                          ", p1C = ", p1C,
                          ", nresamp = ", nresamp, sep = "");
          title(main = caption, outer = TRUE, cex.main = 0.8);                    
        }
        # .................................................................................................                
      }
      # ...................................................................................................
      



      # .......................................................................................
      # . Package results :
      # .......................................................................................
      if (flagMode == 'scanTrain') {
        ntrainInBuf = NULL;
        ntestInBuf = ntestIn;
      } else if (flagMode == 'scanTest') {
        ntrainInBuf = ntrainIn;
        ntestInBuf = NULL;
      }
      
      cr = list(flagMode = flagMode,
                ntrainIn = ntrainInBuf,
                ntestIn = ntestInBuf,        
                dfR = dfR);
      # .......................................................................................      
      

      # ............
      return (cr);
      # ............
}

# =================================================================================================================
# . End of Logistic.fitTrainTestLoopDriver.
# =================================================================================================================







# =================================================================================================================
# . Logistic.runTrainTestOnSeries : runs the function Logistic.fitTrainTestLoop() (see above) on a series of input
# . -----------------------------   data files.
# .                            
# . Syntax:
# .
# .          res =  Logistic.runTrainTestOnSeries(af,
# .                                               tbin,
# .                                               ag,
# .                                               aghk,
# .                                               alab,
# .                                               antrain,
# .                                               antest,
# .                                               nresamp,
# .                                               rngSeed = 123456,
# .                                               p1C = 0.5,
# .                                               fdr0 = 0.25,
# .                                               flagPlotPerFile = FALSE);
# .
# . In:
# .
# .                af = L-length array of names of FLAT files to use. Each FLAT file must have a companion
# .                     LABEL file. Data in each FLAT file is assumed log2-transformed.
# .
# .              tbin = factor name for the {0, 1} binary outcome in each exp design (must be the same for all).
# .
# .                ag = list of genes to be used as predictors in all analyses.
# .                     E.g. ag = c('VIM', 'ACTA2').
# .
# .              aghk = list of housekeeping genes to be used as references in all analyses.
# .                     E.g. ag = c('MVK', 'SNX11').
# .
# .              alab = array of labels for the analysis to be done. Must have length L.
# .
# .           antrain = array of number of training set instances in each realization. Must have length L.
# .
# .            antest = number of test set instances in each realization. Must have length L.
# .
# .           nresamp = number of resampling steps (same for all analyses).
# .
# .           rngSeed = random number seed.
# .
# .               p1C = probability decision threshold. If P(y = 1|x) >= p1C,
# .                     then outcome is predicted to be 1, otherwise 0.
# .                     Valid: 0 < p1C < 1.
# .
# .              fdr0 = FDR threshold for power calculations, etc.
# .
# .   flagPlotPerFile = if TRUE, make plots for the processing of each file.
# .
# .          flagPlot = if TRUE, make at least final plots (even if flagPlotPerFile = FALSE).
# .                     If FALSE, make no final plots (and set flagPlotPerFile = FALSE).
# .
# . Out:
# .        res : contains :
# .
# .           dfRes = data frame, contains results table.
# .         afdrAll = array with pooled FDRs.
# .            
# ===================================================================================================================

Logistic.runTrainTestOnSeries <- function(af,
                                          tbin,
                                          ag,
                                          aghk,
                                          alab,
                                          antrain,
                                          antest,
                                          nresamp,
                                          rngSeed = 123456,
                                          p1C = 0.5,
                                          fdr0 = 0.25,
                                          flagPlotPerFile = FALSE,
                                          flagPlot = TRUE)
{


      # ............................................................
      cat(" ..........  Entry in Logistic.runTrainTestOnSeries.\n");
      # ............................................................
  

      # ......................................................................................
      # . Check on values and consistency :
      # ......................................................................................
      if (!flagPlot) {
        flagPlotPerFile = FALSE;        
      }
      
      stopifnot(p1C > 0.0, p1C < 1.0);
      # ......................................................................................
      # . Training set :
      # ......................................................................................        
      nf = length(af);                                                    # Number of files.

      stopifnot(nf > 0);
      
      if (length(alab) != nf) {
        cat("ERROR: from Logistic.runTrainTestOnSeries:\n");
        cat("alab not same length as file list af.\n");
        stop();
      }

      if (length(antrain) != nf) {
        cat("ERROR: from Logistic.runTrainTestOnSeries:\n");
        cat("antrain not same length as file list af.\n");
        stop();
      }      

      if (length(antest) != nf) {
        cat("ERROR: from Logistic.runTrainTestOnSeries:\n");
        cat("antest not same length as file list af.\n");
        stop();
      }      
      # ......................................................................................
      



      # ................................................................................................
      # . Series here :
      # ................................................................................................
      tag.pred = paste(ag, collapse = ";");
      tag.hk = paste(aghk, collapse = ";");
      afdrAll = c();                                                    # Global FDR for refs.
      afdrDiff = c();                                                   # Global FDR for diff (if applied).
      flagDiffGlobal = FALSE;                                           # Will we also build a univariate predictor?
      
      cat(" ..........  Begin series.\n");
      ta = proc.time()[3];	                                        # Time in seconds.

      for (i in 1:nf) {
        tag.diff = "NONE";                                              # Placeholder.
        cat("-------------------------------------------------------------------------------------------\n");
        cat("Processing file ", i, " out of ", nf, " : ", alab[i], "\n", sep = "");
        cat("File : ", af[i], "\n", sep = "");
        # ...............................................................................................
        # . Generate train and test sets :
        # ...............................................................................................        
        fX = af[i];
        cl = DataFrame.readFlatAndLabel(fX);

        dfX = cl$dfX;
        dfE = cl$dfE;

        n = ncol(dfX); 
        # ...................................................................................................................        
        # . Quick check on binary assignment factor :
        # ...................................................................................................................        
        if (is.null(dfE[[tbin]])) {
          cat("ERROR: from Logistic.runTrainTestOnSeries:\n");
          cat("binary outcome factor name tbin = ", tbin, " not found in exp design.\n", sep = "");
          stop();
        }
        # ...................................................................................................................        
        # . Retrieve binary outcome values :
        # ...................................................................................................................        
        ay = dfE[[tbin]];
        # ...................................................................................................................        
        # . Slice out predictor genes and housekeeping genes :
        # ...................................................................................................................        
        dfY = t(subset(dfX, rownames(dfX) %in% ag));                    # Now in {samples * genes} geometry.
        dfZ = t(subset(dfX, rownames(dfX) %in% aghk));                  # Now in {samples * genes} geometry.

        flagDiff = FALSE;                                               # Will we also build a univariate predictor
                                                                        # based on the difference of two genes?
        if (ncol(dfY) == 2) {
          flagDiff = TRUE;
          flagDiffGlobal = TRUE; 
        }
        # ...................................................................................................................
        # . If there are only two housekeeping genes, plot if requested :
        # ...................................................................................................................                
        if (flagPlotPerFile) {
          if (ncol(dfZ) == 2) {
            Util.readLine();

            gene1 = colnames(dfZ)[1];
            gene2 = colnames(dfZ)[2];

            acol = ifelse(ay == 1, 'blue', 'brown');
            caption = paste(alab[i], " : hk genes (n = ", n, ") - brown = 0, blue = 1.", sep = "");
            xlab = paste('log2(', gene1, ")", sep = "");
            ylab = paste('log2(', gene2, ")", sep = "");          

            xbuf = as.numeric(dfZ[  , 1]);
            ybuf = as.numeric(dfZ[  , 2]);
            
            plot(xbuf,
                 ybuf,
                 pch = 19,
                 xlab = xlab,
                 ylab = ylab,
                 xlim = c(0, max(xbuf)),
                 ylim = c(0, max(ybuf)),                 
                 main = caption,
                 col = acol);
          }
        }
        # ...................................................................................................................        
        # . Build reference-normalized values :
        # ...................................................................................................................        
        azm = apply(dfZ, 1, mean);                                      # ~ average of CT numbers.
        # ...................................................................................................................        
        # . Subtract out to get a 'normalized' data matrix :
        # ...................................................................................................................        
        dfY.n = sweep(dfY, 1, azm, FUN = "-");
        # ...................................................................................................................        
        # . Do the resampling loop for the no-ref data :
        # ...................................................................................................................
        cat(" ..........  Do the resampling loop for the no-ref data/\n");
        
        captionStem = paste(alab[i], " (noRef)", sep = "");
        
        pr.noRef =  Logistic.fitTrainTestLoop(dfY = dfY,
                                              ay = ay, 
                                              ntrain = antrain[i],
                                              ntest = antest[i],
                                              nresamp = nresamp,
                                              rngSeed = rngSeed,
     	      	                              p1C = 0.5,
  			      	              flagPlot = flagPlotPerFile,
				              captionStem = captionStem);
        # ...................................................................................................................        
        # . Do the resampling loop for the ref data :
        # ...................................................................................................................
        cat(" ..........  Do the resampling loop for the referenced data/\n");
        
        captionStem = paste(alab[i], " (ref)", sep = "");
        
        pr.ref =  Logistic.fitTrainTestLoop(dfY = dfY.n,
                                            ay = ay, 
                                            ntrain = antrain[i],
                                            ntest = antest[i],
                                            nresamp = nresamp,
                                            rngSeed = rngSeed,
     	                                    p1C = 0.5,
  	   	      	                    flagPlot = flagPlotPerFile,
				            captionStem = captionStem);
        # ...................................................................................................................        
        # . Do the resampling loop for the difference data :
        # ...................................................................................................................
        if (flagDiff) {
          cat(" ..........  Do the resampling loop for the difference data/\n");

          axbuf = as.numeric(dfY[  , 1] - dfY[  , 2]);
          dfY.diff = data.frame("xdiff" = axbuf);

          gene1 = colnames(dfY)[1];
          gene2 = colnames(dfY)[2];          
          tag.diff = paste(gene1, ".minus.", gene2, sep = "");
          captionStem = paste(alab[i], " (", tag.diff, ")", sep = "");
        
          pr.diff =  Logistic.fitTrainTestLoop(dfY = dfY.diff,
                                               ay = ay, 
                                               ntrain = antrain[i],
                                               ntest = antest[i],
                                               nresamp = nresamp,
                                               rngSeed = rngSeed,
     	                                       p1C = 0.5,
  	   	      	                       flagPlot = flagPlotPerFile,
				               captionStem = captionStem);
       }
       # ...................................................................................................................
       # . In what fraction of instances is FDR_c <= fdr0, and simple stats.
       # . >> 1. No reference :
       # ...................................................................................................................
       afdr = (pr.noRef$matR)[  , "FDR_c"];
                
       prob_leq_fdr0.noRef = sum(afdr <= fdr0) / length(afdr); 
       FDR_med.noRef = median(afdr);
       FDR_095.noRef = quantile(afdr, probs = 0.95);
       # ...................................................................................................................
       # . >> 2. With reference :
       # ...................................................................................................................
       afdr = (pr.ref$matR)[  , "FDR_c"];
       afdrAll = c(afdrAll, afdr);                                                  # Accumulate global afdr values.

       prob_leq_fdr0.ref = sum(afdr <= fdr0) / length(afdr); 
       FDR_med.ref = median(afdr);
       FDR_095.ref = quantile(afdr, probs = 0.95);
       # ...................................................................................................................
       # . >> 3. For the difference :
       # ...................................................................................................................
       if (flagDiff) {
         afdr = (pr.diff$matR)[  , "FDR_c"];
         afdrDiff = c(afdrDiff, afdr);                                              # Accumulate global afdr values.         

         prob_leq_fdr0.diff = sum(afdr <= fdr0) / length(afdr); 
         FDR_med.diff = median(afdr);
         FDR_095.diff = quantile(afdr, probs = 0.95);
       }
       # ...................................................................................................................
       # . Package results.
       # . Build input rows.
       # ...................................................................................................................
       buf1 = c(alab[i],
                 n,
                 'none',
                 antrain[i],
                 antest[i],
                 prob_leq_fdr0.noRef,
                 FDR_med.noRef,
                 FDR_095.noRef,
                 tag.pred,
                 tag.hk,
                 tag.diff);

       buf2 = c(alab[i],
                 n,
                 'hk genes',
                 antrain[i],
                 antest[i],         
                 prob_leq_fdr0.ref,
                 FDR_med.ref,
                 FDR_095.ref,
                 tag.pred,
                 tag.hk,
                 tag.diff);

       if (flagDiff) {
         buf3 = c(alab[i],
                  n,
                  'diff genes',
                  antrain[i],
                  antest[i],         
                  prob_leq_fdr0.diff,
                  FDR_med.diff,
                  FDR_095.diff,
                  tag.pred,
                  tag.hk,
                  tag.diff);         
       }
       # ...................................................................................................................
       # . Add to table :
       # ...................................................................................................................        
        if (i == 1) {
          dfRes = data.frame(matrix(buf1, nrow = 1));
          dfRes = rbind(dfRes, buf2);
          if (flagDiff) {
            dfRes = rbind(dfRes, buf3);            
          }
        } else {
          dfRes = rbind(dfRes, buf1);          
          dfRes = rbind(dfRes, buf2);
          if (flagDiff) {
            dfRes = rbind(dfRes, buf3);            
          }
        }
        # ...................................................................................................................
        cat("-------------------------------------------------------------------------------------------\n");
        # ...................................................................................................................        
      }
      # ...................................................................................................................



      
      # ...................................................................................................................
      # . Tidy up the out put table :
      # ...................................................................................................................        
      colnames(dfRes) = c('panel',
                          'n',
                          'reference',
                          'ntrain',
                          'ntest',
                          'Prob(FDR <= fdr0)',
                          'median(FDR)',
                          'FDR_0.95',
                          'predictor_genes',
                          'hk_genes',
                          'diff_genes');

      dfRes = dfRes[order(dfRes$reference, decreasing = TRUE), ];

      tb = proc.time()[3] - ta;	                                        # Time in seconds.
      
      cat(" ..........  End of series.\n");
      cat(" ..........  Total time = ", tb, " s.\n", sep = "");
      # .................................................................................................


      
      # ...................................................................................................
      # . Compute pooled summary stats :
      # ...................................................................................................
      FDR_025.all = quantile(afdrAll, probs = 0.25);
      FDR_med.all = median(afdrAll);
      FDR_075.all = quantile(afdrAll, probs = 0.75);
      FDR_095.all = quantile(afdrAll, probs = 0.95);

      if (flagDiffGlobal) {
        FDR_025.diff = quantile(afdrDiff, probs = 0.25);
        FDR_med.diff = median(afdrDiff);
        FDR_075.diff = quantile(afdrDiff, probs = 0.75);
        FDR_095.diff = quantile(afdrDiff, probs = 0.95);
      } else {
        FDR_025.diff = 1.0;                                   # Dummy values.
        FDR_med.diff = 1.0;
        FDR_075.diff = 1.0;
        FDR_095.diff = 1.0;
      }
      # ...................................................................................................

      

      # ...................................................................................................
      # . Summary plots here.
      # ...................................................................................................
      if(flagPlot) {
        # ...................................................................................................      
        # . >> 1. Boxplots :
        # ...................................................................................................
        Util.readLine();
        # ...................................................................................................
        # . Extract subsets here :
        # ...................................................................................................      
        dfBuf1 = subset(dfRes, reference == 'none',
                               select = c('Prob(FDR <= fdr0)',
                               'median(FDR)',
                               'FDR_0.95'));
        dfBuf1 = apply(dfBuf1, 2, as.numeric);

        dfBuf2 = subset(dfRes, reference == 'hk genes',
                               select = c('Prob(FDR <= fdr0)',
                               'median(FDR)',
                              'FDR_0.95'));
        dfBuf2 = apply(dfBuf2, 2, as.numeric);

        if (flagDiffGlobal) {
          dfBuf3 = subset(dfRes, reference == 'diff genes',
                                 select = c('Prob(FDR <= fdr0)',
                                 'median(FDR)',
                                'FDR_0.95'));
          dfBuf3 = apply(dfBuf3, 2, as.numeric);
        }
        # ...................................................................................................
        # . Plots here :
        # ...................................................................................................
        lmargin = 2.0;
        mai.OLD = Graphics.setLowerMargin(lmargin);
      
        par(mfrow = c(1, 2));
        
        if (flagDiffGlobal) {
          par(mfrow = c(1, 3));
        }
        
        boxplot(dfBuf1, ylim = c(0, 1), las = 2, main = 'No reference used');
        boxplot(dfBuf2, ylim = c(0, 1), las = 2, main = 'Reference (hk genes) used');      

        if (flagDiffGlobal) {
          boxplot(dfBuf3, ylim = c(0, 1), las = 2, main = paste('Univariate ', tag.diff, ' used', sep = ""));      
        }
        
        par(mfrow = c(1, 1));
        
        par(mai = mai.OLD);      
        # ...................................................................................................      
        # . >> 2. Global FDR : from reference :
        # ...................................................................................................
        Util.readLine();
        # ...................................................................................................
        # . Plot the distribution here :
        # ...................................................................................................
        if (length(afdrAll) <= 500) {
          nb = 20;
        } else if (length(afdrAll) <= 4000) {
          nb = 50;
        } else {
          nb = 100;
        }
        
        caption = paste("Pooled FDR distribution (ref): ",
                        ", p1C = ", p1C,
                        ", nresamp = ", nresamp,
                        " (25%, med, 75%, 95% shown)", sep = "");        
        hist(afdrAll, breaks = nb, xlab = 'FDR', main = caption);
        abline(v = FDR_025.all, lty = 'dashed');
        abline(v = FDR_med.all, lty = 'dashed');
        abline(v = FDR_075.all, lty = 'dashed');                
        abline(v = FDR_095.all, lty = 'dashed');
        # ...................................................................................................      
        # . >> 3. Global FDR : from diff :
        # ...................................................................................................
        if (flagDiffGlobal) {
          Util.readLine();
          # ...................................................................................................
          # . Plot the distribution here :
          # ...................................................................................................
          if (length(afdrDiff) <= 500) {
            nb = 20;
          } else if (length(afdrDiff) <= 4000) {
            nb = 50;
          } else {
            nb = 100;
          }
        
          caption = paste("Pooled FDR distribution (diff): ",
                         ", p1C = ", p1C,
                         ", nresamp = ", nresamp,
                         " (25%, med, 75%, 95% shown)", sep = "");        
          hist(afdrDiff, breaks = nb, xlab = 'FDR', main = caption);
          abline(v = FDR_025.diff, lty = 'dashed');
          abline(v = FDR_med.diff, lty = 'dashed');
          abline(v = FDR_075.diff, lty = 'dashed');                
          abline(v = FDR_095.diff, lty = 'dashed');
          # ...................................................................................................          
        }
        # ...................................................................................................        
      }
      # ...................................................................................................

     

      # ...................................................................................................
      # . Package results here :
      # ...................................................................................................
      res = list(dfRes           = dfRes,
                 afdrAll.ref     = afdrAll,
                 FDR_025.all.ref = FDR_025.all,     # Calculation using reference genes.
                 FDR_med.all.ref = FDR_med.all,
                 FDR_075.all.ref = FDR_075.all,
                 FDR_095.all.ref = FDR_095.all,
                 FDR_025.diff.ref = FDR_025.diff,   #Calculation using difference.
                 FDR_med.diff.ref = FDR_med.diff,
                 FDR_075.diff.ref = FDR_075.diff,
                 FDR_095.diff.ref = FDR_095.diff);

      cat("FINAL SUMMARY STATS, pooled FDRs:\n");
      cat("----------------------------------------------------------------\n");

      if (!flagDiffGlobal) {
        Util.writeTable(unlist(res[3:6]))
      } else {
        Util.writeTable(unlist(res[3:10]))        
      }

      cat("----------------------------------------------------------------\n");      
      # ...................................................................................................            


      # ............................................................
      cat(" ..........  Exit Logistic.runTrainTestOnSeries.\n");
      # ............................................................
      

      # ..............
      return (res);
      # ..............
      
}

# =================================================================================================================
# . End of Logistic.runTrainTestOnSeries.
# =================================================================================================================

