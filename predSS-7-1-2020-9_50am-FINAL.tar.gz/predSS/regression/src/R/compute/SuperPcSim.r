# =================================================================================================
# . SuperPcSim.r : functions to generate simulated data sets for testing supervised principal
# . -----------    components analysis.
# .            
# =================================================================================================

library(survival);

# =================================================================================================
# . SuperPcSim.generateDataCox : generates a simple gene expression data matrix as in
# . --------------------------   Eric Blair et al. Jour. Amer. Stat. Assoc. vol. 101, 118 (2006)
# .                              and survival data alongside.
# .   Syntax example :
# .
# .          sim = SuperPcSim.generateDataCox(nTwoRegion = 200,
# .                                           nFourRegion = 50,
# .                                           nb = 20,
# .                                           rngSeed = 123456,
# .                                           sigma = 1.0,
# .                                           hazardPanel = 'twoRegion',
# .                                           betaSim = 0.5);
# .
# .   In:
# .         nTwoRegion = number of genes used for panel twoRegion.
# .                      Genes in this region have a (-2,2) mean profile.
# .
# .        nFourRegion = number of genes used for panel fourRegion.
# .                      Genes in this region have a (-1,1,-1,1) mean profile.
# .
# .           nb = number of samples in each of 4 blocks used to generate all of the
# .                simulated data matrix columns (there are thus a total of 4 * nb
# .                sample columns in the simulated data matrix). Range: nb > 1.
# .
# .        sigma = standard deviation for all noise terms.
# .
# .      rngSeed = random number seed for generating noise terms.
# .
# .    hazardPanel = determines which panel of genes determines the   
# .                                hazard ratios, as explained below.               
# .                                Allowed: twoRegion, fourRegion, NONE             
# .                                                                        
# .                     * The survival times are generated according to the         
# .                     exponential model :                                         
# .  
# .                        lambda(t|z) = lambda0 * exp(betaSim * z)                 
# . 
# .                     where z = mean gene expression profile of selected panel    
# .                     (thus either from the (-2, 2) profile of the twoRegion,     
# .                     or the (-1,1,-1,1) profile of the fourRegion.               
# .                     Lambda0 = 1.0 is hard-wired.                                
# .                     hazardPanel = NONE is the same as betaSim = 0 above : no    
# .                     dependence on gene expression covariates.                   
# .
# .        betaSim = true Cox coefficient, used in the exponential model.
# .
# .
# .   Out:
# .       sim = list with members :
# .
# .                 A = data matrix, in genes * samples format.
# .               dfX = same data as in A but as a data frame in samples * genes format.
# .               dfE = data frame for the experimental design, with columns:
# .                     'survivalTime', 'censoringStatus', 'Z'
# .
# =================================================================================================

SuperPcSim.generateDataCox <- function(nTwoRegion, nFourRegion, nb, rngSeed, sigma, hazardPanel, betaSim)
{


    # ............................................................................
    stopifnot(nb > 1);
    stopifnot(nTwoRegion >= 0);
    stopifnot(nFourRegion >= 0);

    stopifnot((nTwoRegion > 0) || (nFourRegion >0));  
    stopifnot(nFourRegion >= 0);        
    stopifnot(sigma >= 0.0);
    stopifnot((hazardPanel == 'twoRegion')
              || (hazardPanel == 'fourRegion')
              || (hazardPanel == 'NONE'));
    # ............................................................................  

    
    # ....................
    set.seed(rngSeed);    
    # ....................

    
    # ..........................................................................
    # . Array for the twoRegion genes :
    # ..........................................................................
    amTwoRegion = c(rep(-2, times = 2 * nb), rep(2, times = 2 * nb));    

    if (nTwoRegion > 0) {
      nr = nTwoRegion;              # 200 genes.
      nel = 4 * nb * nr;     # Total number of elements in this matrix.
      
      ATwoRegion = Matrix.spreadRow(amTwoRegion, nr) + matrix(sigma * rnorm(nel), nrow = nr);
    }
    # ...........................................................................


    
    # ...........................................................................
    # . Array for the fourRegion genes :
    # ...........................................................................
    amFourRegion = c(rep(-1, times = nb), rep(1, times = nb),
              rep(-1, times = nb), rep(1, times = nb));

    if (nFourRegion > 0) {
      nr = nFourRegion;               # 50 genes.
      nel = 4 * nb * nr;     # Total number of elements in this matrix.
      
      AFourRegion = Matrix.spreadRow(amFourRegion, nr) + matrix(sigma * rnorm(nel), nrow = nr);
    }
    # ...........................................................................

    

    # ...................................................................
    # . Generate the appropriate matrix, then create the data frame :
    # ...................................................................
    if ((nTwoRegion > 0) && (nFourRegion == 0)) {
      A = ATwoRegion;
    } else if ((nTwoRegion == 0) && (nFourRegion > 0)) {
      A = AFourRegion;
    } else if ((nTwoRegion > 0) && (nFourRegion > 0)) {
      A = rbind(ATwoRegion, AFourRegion);
    }

    dfX = as.data.frame(t(A));
    # ...................................................................
    

    # ...................................................................
    # . Set row and column names :
    # ...................................................................    
    nr = nrow(dfX);     # Final number of rows.
    nc = ncol(dfX);     # Final number of columns.

    rownames(dfX) = paste("s", 1:nr, sep = "");    # Samples.
    colnames(A) = rownames(dfX);
    
    colnames(dfX) = paste("g", 1:nc, sep = "");    # Genes.
    rownames(A) = colnames(dfX);
    # ....................................................................


    # ..........................................................................................
    # . Generate the survival times :
    # ..........................................................................................
    lambda0 = 1;    # Mean survival time is 1 year for z = 0 covariate.
    
    if (hazardPanel == 'twoRegion') {
      aloghR = amTwoRegion * betaSim;
      #xxx alambda = lambda0 * exp(amTwoRegion * betaSim);
      am = amTwoRegion;
    } else if (hazardPanel == 'fourRegion') {
      aloghR = amFourRegion * betaSim;
      #xxx alambda = lambda0 * exp(amFourRegion * betaSim);
      am = amFourRegion;
    } else if (hazardPanel == 'NONE') {
      aloghR = rep(0.0, times = nr);
      am = rep(0.0, times = nr);
      #xxx alambda = rep(lambda0, times = nr);    # Constant value.
    }

    ahR = exp(aloghR);                                         # Risk ratio.
    alambda = lambda0 * ahR;                                   # Exponential rates.
    at = rexp(length(alambda), alambda);                       # Exponential distributions.
    as = rep(1.0, times = length(alambda));                    # All-1 : no censoring.

    aTrainTest = rep('train', times = nr);                     # Initialize as all-training set.
    nr2 = 2 * nb;
    indexTest = 1 + 2 * ((1:nr2) - 1);
    aTrainTest[indexTest] = rep('test', times = nr2);          # Interleave test set elements.
    
    dfE = as.data.frame(cbind(aloghR, ahR, at, as, am));       # Numerical columns.
    dfE = cbind(dfE, aTrainTest);                              # Add the train/test factor.
    rownames(dfE) = rownames(dfX);
    colnames(dfE) = c('logHazardRatio', 'hazardRatio',
                      'survivalTime', 'censoringStatus', 'Zgenerating', 'trainTest');
    # ..........................................................................................


    # ........................................................
    # . Package results :
    # ........................................................
    d = list(A = A, dfX = dfX, dfE = dfE);

    class(d) = "sim.cox";
    # ........................................................


    # ............
    return (d);
    # ............

}

# =================================================================================================
# . End of SuperPcSim.generateDataCox.
# =================================================================================================  



# =================================================================================================
# . SuperPcSim.plotSurvivalTimesCox : plots survival times generated by SuperPcSim.generateDataCox.
# . -------------------------------   
# .                              
# .   Syntax example:
# .
# .       d = SuperPcSim.generateDataCox(nTwoRegion, nFourRegion, nb, rngSeed, sigma,
# .                                      hazardPanel, betaSim);
# .       SuperPcSim.plotSurvivalTimesCox(d, hazardPanel, betaSim);
# .
# .   In:
# .
# .       d = data object returned by SuperPcSim.generateDataCox().
# .       hazardPanel = text defining the mean profile defining the covariate Z.
# .       betaSim = value of beta in the generating Cox model of survival times.
# .
# =================================================================================================

SuperPcSim.plotSurvivalTimesCox <- function(dIn, hazardPanel, betaSim)
{
     # ...................................
     stopifnot(class(dIn) == "sim.cox");
     # ...................................

     
     # ............................................................................................
     par(mfrow = c(2,1));

     xlab = 'Index (sample)';
     ylab = 'Survival time';
     caption = paste("Survival times for hazardPanel = ", hazardPanel,
                      ", betaSim = ", betaSim, sep ="");

     plot(dIn$dfE$survivalTime, xlab = xlab, ylab = ylab, main = caption);

#     xlab = 'Index (sample)';
#     ylab = 'Z';
#     caption = paste("Generating covariate Z [lambda = exp(betaSim * Z)]");
#     plot(dIn$dfE$Z, xlab = xlab, ylab = ylab, main = caption);        
#     abline(h = 0.0);

     xlab = 'Index (sample)';
     ylab = 'exp(betaSim * Z)'
     ylim = c(0.0, max(dIn$dfE$hazardRatio));
     caption = paste("True hazard ratio");
     plot(dIn$dfE$hazardRatio, ylim = ylim,
          xlab = xlab, ylab = ylab, main = caption);        
     abline(h = 0.0);
     
     par(mfrow = c(1,1));
     # ............................................................................................


     # ............
     return (0);
     # ............
}

# =================================================================================================
# . End of SuperPcSim.plotSurvivalTimesCox.
# =================================================================================================



# =================================================================================================
# . SuperPcSim.generateData : generates the simulated data set shown as an example in
# . -----------------------   Eric Blair et al. Jour. Amer. Stat. Assoc. vol. 101, 118 (2006).
# .
# .   Syntax:
# .
# .            d = SuperPcSim.generateData(nb = 20,
# .                                              alpha = 0.0,
# .                                              rngSeed,
# .                                              sigma = 1.0,
# .                                              panel = "both");
# .
# .   In:
# .           nb = number of samples in each of 4 blocks used to generate all of the
# .                simulated data matrix columns (there are thus a total of 4 * nb
# .                sample columns in the simulated data matrix). Range: nb > 1.
# .
# .        alpha = parameter determining the mix of patterns in the outcome vector
# .                (see below). Default value is 0.
# .
# .        sigma = standard deviation for all noise terms.
# .
# .      rngSeed = random number seed for generating noise terms. If not present
# .                in argument list, the background random number generator seed is used.
# .
# .        panel = mix of panels of gene expression to be used. Allowed values :
# .                top, bottom, both :
# .
# .                - top : only the ``top'' panel is generated :
# .                  200 genes with -2,2 mean profile.
# .                - bottom : only the ``bottom'' panel is generated :
# .                  50 genes with -1,1,-1,1 mean profile.
# .                - both : both panels are generated, and stacked
# .                  one atop the other.
# .
# .   Out:
# .       d, list with members :
# .
# .                 A = data matrix, in genes * samples format.
# .               dfX = same data as in A but as a data frame
# .                     with data matrix in samples * genes format.
# .                ay = outcome vector, length = number of samples = nrow(dfX).
# .               aym = mean outcome vector: profile before addition of noise.
# .
# =================================================================================================

SuperPcSim.generateData <- function(nb = 20, alpha = 0.0, sigma = 1.0, rngSeed, panel = "both")
{

    # ............................................................................
    if (!missing(rngSeed)) {
      set.seed(rngSeed);        # Sets the random number seed for this run.
    }
    # ............................................................................

    
    # ..................................................................
    # . Top 200 genes :
    # ..................................................................
    amTop = c(rep(-2, times = 2 * nb), rep(2, times = 2 * nb));

    nr = 200;              # 200 genes.
    nel = 4 * nb * nr;     # Total number of elements in this matrix.
      
    Atop = Matrix.spreadRow(amTop, nr) + matrix(sigma * rnorm(nel), nrow = nr);
    # ...................................................................


    # ...................................................................
    # . Bottom 50 genes :
    # ...................................................................
    amBot = c(rep(-1, times = nb), rep(1, times = nb),
           rep(-1, times = nb), rep(1, times = nb));

    nr = 50;               # 50 genes.
    nel = 4 * nb * nr;     # Total number of elements in this matrix.
      
    Abot = Matrix.spreadRow(amBot, nr) + matrix(sigma * rnorm(nel), nrow = nr);      
    # ...................................................................


    # ...................................................................
    # . Generate the appropriate matrix, then create the data frame :
    # ...................................................................
    if (panel == "top") {
      A = Atop;
    } else if (panel == "bottom") {
      A = Abot;
    } else if (panel == "both") {
      A = rbind(Atop, Abot);
    }

    dfX = as.data.frame(t(A));
    # ...................................................................
    

    # ...................................................................
    # . Set row and column names :
    # ...................................................................    
    nr = nrow(dfX);     # Final number of rows.
    nc = ncol(dfX);     # Final number of columns.

    rownames(dfX) = paste("s", 1:nr, sep = "");    # Samples.
    colnames(A) = rownames(dfX);
    
    colnames(dfX) = paste("g", 1:nc, sep = "");    # Genes.
    rownames(A) = colnames(dfX);
    # ....................................................................


    # ...................................................................
    # . Generate outcome vector :
    # ...................................................................
    aym = alpha * amTop + (1.0 - alpha) * amBot;
    ay = aym + sigma * rnorm(4 * nb);
    # ...................................................................


    # ...................................................................
    # . Package results :
    # ...................................................................
    d = list(A = A, dfX = dfX, ay = ay, aym = aym);
    # ...................................................................


    # ............
    return (d);
    # ............

}

# =================================================================================================
# . End of SuperPcSim.generateData.
# =================================================================================================  



# =================================================================================================
# . SuperPcSim.generateDataRegress : generates a simple gene expression data matrix as in
# . ------------------------------   Eric Blair et al. Jour. Amer. Stat. Assoc. vol. 101, 118 (2006)
# .                                  and an output variable alongside.
# .   Syntax example :
# .
# .          sim = SuperPcSim.generateDataRegress(nTwoRegion = 200,
# .                                               nFourRegion = 50,
# .                                               nb = 20,
# .                                               rngSeed = 123456,
# .                                               sigma = 1.0,
# .                                               generatingPanel = 'twoRegion',
# .                                               modelType = 'lm',
# .                                               betaSim0 = 0.5,
# .                                               betaSim1 = 2.0,
# .                                               sigmaY = 1.0);
# .
# .   In:
# .         nTwoRegion = number of genes used for panel twoRegion.
# .                      Genes in this region have a (-2,2) mean profile.
# .
# .        nFourRegion = number of genes used for panel fourRegion.
# .                      Genes in this region have a (-1,1,-1,1) mean profile.
# .
# .           nb = number of samples in each of 4 blocks used to generate all of the
# .                simulated data matrix columns (there are thus a total of 4 * nb
# .                sample columns in the simulated data matrix). Range: nb > 1.
# .
# .        sigma = standard deviation for all noise terms.
# .
# .      rngSeed = random number seed for generating noise terms.
# .
# .    generatingPanel = determines which panel of genes determines the   
# .                                hazard ratios, as explained below.               
# .                                Allowed: twoRegion, fourRegion, NONE             
# .
# .    modelType = model used to generate the simulated output variable data.
# .                Allowed:
# .                       - lm : linear model.
# .                       - logistic : logit distribution.
# .                
# .                * The output variables are generated according to            
# .                modelType :
# .
# .                 1) lm : linear model, with output y generated accorrding to: 
# .     
# .                            y = betaSim0  +  betaSim1 * z  + epsY            
# .     
# .                         where:                                              
# .                
# .                        z = mean gene expression profile of selected panel   
# .                            (thus either from the (-2, 2) profile of the,    
# .                            twoRegion or the (-1,1,-1,1) profile of the      
# .                            fourRegion.                                      
# .                
# .                        betaSim0, betaSim1 = linear model parameters         
# .                                             (see below).                     
# .     
# .                        epsY = Gaussian noise term, with standard deviation  
# .                               given by sigmaY below.                        
# .
# .                 2) logistic : output y is a binary {0, 1} variable, probabilitically
# .                               generated accorrding to: 
# .     
# .                            logit(P(y = 1|z)) = betaSim0  +  betaSim1 * z
# .
# .                               or equivalently :
# .
# .                                                       1
# .                            P(y = 1|z) =  --------------------------------
# .                                           1 + exp( - (beta0 + beta1 * z))
# .     
# .                         where:                                              
# .                
# .                        z = mean gene expression profile of selected panel   
# .                            (thus either from the (-2, 2) profile of the,    
# .                            twoRegion or the (-1,1,-1,1) profile of the      
# .                            fourRegion.                                      
# .                
# .                        betaSim0, betaSim1 = linear model parameters         
# .                                             (see below).                     
# .     
# .
# .
# .                * Note that generatingPanel = NONE is the same as
# .                betaSim1 = 0 above : no dependence on gene expression        
# .                covariates.                                                  
# .     
# .    betaSim0 = intercept parameter, used in linear model lm or in specifcation of
# .               logit distribution.
# .                
# .    betaSim1 = slope parameter, used in linear model lm or in specification of
# .               logit distribution.
# .     
# .    sigmaY = standard deviation of noise terms in simulated output variable
# .             Y in model lm. Range: sigmaY >= 0.0.
# .     
# .   Out:
# .       sim = list with members :
# .
# .                 A = data matrix, in genes * samples format.
# .               dfX = same data as in A but as a data frame in samples * genes format.
# .               dfE = data frame for the experimental design, with columns:
# .                     'Y', 'ayM', 'Z', 'trainTest'.
# .
# =================================================================================================

SuperPcSim.generateDataRegress <- function(nTwoRegion,
                                           nFourRegion,
                                           nb,
                                           rngSeed,
                                           sigma,
                                           generatingPanel,
                                           modelType,
                                           betaSim0,
                                           betaSim1,
                                           sigmaY)
{


    # ............................................................................
    stopifnot(nb > 1);
    stopifnot(nTwoRegion >= 0);
    stopifnot(nFourRegion >= 0);

    stopifnot((nTwoRegion > 0) || (nFourRegion >0));  
    stopifnot(nFourRegion >= 0);        
    stopifnot(sigma >= 0.0);
    stopifnot((generatingPanel == 'twoRegion')
              || (generatingPanel == 'fourRegion')
              || (generatingPanel == 'NONE'));
    stopifnot((modelType == 'lm') || (modelType == 'logistic'));
    stopifnot(sigmaY >= 0.0);
    # ............................................................................  

    
    # ....................
    set.seed(rngSeed);    
    # ....................

    
    # ..........................................................................
    # . Array for the twoRegion genes :
    # ..........................................................................
    amTwoRegion = c(rep(-2, times = 2 * nb), rep(2, times = 2 * nb));    

    if (nTwoRegion > 0) {
      nr = nTwoRegion;              # 200 genes.
      nel = 4 * nb * nr;     # Total number of elements in this matrix.
      
      ATwoRegion = Matrix.spreadRow(amTwoRegion, nr) + matrix(sigma * rnorm(nel), nrow = nr);
    }
    # ...........................................................................


    
    # ...........................................................................
    # . Array for the fourRegion genes :
    # ...........................................................................
    amFourRegion = c(rep(-1, times = nb), rep(1, times = nb),
              rep(-1, times = nb), rep(1, times = nb));

    if (nFourRegion > 0) {
      nr = nFourRegion;               # 50 genes.
      nel = 4 * nb * nr;     # Total number of elements in this matrix.
      
      AFourRegion = Matrix.spreadRow(amFourRegion, nr) + matrix(sigma * rnorm(nel), nrow = nr);
    }
    # ...........................................................................

    

    # ...................................................................
    # . Generate the appropriate matrix, then create the data frame :
    # ...................................................................
    if ((nTwoRegion > 0) && (nFourRegion == 0)) {
      A = ATwoRegion;
    } else if ((nTwoRegion == 0) && (nFourRegion > 0)) {
      A = AFourRegion;
    } else if ((nTwoRegion > 0) && (nFourRegion > 0)) {
      A = rbind(ATwoRegion, AFourRegion);
    }

    dfX = as.data.frame(t(A));
    # ...................................................................
    

    # ...................................................................
    # . Set row and column names :
    # ...................................................................    
    nr = nrow(dfX);     # Final number of rows.
    nc = ncol(dfX);     # Final number of columns.

    rownames(dfX) = paste("s", 1:nr, sep = "");    # Samples.
    colnames(A) = rownames(dfX);
    
    colnames(dfX) = paste("g", 1:nc, sep = "");    # Genes.
    rownames(A) = colnames(dfX);
    # ....................................................................


    # ..........................................................................................
    # . Generate the output variable profiles.
    # . First build the ``backbone'' of mean values :
    # ..........................................................................................
    if (generatingPanel == 'twoRegion') {
      ay = betaSim0 + amTwoRegion * betaSim1;
      am = amTwoRegion;
    } else if (generatingPanel == 'fourRegion') {
      ay = betaSim0 + amFourRegion * betaSim1;
      am = amFourRegion;
    } else if (generatingPanel == 'NONE') {
      ay = betaSim0;                               # No dependence on gene expression.      
      am = rep(0.0, times = nr);
    }

    ayM = ay;                                      # True mean values.
    # .........................................................................................
    # . >> 1. modelType = lm :
    # .........................................................................................
    if (modelType == 'lm') {
      ay = ay + sigmaY * rnorm(length(ay));         # Add the noise term.
    }
    # .........................................................................................
    # . >> 2. modelType = logistic :
    # .........................................................................................
    if (modelType == 'logistic') {
      apBuf = 1 / (1 + exp(-ay));                   # Use backbone to define P(y = 1).
      aqBuf = runif(length(ay));                    # Random values in [0, 1].
      ay = ifelse(aqBuf <= apBuf, 1.0, 0.0);        # logit(P(y = 1)) = beta0 + beta1 * z.
      ayM = apBuf;                                  # Reset this to the probability.
    }
    # .........................................................................................


    
    # .........................................................................................
    # . Specify a split in the training and test sets :
    # .........................................................................................    
    aTrainTest = rep('train', times = nr);                     # Initialize as all-training set.
    nr2 = 2 * nb;
    indexTest = 1 + 2 * ((1:nr2) - 1);
    aTrainTest[indexTest] = rep('test', times = nr2);          # Interleave test set elements.
    # .........................................................................................


    
    # .........................................................................................
    # . Package all as a data frame :
    # .........................................................................................
    dfE = data.frame(ay = ay, ayM = ayM, am = am, aTrainTest = aTrainTest);
    rownames(dfE) = rownames(dfX);

    if (modelType == 'lm') {
      colnames(dfE) = c('Y', 'ayM', 'Z', 'trainTest');
    } else if (modelType == 'logistic') {
      colnames(dfE) = c('Y', 'Prob(Y=1)', 'Z', 'trainTest');      
    }
    # ..........................................................................................


    # ........................................................
    # . Package results :
    # ........................................................
    d = list(A = A, dfX = dfX, dfE = dfE);

    class(d) = "sim.regress";
    # ........................................................


    # ............
    return (d);
    # ............

}

# =================================================================================================
# . End of SuperPcSim.generateDataRegress.
# =================================================================================================  




# =================================================================================================
# . SuperPcSim.plotOutputVariableRegress : plots the output variable values generated by 
# . ------------------------------------   SuperPcSim.generateDataRegress.
# .                              
# .   Syntax example :
# .
# .       dIn = SuperPcSim.generateDataRegress(nTwoRegion = 200,
# .                                            nFourRegion = 50,
# .                                            nb = 20,
# .                                            rngSeed = 123456,
# .                                            sigma = 1.0,
# .                                            generatingPanel = 'twoRegion',
# .                                            modelType = 'lm',
# .                                            betaSim0 = 0.5,
# .                                            betaSim1 = 2.0,
# .                                            sigmaY = 1.0);
# .
# .       SuperPcSim.plotOutputVariableRegress(dIn, generatingPanel, betaSim0, betaSim1,
# .                                            modelType);
# .
# .   In:
# .
# .       dIn = data object returned by SuperPcSim.generateDataRegress().
# .       generatingPanel = text input which defined the mean profile defining the covariate Z.
# .       betaSim0 = value of beta0 (intercept) in linear model lm or in logit distribution.
# .       betaSim1 = value of beta1 (slope) in linear model lm or in logit distribution.
# .       modelType = type of model used : lm, logistic.
# .
# =================================================================================================

SuperPcSim.plotOutputVariableRegress <- function(dIn, generatingPanel, betaSim0, betaSim1, modelType)
{
     # ...........................................................
     stopifnot(class(dIn) == "sim.regress");
     stopifnot((modelType == 'lm') || (modelType == 'logistic'));        
     # ...........................................................

     
     # ............................................................................................
     # . First plot the output variable against the samples :
     # ............................................................................................
     par(mfrow = c(2,1));
    
     xlab = 'Index (sample)';
     ylab = 'Y';
     caption = paste("model = ", modelType, ": Y for panel = ", generatingPanel,
                      ", beta0 = ", betaSim0, ", beta1 = ", betaSim1, sep ="");

     plot(dIn$dfE$Y, pch = 19, xlab = xlab, ylab = ylab, main = caption);
     lines(dIn$dfE$ayM, type = 'l', col = 'red');
     abline(h = 0.0);

     xpos = 0.0;
     ypos = max(dIn$dfE$Y);

     cex.OLD = par("cex");
     par(cex = 0.7);

     if (modelType == 'lm') {
       legendText = c("yM = b0 + b1 * Z");
     } else if (modelType == 'logistic') {
       legendText = c("P(y=1) = b0 + b1 * Z");       
     }
     
     colVector = c('red');
     ltyVector = c('solid');
     legend(x = xpos, y = ypos, legend = legendText, col = colVector, lty = ltyVector, bty = 'n');
     par(cex = cex.OLD);
     # ............................................................................................
     # . Plot Z = mean gene expression profile which gives rise to the output.
     # ............................................................................................
     xlab = 'Index (sample)';
     ylab = 'Z';

     if (modelType == 'lm') {
       caption = paste("model = ", modelType, ": average gene expression for genes determining Y",
                        sep = "");
     } else if (modelType == 'logistic') {
       caption = paste("model = ", modelType, ": P(y = 1|Z) = beta0 + beta1 * Z", sep = "");
     }

     cex.main.OLD = par("cex.main");
     par(cex.main = 0.7);
     plot(dIn$dfE$Z, pch = 19, xlab = xlab, ylab = ylab, main = caption);
     abline(h = 0.0);
     par(cex.main = cex.main.OLD);
     
     par(mfrow = c(1,1));     
     # ............................................................................................


     # ............
     return (0);
     # ............
}

# =================================================================================================
# . End of SuperPcSim.plotOutputVariableRegress.
# =================================================================================================




# =================================================================================================
# . SuperPcSim.generateDataCoxWithCov : generates a simple gene expression data matrix as in
# . ---------------------------------   Eric Blair et al. Jour. Amer. Stat. Assoc. vol. 101, 118 (2006)
# .                                     and survival data alongside. This version conditions the
# .                                     hazard function on an additional external covariate, as
# .                                     well as on the gene expression values.
# .   Syntax example :
# .
# .          sim = SuperPcSim.generateDataCoxWithCov(nTwoRegion = 200,
# .                                                  xtwoRegion = 2.0,
# .                                                  sigmaTwoRegion = 1.0,
# .                                                  nFourRegion = 50,
# .                                                  xFourRegionL = -1.0,
# .                                                  xFourRegionR = 1.0,
# .                                                  sigmaFourRegion = 1.0,
# .                                                  nb = 20,
# .                                                  rngSeed = 123456,
# .                                                  hazardPanel = 'fourRegion',
# .                                                  betaSim1 = 1.0,
# .                                                  betaSim2 = 0.0,
# .                                                  betaSim3 = -2.0);
# .
# .   In:
# .   >>twoRegion PARAMETERS :
# .
# .         nTwoRegion = number of genes used for panel twoRegion.
# .                      Genes in this region have a (-xTwoRegion, xTwoRegion)
# .                      mean profile.
# .         xTwoRegion = specified mean values in twoRegion panel.
# .     sigmaTwoRegion = std. dev. for noise in tworegion panel.
# .
# .   >>fourRegion PARAMETERS :
# .
# .        nFourRegion = number of genes used for panel fourRegion.
# .                      Genes in this region have a (x4L, x4R, x4L, x4R)
# .                      mean profile, where x4L = xFourRegionL and      
# .                      x4R = xFourRegionR are specified below.         
# .       xFourRegionL = mean values for LH sides for panel fourRegion (see above).
# .       xFourRegionR = mean values for RH sides for panel fourRegion (see above).
# .    sigmaFourRegion = std. dev. for noise in fourRegion panel.
# .
# .   >>general PARAMETERS :
# .           nb = number of samples in each of 4 blocks used to generate all of the
# .                simulated data matrix columns (there are thus a total of 4 * nb
# .                sample columns in the simulated data matrix). Range: nb > 1.
# .
# .      rngSeed = random number seed for generating noise terms.
# .
# .    hazardPanel = determines which panel of genes determines the   
# .                                hazard ratios, as explained below.               
# .                                Allowed: twoRegion, fourRegion, NONE             
# .
# .   >>COX COEFFICIENTS for generating model :                           
# . 								    
# .        betaSim1 = 1.0  : true Cox coefficient beta1.                        
# .        betaSim2 = 0.0  : true Cox coefficient beta2.                        
# .        betaSim3  = -2.0 : true Cox coefficient beta3.                        
# . 								    
# .                                                                     
# .            * The survival times are generated according to an       
# .            exponential model with hazard :                          
# .                                                                     
# .               lambda(t|x,z) = lambda0 *                             
# .                           exp(beta1 * x + beta2 * z + beta3 * z * x)
# .                                                                     
# .            where x = mean gene expression profile of selected panel 
# .            (thus either from the (-2, 2) profile of the twoRegion,  
# .            or the (-1,1,-1,1) profile of the fourRegion, and where z
# .            is a covariate with z = 0 in the first half of the panel,
# .            and z = 1 in the second half of the entire panel.        
# . 								    
# .            Lambda0 = 1.0 is hard-wired.                             
# .            hazardPanel = NONE is the same as betaSim = 0 above : no 
# .            dependence on gene expression covariates.                
# .
# .   Out:
# .       sim = list with members :
# .
# .                 A = data matrix, in genes * samples format.
# .               dfX = same data as in A but as a data frame in samples * genes format.
# .               dfE = data frame for the experimental design, with columns:
# .                     'survivalTime', 'censoringStatus', 'X', 'Z'
# .
# .                     where X = mean gene expression value, and Z = external covariate.
# .
# =================================================================================================

SuperPcSim.generateDataCoxWithCov <- function(nTwoRegion, xTwoRegion, sigmaTwoRegion,
                                              nFourRegion, xFourRegionL, xFourRegionR, sigmaFourRegion,
                                              nb, rngSeed,
                                              hazardPanel,
                                              betaSim1, betaSim2, betaSim3)
{


    # ............................................................................
    stopifnot(nb > 1);
    stopifnot(nTwoRegion >= 0);
    stopifnot(nFourRegion >= 0);

    stopifnot((nTwoRegion > 0) || (nFourRegion >0));
    stopifnot((sigmaTwoRegion >= 0) || (sigmaFourRegion >= 0));      
    stopifnot(nFourRegion >= 0);        
    stopifnot((hazardPanel == 'twoRegion')
              || (hazardPanel == 'fourRegion')
              || (hazardPanel == 'NONE'));
    # ............................................................................  

    
    # ....................
    set.seed(rngSeed);    
    # ....................

    
    # .................................................................................
    # . Array for the twoRegion genes :
    # .................................................................................
    amTwoRegion = c(rep(-xTwoRegion, times = 2 * nb), rep(xTwoRegion, times = 2 * nb));    

    if (nTwoRegion > 0) {
      nr = nTwoRegion;              # 200 genes.
      nel = 4 * nb * nr;     # Total number of elements in this matrix.
      
      ATwoRegion = Matrix.spreadRow(amTwoRegion, nr) +
                   matrix(sigmaTwoRegion * rnorm(nel), nrow = nr);
    }
    # ..................................................................................


    
    # ..................................................................................................
    # . Array for the fourRegion genes :
    # ..................................................................................................
    amFourRegion = c(rep(xFourRegionL, times = nb), rep(xFourRegionR, times = nb),
              rep(xFourRegionL, times = nb), rep(xFourRegionR, times = nb));

    if (nFourRegion > 0) {
      nr = nFourRegion;               # 50 genes.
      nel = 4 * nb * nr;     # Total number of elements in this matrix.
      
      AFourRegion = Matrix.spreadRow(amFourRegion, nr) + matrix(sigmaFourRegion * rnorm(nel), nrow = nr);
    }
    # ...................................................................................................

    

    # ...................................................................
    # . Generate the appropriate matrix, then create the data frame :
    # ...................................................................
    if ((nTwoRegion > 0) && (nFourRegion == 0)) {
      A = ATwoRegion;
    } else if ((nTwoRegion == 0) && (nFourRegion > 0)) {
      A = AFourRegion;
    } else if ((nTwoRegion > 0) && (nFourRegion > 0)) {
      A = rbind(ATwoRegion, AFourRegion);
    }

    dfX = as.data.frame(t(A));
    # ...................................................................
    

    # ...................................................................
    # . Set row and column names :
    # ...................................................................    
    nr = nrow(dfX);     # Final number of rows.
    nc = ncol(dfX);     # Final number of columns.

    rownames(dfX) = paste("s", 1:nr, sep = "");    # Samples.
    colnames(A) = rownames(dfX);
    
    colnames(dfX) = paste("g", 1:nc, sep = "");    # Genes.
    rownames(A) = colnames(dfX);
    # ....................................................................



    # ..........................................................................
    # . Array for the external covariate Z :
    # . this is z = 0 for the first half of the entire panel, and z = 1 for the
    # . second half of the entire panel.
    # ..........................................................................
    az = c(rep(0.0, times = 2 * nb), rep(1, times = 2 * nb));    
    # ...........................................................................



    
    # ..........................................................................................
    # . Generate the survival times :
    # . this is done in accordance to an exponential model, with time-independent but co-variate
    # . -dependent hazard function :
    # .
    # .       lambda(t|x,z) = lambda0 * exp(beta1 * x + beta2 * z + beta3 * z * x)
    # . 
    # ..........................................................................................
    lambda0 = 1;    # Mean survival time is 1 year for z = 0 covariate.
    
    if (hazardPanel == 'twoRegion') {
      am = amTwoRegion;
    } else if (hazardPanel == 'fourRegion') {
      am = amFourRegion;
    } else if (hazardPanel == 'NONE') {
      am = rep(0.0, times = nr);
    }

    aloghR = betaSim1 * am + betaSim2 * az + betaSim3 * az * am;

    ahR = exp(aloghR);                                         # Risk ratio.
    alambda = lambda0 * ahR;                                   # Exponential rates.
    at = rexp(length(alambda), alambda);                       # Exponential distributions.
    as = rep(1.0, times = length(alambda));                    # All-1 : no censoring.

    aTrainTest = rep('train', times = nr);                     # Initialize as all-training set.
    nr2 = 2 * nb;
    indexTest = 1 + 2 * ((1:nr2) - 1);
    aTrainTest[indexTest] = rep('test', times = nr2);          # Interleave test set elements.
    
    dfE = as.data.frame(cbind(aloghR, ahR, at, as, am, az));   # Numerical columns.
    dfE = data.frame(dfE, aTrainTest);                         # Add the train/test factor.
    
    rownames(dfE) = rownames(dfX);
    colnames(dfE) = c('logHazardRatio', 'hazardRatio',
                      'survivalTime', 'censoringStatus', 'X', 'Z',
                      'trainTest');
    # ..........................................................................................


    # ........................................................
    # . Package results :
    # ........................................................
    d = list(A = A, dfX = dfX, dfE = dfE);

    class(d) = "sim.cox";
    # ........................................................


    # ............
    return (d);
    # ............

}

# =================================================================================================
# . End of SuperPcSim.generateDataCoxWithCov.
# =================================================================================================  





# =================================================================================================
# . SuperPcSim.plotSurvivalTimesCoxWithCov : plots survival times generated by 
# . --------------------------------------   SuperPcSim.generateDataCoxWithCv.
# .                              
# .   Syntax example:
# .
# .       d = SuperPcSim.generateDataCoxWithCv(nTwoRegion, nFourRegion, nb, rngSeed, sigma,
# .                                            hazardPanel, betaSim1, betaSim2, betaSim3);
# .       SuperPcSim.plotSurvivalTimesCoxWithCov(d, hazardPanel, betaSim1, betaSim2, betaSim3);
# .
# .   In:
# .
# .       d = data object returned by SuperPcSim.generateDataCox().
# .       hazardPanel = text defining the mean profile defining the covariate Z.
# .       betaSim1, 2, 3 = value of beta1, 2, 3 in the generating Cox model of survival times.
# .
# =================================================================================================

SuperPcSim.plotSurvivalTimesCoxWithCov <- function(dIn, hazardPanel, betaSim1, betaSim2, betaSim3)
{
     # ...................................
     stopifnot(class(dIn) == "sim.cox");
     # ...................................

     
     # ............................................................................................
     par(mfrow = c(2,1));

     xlab = 'Index (sample)';
     ylab = 'Survival time';
     caption = paste("Surv. times for haz.Panel = ", hazardPanel,
                     ", betaSim1 = ", betaSim1,
                     ", betaSim2 = ", betaSim2,
                     ", betaSim3 = ", betaSim3,       
                     sep ="");

     cex.main.OLD = par("cex.main");
     par(cex.main = 0.8);     
     plot(dIn$dfE$survivalTime, xlab = xlab, ylab = ylab, main = caption);
     par(cex.main = cex.main.OLD);
     
#     xlab = 'Index (sample)';
#     ylab = 'Z';
#     caption = paste("Generating covariate Z [lambda = exp(betaSim * Z)]");
#     plot(dIn$dfE$Z, xlab = xlab, ylab = ylab, main = caption);        
#     abline(h = 0.0);

     cex.main.OLD = par("cex.main");
     par(cex.main = 0.8);          
     xlab = 'Index (sample)';
     ylab = 'exp(betaSim * Z)'
     ylim = c(0.0, max(dIn$dfE$hazardRatio));
     caption = paste("True hazard ratio");
     plot(dIn$dfE$hazardRatio, ylim = ylim,
          xlab = xlab, ylab = ylab, main = caption);        
     abline(h = 0.0);
     par(cex.main = cex.main.OLD);     
     
     par(mfrow = c(1,1));
     # ............................................................................................


     # ............
     return (0);
     # ............
}

# =================================================================================================
# . End of SuperPcSim.plotSurvivalTimesCoxWithCov.
# =================================================================================================

