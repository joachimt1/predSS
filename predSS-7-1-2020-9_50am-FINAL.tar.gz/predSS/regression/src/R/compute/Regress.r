# =================================================================================================
# . Regress.r : implementation of regression models.
# . ---------
# .
# =================================================================================================

Regress.MAX_SCORE_FOR_CHI2_NU1 = 224.3847;   # Standin for infinite scores. Corresponds to P-value = 1.0e-50.

# =================================================================================================
# . Regress.computeLmUni : computes scores and P-values for a linear model, regressing the output
# . --------------------   variable against expression values for a set of genes.
# .                        A univariate regression model score is computed for each gene independently.
# .
# .   Syntax:
# .
# .            regS = Regress.computeLmUni(ay, dfX, flagVerbose);
# .
# .   In:
# .     If n = number of samples, and p = number of genes, then (with array dimensions indicated
# .     below) :
# .
# .                ay : n; 1d array of output variable values.
# .               dfX : n * m; data frame with expression values for m genes across n samples.
# .       flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        regS = a list, with members:
# .
# .                       n = number of samples.
# .                       m = number of genes.
# .                      ac = m : gene IDs, corresponding to scores and P-values.
# .                  aalpha = m : intercapt coefficients alpha.
# .                   abeta = m : covariate coefficients beta.
# .                  ascore = m : array of beta / sqrt(phi / ((n - 2) * sx2 * n))
# .                      ap = m : array of corresponding P-values (under Student t test
# .                               test with df = n - 2).
# .
# .................................................................................................
# . Details :
# . -------
# .
# . * For each gene separately, estimates the coefficients for the linear model :
# .
# .            y  = alpha +  beta * x  + eps   , i = 1, ... , n.
# .             i                    i      i
# . 
# .   where y_i is the output variable for sample i, x_i the gene expression level
# .   for that same sample, and eps_i a stochastic noise term.
# .
# =================================================================================================

Regress.computeLmUni <- function(ay, dfX, flagVerbose)
{

      # ....................................................................................
      # . Determine number of samples, catch inconsistencies :
      # ....................................................................................
      n = nrow(dfX);     # Number of samples.
      m = ncol(dfX);     # Number of genes.
      
      ny = length(ay);   # Number of samples in output variables array.

      if (ny != n) {
        msg = "ERROR: from Regress.computeLmUni: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                     n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }
      # .....................................................................................



      # ....................................................................................
      # . Do the sequential computation here, returning the univariate score
      # . for each gene independently.
      # ....................................................................................
      if (flagVerbose) {
        cat(" ..........  Begin univariate linear model score computations for m = ",
            m, " genes.\n", sep ="");
      }

      t1 = proc.time()[3];      
      # .....................................................................................
      # . Compute regression coeffcients :
      # .....................................................................................      
      axm = colMeans(dfX, na.rm = TRUE);                # There are m column means.
      ym = mean(ay, na.rm = TRUE);                      # The single mean for the outcome data.

      dfXc = scale(dfX, center = TRUE, scale = FALSE);  # Center each column (= one gene) separately.
      ayc = ay - ym;                                    # Center the outcome vector.

      asx2 = ((n - 1) / n) * apply(dfXc, 2, var, na.rm = TRUE);         # The m values of sx2 = <dx^2>, where <...> = sample mean.
      asxy = apply(dfXc, 2, function(ax){buf = sum(ayc * ax, na.rm = TRUE); return(buf);});  
      asxy = asxy / n;                                                # The m values of <dx * dy>, where <...> = sample mean.

      abeta = ifelse(asx2 > 0.0, asxy / asx2, 0.0);     # Covariate coefficient beta.
      aalpha = ym - abeta * axm;                        # Intercepts.
      # .....................................................................................
      # . Compute the sum-of-squares of residuals for each gene in turn, then compute the
      # . corresponding t statistics :
      # .....................................................................................
      aphi = sapply(1:m, function(j){abuf = ay - aalpha[j] - abeta[j] * dfX[ ,j];
                                     phi2 = sum(abuf * abuf, na.rm = TRUE);
                                     return(phi2);});

      afac = sqrt(asx2 * ifelse(aphi > 0.0, 1.0 / aphi, 0.0));
      ascore = sqrt(n * (n - 2)) * abeta * afac;    # Statistical score.
      # .....................................................................................
      # . Compute the P-values :
      # .....................................................................................
      n2 = n - 2;                                            # df = n - 2.
      ap = pt(ascore, df = n2, lower.tail = FALSE);          # Corresponding p-values.

      ap = ifelse(ap < 0.5, 2 * ap, 2 * (1 - ap));           # Two-tailed.
      ac = colnames(dfX);                                    # Corresponding gene IDs.
      # .....................................................................................
      # . Display computation time :
      # .....................................................................................
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / m;                                     # Time per gene.
      tau = sprintf("%8.3e", tau);      

      if (flagVerbose) {
        cat(" ..........  Score computation done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per gene.\n");
      }
      # ....................................................................................


      
      # ....................................................................................
      # . TEST : use R lm function model, compare to calculation above.
      # . Note that this is about 100 times slower.
      # ....................................................................................
      ngo = FALSE;      # DEACTIVATES this test.

      if (ngo) {
        cat(" ..........  Begin TEST using lm function for m = ", m, " genes.\n", sep ="");      
        t1 = proc.time()[3];
        # .....................................................................................
        # . Call the R function lm :
        # .....................................................................................        
        aval = sapply(1:m, function(j){ax = dfX[ , j];
                                       fl = lm(ay ~ ax);
                                       fls = summary(fl);
                                       fscore = fls$fstatistic[1];
                                       alpha = fl$coefficients[1];                                     
                                       beta = fl$coefficients[2];
                                       abuf = c(alpha, beta, fscore);
                                       return (abuf);
                                     });

        aalphaTest = rep(0.0, times = m);
        abetaTest = rep(0.0, times = m);
        afscoreTest = rep(0.0, times = m);            
        # .....................................................................................
        # . Unpack results, and compute P-values :
        # .....................................................................................              
        for (j in 1:m) {
          aalphaTest[j] = aval[[j]][1];          # Intercept.
          abetaTest[j] = aval[[j]][2];              # Covariate coefficient beta.
          afscoreTest[j] = aval[[j]][3];            # F statistic, for n - 2 degrees of freedom.      
        }
      
        n2 = n - 2;                                                              # df = n - 2.
        apTest = pf(afscoreTest, df1 = 1, df2 = n2, lower.tail = FALSE);          # Corresponding p-values.
        # .....................................................................................
        # . Display computation time using lm function :
        # .....................................................................................
        t2 = proc.time()[3] - t1;                         # Total time for computation (s).
        tau = t2 / m;                                     # Time per gene.
        tau = sprintf("%8.3e", tau);      

        cat(" ..........  TEST: lm computation done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per gene.\n");
        # .....................................................................................
        # . Comparison plots :
        # .....................................................................................
        par(mfrow = c(2,2));

        plot(aalpha, aalphaTest, caption = "alpha: intercept");
        plot(abeta, abetaTest, caption = "beta: covariate coefficient");

        afscore = ascore^2;
        plot(afscore, afscoreTest, caption = "F statistic");

        plot(-log(ap, base = 10), -log(apTest, base = 10), caption = "P-values");      
      
        par(mfrow = c(1,1));
        # .....................................................................................
      }
      # .....................................................................................



      # ........................................
      # . Package the results :
      # ........................................
      regS = list(n = n,
                  m = m,
                  ac = ac,
                  aalpha = aalpha,
                  abeta = abeta,
                  ascore = ascore,
                  ap = ap);
      # ........................................


      # .............
      return (regS);
      # .............
  
}

# =================================================================================================
# . End of Regress.computeLmUni.
# =================================================================================================





# =================================================================================================
# . Regress.computeLogisticUni : computes scores and P-values for a logistic model, regressing 
# . --------------------------   a binary output variable against expression values one gene at
# .                              a time.
# .
# .   Syntax:
# .
# .            regS = Regress.computeLogisticUni(ay, dfX, flagVerbose);
# .
# .   In:
# .     If n = number of samples, and m = number of genes, then (with array dimensions indicated
# .     below) :
# .
# .                ay : n; 1d array of output variable values. Values of y e {0, 1}.
# .               dfX : n * m; data frame with expression values for m genes across n samples.
# .       flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        regS = a list, with members:
# .
# .                       n = number of samples.
# .                       m = number of genes.
# .                      ac = m : gene IDs, corresponding to scores and P-values.
# .                  aalpha = m : intercept coefficients alpha.
# .                   abeta = m : covariate coefficients beta.
# .                  ascore = m : log-likelihood values.
# .                      ap = m : array of corresponding P-values (under Student t test
# .                               test with df = n - 2).
# .
# .................................................................................................
# . Details :
# . -------
# .
# . * For each gene separately, estimates the coefficients {alpha, beta} in the logistic model :
# .
# .                                          1
# .             P(y = 1|x) =  ------------------------------
# .                            1 + exp(- (alpha + beta * x))
# .
# .
# .   using the data {y_1, . . ., y_n} and {x_1, . . . , x_n}
# .   where y_i is the output variable for sample i and x_i the corresponding gene expression 
# .   level.
# .
# =================================================================================================

Regress.computeLogisticUni <- function(ay, dfX, flagVerbose)
{

      # ....................................................................................
      # . Determine number of samples, catch inconsistencies :
      # ....................................................................................
      n = nrow(dfX);     # Number of samples.
      m = ncol(dfX);     # Number of genes.
      
      ny = length(ay);   # Number of samples in output variables array.

      if (ny != n) {
        msg = "ERROR: from Regress.computeLogisticUni: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                     n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      msg = Cox.checkBinary(ay);   # Check that all values are in {0, 1}.

      if (msg != 'ok') {
        cat("ERROR: from Regress.computeLogisticUni:\n");
        cat("For the output variable array ay:\n", sep = "");
        cat(msgBin);
        stop();
      }      
      # .....................................................................................


      
      # .....................................................................................
      # . Generate the log-likelihood for the model corresponding to the NULL hypothesis
      # . of beta1 = 0 (J. Theilhaber):
      # .....................................................................................      
      n1 = sum(ay);                                       # Number of instances with y = 1.
      n0 = n - n1;                                        # Number of instances with y = 0.

      if ((n0 == 0) || (n1 == 0)) {
        cat("WARNING: from Regress.computeLogisticUni:\n");
        cat("For the outcome variable array ay, all elements are 1 or all are 0.\n", sep = "");
        cat("n0 = ", n0, " n1 = ", n1, "\n", sep ="");
        cat("Continue execution.\n");
      }

      if ((n0 != 0) && (n1 != 0)) {
        beta0Star = log(n1 / (n - n1));                     # Optimal beta0, when beta = 0.        
        lNull = n0 * log(n0) + n1 * log(n1) - n * log(n);   # Log-likelihood with (beta0, beta = 0).
      } else {
        lNull = 0.0;
      }      
      # .....................................................................................

      

      # ....................................................................................
      # . Do the sequential computation here, returning the univariate score
      # . for each gene independently.
      # ....................................................................................
      if (flagVerbose) {
        cat(" ..........  Begin univariate logistic model computations for m = ",
            m, " genes.\n", sep ="");
      }
      # ....................................................................................


      # .....................................................................................
      # . Preamble : define chunk sizes.
      # .....................................................................................
      mchunk = floor(4000 / n);            # For testing. zzzzz
      #xxx mchunk = floor(100000 / n);

      if (mchunk < 1) {
        cat("ERROR: from Regress.computeLogisticUni:\n");        
        cat("Sample size n = ", n, " is too large.\n", sep = '');
        stop();
      }

      ch = Math.makeChunks(m, mchunk);
      # .....................................................................................
      
      
      
      # ....................................................................................
      # . Main loop invoking glm for logistic regression :
      # ....................................................................................
      t1 = proc.time()[3];

      for (k in 1:ch$kchunk) {
        cat("Processing chunk ", k, " out of ", ch$kchunk, ".\n", sep = "");

        mLo = ch$amLo[k];
        mHi = ch$amHi[k];

        avalBuf = sapply(mLo:mHi, function(j){ax = dfX[ , j];
                                              fl = glm(ay ~ ax, family = binomial("logit")); 
                                              fls = summary(fl);
                                              acoef = fls$coefficients;                       # Coefficients array.
                                              alpha = acoef[1, 1];                            # Intercept.
                                              beta = acoef[2, 1];                             # Slope for x-dependency.
                                              pbeta = acoef[2, 4];                            # P-value for x-dependency.
                                              score = - 0.5 * fls$deviance;                   # Log-likelihood of full model.
                                              qR = 2.0 * (score - lNull);                     # Likelihood ratio statistic (J. Theilhaber).
                                              pR = pchisq(qR, df = 1, lower.tail = FALSE);    # p-value from likelihood ratio (j. Theilhaber).
                                              abuf = c(alpha, beta, pbeta, score, pR);
                                              return (abuf);
                                            });
        if (k == 1) {
          aval = avalBuf;
        } else {
          aval = cbind(aval, avalBuf);
        }
      }
      # .....................................................................................
      # . Unpack results, and compute P-values :
      # .....................................................................................
      aalpha = rep(0.0, times = m);
      abeta = rep(0.0, times = m);
      ap = rep(0.0, times = m);
      ascore = rep(0.0, times = m);

      for (j in 1:m) {
        aalpha[j] = aval[1, j];              # Intercept.
        abeta[j] = aval[2, j];               # Covariate coefficient beta.
        #xxx  ap[j] = aval[3, j]  ;          # P-value from beta (suppressed).
        ap[j] = aval[5, j]  ;                # P-value from entire model (J. Theilhaber).
        ascore[j] = aval[4, j];              # Log-likelihood.
      }

      ac = colnames(dfX);                                    # Corresponding gene IDs.      
      # .....................................................................................
      # . Display computation time using glm function :
      # .....................................................................................
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / m;                                     # Time per gene.
      tau = sprintf("%8.3e", tau);      

      if (flagVerbose) {      
        cat(" ..........  Logistic model computations done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per gene.\n");
      }
      # .....................................................................................



      # .............................................................
      # . Package the results :
      # .............................................................
      regS = list(n = n,
                  m = m,
                  ac = ac,
                  aalpha = aalpha,        
                  abeta = abeta,
                  ascore = ascore,
                  ap = ap);
      # .............................................................


      # .............
      return (regS);
      # .............
  
}

# =================================================================================================
# . End of Regress.computeLogisticUni.
# =================================================================================================





# ================================================================================================================
# . Regress.computeLogisticUniMASKED : computes scores and P-values for a logistic model, regressing 
# . --------------------------------   a binary output variable against expression values one gene at
# .                                    a time.  This MASKED version is identical to Regress.computeLogisticUni(),
# .                                    with the exception that it masks out regressions with all x or all
# .                                    y values equal, setting P-values to one.
# .      
# .   Syntax:
# .
# .            regS = Regress.computeLogisticUniMASKED(ay, dfX, flagVerbose);
# .
# .   In:
# .     If n = number of samples, and m = number of genes, then (with array dimensions indicated
# .     below) :
# .
# .                ay : n; 1d array of output variable values. Values of y e {0, 1}.
# .               dfX : n * m; data frame with expression values for m genes across n samples.
# .       flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        regS = a list, with members:
# .
# .                       n = number of samples.
# .                       m = number of genes.
# .                      ac = m : gene IDs, corresponding to scores and P-values.
# .                  aalpha = m : intercept coefficients alpha.
# .                   abeta = m : covariate coefficients beta.
# .                  ascore = m : log-likelihood values.
# .                      ap = m : array of corresponding P-values (under Student t test
# .                               test with df = n - 2).
# .
# .................................................................................................
# . Details :
# . -------
# .
# . * For each gene separately, estimates the coefficients {alpha, beta} in the logistic model :
# .
# .                                          1
# .             P(y = 1|x) =  ------------------------------
# .                            1 + exp(- (alpha + beta * x))
# .
# .
# .   using the data {y_1, . . ., y_n} and {x_1, . . . , x_n}
# .   where y_i is the output variable for sample i and x_i the corresponding gene expression 
# .   level.
# .
# ============================================================================================================

Regress.computeLogisticUniMASKED <- function(ay, dfX, flagVerbose)
{

      # ....................................................................................
      # . Determine number of samples, catch inconsistencies :
      # ....................................................................................
      n = nrow(dfX);     # Number of samples.
      m = ncol(dfX);     # Number of genes.
      
      ny = length(ay);   # Number of samples in output variables array.

      if (ny != n) {
        msg = "ERROR: from Regress.computeLogisticUniMASKED: ";
        msg = paste("The output variable vector at has ny = ", ny, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                     n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      msg = Cox.checkBinary(ay);   # Check that all values are in {0, 1}.

      if (msg != 'ok') {
        cat("ERROR: from Regress.computeLogisticUniMASKED:\n");
        cat("For the output variable array ay:\n", sep = "");
        cat(msgBin);
        stop();
      }      
      # .....................................................................................



      
      # .....................................................................................
      # . Generate the log-likelihood for the model corresponding to the NULL hypothesis
      # . of beta1 = 0 (J. Theilhaber):
      # .....................................................................................      
      n1 = sum(ay);                                       # Number of instances with y = 1.
      n0 = n - n1;                                        # Number of instances with y = 0.

      if ((n0 == 0) || (n1 == 0)) {
        cat("WARNING: from Regress.computeLogisticUni:\n");
        cat("For the outcome variable array ay, all elements are 1 or all are 0.\n", sep = "");
        cat("n0 = ", n0, " n1 = ", n1, "\n", sep ="");
        cat("Continue execution.\n");
      }

      if ((n0 != 0) && (n1 != 0)) {
        beta0Star = log(n1 / (n - n1));                     # Optimal beta0, when beta = 0.        
        lNull = n0 * log(n0) + n1 * log(n1) - n * log(n);   # Log-likelihood with (beta0, beta = 0).
      } else {
        lNull = 0.0;
      }
      # .....................................................................................



      

      # ....................................................................................
      # . Do the sequential computation here, returning the univariate score
      # . for each gene independently.
      # ....................................................................................
      if (flagVerbose) {
        cat(" ..........  Begin univariate logistic model computations for m = ",
            m, " genes.\n", sep ="");
      }
      # ....................................................................................


      # .....................................................................................
      # . Preamble : define chunk sizes.
      # .....................................................................................
      mchunk = floor(4000 / n);            # For testing. zzzzz
      #xxx mchunk = floor(100000 / n);

      if (mchunk < 1) {
        cat("ERROR: from Regress.computeLogisticUniMASKED:\n");        
        cat("Sample size n = ", n, " is too large.\n", sep = '');
        stop();
      }

      ch = Math.makeChunks(m, mchunk);
      # .....................................................................................
      
      
      
      # ....................................................................................
      # . Main loop invoking glm for logistic regression :
      # ....................................................................................
      t1 = proc.time()[3];

      for (k in 1:ch$kchunk) {
        cat("Processing chunk ", k, " out of ", ch$kchunk, ".\n", sep = "");

        mLo = ch$amLo[k];
        mHi = ch$amHi[k];

        avalBuf = sapply(mLo:mHi, function(j){ax = dfX[ , j];
                                              rbuf = range(ax);
                                              if (rbuf[2] != rbuf[1]) {
                                                fl = glm(ay ~ ax, family = binomial("logit")); 
                                                fls = summary(fl);
                                                acoef = fls$coefficients;                       # Coefficients array.
                                                alpha = acoef[1, 1];                            # Intercept.
                                                beta = acoef[2, 1];                             # Slope for x-dependency.
                                                pbeta = acoef[2, 4];                            # P-value for x-dependency.
                                                score = - 0.5 * fls$deviance;                   # Log-likelihood for full model.
                                                qR = 2.0 * (score - lNull);                     # Likelihood ratio statistic (J. Theilhaber).
                                                pR = pchisq(qR, df = 1, lower.tail = FALSE);    # p-value from likelihood ratio (J. Theilhaber).
                                              } else {
                                                alpha = 0.0;                  # Intercept (dummy value).
                                                beta = 0.0;                   # Slope for x-dependency (dummy value).
                                                pbeta = 1.0;                  # P-value for x-dependency (dummy value).
                                                score = 0.0;                  # Log-likelihood  (dummy value).
                                                pR = 1.0;                     # p-value from likelihood ratio (dummy value)(J. Theilhaber).
                                              }
                                              abuf = c(alpha, beta, pbeta, score, pR);
                                              return (abuf);
                                            });

        if (k == 1) {
          aval = avalBuf;
        } else {
          aval = cbind(aval, avalBuf);
        }
      }
      # .....................................................................................
      # . Unpack results, and compute P-values :
      # .....................................................................................
      aalpha = rep(0.0, times = m);
      abeta = rep(0.0, times = m);
      ap = rep(0.0, times = m);
      ascore = rep(0.0, times = m);

      for (j in 1:m) {
        aalpha[j] = aval[1, j];              # Intercept.
        abeta[j] = aval[2, j];               # Covariate coefficient beta.
        #xxx  ap[j] = aval[3, ]  ;           # P-value from beta (suppressed).
        ap[j] = aval[5, j]  ;                # P-value from entire model (J. Theilhaber).        
        ascore[j] = aval[4, j];              # Log-likelihood.
      }

      ac = colnames(dfX);                                    # Corresponding gene IDs.      
      # .....................................................................................
      # . Display computation time using glm function :
      # .....................................................................................
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / m;                                     # Time per gene.
      tau = sprintf("%8.3e", tau);      

      if (flagVerbose) {      
        cat(" ..........  Logistic model computations done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per gene.\n");
      }
      # .....................................................................................



      # .............................................................
      # . Package the results :
      # .............................................................
      regS = list(n = n,
                  m = m,
                  ac = ac,
                  aalpha = aalpha,        
                  abeta = abeta,
                  ascore = ascore,
                  ap = ap);
      # .............................................................


      # .............
      return (regS);
      # .............
  
}

# =================================================================================================
# . End of Regress.computeLogisticUniMASKED.
# =================================================================================================
