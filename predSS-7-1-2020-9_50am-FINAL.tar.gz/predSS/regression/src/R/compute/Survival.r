# ======================================================================================
# . Survival.r : survival analysis functions, mostly for Zhang et al. course work,
# . ----------   ST745. 
# ======================================================================================

# ======================================================================================
# . Survival.weibullL : computes the log-likelihood for the Weibull model for a set of 
# . -----------------   right-censored data.
# .
# . Syntax :
# .
# .      u = Survival.weibullL(at, as, alpha, lambda);
# .
# . In:
# .      at = array of survival or right-censored times.
# .      as = array of status indicator (1 = notcensored, 0 = censored).
# .      alpha = alpha parameter of Weibull distribution.
# .      lambda = lambda parameter of Weibull distribution.
# .
# . Out:
# .      L = log-likelihood.
# .
# ======================================================================================

Survival.weibullL <- function(at, as, alpha, lambda)
{

  # ................................................................
  q1 = sum(as);
  q2 = sum(as * log(at));
  q4 = sum(at^alpha);

  L = q1 * log(alpha * lambda) + (alpha - 1.0) * q2 - lambda * q4;
  # .................................................................

  
  # ..........
  return (L);
  # ..........  
  
}

# ======================================================================================
# . End of Survival.weibullL.
# ======================================================================================


# ======================================================================================
# . Survival.weibullU : computes the score function for the Weibull model for a set of 
# . -----------------   right-censored data.
# .
# . Syntax :
# .
# .      u = Survival.weibullU(at, as, alpha, lambda);
# .
# . In:
# .      at = array of survival or right-censored times.
# .      as = array of status indicator (1 = notcensored, 0 = censored).
# .      alpha = alpha parameter of Weibull distribution.
# .      lambda = lambda parameter of Weibull distribution.
# .
# . Out:
# .      u = array, with alpha = component 1 and lambda = componet 2.
# .
# ======================================================================================

Survival.weibullU <- function(at, as, alpha, lambda)
{

  # ............................................
  q1 = sum(as);
  q2 = sum(as * log(at));
  q3 = sum(log(at) * (at^alpha));
  q4 = sum(at^alpha);

  uAlpha = q1 / alpha + q2 - lambda * q3;
  uLambda = q1 / lambda - q4;
  # ............................................

  
  # .......................
  u = c(uAlpha, uLambda);
  # .......................

  
  # ..........
  return (u);
  # ..........  
  
}

# ======================================================================================
# . End of Survival.weibullU.
# ======================================================================================



# ======================================================================================
# . Survival.weibullJ : computes the Fisher information matrix for the Weibull model 
# . -----------------   for a set of right-censored data.
# .
# . Syntax :
# .
# .      J = Survival.weibullJ(at, as, alpha, lambda);
# .
# . In:
# .      at = array of survival or right-censored times.
# .      as = array of status indicator (1 = notcensored, 0 = censored).
# .      alpha = alpha parameter of Weibull distribution.
# .      lambda = lambda parameter of Weibull distribution.
# .
# . Out:
# .      J = matrix, with alpha = component 1 and lambda = componet 2.
# .
# ======================================================================================

Survival.weibullJ <- function(at, as, alpha, lambda)
{

  # ............................................
  q1 = sum(as);
  q3 = sum(log(at) * (at^alpha));
  q5 = sum((log(at))^2 * (at^alpha));

  Jaa = q1 / (alpha^2) + lambda * q5;
  Jal = q3;
  Jll = q1 / lambda^2;
  # ............................................

  
  # ..........................................................
  J = matrix(c(Jaa, Jal, Jal, Jll), nrow = 2 , byrow = TRUE);
  # ..........................................................

  
  # ..........
  return (J);
  # ..........  
  
}

# ======================================================================================
# . End of Survival.weibullJ.
# ======================================================================================



# ======================================================================================
# . Survival.weibullUMLE : function which is 0 for the MLE of alpha.
# . --------------------   
# .
# . Syntax :
# .
# .      u = Survival.weibullUMLE(at, as, alpha);
# .
# . In:
# .      at = array of survival or right-censored times.
# .      as = array of status indicator (1 = notcensored, 0 = censored).
# .      alpha = alpha parameter of Weibull distribution.
# .
# . Out:
# .      value.
# .
# ======================================================================================

Survival.weibullUMLE <- function(at, as, alpha)
{

  # ............................................
  q1 = sum(as);
  q2 = sum(as * log(at));
  q3 = sum(log(at) * (at^alpha));
  q4 = sum(at^alpha);

  lambda = q1 / q4;
  uAlphaMLE = q1 / alpha + q2 - lambda * q3;
  # ............................................

  
  # .................
  return (uAlphaMLE);
  # .................
  
}

# ======================================================================================
# . End of Survival.weibullUMLE.
# ======================================================================================



# ======================================================================================
# . Survival.weibullS : weibull distrubution survival function.
# . -----------------   
# .
# . Syntax :
# .
# .      s = Survival.weibullS(t, alpha, lambda);
# .
# ======================================================================================

Survival.weibullS <- function(t, alpha, lambda)
{

  # ................................
  s = exp(- lambda * t^alpha);
  # ................................

 
  # ..........
  return (s);
  # ..........
  
}

# ======================================================================================
# . End of Survival.weibullS.
# ======================================================================================
