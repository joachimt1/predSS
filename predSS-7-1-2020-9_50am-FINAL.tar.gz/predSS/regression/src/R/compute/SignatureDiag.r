# ================================================================================================
# . SignatureDiag.r : utility functions for post-processing of panels classified by
# . ---------------   sensitivity or activation signatures.
# ================================================================================================


# =========================================================================================================
# . SignatureDiag.displayCvec : does post-processing of a CVEC (classification output
# . -------------------------   file) in data frame format. Generates a barplot of
# .                             the frequency of a specified output category against
# .                             an internal factor.
# .
# . Syntax:
# .
# .     SignatureDiag.displayCvec(dfIn,
# .                               factorClassOut,
# .                               nameClassOut,
# .                               factorProb,
# .                               probMin,
# .                               factorCat,
# .                               xlabIn,
# .                               ylabIn,
# .                               caption);
# .
# . In:
# .
# .                 dfIn = input data frame (required).
# .       factorClassOut = factor specifying the output class (e.g. 'classOut')  (required).
# .         nameClassOut = actual name of category fro which we will plot the frequency (e.g. 'sensitive')
# .                        (required).
# .
# .           factorProb = factor specifying value of P(nameClassOut|x) (e.g. 'P.sensitive.x').
# .                        If 'NONE' (default value), no additional filtering will be done.
# .                        (optional).
# .              probMin = applies the additional filter P(nameClassOut|x) > probMin in declaring
# .                        instances to be in class nameClassOut. Ignored if factorProb = 'NONE'.
# .                        (required if factorProb != 'NONE').
# .
# .            factorCat = name of factor specifying the categories against which the frequencies
# .                        will be plotted (e.g. 'Tissue').  (required)
# .
# .               xlabIn = label for the x-axis (optional -- default no label).
# .               ylabIn = label for the y-axis (optional -- default no label).
# .              caption = caption for the plot (optional -- default no caption).
# .
# ..........................................................................................................
# . Example : this reads a Cvec file (formatted as a data frame by removing the first column name '#QUAL',
# . but keeping the leading tab), generates a frequency barplot, and returns a data frame containing
# . the frequency table :
# .
# .    .............................................................................................................
# .    fin = "c:/develop/R-Programs/regression/data/Gene-expression/SAR125844_sensitivity_ntop50_cosineActual.DF";
# .    dfMRaw = read.table(file = fin);
# .    dfM = dfMRaw[dfMRaw$classIn == 'NONE', ];
# .
# .    dfOut = SignatureDiag.displayCvec(dfIn = dfM, 
# .     	      	                 factorClassOut = 'classOut', 
# .                	                 nameClassOut = 'sensitive',
# .                        	         factorProb = 'NONE', probMin = 0.0,
# .	                                 factorCat = 'Tissue',
# .	                                 xlabIn = '',
# .        	                         ylabIn = 'Fraction of sensitive cell lines',
# .                	                 caption = 'Frequency of MET-inhibitor sensitive cell lines by tissue type');
# .
# .    fo =  "c:/develop/R-Programs/regression/data/Gene-expression/SAR125844_sensitivity_ntop50_cosineActual-FREQUENCIES.TSV";
# .    DataFrame.writeFlat(dfOut, fo);
# .    .............................................................................................................
# .
# .
# ==========================================================================================================

SignatureDiag.displayCvec <- function(dfIn, factorClassOut, nameClassOut,
                                      factorProb = 'NONE', probMin = 0.0,
                                      factorCat,
                                      xlabIn = '',
                                      ylabIn = '',
                                      caption = '')
{

     # ....................................................................................
     if (is.null(dfIn[[factorClassOut]])) {
       cat("ERROR: from SignatureDiag.displayCvec:\n");
       cat("factorClassOut = ", factorClassOut, " is not defined in input data frame.\n");
       stop();
     }

     if (factorProb != 'NONE') {
       if (is.null(dfIn[[factorProb]])) {
         cat("ERROR: from SignatureDiag.displayCvec:\n");
         cat("factorProb = ", factorProb, " is not defined in input data frame.\n");
         stop();
       }

       if (missing(probMin)) {
         cat("ERROR: from SignatureDiag.displayCvec:\n");
         cat("factorProb = ", factorProb, " is defined, but probMin is missing.\n");
         stop();
       }
     }

     if (is.null(dfIn[[factorCat]])) {
       cat("ERROR: from SignatureDiag.displayCvec:\n");
       cat("factorCat = ", factorCat, " is not defined in input data frame.\n");
       stop();
     }     
     # ....................................................................................


     

     # ..............................................................................................................
     # . * Generate counts of selected output class against specified category :
     # . >> No additional probability filter :
     # ...............................................................................................................
     ac = by(dfM[[factorClassOut]], dfM[[factorCat]], length);                   # Total instances in each category.
     # ...............................................................................................................          
     # . >> No additional probability filter :
     # ...............................................................................................................     
     if (factorProb == 'NONE') {
       acPos = by(dfM[[factorClassOut]], dfM[[factorCat]], 
                       function(x){nbuf = sum(x == nameClassOut); return(nbuf);})       # Positives in each catgeory.
     }
     # ...............................................................................................................          
     # . >> Additional probability filter :
     # ...............................................................................................................
     if (factorProb != 'NONE') {     
       aflagPos = ifelse((dfM[[factorClassOut]] == nameClassOut) & (dfM[[factorProb]] >= probMin), 1, 0);
       acPos = by(aflagPos, dfM[[factorCat]], function(x){ns = sum(x); return(ns);})    # Positives in each catgeory.
     }
     # ...............................................................................................................
     # . Now compute the frequency estimates :
     # ...............................................................................................................         
     af = acPos / ac;                      # Estimated frequency for each tissue.
     as = sqrt(af * (1.0 - af) / ac);      # Estimated standard deviation in estimate.
     # ...............................................................................................................


     
     
     # ...............................................................................................................
     # . >> Sort the arrays in order of increasing frequency :
     # ...............................................................................................................
     sBuf = sort(as.numeric(af), decreasing = FALSE, index.return = TRUE);
     afSorted = sBuf[["x"]];                                     # Sorted frequencies.
     indexSorted = sBuf[["ix"]];                                 # Sort index.
     asSorted = as[indexSorted];                                 # Sorted standard devs.
     acSorted = ac[indexSorted];                                 # Sorted counts.
     acPosSorted = acPos[indexSorted];                           # Sorted positive counts.
     atSorted = rownames(af)[indexSorted];                       # Sorted names.
     # ...............................................................................................................



     # ..................................................................................................
     # . Make barplots, with non-exponentiated error bars :
     # ..................................................................................................
     Stat.barplotWithErrorBars(ay = afSorted, 
                               as = asSorted, 
                               alab = atSorted, 
                               flagExp = FALSE, 
                               xlab = xlabIn,
                               ylab = ylabIn,
                               caption = caption);
     # ..................................................................................................



     # ..................................................................................................
     # . Package the sorted frequency results as a data frame.
     # . Add numerical and alphabetical sort keys.
     # ..................................................................................................
     abufRank = 1:length(atSorted);                                 # Will indicate left-to-right order.
     abufRankAlpha = SignatureDiag.generateAlphabeticalPrefixes()[1:length(atSorted)];
     
     aRankAndAtSorted = paste(abufRankAlpha, "_", atSorted, sep = "");   # Special key for Spotfire display.
     
     dfFreq = data.frame(atSorted = atSorted,
                         afSorted = afSorted,
                         asSorted = asSorted,
                         acSorted = acSorted,
                         acPosSorted = acPosSorted,
                         abufRank = abufRank,
                         aRankAndAtSorted = aRankAndAtSorted);

     rankAlpha =  paste("rank_", factorCat, sep = "");                   # Special key for Spotfire display.

     colBuf = c(factorCat,
                'frequencyPos',
                'sdFrequencyPos',
                'countTotal',
                'countPos',
                'rankOnFrequency',
                rankAlpha);
     
     colnames(dfFreq) = colBuf;
     # ....................................................................................................



     # .................................................................................
     # . Append to the input data frame the frequency results (as additional columns)
     # . then order all rows in accordance with increasing frequency of the
     # . corresponding category :
     # .................................................................................
     dfOut = merge(dfIn, dfFreq);
     dfOut = dfOut[order(dfOut$rankOnFrequency), ];
     # .................................................................................


     # .....................................................
     # . Package results :
     # .....................................................
     sigBuf = list(dfFreq = dfFreq, dfOut = dfOut);
     # .....................................................
     

     # .................
     return (sigBuf);
     # .................
     
}

# =================================================================================================
# . End of SignatureDiag.displayCvec.
# =================================================================================================


# =================================================================================================
# . SignatureDiag.generateAlphabeticalPrefixes :  generates a series of alphabetical prefixes,
# . ------------------------------------------    basically for use in Spotfire display.
# .
# =================================================================================================

SignatureDiag.generateAlphabeticalPrefixes <- function()
{

    # ...........................................................
    x = c('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
          'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
          's', 't', 'u', 'v', 'w', 'x', 'y', 'z');
    # ...........................................................


    # ...........................................................    
    abuf1 = as.character(t(outer(x, x, paste, sep = "")));
    abuf2 = as.character(t(outer(abuf1, x, paste, sep = "")));
    # ...........................................................

    
    # ...............
    return (abuf2);
    # ...............    
    
}

# =================================================================================================
# . End of SignatureDiag.generateAlphabeticalPrefixes.
# =================================================================================================
