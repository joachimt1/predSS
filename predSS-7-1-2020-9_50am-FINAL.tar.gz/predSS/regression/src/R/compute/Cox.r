# =================================================================================================
# . Cox.r : implementation of forms of Cox proportional hazard calculations.
# . -----   
# .
# =================================================================================================

library(survival);

Cox.MAX_SCORE_FOR_CHI2_NU1 = 224.3847;   # Standin for infinite scores. Corresponds to P-value = 1.0e-50.
Cox.MAX_SEBETA = 100.0;                  # Maximum for standard error in beta.

# =================================================================================================
# . Cox.computeOnDataFrameSimple : computes Cox scores and P-values for a set of survival
# . ----------------------------   data against expression values for a set of genes.
# .                                A univariate Cox score is computed for each gene independently.
# .
# .   Note 1 : this version is computing the score U(0)^2 / J(0) (beta = 0, score test statistic).
# .
# .   Note 2 : this is a sequential application of the native R method coxph, and is thus
# .            relatively slow.
# .                                
# .   Syntax:
# .
# .            coxS = Cox.computeOnDataFrameSimple(at, as, dfX, flagVerbose);
# .
# .   In:
# .     If n = number of samples, and p = number of genes, then (with array dimensions indicated
# .     below) :
# .
# .                at : n; 1d array of survival lifetimes for the different samples considered.
# .                as : n; 1d array of corresponding censoring statuses; 1 = not censored,
# .                     0 = censored.
# .               dfX : n * m; data frame with expression values for m genes across n samples.
# .       flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        coxS = a list, with members:
# .
# .                       n = number of samples.
# .                       m = number of genes.
# .                      ac = m : gene IDs, corresponding to scores and P-values.
# .                   abeta = m : covariate coefficients beta, all 0 here.
# .                  ascore = m : array of U^2(beta = 0) / J(beta = 0) scores.
# .                      ap = m : array of corresponding P-values (under chisq
# .                               test with df = 1).
# .
# =================================================================================================

Cox.computeOnDataFrameSimple <- function(at, as, dfX, flagVerbose)
{

      # ........................................................................
      # . Determine nmber of samples, catch inconsistencies :
      # ........................................................................
      n = nrow(dfX);     # Number of samples.
      m = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival times array.
      ns = length(as);   # Number of samples in censoring status array.

      if (nt != n) {
        msg = "ERROR: from Cox.computeOnDataFrameSimple: ";
        msg = paste("The lifetime vector at has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                     n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from Cox.computeOnDataFrameSimple: ";
        msg = paste("The censoring vector as has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                    n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      # .........................................................................



      # ....................................................................................
      # . Do the sequential computation here, returning the univariate score
      # . for each gene independently. Note that we are returning the score as defined
      # . by the score vector (here a scalar) at beta = 0. For using th elog-likelihood
      # . instead, we would write instead in the sapply below :
      # .
      # .            score = 2.0 * (coxBuf$loglik[2] - coxBuf$loglik[1]);
      # .            return (score)});
      # .
      # . It appears that in practice this makes little difference.
      # ....................................................................................
      if (flagVerbose) {
        cat(" ..........  Begin univariate Cox score computations for m = ",
            m, " genes.\n", sep ="");
      }
      
      t1 = proc.time()[3];
      aval = sapply(1:m,  function(j)
                   {coxBuf = coxph(Surv(at, as) ~ dfX[ ,j],
                                   init = c(0.0),
                                   control = coxph.control(iter.max = 0),
                                   method = 'breslow');
                    
                    abuf = c(coxBuf$score, coxBuf$coefficients[1]);
                    return(abuf)});                     # Score-vector score and beta.
                       
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / m;                                     # Time per gene.
      tau = sprintf("%8.3e", tau);      

      if (flagVerbose) {
        cat(" ..........  Score computation done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per gene.\n");
      }
     
      ascore = aval[1, ];     # Score-vector score.
      abeta = aval[2, ];      # Covariate coefficient beta.      
      ap = pchisq(ascore, df = 1, lower.tail = FALSE);       # Corresponding p-values.
      ac = colnames(dfX);                                    # Corresponding gene IDs.
      # ....................................................................................
      


      # ........................................
      # . Package the results :
      # ........................................
      coxS = list(n = n,
                  m = m,
                  ac = ac,
                  abeta = abeta,
                  ascore = ascore,
                  ap = ap);
      # ........................................


      # .............
      return (coxS);
      # .............
  
}

# =================================================================================================
# . End of Cox.computeOnDataFrameSimple.
# =================================================================================================



# =================================================================================================
# . Cox.computeOnDataFrameSimpleBeta : computes Cox scores and P-values for a set of survival
# . --------------------------------   data against expression values for a set of genes.
# .                                    A univariate Cox score is computed for each gene independently.
# .
# .   Note 1 : this version is computing the score 2 * (l(beta*) - l(0)) (beta != 0, log-likelihood
# .            test statistic).
# .
# .   Note 2 : this is a sequential application of the native R method coxph, and is thus
# .            relatively slow.
# .                                
# .   Syntax:
# .
# .            coxS = Cox.computeOnDataFrameSimpleBeta(at, as, dfX, flagVerbose);
# .
# .   In:
# .     If n = number of samples, and p = number of genes, then (with array dimensions indicated
# .     below) :
# .
# .                at : n; 1d array of survival lifetimes for the different samples considered.
# .                as : n; 1d array of corresponding censoring statuses; 1 = not censored,
# .                     0 = censored.
# .               dfX : n * m; data frame with expression values for m genes across n samples.
# .       flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        coxS = a list, with members:
# .
# .                       n = number of samples.
# .                       m = number of genes.
# .                      ac = m : gene IDs, corresponding to scores and P-values.
# .                   abeta = m : covariate coefficients beta, all 0 here.
# .                  ascore = m : array of U^2(beta = 0) / J(beta = 0) scores.
# .                      ap = m : array of corresponding P-values (under chisq
# .                               test with df = 1).
# .
# =================================================================================================

Cox.computeOnDataFrameSimpleBeta <- function(at, as, dfX, flagVerbose)
{

      # ........................................................................
      # . Determine nmber of samples, catch inconsistencies :
      # ........................................................................
      n = nrow(dfX);     # Number of samples.
      m = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival times array.
      ns = length(as);   # Number of samples in censoring status array.

      if (nt != n) {
        msg = "ERROR: from Cox.computeOnDataFrameSimpleBeta: ";
        msg = paste("The lifetime vector at has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                     n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from Cox.computeOnDataFrameSimpleBeta: ";
        msg = paste("The censoring vector as has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                    n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      # .........................................................................



      # ....................................................................................
      # . Do the sequential computation here, returning the univariate score
      # . for each gene independently. Note that we are returning the score as defined
      # . by the score vector (here a scalar) at beta = 0. For using the log-likelihood
      # . instead, we would write instead in the sapply below :
      # .
      # .            score = 2.0 * (coxBuf$loglik[2] - coxBuf$loglik[1]);
      # .            return (score)});
      # .
      # . It appears that in practice this makes little difference.
      # ....................................................................................
      if (flagVerbose) {
        cat(" ..........  Begin univariate Cox score computations for m = ",
            m, " genes.\n", sep ="");
      }
      # .....................................................................................
      # . As preamble, define chunk sizes.
      # .....................................................................................
      #xxxx  mchunk = floor(6400 / n);            # For testing. 
      mchunk = floor(100000 / n);

      if (mchunk < 1) {
        cat("ERROR: from Cox.computeOnDataFrameSimpleBeta: mchunk < 1\n", sep = '');
        cat("Sample size n = ", n, " is too large.\n", sep = '');
        stop();
      }

      ch = Math.makeChunks(m, mchunk);
      # .....................................................................................
      # . Now proceed with the sequential computation :
      # .....................................................................................            
      t1 = proc.time()[3];

      for (k in 1:ch$kchunk) {
        cat("Processing chunk ", k, " out of ", ch$kchunk, ".\n", sep = "");

        mLo = ch$amLo[k];
        mHi = ch$amHi[k];
        
        avalBuf = sapply(mLo:mHi,  function(j)
                        {coxBuf = coxph(Surv(at, as) ~ dfX[ ,j],
                                        method = 'breslow');
                         # ..............................................................
                         # . Compute the log-likelihood-ratio.
                         # .............................................................. 
                         score = 2.0 * (coxBuf$loglik[2] - coxBuf$loglik[1]);
                         # ..............................................................
                         # . Package and return log-likelihood-ratio and beta.
                         # ..............................................................                         
                         abuf = c(score, coxBuf$coefficients[1]);
                         return(abuf)}
                         # ..............................................................
                        );
        
        if (k == 1) {
          aval = avalBuf;
        } else {
          aval = cbind(aval, avalBuf);
        }
      }
                       
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / m;                                     # Time per gene.
      tau = sprintf("%8.3e", tau);      

      if (flagVerbose) {
        cat(" ..........  Score computation done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per gene.\n");
      }
      # .....................................................................................
      # . Package the final results into separate arrays :
      # .....................................................................................      
      ascore = aval[1, ];     # Score-vector score.
      abeta = aval[2, ];      # Covariate coefficient beta.      
      ap = pchisq(ascore, df = 1, lower.tail = FALSE);       # Corresponding p-values.
      ac = colnames(dfX);                                    # Corresponding gene IDs.
      # ....................................................................................
      


      # ...........................................
      # . Package the results into a single list :
      # ...........................................
      coxS = list(n = n,
                  m = m,
                  ac = ac,
                  abeta = abeta,
                  ascore = ascore,
                  ap = ap);
      # ..........................................


      # .............
      return (coxS);
      # .............
  
}

# =================================================================================================
# . End of Cox.computeOnDataFrameSimpleBeta.
# =================================================================================================




# ============================================================================================================
# . Cox.computeOnDataFrameNoTiesParallel : computes Cox scores and P-values for a set of survival
# . ------------------------------------   data against expression values for a set of genes.
# .                                A univariate Cox score is computed for each gene independently.
# .                                This version assumes no ties are present in the survival times.
# .                                If ties are present, there will be some loss of accuracy.
# .
# .   Note : this is a parallelized version of Cox.computeOnDataFrameSimple(), which gives
# .          the same results in the absence of ties in the survival times.
# .                                
# .   Syntax:
# .
# .            coxS = Cox.computeOnDataFrameNoTiesParallel(at, as, dfX, flagVerbose);
# .
# .   In:
# .     If n = number of samples, and p = number of genes, then (with array dimensions indicated
# .     below) :
# .
# .                at : n; 1d array of survival lifetimes for the different samples considered.
# .                as : n; 1d array of corresponding censoring statuses; 1 = not censored,
# .                     0 = censored.
# .               dfX : n * m; data frame with expression values for m genes across n samples.
# .       flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        coxS = a list, with members:
# .
# .                       n = number of samples.
# .                       m = number of genes.
# .                      ac = m : gene IDs, corresponding to scores and P-values.
# .                  ascore = m : array of U^2(beta = 0) / J(beta = 0) scores.
# .                      ap = m : array of corresponding P-values (under chisq
# .                               test with df = 1).
# .
# =============================================================================================================

Cox.computeOnDataFrameNoTiesParallel <- function(at, as, dfX, flagVerbose)
{

      # ...............................................................................
      # . Determine number of samples, catch inconsistencies :
      # ...............................................................................
      n = nrow(dfX);     # Number of samples.
      m = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival times array.
      ns = length(as);   # Number of samples in censoring status array.

      if (nt != n) {
        msg = "ERROR: from Cox.computeOnDataFrameNoTiesParallel: ";
        msg = paste("The lifetime vector at has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                     n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from Cox.computeOnDataFrameNoTiesParallel: ";
        msg = paste("The censoring vector as has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                    n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      # ................................................................................

      

      # ...............................................................................................
      if (flagVerbose) {
        cat(" ..........  Begin univariate Cox score computations for m = ", m, " genes.\n", sep ="");
      }
      # ...............................................................................................      

      

      # ....................
      t1 = proc.time()[3];
      # ....................

      
      
      # ....................................................................................................
      # . Sort arrays :
      # ....................................................................................................
      sBuf = sort(at, decreasing = TRUE, index.return = TRUE);    # Sort in decreasing order.

      indexSort = sBuf[["ix"]];    # Sort index.

      au = sBuf[["x"]];            # Sorted array of event times.
      ad = as[indexSort];          # Sorted array of indicators (1 = death, 0 = censored).
      dfZ = dfX[indexSort, ];      # Sorted array of gene expression values.
      aY = 1:n;                    # Y(u) = number of individuals at risk at time u, assuming no ties.
      # ....................................................................................................
      # . Generate zbar values and compute score values for each gene :
      # ....................................................................................................
      if (flagVerbose) {
        cat(" ..........  Generate U(0) for univariate computation.\n");
      }
      
      dfBuf1 = cumsum(as.data.frame(dfZ));        # Upward cumulative sum, column-by-column.
      dfZbar = sweep(dfBuf1, 1, aY, FUN= "/");    # Average over individuals at risk.

      #xxx dfDelta = dfZ - dfZbar;                     # Deviation for each individual, z_I(u) - zbar (for ref. only).
      dfTemp = sweep(dfZ - dfZbar, 1, ad, FUN = "*");  # Only death events will be counted.

      aU0 = colSums(dfTemp);                      # This is the score for beta = 0.
      # ....................................................................................................
      # . Generate Vz values and compute Fisher information for each gene :
      # ....................................................................................................
      if (flagVerbose) {
        cat(" ..........  Generate J(0) for univariate computation.\n");
      }

      dfBuf2 = cumsum(as.data.frame(dfZ * dfZ));  # Upward cumulative sum of z^2 values, column-by-column.
      dfZ2bar = sweep(dfBuf2, 1, aY, FUN= "/");   # Average over individuals at risk.      
      #xxx    dfVz = dfZ2bar - dfZbar^2;                      # Values of <z^2>- <z>^2  (for ref. only).
      dfTemp = sweep(dfZ2bar - dfZbar^2, 1, ad, FUN = "*");   # Only death events will be counted.

      aJ0 = colSums(dfTemp);                      # This is the Fisher information for beta = 0.
      # ....................................................................................................
      # . Final computation of score test-statistic values :
      # ....................................................................................................
      #xxxx ascore = aU0^2 / aJ0;       # Old version, did not control for 0 denominator.
      ascore = ifelse(aJ0 > 0.0, aU0^2 / aJ0, ifelse(aU0 > 0.0, Cox.MAX_SCORE_FOR_CHI2_NU1, 0.0));
      
      ap = pchisq(ascore, df = 1, lower.tail = FALSE);       # Corresponding p-values.
      ac = colnames(dfX);                                    # Corresponding gene IDs.

      abeta = rep(0.0, times = m);                           # beta = 0 for all genes, by definition of U0^2/J0 score.
      # ....................................................................................................      


      
      # ....................................................................................................
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / m;                                     # Time per gene.
      tau = sprintf("%8.3e", tau);

      if (flagVerbose) {
        cat(" ..........  Score computation done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per gene.\n");
      }      
      # ....................................................................................................

      

      # ........................................
      # . Package the results :
      # ........................................
      coxS = list(n = n,
                  m = m,
                  ac = ac,
                  abeta = abeta,
                  ascore = ascore,
                  ap = ap);
      # ........................................


      # .............
      return (coxS);
      # .............
  
}

# =================================================================================================
# . End of Cox.computeOnDataFrameNoTiesParallel.
# =================================================================================================





# ============================================================================================================
# . Cox.computeOnDataFrameNoTiesCHUNKED : computes Cox scores and P-values for a set of survival
# . -----------------------------------   data against expression values for a set of genes.
# .                                A univariate Cox score is computed for each gene independently.
# .                                This version assumes no ties are present in the survival times.
# .                                If ties are present, there will be some loss of accuracy.
# .
# .   Note : this is a CHUNKED version of Cox.computeOnDataFrameNoTiesParallel(). It
# .          calls Cox.computeOnDataFrameNoTiesParallel() on successive chunks of samples.
# .          Note also that Cox.computeOnDataFrameNoTiesParallel() itself is a parallelized
# .          version of Cox.computeOnDataFrameSimple(),
# .                                
# .   Syntax:
# .
# .            coxS = Cox.computeOnDataFrameNoTiesCHUNKED(at, as, dfX, flagVerbose);
# .
# .   In:
# .     If n = number of samples, and p = number of genes, then (with array dimensions indicated
# .     below) :
# .
# .                at : n; 1d array of survival lifetimes for the different samples considered.
# .                as : n; 1d array of corresponding censoring statuses; 1 = not censored,
# .                     0 = censored.
# .               dfX : n * m; data frame with expression values for m genes across n samples.
# .       flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        coxS = a list, with members:
# .
# .                       n = number of samples.
# .                       m = number of genes.
# .                      ac = m : gene IDs, corresponding to scores and P-values.
# .                  ascore = m : array of U^2(beta = 0) / J(beta = 0) scores.
# .                      ap = m : array of corresponding P-values (under chisq
# .                               test with df = 1).
# .
# =============================================================================================================

Cox.computeOnDataFrameNoTiesCHUNKED <- function(at, as, dfX, flagVerbose)
{

      # ...............................................................................
      # . Determine number of samples, catch inconsistencies :
      # ...............................................................................
      n = nrow(dfX);     # Number of samples.
      m = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival times array.
      ns = length(as);   # Number of samples in censoring status array.

      if (nt != n) {
        msg = "ERROR: from Cox.computeOnDataFrameNoTiesCHUNKED: ";
        msg = paste("The lifetime vector at has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                     n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from Cox.computeOnDataFrameNoTiesCHUNKED: ";
        msg = paste("The censoring vector as has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                    n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      # ................................................................................

      

      # ...............................................................................................
      if (flagVerbose) {
        cat(" ..........  Begin univariate Cox score computations for m = ", m, " genes.\n", sep ="");
      }
      # ...............................................................................................      



      # .....................................................................................
      # . As preamble, define chunk sizes.
      # .....................................................................................
      #xxx mchunk = floor(6400 / n);            # For testing. #zzzz
      mchunk = floor(100000 / n);

      if (mchunk < 1) {
        cat("ERROR: from Cox.computeOnDataFrameSimpleBeta: mchunk < 1\n", sep = '');
        cat("Sample size n = ", n, " is too large.\n", sep = '');
        stop();
      }

      ch = Math.makeChunks(m, mchunk);
      # .....................................................................................
      # . Now proceed with the sequential computation :
      # .....................................................................................      
      t1 = proc.time()[3];

      for (k in 1:ch$kchunk) {
        cat("Processing chunk ", k, " out of ", ch$kchunk, ".\n", sep = "");      

        mLo = ch$amLo[k];
        mHi = ch$amHi[k];

        flagVerboseHere = FALSE;
        coxSBuf = Cox.computeOnDataFrameNoTiesParallel(at, as, dfX[ , mLo:mHi], flagVerboseHere);
        # .......................................................................................
        # . Gather the latest chunk :
        # .......................................................................................        
        if (k == 1) {
          ac = coxSBuf$ac;
          abeta = coxSBuf$abeta;
          ascore = coxSBuf$ascore;
          ap = coxSBuf$ap;                    
        } else {
          ac = c(ac, coxSBuf$ac);
          abeta = c(abeta, coxSBuf$abeta);
          ascore = c(ascore, coxSBuf$ascore);
          ap = c(ap, coxSBuf$ap);                    
        }
        # .......................................................................................        
      }

      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / m;                                     # Time per gene.
      tau = sprintf("%8.3e", tau);

      if (flagVerbose) {
        cat(" ..........  Score computation done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per gene.\n");
      }      
      # ....................................................................................................

      

      # ........................................
      # . Package the results :
      # ........................................
      coxS = list(n = n,
                  m = m,
                  ac = ac,
                  abeta = abeta,
                  ascore = ascore,
                  ap = ap);
      # ........................................


      # .............
      return (coxS);
      # .............
  
}

# =================================================================================================
# . End of Cox.computeOnDataFrameNoTiesCHUNKED.
# =================================================================================================






# ============================================================================================================
# . Cox.computeSingleNoTies : computes the univariate Cox score and P-value for a set of survival
# . -----------------------   data against a single vector of gene expression values.
# .                           This version assumes no ties are present in the survival times.
# .                           If ties are present, there will be some loss of accuracy.
# .
# .   Syntax:
# .
# .             cs = Cox.computeSingleNoTies(at, as, ax);
# .
# .   In:
# .     If n = number of samples; array dimension indicated below :
# .
# .                at : n; array of survival lifetimes for the different samples considered.
# .                as : n; array of censoring statuses; 1 = not censored, 0 = censored.
# .                ax : n; array of expression values.
# .
# .   Out:
# .          cs = a list, with members:
# .
# .                       n = number of samples.
# .                   score = value of U^2(beta = 0) / J(beta = 0).
# .                       p = corresponding P-values (under chisq test with df = 1).
# .
# =============================================================================================================

Cox.computeSingleNoTies <- function(at, as, ax)
{

      # ...............................................................................
      # . Determine number of samples, catch inconsistencies :
      # ...............................................................................
      n = length(ax);      # Number of samples.
      nt = length(at);   # Number of samples in survival times array.
      ns = length(as);   # Number of samples in censoring status array.

      if (nt != n) {
        msg = "ERROR: from Cox.computeSingleNoTies: ";
        msg = paste("The lifetime vector at has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                     n, "samples in ax.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from Cox.computeSingleNoTies: ";
        msg = paste("The censoring vector as has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                    n, "samples in ax.", sep = "");        
        stop(msg);
      }      
      # ................................................................................

      
      
      # ....................................................................................................
      # . Sort arrays according to the 
      # ....................................................................................................
      sBuf = sort(at, decreasing = TRUE, index.return = TRUE);    # Sort in decreasing order.

      indexSort = sBuf[["ix"]];    # Sort index.

      au = sBuf[["x"]];            # Sorted array of event times.
      ad = as[indexSort];          # Sorted array of indicators (1 = death, 0 = censored).
      az = ax[indexSort];          # Sorted array of gene expression values.
      aY = 1:n;                    # Y(u) = number of individuals at risk at time u, assuming no ties.
      # ....................................................................................................
      # . Generate zbar values and compute score U(0) :
      # ....................................................................................................
      buf1 = cumsum(az);           # Upward cumulative sum of z values.
      azbar = buf1 / aY;           # Average over individuals at risk.

      adelta = az - azbar;         # Deviation for each individual, z_I(u) - zbar.
      aU0 = adelta * ad;           # Only death events will be counted.

      U0 = sum(aU0);               # This is the score for beta = 0.
      # ....................................................................................................
      # . Generate Vz values and compute Fisher information J(0) :
      # ....................................................................................................
      buf2 = cumsum(az * az);      # Upward cumulative sum of z^2 values.
      az2bar = buf2 / aY;          # Average over individuals at risk.

      adelta2 = az2bar - azbar^2;  # Values of <z^2>- <z>^2.
      aJ0 = adelta2 * ad;          # Only death events will be counted.

      J0 = sum(aJ0);               # This is the Fisher information for beta = 0.
      # ....................................................................................................
      # . Final computation of score test-statistic and P-value :
      # ....................................................................................................
      score = U0^2 / J0;
      p = pchisq(score, df = 1, lower.tail = FALSE);       # Corresponding p-values.
      # ....................................................................................................      


      # ........................................................................
      # . Package the results :
      # ........................................................................
      cs = list(n = n,
                score = score,
                p = p,
                azbar = azbar,
                aU0 = aU0,
                aJ0 = aJ0,
                U0 = U0,
                J0 = J0);
      # ........................................................................


      # .............
      return (cs);
      # .............
  
}

# =================================================================================================
# . End of Cox.computeSingleNoTies.
# =================================================================================================


# ============================================================================================================
# . Cox.plotUnivariateComparison : compares output from two versions of the univariate Cox calculations, by
# . ----------------------------   generating scatter plots of U^2(0) / J(0) and the corresponding P-values.
# .                                (this is pretty much a one-time utility, for debugging my version of the
# .                                univariate score calculation).
# . Syntax :
# .
# .         Cox.plotUnivariateComparison(coxS, coxSnew);
# .
# . In :
# .
# .        coxS = object returned from Cox.computeOnDataFrameSimple()
# .     coxSnew = object returned from Cox.computeOnDataFrameNoTiesParallel()
# .
# =============================================================================================================

Cox.plotUnivariateComparison <- function(coxS, coxSnew)
{

      # ......................................................................
      # . Compare the two sets of values :
      # ......................................................................      
      par(mfrow = c(1, 2));

      errorMax = max(abs(coxS$ascore - coxSnew$ascore));
      caption = paste("U(0)^2/J(0), errorMax = ", sprintf("%8.3e", errorMax));
      
      plot(coxS$ascore, coxSnew$ascore,
           xlab = "coxph score",
           ylab = "parallel score",
           main = caption);

      ap1 = -log(coxS$ap, base = 10.0);
      ap2 = -log(coxSnew$ap, base = 10.0);      

      errorMax = max(abs(ap1 - ap2));
      caption = paste("P-values, errorMax = ", sprintf("%8.3e", errorMax));        
      
      plot(ap1, ap2,
           xlab = "-log10(P), coxph",
           ylab = "-log10(P), parallel",
           main = caption);
        
      par(mfrow = c(1, 1));
      # ......................................................................
      buf = readline(">>Enter a carriage return to continue: ");    # Pause.
      # ......................................................................

      
      # ............
      return (0);
      # ............      

}

# ============================================================================================================
# . End of Cox.plotUnivariateComparison.
# ============================================================================================================




# =================================================================================================
# . Cox.computeOnDataFrameSimpleBetaWithCov : computes Cox scores and P-values for a set of survival
# . ---------------------------------------   data against expression values for a set of genes.
# .                                           A univariate Cox score is computed for each gene
# .                                           independently, but this version also includes effect
# .                                           of an external covariate as well.
# .
# .   Note 1 : this version is computing the score 2 * (l(beta*) - l(0)) (beta != 0, log-likelihood
# .            test statistic).
# .
# .   Note 2 : this is a sequential application of the native R method coxph, and is thus
# .            relatively slow.
# .                                
# .   Syntax:
# .
# .     coxSCov = Cox.computeOnDataFrameSimpleBetaWithCov(at, as, az, dfX, flagVerbose);
# .
# .   In:
# .     If n = number of samples, and p = number of genes, then (with array dimensions indicated
# .     below) :
# .
# .                at : n; 1d array of survival lifetimes for the different samples considered.
# .                as : n; 1d array of corresponding censoring statuses; 1 = not censored,
# .                     0 = censored.
# .                az : n; 1d array of external covraite values.
# .               dfX : n * m; data frame with expression values for m genes across n samples.
# .       flagVerbose : if TRUE, print progress on calculation. Otherwise, be silent.
# .
# .   Out:
# .        coxSCov = a list, with members:
# .
# .                       n = number of samples.
# .                       m = number of genes.
# .                      ac = m : gene IDs, corresponding to scores and P-values.
# .                   abeta = m : covariate coefficients beta, all 0 here.
# .                  ascore = m : array of U^2(beta = 0) / J(beta = 0) scores.
# .                      ap = m : array of corresponding P-values (under chisq
# .                               test with df = 1).
# .
# =================================================================================================

Cox.computeOnDataFrameSimpleBetaWithCov <- function(at, as, az, dfX, flagVerbose)
{

      # ........................................................................
      # . Determine nmber of samples, catch inconsistencies :
      # ........................................................................
      n = nrow(dfX);     # Number of samples.
      m = ncol(dfX);     # Number of genes.
      
      nt = length(at);   # Number of samples in survival times array.
      ns = length(as);   # Number of samples in censoring status array.
      nz = length(az);   # Number of samples for external covariate.

      if (nt != n) {
        msg = "ERROR: from Cox.computeOnDataFrameSimpleBetaWithCov: ";
        msg = paste("The lifetime vector at has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                     n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (ns != n) {
        msg = "ERROR: from Cox.computeOnDataFrameSimpleBetaWithCov: ";
        msg = paste("The censoring vector as has nt = ", nt, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                    n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from Cox.computeOnDataFrameSimpleBetaWithCov: ";
        msg = paste("The external covariate vector as has nz = ", nz, "samples\n", sep = "");
        msg = paste("Not the same as the n = ",
                    n, "samples in the data matrix dfX.", sep = "");        
        stop(msg);
      }      
      # .........................................................................



      # ....................................................................................
      # . Compute scores and P-values for each gene independently, with presence of external
      # . covariate and allowing for interaction effects.
      # ....................................................................................
      if (flagVerbose) {
        cat(" ..........  Begin univariate Cox score computations for m = ",
            m, " genes.\n", sep ="");
      }
      # .....................................................................................
      # . As preamble, define chunk sizes.
      # .....................................................................................
      #xxx  mchunk = floor(6400 / n);      # For testing.
      mchunk = floor(100000 / n);

      if (mchunk < 1) {
        cat("ERROR: from Cox.computeOnDataFrameSimpleBetaWithCov: mchunk < 1\n", sep = '');
        cat("Sample size n = ", n, " is too large.\n", sep = '');
        stop();
      }

      ch = Math.makeChunks(m, mchunk);
      # .....................................................................................
      # . Now proceed with the sequential computation :
      # .....................................................................................      
      t1 = proc.time()[3];

      for (k in 1:ch$kchunk) {
        cat("Processing chunk ", k, " out of ", ch$kchunk, ".\n", sep = "");

        mLo = ch$amLo[k];
        mHi = ch$amHi[k];
        
        avalBuf = sapply(mLo:mHi,  function(j)
                        {coxBuf = coxph(Surv(at, as) ~ dfX[ ,j] + az + az * dfX[ ,j],
                                        method = 'breslow');
                         csBuf = summary(coxBuf);            # Summary of coxph results.
                         # ..............................................................
                         # . Get the overall model statistics :
                         # ..............................................................                    
                         scoreBuf = csBuf$logtest;  
                         score = scoreBuf[1];                # Log-likelihood-ratio score.
                         pval = scoreBuf[3];                 # Model p-value. df = 3.
                         # ..............................................................
                         # . Get the Cox coeffcients and P-values :
                         # ..............................................................                    
                         coefBuf = csBuf$coefficients;
                         aBeta = coefBuf[, 1];    # Will contain beta1(ax), beta2(az), beta3(ax:az).
                         aseBeta = coefBuf[, 3];  # Will contain seBeta1(ax), seBeta2(az), seBeta3(ax:az).                         
                         aPval = coefBuf[, 5];    # Will contain pval1(ax), pval2(az), pval3(ax:az).                    
                         # ..............................................................
                         # . Package and return :
                         # ..............................................................
                         abuf = c(score, pval, aBeta, aPval, aseBeta);
                         return(abuf)}
                         # ..............................................................                    
                        );

        if (k == 1) {
          aval = avalBuf;
        } else {
          aval = cbind(aval, avalBuf);
        }
      }
                       
      t2 = proc.time()[3] - t1;                         # Total time for computation (s).
      tau = t2 / m;                                     # Time per gene.
      tau = sprintf("%8.3e", tau);      

      if (flagVerbose) {
        cat(" ..........  Score computation done. Total time = ", t2, " s.", sep = "");
        cat(" Tau = ", tau, " s per gene.\n");
      }
      # .....................................................................................
      # . Package the final results into separate arrays :
      # .....................................................................................           
      ascore = aval[1, ];     # Log-likelihood-ratio scores.
      ap = aval[2, ];         # Model P-values.

      abetaX = aval[3, ];    # Coefficients for x effects.
      abetaZ = aval[4, ];    # Coefficients for z effects.
      abetaZX = aval[5, ];   # Coefficients for z * x interaction.

      apX = aval[6, ];       # P-values for x coefficients.
      apZ = aval[7, ];       # P-values for z coefficients.
      apZX = aval[8, ];      # P-values for z * x interaction coefficients.

      aseBetaX = aval[9, ];     # se for coefficients for x effects.
      aseBetaZ = aval[10, ];    # se for coefficients for z effects.
      aseBetaZX = aval[11, ];   # se for coefficients for z * x interaction.
      
      ac = colnames(dfX);    # Corresponding gene IDs.
      # ....................................................................................
      


      # ........................................
      # . Package the results into a single list :
      # ........................................
      coxS = list(n = n,
                  m = m,
                  ac = ac,
                  abetaX = abetaX,
                  abetaZ = abetaZ,
                  abetaZX = abetaZX,
                  apX = apX,
                  apZ = apZ,
                  apZX = apZX,                        
                  ascore = ascore,
                  aseBetaX = aseBetaX,
                  aseBetaZ = aseBetaZ,
                  aseBetaZX = aseBetaZX,        
                  ap = ap);

      class(coxS) = "cox.uni.cov";
      # ........................................


      # .............
      return (coxS);
      # .............
  
}

# =================================================================================================
# . End of Cox.computeOnDataFrameSimpleBetaWithCov.
# =================================================================================================




# =================================================================================================
# . Cox.computeCoxOnSplitLoghR : computes statistical significance of association of survival times
# . --------------------------   with a given set of log-hazard-ratios, using a simple splitting
# .                              scheme.
# .
# . Syntax:
# .
# .       cs = Cox.computeCoxOnSplitLoghR(at, as, aloghR);
# .
# . In:
# .          at = n: survival times (where n = array length);
# .          as = n: censoring statuses.
# .      aloghR = n: predicted log-hazard-ratios.
# .
# . Out:
# .        n = number of samples.
# .        pR = P-value,
# .        hR = hazard-ratio for split populations.
# .        hRLo = lower confidence limit for split hazard-ratio.
# .        hRHi = upper confidence limit for split hazard-ratio.
# .
# .................................................................................................
# . * Details of the calculation :
# .
# .   - We first perform a binary split of the samples on the basis of their aloghR values, 
# .   using the median as a threshold for the cut. This divides the population into two equal 
# .   or almost equal groups, a 'high-risk' group (say with zeta = 1) and a 'low-risk' group
# .   (say with zeta = -1). 
# .
# .   - We then compute a Cox proportional hazard model for (at, as) ~ azeta, and report the
# .   results.
# .
# .................................................................................................
# . * Additional comments :
# .
# .   A less ad hoc test would probably rely on first writing the log-partial-likelihood for the
# .   given sample data, but using the input log-hazard-ratios instead of beta * z :
# .
# .                                                      n
# .      l  (as, at) =  sum    dN(u) . (xi      -  log(  sum  Y (u) exp(xi ) ) )
# .       T            u in G             i(u)          l = 1  l          l
# .
# .   where u = time in increasing order, G = grid of time points, xi = log-hazard-ratio,
# .   dN(u) = 1 if death event, 0 otherwise (i.e. dN(u) = censoring status), i(u) = individual
# .   affected at time u, Y_l(u) = indicator for presence or absence of individual l
# .   at time u, and finally n = total number of individuals.
# .
# .   We would then recompute l_T under random permutations of the assignments of xi to the (at, as)
# .   values, thereby generating a baseline distribution l*_T. The P-value would then be computed
# .   as :
# .                                *
# .          P = fraction of time l   >  l  .
# .                                T      T
# .
# =================================================================================================

Cox.computeCoxOnSplitLoghR <- function(at, as, aloghR)
{


      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nl = length(aloghR);  # Number of samples in log-hazard-ratio vector.

      if (ns != n) {
        msg = "ERROR: from Cox.computeCoxOnSplitLoghR: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl != n) {
        msg = "ERROR: from Cox.computeCoxOnSplitLoghR: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR has nl = ", nl, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      # ...............................................................................................



      
      # ...........................................................................................
      # . Discretize the sample set into high-risk and low-risk groups on the
      # . basis of log-hazard-ratio, with a cut at the median log-hazard-ratio.
      # ...........................................................................................
      aloghRMed = median(aloghR);                               # Select median as cut value.
      aRiskGroup = ifelse(aloghR < aloghRMed, -1, 1);           # Discretize into low and high risk.
      # ...........................................................................................
      # . Directly use a Cox proportional hazard model :
      # ...........................................................................................
      coxK = coxph(Surv(at, as) ~ aRiskGroup);         # Cox model on 1 variable.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);    # Likelihood ratio statistic.
      pR = pchisq(qR, df = 1, lower.tail = FALSE);     # p-value from likelihood ratio.
      
      coxKsum = summary(coxK);
      coxKcoef = coxKsum$coef;                         # Contains the coefficient and P-value.
      
      beta = coxKcoef[ , 1];                           # The Cox coefficient.
      seBeta = coxKcoef[ , 3];                         # Standard error for the coefficient.
      pBeta = coxKcoef[ , 5];                          # The corresponding P-value.
      # .......................................................................................
      # . Compute the hazard ratio between high-risk (+1) and low risk (-1) groups,
      # . and its confidence limits for +/- one std. dev. in the log-hazard-ratio.
      # .......................................................................................
      loghR = 2.0 * beta;
      loghRLo = 2.0 * (beta - seBeta);
      loghRHi = 2.0 * (beta + seBeta);

      hR = exp(loghR);
      hRLo = exp(loghRLo);
      hRHi = exp(loghRHi);      
      # .......................................................................................            

      
      
      # .........................................
      # . Package the results into a list :
      # .........................................
      cs = list(n = n,
                pR = pR,
                hR = hR,
                hRLo = hRLo,
                hRHi = hRHi);

      class(cs) = "cox.significance";
      # .........................................
      
     
      # ...........
      return (cs);
      # ...........

}

# =================================================================================================
# . End of Cox.computeCoxOnSplitLoghR.
# =================================================================================================




# =================================================================================================
# . Cox.computeBinaryCoxOnThreshold : computes a Cox model for a two-arm study, for all
# . -------------------------------   instances with index less than or equal (or greater than or equal
# .                                   to) the indicated value.
# .
# . Syntax :
# .
# .   buf = Cox.computeBinaryCoxOnThreshold(atSort, asSort, azSort, ic, keep.below = TRUE);
# .
# . In:
# .
# .  atSort = n: array of survival times, sorted on increasing relative log-hazard.
# .  asSort = n: array of censoring statuse, sorted on increasing relative log-hazard.
# .  azSort = n: array of treatment arm indicators, z in {0, 1}, sorted on
# .              increasing relative log-hazard.
# .
# .      ic = threshold for keeping samples.
# .
# .   keep.below = if TRUE, use all samples in range 1 <= i <= ic, if FALSE use all
# .                samples in range ic <= i <= n.
# .
# . Out:
# .       buf = list with members:
# .
# .        nc = array of total number of samples used in test.
# .        pR = array of P-value from comparing z = 0 to z = 1 samples with i <= ic,
# .             where ic = array index.
# .        hR = array of hazard ratios; hR = lambda(z = 1) / lambda(z = 0).
# .      hRLo = array of lower confidence limits for hazard ratios [exp(loghR - se)].
# .      hRHi = array of upper confidence limits for hazard ratios [exp(loghR + se)].
# .
# .................................................................................................
# . Note that az is assumed to contain just 0 or 1 values. Use Cox.checkBinary() beforehand
# . to check.
# =================================================================================================

Cox.computeBinaryCoxOnThreshold <- function(atSort, asSort, azSort, ic, keep.below = TRUE)
{

     # ......................................................................................        
     # . Catch inconsistencies in specification of input arrays or parameters.
     # ......................................................................................  
     n = length(atSort);       # Number of samples in survival time vector.
     ns = length(asSort);      # Number of samples in censoring status vector.
     nz = length(azSort);      # Number of samples in treatment indicator.

     if (ns != n) {
       cat("ERROR: from Cox.computeBinaryCoxOnThreshold:\n");
       cat("The censoring status vector as has ns = ", ns, "samples.\n", sep = "");
       cat("This is not the same as the n = ", n, "samples in the time vector at.\n", sep = "");      
       stop();
     }

     if (nz != n) {
       cat("ERROR: from Cox.computeBinaryCoxOnThreshold:\n");
       cat("The treatment indicator  vector as has nz = ", nz, "samples.\n", sep = "");
       cat("This is not the same as the n = ", n, "samples in the time vector at.\n", sep = "");      
       stop();
     }

     if ((ic < 1) || (ic > n)) {
       cat("ERROR: from Cox.computeBinaryCoxOnThreshold:\n");
       cat("Separation index ic is out of range. ic = ", ic, "\n", sep = "");
       cat("Allowed range is 1 <= ic <= ", n, "\n", sep = "");      
       stop();
     }
     # ........................................................................................

     

     # ...........................................................................................
     # . Select relevant subsets of survival times :
     # ...........................................................................................
     if (keep.below) {
       atBuf = atSort[1:ic];
       asBuf = asSort[1:ic];
       azBuf = azSort[1:ic];          
     } else {
       atBuf = atSort[ic:n];
       asBuf = asSort[ic:n];
       azBuf = azSort[ic:n];          
     }

     nc = length(atBuf);            # Number of samples selected by cutoff.     
     # ...........................................................................................


     # ...........................................................................................
     # . Filter out special cases :
     # ...........................................................................................
     if (nc == 1) {
       pR = 1.0;
       hR = 1.0;
       hRLo = 1.0;
       hRHi = 1.0;       

       cs = list(nc = nc,
                 pR = pR,
                 hR = hR,
                 hRLo = hRLo,
                 hRHi = hRHi);

       class(cs) = "cox.significance";
       return (cs);
     }
     # ...........................................................................................     

     
  
     # ...........................................................................................
     # . Compute Cox model to compare the two treatment arms :
     # ...........................................................................................
     coxK = coxph(Surv(atBuf, asBuf) ~ azBuf);         # Cox model on binary {0,1} variable.

     if (!is.na(coxK$coef)) {
       qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);     # Likelihood ratio statistic.
       pR = pchisq(qR, df = 1, lower.tail = FALSE);      # p-value from likelihood ratio.
      
       coxKsum = summary(coxK);
       coxKcoef = coxKsum$coef;                         # Contains the coefficient and P-value.
      
       beta = coxKcoef[ , 1];                           # The Cox coefficient.
       seBeta = coxKcoef[ , 3];                         # Standard error for the coefficient.
       pBeta = coxKcoef[ , 5];                          # The corresponding P-value.

       if (is.nan(seBeta)) {
         seBeta = Cox.MAX_SEBETA;
       }

       if (seBeta > Cox.MAX_SEBETA) {
         seBeta = Cox.MAX_SEBETA;                       # Controls for cases where beta -> -infinity.
       }
     }

     if (is.na(coxK$coef)) {
       beta = 0.0;
       seBeta = Cox.MAX_SEBETA;                         # Complete uncertainty.       
       pR = 1.0;                                        # Not significant.
     }
     # .......................................................................................
     # . Compute the hazard ratio between treated (+1) and untreated (0) groups,
     # . and its confidence limits for 95% interval.
     # .......................................................................................
     loghR = beta;
     loghRLo = beta - 1.959964 * seBeta;               # Upper are the 95% confidence interval.
     loghRHi = beta + 1.959964 * seBeta;               # Lower are the 95% confidence interval.

     hR = exp(loghR);                                  # Hazard ratio of treated to untreated group.
     hRLo = exp(loghRLo);
     hRHi = exp(loghRHi);      
     # .......................................................................................            

      
      
      # .........................................
      # . Package the results into a list :
      # .........................................
      cs = list(nc = nc,
                pR = pR,
                hR = hR,
                hRLo = hRLo,
                hRHi = hRHi);

      class(cs) = "cox.significance";
      # .........................................
      
     
      # ...........
      return (cs);
      # ...........
  
  
  
}

# =================================================================================================
# . End of Cox.computeBinaryCoxOnThreshold.
# =================================================================================================





# =========================================================================================================
# . Cox.computeBinaryCox : computes Cox model for amodel with a binary ({0, 1}) covariate.
# . --------------------   log-hazard-ratio vector, computes a
# .                        statistical significance for the underlying model.
# .
# .   Syntax:
# .
# .       cs = Cox.computeBinaryCox(at, as, abin);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .          abin = n : vector of {0, 1} covariate values.
# .
# .   Out:
# .          cs = list with members :
# .
# .                 n = number of samples.
# .                pR = P-value that obtains from Cox analysis on the two groups (high risk
# .                     and low risk) that result from splitting on the median of the predicted
# .                     log-hazard-ratios.
# .
# .                hR = the hazard ratio between high-risk and low-risk groups.
# .              hRLo = lower 0.95 confidence limit for hR (- 1.96 std dev in log-hazard-ratio).
# .              hRHi = upper 0.95 confidence limit for hR (+ 1.96 std dev in log-hazard-ratio).
# .
# ==========================================================================================================

Cox.computeBinaryCox <- function(at, as, abin)
{

      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nbin = length(abin);  # Number of samples in binary covariate vector.

      if (ns != n) {
        msg = "ERROR: from Cox.computeBinaryCox: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nbin != n) {
        msg = "ERROR: from Cox.computeBinaryCox: ";
        msg = paste(msg, "The binary covaraite vector abin has nbin = ", nbin, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      msg = Cox.checkBinary(abin);

      if (msg != 'ok') {
        msg = "ERROR: from Cox.computeBinaryCox: ";
        cat("Input array abin has non-valid values.\n");
        cat(msg, "\n", sep = "");
        stop();
      }                
      # ...............................................................................................

      


      # ...........................................................................................
      # . Cox proportional hazard model :
      # ...........................................................................................
      coxK = coxph(Surv(at, as) ~ abin);               # Cox model on 1 variable.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);    # Likelihood ratio statistic.
      pR = pchisq(qR, df = 1, lower.tail = FALSE);     # p-value from likelihood ratio.
      
      coxKsum = summary(coxK);
      coxKcoef = coxKsum$coef;                         # Contains the coefficient and P-value.
      
      beta = coxKcoef[ , 1];                           # The Cox coefficient.
      seBeta = coxKcoef[ , 3];                         # Standard error for the coefficient.
      pBeta = coxKcoef[ , 5];                          # The corresponding P-value.
      # .......................................................................................
      # . Compute the hazard ratio between 1 and 0 groups,
      # . and its 0.95 confidence limits in the log-hazard-ratio.
      # .......................................................................................
      loghR = beta;
      loghRLo = beta - 1.959964 * seBeta;
      loghRHi = beta + 1.959964 * seBeta;

      hR = exp(loghR);
      hRLo = exp(loghRLo);
      hRHi = exp(loghRHi);      
      # .......................................................................................            

      
      
      # .........................................
      # . Package the results into a list :
      # .........................................
      cs = list(n = n,
                pR = pR,
                hR = hR,
                hRLo = hRLo,
                hRHi = hRHi);

      class(cs) = "spc.cox.significance";
      # .........................................
      
     
      # ...........
      return (cs);
      # ...........

}

# ==========================================================================================================
# . End of Cox.computeBinaryCox.
# ==========================================================================================================








# ==========================================================================================================
# . Cox.checkBinary : utility function, checks that the input vector contains just 0 and 1 values.
# . ---------------   This version tolerates the presence of NAs.
# .
# . Syntax:
# .
# .     msg = Cox.checkBinary(az);
# .
# . In:
# .      az = array of numerical values.
# .
# . Out:
# .      msg = 'ok', if all values of az are in binary set {0, 1}, else a message
# .             listing up to the first 5 non-binary values.
# .
# ==========================================================================================================

Cox.checkBinary <- function(az) {

  # ...................................
  msg = 'ok';   # Provisionally ok.
  # ...................................  

  
  # ...............................................................
  ad = sort(unique(az));     # Distinct values.
  buf = ad %in% c(0,1);      # Mark those not in {0, 1}.

  if (length(buf[buf == FALSE]) > 0) {
    adNon = ad[buf == FALSE];
    ndDisplay = min(length(adNon), 5);

    msg = paste("Some values in the array are not binary (not in {0, 1}).\n");
    msg = paste(msg, "Non-binary values [up to first 5]: ",
                paste(adNon[1:ndDisplay], collapse = ", "), "\n", sep ="");
  }
  # ................................................................  


  # ...............
  return (msg);
  # ...............
  
}

# ==========================================================================================================
# . End of Cox.checkBinary.
# ==========================================================================================================




# ==========================================================================================================
# . Cox.checkBinaryNoNA : utility function, checks that the input vector contains just 0 and 1 values.
# . -------------------   This version does NOT tolerate the presence of NAs.
# .
# . Syntax:
# .
# .     msg = Cox.checkBinaryNoNA(az);
# .
# . In:
# .      az = array of numerical values.
# .
# . Out:
# .      msg = 'ok', if all values of az are in binary set {0, 1}, else a message
# .             listing up to the first 5 non-binary values.
# .
# ==========================================================================================================

Cox.checkBinaryNoNA <- function(az) {

  # ...................................
  msg = 'ok';   # Provisionally ok.
  # ...................................  


  # ................................................................
  # . Check on presence of NAs :
  # ................................................................
  temp1 = sum(is.na(az));

  if (temp1 > 0) {
    msg = paste("Some values in the array are NAs.\n");
    return (msg);
  }    
  # ................................................................

  
  
  # ................................................................
  ad = sort(unique(az));     # Distinct values.
  buf = ad %in% c(0,1);      # Mark those not in {0, 1}.

  if (length(buf[buf == FALSE]) > 0) {
    adNon = ad[buf == FALSE];
    ndDisplay = min(length(adNon), 5);

    msg = paste("Some values in the array are not binary (not in {0, 1}).\n");
    msg = paste(msg, "Non-binary values [up to first 5]: ",
                paste(adNon[1:ndDisplay], collapse = ", "), "\n", sep ="");
  }
  # .................................................................  


  # ...............
  return (msg);
  # ...............
  
}

# ==========================================================================================================
# . End of Cox.checkBinaryNoNA.
# ==========================================================================================================






# =================================================================================================
# . Cox.plotLoghRBinary :  utility function; plots the predicted log-hazard-ratios for a
# . -------------------    2-treatment-arms Cox regression model.
# .
# .  Syntax:
# .
# .     Cox.plotLoghRBinary(betaZ, betaX, betaZX, xmin, xmax, xlab, caption);
# .
# . In:
# .
# .     betaZ,
# .     betaX,
# .     betaZX = regression coefficients in Cox model, with log-hazard-ratio xi given by:
# .           
# .
# .                        lambda(t|z,x)
# .              xi = log(--------------) = betaZ . Z + betaX . X + betaZX . Z . X
# .                         lambda0(t)
# .
# .             where Z = 0, 1 and X = gene-expression value.
# .
# .  xmin, xmax = minimum and maximum values of X to be plotted.
# .        xlab = x axis label.
# .     caption = plot caption.
# .
# =================================================================================================

Cox.plotLoghRBinary <- function(betaZ, betaX, betaZX, xmin, xmax, xlab, caption)
{
  
  # ..............................................................................................
  ad = seq(from = xmin, to = xmax, length.out = 50);
  axi0 = betaX * ad;
  axi1 = betaZ + (betaX + betaZX) * ad;

  xiMin = min(axi0, axi1);
  xiMax = max(axi0, axi1);

  cex.main.OLD = par("cex.main");
  par(cex.main = 0.8);      
  
  plot(ad, axi0, type = 'l', col = 'blue',
       main = caption,
       xlab = xlab,
       ylab = "log-hazard-ratio",
       ylim = c(xiMin, xiMax));
  
  lines(ad, axi1, type = 'l', col = 'red');
  abline(h = 0);
  abline(v = 0);

  xmin = -1.0;
  xmax = 1.0;

  xtemp = xmin + 0.02 * (xmax - xmin);
  ytemp = xiMax - 0.02 * (xiMax - xiMin);

  legendText = c("z = 0", "z = 1");
  colVector = c('blue', 'red');
  ltyVector = c('solid', 'solid');

  legend(x = xtemp, y = ytemp, legend = legendText, col = colVector, lty = ltyVector, bty = 'n');

  par(cex.main = cex.main.OLD);  
  # ..............................................................................................


  # ......................
  return (0);
  # ......................

}

# =================================================================================================
# . End of Cox.plotLoghRBinary.
# =================================================================================================



# =================================================================================================
# . Cox.computeNSchoenfeld : calculates the number of samples required in each of two groups in 
# . ----------------------   comparison of the two groups using the proportional hazard model,
# .                          using Schoenfeld's analytical approximation.
# .
# .  Syntax:
# .
# .     n = Cox.computeNSchoenfeld(alpha, beta, P1, hR);
# .
# . In:
# .     alpha = confidence level (false-positive rate, two-sided test).
# .      beta = power required for detecting true positives.
# .        P1 = proportion in first group.
# .        hR = assumed hazard-ratio.
# .
# . Out:
# .         n = number of samples required in each group of the study.
# .
# =================================================================================================

Cox.computeNSchoenfeld <- function(alpha, beta, P1, hR)
{

  # ......................................................
  stopifnot(alpha > 0.0, alpha < 1, beta > 0, beta < 1);
  stopifnot(P1 > 0, P1 < 1.0);  
  stopifnot(hR > 0.0);
  # ......................................................  

  
  # ......................................................  
  Z1alpha = qnorm(1 - 0.5 * alpha);
  Zbeta = qnorm(beta);

  n = (Z1alpha + Zbeta)^2 / (P1 * (1 - P1) * (log(hR))^2);
  # ......................................................


  # ...........
  return (n);
  # ...........
  
}

# =================================================================================================
# . End of Cox.computeNSchoenfeld.
# =================================================================================================






# =========================================================================================
# . Cox.computeCoxOnBinarySplits : rather special test function. For a given study,
# . ----------------------------   investigates the effect on hazard ratio of splitting into
# .                                two equal parts, with balanced representation of each level.
# .
# . Generates multiple sampled values, computes Cox coefficient and P-value in each case.
# . Returns arrays with P-values, log-hazard-ratios and hazard-ratios.
# .
# . Syntax :
# .
# .     sp = Cox.computeCoxOnBinarySplits(dfV, tTime, tCens, tZ, tComp, nsamp, rngSeed);
# .
# . In: 
# .          dfV = input data frame.
# .        tTime = name of column with survival time information.
# .        tCens = name of column with censoring information (standard 1 = event).
# .           tZ = name of column with covariate against which to the Cox analyses :
# .                Surv(tTime, tCens) ~ tZ
# .
# .        tComp = name of column specifying a factor that defines the levels
# .                from each of which equal or as equal as possible splits will be
# .                done. This can be a simple factor (e.g. TREATMENT_ARM) or a composite
# .                factor (e.g. TREATMENT_ARM * PRIOR_LINES_OF_TREATMENT), generated
# .                beforehand.
# .        nsamp = number of resamplings to be done.
# .      rngSeed = random number seed.
# .
# . Out:
# .     sp = list, with members :
# .
# .         dfO = output data frame containing the Cox model results, with columns :
# .               {ap1, abeta1, ahR1, ap2, abeta2, ahR2}
# .
# .         indexOpt = index for set 1 for optimal split.
# .         dfV1Opt = data frame for set 1, from split which minimizes |beta2 - beta1|.
# .         dfV2Opt = data frame for set 2, from split which minimizes |beta2 - beta1|.
# .
# .         p1Opt, beta1Opt, p2Opt, beta2Opt = P-values and Cox coefficients for optimal split.
# . 
# ..........................................................................................
# . Example:
# .
# .     Cox.computeCoxOnBinarySplits(dfV = dfV,
# .                                  tTime = "PFSTIMEM",
# .                                  tCens = "PFSCENS",
# .                                  tZ = "ARMCD_binary",
# .                                  tComp = "ARMCD_binary",
# .                                  nsamp = 100,
# .                                  rngSeed = 123456);
# .
# =========================================================================================

Cox.computeCoxOnBinarySplits <- function(dfV, tTime, tCens, tZ, tComp, nsamp, rngSeed)
{

      # .........................................
      # . Initialize random number generator :
      # .........................................      
      set.seed(rngSeed);                  
      # .........................................

      

      # ...............................
      # . Preamble :
      # ...............................
      n = nrow(dfV);
      afac = dfV[[tComp]];      # Levels that define the groups to be split.
      # ...............................



      # .................................................................................
      # . Main sampling loop here :
      # .................................................................................
      ap1 = c();
      abeta1 = c();
      ahR1 = c();
      
      ap2 = c();
      abeta2 = c();
      ahR2 = c();

      deltaBOld = 1.0e9;                                           # Dummy starting value.

      for (i in 1:nsamp) {  
        # ...........................................................
        # . Generate split:
        # ...........................................................
        indexBufList = by(1:n, afac, Cox.sampleBinarySplit);       # Generate splits, group-by-group.
        indexBuf = unlist(indexBufList);                           # Assemble the indices from all the factors.
        # ...........................................................
        # . Extract the splits :
        # ...........................................................
	dfV1BUF = dfV[indexBuf, ];     # Set 1.
	dfV2BUF = dfV[-indexBuf, ];    # Set 2, which is just the complement of set 1.
        # ...........................................................
	# . Do the Cox analyses :
	# . >> Set 1:
        # ...........................................................
        at = dfV1BUF[[tTime]];
        as = dfV1BUF[[tCens]];
        az = dfV1BUF[[tZ]];

        cox1BUF = coxph(Surv(at, as) ~ az);
        sum1 = summary(cox1BUF);

	ap1 = c(ap1, sum1$sctest[3]);                # P-value, score test.
        abeta1 = c(abeta1, sum1$coefficients[1]);    # Log-hazard-ratio.
	ahR1 = c(ahR1, sum1$coefficients[2]);        # Hazard-ratio.
        # ...........................................................
	# . Do the Cox analyses :
	# . >> Set 2:
        # ...........................................................
        at = dfV2BUF[[tTime]];
        as = dfV2BUF[[tCens]];
        az = dfV2BUF[[tZ]];
        
        cox2BUF = coxph(Surv(at, as) ~ az);        
        sum2 = summary(cox2BUF);

	ap2 = c(ap2, sum2$sctest[3]);                # P-value, score test.
        abeta2 = c(abeta2, sum2$coefficients[1]);    # Log-hazard-ratio.        
	ahR2 = c(ahR2, sum2$coefficients[2]);        # Hazard-ratio.
        # ...........................................................
        # . Save index values for most balanced so far :
        # ...........................................................
        deltaB = abs(sum2$coefficients[1] - sum1$coefficients[1]);

        if (deltaB < deltaBOld) {
          indexOpt = indexBuf;
          deltaBOld = deltaB;
        }
        # ...........................................................
        # . Indicate progress :
        # ...........................................................
        if ((i == 0) || (i%%20 == 0)) {
          cat(".");
        }
        # ...........................................................        
      }

      cat("\n");
      # .................................................................................



      # ..................................................
      # . Optimal split set assignments :
      # ..................................................
      asplitOpt = 1:n;
      
      asplitOpt[indexOpt] = 1;
      asplitOpt[-indexOpt] = 2;
      # ..................................................



      # ..................................................................................
      # . (Re)do the Cox analyses for the optimal split :
      # ..................................................................................
      dfV1Opt = dfV[indexOpt, ];     # Set 1.
      dfV2Opt = dfV[-indexOpt, ];    # Set 2, which is just the complement of set 1.
      # ...........................................................
      # . Do the Cox analyses :
      # . >> Set 1:
      # ...........................................................
      at = dfV1Opt[[tTime]];
      as = dfV1Opt[[tCens]];
      az = dfV1Opt[[tZ]];

      cox1Opt = coxph(Surv(at, as) ~ az);
      sum1 = summary(cox1Opt);

      p1Opt =  sum1$sctest[3];            # P-value, score test.
      beta1Opt = sum1$coefficients[1];    # Log-hazard-ratio.
      hR1Opt = sum1$coefficients[2];      # Hazard-ratio.
      # ...........................................................
      # . Do the Cox analyses :
      # . >> Set 2:
      # ...........................................................
      at = dfV2Opt[[tTime]];
      as = dfV2Opt[[tCens]];
      az = dfV2Opt[[tZ]];
        
      cox2Opt = coxph(Surv(at, as) ~ az);        
      sum2 = summary(cox2Opt);

      p2Opt = sum2$sctest[3];               # P-value, score test.
      beta2Opt = sum2$coefficients[1];      # Log-hazard-ratio.        
      hR2Opt = sum2$coefficients[2];        # Hazard-ratio.
      # ...........................................................
      




      

      # ................................................................
      # Package the P-values and coefficients into a data frame :
      # ................................................................
      dfO = data.frame(ap1 = ap1,
                       abeta1 = abeta1,
                       ahR1 = ahR1,
                       ap2 = ap2,
                       abeta2 = abeta2,        
                       ahR2 = ahR2);

      rownames(dfO) = 1:nsamp;
      # ................................................................



      # ................................................................
      # . Package all results into an output list :
      # ................................................................
      sp = list(dfO = dfO,
                indexOpt = indexOpt,
                asplitOpt = asplitOpt,
                dfV1Opt = dfV1Opt,
                dfV2Opt = dfV2Opt,
                p1Opt = p1Opt,
                beta1Opt = beta1Opt,
                p2Opt = p2Opt,
                beta2Opt = beta2Opt);
      # ................................................................      


      

      # ..............
      return (sp);
      # ..............

}

# =========================================================================================
# . End of Cox.computeCoxOnBinarySplits.
# =========================================================================================








# =========================================================================================
# . Cox.computeCoxOnTripleSplits : rather special test function. For a given study,
# . ----------------------------   investigates the effect on hazard ratio of splitting into
# .                                THREE equal parts, with balanced representation of each level.
# .
# . Generates multiple sampled values, computes Cox coefficient and P-value in each case.
# . Returns arrays with P-values, log-hazard-ratios and hazard-ratios.
# .
# . Syntax :
# .
# .     sp = Cox.computeCoxOnTripleSplits(dfV, tTime, tCens, tZ, tComp, nsamp, rngSeed);
# .
# . In: 
# .          dfV = input data frame.
# .        tTime = name of column with survival time information.
# .        tCens = name of column with censoring information (standard 1 = event).
# .           tZ = name of column with covariate against which to the Cox analyses :
# .                Surv(tTime, tCens) ~ tZ
# .
# .        tComp = name of column specifying a factor that defines the levels
# .                from each of which equal or as equal as possible splits will be
# .                done. This can be a simple factor (e.g. TREATMENT_ARM) or a composite
# .                factor (e.g. TREATMENT_ARM * PRIOR_LINES_OF_TREATMENT), generated
# .                beforehand.
# .        nsamp = number of resamplings to be done.
# .      rngSeed = random number seed.
# .
# . Out:
# .     sp = list, with members :
# .
# .         dfO = output data frame containing the Cox model results, with columns :
# .               {ap1, abeta1, ahR1, ap2, abeta2, ahR2}
# .
# .         indexOpt = index for set 1 for optimal split.
# .         dfV1Opt = data frame for set 1, from split which minimizes |beta2 - beta1|.
# .         dfV2Opt = data frame for set 2, from split which minimizes |beta2 - beta1|.
# .
# .         p1Opt, beta1Opt, p2Opt, beta2Opt = P-values and Cox coefficients for optimal split.
# . 
# ..........................................................................................
# . Example:
# .
# .     Cox.computeCoxOnTripleSplits(dfV = dfV,
# .                                  tTime = "PFSTIMEM",
# .                                  tCens = "PFSCENS",
# .                                  tZ = "ARMCD_binary",
# .                                  tComp = "ARMCD_binary",
# .                                  nsamp = 100,
# .                                  rngSeed = 123456);
# .
# =========================================================================================

Cox.computeCoxOnTripleSplits <- function(dfV, tTime, tCens, tZ, tComp, nsamp, rngSeed)
{

      # .........................................
      # . Initialize random number generator :
      # .........................................      
      set.seed(rngSeed);                  
      # .........................................

      

      # ...............................
      # . Preamble :
      # ...............................
      n = nrow(dfV);
      afac = dfV[[tComp]];      # Levels that define the groups to be split.
      # ...............................



      # .................................................................................
      # . Main sampling loop here :
      # .................................................................................
      ap1 = c();
      abeta1 = c();
      ahR1 = c();
      
      ap2 = c();
      abeta2 = c();
      ahR2 = c();

      ap3 = c();
      abeta3 = c();
      ahR3 = c();      

      deltaBOld = 1.0e9;                                           # Dummy starting value.

      for (i in 1:nsamp) {  
        # ...........................................................
        # . Generate split:
        # ...........................................................
        indexBufList = by(1:n, afac, Cox.sampleMultipleSplit, K = 3);   # Generate splits, group-by-group.
        # ...........................................................
        # . Gather the indices for each group (note: I was not
        # . able to do anything more elegant than these for loops):
        # ...........................................................
        K = 3;
        L = length(indexBufList);

        y = list();

        for (k in 1:K) {
          y[[k]] = indexBufList[[1]][[k]];
        }

        if (L > 1) {
          for (l in 2:L) {
            for (k in 1:K) {
              y[[k]] = c(y[[k]], indexBufList[[l]][[k]]);
            }
          }
        }
        # ...........................................................
        # . Extract the splits :
        # ...........................................................
	dfV1BUF = dfV[y[[1]], ];     # Set 1.
	dfV2BUF = dfV[y[[2]], ];     # Set 2.
	dfV3BUF = dfV[y[[3]], ];     # Set 2.        
        # ...........................................................
	# . Do the Cox analyses :
	# . >> Set 1:
        # ...........................................................
        at = dfV1BUF[[tTime]];
        as = dfV1BUF[[tCens]];
        az = dfV1BUF[[tZ]];

        cox1BUF = coxph(Surv(at, as) ~ az);
        sum1 = summary(cox1BUF);

	ap1 = c(ap1, sum1$sctest[3]);                # P-value, score test.
        abeta1 = c(abeta1, sum1$coefficients[1]);    # Log-hazard-ratio.
	ahR1 = c(ahR1, sum1$coefficients[2]);        # Hazard-ratio.
        # ...........................................................
	# . Do the Cox analyses :
	# . >> Set 2:
        # ...........................................................
        at = dfV2BUF[[tTime]];
        as = dfV2BUF[[tCens]];
        az = dfV2BUF[[tZ]];
        
        cox2BUF = coxph(Surv(at, as) ~ az);        
        sum2 = summary(cox2BUF);

	ap2 = c(ap2, sum2$sctest[3]);                # P-value, score test.
        abeta2 = c(abeta2, sum2$coefficients[1]);    # Log-hazard-ratio.        
	ahR2 = c(ahR2, sum2$coefficients[2]);        # Hazard-ratio.
        # ...........................................................
	# . Do the Cox analyses :
	# . >> Set 3:
        # ...........................................................
        at = dfV3BUF[[tTime]];
        as = dfV3BUF[[tCens]];
        az = dfV3BUF[[tZ]];
        
        cox3BUF = coxph(Surv(at, as) ~ az);        
        sum3 = summary(cox3BUF);

	ap3 = c(ap3, sum3$sctest[3]);                # P-value, score test.
        abeta3 = c(abeta3, sum3$coefficients[1]);    # Log-hazard-ratio.        
	ahR3 = c(ahR3, sum3$coefficients[2]);        # Hazard-ratio.        
        # ...........................................................
        # . Save index values for most balanced so far :
        # ...........................................................
        deltaB = sum(sum1$coefficients[1]^2 +
                     sum2$coefficients[1]^2 +
                     sum3$coefficients[1]^2);

        if (deltaB < deltaBOld) {
          indexOpt = y;             # List of so-far optimal indices.
          deltaBOld = deltaB;
        }
        # ...........................................................
        # . Indicate progress :
        # ...........................................................
        if ((i == 0) || (i%%10 == 0)) {
          cat(".");
        }
        # ...........................................................        
      }

      cat("\n");
      # .................................................................................

      

      # ..................................................
      # . Optimal split set assignments :
      # ..................................................
      asplitOpt = 1:n;
      
      asplitOpt[indexOpt[[1]]] = 1;
      asplitOpt[indexOpt[[2]]] = 2;
      asplitOpt[indexOpt[[3]]] = 3;      
      # ..................................................
      


      # ..................................................................................
      # . (Re)do the Cox analyses for the optimal split :
      # ..................................................................................
      dfV1Opt = dfV[indexOpt[[1]], ];     # Set 1.
      dfV2Opt = dfV[indexOpt[[2]], ];     # Set 2.      
      dfV3Opt = dfV[indexOpt[[3]], ];     # Set 3.
      # ...........................................................
      # . Do the Cox analyses :
      # . >> Set 1:
      # ...........................................................
      at = dfV1Opt[[tTime]];
      as = dfV1Opt[[tCens]];
      az = dfV1Opt[[tZ]];

      cox1Opt = coxph(Surv(at, as) ~ az);
      sum1 = summary(cox1Opt);

      p1Opt =  sum1$sctest[3];            # P-value, score test.
      beta1Opt = sum1$coefficients[1];    # Log-hazard-ratio.
      hR1Opt = sum1$coefficients[2];      # Hazard-ratio.
      # ...........................................................
      # . Do the Cox analyses :
      # . >> Set 2:
      # ...........................................................
      at = dfV2Opt[[tTime]];
      as = dfV2Opt[[tCens]];
      az = dfV2Opt[[tZ]];
        
      cox2Opt = coxph(Surv(at, as) ~ az);        
      sum2 = summary(cox2Opt);

      p2Opt = sum2$sctest[3];               # P-value, score test.
      beta2Opt = sum2$coefficients[1];      # Log-hazard-ratio.        
      hR2Opt = sum2$coefficients[2];        # Hazard-ratio.
      # ...........................................................
      # . Do the Cox analyses :
      # . >> Set 3:
      # ...........................................................
      at = dfV3Opt[[tTime]];
      as = dfV3Opt[[tCens]];
      az = dfV3Opt[[tZ]];
        
      cox3Opt = coxph(Surv(at, as) ~ az);        
      sum3 = summary(cox3Opt);

      p3Opt = sum3$sctest[3];               # P-value, score test.
      beta3Opt = sum3$coefficients[1];      # Log-hazard-ratio.        
      hR3Opt = sum3$coefficients[2];        # Hazard-ratio.      
      # ...........................................................
      


      

      # ................................................................
      # Package the P-values and coefficients into a data frame :
      # ................................................................
      dfO = data.frame(ap1 = ap1,
                       abeta1 = abeta1,
                       ahR1 = ahR1,
                       ap2 = ap2,
                       abeta2 = abeta2,        
                       ahR2 = ahR2,
                       ap3 = ap3,
                       abeta3 = abeta3,        
                       ahR3 = ahR3);

      rownames(dfO) = 1:nsamp;
      # ................................................................



      # ................................................................
      # . Package all results into an output list :
      # ................................................................
      sp = list(dfO = dfO,
                indexOpt = indexOpt,
                asplitOpt = asplitOpt,
                dfV1Opt = dfV1Opt,
                dfV2Opt = dfV2Opt,
                dfV3Opt = dfV3Opt,        
                p1Opt = p1Opt,
                beta1Opt = beta1Opt,
                p2Opt = p2Opt,
                beta2Opt = beta2Opt,
                p3Opt = p3Opt,
                beta3Opt = beta3Opt        
               );
      # ................................................................      


      

      # ..............
      return (sp);
      # ..............

}

# =========================================================================================
# . End of Cox.computeCoxOnTripleSplits.
# =========================================================================================







# =========================================================================================
# . Cox.sampleBinarySplit : simple utility function, generates a binary split of the
# . ---------------------   input array. If the length of the array is odd, will
# .                         randomly split on floor or ceiling.
# .
# . Syntax:
# .
# .       axSub =  Cox.sampleBinarySplit(ax);
# .
# . In:
# .       ax = input array.
# .
# . Out:
# .       axSub = subsetted array.
# .
# =========================================================================================

Cox.sampleBinarySplit <- function(ax)
{
  
     # ..............................................
     nx = length(ax);

     if (nx%%2 == 0) {
       nx2 = floor(nx / 2);
     } else {
       if (runif(1) > 0.5) {
         nx2 = floor(nx / 2);
       } else {
         nx2 = ceiling(nx / 2);
       }
     }
       
     axSub = sample(ax, size = nx2);
     # ............................................


     # ...............
     return (axSub);
     # ...............

}

# =========================================================================================
# . End of Cox.sampleBinarySplit.
# =========================================================================================






# =========================================================================================
# . Cox.sampleMultipleSplit : simple utility function, generates a multiple split of the
# . -----------------------   input array. Will always put at least one element into each
# .                           category.
# .
# . Syntax:
# .
# .       axS =  Cox.sampleMultipleSplit(ax, K);
# .
# . In:
# .       ax = input array.
# .        K = number of splits.
# .
# . Out:
# .      axS = list with K elements, each of which
# .            contains a subset of ax corresponding to
# .            the split.
# .
# =========================================================================================

Cox.sampleMultipleSplit <- function(ax, K)
{

     # ..............................................................
     stopifnot(K > 0);
     n = length(ax);

     if (K > n) {
       cat("ERROR: from Cox.sampleMultipleSplit:\n");
       cat("Number K = ", K,
           " of splits requested is greater than number n = ", n,
           " elements in the input array.\n");
       stop();
     }
     # ..............................................................

     
     
     # ..............................................................
     # . Randomly 
     # ..............................................................     
     n = length(ax);
     ft = 1 / K;
     cs = Cox.generateSplitsForVfold(n, ft, flagRandom = TRUE);

     axS = lapply(cs$aIndexSplit, function(index){ax[index];})
     # ..............................................................


     # .....................
     return (axS);
     # .....................

}

# =========================================================================================
# . End of Cox.sampleMultipleSplit.
# =========================================================================================







# =================================================================================================
# . Cox.generateSplitsForVfold : generates splits for the ``strict'' version of vfold.
# . --------------------------
# .
# . Syntax :
# .
# .       cs = Cox.generateSplitsForVfold(n, ft, flagRandom);
# .
# . In:
# .              n = total number of samples.
# .
# .             ft = fraction to be removed from the total to generate each test.
# .                  0 < ft < 1.
# .
# .     flagRandom = TRUE/FALSE. If TRUE, randomize index order before generating the groups.
# .                  If FALSE, the groups are generated in order of appearance of the indices.
# .
# . Out:
# .        cs = list with members :
# .
# .                ncv = number of groups generated.
# .              ntest = number of members in each group (last one may be truncated).
# .        aIndexSplit = list of ncv arrays, each array containing the indices of the group
# .                      to be extracted for a round of the cross-validation.
# .
# =================================================================================================

Cox.generateSplitsForVfold <- function(n, ft, flagRandom = FALSE)
{

      # ..................................
      stopifnot(ft > 0.0, ft < 1.0);
      stopifnot(n > 1);
      # ..................................
     

      
      # .............................................................
      # . Determine the value of ntest :
      # .............................................................      
      ntest = ceiling(ft * n);         # Tentative number in each test set.

      if (ntest < 1) {
        ntest = 1                 # Smallest test set has 1 element.
      };

      n2 = ceiling(n / 2);
      
      if (ntest > n2) {
        ntest = n2;               # At least two approximately equal groups.
      }
      # .............................................................


      
      # .................................................................................
      # . Now generate the actual groups :
      # .................................................................................
      bufIndex = 1:n;
      bufIndexChoose = bufIndex;

      if (ntest == 1) {
        mask = 1:n;                    # Each group will contain just one index.
      } else {
        bufB = bufIndex%%ntest;
        bufB = c(0, bufB[1:(n-1)]);    # Pad with a leading 0.
        bufC = ifelse(bufB == 0, 1, 0);
        mask = cumsum(bufC);
      }
        
      if (flagRandom) {
        bufIndexChoose = sample(bufIndexChoose);    # Randomize before grouping.
      }

      aIndexSplit = split(bufIndexChoose, mask);
      ncv = length(aIndexSplit);
      # ..................................................................................



      # ....................................
      # . Package results :
      # ....................................
      cs = list(ncv = ncv,
                ntest = ntest,
                aIndexSplit = aIndexSplit);
      # ....................................


      # ...........
      return (cs);
      # ...........
      
}  

# =================================================================================================
# . End of Cox.generateSplitsForVfold.
# =================================================================================================





# ===================================================================================================
# . Cox.generatehRConfidenceInterval : generates a confidence interval for a given hazard
# . --------------------------------   ratio, using the companion P-value.
# .                         
# . Syntax:
# .
# .         Cox.generatehRConfidenceInterval(hR, pR, prob);
# .
# . In:
# .         hR = hazard ratio. Must be > 0.
# .         pR = corresponding P-value. Must be in range 0 < P < 1.
# .         prob = probability for confidence interval. Default is 0.95 (95% CI).
# .
# . Out:
# .         List, with members as described in return statement below.
# .
# ===================================================================================================

Cox.generatehRConfidenceInterval <- function(hR, pR, prob = 0.95)
{
  
     # ...............................................................................
     n = length(hR);
     np = length(pR);

     if (np != n) {
       cat("ERROR: from Cox.generatehRConfidenceInterval:\n");
       cat("Length of hR and pR arrays differ. n = ", n, " np = ", np, "\n", sep = "");
       stop();
     }

     if (min(pR) <= 0) {
       cat("ERROR: from Cox.generatehRConfidenceInterval:\n");
       cat("pR has values <= 0.\n");
       stop();
     }

     if (max(pR) > 1) {
       cat("ERROR: from Cox.generatehRConfidenceInterval:\n");
       cat("pR has values > 1.\n");
       stop();
     }

     stopifnot((prob > 0.0) && (prob < 1.0));
     # ................................................................................



     # .......................................................................................................
     # . Compute the confidence interval :
     # .......................................................................................................
     xi = log(hR);                                  # Log-hazard-ratio.
     z = qnorm(0.5 * pR, lower.tail = FALSE);       # Value of z corresponding to P.

     eps = 1.0e-6;                                  # eps for flooring.
     sigmaXi = (abs(xi) + eps) / (z + eps);         # Standard deviation for log-hazard-ratio.

     prob1 = 1.0 - prob;                            # Probability outside the specified confidence interval.
     zc = qnorm(0.5 * prob1, lower.tail = FALSE);   # Value of z for specified confidence interval.

     dxi = zc * sigmaXi;
     xiLo = xi - dxi;
     xiHi = xi + dxi;

     hRLo = exp(xiLo);
     hRHi = exp(xiHi);
     # .......................................................................................................


     
     
     # ....................................................................................
     # . Special formating for single-value estimates :
     # ....................................................................................
     textCI = "";

     if (n == 1) {
       hRLobuf = sprintf("%6.2f", hRLo);
       hRbuf = sprintf("%6.3f", hR);              
       hRHibuf = sprintf("%6.2f", hRHi);

       textCI = paste("hR = ", hRbuf, "[", hRLobuf, ", ", hRHibuf , "]_", prob, sep ="");
     }
     # .....................................................................................
     


     
     
     # ........................................................................
     # . Package the results :
     # ........................................................................
     h = list(hRLo = hRLo,          # Lower bound on hR, at given conf. level.
              hR = hR,              # Input value of log-hazard-ratio.
              hRHi = hRHi,          # Upper bound on hR, at given conf. level.
              sigmaXi = sigmaXi,    # sd for log-hazard-ratio.
              pR = pR,              # Input value of P-values.
              textCI = textCI);     # Text string for hR and its CI.
     # ........................................................................


     # ...............
     return (h);
     # ...............

}

# ===================================================================================================
# . End of Cox.generatehRConfidenceInterval.
# ===================================================================================================



# ===================================================================================================
# . Cox.computeTimes : for given survival times and companion censoring statues, computes
# . ----------------   the estimated median survival time and 0.95 confidence levels based on
# .                    the Kaplan-Meier estimator of the survival function.
# .
# .   Syntax :
# .       ct = Cox.computeTimes(at, as);
# .
# .   In:
# .       at = survival times.
# .       as = binary censoring statuses (1 = died, 0 = censored).
# .
# .   Out:
# .       ct = list with members:
# .
# .            tLo    : 0.025 quantile value.
# .            tMed   : Median.
# .            tHi    : 0.975 quantile value.
# .
# ===================================================================================================

Cox.computeTimes <- function(at, as)
{

       # ...............................................................................
       n = length(at);
       ns = length(as);

       if (ns != n) {
         cat("ERROR: from Cox.computeTimes:\n");
         cat("Length of at and as arrays differ. n = ", n, " ns = ", ns, "\n", sep = "");
         stop();
       }
       # ...............................................................................

       
       # ...............................................................................
       # . Return dummy values if the input arrays are of zero length :
       # ...............................................................................
       if (n == 0) {
         tLo = -1.0;     # 0.025 quantile value.
         tMed = -1.0;    # Median.
         tHi = -1.0;     # 0.975 quantile value.
       }
       # ...............................................................................

         
       
       # ...............................................................................
       # . Generate KM model, then extract survival time estimates for finite-length
       # . arrays :
       # ...............................................................................
       if (n > 0) {
         fitA = survfit(Surv(at, as) ~ 1);
         sumA = summary(fitA);
         tabA = sumA$table;     # Non-obvious place where the time summaries are kept.

         tLo = tabA[8];     # 0.025 quantile value.
         tMed = tabA[7];    # Median.
         tHi = tabA[9];     # 0.975 quantile value.
       }
       # ...............................................................................

       
       # ..........................
       # . Package results :
       # ..........................
       ct = list(tLo = tLo,
                 tMed = tMed,
                 tHi = tHi);
       # ..........................


       # .............
       return (ct);
       # .............

}

# ===================================================================================================
# . End of Cox.computeTimes.
# ===================================================================================================




# ===================================================================================================
# . Cox.computehRROCArea : computes the area under an hR ROC, as described in detail below.
# . --------------------
# .              
# .   Syntax :
# .
# .       auc = Cox.computehRROCArea(ahR);
# .
# .   In :
# .
# .      ahR = the hazard ratio between treatment arms, for either sensitive
# .            or resistant patients, discretized on a grid i = 1, 2, . . ., n.
# .
# .            The fractional number q of patients selected for the i-th sample
# .            is assumed to be :
# .
# .                         i - 1
# .                    q = ------- , i = 1, 2, . . ., n.
# .                         n - 1
# .
# .            so that implicitly 0 <= q <= 1 with dq = 1 / (n - 1).
# .
# .   Out :
# .
# .       auc = area under curve, computed as described below.
# .
# ..................................................................................................
# . Details :
# .
# .  The area under the curve is computed in a way that makes the contributions of hR < 1
# .  and hR > 1 symmetrical.
# .
# .  Consider hR = hR(q), for 0 <= q <= 1.
# .
# .  * For regions where hR(q) <= 1, we directly compute the area A- :
# .
# .               /
# .               |
# .         A  =  |   dq . hR(q)
# .          -    |
# .               /
# .            hR(q) <= 1
# .
# .
# .  * For regions where hR(q) > 1, we transform hR with
# .
# .                 1
# .          hR' = ----
# .                 hR
# .
# .  and for regions where hR' < 1, we then compute the area between the curve of hR'(q)
# .  and the line hR' = 1, to which we add the area under the line hR = 1 in the original
# .  graph, defining the area A+ :
# .
# .               /                            /                         
# .               |                            |                         
# .         A  =  |   dq . (1 - hR'(q)) +      |   dq . 1
# .          +    |                            |                         
# .               /                            /                         
# .            hR(q) > 1                    hR(q) > 1                    
# .
# .
# . The final result is A = A- + A+, which can be written (writing xi = hR) :
# .
# .                 1                                   1
# .                /                                   /                               
# .                |                          1        |                           
# .  A =  1  +     |   dq . theta(xi -1)(1 - --- ) -   |   dq . theta(1 - xi )(1 - xi)
# .                |                          xi       |                          
# .                /                                   /                               
# .                0                                   0
# .
# . Note that i) if hR -> 0 everywhere, then A -> 0; ii) if hR ->infinity everywhere, then A -> 2,
# . and finally, iii) if hR = 1 everywhere, A = 1.
# .
# ...................................................................................................
# . * 5-15-2012 : I changed the area definition outlined above slightly. By omitting the term 1 in
# . the equation above and writing :
# .
# .
# .                 1                                   1
# .                /                                   /                               
# .                |                          1        |                           
# .       A =      |   dq . theta(xi -1)(1 - --- ) -   |   dq . theta(1 - xi )(1 - xi)
# .                |                          xi       |                          
# .                /                                   /                               
# .                0                                   0
# .
# .
# .         def
# .          =   A+ - A-    
# .
# . (with slightly different definitions of A+ and A- tahn above), A is now the *signed* area between
# . the line xi = 1 and the actual hazard ratio line xi = hR(q), with A- tallying areas below xi = 1
# . and A+ tallying areas above xi = 1.
# . Note that i) if hR -> 0 everywhere, then A -> -1; ii) if hR ->infinity everywhere, then A -> 1,
# . and finally, iii) if hR = 1 everywhere, A = 0. Thus,
# .
# .                     -1 <= A <= 1
# .
# . which gives the statistic a more satisfactory feel. Note that this has no effect on the area
# . between curves, as we just subtracted the offset of 1.
# . 
# ===================================================================================================

Cox.computehRROCArea <- function(ahR)
{

     # .....................................................
     n = length(ahR);

     if (n < 2) {
       cat("ERROR: from Cox.computehRROCArea:\n");
       cat("Length of array ahR is less than 2.\n");
       stop();
     }

     ahR = ifelse(is.na(ahR), 1.0, ahR);   # Replace NAs by 1.0
     
     if (min(ahR) < 0.0) {
       cat("ERROR: from Cox.computehRROCArea:\n");
       cat("min(ahR)= ", min(ahR), " is negative.\n");
       stop();
     }
     # .....................................................    


     
     # ..........................................................................
     xPlus = ifelse(ahR > 1.0, (1 - 1.0 / ahR), 0.0);           # Summands for ahR > 1.
     xMinus = ifelse(ahR <= 1.0, (1 - ahR), 0.0);               # Summands for ahR <= 1.

     sumPlus = sum(xPlus) - 0.5 * (xPlus[1] + xPlus[n]);        # Trapezoidal rule.
     sumMinus = sum(xMinus) - 0.5 * (xMinus[1] + xMinus[n]);    # Trapezoidal rule.

     dq = 1 / (n - 1);                                          # Grid spacing.
     auc = dq * (sumPlus - sumMinus);                           # Final sum.
     # ..........................................................................


     # .............
     return (auc);
     # .............
     
}

# ===================================================================================================
# . End of Cox.computehRROCArea.
# ===================================================================================================





# ===================================================================================================
# . Cox.objectivePhi :  a simple-minded objective function for optimizing the threshold in models
# . ----------------    with two treatment armas and a moving threshold based on predicted differential
# .                     log-hazard-ratio.
# .   Syntax :
# .
# .       auc = Cox.objectivePhi(ahRSens, ahRRes);
# .
# .   In :
# .
# .    ahRSens = the hazard ratio between treatment arms, for sensitive
# .              patients, discretized on a grid i = 1, 2, . . ., n
# .
# .     ahRRes = the hazard ratio between treatment arms, for resistant patienst
# .              patients, discretized on a grid i = 1, 2, . . ., n.
# .
# .            The fractional number q of patients selected for the i-th sample
# .            is assumed to be :
# .
# .                         i - 1
# .                    q = ------- , i = 1, 2, . . ., n.
# .                         n - 1
# .
# .            so that implicitly 0 <= q <= 1 with dq = 1 / (n - 1).
# .
# .   Out :
# .
# .
# ..................................................................................................
# . Details :
# .
# ===================================================================================================

Cox.objectivePhi <- function(ahRSens, ahRRes)
{

     # ............................................................................
     n = length(ahRSens);
     nbuf = length(ahRRes);

     if (nbuf != n) {
       cat("ERROR: from Cox.objectivePhi:\n");
       cat("Length of array ahRRes is not the same as that of array ahRSens.\n");
       stop();
     }

     if (n < 2) {
       cat("ERROR: from Cox.objectivePhi:\n");
       cat("Length of arrays < 2.\n");
       stop();       
     }
     # ............................................................................


     
     # ....................................................................................
     dq = 1 / (n - 1);                                          # Grid spacing.
     aq = dq * ((1:n) - 1);                                     # Grid values for sensitive fraction.

     h0 = ahRSens[n];                                           # Global hazard ratio.

     ahRResBUF = ifelse(ahRRes <= 1.0, ahRRes, 1.0);            # Ceiling at 1.
     
     aphi = aq * (ahRSens - h0) + (1.0 - aq) * (1.0 - ahRResBUF);   # Objective function.

     imin = which.min(aphi);                                    # Index for minimum.
     phimin = aphi[imin];                                       # Value at minimun.
     qmin = aq[imin];                                           # Sensitive fraction at minimum.
     hRSensMin = ahRSens[imin];                                 # hR(S) at minimum.
     hRResMin = ahRRes[imin];                                   # hR(R) at minimum.
     # ....................................................................................

     

     # .............................................
     # . Package results :
     # .............................................
     objphi = list(aq = aq,
                   h0 = h0,
                   aphi = aphi,
                   imin = imin,
                   phimin = phimin,
                   qmin = qmin,
                   hRSensMin = hRSensMin,
                   hRResMin = hRResMin);
     # .............................................


     # ................
     return (objphi);
     # ................
     
}

# ===================================================================================================
# . End of Cox.objectivePhi.
# ===================================================================================================




  
# ===================================================================================================
# . Cox.compareHazardRatios : compares two hazard ratios, tests whether they are statistically 
# . -----------------------   different.
# .                         
# . Syntax:
# .
# .      pval = Cox.compareHazardRatios(hR1, pR1, hR2, pR2);
# .
# . In:
# .         hR1 = hazard ratio 1. Must be > 0.
# .         pR1 = corresponding P-value. Must be in range 0 < P < 1.
# .         hR2 = hazard ratio 2. Must be > 0.
# .         pR2 = corresponding P-value. Must be in range 0 < P < 1.  
# .
# . Out:
# .         List, with members as described in return statement below.
# .
# ===================================================================================================

Cox.compareHazardRatios <- function(hR1, pR1, hR2, pR2)
{

     # .......................................................................................................
     # . Compute the confidence intervals :
     # .......................................................................................................
     prob = 1.0 -  2.0 * pnorm(1.0, lower.tail = FALSE);
     ci1 = Cox.generatehRConfidenceInterval(hR1, pR1, prob = prob);
     ci2 = Cox.generatehRConfidenceInterval(hR2, pR2, prob = prob);

     sigmaXi1 = ci1$sigmaXi;
     sigmaXi2 = ci2$sigmaXi;

     delta = abs(log(hR2) - log(hR1));     
     sigma = sqrt(sigmaXi1^2 + sigmaXi2^2);

     z = delta / sigma;
     pval = 2.0 * pnorm(z, lower.tail = FALSE)
     # .....................................................................................

     
     # ...............
     return (pval);
     # ...............

}

# ===================================================================================================
# . End of Cox.compareHazardRatios.
# ===================================================================================================





  
# ===================================================================================================
# . Cox.plotSwimmers : generates a horizontal bars 'swimmers' plot, showing survival span for each 
# . ----------------   subject.
# .                         
# . Syntax:
# .
# .      cn = Cox.plotSwimmers(at, as, an, atype = NULL, xlab, ylab, caption, leftMargin = 2.0);
# .
# . In:
# .         at      = survival time.
# .         as      = censoring status.
# .         an      = names of samples.
# .         atype   = categorical classification of instances. If non-NULL, used to color the bars.
# .         xlab    = label for time axis.
# .         ylab    = label for the sampe axis.
# .         caption = overall caption.
# .         leftMargin = width of left margin (may be adjusted to accomodate labels).
# .
# . Out:
# .         List, with members as described in return statement below.
# .
# ===================================================================================================

Cox.plotSwimmers <- function(at, as, an, atype = NULL, xlab, ylab, caption, leftMargin = 2.0)
{

     # .....................................................................................
     # . Check on values :
     # .....................................................................................
     nt = length(at);
     
     stopifnot(length(as) == length(at));
     stopifnot(length(an) == length(at));     

     if (!is.null(atype)) {
       stopifnot(length(atype) == length(at));       
     }
     # .....................................................................................


     # .....................................................................................
     # . Order by survival time :
     # .....................................................................................
     indexO = order(at, decreasing = FALSE);

     at1 = at[indexO];
     as1 = as[indexO];
     an1 = an[indexO];     

     if (!is.null(atype)) {
       atype1 = atype[indexO];       
     }
     # .....................................................................................


     # ..............................................................................
     # . Adjust left margin size :
     # ..............................................................................
     mai.OLD = par("mai");
     buf = mai.OLD;
     buf[2] = leftMargin;
     par(mai = buf);
     # ..............................................................................
     # . Select colors :
     # ..............................................................................
     if (is.null(atype1)) {
       acol = rep('blue', nt);
     } else {
       if (length(unique(atype1)) == 2) {
         atype1.u = sort(unique(atype1));
         acol = ifelse(atype1 == atype1.u[1], 'blue', 'red');
       } else {
         cw = Graphics.makeColorWheelOnArray(atype1, flagShuffle = TRUE, rngSeed = 458761);
         acol = cw$acol;
       }
     }

     acol1 = Graphics.addTransJST(acol, alpha = 0.75);
     ncol.u = length(unique(acol1));
     # ..............................................................................
     # . Do the barplot :
     # ..............................................................................
     xmin = 0.0;
     xmax = 1.1 * max(at1);
     
     bary = barplot(at1,
                    xlim = c(xmin, xmax),
                    names.arg = an1,
                    xlab = xlab,       
                    ylab = ylab,
                    main = caption,
                    horiz = TRUE,
                    space = 0,
                    las = 1,
                    col = acol1);
     # ..............................................................................
     # . Add censoring information :
     # ..............................................................................
     ays = bary;
     # axs = at1 + 0.01 * xmax;
     axs = at1;
     apch = ifelse(as == 1, NA, 19);
     points(axs, bary, type = 'p', pch = apch);
     # ..............................................................................
     # . Add color legend :
     # ..............................................................................
     if (ncol.u == 2) {
       legendText = atype1.u;
       colVector = c('blue', 'red');
       ltyVector = c(1, 1);
       lwdVector = c(2, 2);
       pchVector = c(15, 15);
      
       legend(x = 0.65 * xmax,
              y = 0.25 * max(bary),
              cex = 1.0,
              legend = legendText, 
	      pch = pchVector,
              col = colVector,
              bty = 'n',
              title = '');
     }
     
     if (ncol.u > 2) {
       par(new = TRUE);
       Graphics.plotLegendOnColorWheel(cw, caption = '', hpos = 'right');  # NOTE: must adjust position (2-2-2018).
     }
     # ..............................................................................
     # . Censoring information :
     # ..............................................................................
     legendText = 'censored event';
     colVector = c('black');
     ltyVector = c(1);
     lwdVector = c(2);
     pchVector = c(19);

     legend(x = 0.65 * xmax,
            y = 0.15 * max(bary),
            cex = 1.0,
            legend = legendText, 
            pch = pchVector,
            col = colVector,
            bty = 'n',
            title = '');     
     # ..............................................................................
     # . Restore margins :
     # ..............................................................................
     par(mai = mai.OLD);
     # ..............................................................................


     
     # ...............
     return (0);
     # ...............

}

# ===================================================================================================
# . End of Cox.plotSwimmers.
# ===================================================================================================





# ===================================================================================================
# . Cox.simulateCellViabilityAssay : generates mock event statistics for cells with an exponential survival
# . ------------------------------   probability.
# .                         
# . Syntax:
# .
# .  cn = Cox.simulateCellViabilityAssay(alpha,           # Death rate (units = 1 / day).
# .                                      nt,              # Number of days of observation (1, 2, ..., 14).
# .                                      N,               # Original number of cells at t = 0.
# .	   		                 rngSeed)         # RNG seed.
# .
# . Out:
# .         List, with members as described in return statement below.# .
# ...................................................................................................
# .  * Example :
# .
# .  alpha = 1/10;                             # Death rate under control conditions (units = 1 / day).
# .  nt = 14;                                  # Number of days of observation (1, 2, ..., 14).
# .  N = 10000;                                # Original number of cells at t = 0.
# .  rngSeed = 123456;                         # RNG seed,
# .
# ===================================================================================================

Cox.simulateCellViabilityAssay <- function(alpha,  
                                           nt,     
                                           N,      
					   rngSeed)
{

       # .......................................................................................................
       at = 1:nt;                                # Observation times (days) post t = 0.
       as = exp(- alpha * at);                   # Survival probabilities.

       set.seed(rngSeed);
       ak = rbinom(length(as), N, as);           # Number of survivors at each time.

       akTot = c(N, ak);                         # Put initial time as well.
       nt1 = nt + 1;
       akDead = akTot[1:nt] - akTot[2:nt1];      # Number with death observed at each time point.

       at.events = rep(at, akDead);              # Times of their deaths.
       acens.events = rep(1, length(at.events)); # All have status 1.

       at.last = rep(at[nt], ak[nt]);            # These are the survivors at t = 14 days.    
       acens.last = rep(0, ak[nt]);              # All exit the study with status = 0.

       at.all = c(at.events, at.last);           # Put all event times and censoring statuses together.
       acens.all = c(acens.events, acens.last);
       # .......................................................................................................


       
       # ...................................................................       
       cn = list(at = at.all, acens = acens.all);      # Package results.
       # ...................................................................              

       
       # ...........
       return (cn);
       # ...........

}

# ===================================================================================================
# . End of Cox.simulateCellViabilityAssay.
# ===================================================================================================


