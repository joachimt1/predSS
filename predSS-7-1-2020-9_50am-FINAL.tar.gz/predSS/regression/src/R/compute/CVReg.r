# ======================================================================================
# . CVReg.r : contains cross-validation programs for regression calculations.
# . -------
# ======================================================================================

# ======================================================================================
# . CVReg.loop:  runs a cross validation loop over a range of regression parameters.
# . ----------
# .
# .      cv = CVReg.loop(ar, inparam);
# .
# . IN:
# .       ar      = input Rdat object (includes input data matrix).
# .       inparam = contains cross-validation parameters.
# . OUT:
# .       cv = output CVReg.loop object.
# .
# .
# . CVReg.loop members:
# .
# .     fModel = fModel,
# .     ngroup    = number of leave-one-out groups used (logo).
# .     aLambda   = array of lambda values used in cross-validation.
# .	aSSR      = array of sum-of-squared residuals, for each lambda.
# .     aRMS      = array of RMS values for the squared residuals, for each lambda.
# .     RMSlogoMin= minimum RMS value for the residuals.
# .     lambdaMin = value of lambda at which RMSlogoMin occurs. If there are tied
# .                 RMSlogoMin values, this selects for the smallest value of lambda.
# .
# .     SSRTr     = sum-of-squared residuals for prediction by the entire training
# .                 set, for lambda = lambdaMin.
# .
# .     RMSTr     = RMS value sum-of-squared residuals for prediction by 
# .                 the entire training set, for lambda = lambdaMin.
# .     betaTr    = regression coefficients for prediction by the entire
# .                 training set, at lambda = lambdaMin.
# .     acPred    = array of predictor variable names.
# . 
# .	yInOut    = two column vector, with yInOut[ ,1] = input values of y,
# .                 and yInOut[ ,2] = predicted values of y, for lambda = lambdaMin.
# .
# ......................................................................................
# . Definition of sum of squared residuals:
# .
# . For the j-th instance that was removed, we can compute the squared residual:
# .
# .                      (p)        2  
# .            SR   =  (y     - y  )   
# .              j       j       j     
# .
# . where y(p) is the predicted value, and y the observed value of the response.
# . We then have:
# .
# .                n      (p)        2  
# .        SSR  = Sum   (y     - y  )   
# .   	         j = 1    j       j     
# .
# . where n = number of instances (rows in the data matrix).
# . The rms (root-mean-square) value is then:
# .
# .       RMS =  sqrt(SSR / n)
# .
# ======================================================================================

CVReg.loop <- function(ar, inparam)
{
	# .................................................................................
	if (class(ar) != "Rdat") {
	   msg = cat("ERROR: from CVReg.loop : input ar is not of class Rdat.\n");
	   stop(msg);
	}

	if (class(inparam) != "InparamReg") {
	   msg = cat("ERROR: from CVReg.loop : input inparam is not of class InparamReg.\n");
	   stop(msg);
	}
	# ..................................................................................


	# ..................................................................................
	# . Check for allowed parameters:
	# ..................................................................................
	if (inparam$flavor != 'ridge') {
	   msg = cat("ERROR: from CVReg.loop : regression flavor = ", inparam$flavor, " is not valid.\n");
	   stop(msg);
	}

	if ((inparam$cv_method != "loocv")
	    && (inparam$cv_method != "logo")
	    && (inparam$cv_method != "vfold")) {
	   msg = cat("ERROR: from CVReg.loop : cv_method = ", inparam$cv_method, " is not valid.\n");
	   stop(msg);
	}
	# ..................................................................................


	# ..................................................................................
	# . Build lambda array for cross-validation:
	# ..................................................................................
	aLambda = seq(inparam$lambdalo, inparam$lambdahi, inparam$lambdainc);
	# ..................................................................................


	# ..................................................................................
	if (inparam$flavor == "ridge") {
	   if (inparam$cv_method == "logo") {
               cv = CVReg.loop.ridgeCVlogo(ar$ad, aLambda);	     	      
 	   }
	}
	# ..................................................................................


}

# ======================================================================================
# . End of CVReg.loop.
# ======================================================================================




# ======================================================================================
# . CVReg.loop.ridgeCVlogo : this function reads a data frame, and performs
# . ----------------------   leave-one-group-out (logo) cross validation on a
# .                          ridge regression model.
# .                          RMS error is generated as a function of the ridge coefficient
# .                          lambda.
# .
# . Syntax:
# .
# .         cv = CVReg.loop.ridgeCVlogo(ad, aLambda);
# .
# . IN:
# .
# .        ad = input data frame, from an Rdat object.
# .     aLambda = array of lambda values (can also be a single scalar value).
# .
# . OUT:
# .        cv = CVReg.loop object.
# .
# . CVReg.loop members:
# .
# .     fModel = fModel,
# .     ngroup    = number of leave-one-out groups used (logo).
# .     aLambda   = array of lambda values used in cross-validation.
# .	aSSR      = array of sum-of-squared residuals, for each lambda.
# .     aRMS      = array of RMS values for the squared residuals, for each lambda.
# .     RMSlogoMin= minimum RMS value for the residuals.
# .     lambdaMin = value of lambda at which RMSlogoMin occurs. If there are tied
# .                 RMSlogoMin values, this selects for the smallest value of lambda.
# .
# .     SSRTr     = sum-of-squared residuals for prediction by the entire training
# .                 set, for lambda = lambdaMin.
# .
# .     RMSTr     = RMS value sum-of-squared residuals for prediction by 
# .                 the entire training set, for lambda = lambdaMin.
# .     betaTr    = regression coefficients for prediction by the entire
# .                 training set, at lambda = lambdaMin.
# .     acPred    = array of predictor variable names.
# . 
# .	yInOut    = two column vector, with yInOut[ ,1] = input values of y,
# .                 and yInOut[ ,2] = predicted values of y, for lambda = lambdaMin.
# .
# =====================================================================================

CVReg.loop.ridgeCVlogo <- function(ad, aLambda)
{

        # ......................................................
  	cat(" ..........  Entry in CVReg.loop.ridgeCVlogo\n");
        # ......................................................



        # .....................................................................................
        # . Check on input parameter identities:
        # .....................................................................................
        if (!is.data.frame(ad)) {
	    msg = "ERROR: from CVReg.loop.ridgeCVlogo: input variable ad is not a data frame. Exit.";
	    stop(msg);
	}

        if (!is.numeric(aLambda)) {
	    msg = "ERROR: from CVReg.loop.ridgeCVlogo: input variable aLambda is not numeric. Exit.";
	}
        # .....................................................................................
	# . Check on data frame parameters :
	# .
        # . Check that the input data frame has the appropriate column names:
        # .....................................................................................
	ac = colnames(ad);

        if (length(ac[ac == "y"]) == 0) {
	    msg = "ERROR: from CVReg.loop.ridgeCVlogo: input data frame does not have column name: y. Exit.";
	    stop(msg);
	}

        if (length(ac[ac == "group"]) == 0) {
	    msg = "ERROR: from CVReg.loop.ridgeCVlogo: input data frame does not have column name: group. Exit.";
	    stop(msg);
	}
        # .....................................................................................
	# . Report on size, check that there are more than one group to do logo on:
        # .....................................................................................
 	nr = nrow(ad);             # Number of instances.

	acPred = ac[(ac != "qual") & (ac != "y") 
                    & (ac != "training") & (ac != "group") & (ac != "test")];
	m = length(acPred);        # Number of predictors (= dimensionality).

        if (m == 0) {
	    msg = "ERROR: from CVReg.loop.ridgeCVlogo: found m = 0 predictors in input data frame. Exit";
	    stop(msg);
	}

  	cat(" ..........  Input data frame has: nr = ", nr, " rows\n.");
	cat("                                   m = ", m, " predictors\n.");

        group = factor(ad$group);   
        aGroup = levels(group);                 # The distinct levels for this factor.
	ngroup = length(aGroup);

	if (ngroup == 1) {
	    msg = "ERROR: from CVReg.loop.ridgeCVlogo: there is only one group in the data frame. Cannot do logo. Exit.";
	    stop(msg);
	}

  	cat(" ..........  Logo cross-validation: ngroup = ", ngroup, " groups.\n");
        # .....................................................................................
	# . Check on the lambda values :
        # .....................................................................................
	if (length(aLambda) == 0) {
	    msg = "ERROR: from CVReg.loop.ridgeCVlogo: lambda array is empty. Exit.";
	    stop(msg);
	}

	flag = sum(aLambda < 0.0);

	if (flag > 0) {
	    msg = "ERROR: from CVReg.loop.ridgeCVlogo: I found at least one negative lambda in the input array. Exit.";
	    stop(msg);
	}
        # .....................................................................................


        # .....................................................................................
	if (length(aLambda) == 1) {
	   cat(" ..........  Doing logo cross-validation for a single value of lambda.\n");
	} else {
	   cat(" ..........  Doing logo cross-validation for multiple values of lambda.\n");
	}
        # .....................................................................................




        # .....................................................................................
	# . Build an explicit formula from the predictor columns:
	# .....................................................................................
	fModel = as.formula(paste("y~", paste(acPred, collapse="+")));
	# .....................................................................................



        # .................................................................................
        # . Logo cross-validation loop :
	# .
	# . For each round of leave-one-group-out, we compute the SSR (sum-of-squared
	# . residuals) for the whole range of lambda values.
	# . At the end of the logo loop, we then do a final summation of all SSR
	# . contributions, for each value of lambda separately.
        # .................................................................................
	nlambda = length(aLambda);                             # Number of lambda terms explored.
        aSSR = seq(length = nlambda, from = 0.0, to = 0.0);    # Initialize SSR array.

  	print("Start cross-validation loop:", quote = FALSE);

	for (g in aGroup) {
	   cat("group out: ", g, "\n");

	   adTrain = ad[ad$group != g , ];               # Remove g from training set.
	   adTest = ad[ad$group == g , ];                # Put g in test set.
	   # ............................................................
	   # . Compute scaled-data statistics: 
	   # .
	   # . These are needed, as the function lm.ridge used below
           # . automatically mean-centers the response, and standardizes
	   # . (means-centers + divides by stddev) the predictors.
	   # ............................................................
           ymTrain = mean(adTrain$y);                              # Mean response in training set.
           # ............................................................
	   # . Find the column means and column std deviations :
           # ............................................................
	   XTrain = Rdat.getPredictors(adTrain);           # Extract predictor columns.
	   xmTrain = apply(XTrain, c(2), mean);            # Gets the column means.
	   smTrain = sqrt(apply(XTrain, c(2), var));       # Gets the column standard deviations.
           # ............................................................
	   # . Extract the test set responses and predictors.
	   # . Then scale (standardize) these against the *training*
	   # . set means and standard deviations.
           # ............................................................
	   yTest = adTest$y;           
	   XTest = Rdat.getPredictors(adTest);                  # Extract predictor columns.
	   XTestNorm = as.matrix(scale(XTest, center = xmTrain, scale = smTrain));
	   # ................................................................
	   # . Compute ridge regressions for all the values of lambda:
	   # . The resulting coefficient matrix is: g$coef (p * nlambda)
	   # ................................................................
           g = lm.ridge(formula = fModel, data = adTrain, lambda = aLambda); 

	   yTestPredict = ymTrain + XTestNorm %*% g$coef;       # This is an nTest * nlambda matrix.
	   dy = yTestPredict - Matrix.spreadCol(yTest, nc = nlambda);  # nTest * nlambda matrix of residuals.
           dy2 = dy * dy;                                   # Squared residuals.
	   dSSR = colSums(dy2);                             # nlambda vector of summed residuals.
           aSSR = aSSR + dSSR;                              # Increment SSR in running tally.
	   # ................................................................
        }

  	cat("End of cross-validation loop.\n");

	aRMS = sqrt(aSSR / nr);                   # RMS values for SSR, for nr held-out samples.
        # .................................................................................



        # .................................................................................
	# . Find the optimal lambda, within range explored:
        # .................................................................................
	RMSlogoMin = min(aRMS);
	lambdaMin = aLambda[aRMS == RMSlogoMin][1];
        # .................................................................................


        # .................................................................................
        # . Do a final prediction based on the entire training set:
        # .................................................................................
        gTr = lm.ridge(formula = fModel, data = ad, lambda = lambdaMin);

	XNorm = Rdat.getPredictors(ad);                          # Extract the predictor columns.
	XNorm = as.matrix(scale(XNorm));

	yTr = gTr$ym + XNorm %*% gTr$coef;      # Final training set prediction.
	dy = yTr - ad$y;                                    # Residuals.

	SSRTr = sum(dy * dy);
	RMSTr = sqrt(SSRTr / nr);              # RMS under training set.
        # .................................................................................



        # ..........................................................................
  	print(" ..........  End of computation in CVReg.loop.ridgeCVlogo", quote = FALSE);
        # ..........................................................................


        # .................................................................................
        # . Package final results:
        # .................................................................................
	yInOut = cbind(ad$y, yTr);

        cv = list(fModel = fModel,
                  aLambda = aLambda, 
	          aSSR = aSSR, 
	          aRMS = aRMS, 
                  RMSlogoMin = RMSlogoMin, 
                  lambdaMin = lambdaMin,
                  SSRTr = SSRTr,
                  RMSTr = RMSTr,
	          betaTr = gTr$coef,
	          acPred = acPred,
	          yInOut = yInOut,
	          ngroup = ngroup);

        class(cv) = "CVReg.loop";

        return(cv);
        # .................................................................................

}

# ======================================================================================
# . End of CVReg.loop.ridgeCVlogo.
# ======================================================================================



# ======================================================================================
# . CVReg.loop.outputStats: outputs statistics from a regression optimization loop.
# . ----------------------
# .
# .      CVReg.loop.outputStats(inparam, cv, fs);
# .
# . IN:
# .
# .   inparam = input parameters for the cross-validation.
# .   cv      = CVReg.loop object; output from a cross-validation exercise.
# .   fs      = output file name.
# .
# ======================================================================================

CVReg.loop.outputStats <- function(inparam, cv, fs)
{


	# ......................................................
      	cat(" ..........  Entry in CVReg.loop.outputStats.\n");
   	# ......................................................


	# .........................................................................................
	if (class(inparam) != "InparamReg") {
	   msg = cat("ERROR: from CVReg.loop.outputStats : input inparam not of class InparamReg.\n");
	   stop(msg);
	}

	if (class(cv) != "CVReg.loop") {
	   msg = cat("ERROR: from CVReg.loop.outputStats : input cv is not of class CVReg.loop.\n");
	   stop(msg);
	}
	# .........................................................................................


	# .....................
	FS = file(fs, "w");
	# .....................


	# .............................................................................
	# . Write header information :
	# .............................................................................
 	cat("\#REGRESSION CROSS-VALIDATION LOOP RESULTS:\n", file = FS);
 	cat("\#\n", file = FS);

	cat("\#INPUT PARAMETERS:\n", file = FS);
	cat("\#Flavor of regression: flavor = ", inparam$flavor, "\n", file = FS);

	if (inparam$flavor == "ridge") {
	   nlambda = length(cv$aLambda);

   	   cat("\#Lower bound on lambda values: lambdalo = ", inparam$lambdalo, "\n", file = FS);
	   cat("\#Upper bound on lambda values: lambdahi = ", inparam$lambdahi, "\n", file = FS);
	   cat("\#Increment on lambda values: lambdainc = ", inparam$lambdainc, "\n", file = FS);
	   cat("\#Number of lambda values: nlambda = ", nlambda, "\n", file = FS);
	}

  	cat("\#Cross-validation method used: cv_method = ", inparam$cv_method, "\n", file = FS);

	if (inparam$cv_method == "logo") {
	  cat("\#Number of groups under logo = ", cv$ngroup, "\n", file = FS);
	}

	if (inparam$cv_method == "vfold") {
	   cat("\#Number of cross-validation steps used: ncv = ", inparam$ncv, "\n", file = FS);
 	   cat("\#Test set fraction: ft = ", ft, "\n", file = FS);
	}
	# .............................................................................
	# . Results:
	# .............................................................................
	cat("\#RESULTS:\n", file = FS);

	if (inparam$flavor == "ridge") {
	   cat("\#Lambda for minimum logo residuals: lambdaMin = ", cv$lambdaMin, "\n", file = FS);
	   cat("\#Minimum logo RMS: RMSlogoMin = ", cv$RMSlogoMin, "\n", file = FS);
	   cat("\#Training set RMS: RMSTr = ", cv$RMSTr, "\n", file = FS);
	}
	# .............................................................................


	# .............................................................................
	# . Write body:
	# .
	# . SSR versus lambda (regularization factor):
	# .............................................................................
	if (inparam$flavor == "ridge") {
 	   cat("\#\n", file = FS);
 	   cat("\#RESIDUALS AS A FUNCTION OF lambda:\n", file = FS);
	   cat("count\tlambda\tSSR\tRMS\n", file = FS);

	   nlambda = length(cv$aLambda);

	   for (i in 1:nlambda) {
	      #xxx line = paste(c(i, cv$aLambda[i], cv$aSSR[i], cv$aRMS[i]), collapse = "\t");
	      line = sprintf("%d\t%10.3e\t%10.3e\t%10.3e\n", i, cv$aLambda[i], cv$aSSR[i], cv$aRMS[i]);
 	      cat(line, file = FS);	      
	   }
	}
	# .............................................................................
	# . Add predicted/observed dat (temporary):
	# .............................................................................
	nr = nrow(cv$yInOut);

	cat("\n", file = FS);
	cat("\n", file = FS);

 	cat("\#PREDICTED VERSUS OBSERVED VALUES OF y:\n", file = FS);
        cat("count\tyIn\tyOut\n", file = FS);
	
	for (i in 1:nr) {
           line = sprintf("%d\t%10.3e\t%10.3e\n", i, cv$yInOut[i,1], cv$yInOut[i,2]);
 	   cat(line, file = FS);	      
	}
	# .............................................................................



	# .............................................................................
	close(FS);
      	cat(" ..........  Regression statistics written to file : ", inparam$fs, "\n");
   	# .............................................................................


	# .....................
	return (0);
	# .....................

}

# ======================================================================================
# . End of CVReg.loop.outputStats.
# ======================================================================================