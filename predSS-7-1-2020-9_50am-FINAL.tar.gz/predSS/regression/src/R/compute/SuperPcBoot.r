# =================================================================================================
# . SuperPcBoot.r : bootstrap-focused functions for analysis of Cox model results.
# . -------------   
#.
# =================================================================================================

library(survival);

# =======================================================================================================
# . SuperPcBoot.computeCoxWithCovSignificanceOnSplit : bootstraps using function
# . ------------------------------------------------   SuperPc.computeCoxWithCovSignificanceOnSplit.
# .
# . Two types of resampling are implemented here :
# .
# .        1) bootstrap :   all samples are resampled with replacement. This simulates
# .                         estimation with a series of new data sets all chosen from the same
# .                         distribution as the inpute data.
# .                         This is typically used to establish confidence intervals 
# .                         on the estimated quantities.
# .
# .        2) permutation : the gene-expression expression attributes (log-hazards)
# .                         are randomly shuffled with respect to the (time, censoring, covariate)
# .                         triplets. This generates statistics of estimators under the null
# .                         hypothesis of no relation between gene expression data and survival
# .                         variables.
# .                         This is typically used to compute a P-value for quantifying
# .                         the significance of the estimates on the actual data set.
# .
# .
# . The resampling mode used is determined by the parameter 'resamplingType' (see description below).
# .
# ..........................................................................................................
# .
# . Given a set of log-hazard-ratios, generated from cross-validation or from direct model estimation,
# . this function does bootstrap resampling of the set. Using the given survival times, censoring statuses,
# . and external covariate values, for each sample it establishes:
# .
# .        i) a sensitive subset defined by DloghR < hRC, where hRC = threshold.
# .
# .       ii) for the sensitive subset generates and saves hazard ratio, P-values, and fraction of patients in set.
# .
# . The resampling functions in two modes:
# .
# .      internal = for each sample, generate the threshold hRC de novo by requiring that the P-value for the sensitive subset
# .                 is extremized. This mode is to be used if the input log-hazard ratios are cross-validated on
# .                 a training set: we are establshing confidence interval for the model parameters.
# .
# .      external = the threshold hRC is imposed externally. This mode is to be used in the validation phase, with
# .                 hRC already established by cross-validation on a separate training set.
# . 
# .......................................................................................................
# .   Syntax:
# .
# .       bs = SuperPcBoot.computeCoxWithCovSignificanceOnSplit(at, as, az,
# .                                                             aloghR,
# .                                                             aloghR0,
# .                                                             aloghR1,
# .                                                             flaghRC,
# .                                                             hRCExt,
# .                                                             nboot,
# .                                                             rngSeed,
# .                                                             resamplingType);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .            az = n : vector of external covariates. Values of z must be binary,
# .                     z in {0, 1}. An internal check is performed and an exception
# .                     occurs if there are non-binary values.
# .
# .        aloghR = n : vector of log-hazard-ratios, as predicted by the Cox model
# .                     for the *actual* values of the external covariate.
# .       aloghR0 = n : vector of log-hazard-ratios, as predicted by the Cox model
# .                     for the all values of the external covariate set to z = 0
# .                     (log-hazard-ratios predicted for baseline treatment).
# .       aloghR1 = n : vector of log-hazard-ratios, as predicted by the Cox model
# .                     for the all values of the external covariate set to z = 1
# .                     (log-hazard-ratios predicted for new treatment).
# .
# .      flaghRC = internal/external : mode of thresholding for defining sensitive subsets.
# .                Description:
# .
# .                internal : hRC is optimized independently for each sample. This option is to be
# .                           used on cross-validated log-hazard-ratios in the process of optimizing
# .                           tuning parameters with a training set.
# .                external : hRC = hRCExt is imposed externally. This is to be used in the validation
# .                           phase, with the log-hazard-ratios determined by prediction with the
# .                           independently trained model.
# .
# .       hRCExt = externally imposed value of hRC. Used whene flaghRC = external, ignored when flaghRC = internal.
# .                (but in both cases, we must have hRCExt > 0).
# .
# .        nboot = number of bootstrap resamplings to be used; nboot >= 5.
# .      rngSeed = random number seed.
# .
# .   Out:
# .
# =======================================================================================================

SuperPcBoot.computeCoxWithCovSignificanceOnSplit <- function(at, as, az, aloghR, aloghR0, aloghR1,
                                                             flaghRC, hRCExt, nboot, rngSeed,
                                                             resamplingType)
{

      # ................................................................................
      cat(" ..........  Entry in SuperPcBoot.computeCoxWithCovSignificanceOnSplit.\n");
      # ................................................................................



      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nz = length(az);      # Number of samples in external covariate vector.
      
      nl = length(aloghR);  # Number of samples in log-hazard-ratio vector.
      nl0 = length(aloghR0);  # Number of samples in log-hazard-ratio vector for z = 0.
      nl1 = length(aloghR1);  # Number of samples in log-hazard-ratio vector for z = 1.

      if (ns != n) {
        msg = "ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      
      if (nl != n) {
        msg = "ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR has nl = ", nl, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl0 != n) {
        msg = "ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR0 has nl0 = ", nl0, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl1 != n) {
        msg = "ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR1 has nl1 = ", nl1, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }            
      # ...............................................................................................


      
      # ...............................................................................................
      # . Checks on input parameters :
      # ...............................................................................................      
      msg = Cox.checkBinary(az);

      if (msg != 'ok') {
        cat("ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit:\n");
        cat(msg, "\n", sep = "");
        stop();
      }

      if (nboot < 5) {
        cat("ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit:\n");
        cat("nboot = ", nboot, " is less than 5. Valid nboot >= 5\n", sep = "");
        stop();
      }

      if ((flaghRC != 'internal') && (flaghRC != 'external')) {
        cat("ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit:\n");
        cat("flaghRC = ", flaghRC, " is not valid. Valid: internal, external\n", sep = "");
        stop();
      }

      if (hRCExt <= 0) {
        cat("ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit:\n");
        cat("hRCExt = ", hRCExt, " is not valid. Valid: hRCExt > 0.\n", sep = "");
        stop();
      }

      if ((resamplingType != 'bootstrap') && (resamplingType != 'permutation')) {
        cat("ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnSplit:\n");
        cat("resamplingType = ", resamplingType, " is not valid. Valid: bootstrap, permutation\n", sep = "");
        stop();
      }
      # ...............................................................................................

      

      # .........................................
      # . Initialize random number generator :
      # .........................................      
      set.seed(rngSeed);                  
      # .........................................
 


      # ...............................................................................................
      # . Generate results for unresampled data set :
      # ...............................................................................................
      if (flaghRC == 'internal') {
        cCov = SuperPc.computeCoxWithCovSignificanceOnSplit(at, as, az,
                                                            aloghR, aloghR0, aloghR1,
                                                            flagComputeRES = TRUE);
      } else if (flaghRC == 'external') {
        cCov = SuperPc.computeCoxWithCovSignificanceOnSplitEXT(at, as, az,
                                                               aloghR, aloghR0, aloghR1,
                                                               hRCExt,
                                                               flagComputeRES = TRUE);        
      }

      hRAll_base = cCov$csAll$hR;             # Hazard ratio for all patients.
      hRC_base = cCov$hRC;                    # Threshold for differential log-hazard.
      hRMin_base = cCov$hRMin;                # Hazard ratio at optimal split.
      pRMin_base = cCov$pRMin;                # P-value at optimal split.
      icMin_base = cCov$icMin;                # Number of items selected at otpimal split.
      SMin_base = cCov$icMin / n;             # Fraction of patients selected at optimal split.
      qRatio_base= hRMin_base / hRAll_base;   # Reduction in hazard ratio, optimal split relative to all patients.

      pModel_base = cCov$cModel$pR;             # P-value for Surv ~ Z + DloghR + Z * DloghR model.
      betaZModel_base = cCov$cModel$betaZ;      # betaZ for the model (Z).
      betaModel_base = cCov$cModel$abeta[1];    # beta for the model (DloghR)
      gammaModel_base = cCov$cModel$agamma[1];  # gamma for the model (interaction).
      # ...............................................................................................

      

      # ...............................................................................
      if (resamplingType == 'bootstrap') {
        cat(" ..........  Begin bootstrap computation, nboot = ", nboot, "\n", sep = "");
      } else if (resamplingType == 'permutation') {
        cat(" ..........  Begin permutation computation, nperm = ", nboot, "\n", sep = "");
      }
      # ...............................................................................

      

      # ...............................................................................................
      # . MAIN RESAMPLING LOOP :
      # ...............................................................................................
      index0 = 1:n;

      aboot_hRAll = c();     # Array of bootstrapped values for hR for all patients.
      aboot_hRC = c();       # Array of bootstrapped differential log-hazard threshold values.
      aboot_hRMin = c();     # Array of bootstrapped values of hRMin, optimal hazard ratio.
      aboot_pRMin = c();     # Array of bootstrapped values of pRMin, optimal P-value.
      aboot_SMin = c();      # Array of bootstrapped values of SMin, fraction of patients under optimal split.
      aboot_qRatio = c();    # Array of hR reductions, hRMin / hRAll.

      for (l in 1:nboot) {
        # ......................................................................................
        # . >>BOOTSTRAP: resample with replacement. All features remain together.
        # . We are simulating a new data set from the same distribution as the input data set.
        # ......................................................................................
        if (resamplingType == 'bootstrap') {
          indexBuf = sample(index0, replace = TRUE);   # Sampling with replacement.
          
          atBuf = at[indexBuf];
          asBuf = as[indexBuf];
          azBuf = az[indexBuf];
          aloghRBuf = aloghR[indexBuf];
          aloghR0Buf = aloghR0[indexBuf];
          aloghR1Buf = aloghR1[indexBuf];
        }
        # ......................................................................................        
        # . >>PERMUTATION: generate a permutation index. Coordinatedly shuffle log-hazards
        # . but keep survival and external co-variate in-place.
        # . We are simulating a data set under the null hypothesis of no association between
        # . survival and gene-expression.
        # ......................................................................................
        if (resamplingType == 'permutation') {
          indexBuf = sample(index0);                   # Permutation.
          
          atBuf = at;
          asBuf = as;
          azBuf = az;
          aloghRBuf = aloghR[indexBuf];
          aloghR0Buf = aloghR0[indexBuf];
          aloghR1Buf = aloghR1[indexBuf];
        }        
        # ......................................................................................
        # . Generate the optimal split for this sample, or use the external threshold, 
        # . depending on thresholding mode :
        # ......................................................................................
        if (flaghRC == 'internal') {
          cCov = SuperPc.computeCoxWithCovSignificanceOnSplit(atBuf, asBuf, azBuf,
                                                              aloghRBuf, aloghR0Buf, aloghR1Buf,
                                                              flagComputeRES = FALSE);          
        } else if (flaghRC == 'external') {
          cCov = SuperPc.computeCoxWithCovSignificanceOnSplitEXT(atBuf, asBuf, azBuf,
                                                                 aloghRBuf, aloghR0Buf, aloghR1Buf,
                                                                 hRCExt,
                                                                 flagComputeRES = FALSE);          
        }
        # ......................................................................................
        # . Retrieve values :
        # ......................................................................................
        hRAll = cCov$csAll$hR;      # Hazard ratio for all patients.
        hRC = cCov$hRC;             # Threshold on differential log-hazard.
        hRMin = cCov$hRMin;         # Hazard ratio at optimal split.
        pRMin = cCov$pRMin;         # P-value at optimal split.
        icMin = cCov$icMin;         # Number of items selected at otpimal split.
        SMin = icMin / n;           # Fraction of patients selected at optimal split.
        qRatio = hRMin / hRAll;     # Reduction in hazard ratio, optimal split relative to all patients.

        aboot_hRAll = c(aboot_hRAll, hRAll);
        aboot_hRC = c(aboot_hRC, hRC);        
        aboot_hRMin = c(aboot_hRMin, hRMin);
        aboot_pRMin = c(aboot_pRMin, pRMin);
        aboot_SMin = c(aboot_SMin, SMin);
        aboot_qRatio = c(aboot_qRatio, qRatio);        
        # ......................................................................................
        # . Indicate progress :
        # ......................................................................................
        cat(".");
        
        if (l%%50 == 0) {
          cat("Processed ", l, " steps out of ", nboot, "\n", sep = "");
        }
        # ......................................................................................        
      }

      cat("\n");
      # ...............................................................................................


      
      # .............................................................
      cat(" ..........  Bootstrap computation done.\n", sep = "");
      # .............................................................


      
      # ...............................................................................................
      # . Generate statistics :
      # ...............................................................................................
      hRAllLo = quantile(aboot_hRAll, probs = 0.025);
      hRAll = median(aboot_hRAll);
      hRAllHi = quantile(aboot_hRAll, probs = 0.975);
              
      hRCLo = quantile(aboot_hRC, probs = 0.025);
      hRC = median(aboot_hRC);
      hRCHi = quantile(aboot_hRC, probs = 0.975);      
              
      hRMinLo = quantile(aboot_hRMin, probs = 0.025);
      hRMin = median(aboot_hRMin);
      hRMinHi = quantile(aboot_hRMin, probs = 0.975);      
              
      pRMinLo = quantile(aboot_pRMin, probs = 0.025);
      pRMin = median(aboot_pRMin);
      pRMinHi = quantile(aboot_pRMin, probs = 0.975);
              
      SMinLo = quantile(aboot_SMin, probs = 0.025);
      SMin = median(aboot_SMin);
      SMinHi = quantile(aboot_SMin, probs = 0.975);
              
      qRatioLo = quantile(aboot_qRatio, probs = 0.025);
      qRatio = median(aboot_qRatio);
      qRatioHi = quantile(aboot_qRatio, probs = 0.975);
      # ..............................................................................................
      # . pge1_qRatio = Prob(qRatio >= 1)
      # .               relevant to BOOTSTRAP resampling.
      # .               pge1_qRatio = 1 - {confidence that we are reducing risk in the sensitive subset}
      # ..............................................................................................
      npge1 = length(which(aboot_qRatio >= 1.0));                    # Number for which qRatio >= 1.
      theta = Stat.probabilityOnCountBayes(k = npge1 , n = nboot);   # Bayesian estimates.

      pge1_qRatioLo = theta$pLo;                                     # Lower bound on CI.
      pge1_qRatio = theta$p;                                         # Median estimator. 
      pge1_qRatioHi = theta$pHi;                                     # Upper bound on CI.
      # ..............................................................................................
      # . pval_qRatio = Prob(qRatio < qRatio_base)
      # .               relevant to PERMUTATION resampling.
      # .               One-sided P-value for testing whether the reduction in risk oberved in the
      # .               input data set is statistically 
      # ..............................................................................................      
      npval = length(which(aboot_qRatio < qRatio_base));              # Number for which qRatio < qRatio_base.

      theta = Stat.probabilityOnCountBayes(k = npval , n = nboot);    # Bayesian estimates.

      pval_qRatioLo = theta$pLo;                                      # Lower bound on CI.
      pval_qRatio = theta$p;                                          # Median estimator. 
      pval_qRatioHi = theta$pHi;                                      # Upper bound on CI.
      # ...............................................................................................

      


      # ...............................................................................................
      # . Package all output in a list :
      # . Save parameters, output arrays, and summary statistics.
      # ...............................................................................................
      bs = list(nboot = nboot,
                rngSeed = rngSeed,
                flaghRC = flaghRC,
                hRCExt = hRCExt,
                resamplingType = resamplingType,

                hRAll_base =  hRAll_base,
                hRC_base = hRC_base,   
                hRMin_base = hRMin_base,
                pRMin_base = pRMin_base,
                SMin_base = SMin_base,
                qRatio_base = qRatio_base,
        
                aboot_hRAll = aboot_hRAll, 
                aboot_hRC = aboot_hRC, 
                aboot_hRMin = aboot_hRMin,
                aboot_pRMin = aboot_pRMin,
                aboot_SMin = aboot_SMin,
                aboot_qRatio = aboot_qRatio,
        
                hRAllLo = hRAllLo,
                hRAll = hRAll,  
                hRAllHi = hRAllHi,
                                    
                hRCLo =   hRCLo,  
                hRC = hRC,    
                hRCHi = hRCHi,
                                    
                hRMinLo = hRMinLo,
                hRMin = hRMin,  
                hRMinHi = hRMinHi,
                                    
                pRMinLo = pRMinLo,
                pRMin = pRMin,
                pRMinHi = pRMinHi,
                                    
                SMinLo =  SMinLo,  
                SMin = SMin,   
                SMinHi = SMinHi,
                                    
                qRatioLo = qRatioLo,
                qRatio = qRatio, 
                qRatioHi = qRatioHi,

                npge1 = npge1,
                pge1_qRatioLo = pge1_qRatioLo,
                pge1_qRatio = pge1_qRatio,
                pge1_qRatioHi = pge1_qRatioHi,

                npval = npval,
                pval_qRatioLo = pval_qRatioLo,        
                pval_qRatio = pval_qRatio,
                pval_qRatioHi = pval_qRatioHi
        );

      class(bs) = "spc.cox.cov.boot";
      # ...............................................................................................            



      # ............
      return (bs);
      # ............

  
}

# =======================================================================================================
# . End of SuperPcBoot.computeCoxWithCovSignificanceOnSplit.
# =======================================================================================================




# =======================================================================================================
# . SuperPcBoot.permuteOnProgIndex : estimates significance of association between a predicted
# . ------------------------------   prognostic index (= loghR) and the observed survival times by applying
# .                                  a permutation test.
# .
# . Syntax:
# .           pg = SuperPcBoot.permuteOnProgIndex(at, as, aloghR, nperm, rngSeed);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .        aloghR = n : vector of log-hazard-ratios, derived from cross-validation
# .                     on the same data set, or from estimation on a separate training set.
# .
# .        nperm = number of permutation resamplings to be used; nperm >= 5.
# .      rngSeed = random number seed.
# .                     
# . Out:
# .    
# .......................................................................................................
# . Details :
# .
# . * One type of resampling is implemented here :
# .
# .           permutation : the gene-expression expression attributes (log-hazard = prognostic index, xi)
# .                         are randomly shuffled with respect to the (time, censoring) pairs,
# .                         and the log-likelihood l(xi) computed each time.
# .                         This generates statistics of l(xi) under the null
# .                         hypothesis of no relation between gene expression data and survival
# .                         variables. A one-sided P-value is then computed, based on the actual
# .                         observed value of l(xi).
# .                         This is typically used to compute a P-value for quantifying
# .                         the significance of the estimates on the actual data set.
# .
# .
# . * The log-likelihood is given by :
# .
# .                    n
# .         l(xi) =   sum   d  . (xi   -  log(   sum    exp(xi )  ))
# .                  i = 1   i      i          j in R(i)      j
# .
# .    where d_i = censoring indicator (d_i = 1, for death, 0 for censored information),
# .    xi_i = prognostic index = log-hazard-ratio for i-th individual, and R(i) = risk set
# .    at time t_i-.
# .
# .
# . * Schematically, the prognostic indices xi_i can be given by:
# .
# .               _
# .               |
# .               |  beta    .  x    , cross-validated log-hazard ratios.
# .               |      (-i)    i
# .        xi   = |
# .          i    |
# .               |  beta . x  ,       beta derived from an independent training set.
# .               |      i
# .               -
# .
# ==========================================================================================================

SuperPcBoot.permuteOnProgIndex <- function(at, as, aloghR, nperm, rngSeed)
{

  
      # ...............................................................
      cat(" ..........  Entry in SuperPcBoot.permuteOnProgIndex.\n");
      # ...............................................................



      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nl = length(aloghR);  # Number of samples in log-hazard-ratio vector.

      if (ns != n) {
        msg = "ERROR: from SuperPcBoot.permuteOnProgIndex: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      
      if (nl != n) {
        msg = "ERROR: from SuperPcBoot.permuteOnProgIndex: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR has nl = ", nl, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      # ...............................................................................................


      
      # ............................................................................
      # . Checks on input parameters :
      # ............................................................................
      if (nperm < 5) {
        cat("ERROR: from SuperPcBoot.permuteOnProgIndex:\n");
        cat("nperm = ", nperm, " is less than 5. Valid nperm >= 5\n", sep = "");
        stop();
      }
      # ............................................................................

      

      # .........................................
      # . Initialize random number generator :
      # .........................................      
      set.seed(rngSeed);                  
      # .........................................

      

      # .....................................................................................
      # . Generate results for UNRESAMPLED data set : calibration values.
      # . >> Compute beta de novo : here we allow for beta != 1.
      # . This can be considered a ``calibration'' step.
      # .....................................................................................
      coxK = coxph(Surv(at, as) ~ aloghR);           # Cox model on one covariate. Optimize beta.

      qR = 2.0 * (coxK$loglik[2] - coxK$loglik[1]);        # Likelihood ratio statistic.
      pR_calib = pchisq(qR, df = 1, lower.tail = FALSE);   # p-value from likelihood ratio.
      
      coxKsum = summary(coxK);
      coxKcoef = coxKsum$coef;                   # Contains the coefficient and P-value.

      loglik_calib = coxK$loglik[2];             # Log-likelihood at calibrated beta.
      beta_calib = coxKcoef[ , 1];               # The Cox coefficient.
      seBeta_calib = coxKcoef[ , 3];             # Standard errors for the coefficient.
      pval_calib = coxKcoef[ , 5];               # The corresponding P-value.
      # .....................................................................................      


      

      # ....................................................................................
      # . Generate results for UNRESAMPLED data set: baseline values.
      # .
      # . >> Compute the log-likelihood on the basis of the formula :
      # .
      # .                    n
      # .         l(xi) =   sum   d  . (xi   -  log(   sum    exp(xi )  ))
      # .                  i = 1   i      i          j in R(i)      j
      # .        
      # . We call the coxph() function, with xi as covariate, with initial beta = 1
      # . and with no iterations.
      # .....................................................................................
      coxBuf = coxph(Surv(at, as) ~ aloghR,
                     init = 1.0,                               # beta = 1.
                     control = coxph.control(iter.max = 0));   # No iterations.

      loglik_base = coxBuf$loglik[1];
      # .....................................................................................



      
      # ...............................................................................
      cat(" ..........  Begin permutation computation, nperm = ", nperm, "\n", sep = "");
      # ...............................................................................

     
      

      # ...............................................................................................
      # . MAIN RESAMPLING LOOP :
      # ...............................................................................................
      index0 = 1:n;
      aboot_loglik = c();    # Array of resampled values for the log-likelihood.

      for (l in 1:nperm) {
        # ......................................................................................        
        # . >>PERMUTATION: generate a permutation index. Coordinatedly shuffle log-hazards
        # . but keep survival and external co-variate in-place.
        # . We are simulating a data set under the null hypothesis of no association between
        # . survival and gene-expression.
        # ......................................................................................
        indexBuf = sample(index0);                   # Permutation.
          
        atBuf = at;                                  # Not permuted.
        asBuf = as;                                  # Not permuted.
        aloghRBuf = aloghR[indexBuf];                # Only the log-hazard ratio is permuted.
        # ......................................................................................
        # . Compute the log-likelihood on the basis of the formula :
        # .
        # .                    n
        # .         l(xi) =   sum   d  . (xi   -  log(   sum    exp(xi )  ))
        # .                  i = 1   i      i          j in R(i)      j
        # .        
        # . We call the coxph() function, with xi as covaraite, with initial beta = 1
        # . and with no iterations.
        # ......................................................................................
        coxBuf = coxph(Surv(atBuf, asBuf) ~ aloghRBuf,
                       init = 1.0,                               # beta = 1.
                       control = coxph.control(iter.max = 0));   # No iterations.

        loglik = coxBuf$loglik[1];
        # ......................................................................................
        # . Store value :
        # ......................................................................................
        aboot_loglik = c(aboot_loglik, loglik);
        # ......................................................................................
        # . Indicate progress :
        # ......................................................................................
        if (l%%50 == 0) {
          cat(".");
        }
        
        if (l%%500 == 0) {
          cat("Processed ", l, " steps out of ", nperm, "\n", sep = "");
        }
        # ......................................................................................        
      }

      cat("\n");
      # ...............................................................................................


      
      # .............................................................
      cat(" ..........  Permutation computation done.\n", sep = "");
      # .............................................................
      


      
      # ...............................................................................................
      # . Generate statistics.
      # . >> Summary statistics :
      # ...............................................................................................
      loglikLo = quantile(aboot_loglik, probs = 0.025);
      loglikMed = median(aboot_loglik);
      loglikHi= quantile(aboot_loglik, probs = 0.975);
      # ..............................................................................................
      # . >> P-value :
      # . pval_loglik = Prob(loglik > loglik_base). One-sided P-value.
      # ..............................................................................................      
      npval = length(which(aboot_loglik > loglik_base));              # Number loglik* > loglik observed.

      theta = Stat.probabilityOnCountBayes(k = npval , n = nperm);    # Bayesian estimates.

      pval_loglikLo = theta$pLo;                                      # Lower 0.025 bound on CI.
      pval_loglik = theta$p;                                          # Median estimator. 
      pval_loglikHi = theta$pHi;                                      # Upper 0.975 bound on CI.
      # ...............................................................................................
      

      
      # ......................................................................................
      # . >> Add a simpler test:
      # . Compute the significance of split on lower and upper tertiles of the log-hazard-ratio:
      # ......................................................................................          
      cs = SuperPc.computeCoxSignificanceOnSplitLoghRQUANT(at, as, aloghR, nq = 3);
      # ......................................................................................        


      

      # ...............................................................................................
      # . Package all output in a list :
      # . Save parameters, output arrays, and summary statistics.
      # ...............................................................................................
      pg = list(n = n,                              # Number of samples.
                nperm = nperm,                      # Number of permutations.
                rngSeed = rngSeed,                  # Random number seed used.

                loglik_calib = loglik_calib,        # Loglikelihood at calibrated beta.
                pR_calib = pR_calib,                # Model p-value for calibrated beta.
                beta_calib = beta_calib,            # Calibrated beta.
                seBeta_calib = seBeta_calib,        # Standard error for beta.
                pval_calib = pval_calib,            # P-value for calibrated beta.
        
                loglik_base =  loglik_base,         # Baseline log-likelihood.
        
                aboot_loglik = aboot_loglik,        # Array of resampled values (loglik*, null hypothesis).
                loglikLo = loglikLo,                # 0.025 quantile for loglik*.
                loglikMed = loglikMed,              # median for loglik*.
                loglikHi = loglikHi,                # 0.975 quantile for loglik*.
                                    
                npval = npval,                      # Count of times loglik* > loglik_base
                pval_loglikLo = pval_loglikLo,      # Corresponding estimates of p-value,
                pval_loglik = pval_loglik,          # with 95% confidence interval
                pval_loglikHi = pval_loglikHi,      # bounds.

                pval_tertile = cs$pR,               # ``Poor man's'' p-value, based on tertile comparison.
                hR_tertile = cs$hR                  # ``Poor man's'' hR, based on tertile comparison.
        );

      class(pg) = "spc.cox.perm";
      # ...............................................................................................            


      # ............
      return (pg);
      # ............
  
}

# =======================================================================================================
# . End of SuperPcBoot.permuteOnProgIndex.
# =======================================================================================================





# =======================================================================================================
# . SuperPcBoot.permuteOnProgIndexALLCov :  for binary external covariate, runs permutation tests on the
# . ------------------------------------    prognostic models, to establish significance of fit to data.
# .
# . Syntax:
# .           pg = SuperPcBoot.permuteOnProgIndex(at, as, az, aloghR, nperm, rngSeed);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .            az = n : vector of binary external covaraite (0, 1).
# .        aloghR = n : vector of log-hazard-ratios, derived from cross-validation
# .                     on the same data set, or from estimation on a separate training set.
# .
# .        nperm = number of permutation resamplings to be used; nperm >= 5.
# .      rngSeed = random number seed.
# .                     
# . Out:
# .
# .......................................................................................................
# . Details:
# .
# .    * Simply runs the resampling calculation SuperPcBoot.permuteOnProgIndex() separately on:
# .
# .          i) all the data.
# .          ii) Z = 0 data.
# .          iii) Z = 1 data.
# .
# . generating a P-value for each in turn, and then packages the final results.
# .
# =======================================================================================================

SuperPcBoot.permuteOnProgIndexALLCov <- function(at, as, az, aloghR,
                                                 nperm, rngSeed)
{
  
      # ....................................................................
      cat(" ..........  Entry in SuperPcBoot.permuteOnProgIndexALLCov.\n");
      # ....................................................................



      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nz = length(az);      # Number of samples in censoring status vector.      
      nl = length(aloghR);  # Number of samples in log-hazard-ratio vector.

      if (ns != n) {
        msg = "ERROR: from SuperPcBoot.permuteOnProgIndexALLCov: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      
      if (nz != n) {
        msg = "ERROR: from SuperPcBoot.permuteOnProgIndexALLCov: ";
        msg = paste(msg, "The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nl != n) {
        msg = "ERROR: from SuperPcBoot.permuteOnProgIndexALLCov: ";
        msg = paste(msg, "The log-hazard-ratio vector aloghR has nl = ", nl, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      # ...............................................................................................


      
      # ............................................................................
      # . Checks on input parameters :
      # ............................................................................
      if (nperm < 5) {
        cat("ERROR: from SuperPcBoot.permuteOnProgIndexALLCov:\n");
        cat("nperm = ", nperm, " is less than 5. Valid nperm >= 5\n", sep = "");
        stop();
      }

      msg = Cox.checkBinary(az);

      if (msg != 'ok') {
        cat("ERROR: from SuperPcBoot.permuteOnProgIndexALLCov:\n");        
        cat(msg, "\n", sep = "");
        stop();
      }
      # ............................................................................


      # ............................................................................
      # . Generate subsets :
      # ............................................................................
      n0 = length(az[az == 0]);
      n1 = length(az[az == 1]);

      if (n0 > 0) {
        at0 = at[az == 0];
        as0 = as[az == 0];
        aloghR0 = aloghR[az == 0];                 
      }

      if (n1 > 0) {
        at1 = at[az == 1];
        as1 = as[az == 1];
        aloghR1 = aloghR[az == 1];                 
      }      
      # ............................................................................      

      

      # ......................................................................................
      # . Do the permutation tests :
      # ......................................................................................
      cat(" ..........  Permutation test for prognostic estimates : All patients.\n");
      pgAll = SuperPcBoot.permuteOnProgIndex(at, as, aloghR, nperm = nperm, rngSeed = rngSeed);

      if (n0 == 0) {
        pg0 = NULL;
      } else if (n0 < n) {
        cat(" ..........  Permutation test for prognostic estimates : Z = 0 patients.\n");        
        pg0 = SuperPcBoot.permuteOnProgIndex(at0, as0, aloghR0, nperm = nperm, rngSeed = rngSeed);
      } else {
        pg0 = pgAll;     # Since it is the same data set.
      }

      if (n1 == 0) {
        pg1 = NULL;
      } else if (n1 < n) {
        cat(" ..........  Permutation test for prognostic estimates : Z = 1 patients.\n");                
        pg1 = SuperPcBoot.permuteOnProgIndex(at1, as1, aloghR1, nperm = nperm, rngSeed = rngSeed);
      } else {
        pg1 = pgAll;     # Since it is the same data set.
      }
      # ......................................................................................


      # ...........................................
      # . Package results :
      # ...........................................
      pgALLCov = list(n = n,
                      n0 = n0,
                      n1 = n1,
                      nperm = nperm,
                      rngSeed = rngSeed,
                      pgAll = pgAll,
                      pg0 = pg0,
                      pg1 = pg1);

      class(pgALLCov) = "spc.cox.perm.ALL";      
      # ...........................................


      # .................
      return (pgALLCov);
      # .................
  
}

# =======================================================================================================
# . End of SuperPcBoot.permuteOnProgIndexALLCov.
# =======================================================================================================




# =======================================================================================================
# . SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit : does a bootstrap or permutation test
# . -----------------------------------------------------   to find significance of a binary split
# .                                                         on two subsets.
# .
# . Two types of resampling are implemented here :
# .
# .        1) bootstrap :   all samples are resampled with replacement. This simulates
# .                         estimation with a series of new data sets all chosen from the same
# .                         distribution as the inpute data.
# .                         This is typically used to establish confidence intervals 
# .                         on the estimated quantities.
# .
# .        2) permutation : the {0, 1} subset assignments
# .                         are randomly shuffled with respect to the (time, censoring, covariate)
# .                         triplets. This generates statistics of estimators under the null
# .                         hypothesis of no relation between subset membership and survival
# .                         variables.
# .                         This is typically used to compute a P-value for quantifying
# .                         the significance of the estimates on the actual data set.
# .
# .
# . The resampling mode used is determined by the parameter 'resamplingType' (see description below).
# .
# .......................................................................................................
# .   Syntax:
# .
# .       bs = SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit(at, as, az, ar,
# .                                                                  nresamp,
# .                                                                  rngSeed,
# .                                                                  resamplingType);
# .
# .   In:
# .            at = n : vector of survival times (n = number of samples).
# .
# .            as = n : vector of censoring statuses (1 = not censored, 0 = censored).
# .
# .            az = n : vector of external covariates. Values of z must be binary,
# .                     z in {0, 1}. An internal check is performed and an exception
# .                     occurs if there are non-binary values.
# .
# .            ar = n : vector of subset assignments. Values of r must be binary,
# .                     r in {0, 1}. An internal check is performed and an exception
# .                     occurs if there are non-binary values.
# .
# .           nresamp = number of bootstrap resamplings to be used; nresamp >= 5.
# .
# .           rngSeed = random number seed.
# .
# .......................................................................................................
# .  >> NOTE: by convention, the subset with r = 1 is assumed to contain the ``sensitive'' patients,
# .           and the subset with r = 0 to contain the ``resistant'' patients.
# .           We thus want to do the one-sided tests :
# .
# .                   hR1 < hRall
# .                   hR0 > hRall
# .                   hR1 < hR0
# .
# =======================================================================================================

SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit <- function(at, as, az, ar, nresamp, rngSeed, resamplingType)
{

      # ...................................................................................
      cat(" ..........  Entry in SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit.\n");
      # ...................................................................................



      # ......................................................................................        
      # . Catch inconsistencies in specification of input arrays or parameters.
      # ......................................................................................  
      n = length(at);       # Number of samples in survival time vector.
      ns = length(as);      # Number of samples in censoring status vector.
      nz = length(az);      # Number of samples in external covariate vector.
      nr = length(ar);      # Number of samples in subset assignment vector.
      
      if (ns != n) {
        msg = "ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit: ";
        msg = paste(msg, "The censoring status vector as has ns = ", ns, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }

      if (nz != n) {
        msg = "ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit: ";
        msg = paste(msg, "The external covariate vector az has nz = ", nz, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      
      if (nr != n) {
        msg = "ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit: ";
        msg = paste(msg, "The subset vector ar has nr = ", nr, "samples. ", sep = "");
        msg = paste(msg, "This is not the same as the n = ", n, "samples in the time vector at.", sep = "");      
        stop(msg);
      }
      # ...............................................................................................


      
      # ...............................................................................................
      # . Checks on input parameters :
      # ...............................................................................................      
      msg = Cox.checkBinary(az);

      if (msg != 'ok') {
        cat("ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit:\n");
        cat("az has non 0, 1 values.\n");
        cat(msg, "\n", sep = "");
        stop();
      }

      msg = Cox.checkBinary(ar);

      if (msg != 'ok') {
        cat("ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit:\n");
        cat("ar has non 0, 1 values.\n");        
        cat(msg, "\n", sep = "");
        stop();
      }
      
      if (nresamp < 5) {
        cat("ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit:\n");
        cat("nresamp = ", nresamp, " is less than 5. Valid nresamp >= 5\n", sep = "");
        stop();
      }

      if ((resamplingType != 'bootstrap') && (resamplingType != 'permutation')) {
        cat("ERROR: from SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit:\n");
        cat("resamplingType = ", resamplingType, " is not valid. Valid: bootstrap, permutation\n", sep = "");
        stop();
      }
      # ...............................................................................................

      

      # .........................................
      # . Initialize random number generator :
      # .........................................      
      set.seed(rngSeed);                  
      # .........................................
 


      # ...............................................................................................
      # . Generate results for unresampled data set : these establish the baseline values.
      # . First extract times, censoring statuses and covariates for the two defined subsets :
      # ...............................................................................................
      at0 = at[ar == 0];
      as0 = as[ar == 0];  
      az0 = az[ar == 0];

      at1 = at[ar == 1];
      as1 = as[ar == 1];  
      az1 = az[ar == 1];                  
      # ...............................................................................................
      # . Compute a Cox model for each subset and all samples :
      # ...............................................................................................
      cs = Cox.computeBinaryCox(at, as, az);      
      cs0 = Cox.computeBinaryCox(at0, as0, az0);
      cs1 = Cox.computeBinaryCox(at1, as1, az1);      

      hRall_base = cs$hR;                      # Hazard ratio for all patients.
      hR0_base = cs0$hR;                       # Hazard ratio for subset 0.
      hR1_base = cs1$hR;                       # Hazard ratio for subset 1.

      pRall_base = cs$pR;                      # P-value for all patients.
      pR0_base = cs0$pR;                       # P-value for subset 0.
      pR1_base = cs1$pR;                       # P-value for subset 1.      
      
      q0_all_base= hR0_base / hRall_base;      # Relative hazard ratio, subset 0 relative to all patients.
      q1_all_base= hR1_base / hRall_base;      # Relative hazard ratio, subset 1 relative to all patients.
      q1_0_base= hR1_base / hR0_base;          # Relative hazard ratio, subset 1 relative to subset 0.
      # ...............................................................................................

      

      # ...............................................................................
      if (resamplingType == 'bootstrap') {
        cat(" ..........  Begin bootstrap computation, nresamp = ", nresamp, "\n", sep = "");
      } else if (resamplingType == 'permutation') {
        cat(" ..........  Begin permutation computation, nperm = ", nresamp, "\n", sep = "");
      }
      # ...............................................................................

      

      # ...............................................................................................
      # . MAIN RESAMPLING LOOP :
      # ...............................................................................................
      index0 = 1:n;

      aboot_hRall = c()      # Array of values for hR for all patients.
      aboot_hR0 = c();       # Array of values for hR for subset 0.
      aboot_hR1 = c();       # Array of values for hR for subset 1.

      aboot_pRall = c()      # Array of values for pR for all patients.
      aboot_pR0 = c();       # Array of values for pR for subset 0.
      aboot_pR1 = c();       # Array of values for pR for subset 1.      
      
      aboot_q0_all = c();    # Array of hR0 / hRall.
      aboot_q1_all = c();    # Array of hR1 / hRall.
      aboot_q1_0 = c();      # Array of hR1 / hR0.            

      for (l in 1:nresamp) {
        # ......................................................................................
        # . >>BOOTSTRAP: resample with replacement. All features remain together.
        # . We are simulating a new data set from the same distribution as the input data set.
        # ......................................................................................
        if (resamplingType == 'bootstrap') {
          indexBuf = sample(index0, replace = TRUE);   # Sampling with replacement.
          
          atBuf = at[indexBuf];
          asBuf = as[indexBuf];
          azBuf = az[indexBuf];
          arBuf = ar[indexBuf];          
        }
        # ......................................................................................        
        # . >>PERMUTATION: generate a permutation index. Coordinatedly shuffle log-hazards
        # . but keep survival and external co-variate in-place.
        # . We are simulating a data set under the null hypothesis of no association between
        # . survival and gene-expression.
        # ......................................................................................
        if (resamplingType == 'permutation') {
          indexBuf = sample(index0);                   # Permutation.
          
          atBuf = at;
          asBuf = as;
          azBuf = az;
          arBuf = ar[indexBuf];          
        }
        # ...............................................................................................        
        # . First extract times, censoring statuses and covariates for the two defined subsets :
        # ...............................................................................................
        atBuf0 = atBuf[arBuf == 0];
        asBuf0 = asBuf[arBuf == 0];  
        azBuf0 = azBuf[arBuf == 0];

        atBuf1 = atBuf[arBuf == 1];
        asBuf1 = asBuf[arBuf == 1];  
        azBuf1 = azBuf[arBuf == 1];                  
        # ...............................................................................................
        # . Compute a Cox model for each subset and all samples :
        # ...............................................................................................
        cs = Cox.computeBinaryCox(atBuf, asBuf, azBuf);      
        cs0 = Cox.computeBinaryCox(atBuf0, asBuf0, azBuf0);
        cs1 = Cox.computeBinaryCox(atBuf1, asBuf1, azBuf1);      

        hRall = cs$hR;                      # Hazard ratio for all patients.
        hR0 = cs0$hR;                       # Hazard ratio for subset 0.
        hR1 = cs1$hR;                       # Hazard ratio for subset 1.      

        pRall = cs$pR;                      # P-value for all patients.
        pR0 = cs0$pR;                       # P-value for subset 0.
        pR1 = cs1$pR;                       # P-value for subset 1.      
        
        q0_all= hR0 / hRall;                # Relative hazard ratio, subset 0 relative to all patients.
        q1_all= hR1 / hRall;                # Relative hazard ratio, subset 1 relative to all patients.
        q1_0= hR1 / hR0;                    # Relative hazard ratio, subset 1 relative to subset 0.
        # ......................................................................................
        # . Add to arrays :
        # ......................................................................................
        aboot_hRall = c(aboot_hRall, hRall)        # Array of values for hR for all patients.
        aboot_hR0 = c(aboot_hR0, hR0);             # Array of values for hR for subset 0.
        aboot_hR1 = c(aboot_hR1, hR1);             # Array of values for hR for subset 1.

        aboot_pRall = c(aboot_pRall, pRall)        # Array of values for pR for all patients.
        aboot_pR0 = c(aboot_pR0, pR0);             # Array of values for pR for subset 0.
        aboot_pR1 = c(aboot_pR1, pR1);             # Array of values for pR for subset 1.        

        aboot_q0_all = c(aboot_q0_all, q0_all);    # Array of hR0 / hRall.
        aboot_q1_all = c(aboot_q1_all, q1_all);    # Array of hR1 / hRall.
        aboot_q1_0 = c(aboot_q1_0, q1_0);          # Array of hR1 / hR0.            
        # ......................................................................................
        # . Indicate progress :
        # ......................................................................................
        cat(".");
        
        if (l%%50 == 0) {
          cat("Processed ", l, " steps out of ", nresamp, "\n", sep = "");
        }
        # ......................................................................................        
      }

      cat("\n");
      # ...............................................................................................


      
      # .............................................................
      cat(" ..........  Bootstrap computation done.\n", sep = "");
      # .............................................................


      
      # ...............................................................................................
      # . First compute general statistics :
      # ...............................................................................................
      hRallLo = quantile(aboot_hRall, probs = 0.025);
      hRall = median(aboot_hRall);
      hRallHi = quantile(aboot_hRall, probs = 0.975);
              
      hR0Lo = quantile(aboot_hR0, probs = 0.025);
      hR0 = median(aboot_hR0);
      hR0Hi = quantile(aboot_hR0, probs = 0.975);      
              
      hR1Lo = quantile(aboot_hR1, probs = 0.025);
      hR1 = median(aboot_hR1);
      hR1Hi = quantile(aboot_hR1, probs = 0.975);      

      pR0Lo = quantile(aboot_pR0, probs = 0.025);
      pR0 = median(aboot_pR0);
      pR0Hi = quantile(aboot_pR0, probs = 0.975);      
              
      pR1Lo = quantile(aboot_pR1, probs = 0.025);
      pR1 = median(aboot_pR1);
      pR1Hi = quantile(aboot_pR1, probs = 0.975);      
              
      q0_allLo = quantile(aboot_q0_all, probs = 0.025);
      q0_all = median(aboot_q0_all);
      q0_allHi = quantile(aboot_q0_all, probs = 0.975);

      q1_allLo = quantile(aboot_q1_all, probs = 0.025);
      q1_all = median(aboot_q1_all);
      q1_allHi = quantile(aboot_q1_all, probs = 0.975);

      q1_0Lo = quantile(aboot_q1_0, probs = 0.025);
      q1_0 = median(aboot_q1_0);
      q1_0Hi = quantile(aboot_q1_0, probs = 0.975);
      # ...............................................................................................


      
      # ..............................................................................................
      # . I. Compute P-values :  relevant to PERMUTATION resampling.
      # .
      # . 1A. q0all = hR0 / hRall : one-sided P-value : test for hR0 > hRall :
      # ..............................................................................................      
      npval0 = length(which(aboot_q0_all > q0_all_base));                  # Number for which q* < q_base.

      theta = Stat.probabilityOnCountBayes(k = npval0 , n = nresamp);      # Bayesian estimates.

      pvalOne_q0_allLo = theta$pLo;                                        # Lower bound on CI.
      pvalOne_q0_all = theta$p;                                            # Median estimator. 
      pvalOne_q0_allHi = theta$pHi;                                        # Upper bound on CI.
      # ..............................................................................................            
      # . 1B. q0all = hR0 / hRall : two-sided P-value : test for hR0 != hRall :
      # ..............................................................................................
      pvalTwo_q0_allLo = ifelse(theta$pLo < 0.5, 2.0 * theta$pLo, 2.0 * (1.0 - theta$pLo));
      pvalTwo_q0_all = ifelse(theta$p < 0.5, 2.0 * theta$p, 2.0 * (1.0 - theta$p));
      pvalTwo_q0_allHi = ifelse(theta$pHi < 0.5, 2.0 * theta$pHi, 2.0 * (1.0 - theta$pHi));
      # ..............................................................................................
      # . 2A. q1all = hR1 / hRall : one-sided P-value : test for hR1 < hRall :
      # ..............................................................................................      
      npval1 = length(which(aboot_q1_all < q1_all_base));                  # Number for which q* < q_base.

      theta = Stat.probabilityOnCountBayes(k = npval1 , n = nresamp);       # Bayesian estimates.

      pvalOne_q1_allLo = theta$pLo;                                        # Lower bound on CI.
      pvalOne_q1_all = theta$p;                                            # Median estimator. 
      pvalOne_q1_allHi = theta$pHi;                                        # Upper bound on CI.
      # ..............................................................................................            
      # . 2B. q1all = hR1 / hRall : two-sided P-value : test for hR1 != hRall :
      # ..............................................................................................
      pvalTwo_q1_allLo = ifelse(theta$pLo < 0.5, 2.0 * theta$pLo, 2.0 * (1.0 - theta$pLo));
      pvalTwo_q1_all = ifelse(theta$p < 0.5, 2.0 * theta$p, 2.0 * (1.0 - theta$p));
      pvalTwo_q1_allHi = ifelse(theta$pHi < 0.5, 2.0 * theta$pHi, 2.0 * (1.0 - theta$pHi));
      # ..............................................................................................
      # . 3A. q10 = hR1 / hR0 : one-sided P-value : test for hR1 < hR0 :
      # ..............................................................................................      
      npval10 = length(which(aboot_q1_0 < q1_0_base));                     # Number for which q* < q_base.

      theta = Stat.probabilityOnCountBayes(k = npval10 , n = nresamp);     # Bayesian estimates.

      pvalOne_q1_0Lo = theta$pLo;                                          # Lower bound on CI.
      pvalOne_q1_0 = theta$p;                                              # Median estimator. 
      pvalOne_q1_0Hi = theta$pHi;                                          # Upper bound on CI.
      # ..............................................................................................            
      # . 2B. q10 = hR1 / hRall : two-sided P-value : test for hR1 != hRall :
      # ..............................................................................................
      pvalTwo_q1_0Lo = ifelse(theta$pLo < 0.5, 2.0 * theta$pLo, 2.0 * (1.0 - theta$pLo));
      pvalTwo_q1_0 = ifelse(theta$p < 0.5, 2.0 * theta$p, 2.0 * (1.0 - theta$p));
      pvalTwo_q1_0Hi = ifelse(theta$pHi < 0.5, 2.0 * theta$pHi, 2.0 * (1.0 - theta$pHi));
      # ..............................................................................................



      
      # ..............................................................................................      
      # . pge1_qRatio = Prob(qRatio >= 1)
      # .               relevant to BOOTSTRAP resampling.
      # .               pge1_qRatio = 1 - {confidence that we are reducing risk in the sensitive subset}
      # ..............................................................................................
#      npge1 = length(which(aboot_qRatio >= 1.0));                    # Number for which qRatio >= 1.
#      theta = Stat.probabilityOnCountBayes(k = npge1 , n = nresamp);   # Bayesian estimates.

#      pge1_qRatioLo = theta$pLo;                                     # Lower bound on CI.
#      pge1_qRatio = theta$p;                                         # Median estimator. 
#      pge1_qRatioHi = theta$pHi;                                     # Upper bound on CI.
      # ...............................................................................................

      


      # ...............................................................................................
      # . Package all output in a list :
      # . Save parameters, output arrays, and summary statistics.
      # ...............................................................................................
      bs = list(nresamp = nresamp,
                rngSeed = rngSeed,
                resamplingType = resamplingType,

                hRall_base =  hRall_base,
                hR0_base =  hR0_base,
                hR0_base =  hR0_base,        

                pRall_base = pRall_base,        # P-value for all patients.
                pR0_base = pR0_base,            # P-value for subset 0.
                pR1_base = pR1_base,            # P-value for subset 1.      
      
                q0_all_base = q0_all_base,      # Relative hazard ratio, subset 0 relative to all patients.
                q1_all_base = q1_all_base,      # Relative hazard ratio, subset 1 relative to all patients.
                q1_0_base = q1_0_base,          # Relative hazard ratio, subset 1 relative to subset 0.
        
                aboot_hRall = aboot_hRall, 
                aboot_hR0 = aboot_hR0,
                aboot_hR1 = aboot_hR1,         

                aboot_q0_all = aboot_q0_all,
                aboot_q1_all = aboot_q1_all,
                aboot_q1_0 = aboot_q1_0,                

                hRallLo =  hRallLo,
                hRall =    hRall,
                hRallHi =  hRallHi,
                                    
                hR0Lo =    hR0Lo, 
                hR0 =      hR0,   
                hR0Hi =    hR0Hi,
                                    
                hR1Lo =    hR1Lo,
                hR1 =      hR1,   
                hR1Hi =    hR1Hi,
                                    
                pR0Lo =    pR0Lo,
                pR0 =      pR0,   
                pR0Hi =    pR0Hi,
                                    
                pR1Lo =    pR1Lo,
                pR1 =      pR1,   
                pR1Hi =    pR1Hi,
                                    
                q0_allLo = q0_allLo ,
                q0_all =   q0_all,
                q0_allHi = q0_allHi,
                                    
                q1_allLo = q1_allLo,
                q1_all =   q1_all,
                q1_allHi = q1_allHi,
                                    
                q1_0Lo =   q1_0Lo,
                q1_0 =     q1_0,  
                q1_0Hi =   q1_0Hi,

                npval0 = npval0,
                pvalOne_q0_allLo = pvalOne_q0_allLo ,
                pvalOne_q0_all   = pvalOne_q0_all   ,
                pvalOne_q0_allHi = pvalOne_q0_allHi ,
                pvalTwo_q0_allLo = pvalTwo_q0_allLo ,
                pvalTwo_q0_all   = pvalTwo_q0_all   ,
                pvalTwo_q0_allHi = pvalTwo_q0_allHi ,

                npval1 = npval1,
                pvalOne_q1_allLo = pvalOne_q1_allLo ,
                pvalOne_q1_all   = pvalOne_q1_all   ,
                pvalOne_q1_allHi = pvalOne_q1_allHi ,
                pvalTwo_q1_allLo = pvalTwo_q1_allLo ,
                pvalTwo_q1_all   = pvalTwo_q1_all   ,
                pvalTwo_q1_allHi = pvalTwo_q1_allHi ,

                npval10 = npval10,
                pvalOne_q1_0Lo   = pvalOne_q1_0Lo   ,
                pvalOne_q1_0     = pvalOne_q1_0     ,
                pvalOne_q1_0Hi   = pvalOne_q1_0Hi   ,
                pvalTwo_q1_0Lo   = pvalTwo_q1_0Lo   ,
                pvalTwo_q1_0     = pvalTwo_q1_0     ,
                pvalTwo_q1_0Hi   = pvalTwo_q1_0Hi 
        );

      class(bs) = "spc.cox.cov.boot";
      # ...............................................................................................            



      # ............
      return (bs);
      # ............

  
}

# =======================================================================================================
# . End of SuperPcBoot.computeCoxWithCovSignificanceOnGIVENSplit.
# =======================================================================================================







# =======================================================================================================
# . SuperPcBoot.extractResampledCoxWithCovStats : extracts confidence intervals or P-values from
# . -------------------------------------------   resampled Cox statistics on sensitive versus resistant
# .                                               calls in the context of two-armed studies.
# .
# . This uses as input the results of calls to functions :
# .
# .         cvBoot = GlmnetCv.crossValidateCoxWithCovBoot();
# .                                                        
# .
# .......................................................................................................
# .   Syntax:
# .
# .       SuperPcBoot.extractResampledCoxWithCovStats(cvBoot);
# .
# .   In:
# .
# .        cvBoot = result of call to :  GlmnetCv.crossValidateCoxWithCovBoot();
# .
# .  Out:
# .        
# .
# =======================================================================================================

SuperPcBoot.extractResampledCoxWithCovStats <- function(cvBoot)
{

      # ............................................................................
      cat(" ..........  Entry in SuperPcBoot.extractResampledCoxWithCovStats.\n");
      # ............................................................................

      
      # ............................................................................
      if (class(cvBoot) != 'glmnet.cox.cov.cv.boot') {
        cat("ERROR: from SuperPcBoot.extractResampledCoxWithCovStats:\n");
        cat("Class cvBoot = ", class(cvBoot), " is not valid.\n");
        stop();
      }

      stopifnot((cvBoot$bootType == 'fullBoot')                    # Failsafe.
                || (cvBoot$bootType == 'splitOnly')
                || (cvBoot$bootType == 'permutation'));
      # ............................................................................      



      # .......................................................................
      # . First get values for the actual, unresampled training set :
      # .......................................................................      
      sumCObs = cvBoot$sumCObs;

      hRC_obs = sumCObs$hRC;
      hR_all_obs = sumCObs$hR_all;
      hR_S_obs = sumCObs$hR_S;
      hR_R_obs = sumCObs$hR_R;
      ratio_hR_S_to_R_obs = sumCObs$ratio_hR_S_to_R;
      abc_obs = sumCObs$abc;
      nS_obs = sumCObs$nS;
      nR_obs = sumCObs$nR;
      # .........................................................................
     

      
      # ........................................................................
      # . For the statistics from the resampled data sets, put into arrays :
      # ........................................................................      
      nboot = cvBoot$nboot;

      ahRC = c();                 # Thresholds on DloghR actually used.
      ahR_all = c();              # Hazard ratio for all samples.
      ahR_S = c();                # Hazard ratio for sensitive samples.
      ahR_R = c();                # Hazard ratio for resistant samples.
      aratio_hR_S_to_R = c();     # S/R ratio of hazards.      
      aAbc = c();                 # Area between curves, abc = AUC(R) - AUC(S).

      anS = c();                  # Number of sensitives.
      anR = c();                  # Number of resistants.

      for (l in 1:nboot) {
        sumC = cvBoot$asumC[[l]];                    # Note that asumC is a list.
        ahRC[l] = sumC$hRC;
        ahR_all[l] = sumC$hR_all;
        ahR_S[l] = sumC$hR_S;
        ahR_R[l] = sumC$hR_R;
        aratio_hR_S_to_R[l] = sumC$ratio_hR_S_to_R;
        aAbc[l] = sumC$abc;
        anS[l] = sumC$nS;
        anR[l] = sumC$nR;        
      }

      aLogratio_hR_S_to_R = log(aratio_hR_S_to_R);
      # ........................................................................      

      
        
      # ........................................................................
      # . Apply Shapiro-Wilk tests of normality:
      # . >>1. log-ratios hR(S) / hR(R) :
      # ........................................................................
      if (nboot > 5000) {
        ybuf = sample(aLogratio_hR_S_to_R, size = 5000);    # Test requires 3 <= n <= 5000.
      } else {
        ybuf = aLogratio_hR_S_to_R;
      }
          
      st  = shapiro.test(ybuf);
      pval_NORMAL_Logratio_hR_S_to_R = st$p.value;

      mu_logratio_hR_S_to_R = mean(aLogratio_hR_S_to_R);     # Mean estimate.
      sd_logratio_hR_S_to_R = sd(aLogratio_hR_S_to_R);       # Standard dev.
      # ........................................................................
      # . >>2. ABC :
      # ........................................................................
      if (nboot > 5000) {
        ybuf = sample(aAbc, size = 5000);    # Test requires 3 <= n <= 5000.
      } else {
        ybuf = aAbc;
      }
          
      st  = shapiro.test(ybuf);
      pval_NORMAL_abc = st$p.value;

      mu_abc = mean(aAbc);                                     # Mean estimate.
      sd_abc = sd(aAbc);                                       # Standard dev.
      # .........................................................................
      

      
      
      # ............................................................................
      # . >>1. FULL BOOTSTRAP RESAMPLING, or FOLD-ONLY RESAMPLING : 
      # . generate 95% confidence intervals and a confidence level.
      # ............................................................................
      if ((cvBoot$bootType == 'fullBoot') || (cvBoot$bootType == 'splitOnly')) {
        # ..........................................................................
        # . Threshold used :
        # ..........................................................................
        hRCLo = quantile(ahRC, probs = 0.025);
        hRCMed = median(ahRC);
        hRCHi = quantile(ahRC, probs = 0.975);        
        # ..........................................................................
        # . All samples :
        # ..........................................................................
        hR_allLo = quantile(ahR_all, probs = 0.025);
        hR_all = median(ahR_all);
        hR_allHi = quantile(ahR_all, probs = 0.975);
        # ..........................................................................
        # . hR(S) : median and confidence interval :
        # ..........................................................................
        hR_SLo = quantile(ahR_S, probs = 0.025);
        hR_S = median(ahR_S);
        hR_SHi = quantile(ahR_S, probs = 0.975);
        # ..........................................................................
        # . hR(S) : compute confidence probabilities :
        # ..........................................................................
        cpr = Stat.computeConfProbOnCount(ax = log(ahR_S/ahR_all), xc = 0.0, side = 'negative');

        nconf_hR_S = cpr$ncount;                            # Count of samples with hR(S) < hR(all).
        pconf_hR_SLo = cpr$pconfLo;                         # Lower bound on CI (95%). 
        pconf_hR_S = cpr$pconf;                             # Median estimator.        
        pconf_hR_SHi = cpr$pconfHi;                         # Upper bound on CI (95%). 
        pconf_hR_S_ANALYTIC = cpr$pconf_ANALYTIC;           # Analytic estimate        
        # ..........................................................................
        # . hR(S) : assign dummy P-values, as this does not test against H0.
        # ..........................................................................
        npval_hR_S = 0;                                     # Dummy.
        pval_hR_SLo = 1.0;                                  # Dummy.
        pval_hR_S = 1.0;                                    # Dummy.
        pval_hR_SHi = 1.0;                                  # Dummy.
        pval_hR_S_ANALYTIC = 1.0;                           # Dummy.
        # ..........................................................................
        # . hR(R) : resistant samples :
        # ..........................................................................
        hR_RLo = quantile(ahR_R, probs = 0.025);
        hR_R = median(ahR_R);
        hR_RHi = quantile(ahR_R, probs = 0.975);
        # ..........................................................................
        # . S to R ratio : the confidence level is the probability
        # . that hR(S) / hR(R) <=1 based on the resampled data.
        # . (a large confidence level is "good").
        # ...........................................................................
        ratio_hR_S_to_RLo = quantile(aratio_hR_S_to_R, probs = 0.025);
        ratio_hR_S_to_R = median(aratio_hR_S_to_R);
        ratio_hR_S_to_RHi = quantile(aratio_hR_S_to_R, probs = 0.975);

        nbuf = length(which(aratio_hR_S_to_R <= 1.0));                 # Number for which hR(S) / hR(R) <= 1.
        theta = Stat.probabilityOnCountBayes(k = nbuf, n = nboot);     # Bayesian estimates.

        nconf_ratio_hR_S_to_R = nbuf;                                  # Count for hR(S) / hR(R) <= 1 events.
        
        pconf_ratio_hR_S_to_RLo = theta$pLo;                           # Lower bound on CI (95%).
        pconf_ratio_hR_S_to_R = theta$p;                               # Median estimator. 
        pconf_ratio_hR_S_to_RHi = theta$pHi;                           # Upper bound on CI (95%).

        pconf_ratio_hR_S_to_R_ANALYTIC =                               # Analytic estimate
                         pnorm(0.0, mean = mu_logratio_hR_S_to_R,      # based on gaussian model
                               sd = sd_logratio_hR_S_to_R,             # and sample mean/sd.
                               lower.tail = TRUE);

        npval_ratio_hR_S_to_R = 0;                                     # Dummy.
        pval_ratio_hR_S_to_RLo = 1.0;                                  # Dummy.
        pval_ratio_hR_S_to_R = 1.0;                                    # Dummy.
        pval_ratio_hR_S_to_RHi = 1.0;                                  # Dummy.
        pval_ratio_hR_S_to_R_ANALYTIC = 1.0;                           # Dummy.
        # ...........................................................................
        # . Area between curves : the confidence level is the probability
        # . that AUC(S) <= AUC(R) based on the resampled data.
        # . (a large confidence level is "good").
        # ............................................................................
        abcLo = quantile(aAbc, probs = 0.025);
        abc = median(aAbc);
        abcHi = quantile(aAbc, probs = 0.975);

        nbuf = length(which(aAbc >= 0.0));                             # Number for which AUC(S) <= AUC(R).
        theta = Stat.probabilityOnCountBayes(k = nbuf, n = nboot);     # Bayesian estimates.

        nconf_abc = nbuf;                                              # Count for AUC(S) <= AUC(R)s.
        
        pconf_abcLo = theta$pLo;                                       # Lower bound on CI (95%).
        pconf_abc = theta$p;                                           # Median estimator. 
        pconf_abcHi = theta$pHi;                                       # Upper bound on CI (95%).
        pconf_abc_ANALYTIC =  pnorm(0.0, mean = mu_abc,                # Analytic estimate
                                    sd = sd_abc,                       # based on gaussian model
                                    lower.tail = FALSE);               # and sample mean/sd.

        npval_abc = 0;                                                 # Dummy.        
        pval_abcLo = 1.0;                                              # Dummy.
        pval_abc = 1.0;                                                # Dummy.
        pval_abcHi = 1.0;                                              # Dummy.
        pval_abc_ANALYTIC = 1.0;                                       # Dummy.        
        # ..........................................................................
        # . Numbers of sensitives and resistants :
        # ..........................................................................
        nSLo = quantile(anS, probs = 0.025);
        nS = median(anS);
        nSHi = quantile(anS, probs = 0.975);

        nRLo = quantile(anR, probs = 0.025);
        nR = median(anR);
        nRHi = quantile(anR, probs = 0.975);        
        # ..........................................................................            
      }
      # ............................................................................      


      
      
      # ............................................................................
      # . >>2. PERMUTATION RESAMPLING :
      # . generate 95% confidence intervals and a P-value.
      # ............................................................................
      if (cvBoot$bootType == 'permutation') {
        # ..........................................................................
        # . Threshold used :
        # ..........................................................................
        hRCLo = quantile(ahRC, probs = 0.025);
        hRCMed = median(ahRC);
        hRCHi = quantile(ahRC, probs = 0.975);        
        # ..........................................................................
        # . All samples :
        # ..........................................................................
        hR_allLo = quantile(ahR_all, probs = 0.025);
        hR_all = median(ahR_all);
        hR_allHi = quantile(ahR_all, probs = 0.975);
        # ..........................................................................
        # . hR(S) : median and confidence interval :
        # ..........................................................................
        hR_SLo = quantile(ahR_S, probs = 0.025);
        hR_S = median(ahR_S);
        hR_SHi = quantile(ahR_S, probs = 0.975);
        # ..........................................................................
        # . hR(S) : assign dummy values, as this only tests against H0.
        # ..........................................................................
        nconf_hR_S = 0;                                     # Dummy.
        pconf_hR_SLo = 0.0;                                 # Dummy.
        pconf_hR_S = 0.0;                                   # Dummy.
        pconf_hR_SHi = 0.0;                                 # Dummy.
        pconf_hR_S_ANALYTIC = 0.0;                          # Dummy.
        # ..........................................................................
        # . hR(S) : compute P-value :
        # ..........................................................................
        cpr = Stat.computeConfProbOnCount(ax = log(ahR_S), xc = log(hR_S_obs), side = 'negative');
        
        npval_hR_S = cpr$ncount;                            # Count of samples with hR(S*) < hR(S)_obs.
        pval_hR_SLo = cpr$pconfLo;                          # Lower bound on CI (95%). 
        pval_hR_S = cpr$pconf;                              # Median estimator.        
        pval_hR_SHi = cpr$pconfHi;                          # Upper bound on CI (95%). 
        pval_hR_S_ANALYTIC = cpr$pconf_ANALYTIC;            # Analytic estimate        
        # ..........................................................................
        # . hR(R) : resistant samples :
        # ..........................................................................
        hR_RLo = quantile(ahR_R, probs = 0.025);
        hR_R = median(ahR_R);
        hR_RHi = quantile(ahR_R, probs = 0.975);
        # ..........................................................................
        # . S to R ratio : the P-value is the one-tailed probability
        # . that (hR(S) / hR(R))_permutation <= (hR(S) / hR(R))_obs.
        # ..........................................................................
        ratio_hR_S_to_RLo = quantile(aratio_hR_S_to_R, probs = 0.025);
        ratio_hR_S_to_R = median(aratio_hR_S_to_R);
        ratio_hR_S_to_RHi = quantile(aratio_hR_S_to_R, probs = 0.975);

        nbuf = length(which(aratio_hR_S_to_R <= ratio_hR_S_to_R_obs)); # Number (hR(S)/hR(R)) < (hR(S) / hR(R))_obs
        theta = Stat.probabilityOnCountBayes(k = nbuf, n = nboot);     # Bayesian estimates.

        npval_ratio_hR_S_to_R = nbuf;                                 # Number (hR(S)/hR(R)) < (hR(S) / hR(R))_obs
        
        pval_ratio_hR_S_to_RLo = theta$pLo;                           # Lower bound on CI (95%).
        pval_ratio_hR_S_to_R = theta$p;                               # Median estimator. 
        pval_ratio_hR_S_to_RHi = theta$pHi;                           # Upper bound on CI (95%).
        pval_ratio_hR_S_to_R_ANALYTIC =                               # Analytic estimate
                         pnorm(log(ratio_hR_S_to_R_obs),              # based on gaussian model
                               mean = mu_logratio_hR_S_to_R,          # and sample mean/sd.
                               sd = sd_logratio_hR_S_to_R,
                               lower.tail = TRUE);

        nconf_ratio_hR_S_to_R = 0;                                    # Dummy.
        pconf_ratio_hR_S_to_RLo = 1.0;                                # Dummy.
        pconf_ratio_hR_S_to_R = 1.0;                                  # Dummy.
        pconf_ratio_hR_S_to_RHi = 1.0;                                # Dummy.
        pconf_ratio_hR_S_to_R_ANALYTIC = 1.0;                         # Dummy.       
        # ..........................................................................
        # . Area between curves :
        # ..........................................................................
        abcLo = quantile(aAbc, probs = 0.025);
        abc = median(aAbc);
        abcHi = quantile(aAbc, probs = 0.975);

        nbuf = length(which(aAbc >= abc_obs));                         # Number for which abc >= abc_obs.
        theta = Stat.probabilityOnCountBayes(k = nbuf, n = nboot);     # Bayesian estimates.

        npval_abc = nbuf;                                              # Number for which abc >= abc_obs.
        
        pval_abcLo = theta$pLo;                                        # Lower bound on CI (95%).
        pval_abc = theta$p;                                            # Median estimator. 
        pval_abcHi = theta$pHi;                                        # Upper bound on CI (95%).
        pval_abc_ANALYTIC = pnorm(abc_obs, mean = mu_abc,              # Analytic estimate            
                                  sd = sd_abc,                         # based on gaussian model
                                  lower.tail = FALSE);                 # and sample mean/sd.

        nconf_abc = 0;                                                 # Dummy.
        pconf_abcLo = 1.0;                                             # Dummy.
        pconf_abc = 1.0;                                               # Dummy.
        pconf_abcHi = 1.0;                                             # Dummy.
        pconf_abc_ANALYTIC = 1.0;                                             # Dummy.
        # ..........................................................................
        # . Numbers of sensitives and resistants :
        # ..........................................................................
        nSLo = quantile(anS, probs = 0.025);          # Will be constant under permutation.
        nS = median(anS);                             # Will be constant under permutation.
        nSHi = quantile(anS, probs = 0.975);          # Will be constant under permutation.

        nRLo = quantile(anR, probs = 0.025);          # Will be constant under permutation.
        nR = median(anR);                             # Will be constant under permutation.
        nRHi = quantile(anR, probs = 0.975);          # Will be constant under permutation.
        # ..........................................................................      
      }
      # ............................................................................



      # .............................................................................
      # . Package the results :
      # .............................................................................
      rs = list(bootType = cvBoot$bootType,     # type of resampling.
                nboot = cvBoot$nboot,           # Number of bootstarp resamplings.
                rngSeed = cvBoot$rngSeed,       # Random number seed.
                hRC = cvBoot$hRC,               # log(hRC) = DloghR decision threshold.
                n = cvBoot$n,                   # Total number of samples.
                # ....................................................................
                # . Values for the actual, non-resampled data set :
                # ....................................................................
                hRC_obs = hRC_obs,                           # Threshold used.
                hR_all_obs = hR_all_obs,                     # hR(all).
                hR_S_obs = hR_S_obs,                         # hR(S).
                hR_R_obs = hR_R_obs,                         # hR(R).
                ratio_hR_S_to_R_obs = ratio_hR_S_to_R_obs,   # hR(S) / hR(R).
                abc_obs = abc_obs,                           # abc = AUC(R) - AUC(S).
                nS_obs = nS_obs,                             # Number of sensitives.
                nR_obs = nR_obs,                             # Number of resistants.
                # ....................................................................
                # . Extracted arrays :
                # ....................................................................
                ahRC = ahRC,                                 # nboot : array of thresholds actually used.
                ahR_all = ahR_all,                           # nboot : array of hR(all) values.
                ahR_S = ahR_S,                               # nboot : array of hR(S) values.
                ahR_R = ahR_R,                               # nboot : array of hR(R) values.
                aratio_hR_S_to_R = aratio_hR_S_to_R,         # nboot : array of hR(S)/ hR(R) values.
                aAbc = aAbc,                                 # nboot : array of abc values.
                anS = anS,                                   # nboot : array of number of sensitives.
                anR = anR,                                   # nboot : array of number of resistants.        
                # ....................................................................
                # . Normality tests :
                # ....................................................................                
                pval_NORMAL_Logratio_hR_S_to_R = pval_NORMAL_Logratio_hR_S_to_R,      # Normality test on hR(S)/hR(R) distribution.
                pval_NORMAL_abc = pval_NORMAL_abc,                                    # Normality test ob abc distribution.
                # ....................................................................
                # . Summary statistics : separate populations.
                # ....................................................................
                hRCLo = hRCLo,                     # 2.5% bound on hRC used.
                hRCMed = hRCMed,                   # Median on hRC.
                hRCHi = hRCHi,                     # 97.5% bound on hRC.
        
                hR_allLo =  hR_allLo,              # Hazard ratios for all samples,
                hR_all =    hR_all,                # with 95% confidence interval.
                hR_allHi =  hR_allHi,
                                                              
                hR_SLo =    hR_SLo,                # Hazard ratios for sensitive samples,
                hR_S =      hR_S,                  # with 95% confidence interval.
                hR_SHi =    hR_SHi,                          
                                                              
                hR_RLo =    hR_RLo,                # Hazard ratios for resistant samples,
                hR_R =      hR_R,                  # with 95% confidence interval.
                hR_RHi =    hR_RHi,
                # ....................................................................
                # . Summary statistics : hR(S) 
                # ....................................................................
                nconf_hR_S =           nconf_hR_S,    # Count for hR(S) <= hR(all) events.        
                pconf_hR_SLo =         pconf_hR_SLo,  # Prob(hR(S) < hR(all))
                pconf_hR_S =           pconf_hR_S,    # with 95% confidence interval.
                pconf_hR_SHi =         pconf_hR_SHi,         
                pconf_hR_S_ANALYTIC =  pconf_hR_S_ANALYTIC,  # Analytic model estimate.

                npval_hR_S =           npval_hR_S,    # Number (hR(S)/hR(all))* < (hR(S) / hR(R))_obs
                pval_hR_SLo =          pval_hR_SLo,   # Prob(ratio* < ratio_obs),
                pval_hR_S =            pval_hR_S,     # with 95% confidence interval.
                pval_hR_SHi =          pval_hR_SHi,          
                pval_hR_S_ANALYTIC =   pval_hR_S_ANALYTIC,   # Analytic model estimate.
                # ....................................................................
                # . Summary statistics : hR(S) / hR(R).
                # ....................................................................
                ratio_hR_S_to_RLo =    ratio_hR_S_to_RLo,  # hR(S) / hR(R) statistics,
                ratio_hR_S_to_R =      ratio_hR_S_to_R,    # with 95% confidence interval.
                ratio_hR_S_to_RHi =    ratio_hR_S_to_RHi,               

                nconf_ratio_hR_S_to_R =           nconf_ratio_hR_S_to_R,    # Count for hR(S) / hR(R) <= 1 events.        
                pconf_ratio_hR_S_to_RLo =         pconf_ratio_hR_S_to_RLo,  # Prob(ratio < 1),
                pconf_ratio_hR_S_to_R =           pconf_ratio_hR_S_to_R,    # with 95% confidence interval.
                pconf_ratio_hR_S_to_RHi =         pconf_ratio_hR_S_to_RHi,         
                pconf_ratio_hR_S_to_R_ANALYTIC =  pconf_ratio_hR_S_to_R_ANALYTIC,  # Analytic model estimate.

                npval_ratio_hR_S_to_R =           npval_ratio_hR_S_to_R,    # Number (hR(S)/hR(R)) < (hR(S) / hR(R))_obs
                pval_ratio_hR_S_to_RLo =          pval_ratio_hR_S_to_RLo,   # Prob(ratio* < ratio_obs),
                pval_ratio_hR_S_to_R =            pval_ratio_hR_S_to_R,     # with 95% confidence interval.
                pval_ratio_hR_S_to_RHi =          pval_ratio_hR_S_to_RHi,          
                pval_ratio_hR_S_to_R_ANALYTIC =   pval_ratio_hR_S_to_R_ANALYTIC,   # Analytic model estimate.
                # ....................................................................
                # . Summary statistics : area between curves.
                # ....................................................................
                abcLo =    abcLo,                            # Area between curves statistics,
                abc =      abc,                              # with 95% confidence interval.
                abcHi =    abcHi,                           

                nconf_abc = nconf_abc,                       # Count for AUC(S) <= AUC(R)s.        
                pconf_abcLo =           pconf_abcLo,         # Prob(abc > 0).               
                pconf_abc =             pconf_abc,           # with 95% confidence interval.         
                pconf_abcHi =           pconf_abcHi,                     
                pconf_abc_ANALYTIC =    pconf_abc_ANALYTIC,  # Analytic model estimate.

                npval_abc = npval_abc,                       # Number for which abc >= abc_obs.        
                pval_abcLo =            pval_abcLo,          # Prob(abc* > abc_obs),
                pval_abc =              pval_abc,            # with 95% confidence interval.
                pval_abcHi =            pval_abcHi,                      
                pval_abc_ANALYTIC =     pval_abc_ANALYTIC,   # Analytic model estimate.
                # ....................................................................
                # . Summary statistics : number of sensitives and resistants.
                # ....................................................................
                nSLo =    nSLo,                            # Number of sensitives,
                nS =      nS,                              # with 95% confidence interval.
                nSHi =    nSHi,

                nRLo =    nRLo,                            # Number of resistants
                nR =      nR,                              # with 95% confidence interval.
                nRHi =    nRHi
                # ....................................................................
        );

      class(rs) = 'cox.cov.boot.extract';
      # .............................................................................


      # ............
      return (rs);
      # ............
      
}

# =======================================================================================================
# . End of SuperPcBoot.extractResampledCoxWithCovStats.
# =======================================================================================================
